n8n documentation snapshot (v1.115.2) — JSON archive
--------------------------------------------------
This archive contains a curated JSON snapshot of selected n8n documentation pages relevant to version 1.115.2.
Files:
  - n8n_docs_v1.115.2_snapshot.json  : The main JSON with page summaries and URLs.

Sources (important pages used to assemble this snapshot):
  - Release notes (docs.n8n.io release notes) — lists 1.115.2 as current latest and release items.
  - Installation (npm & Docker) pages — current latest version and installation guidance.
  - Webhook & Respond to Webhook nodes — node parameter and workflow behavior guidance.
  - Export/import workflows and CLI commands — JSON import/export guidance.
  - Endpoints environment variables — webhook URL config and reverse-proxy notes.

Limitations:
  - This is a curated snapshot, not a full site mirror. It contains concise snapshots (summaries), direct URLs to each original page, and guidance notes.
  - If you want a complete crawl (full HTML/text for every docs page), I can generate that next — but it requires more time and will create a substantially larger archive.
  - The snapshots were assembled by programmatically visiting the listed docs pages and extracting key sections.

Generated files were produced on: 2025-10-17 (Singapore local date).
