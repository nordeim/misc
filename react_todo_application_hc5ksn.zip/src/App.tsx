import React, { useState, useEffect } from 'react'
import { Check, Trash2, Edit } from 'lucide-react'

interface Todo {
  id: string
  text: string
  completed: boolean
}

function App() {
  const [todos, setTodos] = useState<Todo[]>(() => {
    const savedTodos = localStorage.getItem('todos')
    if (savedTodos) {
      return JSON.parse(savedTodos)
    } else {
      return []
    }
  })
  const [newTodo, setNewTodo] = useState('')
  const [editingTodoId, setEditingTodoId] = useState<string | null>(null)
  const [editText, setEditText] = useState('')

  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos))
  }, [todos])

  const handleAddTodo = () => {
    if (newTodo.trim()) {
      setTodos([...todos, { id: crypto.randomUUID(), text: newTodo, completed: false }])
      setNewTodo('')
    }
  }

  const handleDeleteTodo = (id: string) => {
    setTodos(todos.filter((todo) => todo.id !== id))
  }

  const handleCompleteTodo = (id: string) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo,
      ),
    )
  }

  const handleEditTodo = (todo: Todo) => {
    setEditingTodoId(todo.id)
    setEditText(todo.text)
  }

  const handleUpdateTodo = (id: string) => {
    if (editText.trim()) {
      setTodos(
        todos.map((todo) =>
          todo.id === id ? { ...todo, text: editText } : todo,
        ),
      )
      setEditingTodoId(null)
      setEditText('')
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-300 to-blue-600 shadow-lg transform -skew-y-6 sm:skew-y-0 sm:-rotate-6 sm:rounded-3xl"></div>
        <div className="relative px-4 py-10 bg-white shadow-lg sm:rounded-3xl sm:p-20">
          <div className="max-w-md mx-auto">
            <div>
              <h1 className="text-2xl font-semibold text-gray-800">My Todo List</h1>
            </div>
            <div className="divide-y divide-gray-200">
              <div className="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <div className="flex rounded-md shadow-sm">
                  <input
                    type="text"
                    className="flex-1 block w-full min-w-0 rounded-none rounded-l-md border-gray-300 px-3 py-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    placeholder="Add new todo"
                    value={newTodo}
                    onChange={(e) => setNewTodo(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' ? handleAddTodo() : null}
                  />
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent font-medium rounded-r-md shadow-sm text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm"
                    onClick={handleAddTodo}
                  >
                    Add
                  </button>
                </div>
              </div>
              <div className="pt-6 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <ul className="space-y-2">
                  {todos.map((todo) => (
                    <li key={todo.id} className="flex items-center justify-between py-2">
                      {editingTodoId === todo.id ? (
                        <div className="flex flex-1 rounded-md shadow-sm">
                          <input
                            type="text"
                            className="flex-1 block w-full min-w-0 rounded-none rounded-l-md border-gray-300 px-3 py-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' ? handleUpdateTodo(todo.id) : null}
                          />
                          <button
                            type="button"
                            className="inline-flex items-center px-4 py-2 border border-transparent font-medium rounded-r-md shadow-sm text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm"
                            onClick={() => handleUpdateTodo(todo.id)}
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            className="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm"
                            onClick={() => setEditingTodoId(null)}
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <>
                          <label className="flex items-center space-x-2 flex-1">
                            <input
                              type="checkbox"
                              className="form-checkbox h-5 w-5 text-blue-600 rounded focus:ring-blue-500"
                              checked={todo.completed}
                              onChange={() => handleCompleteTodo(todo.id)}
                            />
                            <span className={` ${todo.completed ? 'line-through text-gray-500' : ''}`}>
                              {todo.text}
                            </span>
                          </label>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleEditTodo(todo)}
                              className="p-2 rounded-md hover:bg-gray-100"
                            >
                              <Edit className="h-5 w-5 text-gray-500" />
                            </button>
                            <button
                              onClick={() => handleDeleteTodo(todo.id)}
                              className="p-2 rounded-md hover:bg-gray-100"
                            >
                              <Trash2 className="h-5 w-5 text-red-500" />
                            </button>
                          </div>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
                {todos.length === 0 && <p className="text-center text-gray-500">No todos yet. Add some!</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
