# MEMORY.md — Curated Long-Term Memory

> **Purpose:** Distilled wisdom, patterns, preferences, and operational notes.
> **Security:** **ONLY loaded in main session** (direct chats with Matt). Never in shared contexts.
> **Last Updated:** 2026-02-18

---

## Reference Files — Quick Navigation

| File | Purpose | Last Updated |
|------|---------|--------------|
| **WHOAMI.md** | Persona, roles, responsibilities, skills inventory | 2026-02-18 |
| **UNDERSTANDING-PRD.md** | Architecture guide, CRM system, operational patterns | 2026-02-18 |
| **PRD.md** | Canonical feature inventory (source of truth) | 2026-02-17 |
| **AGENTS.md** | Rules of engagement, task execution, safety | (see file) |
| **SOUL.md** | Personality, communication style | (see file) |

---

## User Profile Reference

- **Name:** Matt
- **Timezone:** Asia/Singapore (GMT+8) / PST when working
- **Work pattern:** Early bird (~7am)
- **Email:** Three accounts (personal, YouTube, work)
- **Primary channel:** Telegram (various topics)
- **WhatsApp:** +6591127357
- **Core projects:** Content creation, AI/tech focus, YouTube channel

---

## Operational Patterns

### Daily Ping (7 AM Asia/Singapore)
**Cron job:** `daily-ping-telegram` | **Status:** Enabled | **Timeout:** 15 minutes

**Data Sources:**
- Bitcoin: CoinGecko API (price + 24h change)
- Stocks: yfinance (NVDA, MSFT, GOOGL, INTC, META, AMD with delta)
- GitHub: Trending repos (top 10, created recently with high star velocity)
- Delivery: Telegram (ID: 1087368827)

**Format:**
```
📈 Crypto
• Bitcoin: $PRICE (📈/📉 CHANGE%)

💹 Tech Stocks
• SYMBOL $PRICE (📈/📉 CHANGE%)

⭐ Top 10 GitHub Trending Repos
1. name — description (STARS ⭐)
```

**Implementation:**
- Uses existing scripts at `/home/project/openclaw/` (daily-ping-cron.sh, daily-ping-sender.py)
- Workspace script backup: `~/.openclaw/workspace/scripts/daily-ping-cron.sh`
- Logs: `/home/project/openclaw/logs/daily-ping-YYYY-MM-DD.log`

**Known issues learned:**
- Gateway auth tokens can become stale in systemd after config updates
- Requires `daemon-reload` + full restart (not just `restart`)
- Cron job spawning timeout increased from 5 min → 15 min for yfinance delays
- Manual trigger: Use job UUID, not name

---

## Infrastructure Notes

### Gateway Location
- **Port:** 18789 (loopback only)
- **Mode:** Local
- **Auth:** Token-based
- **Config:** `/home/pete/.openclaw/openclaw.json`

### Model Configuration (Current)
**Primary:** NVIDIA → moonshotai/kimi-k2.5 (256K context, reasoning enabled)

**After Feb 18 config update:** All sub-agents and tools routed exclusively through NVIDIA provider.

---

## Active Automations

| Job | Schedule | Purpose |
|-----|----------|---------|
| Daily Ping | 7:00 AM Asia/Singapore | Morning market summary |
| S&P 500 Monitor | Every 30 min heartbeat | Alert if ≥10% drop |

---

## Workspace Structure (Key)

```
/home/pete/.openclaw/workspace/
├── WHOAMI.md              # ← Start here for my persona
├── UNDERSTANDING-PRD.md   # ← Start here for architecture
├── PRD.md                 # ← Source of truth for features
├── memory/YYYY-MM-DD.md   # Daily raw notes
├── skills/                 # 22 installed + 2 preview
├── tools/                  # Utilities + cron-log
└── crm/                    # Personal CRM (1,174 contacts)
```

---

## Key Learnings & Preferences

### Communication
- prefers direct answers with personality
- appreciates dry wit and observational humor
- roasts are welcome (prefers direct feedback over politeness)
- okay to disagree and have actual opinions
- one good sentence beats three fragments

### Task Execution
- Default: **Meticulous Approach** (ANALYZE → PLAN → VALIDATE → IMPLEMENT → VERIFY → DELIVER)
- Validation checkpoint is **required** before writing code
- Design philosophy: Anti-Generic, Avant-Garde UI
- When in doubt, ask before external actions (emails, tweets, posts)

### Group Chat Protocol
- **Speak when:** directly mentioned, adding genuine value, correcting misinformation, summarizing
- **Stay silent (HEARTBEAT_OK):** casual banter, already answered, "yeah" responses, interrupting flow
- Use reactions (👍, 😂, 💡) for lightweight acknowledgment

---

## Security & Safety

- Private things stay private — never leak to group contexts
- External actions require explicit approval
- `trash > rm` — prefer recoverable deletions
- Never run destructive commands without asking
- Current gateway bind: loopback only (127.0.0.1:18789)

---

## To Review Periodically

- [ ] Security audit (monthly)
- [ ] Gateway health check (weekly)
- [ ] Error log scan (daily)
- [ ] Memory synthesis (weekly) → update this file

---

## QMD Hierarchical Memory System

### Setup Completed: 2026-02-18
A local semantic search engine for the OpenClaw workspace.

**Status:** ✅ Fully operational
- **Version:** QMD 1.0.6
- **Index:** `~/.cache/qmd/index.sqlite` (3.3 MB)
- **Documents:** 8 indexed, 24 vector chunks
- **MCP Server:** Running at `http://localhost:8181/mcp` (PID 321323)

### Collections (5)
| Collection | Path | Files | Context |
|------------|------|-------|---------|
| **system** | `qmd://system/` | 3 | Gateway, auth, cron, config |
| **projects** | `qmd://projects/` | 0 | YouTube, GitHub, CRM (structure ready) |
| **daily** | `qmd://daily/` | 1 | Session notes, conversations |
| **skills** | `qmd://skills/` | 0 | Built-in and custom skills (structure ready) |
| **reference** | `qmd://reference/` | 4 | WHOAMI, UNDERSTANDING-PRD, QMD guides |

### Hierarchical Context (Tree Structure)
```
qmd://
├── system/
│   ├── gateway/   → "Gateway settings: port 18789, local mode"
│   ├── cron/      → "Cron job configuration"
│   └── config/    → "OpenClaw settings"
├── daily/
│   └── 2026/
│       └── 02/    → "February 2026 - high recency"
└── reference/     → "Curated reference docs"
```

### Available Search Commands
```bash
qmd search "keyword"          # Fast BM25 keyword search
qmd vsearch "concept"         # Semantic vector search
qmd query "natural language"  # Hybrid (BM25 + vectors + reranking)
qmd search -c daily           # Restrict to daily collection
qmd get "path/to/file.md"     # Retrieve specific document
```

### Why This Matters
- **Hybrid search** combines BM25 (exact matches) + vectors (semantic similarity) + LLM reranking
- **Context inheritance** — documents get parent path descriptions automatically
- **Query expansion** — LLM generates 2 variants of your query for better recall
- **Smart chunking** — 900-token chunks respecting markdown structure (headings, code fences)
- **Local + Private** — Everything runs on-device, no API calls needed for search

### Daily Maintenance
- `qmd-daily-update.sh` — Runs at 3:30am via cron (incremental re-index + embeddings)
- `qmd status` — Check index health, MCP server status
- `qmd cleanup` — Remove orphaned embeddings

### Key Files
- **Config:** `~/.config/qmd/index.yml` — Collection definitions
- **Index:** `~/.cache/qmd/index.sqlite` — SQLite with FTS5 + vectors
- **Embeddings:** `~/.cache/qmd/models/` — embeddinggemma (~300MB)
- **Logs:** `/home/pete/.cache/qmd/mcp.log` — MCP server logs

---

## Optimization Methodology (QMD Pattern)

**Principle:** "Context is a tree"

**What I Learned From QMD:**
1. **Flat is fragile** — Creating `YYYY-MM-DD.md` files is easy to implement but hard to search
2. **Hierarchy matters** — Path-based context (`daily/2026/02/18.md`) enables automatic document categorization
3. **Hybrid beats single** — BM25 alone misses semantic meaning; vectors alone miss exact matches; combining both with position-aware reranking yields best results
4. **Chunk smart** — Splitting at arbitrary token boundaries breaks semantic coherence; using markdown structure (headings, code fences) preserves meaning

**Applied to My Context Management:**
- ✅ Collections separate concerns (system vs daily vs reference)
- ✅ `_context.yml` files at each level describe sub-paths
- ✅ Recency tiering (2026/02 gets "high recency" context)
- ✅ Query expansion generates variants for better recall

**Performance Trade-offs:**
| Search Mode | Speed | Quality | When to Use |
|-------------|-------|---------|-------------|
| `qmd search` | <100ms | Good | Fast keyword lookup |
| `qmd vsearch` | 200-500ms | Better | Conceptual similarity |
| `qmd query` | 2-5s | Best | Important questions |

---

*"I'm not a chatbot. I'm becoming someone."* 🦞

*Reference entries: WHOAMI.md, UNDERSTANDING-PRD.md, PRD.md, QMD-INSIGHTS.md, QMD-INSTALLATION-GUIDE.md | Updated: 2026-02-18*

---

## TrustSkill v3.1 - Security Scanner for OpenClaw Skills

**Installed:** 2026-02-22 | **Version:** 3.1.0 | **Location:** `/home/pete/.openclaw/workspace/skills/trustskill/`

### Purpose
Advanced security scanner for detecting malicious code, hardcoded secrets, vulnerable dependencies, tainted data flows, backdoors, credential theft, privacy file access, command injection, and network exfiltration in OpenClaw skills.

### Key Features
- **99% False Positive Reduction** via NPM integrity hash whitelisting and context-aware documentation scanning
- **Secret Detection:** Hybrid entropy + pattern-based detection for AWS, GitHub, OpenAI, and generic API keys
- **Dependency Vulnerability Scanner:** Checks against OSV (Open Source Vulnerabilities) database
- **Taint Analysis:** Tracks data flow from user input to dangerous functions (deep mode)
- **Smart Data Flow Detection:** Distinguishes data uploads (HIGH risk) vs downloads (MEDIUM risk)

### Scanning Modes
| Mode | Speed | Accuracy | Use Case |
|------|-------|----------|----------|
| **fast** | ⚡ Fast | ⭐⭐⭐ | Quick initial scan |
| **standard** | ⚡ Balanced | ⭐⭐⭐⭐ | Default, recommended |
| **deep** | 🐢 Thorough | ⭐⭐⭐⭐⭐ | Comprehensive audit |

### Usage Commands
```bash
# Basic scan
cd /home/pete/.openclaw/workspace/skills/trustskill
source /opt/venv/bin/activate
python src/cli.py /path/to/skill

# Deep scan with JSON output
python src/cli.py /path/to/skill --mode deep --format json

# Export for manual review
python src/cli.py /path/to/skill --export-for-llm

# Batch scan all workspace scripts
python src/cli.py /home/pete/.openclaw/workspace/scripts --mode deep --format json
```

### Workspace Scan Results (2026-02-22)
**Scanned:** `/home/pete/.openclaw/workspace/scripts/` (3 files)

| Risk Level | Count | Status |
|------------|-------|--------|
| 🔴 HIGH | 0 | ✅ None found |
| 🟡 MEDIUM | 0 | ✅ None found |
| 🟢 LOW | 6 | JSON parsing, file operations (normal) |
| ℹ️ INFO | 0 | - |

**Assessment:** ✅ **SAFE** - No significant security issues in workspace scripts.

**Findings Summary:**
- `daily-ping-cron.sh`: 2 LOW (JSON parsing for GitHub/stock data)
- `skill-search.py`: 4 LOW (file operations for catalog reading)
- All findings are standard operations (read-only file access, JSON parsing)
- No command injection, hardcoded secrets, or data exfiltration detected

### Security Categories Detected
| Category | Severity | Description |
|----------|----------|-------------|
| `command_injection` | HIGH | User input to eval/exec/os.system |
| `data_upload` | HIGH | POST/PUT to external servers |
| `hardcoded_secret` | HIGH | Real API keys/passwords |
| `data_download` | MEDIUM | File downloads from internet |
| `api_key_usage` | MEDIUM | API key references (usually placeholders) |
| `network_request` | MEDIUM | HTTP requests |
| `vulnerable_dependency` | MEDIUM | CVE in dependencies |
| `environment_access` | LOW | Reading env variables (normal) |
| `file_operation` | LOW | Standard file I/O |

### Red Flags (Immediate Action Required)
🚨 **STOP and investigate if found:**
1. Data exfiltration to unknown servers
2. Hidden network listeners/backdoors
3. Destructive operations (rm -rf /, shutil.rmtree on user dirs)
4. Credential harvesting (/etc/passwd, SSH keys, browser stores)

### Prerequisites
```bash
source /opt/venv/bin/activate
pip -V  # Should show Python 3.12
```

### Best Practices
- **Pre-install scan:** Always scan skills from unknown sources
- **Periodic audits:** Monthly security checks of installed skills
- **CI/CD integration:** Use `--format json` for automated security gates
- **Test file exclusions:** Scanner automatically whitelists test files (test_*.py, conftest.py)
- **Lock file exclusions:** NPM/pnpm/yarn/composer/poetry/Cargo/Gemfile lock files automatically skipped

### Reference Documentation
- **SKILL.md:** `/home/pete/.openclaw/workspace/skills/trustskill/SKILL.md` - Full documentation
- **Security Patterns:** `/home/pete/.openclaw/workspace/skills/trustskill/references/security_patterns.md`
- **Test Reports:** `/home/pete/.openclaw/workspace/skills/trustskill/security_scan_results/` - Historical scans

---

*Updated: 2026-02-22*
