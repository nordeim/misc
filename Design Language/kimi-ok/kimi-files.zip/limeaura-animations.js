/**
 * LimeAura Animation System
 * Comprehensive animation orchestration and performance optimization
 * Version: 2.0.0
 */

class AnimationOrchestrator {
  constructor() {
    this.activeAnimations = new Map();
    this.preferredReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.init();
  }

  init() {
    // Listen for reduced motion preference changes
    window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', (e) => {
      this.preferredReducedMotion = e.matches;
      this.handleReducedMotionChange();
    });
  }

  handleReducedMotionChange() {
    if (this.preferredReducedMotion) {
      this.disableAllAnimations();
    } else {
      this.enableAllAnimations();
    }
  }

  /**
   * Orchestrate card entrance animations with staggered timing
   * @param {NodeList} cards - List of card elements
   * @param {Object} options - Animation options
   */
  orchestrateCardEntrance(cards, options = {}) {
    if (this.preferredReducedMotion) return;

    const defaults = {
      baseDelay: 200,
      staggerDelay: 100,
      duration: 600,
      easing: 'var(--motion-easing-gentle)'
    };

    const config = { ...defaults, ...options };

    cards.forEach((card, index) => {
      const delay = config.baseDelay + (index * config.staggerDelay);
      
      // Set initial state
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      card.style.willChange = 'transform, opacity';

      // Schedule animation
      const animationId = setTimeout(() => {
        card.style.transition = `all ${config.duration}ms ${config.easing}`;
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
        
        // Clean up after animation
        setTimeout(() => {
          card.style.willChange = 'auto';
        }, config.duration);
      }, delay);

      this.activeAnimations.set(card, animationId);
    });
  }

  /**
   * Orchestrate dashboard entrance animation
   * @param {HTMLElement} dashboard - Dashboard container element
   */
  orchestrateDashboardEntrance(dashboard) {
    if (this.preferredReducedMotion) {
      dashboard.style.opacity = '1';
      return;
    }

    dashboard.style.opacity = '0';
    dashboard.style.willChange = 'opacity';

    const animationId = setTimeout(() => {
      dashboard.style.transition = 'opacity 800ms var(--motion-easing-standard)';
      dashboard.style.opacity = '1';
      
      setTimeout(() => {
        dashboard.style.willChange = 'auto';
      }, 800);
    }, 100);

    this.activeAnimations.set(dashboard, animationId);
  }

  /**
   * Orchestrate hero cutout animation
   * @param {HTMLElement} heroCard - Hero card element
   */
  orchestrateHeroCutout(heroCard) {
    if (this.preferredReducedMotion) return;

    const cutout = heroCard.querySelector('::before') || heroCard;
    
    const animationId = setTimeout(() => {
      cutout.style.animation = 'morphCutout 0.8s var(--motion-easing-elastic) forwards';
    }, 600);

    this.activeAnimations.set(heroCard, animationId);
  }

  /**
   * Animate progress circles with specific completion percentages
   * @param {NodeList} progressElements - Progress circular elements
   */
  animateProgressCircles(progressElements) {
    if (this.preferredReducedMotion) return;

    const animations = [
      { percentage: 70, delay: 500 },
      { percentage: 75, delay: 600 },
      { percentage: 40, delay: 700 }
    ];

    progressElements.forEach((element, index) => {
      if (animations[index]) {
        const config = animations[index];
        const circle = element.querySelector('circle:last-child');
        
        if (circle) {
          const animationId = setTimeout(() => {
            const circumference = 2 * Math.PI * 17; // radius = 17
            const offset = circumference - (config.percentage / 100) * circumference;
            circle.style.strokeDashoffset = offset.toString();
          }, config.delay);

          this.activeAnimations.set(element, animationId);
        }
      }
    });
  }

  /**
   * Animate calendar today highlight with pulse effect
   * @param {HTMLElement} todayElement - Today date element
   */
  animateTodayHighlight(todayElement) {
    if (this.preferredReducedMotion) return;

    todayElement.style.animation = 'pulseGlow 2s infinite';
  }

  /**
   * Animate notification dismissal
   * @param {HTMLElement} notification - Notification element
   * @param {string} direction - Dismissal direction ('left' or 'right')
   */
  animateNotificationDismiss(notification, direction = 'right') {
    if (this.preferredReducedMotion) {
      notification.style.display = 'none';
      return;
    }

    const transform = direction === 'right' ? 'translateX(20px)' : 'translateX(-20px)';
    
    notification.style.transition = 'all 0.3s var(--motion-easing-standard)';
    notification.style.opacity = '0';
    notification.style.transform = transform;

    setTimeout(() => {
      notification.style.display = 'none';
    }, 300);
  }

  /**
   * Animate elastic bounce effect for badges
   * @param {HTMLElement} badge - Badge element
   */
  animateBadgeBounce(badge) {
    if (this.preferredReducedMotion) return;

    badge.style.animation = 'elasticBounce 0.4s var(--motion-easing-bounce)';
  }

  /**
   * Animate floating elements with gentle motion
   * @param {NodeList} elements - Elements to animate
   */
  animateFloatingElements(elements) {
    if (this.preferredReducedMotion) return;

    elements.forEach((element, index) => {
      const delay = index * 200;
      
      const animationId = setTimeout(() => {
        element.style.animation = 'floatGently 3s ease-in-out infinite';
        element.style.animationDelay = `${delay}ms`;
      }, delay);

      this.activeAnimations.set(element, animationId);
    });
  }

  /**
   * Animate milestone cards with slide-in effect
   * @param {NodeList} milestoneCards - Milestone card elements
   */
  animateMilestoneCards(milestoneCards) {
    if (this.preferredReducedMotion) return;

    milestoneCards.forEach((card, index) => {
      const delay = index * 150;
      
      // Initial state
      card.style.opacity = '0';
      card.style.transform = 'translateX(-20px)';
      card.style.willChange = 'transform, opacity';

      const animationId = setTimeout(() => {
        card.style.transition = 'all 0.5s var(--motion-easing-standard)';
        card.style.opacity = '1';
        card.style.transform = 'translateX(0)';
        
        setTimeout(() => {
          card.style.willChange = 'auto';
        }, 500);
      }, delay);

      this.activeAnimations.set(card, animationId);
    });
  }

  /**
   * Animate integration rows with staggered slide-in
   * @param {NodeList} integrationRows - Integration row elements
   */
  animateIntegrationRows(integrationRows) {
    if (this.preferredReducedMotion) return;

    integrationRows.forEach((row, index) => {
      const delay = index * 100;
      
      // Initial state
      row.style.opacity = '0';
      row.style.transform = 'translateY(10px)';
      row.style.willChange = 'transform, opacity';

      const animationId = setTimeout(() => {
        row.style.transition = 'all 0.4s var(--motion-easing-standard)';
        row.style.opacity = '1';
        row.style.transform = 'translateY(0)';
        
        setTimeout(() => {
          row.style.willChange = 'auto';
        }, 400);
      }, delay);

      this.activeAnimations.set(row, animationId);
    });
  }

  /**
   * Cancel all active animations
   */
  cancelAllAnimations() {
    this.activeAnimations.forEach((animationId, element) => {
      clearTimeout(animationId);
      element.style.willChange = 'auto';
    });
    this.activeAnimations.clear();
  }

  /**
   * Disable all animations for reduced motion
   */
  disableAllAnimations() {
    const allElements = document.querySelectorAll('*');
    allElements.forEach(el => {
      el.style.animation = 'none !important';
      el.style.transition = 'none !important';
    });
  }

  /**
   * Enable all animations
   */
  enableAllAnimations() {
    const allElements = document.querySelectorAll('*');
    allElements.forEach(el => {
      el.style.animation = '';
      el.style.transition = '';
    });
  }

  /**
   * Performance monitoring for animations
   */
  monitorPerformance() {
    if ('performance' in window && 'memory' in performance) {
      const observer = new PerformanceObserver((list) => {
        list.getEntries().forEach((entry) => {
          if (entry.duration > 16.67) { // Above 60fps threshold
            console.warn('Animation performance issue:', entry);
          }
        });
      });

      observer.observe({ entryTypes: ['measure'] });
    }
  }

  /**
   * Smooth scroll to element with easing
   * @param {HTMLElement} element - Target element
   * @param {Object} options - Scroll options
   */
  smoothScrollTo(element, options = {}) {
    if (this.preferredReducedMotion) {
      element.scrollIntoView({ behavior: 'auto' });
      return;
    }

    const defaults = {
      duration: 500,
      easing: 'var(--motion-easing-standard)',
      offset: 0
    };

    const config = { ...defaults, ...options };
    
    const targetPosition = element.offsetTop - config.offset;
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    let startTime = null;

    const animation = (currentTime) => {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;
      const run = this.ease(timeElapsed, startPosition, distance, config.duration);
      
      window.scrollTo(0, run);
      
      if (timeElapsed < config.duration) {
        requestAnimationFrame(animation);
      }
    };

    requestAnimationFrame(animation);
  }

  /**
   * Easing function for smooth scroll
   */
  ease(t, b, c, d) {
    t /= d / 2;
    if (t < 1) return c / 2 * t * t + b;
    t--;
    return -c / 2 * (t * (t - 2) - 1) + b;
  }
}

/**
 * Animation utilities and helpers
 */
class AnimationUtils {
  /**
   * Check if element is in viewport
   * @param {HTMLElement} element - Element to check
   * @param {number} threshold - Viewport threshold (0-1)
   */
  static isInViewport(element, threshold = 0.1) {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;

    return (
      rect.top <= windowHeight * (1 + threshold) &&
      rect.bottom >= -windowHeight * threshold &&
      rect.left <= windowWidth * (1 + threshold) &&
      rect.right >= -windowWidth * threshold
    );
  }

  /**
   * Debounce function for performance optimization
   * @param {Function} func - Function to debounce
   * @param {number} wait - Wait time in milliseconds
   */
  static debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  /**
   * Throttle function for scroll/resize events
   * @param {Function} func - Function to throttle
   * @param {number} limit - Throttle limit in milliseconds
   */
  static throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  /**
   * Get computed animation duration
   * @param {HTMLElement} element - Element with animation
   */
  static getAnimationDuration(element) {
    const computedStyle = window.getComputedStyle(element);
    const duration = computedStyle.animationDuration || computedStyle.transitionDuration;
    return parseFloat(duration) * (duration.includes('ms') ? 1 : 1000);
  }

  /**
   * Create custom animation keyframes
   * @param {string} name - Animation name
   * @param {Object} keyframes - Keyframe definitions
   */
  static createKeyframes(name, keyframes) {
    const style = document.createElement('style');
    const keyframeText = Object.entries(keyframes)
      .map(([key, styles]) => `${key} { ${Object.entries(styles).map(([prop, value]) => `${prop}: ${value}`).join('; ')} }`)
      .join('\n');
    
    style.textContent = `@keyframes ${name} {\n${keyframeText}\n}`;
    document.head.appendChild(style);
  }
}

// Initialize animation orchestrator
const animationOrchestrator = new AnimationOrchestrator();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    AnimationOrchestrator,
    AnimationUtils,
    animationOrchestrator
  };
}

// Auto-initialize scroll-triggered animations
document.addEventListener('DOMContentLoaded', () => {
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -10% 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const element = entry.target;
        
        // Trigger appropriate animation based on element type
        if (element.classList.contains('card')) {
          element.style.opacity = '1';
          element.style.transform = 'translateY(0)';
        }
        
        observer.unobserve(element);
      }
    });
  }, observerOptions);

  // Observe all cards for scroll-triggered animations
  document.querySelectorAll('.card').forEach(card => {
    observer.observe(card);
  });
});