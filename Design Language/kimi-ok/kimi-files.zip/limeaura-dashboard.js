/**
 * LimeAura Dashboard Application
 * Main dashboard logic and interactive features
 * Version: 2.0.0
 */

class LimeAuraDashboard {
  constructor() {
    this.state = {
      currentDate: new Date(),
      selectedDate: null,
      notifications: [],
      integrations: new Map(),
      milestones: [],
      activities: []
    };
    
    this.init();
  }

  init() {
    this.initializeState();
    this.setupEventListeners();
    this.initializeAnimations();
    this.startPerformanceMonitoring();
  }

  /**
   * Initialize application state with mock data
   */
  initializeState() {
    // Initialize integrations state
    this.state.integrations.set('slack', { enabled: true, name: 'Slack' });
    this.state.integrations.set('gmail', { enabled: true, name: 'Gmail' });
    this.state.integrations.set('drive', { enabled: false, name: 'Google Drive' });
    this.state.integrations.set('calendar', { enabled: true, name: 'Google Calendar' });
    this.state.integrations.set('zoom', { enabled: false, name: 'Zoom' });

    // Initialize milestones
    this.state.milestones = [
      {
        id: 1,
        title: 'Design System Complete',
        description: 'Final design tokens and component library',
        progress: 75,
        dueDate: '2025-11-20',
        assignees: ['Alex Kim', 'Maya Patel', 'Jordan Lee']
      },
      {
        id: 2,
        title: 'API Integration',
        description: 'Backend services and data synchronization',
        progress: 40,
        dueDate: '2025-11-25',
        assignees: ['Sam Wilson', 'Casey Wong']
      },
      {
        id: 3,
        title: 'User Testing',
        description: 'Usability testing and feedback collection',
        progress: 15,
        dueDate: '2025-12-05',
        assignees: ['Riley Smith']
      }
    ];

    // Initialize recent activities
    this.state.activities = [
      {
        id: 1,
        user: 'Alex Kim',
        action: 'completed task',
        target: 'Update color palette',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        avatar: 'AK'
      },
      {
        id: 2,
        user: 'Maya Patel',
        action: 'added comment to',
        target: 'API Documentation',
        timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        avatar: 'MP'
      },
      {
        id: 3,
        user: 'Jordan Lee',
        action: 'created new milestone',
        target: 'Security Review',
        timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
        avatar: 'JL'
      },
      {
        id: 4,
        user: 'Sam Wilson',
        action: 'uploaded files to',
        target: 'Design Assets',
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
        avatar: 'SW'
      }
    ];
  }

  /**
   * Setup event listeners for interactive features
   */
  setupEventListeners() {
    // Calendar navigation
    this.setupCalendarNavigation();
    
    // Integration toggles
    this.setupIntegrationToggles();
    
    // Quick actions
    this.setupQuickActions();
    
    // Tag interactions
    this.setupTagInteractions();
    
    // Notification badge
    this.setupNotificationBadge();
    
    // Milestone interactions
    this.setupMilestoneInteractions();
  }

  /**
   * Setup calendar navigation
   */
  setupCalendarNavigation() {
    const prevButton = document.querySelector('.calendar-nav button:first-child');
    const nextButton = document.querySelector('.calendar-nav button:last-child');
    const monthDisplay = document.querySelector('.current-month');

    if (prevButton && nextButton && monthDisplay) {
      prevButton.addEventListener('click', () => {
        this.state.currentDate.setMonth(this.state.currentDate.getMonth() - 1);
        this.updateCalendarDisplay(monthDisplay);
        this.animateCalendarChange();
      });

      nextButton.addEventListener('click', () => {
        this.state.currentDate.setMonth(this.state.currentDate.getMonth() + 1);
        this.updateCalendarDisplay(monthDisplay);
        this.animateCalendarChange();
      });
    }

    // Calendar day clicks
    document.querySelectorAll('.day:not(.muted)').forEach(day => {
      day.addEventListener('click', (e) => {
        this.handleDateSelection(e.target);
      });
    });
  }

  /**
   * Update calendar month display
   */
  updateCalendarDisplay(monthDisplay) {
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    
    monthDisplay.textContent = `${monthNames[this.state.currentDate.getMonth()]} ${this.state.currentDate.getFullYear()}`;
  }

  /**
   * Animate calendar change
   */
  animateCalendarChange() {
    const calendarGrid = document.querySelector('.calendar-grid');
    if (calendarGrid && animationOrchestrator) {
      calendarGrid.style.opacity = '0.5';
      calendarGrid.style.transform = 'scale(0.98)';
      
      setTimeout(() => {
        calendarGrid.style.opacity = '1';
        calendarGrid.style.transform = 'scale(1)';
      }, 150);
    }
  }

  /**
   * Handle date selection in calendar
   */
  handleDateSelection(dayElement) {
    // Remove previous selection
    document.querySelectorAll('.day.selected').forEach(el => {
      el.classList.remove('selected');
    });

    // Add selection to clicked day
    dayElement.classList.add('selected');
    
    // Update state
    const dayNumber = parseInt(dayElement.textContent);
    this.state.selectedDate = new Date(
      this.state.currentDate.getFullYear(),
      this.state.currentDate.getMonth(),
      dayNumber
    );

    // Show notification
    this.showNotification(`Selected ${this.formatDate(this.state.selectedDate)}`, 'info');
  }

  /**
   * Setup integration toggle switches
   */
  setupIntegrationToggles() {
    document.querySelectorAll('.integration-toggle .toggle-switch').forEach(toggle => {
      const integrationRow = toggle.closest('.integration-row');
      const integrationName = integrationRow.querySelector('h4').textContent.toLowerCase();
      
      // Find the corresponding integration
      let integrationKey = null;
      for (const [key, integration] of this.state.integrations) {
        if (integration.name.toLowerCase() === integrationName) {
          integrationKey = key;
          break;
        }
      }

      if (integrationKey) {
        const checkbox = toggle.querySelector('input[type="checkbox"]');
        if (checkbox) {
          checkbox.addEventListener('change', (e) => {
            this.handleIntegrationToggle(integrationKey, e.target.checked, integrationRow);
          });
        }
      }
    });
  }

  /**
   * Handle integration toggle changes
   */
  handleIntegrationToggle(integrationKey, enabled, integrationRow) {
    this.state.integrations.set(integrationKey, {
      ...this.state.integrations.get(integrationKey),
      enabled
    });

    const integrationName = this.state.integrations.get(integrationKey).name;
    const status = enabled ? 'enabled' : 'disabled';
    
    this.showNotification(`${integrationName} integration ${status}`, enabled ? 'success' : 'warning');
    
    // Animate the row
    if (animationOrchestrator) {
      integrationRow.style.transform = 'scale(0.98)';
      setTimeout(() => {
        integrationRow.style.transform = 'scale(1)';
      }, 200);
    }

    // Update active count
    this.updateIntegrationCount();
  }

  /**
   * Update integration count badge
   */
  updateIntegrationCount() {
    const activeCount = Array.from(this.state.integrations.values())
      .filter(integration => integration.enabled).length;
    
    const badge = document.querySelector('.badge-status');
    if (badge) {
      badge.textContent = `${activeCount} Active`;
    }
  }

  /**
   * Setup quick action buttons
   */
  setupQuickActions() {
    document.querySelectorAll('.quick-actions button').forEach(button => {
      button.addEventListener('click', (e) => {
        const buttonText = e.target.textContent.trim();
        this.handleQuickAction(buttonText);
      });
    });
  }

  /**
   * Handle quick action clicks
   */
  handleQuickAction(action) {
    switch (action) {
      case 'Create Task':
        this.showTaskCreationModal();
        break;
      case 'View Reports':
        this.showNotification('Opening reports dashboard...', 'info');
        break;
      case 'Invite Team':
        this.showNotification('Opening team invitation...', 'info');
        break;
      case 'Settings':
        this.showNotification('Opening settings panel...', 'info');
        break;
      default:
        this.showNotification(`Action: ${action}`, 'info');
    }
  }

  /**
   * Show task creation modal (simplified implementation)
   */
  showTaskCreationModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <h3>Create New Task</h3>
          <button class="btn-icon modal-close" aria-label="Close">×</button>
        </div>
        <div class="modal-body">
          <form class="task-form">
            <div class="form-group">
              <label for="taskTitle">Task Title</label>
              <input type="text" id="taskTitle" required>
            </div>
            <div class="form-group">
              <label for="taskDescription">Description</label>
              <textarea id="taskDescription" rows="3"></textarea>
            </div>
            <div class="form-group">
              <label for="taskAssignee">Assign to</label>
              <select id="taskAssignee">
                <option value="">Select team member</option>
                <option value="Alex Kim">Alex Kim</option>
                <option value="Maya Patel">Maya Patel</option>
                <option value="Jordan Lee">Jordan Lee</option>
                <option value="Sam Wilson">Sam Wilson</option>
                <option value="Casey Wong">Casey Wong</option>
              </select>
            </div>
            <div class="form-actions">
              <button type="button" class="btn-secondary modal-cancel">Cancel</button>
              <button type="submit" class="btn-primary">Create Task</button>
            </div>
          </form>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Setup modal event listeners
    const closeBtn = modal.querySelector('.modal-close');
    const cancelBtn = modal.querySelector('.modal-cancel');
    const form = modal.querySelector('.task-form');

    const closeModal = () => {
      modal.remove();
    };

    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      const taskData = {
        title: formData.get('taskTitle') || document.getElementById('taskTitle').value,
        description: formData.get('taskDescription') || document.getElementById('taskDescription').value,
        assignee: formData.get('taskAssignee') || document.getElementById('taskAssignee').value
      };
      
      this.createTask(taskData);
      closeModal();
    });

    // Focus management
    const firstInput = modal.querySelector('input, textarea, select');
    if (firstInput) firstInput.focus();
  }

  /**
   * Create a new task
   */
  createTask(taskData) {
    // Simulate task creation
    this.showNotification(`Task "${taskData.title}" created successfully!`, 'success');
    
    // Add to activity feed
    this.addActivity({
      user: 'You',
      action: 'created task',
      target: taskData.title,
      timestamp: new Date(),
      avatar: 'YU'
    });
  }

  /**
   * Setup tag interactions
   */
  setupTagInteractions() {
    document.querySelectorAll('.tag').forEach(tag => {
      tag.addEventListener('click', (e) => {
        const tagText = e.target.textContent;
        this.handleTagClick(tagText);
      });
    });
  }

  /**
   * Handle tag clicks
   */
  handleTagClick(tagText) {
    this.showNotification(`Filtering by tag: ${tagText}`, 'info');
    
    // Visual feedback
    const tag = Array.from(document.querySelectorAll('.tag')).find(t => t.textContent === tagText);
    if (tag) {
      tag.style.transform = 'scale(1.1)';
      setTimeout(() => {
        tag.style.transform = '';
      }, 200);
    }
  }

  /**
   * Setup notification badge
   */
  setupNotificationBadge() {
    const notificationBtn = document.querySelector('.header-actions .btn-icon');
    if (notificationBtn) {
      notificationBtn.addEventListener('click', () => {
        this.showNotificationsPanel();
      });
    }
  }

  /**
   * Show notifications panel
   */
  showNotificationsPanel() {
    const notifications = [
      { title: 'Task Completed', message: 'Design system tokens updated', time: '2 hours ago', type: 'success' },
      { title: 'New Comment', message: 'Maya commented on API docs', time: '4 hours ago', type: 'info' },
      { title: 'Milestone Created', message: 'Security review milestone added', time: '6 hours ago', type: 'warning' }
    ];

    const panel = document.createElement('div');
    panel.className = 'notifications-panel';
    panel.innerHTML = `
      <div class="notifications-header">
        <h3>Notifications</h3>
        <button class="btn-icon notifications-close" aria-label="Close">×</button>
      </div>
      <div class="notifications-list">
        ${notifications.map(notification => `
          <div class="notification-item ${notification.type}">
            <div class="notification-icon">${this.getNotificationIcon(notification.type)}</div>
            <div class="notification-content">
              <h4>${notification.title}</h4>
              <p>${notification.message}</p>
              <span class="notification-time">${notification.time}</span>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    document.body.appendChild(panel);

    // Setup panel event listeners
    const closeBtn = panel.querySelector('.notifications-close');
    closeBtn.addEventListener('click', () => {
      panel.remove();
    });

    // Clear notification badge
    const badge = document.querySelector('.header-actions .badge');
    if (badge) {
      badge.style.display = 'none';
    }
  }

  /**
   * Get notification icon based on type
   */
  getNotificationIcon(type) {
    switch (type) {
      case 'success': return '✅';
      case 'warning': return '⚠️';
      case 'error': return '❌';
      default: return 'ℹ️';
    }
  }

  /**
   * Setup milestone interactions
   */
  setupMilestoneInteractions() {
    document.querySelectorAll('.milestone-item').forEach(item => {
      item.addEventListener('click', (e) => {
        const milestoneTitle = item.querySelector('h4').textContent;
        this.handleMilestoneClick(milestoneTitle);
      });
    });
  }

  /**
   * Handle milestone clicks
   */
  handleMilestoneClick(milestoneTitle) {
    const milestone = this.state.milestones.find(m => m.title === milestoneTitle);
    if (milestone) {
      this.showMilestoneDetails(milestone);
    }
  }

  /**
   * Show milestone details
   */
  showMilestoneDetails(milestone) {
    this.showNotification(`Viewing details for: ${milestone.title}`, 'info');
    
    // Could expand this to show a detailed milestone view
    console.log('Milestone details:', milestone);
  }

  /**
   * Initialize animations
   */
  initializeAnimations() {
    // Setup scroll-triggered animations
    this.setupScrollAnimations();
    
    // Setup hover animations
    this.setupHoverAnimations();
  }

  /**
   * Setup scroll-triggered animations
   */
  setupScrollAnimations() {
    if (!animationOrchestrator) return;

    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const element = entry.target;
          
          if (element.classList.contains('milestone-item')) {
            animationOrchestrator.animateMilestoneCards([element]);
          }
          
          observer.unobserve(element);
        }
      });
    }, observerOptions);

    // Observe milestone items
    document.querySelectorAll('.milestone-item').forEach(item => {
      observer.observe(item);
    });
  }

  /**
   * Setup hover animations
   */
  setupHoverAnimations() {
    // Add subtle hover effects to cards
    document.querySelectorAll('.card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        if (animationOrchestrator && !animationOrchestrator.preferredReducedMotion) {
          card.style.transform = 'translateY(-4px) rotateX(1deg)';
        }
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0) rotateX(0deg)';
      });
    });
  }

  /**
   * Start performance monitoring
   */
  startPerformanceMonitoring() {
    if (animationOrchestrator) {
      animationOrchestrator.monitorPerformance();
    }

    // Monitor memory usage
    if ('memory' in performance) {
      setInterval(() => {
        const memoryInfo = performance.memory;
        if (memoryInfo.usedJSHeapSize > memoryInfo.jsHeapSizeLimit * 0.9) {
          console.warn('High memory usage detected');
        }
      }, 30000); // Check every 30 seconds
    }
  }

  /**
   * Show notification
   */
  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
      <div class="notification-content">
        <span class="notification-icon">${this.getNotificationIcon(type)}</span>
        <span class="notification-message">${message}</span>
      </div>
      <button class="notification-close" aria-label="Close">×</button>
    `;

    // Add to notification container or body
    let container = document.querySelector('.notifications-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'notifications-container';
      document.body.appendChild(container);
    }

    container.appendChild(notification);

    // Animate in
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);

    // Setup auto close
    const autoClose = setTimeout(() => {
      this.closeNotification(notification);
    }, 5000);

    // Setup manual close
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
      clearTimeout(autoClose);
      this.closeNotification(notification);
    });
  }

  /**
   * Close notification
   */
  closeNotification(notification) {
    notification.classList.add('hide');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }

  /**
   * Add activity to activity feed
   */
  addActivity(activity) {
    this.state.activities.unshift(activity);
    
    // Update activity display if needed
    this.updateActivityDisplay();
  }

  /**
   * Update activity display
   */
  updateActivityDisplay() {
    // Could implement real-time activity feed updates here
    console.log('Activity feed updated:', this.state.activities);
  }

  /**
   * Format date for display
   */
  formatDate(date) {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  /**
   * Initialize interactive features
   */
  initializeInteractiveFeatures() {
    // This method can be called to initialize all interactive features
    // It's already called in the constructor, but can be used for re-initialization
    console.log('Interactive features initialized');
  }
}

// Notification styles
const notificationStyles = `
.notifications-container {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.notification {
  background: var(--color-surface-primary);
  border-radius: var(--radius-card-md);
  box-shadow: var(--shadow-floating);
  padding: 16px;
  min-width: 300px;
  max-width: 400px;
  transform: translateX(100%);
  transition: all 0.3s var(--motion-easing-standard);
  border-left: 4px solid var(--color-accent-primary);
}

.notification.show {
  transform: translateX(0);
}

.notification.hide {
  transform: translateX(100%);
  opacity: 0;
}

.notification.success {
  border-left-color: var(--color-semantic-success);
}

.notification.warning {
  border-left-color: var(--color-semantic-warning);
}

.notification.error {
  border-left-color: var(--color-semantic-danger);
}

.notification-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.notification-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.notification-message {
  flex: 1;
  font-size: var(--font-size-body);
  color: var(--color-text-primary);
}

.notification-close {
  background: none;
  border: none;
  font-size: 18px;
  color: var(--color-text-muted);
  cursor: pointer;
  padding: 0;
  margin-left: 8px;
  transition: color 0.2s;
}

.notification-close:hover {
  color: var(--color-text-primary);
}

/* Modal styles */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  animation: fadeIn 0.2s ease-out;
}

.modal {
  background: var(--color-surface-primary);
  border-radius: var(--radius-card-lg);
  box-shadow: var(--shadow-floating);
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  animation: slideUp 0.3s var(--motion-easing-standard);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 24px 0 24px;
  margin-bottom: 16px;
}

.modal-header h3 {
  margin: 0;
  font-size: var(--font-size-h3);
  color: var(--color-text-primary);
}

.modal-close {
  background: none;
  border: none;
  font-size: 24px;
  color: var(--color-text-muted);
  cursor: pointer;
  padding: 4px;
  border-radius: var(--radius-control);
  transition: all 0.2s;
}

.modal-close:hover {
  background: var(--color-surface-soft);
  color: var(--color-text-primary);
}

.modal-body {
  padding: 0 24px 24px 24px;
}

.task-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group label {
  font-size: var(--font-size-label);
  font-weight: var(--font-weight-medium);
  color: var(--color-text-primary);
}

.form-group input,
.form-group textarea,
.form-group select {
  padding: 10px 12px;
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-card-md);
  font-size: var(--font-size-body);
  font-family: var(--font-family-primary);
  background: var(--color-surface-primary);
  color: var(--color-text-primary);
  transition: border-color 0.2s;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  outline: none;
  border-color: var(--color-accent-primary);
  box-shadow: 0 0 0 3px var(--color-accent-primary-soft);
}

.form-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  margin-top: 20px;
}

/* Notifications panel styles */
.notifications-panel {
  position: fixed;
  top: 80px;
  right: 20px;
  background: var(--color-surface-primary);
  border-radius: var(--radius-card-lg);
  box-shadow: var(--shadow-floating);
  width: 350px;
  max-height: 500px;
  overflow-y: auto;
  z-index: 1000;
  animation: slideDown 0.3s var(--motion-easing-standard);
}

.notifications-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--color-border-subtle);
}

.notifications-header h3 {
  margin: 0;
  font-size: var(--font-size-h3);
  color: var(--color-text-primary);
}

.notifications-close {
  background: none;
  border: none;
  font-size: 20px;
  color: var(--color-text-muted);
  cursor: pointer;
  padding: 4px;
  border-radius: var(--radius-control);
}

.notifications-close:hover {
  background: var(--color-surface-soft);
  color: var(--color-text-primary);
}

.notifications-list {
  padding: 8px 0;
}

.notification-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px 20px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.notification-item:hover {
  background-color: var(--color-surface-soft);
}

.notification-item.success {
  border-left: 3px solid var(--color-semantic-success);
}

.notification-item.warning {
  border-left: 3px solid var(--color-semantic-warning);
}

.notification-item.error {
  border-left: 3px solid var(--color-semantic-danger);
}

.notification-item.info {
  border-left: 3px solid var(--color-accent-primary);
}

.notification-icon {
  font-size: 16px;
  margin-top: 2px;
  flex-shrink: 0;
}

.notification-content {
  flex: 1;
  min-width: 0;
}

.notification-content h4 {
  margin: 0 0 4px 0;
  font-size: var(--font-size-body);
  color: var(--color-text-primary);
}

.notification-content p {
  margin: 0 0 4px 0;
  font-size: var(--font-size-label);
  color: var(--color-text-secondary);
}

.notification-time {
  font-size: 11px;
  color: var(--color-text-muted);
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideUp {
  from { transform: translateY(20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes slideDown {
  from { transform: translateY(-20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}
`;

// Add notification styles to document
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);