# LimeAura Productivity Suite

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![WCAG 2.1 AA](https://img.shields.io/badge/WCAG-2.1%20AA-green.svg)](https://www.w3.org/WAI/WCAG21/quickref/)
[![Performance: 95+](https://img.shields.io/badge/Performance-95%2B-brightgreen.svg)](PERFORMANCE.md)
[![Accessibility: AA](https://img.shields.io/badge/Accessibility-AA-blue.svg)](ACCESSIBILITY.md)

LimeAura is a design-first, enterprise-ready productivity platform combining delightful UI, real-time collaboration, and production-grade reliability.

## 🌟 Features

### Core Functionality
- **📊 Interactive Dashboard**: Real-time project overview with animated metrics
- **📅 Smart Calendar**: Full-featured calendar with event management
- **🎯 Milestone Tracking**: Visual progress tracking with team assignments
- **👥 Team Activity Feed**: Live activity stream with avatar interactions
- **🔗 Integration Management**: Toggle-enabled third-party service integrations
- **🏷️ Smart Tagging**: Dynamic tag cloud for project organization

### Design Excellence
- **🎨 Design System**: Comprehensive token-based design system
- **✨ Advanced Animations**: Hardware-accelerated animations with reduced motion support
- **📱 Responsive Design**: Mobile-first approach with fluid layouts
- **🎯 WCAG 2.1 AA**: Full accessibility compliance

### Technical Excellence
- **⚡ Performance**: Sub-2s load times with Core Web Vitals optimization
- **🔧 TypeScript Ready**: Full TypeScript support with type definitions
- **📦 Modular Architecture**: Component-based architecture with tree shaking
- **🚀 Offline Support**: Service worker with offline-first capabilities

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ (Node 20 recommended)
- Modern web browser (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)

### Installation

```bash
# Clone the repository
git clone https://github.com/your-org/limeaura.git
cd limeaura

# Install dependencies
npm install

# Build the design tokens
npm run build:tokens

# Start the development server
npm run dev
```

### Basic Usage

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LimeAura Dashboard</title>
    <link rel="stylesheet" href="limeaura-tokens.css">
    <link rel="stylesheet" href="limeaura-dashboard.css">
</head>
<body>
    <div id="app">
        <!-- Dashboard content -->
    </div>
    
    <script src="limeaura-components.js"></script>
    <script src="limeaura-animations.js"></script>
    <script src="limeaura-dashboard.js"></script>
</body>
</html>
```

## 📖 Documentation

### Component Library
The LimeAura component library provides a comprehensive set of accessible, animated components:

- **[Card Component](./docs/components/card.md)**: Flexible card containers with variants
- **[Avatar Component](./docs/components/avatar.md)**: User profile displays
- **[Button Component](./docs/components/button.md)**: Interactive buttons with multiple variants
- **[ProgressCircular](./docs/components/progress-circular.md)**: Circular progress indicators
- **[ToggleSwitch](./docs/components/toggle-switch.md)**: iOS-style toggle switches
- **[Calendar](./docs/components/calendar.md)**: Interactive calendar component

### Design System
- **[Design Tokens](./docs/design-system/tokens.md)**: Complete token specification
- **[Color System](./docs/design-system/colors.md)**: Accessible color palette
- **[Typography](./docs/design-system/typography.md)**: Font specifications and hierarchy
- **[Spacing](./docs/design-system/spacing.md)**: Consistent spacing scale
- **[Animations](./docs/design-system/animations.md)**: Animation principles and timing

### Technical Guides
- **[Performance Guide](./PERFORMANCE.md)**: Performance optimization strategies
- **[Accessibility Guide](./ACCESSIBILITY.md)**: WCAG 2.1 AA implementation
- **[Architecture Overview](./docs/architecture.md)**: System architecture documentation

## 🏗️ Architecture

### Component Architecture
```
limeaura/
├── design-tokens/          # Design system tokens
│   ├── limeaura-design-system.json
│   ├── limeaura-tokens.css
│   └── limeaura-tokens.ts
├── components/             # Reusable UI components
│   ├── card.js
│   ├── avatar.js
│   ├── button.js
│   └── progress-circular.js
├── animations/             # Animation system
│   └── limeaura-animations.js
├── dashboard/              # Dashboard application
│   ├── limeaura-dashboard.js
│   ├── limeaura-dashboard.css
│   └── index.html
└── docs/                   # Documentation
    ├── components/
    ├── design-system/
    └── guides/
```

### Technology Stack
- **Frontend**: Vanilla JavaScript (ES6+) with TypeScript definitions
- **Styling**: CSS Custom Properties with design tokens
- **Animations**: CSS keyframes with JavaScript orchestration
- **Build Tools**: Vite for development and production builds
- **Testing**: Jest for unit tests, Playwright for e2e tests

## 🎯 Design Principles

### Visual Design
- **Vibrant Lime Canvas**: #D6F25F background with floating white cards
- **Purple Accent**: #7B3EFF for interactive elements and emphasis
- **Accessible Contrast**: All text meets WCAG 2.1 AA standards (4.5:1 minimum)
- **Generous Spacing**: Ample whitespace for visual breathing room

### Interaction Design
- **Micro-interactions**: Subtle hover effects and state changes
- **Elastic Animations**: Organic, physics-based motion curves
- **Responsive Feedback**: Immediate visual feedback for user actions
- **Progressive Enhancement**: Core functionality works without JavaScript

### Animation Principles
- **Hardware Acceleration**: Transform and opacity for smooth 60fps animations
- **Reduced Motion**: Respects user preferences for reduced motion
- **Staggered Entrances**: Coordinated component entrance animations
- **Purposeful Motion**: Every animation serves a functional purpose

## 🎨 Customization

### Theme Customization
```javascript
// Override design tokens
:root {
  --color-background-main: #your-color;
  --color-accent-primary: #your-accent;
  --font-family-primary: 'Your Font', sans-serif;
}
```

### Component Configuration
```javascript
// Component initialization with options
const card = new Card(element, {
  variant: 'hero',
  animated: true,
  padding: 'lg',
  delay: '0.2s'
});
```

## 📊 Performance

### Core Web Vitals
- **Largest Contentful Paint (LCP)**: < 2.5s
- **First Input Delay (FID)**: < 100ms
- **Cumulative Layout Shift (CLS)**: < 0.1
- **First Contentful Paint (FCP)**: < 1.8s
- **Time to Interactive (TTI)**: < 3.8s

### Optimization Features
- **Code Splitting**: Route-based and component-based splitting
- **Lazy Loading**: Images and non-critical resources
- **Asset Compression**: WebP images with fallbacks
- **Service Worker**: Offline-first with intelligent caching
- **Tree Shaking**: Dead code elimination

## ♿ Accessibility

### WCAG 2.1 AA Compliance
- **Color Contrast**: All text meets 4.5:1 minimum ratio
- **Keyboard Navigation**: Full keyboard accessibility
- **Screen Readers**: Comprehensive ARIA labeling
- **Focus Management**: Proper focus indicators and management
- **Reduced Motion**: Respects user motion preferences

### Assistive Technology Support
- **Screen Readers**: JAWS, NVDA, VoiceOver, TalkBack
- **Voice Control**: Dragon NaturallySpeaking support
- **Switch Navigation**: Keyboard emulators and switch devices
- **Magnification**: Zoom compatibility up to 200%

## 🧪 Testing

### Test Commands
```bash
# Run all tests
npm test

# Run specific test suites
npm run test:unit
npm run test:e2e
npm run test:accessibility

# Run tests in watch mode
npm run test:watch
```

### Test Coverage
- **Unit Tests**: Component functionality and edge cases
- **Integration Tests**: Component interaction and data flow
- **Accessibility Tests**: axe-core automated accessibility testing
- **Performance Tests**: Lighthouse performance audits
- **Cross-browser Tests**: Browser compatibility verification

## 🚀 Deployment

### Production Build
```bash
# Build for production
npm run build

# Preview production build
npm run preview

# Deploy to static hosting
npm run deploy
```

### Environment Configuration
```bash
# Development
VITE_ENV=development
VITE_API_URL=http://localhost:3001

# Production
VITE_ENV=production
VITE_API_URL=https://api.limeaura.com
```

## 📈 Monitoring

### Performance Monitoring
- **Real User Monitoring**: Core Web Vitals tracking
- **Error Tracking**: JavaScript error monitoring
- **Analytics**: User interaction and engagement metrics
- **Uptime Monitoring**: Service availability tracking

### Health Checks
```javascript
// Performance monitoring integration
const monitor = new PerformanceMonitor();
monitor.observeLCP();
monitor.observeFID();
monitor.observeCLS();
```

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Code Standards
- **ESLint**: JavaScript linting with Airbnb config
- **Prettier**: Code formatting with consistent style
- **TypeScript**: Type definitions and strict type checking
- **Conventional Commits**: Structured commit messages

### Pull Request Process
1. Update documentation for any new features
2. Add tests for new functionality
3. Ensure all tests pass
4. Update the changelog
5. Request review from maintainers

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Design System**: Inspired by modern design systems like Google's Material Design and Apple's Human Interface Guidelines
- **Animation Library**: Built with performance principles from Framer Motion and React Spring
- **Accessibility**: Guided by WebAIM and W3C accessibility best practices
- **Performance**: Optimization techniques from Google Web Fundamentals

## 📞 Support

- **Documentation**: [docs.limeaura.com](https://docs.limeaura.com)
- **Issues**: [GitHub Issues](https://github.com/your-org/limeaura/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/limeaura/discussions)
- **Email**: support@limeaura.com

## 🗺️ Roadmap

### Phase 2: Planning & Reporting (Q1 2026)
- [ ] Calendar and Gantt views with keyboard navigation
- [ ] Time tracking and server-side aggregated dashboard widgets
- [ ] Integration scaffolding: Calendar (Google/Office 365) and Slack notifications

### Phase 3: Wow & Automation (Q2 2026)
- [ ] Customizable drag-and-drop dashboards (persisted per-user)
- [ ] AI-assisted task creation (NL → structured fields) and smart suggestions
- [ ] Advanced animation orchestration and runtime throttling for device tiers

### Phase 4: Enterprise & Hardening (Q3 2026)
- [ ] SAML/SSO, audit logs, advanced RBAC/ABAC policies
- [ ] Production observability (tracing, logs, dashboards)
- [ ] Disaster recovery runbooks and performance hardening

---

**Built with ❤️ by the LimeAura Team**  
**Version**: 2.0.0  
**Last Updated**: November 15, 2025