/* LimeAura Design System - TypeScript Token Definitions */
/* Version: 2.0.0 | Generated from limeaura-design-system.json */

export const tokens = {
  /* ===== COLOR SYSTEM ===== */
  color: {
    background: {
      main: '#D6F25F',
    },
    surface: {
      primary: '#FFFFFF',
      soft: '#F9FAFB',
    },
    text: {
      primary: '#111111',
      secondary: '#555555',
      muted: '#9CA3AF',
      onAccent: '#FFFFFF',
    },
    accent: {
      primary: '#7B3EFF',
      primarySoft: '#EDE7FF',
      secondary: '#00C6AE',
      yellow: '#FFB020',
    },
    semantic: {
      success: '#10B981',
      warning: '#FBBF24',
      danger: '#EF4444',
    },
    border: {
      subtle: '#F0F0F0',
    },
    common: {
      white: '#FFFFFF',
      black: '#000000',
    },
  },

  /* ===== TYPOGRAPHY SYSTEM ===== */
  font: {
    family: {
      primary: "'Nunito', 'SF Pro Rounded', 'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
    },
    size: {
      h1: '28px',
      h2: '22px',
      h3: '18px',
      bodyLg: '16px',
      body: '14px',
      label: '12px',
    },
    weight: {
      regular: 400,
      medium: 500,
      semibold: 600,
    },
    lineHeight: {
      tight: 1.3,
      snug: 1.35,
      normal: 1.5,
    },
    letterSpacing: {
      default: '0em',
    },
  },

  /* ===== SPACING SYSTEM ===== */
  spacing: {
    xxs: '4px',
    xs: '6px',
    sm: '8px',
    md: '12px',
    lg: '16px',
    xl: '20px',
    xxl: '24px',
    xxxl: '32px',
    pagePadding: '40px',
    cardPadding: {
      default: '24px',
      compact: '16px',
    },
  },

  /* ===== RADIUS SYSTEM ===== */
  radius: {
    pill: '999px',
    card: {
      lg: '28px',
      md: '20px',
    },
    control: '999px',
  },

  /* ===== SHADOW SYSTEM ===== */
  shadow: {
    none: 'none',
    card: '0 10px 25px 0 rgba(15, 23, 42, 0.06)',
    floating: '0 18px 40px 0 rgba(15, 23, 42, 0.10)',
    button: {
      primary: '0 8px 18px 0 rgba(123, 62, 255, 0.25)',
    },
    avatar: {
      hover: '0 6px 15px 0 rgba(0, 0, 0, 0.18)',
    },
  },

  /* ===== BORDER SYSTEM ===== */
  border: {
    width: {
      none: '0px',
      hairline: '1px',
      focus: '2px',
    },
    color: {
      subtle: '#F0F0F0',
    },
  },

  /* ===== SIZE SYSTEM ===== */
  size: {
    icon: {
      sm: '16px',
      md: '20px',
      lg: '24px',
    },
    avatar: {
      sm: '32px',
      md: '36px',
      lg: '64px',
    },
    control: {
      toggle: {
        width: '44px',
        height: '24px',
        handle: '18px',
      },
      iconButton: '36px',
      progressCircular: {
        default: '40px',
        small: '32px',
      },
      calendarDay: '36px',
    },
  },

  /* ===== MOTION SYSTEM ===== */
  motion: {
    duration: {
      fast: '120ms',
      normal: '180ms',
      slow: '300ms',
    },
    easing: {
      standard: 'cubic-bezier(0.25, 0.8, 0.25, 1)',
      gentle: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      elastic: 'cubic-bezier(0.68, -0.55, 0.27, 1.55)',
      bounce: 'cubic-bezier(0.68, -0.6, 0.32, 1.6)',
    },
  },

  /* ===== STATE SYSTEM ===== */
  state: {
    focus: {
      outlineWidth: '2px',
      outlineColor: '#EDE7FF',
      outlineOffset: '2px',
    },
    hover: {
      card: {
        shadow: '0 18px 40px 0 rgba(15, 23, 42, 0.10)',
        transform: 'translateY(-4px) rotateX(2deg)',
      },
      button: {
        primary: {
          background: '#6B2FFF',
        },
        secondary: {
          background: '#F9FAFB',
        },
      },
    },
    active: {
      button: {
        transform: 'scale(0.98)',
      },
    },
    disabled: {
      opacity: 0.4,
    },
  },

  /* ===== LAYOUT SYSTEM ===== */
  layout: {
    container: {
      maxWidth: '1440px',
    },
    dashboard: {
      gridColumns: 'repeat(auto-fit, minmax(380px, 1fr))',
      gridGap: '32px',
    },
    breakpoints: {
      tablet: '1200px',
      mobile: '768px',
    },
  },

  /* ===== ANIMATION DELAYS ===== */
  animationDelay: {
    child1: '0.1s',
    child2: '0.2s',
    child3: '0.3s',
    child4: '0.4s',
    child5: '0.5s',
    child6: '0.6s',
    child7: '0.7s',
  },
} as const;

/* ===== TYPE DEFINITIONS ===== */
export type ColorToken = typeof tokens.color;
export type TypographyToken = typeof tokens.font;
export type SpacingToken = typeof tokens.spacing;
export type RadiusToken = typeof tokens.radius;
export type ShadowToken = typeof tokens.shadow;
export type BorderToken = typeof tokens.border;
export type SizeToken = typeof tokens.size;
export type MotionToken = typeof tokens.motion;
export type StateToken = typeof tokens.state;
export type LayoutToken = typeof tokens.layout;

/* ===== UTILITY FUNCTIONS ===== */

/**
 * Get a nested token value using dot notation
 * @param path - Dot-separated path to the token (e.g., 'color.accent.primary')
 * @returns The token value or undefined if not found
 */
export function getTokenValue(path: string): string | number | undefined {
  const keys = path.split('.');
  let current: any = tokens;
  
  for (const key of keys) {
    if (current[key] === undefined) {
      return undefined;
    }
    current = current[key];
  }
  
  return current;
}

/**
 * Apply CSS custom properties to an element
 * @param element - DOM element to apply styles to
 * @param properties - Object of CSS properties and values
 */
export function applyTokens(element: HTMLElement, properties: Record<string, string>): void {
  Object.entries(properties).forEach(([property, value]) => {
    element.style.setProperty(property, value);
  });
}

/**
 * Create a CSS custom property string from a token path
 * @param path - Dot-separated path to the token
 * @returns CSS custom property string (e.g., 'var(--color-accent-primary)')
 */
export function cssVar(path: string): string {
  const cssPath = path.replace(/\./g, '-');
  return `var(--${cssPath})`;
}

/**
 * Validate that all required tokens are present
 * @returns Array of missing token paths
 */
export function validateTokens(): string[] {
  const requiredTokens = [
    'color.background.main',
    'color.surface.primary',
    'color.text.primary',
    'color.accent.primary',
    'font.family.primary',
    'spacing.md',
    'radius.pill',
    'motion.duration.normal',
  ];
  
  const missing: string[] = [];
  
  requiredTokens.forEach(token => {
    if (getTokenValue(token) === undefined) {
      missing.push(token);
    }
  });
  
  return missing;
}

/* ===== EXPORT DEFAULT ===== */
export default tokens;