/**
 * LimeAura API Client
 * Frontend client for interacting with the backend API
 * Version: 3.0.0 - Dynamic Application Integration
 */

class LimeAuraAPI {
    constructor(baseURL = 'http://localhost:3001/api') {
        this.baseURL = baseURL;
        this.token = localStorage.getItem('limeaura_token');
        this.user = null;
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.subscriptions = new Set();
        
        this.setupWebSocket();
    }

    // Authentication methods
    async login(email, password) {
        try {
            const response = await this.request('/auth/login', 'POST', { email, password });
            if (response.token) {
                this.token = response.token;
                localStorage.setItem('limeaura_token', this.token);
                this.user = response.user;
                this.setupWebSocket(); // Reconnect with authentication
            }
            return response;
        } catch (error) {
            throw new Error(`Login failed: ${error.message}`);
        }
    }

    async register(email, username, displayName, password) {
        try {
            const response = await this.request('/auth/register', 'POST', {
                email,
                username,
                displayName,
                password
            });
            if (response.token) {
                this.token = response.token;
                localStorage.setItem('limeaura_token', this.token);
                this.user = response.user;
                this.setupWebSocket();
            }
            return response;
        } catch (error) {
            throw new Error(`Registration failed: ${error.message}`);
        }
    }

    async logout() {
        try {
            await this.request('/auth/logout', 'POST');
        } catch (error) {
            // Ignore logout errors
        } finally {
            this.token = null;
            this.user = null;
            localStorage.removeItem('limeaura_token');
            if (this.ws) {
                this.ws.close();
                this.ws = null;
            }
        }
    }

    async getCurrentUser() {
        if (this.user) return this.user;
        
        try {
            const response = await this.request('/auth/me');
            this.user = response;
            return this.user;
        } catch (error) {
            this.token = null;
            localStorage.removeItem('limeaura_token');
            throw new Error('Session expired');
        }
    }

    // Organization methods
    async getOrganizations() {
        return await this.request('/organizations');
    }

    async createOrganization(name, slug, description) {
        return await this.request('/organizations', 'POST', { name, slug, description });
    }

    async getOrganization(id) {
        return await this.request(`/organizations/${id}`);
    }

    async updateOrganization(id, data) {
        return await this.request(`/organizations/${id}`, 'PUT', data);
    }

    async deleteOrganization(id) {
        return await this.request(`/organizations/${id}`, 'DELETE');
    }

    // Workspace methods
    async getWorkspaces(organizationId = null) {
        const params = organizationId ? `?organizationId=${organizationId}` : '';
        return await this.request(`/workspaces${params}`);
    }

    async createWorkspace(organizationId, name, slug, description, color = null) {
        return await this.request('/workspaces', 'POST', {
            organizationId,
            name,
            slug,
            description,
            color
        });
    }

    async getWorkspace(id) {
        return await this.request(`/workspaces/${id}`);
    }

    async updateWorkspace(id, data) {
        return await this.request(`/workspaces/${id}`, 'PUT', data);
    }

    async deleteWorkspace(id) {
        return await this.request(`/workspaces/${id}`, 'DELETE');
    }

    // Project methods
    async getProjects(workspaceId = null) {
        const params = workspaceId ? `?workspaceId=${workspaceId}` : '';
        return await this.request(`/projects${params}`);
    }

    async createProject(workspaceId, name, slug, description, color = null, startDate = null, endDate = null) {
        return await this.request('/projects', 'POST', {
            workspaceId,
            name,
            slug,
            description,
            color,
            startDate,
            endDate
        });
    }

    async getProject(id) {
        return await this.request(`/projects/${id}`);
    }

    async updateProject(id, data) {
        return await this.request(`/projects/${id}`, 'PUT', data);
    }

    async deleteProject(id) {
        return await this.request(`/projects/${id}`, 'DELETE');
    }

    // Task methods
    async getTasks(params = {}) {
        const queryParams = new URLSearchParams(params).toString();
        return await this.request(`/tasks${queryParams ? `?${queryParams}` : ''}`);
    }

    async createTask(projectId, title, description = null, assigneeId = null, dueDate = null, priority = 'medium', estimatedHours = null) {
        return await this.request('/tasks', 'POST', {
            projectId,
            title,
            description,
            assigneeId,
            dueDate,
            priority,
            estimatedHours
        });
    }

    async getTask(id) {
        return await this.request(`/tasks/${id}`);
    }

    async updateTask(id, data) {
        return await this.request(`/tasks/${id}`, 'PUT', data);
    }

    async deleteTask(id) {
        return await this.request(`/tasks/${id}`, 'DELETE');
    }

    // Task status methods
    async getTaskStatuses(projectId) {
        return await this.request(`/projects/${projectId}/statuses`);
    }

    async createTaskStatus(projectId, name, color, orderIndex = 0, isDefault = false) {
        return await this.request(`/projects/${projectId}/statuses`, 'POST', {
            name,
            color,
            orderIndex,
            isDefault
        });
    }

    async updateTaskStatus(id, data) {
        return await this.request(`/statuses/${id}`, 'PUT', data);
    }

    async deleteTaskStatus(id) {
        return await this.request(`/statuses/${id}`, 'DELETE');
    }

    // Milestone methods
    async getMilestones(projectId) {
        return await this.request(`/projects/${projectId}/milestones`);
    }

    async createMilestone(projectId, name, description, dueDate, progressPercentage = 0) {
        return await this.request(`/projects/${projectId}/milestones`, 'POST', {
            name,
            description,
            dueDate,
            progressPercentage
        });
    }

    async getMilestone(id) {
        return await this.request(`/milestones/${id}`);
    }

    async updateMilestone(id, data) {
        return await this.request(`/milestones/${id}`, 'PUT', data);
    }

    async deleteMilestone(id) {
        return await this.request(`/milestones/${id}`, 'DELETE');
    }

    // Calendar methods
    async getCalendarEvents(workspaceId) {
        return await this.request(`/workspaces/${workspaceId}/calendar/events`);
    }

    async createCalendarEvent(workspaceId, title, description, eventType, startDate, startTime = null, endTime = null, organizerId, location = null, meetingUrl = null, isAllDay = false) {
        return await this.request(`/workspaces/${workspaceId}/calendar/events`, 'POST', {
            title,
            description,
            eventType,
            startDate,
            startTime,
            endTime,
            organizerId,
            location,
            meetingUrl,
            isAllDay
        });
    }

    async getCalendarEvent(id) {
        return await this.request(`/calendar/events/${id}`);
    }

    async updateCalendarEvent(id, data) {
        return await this.request(`/calendar/events/${id}`, 'PUT', data);
    }

    async deleteCalendarEvent(id) {
        return await this.request(`/calendar/events/${id}`, 'DELETE');
    }

    // Dashboard methods
    async getDashboardMetrics(organizationId = null) {
        const params = organizationId ? `?organizationId=${organizationId}` : '';
        return await this.request(`/dashboard/metrics${params}`);
    }

    async getDashboardActivities(limit = 20, offset = 0) {
        return await this.request(`/dashboard/activities?limit=${limit}&offset=${offset}`);
    }

    // Activity methods
    async getActivities() {
        return await this.request('/activities');
    }

    async getNotifications() {
        return await this.request('/notifications');
    }

    async markNotificationRead(id) {
        return await this.request(`/notifications/${id}/read`, 'PUT');
    }

    // Integration methods
    async getIntegrations() {
        return await this.request('/integrations');
    }

    async createIntegration(serviceType, name, description, isEnabled = false, config = {}) {
        return await this.request('/integrations', 'POST', {
            serviceType,
            name,
            description,
            isEnabled,
            config
        });
    }

    async updateIntegration(id, data) {
        return await this.request(`/integrations/${id}`, 'PUT', data);
    }

    async deleteIntegration(id) {
        return await this.request(`/integrations/${id}`, 'DELETE');
    }

    // WebSocket methods
    setupWebSocket() {
        if (!this.token) return;

        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.host}/ws`;
        
        try {
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('🔌 Connected to LimeAura real-time updates');
                this.reconnectAttempts = 0;
                this.resubscribeAll();
            };
            
            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleWebSocketMessage(data);
                } catch (error) {
                    console.error('WebSocket message error:', error);
                }
            };
            
            this.ws.onclose = () => {
                console.log('🔌 Disconnected from real-time updates');
                this.attemptReconnect();
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
            
        } catch (error) {
            console.error('Failed to setup WebSocket:', error);
        }
    }

    attemptReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnection attempts reached');
            return;
        }
        
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`🔄 Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        
        setTimeout(() => {
            this.setupWebSocket();
        }, delay);
    }

    handleWebSocketMessage(data) {
        // Emit custom events for the application to handle
        const event = new CustomEvent(`limeaura:${data.type}`, {
            detail: data
        });
        window.dispatchEvent(event);
    }

    subscribeToProject(projectId) {
        this.subscriptions.add(`project:${projectId}`);
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'subscribe_project',
                projectId
            }));
        }
    }

    unsubscribeFromProject(projectId) {
        this.subscriptions.delete(`project:${projectId}`);
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'unsubscribe_project',
                projectId
            }));
        }
    }

    resubscribeAll() {
        this.subscriptions.forEach(subscription => {
            if (subscription.startsWith('project:')) {
                const projectId = subscription.replace('project:', '');
                this.subscribeToProject(projectId);
            }
        });
    }

    // Utility methods
    async request(endpoint, method = 'GET', data = null) {
        const url = `${this.baseURL}${endpoint}`;
        const headers = {
            'Content-Type': 'application/json'
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        const config = {
            method,
            headers
        };

        if (data && method !== 'GET') {
            config.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, config);
            const responseData = await response.json();

            if (!response.ok) {
                throw new Error(responseData.error || `HTTP ${response.status}`);
            }

            return responseData;
        } catch (error) {
            if (error.message.includes('Failed to fetch')) {
                throw new Error('Unable to connect to server. Please check your internet connection.');
            }
            throw error;
        }
    }

    // Data transformation utilities
    transformTask(task) {
        return {
            id: task.id,
            title: task.title,
            description: task.description,
            status: task.status_name || 'To Do',
            statusColor: task.status_color || '#6B7280',
            assignee: task.assignee_name ? {
                name: task.assignee_name,
                avatarUrl: task.assignee_avatar
            } : null,
            dueDate: task.due_date,
            priority: task.priority,
            estimatedHours: task.estimated_hours,
            actualHours: task.actual_hours,
            isCompleted: task.is_completed,
            createdAt: task.created_at,
            updatedAt: task.updated_at
        };
    }

    transformMilestone(milestone) {
        return {
            id: milestone.id,
            name: milestone.name,
            description: milestone.description,
            dueDate: milestone.due_date,
            progress: milestone.progress_percentage,
            status: milestone.status,
            isCompleted: milestone.is_completed,
            createdAt: milestone.created_at
        };
    }

    transformProject(project) {
        return {
            id: project.id,
            name: project.name,
            slug: project.slug,
            description: project.description,
            color: project.color,
            status: project.status,
            startDate: project.start_date,
            endDate: project.end_date,
            isArchived: project.is_archived,
            createdAt: project.created_at,
            updatedAt: project.updated_at
        };
    }

    // Event handling utilities
    on(event, callback) {
        window.addEventListener(`limeaura:${event}`, callback);
    }

    off(event, callback) {
        window.removeEventListener(`limeaura:${event}`, callback);
    }

    // Cache management
    clearCache() {
        // Clear any cached data
        this.user = null;
    }

    // Health check
    async healthCheck() {
        try {
            const response = await this.request('/health');
            return response.status === 'healthy';
        } catch (error) {
            console.error('Health check failed:', error);
            return false;
        }
    }
}

// Create global API instance
window.limeauraAPI = new LimeAuraAPI();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LimeAuraAPI;
}