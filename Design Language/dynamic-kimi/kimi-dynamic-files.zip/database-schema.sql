-- LimeAura Productivity Suite - Database Schema
-- Version: 3.0.0 - Dynamic Application Backend
-- Supports: PostgreSQL 14+

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create schema
CREATE SCHEMA IF NOT EXISTS limeaura;

-- Set search path
SET search_path TO limeaura, public;

-- =============================================================================
-- CORE USER AND AUTHENTICATION TABLES
-- =============================================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    avatar_url TEXT,
    timezone VARCHAR(50) DEFAULT 'UTC',
    locale VARCHAR(10) DEFAULT 'en-US',
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    avatar_url TEXT,
    website_url TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE organization_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    invited_by UUID REFERENCES users(id),
    UNIQUE(organization_id, user_id)
);

-- =============================================================================
-- WORKSPACE AND PROJECT HIERARCHY
-- =============================================================================

CREATE TABLE workspaces (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(50) NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#7B3EFF',
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id),
    metadata JSONB DEFAULT '{}'::jsonb,
    UNIQUE(organization_id, slug)
);

CREATE TABLE workspace_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'member', 'viewer')),
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(workspace_id, user_id)
);

CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(50) NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#7B3EFF',
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'completed', 'archived')),
    start_date DATE,
    end_date DATE,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id),
    metadata JSONB DEFAULT '{}'::jsonb,
    UNIQUE(workspace_id, slug)
);

CREATE TABLE project_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'member', 'viewer')),
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, user_id)
);

-- =============================================================================
-- TASK MANAGEMENT SYSTEM
-- =============================================================================

CREATE TABLE task_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    color VARCHAR(7) DEFAULT '#6B7280',
    order_index INTEGER NOT NULL DEFAULT 0,
    is_default BOOLEAN DEFAULT false,
    is_completed BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, name)
);

CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    status_id UUID REFERENCES task_statuses(id) ON DELETE SET NULL,
    parent_task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    assignee_id UUID REFERENCES users(id) ON DELETE SET NULL,
    due_date DATE,
    priority VARCHAR(10) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    estimated_hours DECIMAL(5,2),
    actual_hours DECIMAL(5,2),
    order_index INTEGER NOT NULL DEFAULT 0,
    is_completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    completed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE task_tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    color VARCHAR(7) DEFAULT '#9CA3AF',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(project_id, name)
);

CREATE TABLE task_tag_assignments (
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES task_tags(id) ON DELETE CASCADE,
    PRIMARY KEY (task_id, tag_id)
);

CREATE TABLE task_dependencies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    depends_on_task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    dependency_type VARCHAR(20) DEFAULT 'finish_to_start' CHECK (dependency_type IN ('finish_to_start', 'start_to_start', 'finish_to_finish', 'start_to_finish')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(task_id, depends_on_task_id)
);

-- =============================================================================
-- MILESTONE AND GOAL TRACKING
-- =============================================================================

CREATE TABLE milestones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    due_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'overdue')),
    progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    is_completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    completed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE milestone_tasks (
    milestone_id UUID NOT NULL REFERENCES milestones(id) ON DELETE CASCADE,
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    PRIMARY KEY (milestone_id, task_id)
);

-- =============================================================================
-- CALENDAR AND EVENTS
-- =============================================================================

CREATE TABLE calendar_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    event_type VARCHAR(20) DEFAULT 'event' CHECK (event_type IN ('event', 'meeting', 'reminder', 'deadline')),
    start_date DATE NOT NULL,
    end_date DATE,
    start_time TIME,
    end_time TIME,
    is_all_day BOOLEAN DEFAULT false,
    location TEXT,
    meeting_url TEXT,
    organizer_id UUID NOT NULL REFERENCES users(id),
    is_recurring BOOLEAN DEFAULT false,
    recurrence_rule TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE calendar_event_attendees (
    event_id UUID NOT NULL REFERENCES calendar_events(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'tentative')),
    responded_at TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY (event_id, user_id)
);

-- =============================================================================
-- ACTIVITY AND NOTIFICATIONS
-- =============================================================================

CREATE TABLE activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action_type VARCHAR(50) NOT NULL, -- 'task_created', 'task_completed', 'comment_added', etc.
    entity_type VARCHAR(30) NOT NULL, -- 'task', 'project', 'milestone', etc.
    entity_id UUID NOT NULL,
    entity_title VARCHAR(200),
    description TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(30) NOT NULL, -- 'task_assigned', 'deadline_approaching', 'mention', etc.
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    action_url TEXT,
    is_read BOOLEAN DEFAULT false,
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

-- =============================================================================
-- COMMENTS AND COLLABORATION
-- =============================================================================

CREATE TABLE comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(30) NOT NULL, -- 'task', 'project', 'milestone', etc.
    entity_id UUID NOT NULL,
    author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_comment_id UUID REFERENCES comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    is_edited BOOLEAN DEFAULT false,
    edited_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE comment_mentions (
    comment_id UUID NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mentioned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (comment_id, user_id)
);

-- =============================================================================
-- FILE ATTACHMENTS AND ASSETS
-- =============================================================================

CREATE TABLE file_attachments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(30) NOT NULL, -- 'task', 'comment', 'project', etc.
    entity_id UUID NOT NULL,
    uploader_id UUID NOT NULL REFERENCES users(id),
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    storage_path TEXT NOT NULL,
    thumbnail_path TEXT,
    is_image BOOLEAN DEFAULT false,
    width INTEGER,
    height INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'::jsonb
);

-- =============================================================================
-- INTEGRATIONS AND EXTERNAL SERVICES
-- =============================================================================

CREATE TABLE integrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    service_type VARCHAR(50) NOT NULL, -- 'slack', 'github', 'google_drive', etc.
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_enabled BOOLEAN DEFAULT false,
    config JSONB NOT NULL DEFAULT '{}'::jsonb, -- API keys, webhooks, etc.
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id),
    UNIQUE(organization_id, service_type)
);

-- =============================================================================
-- WORKFLOW AND AUTOMATION
-- =============================================================================

CREATE TABLE workflow_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    trigger_type VARCHAR(30) NOT NULL, -- 'task_created', 'status_changed', 'deadline_approaching', etc.
    trigger_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    action_type VARCHAR(30) NOT NULL, -- 'assign_user', 'send_notification', 'update_field', etc.
    action_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID NOT NULL REFERENCES users(id)
);

-- =============================================================================
-- INDEXES FOR PERFORMANCE
-- =============================================================================

-- User and authentication indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_active ON users(is_active) WHERE is_active = true;

-- Organization indexes
CREATE INDEX idx_org_members_user ON organization_members(user_id);
CREATE INDEX idx_org_members_org ON organization_members(organization_id);

-- Workspace indexes
CREATE INDEX idx_workspace_members_user ON workspace_members(user_id);
CREATE INDEX idx_workspace_members_workspace ON workspace_members(workspace_id);

-- Project indexes
CREATE INDEX idx_project_members_user ON project_members(user_id);
CREATE INDEX idx_project_members_project ON project_members(project_id);
CREATE INDEX idx_projects_workspace ON projects(workspace_id);
CREATE INDEX idx_projects_status ON projects(status) WHERE status = 'active';

-- Task indexes
CREATE INDEX idx_tasks_project ON tasks(project_id);
CREATE INDEX idx_tasks_assignee ON tasks(assignee_id);
CREATE INDEX idx_tasks_status ON tasks(status_id);
CREATE INDEX idx_tasks_due_date ON tasks(due_date);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_tasks_completed ON tasks(is_completed);

-- Activity and notification indexes
CREATE INDEX idx_activities_user ON activities(user_id);
CREATE INDEX idx_activities_created ON activities(created_at);
CREATE INDEX idx_activities_entity ON activities(entity_type, entity_id);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read) WHERE is_read = false;

-- Calendar indexes
CREATE INDEX idx_calendar_events_workspace ON calendar_events(workspace_id);
CREATE INDEX idx_calendar_events_start_date ON calendar_events(start_date);
CREATE INDEX idx_calendar_events_organizer ON calendar_events(organizer_id);

-- Comment indexes
CREATE INDEX idx_comments_entity ON comments(entity_type, entity_id);
CREATE INDEX idx_comments_author ON comments(author_id);
CREATE INDEX idx_comments_created ON comments(created_at);

-- File attachment indexes
CREATE INDEX idx_file_attachments_entity ON file_attachments(entity_type, entity_id);
CREATE INDEX idx_file_attachments_uploader ON file_attachments(uploader_id);

-- =============================================================================
-- FUNCTIONS AND TRIGGERS
-- =============================================================================

-- Function to update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at columns
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_workspaces_updated_at BEFORE UPDATE ON workspaces 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_milestones_updated_at BEFORE UPDATE ON milestones 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_integrations_updated_at BEFORE UPDATE ON integrations 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically create default task statuses for new projects
CREATE OR REPLACE FUNCTION create_default_task_statuses()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO task_statuses (project_id, name, color, order_index, is_default) VALUES
        (NEW.id, 'To Do', '#6B7280', 0, true),
        (NEW.id, 'In Progress', '#3B82F6', 1, false),
        (NEW.id, 'Review', '#F59E0B', 2, false),
        (NEW.id, 'Done', '#10B981', 3, false);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to create default task statuses
CREATE TRIGGER create_default_statuses_after_project
    AFTER INSERT ON projects
    FOR EACH ROW EXECUTE FUNCTION create_default_task_statuses();

-- Function to update milestone progress based on task completion
CREATE OR REPLACE FUNCTION update_milestone_progress()
RETURNS TRIGGER AS $$
DECLARE
    milestone_record RECORD;
    total_tasks INTEGER;
    completed_tasks INTEGER;
    new_progress INTEGER;
BEGIN
    -- Check if this task is associated with any milestones
    FOR milestone_record IN 
        SELECT milestone_id FROM milestone_tasks WHERE task_id = NEW.id
    LOOP
        -- Count total and completed tasks for this milestone
        SELECT 
            COUNT(*)::INTEGER,
            COUNT(CASE WHEN is_completed = true THEN 1 END)::INTEGER
        INTO total_tasks, completed_tasks
        FROM tasks 
        WHERE id IN (SELECT task_id FROM milestone_tasks WHERE milestone_id = milestone_record.milestone_id);
        
        -- Calculate new progress percentage
        IF total_tasks > 0 THEN
            new_progress := (completed_tasks * 100) / total_tasks;
        ELSE
            new_progress := 0;
        END IF;
        
        -- Update milestone progress
        UPDATE milestones 
        SET progress_percentage = new_progress,
            status = CASE 
                WHEN new_progress = 100 THEN 'completed'
                WHEN new_progress > 0 THEN 'in_progress'
                ELSE 'pending'
            END,
            is_completed = (new_progress = 100),
            completed_at = CASE WHEN new_progress = 100 THEN CURRENT_TIMESTAMP ELSE completed_at END
        WHERE id = milestone_record.milestone_id;
    END LOOP;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update milestone progress when tasks are completed
CREATE TRIGGER update_milestone_progress_after_task_update
    AFTER UPDATE OF is_completed ON tasks
    FOR EACH ROW EXECUTE FUNCTION update_milestone_progress();

-- =============================================================================
-- INITIAL DATA
-- =============================================================================

-- Insert default task priorities
INSERT INTO task_statuses (project_id, name, color, order_index, is_default) 
SELECT '00000000-0000-0000-0000-000000000000', name, color, order_index, is_default
FROM (VALUES 
    ('To Do', '#6B7280', 0, true),
    ('In Progress', '#3B82F6', 1, false),
    ('Review', '#F59E0B', 2, false),
    ('Done', '#10B981', 3, false)
) AS default_statuses(name, color, order_index, is_default)
WHERE NOT EXISTS (SELECT 1 FROM task_statuses WHERE project_id = '00000000-0000-0000-0000-000000000000');

-- =============================================================================
-- VIEWS FOR COMMON QUERIES
-- =============================================================================

-- View for task details with all related information
CREATE VIEW task_details AS
SELECT 
    t.*,
    p.name as project_name,
    p.slug as project_slug,
    w.name as workspace_name,
    w.slug as workspace_slug,
    o.name as organization_name,
    o.slug as organization_slug,
    assignee.display_name as assignee_name,
    assignee.avatar_url as assignee_avatar,
    assignee.username as assignee_username,
    creator.display_name as creator_name,
    creator.avatar_url as creator_avatar,
    creator.username as creator_username,
    ts.name as status_name,
    ts.color as status_color,
    ts.is_completed as status_is_completed,
    array_agg(DISTINCT tg.name) FILTER (WHERE tg.name IS NOT NULL) as tags,
    array_agg(DISTINCT tg.color) FILTER (WHERE tg.color IS NOT NULL) as tag_colors
FROM tasks t
LEFT JOIN projects p ON t.project_id = p.id
LEFT JOIN workspaces w ON p.workspace_id = w.id
LEFT JOIN organizations o ON w.organization_id = o.id
LEFT JOIN users assignee ON t.assignee_id = assignee.id
LEFT JOIN users creator ON t.created_by = creator.id
LEFT JOIN task_statuses ts ON t.status_id = ts.id
LEFT JOIN task_tag_assignments tta ON t.id = tta.task_id
LEFT JOIN task_tags tg ON tta.tag_id = tg.id
GROUP BY t.id, p.name, p.slug, w.name, w.slug, o.name, o.slug, 
         assignee.display_name, assignee.avatar_url, assignee.username,
         creator.display_name, creator.avatar_url, creator.username,
         ts.name, ts.color, ts.is_completed;

-- View for dashboard metrics
CREATE VIEW dashboard_metrics AS
SELECT 
    o.id as organization_id,
    o.name as organization_name,
    w.id as workspace_id,
    w.name as workspace_name,
    p.id as project_id,
    p.name as project_name,
    COUNT(DISTINCT t.id) FILTER (WHERE t.is_completed = false) as active_tasks,
    COUNT(DISTINCT t.id) FILTER (WHERE t.is_completed = true) as completed_tasks,
    COUNT(DISTINCT t.id) as total_tasks,
    COUNT(DISTINCT t.assignee_id) FILTER (WHERE t.assignee_id IS NOT NULL) as assigned_members,
    COUNT(DISTINCT m.id) as total_milestones,
    COUNT(DISTINCT m.id) FILTER (WHERE m.is_completed = true) as completed_milestones
FROM organizations o
LEFT JOIN workspaces w ON o.id = w.organization_id
LEFT JOIN projects p ON w.id = p.workspace_id
LEFT JOIN tasks t ON p.id = t.project_id
LEFT JOIN milestones m ON p.id = m.project_id
GROUP BY o.id, o.name, w.id, w.name, p.id, p.name;

-- =============================================================================
-- ROW LEVEL SECURITY POLICIES
-- =============================================================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_attachments ENABLE ROW LEVEL SECURITY;

-- Example RLS policies (simplified - would need to be expanded for full security)
CREATE POLICY "Users can view their organizations" ON organizations
    FOR SELECT USING (
        id IN (SELECT organization_id FROM organization_members WHERE user_id = current_user_id())
    );

CREATE POLICY "Users can view their workspaces" ON workspaces
    FOR SELECT USING (
        id IN (SELECT workspace_id FROM workspace_members WHERE user_id = current_user_id())
    );

CREATE POLICY "Users can view their projects" ON projects
    FOR SELECT USING (
        id IN (SELECT project_id FROM project_members WHERE user_id = current_user_id())
    );

-- =============================================================================
-- FUNCTIONS TO HELP WITH RLS
-- =============================================================================

-- Function to get current user ID (would be set by application)
CREATE OR REPLACE FUNCTION current_user_id()
RETURNS UUID AS $$
BEGIN
    -- This would be set by the application using SET
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Grant necessary permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA limeaura TO app_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA limeaura TO app_user;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA limeaura TO app_user;

-- Create indexes for better performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tasks_composite ON tasks(project_id, status_id, assignee_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_activities_composite ON activities(organization_id, created_at DESC);

-- Final notes for production deployment:
-- 1. Set up proper connection pooling
-- 2. Configure backup and replication
-- 3. Set up monitoring and alerting
-- 4. Implement proper error handling and logging
-- 5. Configure SSL/TLS for connections
-- 6. Set up read replicas for read-heavy operations
-- 7. Implement data retention policies
-- 8. Configure automated database migrations