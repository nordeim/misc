/**
 * LimeAura Backend API Server
 * Express.js server with PostgreSQL integration
 * Version: 3.0.0 - Dynamic Application Backend
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const WebSocket = require('ws');
const http = require('http');

// Environment configuration
require('dotenv').config();

class LimeAuraServer {
    constructor() {
        this.app = express();
        this.server = http.createServer(this.app);
        this.wss = new WebSocket.Server({ server: this.server });
        this.pool = new Pool({
            connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/limeaura',
            ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
        });
        
        this.setupMiddleware();
        this.setupRoutes();
        this.setupWebSocket();
        this.setupErrorHandling();
    }

    setupMiddleware() {
        // Security middleware
        this.app.use(helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
                    fontSrc: ["'self'", "https://fonts.gstatic.com"],
                    scriptSrc: ["'self'"],
                    imgSrc: ["'self'", "data:", "https:"],
                    connectSrc: ["'self'", "ws:", "wss:"]
                }
            }
        }));

        // CORS configuration
        this.app.use(cors({
            origin: process.env.FRONTEND_URL || 'http://localhost:3000',
            credentials: true,
            methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
            allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
        }));

        // Compression
        this.app.use(compression());

        // Rate limiting
        const limiter = rateLimit({
            windowMs: 15 * 60 * 1000, // 15 minutes
            max: 1000, // limit each IP to 1000 requests per windowMs
            message: {
                error: 'Too many requests from this IP, please try again later.',
                retryAfter: 15 * 60
            }
        });
        this.app.use('/api/', limiter);

        // Body parsing
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));

        // Request logging
        this.app.use((req, res, next) => {
            console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
            next();
        });
    }

    setupRoutes() {
        // Health check
        this.app.get('/api/health', (req, res) => {
            res.json({ 
                status: 'healthy', 
                timestamp: new Date().toISOString(),
                version: '3.0.0',
                environment: process.env.NODE_ENV || 'development'
            });
        });

        // Authentication routes
        this.app.post('/api/auth/register', this.register.bind(this));
        this.app.post('/api/auth/login', this.login.bind(this));
        this.app.post('/api/auth/logout', this.logout.bind(this));
        this.app.get('/api/auth/me', this.authenticate.bind(this), this.getCurrentUser.bind(this));

        // Organization routes
        this.app.get('/api/organizations', this.authenticate.bind(this), this.getOrganizations.bind(this));
        this.app.post('/api/organizations', this.authenticate.bind(this), this.createOrganization.bind(this));
        this.app.get('/api/organizations/:id', this.authenticate.bind(this), this.getOrganization.bind(this));
        this.app.put('/api/organizations/:id', this.authenticate.bind(this), this.updateOrganization.bind(this));
        this.app.delete('/api/organizations/:id', this.authenticate.bind(this), this.deleteOrganization.bind(this));

        // Workspace routes
        this.app.get('/api/workspaces', this.authenticate.bind(this), this.getWorkspaces.bind(this));
        this.app.post('/api/workspaces', this.authenticate.bind(this), this.createWorkspace.bind(this));
        this.app.get('/api/workspaces/:id', this.authenticate.bind(this), this.getWorkspace.bind(this));
        this.app.put('/api/workspaces/:id', this.authenticate.bind(this), this.updateWorkspace.bind(this));
        this.app.delete('/api/workspaces/:id', this.authenticate.bind(this), this.deleteWorkspace.bind(this));

        // Project routes
        this.app.get('/api/projects', this.authenticate.bind(this), this.getProjects.bind(this));
        this.app.post('/api/projects', this.authenticate.bind(this), this.createProject.bind(this));
        this.app.get('/api/projects/:id', this.authenticate.bind(this), this.getProject.bind(this));
        this.app.put('/api/projects/:id', this.authenticate.bind(this), this.updateProject.bind(this));
        this.app.delete('/api/projects/:id', this.authenticate.bind(this), this.deleteProject.bind(this));

        // Task routes
        this.app.get('/api/tasks', this.authenticate.bind(this), this.getTasks.bind(this));
        this.app.post('/api/tasks', this.authenticate.bind(this), this.createTask.bind(this));
        this.app.get('/api/tasks/:id', this.authenticate.bind(this), this.getTask.bind(this));
        this.app.put('/api/tasks/:id', this.authenticate.bind(this), this.updateTask.bind(this));
        this.app.delete('/api/tasks/:id', this.authenticate.bind(this), this.deleteTask.bind(this));

        // Task status routes
        this.app.get('/api/projects/:projectId/statuses', this.authenticate.bind(this), this.getTaskStatuses.bind(this));
        this.app.post('/api/projects/:projectId/statuses', this.authenticate.bind(this), this.createTaskStatus.bind(this));
        this.app.put('/api/statuses/:id', this.authenticate.bind(this), this.updateTaskStatus.bind(this));
        this.app.delete('/api/statuses/:id', this.authenticate.bind(this), this.deleteTaskStatus.bind(this));

        // Milestone routes
        this.app.get('/api/projects/:projectId/milestones', this.authenticate.bind(this), this.getMilestones.bind(this));
        this.app.post('/api/projects/:projectId/milestones', this.authenticate.bind(this), this.createMilestone.bind(this));
        this.app.get('/api/milestones/:id', this.authenticate.bind(this), this.getMilestone.bind(this));
        this.app.put('/api/milestones/:id', this.authenticate.bind(this), this.updateMilestone.bind(this));
        this.app.delete('/api/milestones/:id', this.authenticate.bind(this), this.deleteMilestone.bind(this));

        // Calendar routes
        this.app.get('/api/workspaces/:workspaceId/calendar/events', this.authenticate.bind(this), this.getCalendarEvents.bind(this));
        this.app.post('/api/workspaces/:workspaceId/calendar/events', this.authenticate.bind(this), this.createCalendarEvent.bind(this));
        this.app.get('/api/calendar/events/:id', this.authenticate.bind(this), this.getCalendarEvent.bind(this));
        this.app.put('/api/calendar/events/:id', this.authenticate.bind(this), this.updateCalendarEvent.bind(this));
        this.app.delete('/api/calendar/events/:id', this.authenticate.bind(this), this.deleteCalendarEvent.bind(this));

        // Activity routes
        this.app.get('/api/activities', this.authenticate.bind(this), this.getActivities.bind(this));
        this.app.get('/api/notifications', this.authenticate.bind(this), this.getNotifications.bind(this));
        this.app.put('/api/notifications/:id/read', this.authenticate.bind(this), this.markNotificationRead.bind(this));

        // Dashboard routes
        this.app.get('/api/dashboard/metrics', this.authenticate.bind(this), this.getDashboardMetrics.bind(this));
        this.app.get('/api/dashboard/activities', this.authenticate.bind(this), this.getDashboardActivities.bind(this));

        // Integration routes
        this.app.get('/api/integrations', this.authenticate.bind(this), this.getIntegrations.bind(this));
        this.app.post('/api/integrations', this.authenticate.bind(this), this.createIntegration.bind(this));
        this.app.put('/api/integrations/:id', this.authenticate.bind(this), this.updateIntegration.bind(this));
        this.app.delete('/api/integrations/:id', this.authenticate.bind(this), this.deleteIntegration.bind(this));

        // Serve static files
        this.app.use(express.static('public'));

        // SPA fallback
        this.app.get('*', (req, res) => {
            res.sendFile('index.html', { root: 'public' });
        });
    }

    // Authentication middleware
    authenticate(req, res, next) {
        const token = req.header('Authorization')?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({ error: 'Access token required' });
        }

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
            req.user = decoded;
            next();
        } catch (error) {
            return res.status(401).json({ error: 'Invalid access token' });
        }
    }

    // Authentication methods
    async register(req, res) {
        try {
            const { email, username, displayName, password } = req.body;

            // Validation
            if (!email || !username || !displayName || !password) {
                return res.status(400).json({ error: 'All fields are required' });
            }

            if (password.length < 8) {
                return res.status(400).json({ error: 'Password must be at least 8 characters' });
            }

            // Check if user exists
            const existingUser = await this.pool.query(
                'SELECT id FROM users WHERE email = $1 OR username = $2',
                [email, username]
            );

            if (existingUser.rows.length > 0) {
                return res.status(400).json({ error: 'User with this email or username already exists' });
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(password, 12);

            // Create user
            const userResult = await this.pool.query(
                `INSERT INTO users (email, username, display_name, metadata) 
                 VALUES ($1, $2, $3, $4) 
                 RETURNING id, email, username, display_name, avatar_url, created_at`,
                [email, username, displayName, JSON.stringify({ password: hashedPassword })]
            );

            const user = userResult.rows[0];

            // Generate JWT token
            const token = jwt.sign(
                { userId: user.id, email: user.email, username: user.username },
                process.env.JWT_SECRET || 'fallback-secret',
                { expiresIn: '7d' }
            );

            res.status(201).json({
                message: 'User registered successfully',
                user: {
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    displayName: user.display_name,
                    avatarUrl: user.avatar_url,
                    createdAt: user.created_at
                },
                token
            });

        } catch (error) {
            console.error('Registration error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async login(req, res) {
        try {
            const { email, password } = req.body;

            if (!email || !password) {
                return res.status(400).json({ error: 'Email and password are required' });
            }

            // Find user
            const userResult = await this.pool.query(
                'SELECT id, email, username, display_name, avatar_url, metadata, created_at FROM users WHERE email = $1 AND is_active = true',
                [email]
            );

            if (userResult.rows.length === 0) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            const user = userResult.rows[0];
            const metadata = user.metadata || {};

            // Verify password
            const isValidPassword = await bcrypt.compare(password, metadata.password || '');
            if (!isValidPassword) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }

            // Update last login
            await this.pool.query(
                'UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = $1',
                [user.id]
            );

            // Generate JWT token
            const token = jwt.sign(
                { userId: user.id, email: user.email, username: user.username },
                process.env.JWT_SECRET || 'fallback-secret',
                { expiresIn: '7d' }
            );

            res.json({
                message: 'Login successful',
                user: {
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    displayName: user.display_name,
                    avatarUrl: user.avatar_url,
                    createdAt: user.created_at
                },
                token
            });

        } catch (error) {
            console.error('Login error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async logout(req, res) {
        // In a real application, you might want to invalidate the token
        res.json({ message: 'Logged out successfully' });
    }

    async getCurrentUser(req, res) {
        try {
            const userResult = await this.pool.query(
                'SELECT id, email, username, display_name, avatar_url, created_at FROM users WHERE id = $1',
                [req.user.userId]
            );

            if (userResult.rows.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            const user = userResult.rows[0];
            res.json({
                id: user.id,
                email: user.email,
                username: user.username,
                displayName: user.display_name,
                avatarUrl: user.avatar_url,
                createdAt: user.created_at
            });

        } catch (error) {
            console.error('Get current user error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // Organization methods
    async getOrganizations(req, res) {
        try {
            const result = await this.pool.query(
                `SELECT o.*, om.role as user_role
                 FROM organizations o
                 JOIN organization_members om ON o.id = om.organization_id
                 WHERE om.user_id = $1 AND o.is_active = true
                 ORDER BY o.created_at DESC`,
                [req.user.userId]
            );

            res.json(result.rows);

        } catch (error) {
            console.error('Get organizations error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async createOrganization(req, res) {
        try {
            const { name, slug, description } = req.body;

            if (!name || !slug) {
                return res.status(400).json({ error: 'Name and slug are required' });
            }

            // Check if slug is available
            const existingSlug = await this.pool.query(
                'SELECT id FROM organizations WHERE slug = $1',
                [slug]
            );

            if (existingSlug.rows.length > 0) {
                return res.status(400).json({ error: 'Slug is already taken' });
            }

            // Create organization
            const orgResult = await this.pool.query(
                `INSERT INTO organizations (name, slug, description) 
                 VALUES ($1, $2, $3) 
                 RETURNING *`,
                [name, slug, description]
            );

            const organization = orgResult.rows[0];

            // Add creator as owner
            await this.pool.query(
                'INSERT INTO organization_members (organization_id, user_id, role) VALUES ($1, $2, $3)',
                [organization.id, req.user.userId, 'owner']
            );

            res.status(201).json(organization);

        } catch (error) {
            console.error('Create organization error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // Workspace methods
    async getWorkspaces(req, res) {
        try {
            const { organizationId } = req.query;
            
            let query = `
                SELECT w.*, wm.role as user_role
                FROM workspaces w
                JOIN workspace_members wm ON w.id = wm.workspace_id
                WHERE wm.user_id = $1 AND w.is_archived = false
            `;
            const params = [req.user.userId];

            if (organizationId) {
                query += ' AND w.organization_id = $2';
                params.push(organizationId);
            }

            query += ' ORDER BY w.created_at DESC';

            const result = await this.pool.query(query, params);
            res.json(result.rows);

        } catch (error) {
            console.error('Get workspaces error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async createWorkspace(req, res) {
        try {
            const { organizationId, name, slug, description, color } = req.body;

            if (!organizationId || !name || !slug) {
                return res.status(400).json({ error: 'Organization ID, name, and slug are required' });
            }

            // Verify user has access to organization
            const orgAccess = await this.pool.query(
                'SELECT 1 FROM organization_members WHERE organization_id = $1 AND user_id = $2',
                [organizationId, req.user.userId]
            );

            if (orgAccess.rows.length === 0) {
                return res.status(403).json({ error: 'Access denied to organization' });
            }

            // Check if slug is available
            const existingSlug = await this.pool.query(
                'SELECT id FROM workspaces WHERE organization_id = $1 AND slug = $2',
                [organizationId, slug]
            );

            if (existingSlug.rows.length > 0) {
                return res.status(400).json({ error: 'Slug is already taken in this organization' });
            }

            // Create workspace
            const workspaceResult = await this.pool.query(
                `INSERT INTO workspaces (organization_id, name, slug, description, color, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6) 
                 RETURNING *`,
                [organizationId, name, slug, description, color || '#7B3EFF', req.user.userId]
            );

            const workspace = workspaceResult.rows[0];

            // Add creator as admin
            await this.pool.query(
                'INSERT INTO workspace_members (workspace_id, user_id, role) VALUES ($1, $2, $3)',
                [workspace.id, req.user.userId, 'admin']
            );

            res.status(201).json(workspace);

        } catch (error) {
            console.error('Create workspace error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // Project methods
    async getProjects(req, res) {
        try {
            const { workspaceId } = req.query;
            
            let query = `
                SELECT p.*, pm.role as user_role
                FROM projects p
                JOIN project_members pm ON p.id = pm.project_id
                WHERE pm.user_id = $1 AND p.is_archived = false
            `;
            const params = [req.user.userId];

            if (workspaceId) {
                query += ' AND p.workspace_id = $2';
                params.push(workspaceId);
            }

            query += ' ORDER BY p.created_at DESC';

            const result = await this.pool.query(query, params);
            res.json(result.rows);

        } catch (error) {
            console.error('Get projects error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async createProject(req, res) {
        try {
            const { workspaceId, name, slug, description, color, startDate, endDate } = req.body;

            if (!workspaceId || !name || !slug) {
                return res.status(400).json({ error: 'Workspace ID, name, and slug are required' });
            }

            // Verify user has access to workspace
            const workspaceAccess = await this.pool.query(
                'SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2',
                [workspaceId, req.user.userId]
            );

            if (workspaceAccess.rows.length === 0) {
                return res.status(403).json({ error: 'Access denied to workspace' });
            }

            // Check if slug is available
            const existingSlug = await this.pool.query(
                'SELECT id FROM projects WHERE workspace_id = $1 AND slug = $2',
                [workspaceId, slug]
            );

            if (existingSlug.rows.length > 0) {
                return res.status(400).json({ error: 'Slug is already taken in this workspace' });
            }

            // Create project
            const projectResult = await this.pool.query(
                `INSERT INTO projects (workspace_id, name, slug, description, color, start_date, end_date, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
                 RETURNING *`,
                [workspaceId, name, slug, description, color || '#7B3EFF', startDate, endDate, req.user.userId]
            );

            const project = projectResult.rows[0];

            // Add creator as admin
            await this.pool.query(
                'INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, $3)',
                [project.id, req.user.userId, 'admin']
            );

            res.status(201).json(project);

        } catch (error) {
            console.error('Create project error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // Task methods
    async getTasks(req, res) {
        try {
            const { projectId, assigneeId, status, priority, isCompleted } = req.query;
            
            let query = `
                SELECT t.*, 
                       p.name as project_name,
                       assignee.display_name as assignee_name,
                       assignee.avatar_url as assignee_avatar,
                       creator.display_name as creator_name,
                       ts.name as status_name,
                       ts.color as status_color
                FROM tasks t
                JOIN projects p ON t.project_id = p.id
                JOIN project_members pm ON p.id = pm.project_id
                LEFT JOIN users assignee ON t.assignee_id = assignee.id
                LEFT JOIN users creator ON t.created_by = creator.id
                LEFT JOIN task_statuses ts ON t.status_id = ts.id
                WHERE pm.user_id = $1
            `;
            const params = [req.user.userId];
            let paramCount = 1;

            if (projectId) {
                paramCount++;
                query += ` AND t.project_id = $${paramCount}`;
                params.push(projectId);
            }

            if (assigneeId) {
                paramCount++;
                query += ` AND t.assignee_id = $${paramCount}`;
                params.push(assigneeId);
            }

            if (status) {
                paramCount++;
                query += ` AND ts.name = $${paramCount}`;
                params.push(status);
            }

            if (priority) {
                paramCount++;
                query += ` AND t.priority = $${paramCount}`;
                params.push(priority);
            }

            if (isCompleted !== undefined) {
                paramCount++;
                query += ` AND t.is_completed = $${paramCount}`;
                params.push(isCompleted === 'true');
            }

            query += ' ORDER BY t.created_at DESC';

            const result = await this.pool.query(query, params);
            res.json(result.rows);

        } catch (error) {
            console.error('Get tasks error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async createTask(req, res) {
        try {
            const { projectId, title, description, assigneeId, dueDate, priority, estimatedHours } = req.body;

            if (!projectId || !title) {
                return res.status(400).json({ error: 'Project ID and title are required' });
            }

            // Verify user has access to project
            const projectAccess = await this.pool.query(
                'SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2',
                [projectId, req.user.userId]
            );

            if (projectAccess.rows.length === 0) {
                return res.status(403).json({ error: 'Access denied to project' });
            }

            // Get default status for project
            const statusResult = await this.pool.query(
                'SELECT id FROM task_statuses WHERE project_id = $1 AND is_default = true',
                [projectId]
            );

            const defaultStatusId = statusResult.rows.length > 0 ? statusResult.rows[0].id : null;

            // Create task
            const taskResult = await this.pool.query(
                `INSERT INTO tasks (project_id, status_id, title, description, assignee_id, due_date, priority, estimated_hours, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) 
                 RETURNING *`,
                [projectId, defaultStatusId, title, description, assigneeId, dueDate, priority || 'medium', estimatedHours, req.user.userId]
            );

            const task = taskResult.rows[0];

            // Create activity record
            await this.pool.query(
                `INSERT INTO activities (organization_id, workspace_id, project_id, user_id, action_type, entity_type, entity_id, entity_title) 
                 SELECT o.id, w.id, p.id, $1, 'task_created', 'task', $2, $3
                 FROM projects p
                 JOIN workspaces w ON p.workspace_id = w.id
                 JOIN organizations o ON w.organization_id = o.id
                 WHERE p.id = $4`,
                [req.user.userId, task.id, task.title, projectId]
            );

            // Send real-time update
            this.broadcastToProject(projectId, 'task_created', task);

            res.status(201).json(task);

        } catch (error) {
            console.error('Create task error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async updateTask(req, res) {
        try {
            const { id } = req.params;
            const { title, description, assigneeId, statusId, dueDate, priority, estimatedHours, actualHours, isCompleted } = req.body;

            // Verify task exists and user has access
            const taskAccess = await this.pool.query(
                `SELECT t.id FROM tasks t
                 JOIN projects p ON t.project_id = p.id
                 JOIN project_members pm ON p.id = pm.project_id
                 WHERE t.id = $1 AND pm.user_id = $2`,
                [id, req.user.userId]
            );

            if (taskAccess.rows.length === 0) {
                return res.status(404).json({ error: 'Task not found or access denied' });
            }

            // Build dynamic update query
            const updates = [];
            const values = [];
            let paramCount = 0;

            if (title !== undefined) {
                paramCount++;
                updates.push(`title = $${paramCount}`);
                values.push(title);
            }

            if (description !== undefined) {
                paramCount++;
                updates.push(`description = $${paramCount}`);
                values.push(description);
            }

            if (assigneeId !== undefined) {
                paramCount++;
                updates.push(`assignee_id = $${paramCount}`);
                values.push(assigneeId);
            }

            if (statusId !== undefined) {
                paramCount++;
                updates.push(`status_id = $${paramCount}`);
                values.push(statusId);
            }

            if (dueDate !== undefined) {
                paramCount++;
                updates.push(`due_date = $${paramCount}`);
                values.push(dueDate);
            }

            if (priority !== undefined) {
                paramCount++;
                updates.push(`priority = $${paramCount}`);
                values.push(priority);
            }

            if (estimatedHours !== undefined) {
                paramCount++;
                updates.push(`estimated_hours = $${paramCount}`);
                values.push(estimatedHours);
            }

            if (actualHours !== undefined) {
                paramCount++;
                updates.push(`actual_hours = $${paramCount}`);
                values.push(actualHours);
            }

            if (isCompleted !== undefined) {
                paramCount++;
                updates.push(`is_completed = $${paramCount}`);
                updates.push(`completed_at = CASE WHEN $${paramCount} = true THEN CURRENT_TIMESTAMP ELSE NULL END`);
                updates.push(`completed_by = CASE WHEN $${paramCount} = true THEN $${paramCount + 1}::uuid ELSE NULL END`);
                values.push(isCompleted);
                values.push(req.user.userId);
            }

            if (updates.length === 0) {
                return res.status(400).json({ error: 'No updates provided' });
            }

            paramCount++;
            updates.push(`updated_at = CURRENT_TIMESTAMP`);
            values.push(id);

            const updateQuery = `UPDATE tasks SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING *`;
            const result = await this.pool.query(updateQuery, values);

            const updatedTask = result.rows[0];

            // Create activity record
            await this.pool.query(
                `INSERT INTO activities (organization_id, workspace_id, project_id, user_id, action_type, entity_type, entity_id, entity_title) 
                 SELECT o.id, w.id, p.id, $1, 'task_updated', 'task', $2, $3
                 FROM tasks t
                 JOIN projects p ON t.project_id = p.id
                 JOIN workspaces w ON p.workspace_id = w.id
                 JOIN organizations o ON w.organization_id = o.id
                 WHERE t.id = $4`,
                [req.user.userId, updatedTask.id, updatedTask.title, id]
            );

            // Send real-time update
            this.broadcastToProject(updatedTask.project_id, 'task_updated', updatedTask);

            res.json(updatedTask);

        } catch (error) {
            console.error('Update task error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // Dashboard methods
    async getDashboardMetrics(req, res) {
        try {
            const { organizationId } = req.query;

            let query = `
                SELECT 
                    o.id as organization_id,
                    o.name as organization_name,
                    w.id as workspace_id,
                    w.name as workspace_name,
                    p.id as project_id,
                    p.name as project_name,
                    COUNT(DISTINCT t.id) FILTER (WHERE t.is_completed = false) as active_tasks,
                    COUNT(DISTINCT t.id) FILTER (WHERE t.is_completed = true) as completed_tasks,
                    COUNT(DISTINCT t.id) as total_tasks,
                    COUNT(DISTINCT t.assignee_id) FILTER (WHERE t.assignee_id IS NOT NULL) as assigned_members,
                    COUNT(DISTINCT m.id) as total_milestones,
                    COUNT(DISTINCT m.id) FILTER (WHERE m.is_completed = true) as completed_milestones
                FROM organizations o
                JOIN organization_members om ON o.id = om.organization_id
                LEFT JOIN workspaces w ON o.id = w.organization_id
                LEFT JOIN workspace_members wm ON w.id = wm.workspace_id AND wm.user_id = $1
                LEFT JOIN projects p ON w.id = p.workspace_id
                LEFT JOIN project_members pm ON p.id = pm.project_id AND pm.user_id = $1
                LEFT JOIN tasks t ON p.id = t.project_id
                LEFT JOIN milestones m ON p.id = m.project_id
                WHERE om.user_id = $1
            `;
            const params = [req.user.userId];

            if (organizationId) {
                query += ' AND o.id = $2';
                params.push(organizationId);
            }

            query += ' GROUP BY o.id, o.name, w.id, w.name, p.id, p.name ORDER BY o.created_at DESC, w.created_at DESC, p.created_at DESC';

            const result = await this.pool.query(query, params);
            res.json(result.rows);

        } catch (error) {
            console.error('Get dashboard metrics error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    async getDashboardActivities(req, res) {
        try {
            const { limit = 20, offset = 0 } = req.query;

            const result = await this.pool.query(
                `SELECT 
                    a.*,
                    u.display_name as user_name,
                    u.avatar_url as user_avatar
                FROM activities a
                JOIN users u ON a.user_id = u.id
                WHERE a.user_id = $1 OR a.organization_id IN (
                    SELECT organization_id FROM organization_members WHERE user_id = $1
                )
                ORDER BY a.created_at DESC
                LIMIT $2 OFFSET $3`,
                [req.user.userId, parseInt(limit), parseInt(offset)]
            );

            res.json(result.rows);

        } catch (error) {
            console.error('Get dashboard activities error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }

    // WebSocket setup for real-time updates
    setupWebSocket() {
        this.wss.on('connection', (ws, req) => {
            console.log('New WebSocket connection established');
            
            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message);
                    this.handleWebSocketMessage(ws, data);
                } catch (error) {
                    console.error('WebSocket message error:', error);
                }
            });

            ws.on('close', () => {
                console.log('WebSocket connection closed');
            });

            // Send welcome message
            ws.send(JSON.stringify({ type: 'connected', message: 'Connected to LimeAura real-time updates' }));
        });
    }

    handleWebSocketMessage(ws, data) {
        switch (data.type) {
            case 'subscribe_project':
                this.subscribeToProject(ws, data.projectId);
                break;
            case 'unsubscribe_project':
                this.unsubscribeFromProject(ws, data.projectId);
                break;
            default:
                console.log('Unknown WebSocket message type:', data.type);
        }
    }

    subscribeToProject(ws, projectId) {
        if (!ws.subscriptions) {
            ws.subscriptions = new Set();
        }
        ws.subscriptions.add(`project:${projectId}`);
        ws.send(JSON.stringify({ type: 'subscribed', projectId }));
    }

    unsubscribeFromProject(ws, projectId) {
        if (ws.subscriptions) {
            ws.subscriptions.delete(`project:${projectId}`);
            ws.send(JSON.stringify({ type: 'unsubscribed', projectId }));
        }
    }

    broadcastToProject(projectId, eventType, data) {
        const message = JSON.stringify({
            type: eventType,
            projectId,
            data,
            timestamp: new Date().toISOString()
        });

        this.wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN && 
                client.subscriptions && 
                client.subscriptions.has(`project:${projectId}`)) {
                client.send(message);
            }
        });
    }

    // Error handling
    setupErrorHandling() {
        this.app.use((err, req, res, next) => {
            console.error('Unhandled error:', err);
            res.status(500).json({ 
                error: 'Internal server error',
                message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
            });
        });
    }

    // Start server
    start(port = process.env.PORT || 3001) {
        this.server.listen(port, () => {
            console.log(`LimeAura API server running on port ${port}`);
            console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
            console.log(`Database: ${process.env.DATABASE_URL ? 'Connected' : 'Not configured'}`);
        });
    }

    // Graceful shutdown
    async shutdown() {
        console.log('Shutting down server...');
        
        this.server.close(() => {
            console.log('HTTP server closed');
        });

        this.wss.close(() => {
            console.log('WebSocket server closed');
        });

        await this.pool.end();
        console.log('Database connections closed');
        
        process.exit(0);
    }
}

// Create and start server
const server = new LimeAuraServer();
server.start();

// Handle graceful shutdown
process.on('SIGTERM', () => server.shutdown());
process.on('SIGINT', () => server.shutdown());

module.exports = server;