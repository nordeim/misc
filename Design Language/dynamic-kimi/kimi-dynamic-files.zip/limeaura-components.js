/**
 * LimeAura Component Library
 * Implementation of the LimeAura Design System components
 * Version: 2.0.0
 */

class LimeAuraComponent {
  constructor(element) {
    this.element = element;
    this.init();
  }

  init() {
    // Base initialization for all components
    this.element.setAttribute('data-component', this.constructor.name.toLowerCase());
  }

  addEventListeners(events) {
    Object.entries(events).forEach(([event, handler]) => {
      this.element.addEventListener(event, handler);
    });
  }

  setStyles(styles) {
    Object.assign(this.element.style, styles);
  }
}

/**
 * Card Component
 * Base card component with white surface, rounded corners, and soft shadow
 */
class Card extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      variant: 'default',
      padding: 'xxl',
      animated: true,
      ...options
    };
    this.render();
  }

  render() {
    const styles = {
      backgroundColor: 'var(--color-surface-primary)',
      borderRadius: 'var(--radius-card-lg)',
      boxShadow: 'var(--shadow-card)',
      padding: `var(--spacing-${this.options.padding})`,
      transition: 'all var(--motion-duration-normal) var(--motion-easing-standard)',
      position: 'relative',
      willChange: 'transform, box-shadow',
      opacity: this.options.animated ? '0' : '1',
      transform: this.options.animated ? 'translateY(20px)' : 'translateY(0)',
      animation: this.options.animated ? 
        'fadeInUp 0.6s var(--motion-easing-gentle) forwards' : 'none',
      animationDelay: this.options.delay || 'calc(var(--animation-delay-child1, 0.1s) + 0.2s)'
    };

    this.setStyles(styles);
    this.addEventListeners({
      mouseenter: this.handleHover.bind(this),
      mouseleave: this.handleLeave.bind(this),
      mousedown: this.handleActive.bind(this),
      mouseup: this.handleLeave.bind(this)
    });
  }

  handleHover() {
    this.element.style.boxShadow = 'var(--shadow-floating)';
    this.element.style.transform = 'translateY(-4px) rotateX(1deg) rotateY(0.5deg)';
  }

  handleLeave() {
    this.element.style.boxShadow = 'var(--shadow-card)';
    this.element.style.transform = 'translateY(0) rotateX(0deg) rotateY(0deg)';
  }

  handleActive() {
    this.element.style.transform = 'translateY(-2px) scale(0.995)';
  }
}

/**
 * Hero Card Component
 * Hero card with circular cutout in top-right corner for visual interest
 */
class HeroCard extends Card {
  constructor(element, options = {}) {
    super(element, { ...options, variant: 'hero' });
    this.renderHero();
  }

  renderHero() {
    // Apply hero-specific styles
    Object.assign(this.element.style, {
      gridColumn: 'span 2',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      overflow: 'hidden',
      position: 'relative',
      minHeight: '280px'
    });

    // Create circular cutout pseudo-element
    const style = document.createElement('style');
    style.textContent = `
      [data-component="hero"]::before {
        content: '';
        position: absolute;
        top: -30px;
        right: -30px;
        width: 140px;
        height: 140px;
        background-color: var(--color-background-main);
        border-radius: 50%;
        z-index: 0;
        opacity: 0;
        transform: scale(0.5) translate(30px, -30px);
        animation: morphCutout 0.8s var(--motion-easing-elastic) 0.6s forwards;
      }
    `;
    document.head.appendChild(style);
  }
}

/**
 * Avatar Component
 * Circular avatar component used for user profiles and team members
 */
class Avatar extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      size: 'lg',
      name: '',
      src: '',
      variant: 'default',
      ...options
    };
    this.render();
  }

  render() {
    const size = this.options.size;
    const sizeValue = size === 'sm' ? '32px' : size === 'md' ? '36px' : '64px';
    const fontSize = size === 'sm' ? '12px' : size === 'md' ? '12px' : '20px';
    const borderWidth = size === 'sm' ? '2px' : '3px';

    const styles = {
      width: sizeValue,
      height: sizeValue,
      borderRadius: 'var(--radius-pill)',
      background: 'linear-gradient(135deg, var(--color-accent-primary), #5A20E0)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--color-common-white)',
      fontWeight: 'var(--font-weight-semibold)',
      fontSize: fontSize,
      border: `${borderWidth} solid var(--color-surface-primary)`,
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
      transition: 'all var(--motion-duration-normal) var(--motion-easing-standard)',
      willChange: 'transform, box-shadow',
      cursor: 'pointer'
    };

    this.setStyles(styles);

    // Set content
    if (this.options.src) {
      this.element.innerHTML = `<img src="${this.options.src}" alt="${this.options.name}" style="width: 100%; height: 100%; border-radius: inherit; object-fit: cover;">`;
    } else if (this.options.name) {
      const initials = this.options.name.split(' ').map(n => n[0]).join('').toUpperCase();
      this.element.textContent = initials;
    }

    this.addEventListeners({
      mouseenter: this.handleHover.bind(this),
      mouseleave: this.handleLeave.bind(this)
    });
  }

  handleHover() {
    this.element.style.transform = 'scale(1.1) translateY(-3px)';
    this.element.style.boxShadow = 'var(--shadow-avatar-hover)';
    this.element.style.zIndex = '10';
  }

  handleLeave() {
    this.element.style.transform = 'scale(1) translateY(0)';
    this.element.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
    this.element.style.zIndex = 'auto';
  }
}

/**
 * Button Component
 * Interactive button component with multiple variants
 */
class Button extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      variant: 'primary',
      size: 'default',
      disabled: false,
      loading: false,
      ...options
    };
    this.render();
  }

  render() {
    const baseStyles = {
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-family-primary)',
      fontWeight: 'var(--font-weight-medium)',
      fontSize: 'var(--font-size-body)',
      padding: '9px 18px',
      border: 'none',
      cursor: this.options.disabled ? 'not-allowed' : 'pointer',
      transition: 'all var(--motion-duration-normal) var(--motion-easing-standard)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '36px',
      willChange: 'transform, box-shadow',
      position: 'relative',
      overflow: 'hidden'
    };

    const variantStyles = this.getVariantStyles();
    const styles = { ...baseStyles, ...variantStyles };

    if (this.options.disabled) {
      styles.opacity = 'var(--state-disabled-opacity)';
    }

    this.setStyles(styles);
    this.addEventListeners({
      mouseenter: this.handleHover.bind(this),
      mouseleave: this.handleLeave.bind(this),
      mousedown: this.handleActive.bind(this),
      mouseup: this.handleLeave.bind(this)
    });
  }

  getVariantStyles() {
    switch (this.options.variant) {
      case 'primary':
        return {
          backgroundColor: 'var(--color-accent-primary)',
          color: 'var(--color-common-white)',
          boxShadow: 'var(--shadow-button-primary)'
        };
      case 'success':
        return {
          backgroundColor: 'var(--color-semantic-success)',
          color: 'var(--color-common-white)',
          boxShadow: '0 6px 15px rgba(16, 185, 129, 0.25)'
        };
      case 'secondary':
        return {
          backgroundColor: 'var(--color-common-white)',
          color: 'var(--color-text-primary)',
          border: '1px solid var(--color-border-subtle)'
        };
      case 'ghost':
        return {
          backgroundColor: 'transparent',
          color: 'var(--color-text-primary)',
          padding: '6px 12px',
          fontSize: 'var(--font-size-body)'
        };
      default:
        return {};
    }
  }

  handleHover() {
    if (this.options.disabled) return;
    
    this.element.style.transform = 'translateY(-2px)';
    
    if (this.options.variant === 'primary') {
      this.element.style.backgroundColor = '#6B2FFF';
      this.element.style.boxShadow = '0 10px 25px 0 rgba(123, 62, 255, 0.4)';
    } else if (this.options.variant === 'secondary') {
      this.element.style.backgroundColor = 'var(--color-surface-soft)';
      this.element.style.borderColor = '#d1d5db';
    } else if (this.options.variant === 'ghost') {
      this.element.style.backgroundColor = 'var(--color-surface-soft)';
    }
  }

  handleLeave() {
    if (this.options.disabled) return;
    
    this.element.style.transform = 'translateY(0)';
    
    if (this.options.variant === 'primary') {
      this.element.style.backgroundColor = 'var(--color-accent-primary)';
      this.element.style.boxShadow = 'var(--shadow-button-primary)';
    } else if (this.options.variant === 'secondary') {
      this.element.style.backgroundColor = 'var(--color-common-white)';
      this.element.style.borderColor = 'var(--color-border-subtle)';
    } else if (this.options.variant === 'ghost') {
      this.element.style.backgroundColor = 'transparent';
    }
  }

  handleActive() {
    if (this.options.disabled) return;
    this.element.style.transform = 'translateY(0) scale(0.98)';
  }
}

/**
 * ProgressCircular Component
 * Circular progress indicator used for project completion and milestone tracking
 */
class ProgressCircular extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      percentage: 0,
      size: 'default',
      animated: true,
      label: '',
      ...options
    };
    this.render();
  }

  render() {
    const size = this.options.size === 'small' ? '32px' : '40px';
    const radius = this.options.size === 'small' ? '13' : '17';
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (this.options.percentage / 100) * circumference;

    const styles = {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 'var(--spacing-md)',
      fontSize: 'var(--font-size-label)',
      fontWeight: 'var(--font-weight-medium)',
      color: 'var(--color-text-secondary)'
    };

    this.setStyles(styles);

    this.element.innerHTML = `
      <svg width="${size}" height="${size}" style="transform: rotate(-90deg);">
        <circle
          cx="50%"
          cy="50%"
          r="${radius}"
          fill="none"
          stroke="var(--color-accent-primary-soft)"
          stroke-width="6"
        />
        <circle
          cx="50%"
          cy="50%"
          r="${radius}"
          fill="none"
          stroke="var(--color-accent-primary)"
          stroke-width="6"
          stroke-linecap="round"
          stroke-dasharray="${circumference}"
          stroke-dashoffset="${this.options.animated ? circumference : offset}"
          style="
            transition: stroke-dashoffset var(--motion-duration-slow) var(--motion-easing-standard);
            ${this.options.animated ? `animation: progressReveal 1s var(--motion-easing-standard) ${this.options.delay || '0.5s'} forwards` : ''}
          "
        />
        <text
          x="50%"
          y="50%"
          text-anchor="middle"
          dominant-baseline="middle"
          style="
            transform: rotate(90deg);
            font-size: 14px;
            font-weight: var(--font-weight-semibold);
            color: var(--color-accent-primary);
            font-family: var(--font-family-primary);
          "
        >
          ${this.options.percentage}%
        </text>
      </svg>
      ${this.options.label ? `<span>${this.options.label}</span>` : ''}
    `;
  }
}

/**
 * ToggleSwitch Component
 * iOS-style pill toggle switch for enabling/disabling features
 */
class ToggleSwitch extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      checked: false,
      disabled: false,
      onChange: null,
      ...options
    };
    this.render();
  }

  render() {
    const id = `toggle-${Math.random().toString(36).substr(2, 9)}`;
    
    this.element.innerHTML = `
      <input
        type="checkbox"
        id="${id}"
        ${this.options.checked ? 'checked' : ''}
        ${this.options.disabled ? 'disabled' : ''}
        style="opacity: 0; width: 0; height: 0;"
      />
      <label
        for="${id}"
        style="
          position: relative;
          display: inline-block;
          width: var(--size-control-toggle-width);
          height: var(--size-control-toggle-height);
          cursor: ${this.options.disabled ? 'not-allowed' : 'pointer'};
        "
      >
        <span
          style="
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #E5E7EB;
            transition: all var(--motion-duration-normal) var(--motion-easing-standard);
            border-radius: var(--radius-pill);
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding: 2px;
          "
        >
          <span
            style="
              height: var(--size-control-toggle-handle);
              width: var(--size-control-toggle-handle);
              background-color: var(--color-common-white);
              transition: all var(--motion-duration-normal) var(--motion-easing-standard);
              border-radius: 50%;
              box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            "
          ></span>
        </span>
      </label>
    `;

    const input = this.element.querySelector('input');
    const slider = this.element.querySelector('label span:first-child');
    const handle = this.element.querySelector('label span:last-child');

    const updateState = () => {
      if (input.checked) {
        slider.style.backgroundColor = 'var(--color-accent-primary)';
        slider.style.justifyContent = 'flex-end';
      } else {
        slider.style.backgroundColor = '#E5E7EB';
        slider.style.justifyContent = 'flex-start';
      }
    };

    input.addEventListener('change', () => {
      updateState();
      if (this.options.onChange) {
        this.options.onChange(input.checked);
      }
    });

    // Initial state
    updateState();

    // Focus state
    input.addEventListener('focus', () => {
      slider.style.boxShadow = '0 0 0 3px var(--color-accent-primary-soft)';
    });

    input.addEventListener('blur', () => {
      slider.style.boxShadow = 'none';
    });

    // Active state
    input.addEventListener('mousedown', () => {
      handle.style.width = '22px';
    });

    input.addEventListener('mouseup', () => {
      handle.style.width = 'var(--size-control-toggle-handle)';
    });
  }
}

/**
 * Tag Component
 * Soft pill labels used for skills, topics, and filters
 */
class Tag extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      text: '',
      clickable: true,
      ...options
    };
    this.render();
  }

  render() {
    const styles = {
      backgroundColor: 'var(--color-surface-soft)',
      color: 'var(--color-text-primary)',
      borderRadius: 'var(--radius-pill)',
      padding: 'var(--spacing-xs) var(--spacing-lg)',
      fontSize: 'var(--font-size-label)',
      fontWeight: 'var(--font-weight-medium)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--motion-duration-normal) var(--motion-easing-standard)',
      cursor: this.options.clickable ? 'pointer' : 'default',
      willChange: 'transform, background-color',
      border: 'none',
      outline: 'none'
    };

    this.setStyles(styles);
    this.element.textContent = this.options.text;

    if (this.options.clickable) {
      this.addEventListeners({
        mouseenter: this.handleHover.bind(this),
        mouseleave: this.handleLeave.bind(this)
      });
    }
  }

  handleHover() {
    this.element.style.transform = 'translateY(-2px) scale(1.05)';
    this.element.style.backgroundColor = 'var(--color-accent-primary-soft)';
    this.element.style.color = 'var(--color-accent-primary)';
  }

  handleLeave() {
    this.element.style.transform = 'translateY(0) scale(1)';
    this.element.style.backgroundColor = 'var(--color-surface-soft)';
    this.element.style.color = 'var(--color-text-primary)';
  }
}

/**
 * Badge Component
 * Small numeric or status indicators for notifications and counts
 */
class Badge extends LimeAuraComponent {
  constructor(element, options = {}) {
    super(element);
    this.options = {
      variant: 'numeric',
      count: 0,
      status: 'default',
      ...options
    };
    this.render();
  }

  render() {
    if (this.options.variant === 'numeric') {
      const styles = {
        minWidth: '20px',
        height: '20px',
        borderRadius: '50%',
        backgroundColor: 'var(--color-accent-primary)',
        color: 'var(--color-common-white)',
        fontSize: '11px',
        fontWeight: '700',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2px',
        fontFamily: 'var(--font-family-primary)',
        position: 'relative',
        animation: 'elasticBounce 0.4s var(--motion-easing-bounce)',
        border: 'none'
      };

      this.setStyles(styles);
      this.element.textContent = Math.min(this.options.count, 99);
    } else if (this.options.variant === 'statusPill') {
      const styles = {
        backgroundColor: 'var(--color-accent-primary-soft)',
        color: 'var(--color-accent-primary)',
        borderRadius: 'var(--radius-pill)',
        padding: '4px 12px',
        fontSize: 'var(--font-size-label)',
        fontWeight: '600',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'all var(--motion-duration-normal) var(--motion-easing-standard)',
        border: 'none'
      };

      if (this.options.status === 'success') {
        styles.backgroundColor = '#D1FAE5';
        styles.color = '#065F46';
      } else if (this.options.status === 'warning') {
        styles.backgroundColor = '#FEF3C7';
        styles.color = '#92400E';
      }

      this.setStyles(styles);
      this.element.textContent = this.options.text || '';

      this.addEventListeners({
        mouseenter: () => {
          this.element.style.transform = 'scale(1.05)';
        },
        mouseleave: () => {
          this.element.style.transform = 'scale(1)';
        }
      });
    }
  }
}

/**
 * Component Factory
 * Utility to create and initialize components
 */
class LimeAuraFactory {
  static createCard(element, options) {
    return new Card(element, options);
  }

  static createHeroCard(element, options) {
    return new HeroCard(element, options);
  }

  static createAvatar(element, options) {
    return new Avatar(element, options);
  }

  static createButton(element, options) {
    return new Button(element, options);
  }

  static createProgressCircular(element, options) {
    return new ProgressCircular(element, options);
  }

  static createToggleSwitch(element, options) {
    return new ToggleSwitch(element, options);
  }

  static createTag(element, options) {
    return new Tag(element, options);
  }

  static createBadge(element, options) {
    return new Badge(element, options);
  }

  static initAll() {
    // Initialize all components with data attributes
    document.querySelectorAll('[data-limeaura-card]').forEach(el => {
      new Card(el, JSON.parse(el.dataset.limeauraCard || '{}'));
    });

    document.querySelectorAll('[data-limeaura-hero-card]').forEach(el => {
      new HeroCard(el, JSON.parse(el.dataset.limeauraHeroCard || '{}'));
    });

    document.querySelectorAll('[data-limeaura-avatar]').forEach(el => {
      new Avatar(el, JSON.parse(el.dataset.limeauraAvatar || '{}'));
    });

    document.querySelectorAll('[data-limeaura-button]').forEach(el => {
      new Button(el, JSON.parse(el.dataset.limeauraButton || '{}'));
    });

    document.querySelectorAll('[data-limeaura-progress]').forEach(el => {
      new ProgressCircular(el, JSON.parse(el.dataset.limeauraProgress || '{}'));
    });

    document.querySelectorAll('[data-limeaura-toggle]').forEach(el => {
      new ToggleSwitch(el, JSON.parse(el.dataset.limeauraToggle || '{}'));
    });

    document.querySelectorAll('[data-limeaura-tag]').forEach(el => {
      new Tag(el, JSON.parse(el.dataset.limeauraTag || '{}'));
    });

    document.querySelectorAll('[data-limeaura-badge]').forEach(el => {
      new Badge(el, JSON.parse(el.dataset.limeauraBadge || '{}'));
    });
  }
}

// Auto-initialize components when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  LimeAuraFactory.initAll();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    LimeAuraComponent,
    Card,
    HeroCard,
    Avatar,
    Button,
    ProgressCircular,
    ToggleSwitch,
    Tag,
    Badge,
    LimeAuraFactory
  };
}