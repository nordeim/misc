/**
 * LimeAura Dynamic Dashboard
 * Enhanced dashboard with backend API integration
 * Version: 3.0.0 - Dynamic Application Frontend
 */

class LimeAuraDynamicDashboard {
    constructor() {
        this.data = {
            user: null,
            organizations: [],
            workspaces: [],
            projects: [],
            tasks: [],
            milestones: [],
            activities: [],
            calendarEvents: [],
            integrations: [],
            notifications: []
        };
        
        this.state = {
            selectedOrganization: null,
            selectedWorkspace: null,
            selectedProject: null,
            loading: false,
            error: null,
            realTimeEnabled: true
        };
        
        this.api = window.limeauraAPI || new LimeAuraAPI();
        this.init();
    }

    async init() {
        try {
            console.log('🚀 Initializing LimeAura Dynamic Dashboard...');
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Load initial data
            await this.loadUserData();
            await this.loadDashboardData();
            
            // Setup real-time updates
            this.setupRealTimeUpdates();
            
            // Render the dashboard
            this.render();
            
            console.log('✅ Dashboard initialized successfully');
            
        } catch (error) {
            console.error('❌ Dashboard initialization failed:', error);
            this.showError('Failed to initialize dashboard', error);
        }
    }

    setupEventListeners() {
        // Real-time event listeners
        this.api.on('task_created', (event) => {
            this.handleTaskCreated(event.detail.data);
        });

        this.api.on('task_updated', (event) => {
            this.handleTaskUpdated(event.detail.data);
        });

        this.api.on('task_deleted', (event) => {
            this.handleTaskDeleted(event.detail.data);
        });

        // Window event listeners
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });

        // Visibility change for WebSocket management
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.pauseRealTimeUpdates();
            } else {
                this.resumeRealTimeUpdates();
            }
        });
    }

    async loadUserData() {
        try {
            this.state.loading = true;
            this.data.user = await this.api.getCurrentUser();
            
            // Load user's organizations
            this.data.organizations = await this.api.getOrganizations();
            
            if (this.data.organizations.length > 0) {
                this.state.selectedOrganization = this.data.organizations[0];
            }
            
            console.log('✅ User data loaded:', this.data.user.displayName);
            
        } catch (error) {
            console.error('❌ Failed to load user data:', error);
            throw error;
        } finally {
            this.state.loading = false;
        }
    }

    async loadDashboardData() {
        try {
            this.state.loading = true;
            
            // Load workspaces
            this.data.workspaces = await this.api.getWorkspaces(
                this.state.selectedOrganization?.id
            );
            
            if (this.data.workspaces.length > 0) {
                this.state.selectedWorkspace = this.data.workspaces[0];
            }
            
            // Load projects
            this.data.projects = await this.api.getProjects(
                this.state.selectedWorkspace?.id
            );
            
            if (this.data.projects.length > 0) {
                this.state.selectedProject = this.data.projects[0];
            }
            
            // Load tasks
            this.data.tasks = await this.api.getTasks({
                projectId: this.state.selectedProject?.id
            });
            
            // Load milestones
            if (this.state.selectedProject) {
                this.data.milestones = await this.api.getMilestones(
                    this.state.selectedProject.id
                );
            }
            
            // Load activities
            this.data.activities = await this.api.getDashboardActivities();
            
            // Load integrations
            this.data.integrations = await this.api.getIntegrations();
            
            // Load notifications
            this.data.notifications = await this.api.getNotifications();
            
            // Load calendar events if workspace is selected
            if (this.state.selectedWorkspace) {
                this.data.calendarEvents = await this.api.getCalendarEvents(
                    this.state.selectedWorkspace.id
                );
            }
            
            console.log('✅ Dashboard data loaded:', {
                workspaces: this.data.workspaces.length,
                projects: this.data.projects.length,
                tasks: this.data.tasks.length,
                activities: this.data.activities.length
            });
            
        } catch (error) {
            console.error('❌ Failed to load dashboard data:', error);
            throw error;
        } finally {
            this.state.loading = false;
        }
    }

    setupRealTimeUpdates() {
        if (!this.state.realTimeEnabled) return;
        
        // Subscribe to project updates
        if (this.state.selectedProject) {
            this.api.subscribeToProject(this.state.selectedProject.id);
        }
    }

    pauseRealTimeUpdates() {
        console.log('⏸️ Pausing real-time updates');
        this.state.realTimeEnabled = false;
    }

    resumeRealTimeUpdates() {
        console.log('▶️ Resuming real-time updates');
        this.state.realTimeEnabled = true;
        this.setupRealTimeUpdates();
    }

    // Real-time event handlers
    handleTaskCreated(task) {
        console.log('📥 Task created via real-time:', task.title);
        this.data.tasks.unshift(task);
        this.updateTaskDisplay();
        this.showNotification(`New task created: ${task.title}`, 'success');
    }

    handleTaskUpdated(task) {
        console.log('📝 Task updated via real-time:', task.title);
        const index = this.data.tasks.findIndex(t => t.id === task.id);
        if (index !== -1) {
            this.data.tasks[index] = task;
            this.updateTaskDisplay();
        }
    }

    handleTaskDeleted(task) {
        console.log('🗑️ Task deleted via real-time:', task.title);
        this.data.tasks = this.data.tasks.filter(t => t.id !== task.id);
        this.updateTaskDisplay();
        this.showNotification(`Task deleted: ${task.title}`, 'warning');
    }

    // UI Update methods
    updateTaskDisplay() {
        const taskElements = document.querySelectorAll('[data-task-id]');
        taskElements.forEach(element => {
            const taskId = element.dataset.taskId;
            const task = this.data.tasks.find(t => t.id === taskId);
            if (task) {
                this.updateTaskElement(element, task);
            }
        });
    }

    updateTaskElement(element, task) {
        // Update task status
        const statusElement = element.querySelector('.task-status');
        if (statusElement) {
            statusElement.textContent = task.status_name || 'To Do';
            statusElement.style.backgroundColor = task.status_color || '#6B7280';
        }

        // Update assignee
        const assigneeElement = element.querySelector('.task-assignee');
        if (assigneeElement && task.assignee_name) {
            assigneeElement.textContent = task.assignee_name;
            if (task.assignee_avatar) {
                const avatarImg = assigneeElement.querySelector('img');
                if (avatarImg) {
                    avatarImg.src = task.assignee_avatar;
                }
            }
        }

        // Update progress
        const progressElement = element.querySelector('.task-progress');
        if (progressElement && task.actual_hours && task.estimated_hours) {
            const progress = (task.actual_hours / task.estimated_hours) * 100;
            progressElement.style.width = `${Math.min(progress, 100)}%`;
        }
    }

    // Data transformation methods
    transformDashboardData() {
        const metrics = this.calculateMetrics();
        const recentActivities = this.getRecentActivities();
        const upcomingDeadlines = this.getUpcomingDeadlines();
        
        return {
            metrics,
            recentActivities,
            upcomingDeadlines,
            tasks: this.data.tasks.map(task => this.api.transformTask(task)),
            milestones: this.data.milestones.map(milestone => this.api.transformMilestone(milestone)),
            projects: this.data.projects.map(project => this.api.transformProject(project))
        };
    }

    calculateMetrics() {
        const totalTasks = this.data.tasks.length;
        const completedTasks = this.data.tasks.filter(t => t.is_completed).length;
        const activeTasks = totalTasks - completedTasks;
        const overdueTasks = this.data.tasks.filter(t => 
            !t.is_completed && t.due_date && new Date(t.due_date) < new Date()
        ).length;
        
        const totalMilestones = this.data.milestones.length;
        const completedMilestones = this.data.milestones.filter(m => m.is_completed).length;
        
        const completedMilestonesCount = this.data.milestones.filter(m => m.is_completed).length;
        const totalProjects = this.data.projects.length;
        const activeProjects = this.data.projects.filter(p => p.status === 'active').length;
        
        return {
            totalTasks,
            activeTasks,
            completedTasks,
            overdueTasks,
            completionRate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
            totalMilestones,
            completedMilestones: completedMilestonesCount,
            milestoneProgress: totalMilestones > 0 ? Math.round((completedMilestonesCount / totalMilestones) * 100) : 0,
            totalProjects,
            activeProjects
        };
    }

    getRecentActivities() {
        return this.data.activities.slice(0, 10).map(activity => ({
            id: activity.id,
            user: {
                name: activity.user_name,
                avatar: activity.user_avatar
            },
            action: activity.action_type,
            target: activity.entity_title,
            timestamp: activity.created_at,
            description: activity.description
        }));
    }

    getUpcomingDeadlines() {
        const now = new Date();
        const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        
        return this.data.tasks
            .filter(task => 
                task.due_date && 
                !task.is_completed &&
                new Date(task.due_date) <= nextWeek
            )
            .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
            .slice(0, 5)
            .map(task => ({
                id: task.id,
                title: task.title,
                dueDate: task.due_date,
                assignee: task.assignee_name,
                project: task.project_name,
                priority: task.priority
            }));
    }

    // Rendering methods
    render() {
        const data = this.transformDashboardData();
        this.updateHeroCard(data.metrics);
        this.updateMilestonesList(data.milestones);
        this.updateActivityFeed(data.recentActivities);
        this.updateTasksList(data.tasks);
        this.updateCalendar(data.calendarEvents);
        this.updateIntegrations(data.integrations);
        this.updateUserProfile();
    }

    updateHeroCard(metrics) {
        const heroCard = document.querySelector('.hero-card');
        if (!heroCard) return;

        // Update hero stats
        const stats = heroCard.querySelectorAll('.stat-value');
        if (stats.length >= 3) {
            stats[0].textContent = metrics.activeTasks;
            stats[1].textContent = this.users.length;
            stats[2].textContent = '3'; // Weeks left (mock data)
        }

        // Update progress circle
        const progressElement = heroCard.querySelector('[data-limeaura-progress]');
        if (progressElement) {
            progressElement.dataset.limeauraProgress = JSON.stringify({
                percentage: metrics.completionRate,
                size: 'default',
                animated: true,
                label: 'Overall Progress'
            });
        }
    }

    updateMilestonesList(milestones) {
        const milestonesList = document.querySelector('.milestones-list');
        if (!milestonesList) return;

        // Clear existing milestones
        milestonesList.innerHTML = '';

        // Add milestone items
        milestones.forEach(milestone => {
            const milestoneElement = this.createMilestoneElement(milestone);
            milestonesList.appendChild(milestoneElement);
        });
    }

    createMilestoneElement(milestone) {
        const element = document.createElement('div');
        element.className = 'milestone-item';
        element.innerHTML = `
            <div class="milestone-info">
                <h4>${milestone.name}</h4>
                <p>${milestone.description}</p>
                <span class="due-date">Due: ${new Date(milestone.dueDate).toLocaleDateString()}</span>
            </div>
            <div class="milestone-progress">
                <div class="progress-mini" data-limeaura-progress='${JSON.stringify({
                    percentage: milestone.progress,
                    size: 'small',
                    animated: true
                })}'></div>
                <div class="milestone-assignees">
                    <div class="avatar-group">
                        ${this.users.slice(0, 3).map(user => 
                            `<div class="avatar" data-name="${user.displayName}" data-size="sm"></div>`
                        ).join('')}
                    </div>
                </div>
            </div>
        `;
        return element;
    }

    updateActivityFeed(activities) {
        const activityList = document.querySelector('.activity-list');
        if (!activityList) return;

        // Clear existing activities
        activityList.innerHTML = '';

        // Add activity items
        activities.forEach(activity => {
            const activityElement = this.createActivityElement(activity);
            activityList.appendChild(activityElement);
        });
    }

    createActivityElement(activity) {
        const element = document.createElement('div');
        element.className = 'activity-item';
        element.innerHTML = `
            <div class="avatar" data-name="${activity.user.name}" data-size="md"></div>
            <div class="activity-content">
                <p><strong>${activity.user.name}</strong> ${activity.action} "${activity.target}"</p>
                <span class="activity-time">${this.formatTimeAgo(activity.timestamp)}</span>
            </div>
        `;
        return element;
    }

    updateTasksList(tasks) {
        // Update task counts and progress
        const totalTasksElement = document.querySelector('.total-tasks');
        const completedTasksElement = document.querySelector('.completed-tasks');
        
        if (totalTasksElement) totalTasksElement.textContent = tasks.length;
        if (completedTasksElement) {
            const completed = tasks.filter(t => t.isCompleted).length;
            completedTasksElement.textContent = completed;
        }
    }

    updateCalendar(events) {
        // Update calendar with events
        const calendarDays = document.querySelectorAll('.day');
        calendarDays.forEach(day => {
            const dayNumber = parseInt(day.textContent);
            const hasEvent = events.some(event => {
                const eventDate = new Date(event.startDate);
                return eventDate.getDate() === dayNumber;
            });
            
            if (hasEvent) {
                day.classList.add('event');
            }
        });
    }

    updateIntegrations(integrations) {
        // Update integration toggles
        const integrationRows = document.querySelectorAll('.integration-row');
        integrationRows.forEach(row => {
            const integrationName = row.querySelector('h4').textContent.toLowerCase();
            const integration = integrations.find(i => 
                i.serviceType.toLowerCase().includes(integrationName) ||
                i.name.toLowerCase().includes(integrationName)
            );
            
            if (integration) {
                const toggle = row.querySelector('.toggle-switch');
                if (toggle) {
                    toggle.dataset.limeauraToggle = JSON.stringify({
                        checked: integration.isEnabled
                    });
                }
            }
        });
    }

    updateUserProfile() {
        const userNameElement = document.querySelector('.user-name');
        const userAvatarElement = document.querySelector('.user-profile .avatar');
        
        if (userNameElement && this.data.user) {
            userNameElement.textContent = this.data.user.displayName;
        }
        
        if (userAvatarElement && this.data.user) {
            userAvatarElement.dataset.name = this.data.user.displayName;
            if (this.data.user.avatarUrl) {
                userAvatarElement.dataset.src = this.data.user.avatarUrl;
            }
        }
    }

    // Utility methods
    formatTimeAgo(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diffInHours = Math.floor((now - time) / (1000 * 60 * 60));
        
        if (diffInHours < 1) {
            const diffInMinutes = Math.floor((now - time) / (1000 * 60));
            return `${diffInMinutes} minutes ago`;
        } else if (diffInHours < 24) {
            return `${diffInHours} hours ago`;
        } else {
            const diffInDays = Math.floor(diffInHours / 24);
            return `${diffInDays} days ago`;
        }
    }

    showNotification(message, type = 'info') {
        // Use the existing notification system
        if (window.dashboard && window.dashboard.showNotification) {
            window.dashboard.showNotification(message, type);
        } else {
            console.log(`📢 ${type.toUpperCase()}: ${message}`);
        }
    }

    showError(title, error) {
        console.error(`❌ ${title}:`, error);
        this.showNotification(`${title}: ${error.message}`, 'error');
    }

    // Data management methods
    async refreshData() {
        try {
            this.state.loading = true;
            await this.loadDashboardData();
            this.render();
            this.showNotification('Dashboard refreshed', 'success');
        } catch (error) {
            this.showError('Failed to refresh data', error);
        } finally {
            this.state.loading = false;
        }
    }

    async selectOrganization(organizationId) {
        const organization = this.data.organizations.find(o => o.id === organizationId);
        if (organization) {
            this.state.selectedOrganization = organization;
            await this.loadDashboardData();
            this.render();
        }
    }

    async selectWorkspace(workspaceId) {
        const workspace = this.data.workspaces.find(w => w.id === workspaceId);
        if (workspace) {
            this.state.selectedWorkspace = workspace;
            await this.loadDashboardData();
            this.render();
        }
    }

    async selectProject(projectId) {
        const project = this.data.projects.find(p => p.id === projectId);
        if (project) {
            this.state.selectedProject = project;
            
            // Update WebSocket subscription
            if (this.state.selectedProject) {
                this.api.unsubscribeFromProject(this.state.selectedProject.id);
            }
            this.api.subscribeToProject(projectId);
            
            await this.loadDashboardData();
            this.render();
        }
    }

    // Cleanup method
    cleanup() {
        if (this.ws) {
            this.ws.close();
        }
        this.api.clearCache();
    }

    // Public API for other components
    getData() {
        return {
            ...this.data,
            state: this.state
        };
    }

    getAPI() {
        return this.api;
    }
}

// Initialize the dynamic dashboard when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.dynamicDashboard = new LimeAuraDynamicDashboard();
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LimeAuraDynamicDashboard;
}