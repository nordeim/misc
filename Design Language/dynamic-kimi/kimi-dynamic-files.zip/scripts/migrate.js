#!/usr/bin/env node

/**
 * Database Migration Script
 * Sets up the LimeAura database schema
 */

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config();

class DatabaseMigrator {
    constructor() {
        this.pool = new Pool({
            connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/limeaura',
            ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
        });
    }

    async migrate() {
        try {
            console.log('🚀 Starting database migration...');
            
            // Read and execute the schema file
            const schemaPath = path.join(__dirname, '..', 'database-schema.sql');
            const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
            
            console.log('📖 Reading schema file...');
            
            // Split the SQL into individual statements
            const statements = this.splitSQLStatements(schemaSQL);
            
            console.log(`🔧 Executing ${statements.length} SQL statements...`);
            
            // Execute each statement
            for (let i = 0; i < statements.length; i++) {
                const statement = statements[i].trim();
                if (statement && !statement.startsWith('--') && !statement.startsWith('/*')) {
                    try {
                        await this.pool.query(statement);
                        if (i % 10 === 0) {
                            console.log(`✅ Executed ${i + 1}/${statements.length} statements...`);
                        }
                    } catch (error) {
                        console.error(`❌ Error executing statement ${i + 1}:`, error.message);
                        console.error('Statement:', statement.substring(0, 200) + '...');
                        throw error;
                    }
                }
            }
            
            console.log('✅ Database migration completed successfully!');
            console.log('🎉 LimeAura database is ready for use!');
            
        } catch (error) {
            console.error('❌ Migration failed:', error.message);
            process.exit(1);
        } finally {
            await this.pool.end();
        }
    }

    splitSQLStatements(sql) {
        const statements = [];
        let currentStatement = '';
        let inString = false;
        let stringChar = null;
        let inComment = false;
        let commentChar = null;
        
        for (let i = 0; i < sql.length; i++) {
            const char = sql[i];
            const nextChar = sql[i + 1];
            
            // Handle string literals
            if ((char === '"' || char === "'") && !inComment) {
                if (!inString) {
                    inString = true;
                    stringChar = char;
                } else if (char === stringChar) {
                    inString = false;
                    stringChar = null;
                }
            }
            
            // Handle comments
            if (!inString) {
                if (char === '-' && nextChar === '-') {
                    inComment = true;
                    commentChar = '\n';
                } else if (char === '/' && nextChar === '*') {
                    inComment = true;
                    commentChar = '*/';
                    i++; // Skip the *
                } else if (inComment && commentChar === '\n' && char === '\n') {
                    inComment = false;
                } else if (inComment && commentChar === '*/' && char === '*' && nextChar === '/') {
                    inComment = false;
                    i++; // Skip the /
                }
            }
            
            // Add character to current statement if not in comment
            if (!inComment) {
                currentStatement += char;
            }
            
            // Check for statement end
            if (!inString && !inComment && char === ';') {
                statements.push(currentStatement);
                currentStatement = '';
            }
        }
        
        // Add any remaining statement
        if (currentStatement.trim()) {
            statements.push(currentStatement);
        }
        
        return statements;
    }

    async checkDatabaseConnection() {
        try {
            const client = await this.pool.connect();
            const result = await client.query('SELECT version()');
            console.log('📡 Connected to PostgreSQL:', result.rows[0].version);
            client.release();
            return true;
        } catch (error) {
            console.error('❌ Database connection failed:', error.message);
            return false;
        }
    }

    async createDatabaseIfNotExists() {
        try {
            // Extract database name from connection string
            const dbUrl = process.env.DATABASE_URL || 'postgresql://localhost:5432/limeaura';
            const dbName = dbUrl.split('/').pop().split('?')[0];
            
            // Connect to default database to create the target database
            const defaultPool = new Pool({
                connectionString: 'postgresql://localhost:5432/postgres',
                ssl: false
            });
            
            try {
                await defaultPool.query(`CREATE DATABASE ${dbName}`);
                console.log(`✅ Database '${dbName}' created successfully`);
            } catch (error) {
                if (error.code === '42P04') {
                    console.log(`ℹ️  Database '${dbName}' already exists`);
                } else {
                    throw error;
                }
            }
            
            await defaultPool.end();
            
        } catch (error) {
            console.error('❌ Error creating database:', error.message);
        }
    }
}

// Run migration if called directly
if (require.main === module) {
    const migrator = new DatabaseMigrator();
    
    // Check database connection first
    migrator.checkDatabaseConnection().then(async (connected) => {
        if (connected) {
            await migrator.migrate();
        } else {
            console.log('🔄 Attempting to create database...');
            await migrator.createDatabaseIfNotExists();
            
            // Try connecting again
            setTimeout(async () => {
                const connectedNow = await migrator.checkDatabaseConnection();
                if (connectedNow) {
                    await migrator.migrate();
                } else {
                    console.error('❌ Failed to connect to database after creation attempt');
                    process.exit(1);
                }
            }, 2000);
        }
    });
}

module.exports = DatabaseMigrator;