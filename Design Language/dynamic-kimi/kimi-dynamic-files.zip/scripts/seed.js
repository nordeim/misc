#!/usr/bin/env node

/**
 * Database Seeding Script
 * Populates the database with sample data for development
 */

const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

class DataSeeder {
    constructor() {
        this.pool = new Pool({
            connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/limeaura',
            ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
        });
        
        this.users = [];
        this.organizations = [];
        this.workspaces = [];
        this.projects = [];
        this.tasks = [];
        this.milestones = [];
    }

    async seed() {
        try {
            console.log('🌱 Starting database seeding...');
            
            await this.createUsers();
            await this.createOrganizations();
            await this.createWorkspaces();
            await this.createProjects();
            await this.createMilestones();
            await this.createTasks();
            await this.createActivities();
            await this.createCalendarEvents();
            await this.createIntegrations();
            
            console.log('✅ Database seeding completed successfully!');
            console.log('🎉 Sample data is ready for development!');
            
        } catch (error) {
            console.error('❌ Seeding failed:', error.message);
            console.error(error.stack);
            process.exit(1);
        } finally {
            await this.pool.end();
        }
    }

    async createUsers() {
        console.log('👥 Creating sample users...');
        
        const usersData = [
            {
                email: 'sarah.chen@limeaura.com',
                username: 'sarahchen',
                displayName: 'Sarah Chen',
                password: 'password123'
            },
            {
                email: 'alex.kim@limeaura.com',
                username: 'alexkim',
                displayName: 'Alex Kim',
                password: 'password123'
            },
            {
                email: 'maya.patel@limeaura.com',
                username: 'mayapatel',
                displayName: 'Maya Patel',
                password: 'password123'
            },
            {
                email: 'jordan.lee@limeaura.com',
                username: 'jordanlee',
                displayName: 'Jordan Lee',
                password: 'password123'
            },
            {
                email: 'sam.wilson@limeaura.com',
                username: 'samwilson',
                displayName: 'Sam Wilson',
                password: 'password123'
            },
            {
                email: 'casey.wong@limeaura.com',
                username: 'caseywong',
                displayName: 'Casey Wong',
                password: 'password123'
            },
            {
                email: 'riley.smith@limeaura.com',
                username: 'rileysmith',
                displayName: 'Riley Smith',
                password: 'password123'
            }
        ];

        for (const userData of usersData) {
            const hashedPassword = await bcrypt.hash(userData.password, 12);
            const userResult = await this.pool.query(
                `INSERT INTO users (email, username, display_name, metadata, is_verified) 
                 VALUES ($1, $2, $3, $4, $5) 
                 RETURNING id, email, username, display_name, avatar_url, created_at`,
                [
                    userData.email,
                    userData.username,
                    userData.displayName,
                    JSON.stringify({ password: hashedPassword }),
                    true
                ]
            );
            
            this.users.push(userResult.rows[0]);
        }

        console.log(`✅ Created ${this.users.length} users`);
    }

    async createOrganizations() {
        console.log('🏢 Creating sample organizations...');
        
        const organizationsData = [
            {
                name: 'TechCorp Solutions',
                slug: 'techcorp',
                description: 'Leading technology solutions provider',
                websiteUrl: 'https://techcorp.com'
            },
            {
                name: 'Creative Studio',
                slug: 'creative-studio',
                description: 'Digital design and creative agency',
                websiteUrl: 'https://creativestudio.design'
            }
        ];

        for (const orgData of organizationsData) {
            const orgResult = await this.pool.query(
                `INSERT INTO organizations (name, slug, description, website_url) 
                 VALUES ($1, $2, $3, $4) 
                 RETURNING *`,
                [orgData.name, orgData.slug, orgData.description, orgData.websiteUrl]
            );
            
            const organization = orgResult.rows[0];
            this.organizations.push(organization);

            // Add all users as members
            for (const user of this.users) {
                const role = user.username === 'sarahchen' ? 'owner' : 'member';
                await this.pool.query(
                    'INSERT INTO organization_members (organization_id, user_id, role) VALUES ($1, $2, $3)',
                    [organization.id, user.id, role]
                );
            }
        }

        console.log(`✅ Created ${this.organizations.length} organizations`);
    }

    async createWorkspaces() {
        console.log('💼 Creating sample workspaces...');
        
        const workspacesData = [
            {
                organizationId: this.organizations[0].id,
                name: 'Product Development',
                slug: 'product-dev',
                description: 'Main product development workspace',
                color: '#7B3EFF'
            },
            {
                organizationId: this.organizations[0].id,
                name: 'Marketing Team',
                slug: 'marketing',
                description: 'Marketing campaigns and initiatives',
                color: '#00C6AE'
            },
            {
                organizationId: this.organizations[1].id,
                name: 'Client Projects',
                slug: 'client-projects',
                description: 'Active client design projects',
                color: '#FFB020'
            }
        ];

        for (const workspaceData of workspacesData) {
            const workspaceResult = await this.pool.query(
                `INSERT INTO workspaces (organization_id, name, slug, description, color, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6) 
                 RETURNING *`,
                [
                    workspaceData.organizationId,
                    workspaceData.name,
                    workspaceData.slug,
                    workspaceData.description,
                    workspaceData.color,
                    this.users[0].id
                ]
            );
            
            const workspace = workspaceResult.rows[0];
            this.workspaces.push(workspace);

            // Add users as workspace members
            for (const user of this.users) {
                const role = user.username === 'sarahchen' ? 'admin' : 'member';
                await this.pool.query(
                    'INSERT INTO workspace_members (workspace_id, user_id, role) VALUES ($1, $2, $3)',
                    [workspace.id, user.id, role]
                );
            }
        }

        console.log(`✅ Created ${this.workspaces.length} workspaces`);
    }

    async createProjects() {
        console.log('📋 Creating sample projects...');
        
        const projectsData = [
            {
                workspaceId: this.workspaces[0].id,
                name: 'LimeAura Product Launch',
                slug: 'product-launch-2025',
                description: 'Complete product launch for LimeAura productivity suite',
                color: '#7B3EFF',
                startDate: '2025-01-01',
                endDate: '2025-12-31'
            },
            {
                workspaceId: this.workspaces[0].id,
                name: 'Mobile App Development',
                slug: 'mobile-app',
                description: 'Native mobile applications for iOS and Android',
                color: '#00C6AE',
                startDate: '2025-03-01',
                endDate: '2025-09-30'
            },
            {
                workspaceId: this.workspaces[1].id,
                name: 'Brand Awareness Campaign',
                slug: 'brand-campaign',
                description: 'Q4 brand awareness marketing campaign',
                color: '#FFB020',
                startDate: '2025-10-01',
                endDate: '2025-12-31'
            }
        ];

        for (const projectData of projectsData) {
            const projectResult = await this.pool.query(
                `INSERT INTO projects (workspace_id, name, slug, description, color, start_date, end_date, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
                 RETURNING *`,
                [
                    projectData.workspaceId,
                    projectData.name,
                    projectData.slug,
                    projectData.description,
                    projectData.color,
                    projectData.startDate,
                    projectData.endDate,
                    this.users[0].id
                ]
            );
            
            const project = projectResult.rows[0];
            this.projects.push(project);

            // Add users as project members
            for (const user of this.users) {
                const role = user.username === 'sarahchen' ? 'admin' : 'member';
                await this.pool.query(
                    'INSERT INTO project_members (project_id, user_id, role) VALUES ($1, $2, $3)',
                    [project.id, user.id, role]
                );
            }
        }

        console.log(`✅ Created ${this.projects.length} projects`);
    }

    async createMilestones() {
        console.log('🎯 Creating sample milestones...');
        
        const milestonesData = [
            {
                projectId: this.projects[0].id,
                name: 'Design System Complete',
                description: 'Final design tokens and component library',
                dueDate: '2025-11-20',
                progressPercentage: 75
            },
            {
                projectId: this.projects[0].id,
                name: 'API Integration',
                description: 'Backend services and data synchronization',
                dueDate: '2025-11-25',
                progressPercentage: 40
            },
            {
                projectId: this.projects[0].id,
                name: 'User Testing',
                description: 'Usability testing and feedback collection',
                dueDate: '2025-12-05',
                progressPercentage: 15
            }
        ];

        for (const milestoneData of milestonesData) {
            const milestoneResult = await this.pool.query(
                `INSERT INTO milestones (project_id, name, description, due_date, progress_percentage, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6) 
                 RETURNING *`,
                [
                    milestoneData.projectId,
                    milestoneData.name,
                    milestoneData.description,
                    milestoneData.dueDate,
                    milestoneData.progressPercentage,
                    this.users[0].id
                ]
            );
            
            const milestone = milestoneResult.rows[0];
            this.milestones.push(milestone);
        }

        console.log(`✅ Created ${this.milestones.length} milestones`);
    }

    async createTasks() {
        console.log('✅ Creating sample tasks...');
        
        const tasksData = [
            // Design System tasks
            {
                projectId: this.projects[0].id,
                title: 'Update color palette',
                description: 'Refine color system for better accessibility',
                assigneeId: this.users[1].id, // Alex Kim
                priority: 'high',
                estimatedHours: 8
            },
            {
                projectId: this.projects[0].id,
                title: 'Implement button components',
                description: 'Create reusable button component library',
                assigneeId: this.users[2].id, // Maya Patel
                priority: 'medium',
                estimatedHours: 12
            },
            {
                projectId: this.projects[0].id,
                title: 'Design icon system',
                description: 'Create comprehensive icon library',
                assigneeId: this.users[3].id, // Jordan Lee
                priority: 'medium',
                estimatedHours: 16
            },
            // Mobile App tasks
            {
                projectId: this.projects[1].id,
                title: 'Setup React Native project',
                description: 'Initialize mobile app development environment',
                assigneeId: this.users[4].id, // Sam Wilson
                priority: 'high',
                estimatedHours: 4
            },
            {
                projectId: this.projects[1].id,
                title: 'Implement authentication flow',
                description: 'User login and registration screens',
                assigneeId: this.users[5].id, // Casey Wong
                priority: 'high',
                estimatedHours: 20
            },
            // Marketing tasks
            {
                projectId: this.projects[2].id,
                title: 'Create brand guidelines',
                description: 'Document brand voice and visual identity',
                assigneeId: this.users[6].id, // Riley Smith
                priority: 'medium',
                estimatedHours: 10
            }
        ];

        for (const taskData of tasksData) {
            // Get default status for project
            const statusResult = await this.pool.query(
                'SELECT id FROM task_statuses WHERE project_id = $1 AND is_default = true',
                [taskData.projectId]
            );

            const defaultStatusId = statusResult.rows.length > 0 ? statusResult.rows[0].id : null;

            const taskResult = await this.pool.query(
                `INSERT INTO tasks (project_id, status_id, title, description, assignee_id, priority, estimated_hours, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
                 RETURNING *`,
                [
                    taskData.projectId,
                    defaultStatusId,
                    taskData.title,
                    taskData.description,
                    taskData.assigneeId,
                    taskData.priority,
                    taskData.estimatedHours,
                    this.users[0].id
                ]
            );
            
            this.tasks.push(taskResult.rows[0]);
        }

        console.log(`✅ Created ${this.tasks.length} tasks`);
    }

    async createActivities() {
        console.log('📈 Creating sample activities...');
        
        const activitiesData = [
            {
                userId: this.users[1].id, // Alex Kim
                actionType: 'task_completed',
                entityType: 'task',
                entityTitle: 'Update color palette',
                description: 'Completed task "Update color palette"'
            },
            {
                userId: this.users[2].id, // Maya Patel
                actionType: 'comment_added',
                entityType: 'task',
                entityTitle: 'API Documentation',
                description: 'Added comment to "API Documentation"'
            },
            {
                userId: this.users[3].id, // Jordan Lee
                actionType: 'milestone_created',
                entityType: 'milestone',
                entityTitle: 'Security Review',
                description: 'Created new milestone "Security Review"'
            },
            {
                userId: this.users[4].id, // Sam Wilson
                actionType: 'file_uploaded',
                entityType: 'project',
                entityTitle: 'Design Assets',
                description: 'Uploaded files to "Design Assets"'
            }
        ];

        for (const activityData of activitiesData) {
            await this.pool.query(
                `INSERT INTO activities (organization_id, workspace_id, project_id, user_id, action_type, entity_type, entity_id, entity_title, description) 
                 SELECT o.id, w.id, p.id, $1, $2, $3, $4, $5, $6
                 FROM projects p
                 JOIN workspaces w ON p.workspace_id = w.id
                 JOIN organizations o ON w.organization_id = o.id
                 WHERE p.id = $7`,
                [
                    activityData.userId,
                    activityData.actionType,
                    activityData.entityType,
                    uuidv4(), // Mock entity ID
                    activityData.entityTitle,
                    activityData.description,
                    this.projects[0].id
                ]
            );
        }

        console.log(`✅ Created ${activitiesData.length} activities`);
    }

    async createCalendarEvents() {
        console.log('📅 Creating sample calendar events...');
        
        const eventsData = [
            {
                workspaceId: this.workspaces[0].id,
                title: 'Sprint Planning Meeting',
                description: 'Weekly sprint planning session',
                eventType: 'meeting',
                startDate: '2025-11-18',
                startTime: '09:00',
                endTime: '10:30',
                organizerId: this.users[0].id,
                location: 'Conference Room A',
                meetingUrl: 'https://meet.google.com/abc-defg-hij'
            },
            {
                workspaceId: this.workspaces[0].id,
                title: 'Design Review',
                description: 'Review design system components',
                eventType: 'meeting',
                startDate: '2025-11-20',
                startTime: '14:00',
                endTime: '15:00',
                organizerId: this.users[1].id,
                isAllDay: false
            },
            {
                workspaceId: this.workspaces[1].id,
                title: 'Product Launch Deadline',
                description: 'Final deadline for product launch',
                eventType: 'deadline',
                startDate: '2025-12-15',
                organizerId: this.users[0].id,
                isAllDay: true
            }
        ];

        for (const eventData of eventsData) {
            const eventResult = await this.pool.query(
                `INSERT INTO calendar_events (workspace_id, title, description, event_type, start_date, start_time, end_time, organizer_id, location, meeting_url, is_all_day) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) 
                 RETURNING *`,
                [
                    eventData.workspaceId,
                    eventData.title,
                    eventData.description,
                    eventData.eventType,
                    eventData.startDate,
                    eventData.startTime,
                    eventData.endTime,
                    eventData.organizerId,
                    eventData.location,
                    eventData.meetingUrl,
                    eventData.isAllDay
                ]
            );

            // Add attendees
            for (const user of this.users.slice(0, 4)) { // First 4 users as attendees
                await this.pool.query(
                    'INSERT INTO calendar_event_attendees (event_id, user_id, status) VALUES ($1, $2, $3)',
                    [eventResult.rows[0].id, user.id, 'accepted']
                );
            }
        }

        console.log(`✅ Created ${eventsData.length} calendar events`);
    }

    async createIntegrations() {
        console.log('🔗 Creating sample integrations...');
        
        const integrationsData = [
            {
                organizationId: this.organizations[0].id,
                serviceType: 'slack',
                name: 'Slack Integration',
                description: 'Team communication and notifications',
                isEnabled: true,
                config: { webhookUrl: 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX' }
            },
            {
                organizationId: this.organizations[0].id,
                serviceType: 'gmail',
                name: 'Gmail Integration',
                description: 'Email integration and task creation',
                isEnabled: true,
                config: { apiKey: 'fake-api-key-for-demo' }
            },
            {
                organizationId: this.organizations[0].id,
                serviceType: 'drive',
                name: 'Google Drive Integration',
                description: 'File storage and document collaboration',
                isEnabled: false,
                config: {}
            }
        ];

        for (const integrationData of integrationsData) {
            await this.pool.query(
                `INSERT INTO integrations (organization_id, service_type, name, description, is_enabled, config, created_by) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7)`,
                [
                    integrationData.organizationId,
                    integrationData.serviceType,
                    integrationData.name,
                    integrationData.description,
                    integrationData.isEnabled,
                    JSON.stringify(integrationData.config),
                    this.users[0].id
                ]
            );
        }

        console.log(`✅ Created ${integrationsData.length} integrations`);
    }
}

// Run seeder if called directly
if (require.main === module) {
    const seeder = new DataSeeder();
    
    // Check if seeding is enabled
    if (process.env.ENABLE_SEEDING !== 'true' && process.env.NODE_ENV === 'production') {
        console.log('⚠️  Seeding is disabled in production. Set ENABLE_SEEDING=true to enable.');
        process.exit(0);
    }
    
    seeder.seed();
}

module.exports = DataSeeder;