# LimeAura Deployment Guide

## Overview

This guide provides comprehensive instructions for deploying the LimeAura Productivity Suite in various environments, from local development to production.

## 🚀 Quick Start Deployment

### Prerequisites
- Node.js 18+ and npm 8+
- PostgreSQL 14+
- Git

### Local Development Setup

```bash
# Clone the repository
git clone https://github.com/your-org/limeaura.git
cd limeaura

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your configuration

# Setup database
npm run db:migrate
npm run db:seed

# Start the application
npm run dev
```

## 📦 Production Deployment

### 1. Environment Configuration

Create a production `.env` file:

```bash
# Server Configuration
NODE_ENV=production
PORT=3001

# Database Configuration
DATABASE_URL=postgresql://username:password@host:5432/limeaura_prod

# Security
JWT_SECRET=your-super-secure-jwt-secret-min-32-characters
BCRYPT_ROUNDS=12

# Frontend URL for CORS
FRONTEND_URL=https://your-domain.com

# Rate Limiting
RATE_LIMIT_WINDOW_MINUTES=15
RATE_LIMIT_MAX_REQUESTS=1000

# Features
ENABLE_REAL_TIME=true
ENABLE_FILE_UPLOADS=true
ENABLE_EMAIL_NOTIFICATIONS=true
```

### 2. Database Setup

```sql
-- Create production database
CREATE DATABASE limeaura_prod;

-- Create application user
CREATE USER limeaura_app WITH PASSWORD 'secure-password';
GRANT ALL PRIVILEGES ON DATABASE limeaura_prod TO limeaura_app;

-- Run migrations
npm run db:migrate
```

### 3. Server Deployment Options

#### Option A: PM2 (Recommended for Node.js)

```bash
# Install PM2 globally
npm install -g pm2

# Start the application
pm2 start server.js --name limeaura-api

# Save PM2 configuration
pm2 save
pm2 startup
```

#### Option B: Docker

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3001

CMD ["node", "server.js"]
```

Build and run:

```bash
docker build -t limeaura:latest .
docker run -d -p 3001:3001 --env-file .env limeaura:latest
```

#### Option C: Systemd Service

Create `/etc/systemd/system/limeaura.service`:

```ini
[Unit]
Description=LimeAura API Server
After=network.target

[Service]
Type=simple
User=limeaura
WorkingDirectory=/opt/limeaura
ExecStart=/usr/bin/node server.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl enable limeaura
sudo systemctl start limeaura
```

### 4. Reverse Proxy Setup

#### Nginx Configuration

```nginx
# /etc/nginx/sites-available/limeaura
server {
    listen 80;
    server_name your-domain.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    # SSL Configuration
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";

    # Static files
    location / {
        root /opt/limeaura/public;
        try_files $uri $uri/ /index.html;
    }

    # API proxy
    location /api/ {
        proxy_pass http://localhost:3001/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/limeaura /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 🏗️ Infrastructure as Code

### Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:14-alpine
    environment:
      POSTGRES_DB: limeaura
      POSTGRES_USER: limeaura
      POSTGRES_PASSWORD: secure-password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    networks:
      - limeaura-network

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    networks:
      - limeaura-network

  app:
    build: .
    environment:
      NODE_ENV: production
      DATABASE_URL: postgresql://limeaura:secure-password@postgres:5432/limeaura
      REDIS_URL: redis://redis:6379
      JWT_SECRET: your-super-secure-jwt-secret
    ports:
      - "3001:3001"
    depends_on:
      - postgres
      - redis
    networks:
      - limeaura-network
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - app
    networks:
      - limeaura-network
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:

networks:
  limeaura-network:
    driver: bridge
```

### Kubernetes Deployment

Create `k8s-deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: limeaura-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: limeaura
  template:
    metadata:
      labels:
        app: limeaura
    spec:
      containers:
      - name: limeaura
        image: limeaura:latest
        ports:
        - containerPort: 3001
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: limeaura-secrets
              key: database-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: limeaura-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 3001
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 3001
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: limeaura-service
spec:
  selector:
    app: limeaura
  ports:
  - port: 80
    targetPort: 3001
  type: LoadBalancer

---
apiVersion: v1
kind: Secret
metadata:
  name: limeaura-secrets
type: Opaque
data:
  database-url: <base64-encoded-database-url>
  jwt-secret: <base64-encoded-jwt-secret>
```

## 📊 Monitoring and Observability

### Health Checks

The application provides health check endpoints:

- **GET /api/health** - Basic health status
- **GET /api/health/detailed** - Detailed health with database connectivity

### Logging

Configure logging with Winston:

```javascript
const winston = require('winston');

const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/combined.log' }),
        new winston.transports.Console({
            format: winston.format.simple()
        })
    ]
});
```

### Metrics

Implement application metrics with Prometheus:

```javascript
const client = require('prom-client');

// Create metrics
collectDefaultMetrics();

const httpRequestDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [0.1, 0.5, 1, 2, 5]
});

const httpRequestsTotal = new client.Counter({
    name: 'http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method', 'route', 'status_code']
});

// Middleware to collect metrics
app.use((req, res, next) => {
    const start = Date.now();
    
    res.on('finish', () => {
        const duration = (Date.now() - start) / 1000;
        const route = req.route ? req.route.path : req.path;
        
        httpRequestDuration
            .labels(req.method, route, res.statusCode)
            .observe(duration);
            
        httpRequestsTotal
            .labels(req.method, route, res.statusCode)
            .inc();
    });
    
    next();
});

// Metrics endpoint
app.get('/metrics', (req, res) => {
    res.set('Content-Type', client.register.contentType);
    res.end(client.register.metrics());
});
```

## 🔒 Security Considerations

### 1. Database Security

```sql
-- Use parameterized queries to prevent SQL injection
-- Example in the API code already uses parameterization

-- Limit database user permissions
REVOKE ALL ON SCHEMA public FROM public;
GRANT USAGE ON SCHEMA public TO limeaura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA limeaura TO limeaura_app;
```

### 2. Application Security

- **Input Validation**: Validate all user inputs
- **Rate Limiting**: Implemented with express-rate-limit
- **CORS**: Configured for specific origins
- **Helmet**: Security headers middleware
- **JWT**: Secure token-based authentication

### 3. Infrastructure Security

```bash
# Firewall configuration (UFW)
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable

# SSL Certificate with Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 🔄 CI/CD Pipeline

### GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:14
        env:
          POSTGRES_PASSWORD: test-password
          POSTGRES_DB: limeaura_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run tests
      run: npm test
      env:
        DATABASE_URL: postgresql://postgres:test-password@localhost:5432/limeaura_test
        JWT_SECRET: test-secret

  deploy:
    needs: test
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci --only=production
    
    - name: Deploy to server
      uses: appleboy/ssh-action@v0.1.5
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /opt/limeaura
          git pull origin main
          npm ci --only=production
          npm run db:migrate
          pm2 reload all
```

## 📈 Performance Optimization

### 1. Database Optimization

```sql
-- Add indexes for common queries
CREATE INDEX CONCURRENTLY idx_tasks_user_status ON tasks(assignee_id, status_id);
CREATE INDEX CONCURRENTLY idx_activities_created_desc ON activities(created_at DESC);

-- Partition large tables
CREATE TABLE activities_2025 PARTITION OF activities
    FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
```

### 2. Application Optimization

```javascript
// Enable compression
const compression = require('compression');
app.use(compression({
    filter: (req, res) => {
        if (req.headers['x-no-compression']) {
            return false;
        }
        return compression.filter(req, res);
    },
    level: 6
}));

// Cache static assets
app.use(express.static('public', {
    maxAge: '1d',
    etag: true
}));
```

### 3. CDN Integration

```javascript
// Serve static files from CDN in production
if (process.env.NODE_ENV === 'production' && process.env.CDN_URL) {
    app.use('/static', (req, res, next) => {
        res.set('Cache-Control', 'public, max-age=31536000');
        next();
    });
}
```

## 🚨 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check PostgreSQL status
   sudo systemctl status postgresql
   
   # Check connection
   psql -h localhost -U limeaura -d limeaura
   ```

2. **WebSocket Connection Failed**
   - Check firewall rules
   - Verify nginx proxy configuration
   - Ensure SSL certificate is valid

3. **High Memory Usage**
   ```bash
   # Monitor memory usage
   pm2 monit
   
   # Check for memory leaks
   node --inspect server.js
   ```

4. **Slow Query Performance**
   ```sql
   -- Enable query logging
   SET log_min_duration_statement = 1000;
   
   -- Analyze slow queries
   EXPLAIN ANALYZE SELECT * FROM tasks WHERE assignee_id = 'user-id';
   ```

### Log Analysis

```bash
# Check application logs
pm2 logs limeaura-api

# Check system logs
sudo journalctl -u limeaura -f

# Check nginx logs
sudo tail -f /var/log/nginx/error.log
```

## 🔄 Backup and Recovery

### Database Backup

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="limeaura_prod"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
pg_dump -h localhost -U limeaura_app $DB_NAME > $BACKUP_DIR/limeaura_$DATE.sql

# Compress backup
gzip $BACKUP_DIR/limeaura_$DATE.sql

# Remove old backups (keep last 7 days)
find $BACKUP_DIR -name "limeaura_*.sql.gz" -mtime +7 -delete

# Upload to cloud storage (optional)
aws s3 cp $BACKUP_DIR/limeaura_$DATE.sql.gz s3://your-backup-bucket/
```

### Application Backup

```bash
#!/bin/bash
# backup-app.sh

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup application files
tar -czf $BACKUP_DIR/limeaura-app_$DATE.tar.gz /opt/limeaura

# Backup uploaded files
if [ -d /opt/limeaura/uploads ]; then
    tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /opt/limeaura/uploads
fi
```

## 🌐 Multi-Environment Setup

### Environment-Specific Configurations

```javascript
// config/environments.js
const environments = {
    development: {
        database: {
            host: 'localhost',
            port: 5432,
            name: 'limeaura_dev'
        },
        redis: {
            host: 'localhost',
            port: 6379
        },
        logging: {
            level: 'debug'
        }
    },
    staging: {
        database: {
            host: process.env.DB_HOST,
            port: 5432,
            name: 'limeaura_staging'
        },
        redis: {
            host: process.env.REDIS_HOST,
            port: 6379
        },
        logging: {
            level: 'info'
        }
    },
    production: {
        database: {
            host: process.env.DB_HOST,
            port: 5432,
            name: 'limeaura_prod'
        },
        redis: {
            host: process.env.REDIS_HOST,
            port: 6379
        },
        logging: {
            level: 'warn'
        }
    }
};

module.exports = environments[process.env.NODE_ENV] || environments.development;
```

## 📚 Additional Resources

- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)
- [Express.js Security](https://expressjs.com/en/advanced/best-practice-security.html)
- [Nginx Documentation](https://nginx.org/en/docs/)
- [Docker Documentation](https://docs.docker.com/)

## 🤝 Support

For deployment support:
- Check the [Troubleshooting](#troubleshooting) section
- Review application logs
- Open an issue on GitHub
- Contact support@limeaura.com

---

**Last Updated**: November 15, 2025  
**Version**: 3.0.0  
**Compatibility**: Node.js 18+, PostgreSQL 14+