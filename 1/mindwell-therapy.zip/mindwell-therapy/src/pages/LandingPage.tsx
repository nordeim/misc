import React from 'react'
import { Link } from 'react-router-dom'
import { Shield, Video, Users, FileText, Heart, Star, Calendar, UserCheck, Phone, ArrowRight } from 'lucide-react'
import { PublicLayout } from '@/components/Layout'

export function LandingPage() {
  return (
    <PublicLayout>
      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-neutral-900 mb-6">
              Mental Health Care
              <span className="block text-primary-600">Made Accessible</span>
            </h1>
            <p className="text-xl text-neutral-600 mb-8 max-w-3xl mx-auto">
              Connect with licensed therapists through our HIPAA-compliant platform. 
              From insurance verification to secure video sessions, experience comprehensive mental health care.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/client"
                className="bg-primary-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-primary-600 transition-colors shadow-therapeutic flex items-center justify-center gap-2"
              >
                Try Client Portal
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/provider"
                className="border-2 border-primary-500 text-primary-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-primary-50 transition-colors flex items-center justify-center gap-2"
              >
                Try Provider Portal
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            
            <div className="mt-12 bg-therapeutic-calm/20 p-6 rounded-xl max-w-2xl mx-auto">
              <div className="flex items-center justify-center space-x-2 mb-3">
                <Phone className="w-5 h-5 text-primary-600" />
                <span className="font-semibold text-neutral-900">Crisis Support Available 24/7</span>
              </div>
              <p className="text-neutral-700">
                Call 988 (Suicide & Crisis Lifeline) • Text HOME to 741741
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Access Section */}
      <section className="py-16 bg-gradient-to-br from-primary-50 to-secondary-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">
              Experience AT-AI Instantly
            </h2>
            <p className="text-lg text-neutral-600">
              No registration required. Explore our platform and see how we're revolutionizing mental health care.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-therapeutic hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-primary-500 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-neutral-900 mb-4 text-center">For Clients</h3>
              <p className="text-neutral-600 mb-6 text-center">
                Explore our client dashboard with features for finding therapists, managing appointments, and tracking your mental health journey.
              </p>
              <Link
                to="/client"
                className="w-full bg-primary-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-600 transition-colors flex items-center justify-center gap-2"
              >
                Explore Client Features
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-therapeutic hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-secondary-500 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <UserCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-neutral-900 mb-4 text-center">For Providers</h3>
              <p className="text-neutral-600 mb-6 text-center">
                Experience our provider dashboard with patient management, session tools, and practice administration features.
              </p>
              <Link
                to="/provider"
                className="w-full bg-secondary-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-secondary-600 transition-colors flex items-center justify-center gap-2"
              >
                Explore Provider Features
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
              Everything You Need for Mental Health Care
            </h2>
            <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
              Our platform combines cutting-edge technology with compassionate care to provide 
              a comprehensive mental health solution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-primary-500 rounded-xl flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Insurance Verification</h3>
              <p className="text-neutral-600">
                Scan your insurance card with your phone. We'll instantly verify coverage and 
                find in-network therapists for you.
              </p>
            </div>

            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-secondary-500 rounded-xl flex items-center justify-center mb-6">
                <Video className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Secure Video Sessions</h3>
              <p className="text-neutral-600">
                HIPAA-compliant video therapy sessions with recording and transcription capabilities. 
                Your privacy and security are our top priorities.
              </p>
            </div>

            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-accent-500 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Expert Matching</h3>
              <p className="text-neutral-600">
                Find therapists who specialize in your specific needs and accept your insurance. 
                Our smart matching considers location, specialty, and availability.
              </p>
            </div>

            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center mb-6">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Session History</h3>
              <p className="text-neutral-600">
                Access your complete therapy journey with session notes, recordings, and 
                progress tracking all in one secure place.
              </p>
            </div>

            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-secondary-600 rounded-xl flex items-center justify-center mb-6">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Crisis Support</h3>
              <p className="text-neutral-600">
                24/7 crisis intervention with automatic detection and emergency contact systems. 
                Your safety is always our priority.
              </p>
            </div>

            <div className="bg-therapeutic-safety p-8 rounded-2xl hover:shadow-therapeutic transition-shadow">
              <div className="w-12 h-12 bg-accent-600 rounded-xl flex items-center justify-center mb-6">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Easy Scheduling</h3>
              <p className="text-neutral-600">
                Book, reschedule, or cancel appointments with ease. Automated reminders 
                ensure you never miss a session.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gradient-to-br from-primary-50 to-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
              How AT-AI Works
            </h2>
            <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
              Simple, secure, and effective mental health care delivery
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-primary-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Verify Insurance Coverage</h3>
              <p className="text-neutral-600">
                Simply scan your insurance card. Our system instantly verifies coverage and 
                shows you which therapists are available.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-secondary-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Find Your Perfect Match</h3>
              <p className="text-neutral-600">
                Browse therapists by specialty, location, and availability. 
                Read profiles and book your first appointment instantly.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-accent-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Start Your Journey</h3>
              <p className="text-neutral-600">
                Attend secure video sessions, track your progress, and access 
                your complete session history anytime, anywhere.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Experience the Future of Mental Health Care
          </h2>
          <p className="text-xl text-primary-100 mb-8">
            No registration required. Explore our platform and discover how we're making 
            mental health care more accessible and effective.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/client"
              className="bg-white text-primary-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-neutral-100 transition-colors flex items-center justify-center gap-2"
            >
              Explore Client Portal
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/provider"
              className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-primary-600 transition-colors flex items-center justify-center gap-2"
            >
              Explore Provider Portal
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  )
}