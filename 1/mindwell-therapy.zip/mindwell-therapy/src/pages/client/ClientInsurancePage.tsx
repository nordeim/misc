import React, { useState, useEffect } from 'react'
import { Shield, CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react'
import { Layout } from '@/components/Layout'
import { InsuranceCardScanner } from '@/components/InsuranceCardScanner'
import { ProviderSearch } from '@/components/ProviderSearch'
import { getDemoInsurancePlan } from '@/lib/publicData'

export function ClientInsurancePage() {
  const [insurancePlan, setInsurancePlan] = useState<any>(null)
  const [showScanner, setShowScanner] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadInsurancePlan()
  }, [])

  async function loadInsurancePlan() {
    try {
      const plan = await getDemoInsurancePlan()
      setInsurancePlan(plan)
      if (!plan) {
        setShowScanner(true)
      }
    } catch (error) {
      console.error('Error loading insurance plan:', error)
    } finally {
      setLoading(false)
    }
  }

  function handleScanComplete(insuranceData: any) {
    // Update insurance plan with scanned data
    setInsurancePlan({
      ...insurancePlan,
      ...insuranceData.insurancePlan
    })
    setShowScanner(false)
  }

  if (loading) {
    return (
      <Layout className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-neutral-200 rounded w-1/4 mb-6"></div>
            <div className="h-64 bg-neutral-200 rounded-xl"></div>
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neutral-900 mb-2">Insurance & Coverage</h1>
          <p className="text-neutral-600">
            Manage your insurance information and find in-network therapists
          </p>
        </div>

        {/* Insurance Status */}
        {insurancePlan ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Current Insurance Plan */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
                      <Shield className="w-6 h-6 text-secondary-600" />
                    </div>
                    <h2 className="text-xl font-bold text-neutral-900">Current Insurance Plan</h2>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      insurancePlan.verification_status === 'verified'
                        ? 'bg-secondary-100 text-secondary-700'
                        : insurancePlan.verification_status === 'pending'
                        ? 'bg-yellow-100 text-yellow-700'
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {insurancePlan.verification_status === 'verified' && <CheckCircle className="w-4 h-4 inline mr-1" />}
                      {insurancePlan.verification_status === 'pending' && <RefreshCw className="w-4 h-4 inline mr-1" />}
                      {insurancePlan.verification_status === 'rejected' && <AlertTriangle className="w-4 h-4 inline mr-1" />}
                      {insurancePlan.verification_status.charAt(0).toUpperCase() + insurancePlan.verification_status.slice(1)}
                    </span>
                    <button
                      onClick={() => setShowScanner(true)}
                      className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
                    >
                      Update Card
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-neutral-600">Insurance Company</label>
                      <p className="text-lg font-semibold text-neutral-900">{insurancePlan.insurance_company}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-neutral-600">Plan Name</label>
                      <p className="text-neutral-900">{insurancePlan.plan_name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-neutral-600">Member ID</label>
                      <p className="text-neutral-900 font-mono">{insurancePlan.member_id}</p>
                    </div>
                    {insurancePlan.group_number && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-600">Group Number</label>
                        <p className="text-neutral-900 font-mono">{insurancePlan.group_number}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-4">
                    {insurancePlan.copay_amount && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-600">Copay Amount</label>
                        <p className="text-lg font-semibold text-neutral-900">${insurancePlan.copay_amount}</p>
                      </div>
                    )}
                    {insurancePlan.deductible_amount && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-600">Deductible</label>
                        <p className="text-neutral-900">${insurancePlan.deductible_amount}</p>
                      </div>
                    )}
                    {insurancePlan.out_of_pocket_max && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-600">Out-of-Pocket Max</label>
                        <p className="text-neutral-900">${insurancePlan.out_of_pocket_max}</p>
                      </div>
                    )}
                    {insurancePlan.last_verified_at && (
                      <div>
                        <label className="block text-sm font-medium text-neutral-600">Last Verified</label>
                        <p className="text-neutral-900">
                          {new Date(insurancePlan.last_verified_at).toLocaleDateString()}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {insurancePlan.card_image_url && (
                  <div className="mt-6">
                    <label className="block text-sm font-medium text-neutral-600 mb-2">Insurance Card</label>
                    <img
                      src={insurancePlan.card_image_url}
                      alt="Insurance card"
                      className="w-full max-w-md h-48 object-cover rounded-lg border border-neutral-200"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Coverage Summary */}
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-secondary-50 to-primary-50 rounded-xl p-6 border border-secondary-200">
                <h3 className="text-lg font-bold text-neutral-900 mb-4">Coverage Benefits</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-700">Mental Health Covered</span>
                    <CheckCircle className="w-5 h-5 text-secondary-600" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-700">Telehealth Sessions</span>
                    <CheckCircle className="w-5 h-5 text-secondary-600" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-700">Crisis Support</span>
                    <CheckCircle className="w-5 h-5 text-secondary-600" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-700">Session Recordings</span>
                    <CheckCircle className="w-5 h-5 text-secondary-600" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
                <h3 className="text-lg font-bold text-neutral-900 mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <button className="w-full text-left p-3 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors">
                    <span className="font-medium text-neutral-900">Verify Current Benefits</span>
                    <p className="text-sm text-neutral-600">Check your current coverage status</p>
                  </button>
                  <button className="w-full text-left p-3 bg-secondary-50 rounded-lg hover:bg-secondary-100 transition-colors">
                    <span className="font-medium text-neutral-900">Download Insurance Card</span>
                    <p className="text-sm text-neutral-600">Get a digital copy of your card</p>
                  </button>
                  <button 
                    onClick={() => setShowScanner(true)}
                    className="w-full text-left p-3 bg-accent-50 rounded-lg hover:bg-accent-100 transition-colors"
                  >
                    <span className="font-medium text-neutral-900">Update Insurance</span>
                    <p className="text-sm text-neutral-600">Scan a new insurance card</p>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : null}

        {/* Insurance Scanner (when no plan or updating) */}
        {(showScanner || !insurancePlan) && (
          <div className="mb-8">
            <InsuranceCardScanner onScanComplete={handleScanComplete} />
          </div>
        )}

        {/* Provider Search */}
        <div className="mt-8">
          <ProviderSearch 
            insuranceCompany={insurancePlan?.insurance_company}
          />
        </div>
      </div>
    </Layout>
  )
}