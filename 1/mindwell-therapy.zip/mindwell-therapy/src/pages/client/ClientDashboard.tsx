import React, { useEffect, useState } from 'react'
import { Calendar, Clock, Heart, Users, Video, TrendingUp, AlertTriangle } from 'lucide-react'
import { Layout } from '@/components/Layout'
import { Link } from 'react-router-dom'
import { getDemoClientAppointments, getDemoClientSessions, getDemoClientProfile } from '@/lib/publicData'

export function ClientDashboard() {
  const [upcomingAppointments, setUpcomingAppointments] = useState<any[]>([])
  const [recentSessions, setRecentSessions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  
  // Demo user profile
  const demoProfile = getDemoClientProfile()

  useEffect(() => {
    loadDashboardData()
  }, [])

  async function loadDashboardData() {
    try {
      const [appointments, sessions] = await Promise.all([
        getDemoClientAppointments(),
        getDemoClientSessions()
      ])
      
      setUpcomingAppointments(appointments)
      setRecentSessions(sessions)
    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Layout className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-neutral-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neutral-900 mb-2">
            Welcome back, {demoProfile.first_name}! 👋
          </h1>
          <p className="text-neutral-600">
            Here's an overview of your mental health journey
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Next Session</p>
                <p className="text-2xl font-bold text-neutral-900">
                  {upcomingAppointments.length > 0 ? (
                    new Date(upcomingAppointments[0].scheduled_at).toLocaleDateString()
                  ) : (
                    'None scheduled'
                  )}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-primary-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Total Sessions</p>
                <p className="text-2xl font-bold text-neutral-900">{recentSessions.length}</p>
              </div>
              <div className="w-12 h-12 bg-secondary-100 rounded-xl flex items-center justify-center">
                <Video className="w-6 h-6 text-secondary-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Mood Trend</p>
                <p className="text-2xl font-bold text-neutral-900">Improving</p>
              </div>
              <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Wellbeing Score</p>
                <p className="text-2xl font-bold text-neutral-900">7.2/10</p>
              </div>
              <div className="w-12 h-12 bg-therapeutic-peace/20 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-secondary-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upcoming Appointments */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-neutral-900">Upcoming Appointments</h2>
                <Link
                  to="/client/appointments"
                  className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
                >
                  View all
                </Link>
              </div>

              {upcomingAppointments.length > 0 ? (
                <div className="space-y-4">
                  {upcomingAppointments.map((appointment) => (
                    <div key={appointment.id} className="flex items-center p-4 bg-therapeutic-safety rounded-lg">
                      <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mr-4">
                        <Video className="w-6 h-6 text-primary-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-neutral-900 capitalize">
                          {appointment.appointment_type.replace('_', ' ')}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-neutral-600">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(appointment.scheduled_at).toLocaleDateString()}
                          </span>
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {new Date(appointment.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          appointment.status === 'confirmed' 
                            ? 'bg-secondary-100 text-secondary-700'
                            : 'bg-neutral-100 text-neutral-700'
                        }`}>
                          {appointment.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-neutral-900 mb-2">No upcoming appointments</h3>
                  <p className="text-neutral-600 mb-4">Ready to schedule your next session?</p>
                  <Link
                    to="/client/find-providers"
                    className="inline-block bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 transition-colors font-medium"
                  >
                    Find a Therapist
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions & Crisis Support */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Quick Actions</h2>
              <div className="space-y-3">
                <Link
                  to="/client/find-providers"
                  className="flex items-center p-3 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors group"
                >
                  <Users className="w-5 h-5 text-primary-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-primary-700">Find Therapists</span>
                </Link>
                
                <Link
                  to="/client/appointments"
                  className="flex items-center p-3 bg-secondary-50 rounded-lg hover:bg-secondary-100 transition-colors group"
                >
                  <Calendar className="w-5 h-5 text-secondary-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-secondary-700">Schedule Session</span>
                </Link>
                
                <Link
                  to="/client/sessions"
                  className="flex items-center p-3 bg-accent-50 rounded-lg hover:bg-accent-100 transition-colors group"
                >
                  <Video className="w-5 h-5 text-accent-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-accent-700">Session History</span>
                </Link>
              </div>
            </div>

            {/* Crisis Support */}
            <div className="bg-gradient-to-br from-crisis-low to-crisis-medium rounded-xl p-6 border border-orange-200">
              <div className="flex items-center mb-4">
                <AlertTriangle className="w-6 h-6 text-orange-600 mr-3" />
                <h2 className="text-xl font-bold text-neutral-900">Crisis Support</h2>
              </div>
              <p className="text-neutral-700 mb-4">
                If you're experiencing a mental health crisis, help is available 24/7.
              </p>
              <div className="space-y-3">
                <a
                  href="tel:988"
                  className="block w-full bg-red-600 text-white py-3 px-4 rounded-lg text-center font-semibold hover:bg-red-700 transition-colors"
                >
                  Call 988 - Crisis Lifeline
                </a>
                <a
                  href="sms:741741?body=HOME"
                  className="block w-full bg-blue-600 text-white py-3 px-4 rounded-lg text-center font-semibold hover:bg-blue-700 transition-colors"
                >
                  Text HOME to 741741
                </a>
                <Link
                  to="/client/crisis-support"
                  className="block w-full bg-neutral-700 text-white py-3 px-4 rounded-lg text-center font-semibold hover:bg-neutral-800 transition-colors"
                >
                  Access Safety Plan
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Sessions */}
        {recentSessions.length > 0 && (
          <div className="mt-8">
            <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Recent Sessions</h2>
              <div className="space-y-4">
                {recentSessions.slice(0, 3).map((session) => (
                  <div key={session.id} className="flex items-center p-4 bg-therapeutic-safety rounded-lg">
                    <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center mr-4">
                      <Video className="w-5 h-5 text-secondary-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-neutral-900 capitalize">
                        {session.session_type.replace('_', ' ')}
                      </h3>
                      <p className="text-sm text-neutral-600">
                        {session.ended_at && new Date(session.ended_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      {session.mood_after && (
                        <div className="text-sm">
                          <span className="text-neutral-600">Mood: </span>
                          <span className="font-semibold text-neutral-900">{session.mood_after}/10</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  )
}