import React, { useEffect, useState } from 'react'
import { Calendar, Clock, Users, Video, FileText, TrendingUp, AlertCircle } from 'lucide-react'
import { Layout } from '@/components/Layout'
import { Link } from 'react-router-dom'
import { getDemoProviderAppointments, getDemoProviderSessions, getDemoProviderProfile } from '@/lib/publicData'

export function ProviderDashboard() {
  const [upcomingAppointments, setUpcomingAppointments] = useState<any[]>([])
  const [recentSessions, setRecentSessions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  
  // Demo provider profile
  const demoProfile = getDemoProviderProfile()
  
  // Filter today's sessions
  const todaysSessions = upcomingAppointments.filter(apt => 
    new Date(apt.scheduled_at).toDateString() === new Date().toDateString()
  )

  useEffect(() => {
    loadDashboardData()
  }, [])

  async function loadDashboardData() {
    try {
      const [appointments, sessions] = await Promise.all([
        getDemoProviderAppointments(),
        getDemoProviderSessions()
      ])
      
      setUpcomingAppointments(appointments)
      setRecentSessions(sessions)
    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Layout className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-neutral-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
            <div className="h-32 bg-neutral-200 rounded-xl"></div>
          </div>
        </div>
      </Layout>
    )
  }

  return (
    <Layout className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neutral-900 mb-2">
            Good morning, Dr. {demoProfile.last_name}! 🌅
          </h1>
          <p className="text-neutral-600">
            Your practice overview for {new Date().toLocaleDateString()}
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Today's Sessions</p>
                <p className="text-2xl font-bold text-neutral-900">{todaysSessions.length}</p>
              </div>
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-primary-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Active Clients</p>
                <p className="text-2xl font-bold text-neutral-900">24</p>
              </div>
              <div className="w-12 h-12 bg-secondary-100 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">This Week</p>
                <p className="text-2xl font-bold text-neutral-900">18 sessions</p>
              </div>
              <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-soft border border-neutral-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Pending Notes</p>
                <p className="text-2xl font-bold text-neutral-900">3</p>
              </div>
              <div className="w-12 h-12 bg-therapeutic-warmth/20 rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Schedule */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-neutral-900">Today's Schedule</h2>
                <Link
                  to="/provider/schedule"
                  className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
                >
                  View full schedule
                </Link>
              </div>

              {todaysSessions.length > 0 ? (
                <div className="space-y-4">
                  {todaysSessions.map((appointment) => (
                    <div key={appointment.id} className="flex items-center p-4 bg-therapeutic-safety rounded-lg">
                      <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mr-4">
                        <Video className="w-6 h-6 text-primary-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-neutral-900">
                          {appointment.appointment_type.replace('_', ' ')}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-neutral-600">
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {new Date(appointment.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <span>{appointment.duration_minutes} min</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          appointment.status === 'confirmed' 
                            ? 'bg-secondary-100 text-secondary-700'
                            : 'bg-neutral-100 text-neutral-700'
                        }`}>
                          {appointment.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-neutral-900 mb-2">No sessions today</h3>
                  <p className="text-neutral-600">Enjoy your day off or check your upcoming schedule.</p>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions & Alerts */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
              <h2 className="text-xl font-bold text-neutral-900 mb-6">Quick Actions</h2>
              <div className="space-y-3">
                <Link
                  to="/provider/clients"
                  className="flex items-center p-3 bg-primary-50 rounded-lg hover:bg-primary-100 transition-colors group"
                >
                  <Users className="w-5 h-5 text-primary-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-primary-700">Manage Clients</span>
                </Link>
                
                <Link
                  to="/provider/schedule"
                  className="flex items-center p-3 bg-secondary-50 rounded-lg hover:bg-secondary-100 transition-colors group"
                >
                  <Calendar className="w-5 h-5 text-secondary-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-secondary-700">Schedule Management</span>
                </Link>
                
                <Link
                  to="/provider/notes"
                  className="flex items-center p-3 bg-accent-50 rounded-lg hover:bg-accent-100 transition-colors group"
                >
                  <FileText className="w-5 h-5 text-accent-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-accent-700">Session Notes</span>
                </Link>
                
                <Link
                  to="/provider/sessions"
                  className="flex items-center p-3 bg-therapeutic-peace/20 rounded-lg hover:bg-therapeutic-peace/30 transition-colors group"
                >
                  <Video className="w-5 h-5 text-secondary-600 mr-3" />
                  <span className="font-medium text-neutral-900 group-hover:text-secondary-700">Session History</span>
                </Link>
              </div>
            </div>

            {/* Alerts & Notifications */}
            <div className="bg-gradient-to-br from-crisis-low to-therapeutic-warmth rounded-xl p-6 border border-orange-200">
              <div className="flex items-center mb-4">
                <AlertCircle className="w-6 h-6 text-orange-600 mr-3" />
                <h2 className="text-xl font-bold text-neutral-900">Practice Alerts</h2>
              </div>
              <div className="space-y-3">
                <div className="bg-white/50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-neutral-900">Crisis Alert</p>
                  <p className="text-xs text-neutral-600">Client Jane D. flagged for follow-up</p>
                </div>
                <div className="bg-white/50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-neutral-900">Documentation</p>
                  <p className="text-xs text-neutral-600">3 session notes pending completion</p>
                </div>
                <div className="bg-white/50 p-3 rounded-lg">
                  <p className="text-sm font-medium text-neutral-900">License Renewal</p>
                  <p className="text-xs text-neutral-600">Due in 60 days</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Upcoming Appointments */}
        <div className="mt-8">
          <div className="bg-white rounded-xl shadow-soft border border-neutral-100 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-neutral-900">Upcoming Appointments</h2>
              <Link
                to="/provider/schedule"
                className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
              >
                View all
              </Link>
            </div>

            {upcomingAppointments.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {upcomingAppointments.slice(0, 6).map((appointment) => (
                  <div key={appointment.id} className="p-4 bg-therapeutic-safety rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-neutral-900 capitalize">
                        {appointment.appointment_type.replace('_', ' ')}
                      </h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        appointment.status === 'confirmed' 
                          ? 'bg-secondary-100 text-secondary-700'
                          : 'bg-neutral-100 text-neutral-700'
                      }`}>
                        {appointment.status}
                      </span>
                    </div>
                    <div className="space-y-1 text-sm text-neutral-600">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2" />
                        {new Date(appointment.scheduled_at).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        {new Date(appointment.scheduled_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-neutral-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">No upcoming appointments</h3>
                <p className="text-neutral-600">Your schedule is clear for the coming days.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  )
}