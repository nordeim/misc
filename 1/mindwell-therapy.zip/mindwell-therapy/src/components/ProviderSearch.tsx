import React, { useState, useEffect } from 'react'
import { Search, MapPin, Star, Users, Calendar, Shield, Filter } from 'lucide-react'
import { getDemoProviders } from '@/lib/publicData'

interface Provider {
  id: string
  user_id: string
  first_name: string
  last_name: string
  credentials?: {
    specialties: string[]
    bio?: string
    years_experience?: number
    languages: string[]
    insurance_accepted: string[]
    is_accepting_new_clients: boolean
  }
  matchScore?: number
  matchReasons?: string[]
  isRecommended?: boolean
}

interface ProviderSearchProps {
  insuranceCompany?: string
  className?: string
}

export function ProviderSearch({ insuranceCompany, className = '' }: ProviderSearchProps) {
  const [providers, setProviders] = useState<Provider[]>([])
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>([])
  const [locationFilter, setLocationFilter] = useState('')

  const specialtyOptions = [
    'Anxiety Disorders',
    'Depression',
    'PTSD/Trauma',
    'Relationship Counseling',
    'Family Therapy',
    'Addiction Recovery',
    'Eating Disorders',
    'ADHD',
    'Bipolar Disorder',
    'Grief Counseling',
    'Stress Management',
    'Sleep Disorders'
  ]

  useEffect(() => {
    searchProviders()
  }, [selectedSpecialties, insuranceCompany])

  async function searchProviders() {
    setLoading(true)
    
    try {
      // Get real providers from database
      const providersData = await getDemoProviders()
      
      // Transform and filter providers based on search criteria
      let filteredProviders = providersData.map(provider => ({
        ...provider,
        // Add match scoring for demo purposes
        matchScore: calculateMatchScore(provider, insuranceCompany, selectedSpecialties),
        matchReasons: getMatchReasons(provider, insuranceCompany, selectedSpecialties),
        isRecommended: provider.credentials?.is_accepting_new_clients && 
                      provider.credentials?.insurance_accepted?.includes(insuranceCompany || 'Blue Cross Blue Shield')
      }))
      
      if (selectedSpecialties.length > 0) {
        filteredProviders = filteredProviders.filter(provider => 
          provider.credentials?.specialties?.some(specialty => 
            selectedSpecialties.includes(specialty)
          )
        )
      }
      
      if (insuranceCompany) {
        filteredProviders = filteredProviders.filter(provider => 
          provider.credentials?.insurance_accepted?.includes(insuranceCompany)
        )
      }
      
      setProviders(filteredProviders)
    } catch (error) {
      console.error('Provider search error:', error)
    } finally {
      setLoading(false)
    }
  }

  function calculateMatchScore(provider: any, insurance?: string, specialties: string[] = []): number {
    let score = 70 // Base score
    
    if (insurance && provider.credentials?.insurance_accepted?.includes(insurance)) {
      score += 20
    }
    
    if (specialties.length > 0 && provider.credentials?.specialties?.some(s => specialties.includes(s))) {
      score += 15
    }
    
    if (provider.credentials?.is_accepting_new_clients) {
      score += 10
    }
    
    return Math.min(score, 100)
  }

  function getMatchReasons(provider: any, insurance?: string, specialties: string[] = []): string[] {
    const reasons = []
    
    if (insurance && provider.credentials?.insurance_accepted?.includes(insurance)) {
      reasons.push('Insurance match')
    }
    
    if (specialties.length > 0 && provider.credentials?.specialties?.some(s => specialties.includes(s))) {
      reasons.push('Specialty match')
    }
    
    if (provider.credentials?.is_accepting_new_clients) {
      reasons.push('Accepting new clients')
    }
    
    return reasons
  }

  const filteredProviders = providers.filter(provider => {
    const nameMatch = `${provider.first_name} ${provider.last_name}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
    
    const specialtyMatch = selectedSpecialties.length === 0 || 
      selectedSpecialties.some(specialty => 
        provider.credentials?.specialties?.includes(specialty)
      )

    return nameMatch && specialtyMatch
  })

  return (
    <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 ${className}`}>
      {/* Search Header */}
      <div className="p-6 border-b border-neutral-100">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-neutral-900">Find Your Therapist</h2>
          {insuranceCompany && (
            <div className="flex items-center space-x-2 bg-secondary-50 px-3 py-2 rounded-lg">
              <Shield className="w-4 h-4 text-secondary-600" />
              <span className="text-sm font-medium text-secondary-700">{insuranceCompany} Network</span>
            </div>
          )}
        </div>

        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input
            type="text"
            placeholder="Search by therapist name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-3 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
          />
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">
              <Filter className="w-4 h-4 inline mr-1" />
              Specialties
            </label>
            <select
              multiple
              value={selectedSpecialties}
              onChange={(e) => {
                const values = Array.from(e.target.selectedOptions, option => option.value)
                setSelectedSpecialties(values)
              }}
              className="w-full border border-neutral-300 rounded-lg p-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              size={4}
            >
              {specialtyOptions.map(specialty => (
                <option key={specialty} value={specialty}>
                  {specialty}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">
              <MapPin className="w-4 h-4 inline mr-1" />
              Location
            </label>
            <input
              type="text"
              placeholder="Enter state (e.g., CA, NY, TX)"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Provider Results */}
      <div className="p-6">
        {loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse p-6 bg-neutral-50 rounded-lg">
                <div className="flex space-x-4">
                  <div className="w-16 h-16 bg-neutral-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-neutral-200 rounded w-1/4"></div>
                    <div className="h-3 bg-neutral-200 rounded w-1/2"></div>
                    <div className="h-3 bg-neutral-200 rounded w-3/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredProviders.length > 0 ? (
          <div className="space-y-6">
            {filteredProviders.map((provider) => (
              <div key={provider.id} className="p-6 bg-therapeutic-safety rounded-lg hover:shadow-soft transition-shadow">
                <div className="flex flex-col md:flex-row md:items-start space-y-4 md:space-y-0 md:space-x-6">
                  {/* Provider Avatar */}
                  <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl font-bold text-primary-600">
                      {provider.first_name[0]}{provider.last_name[0]}
                    </span>
                  </div>

                  {/* Provider Info */}
                  <div className="flex-1">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold text-neutral-900">
                          Dr. {provider.first_name} {provider.last_name}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-neutral-600 mt-1">
                          {provider.credentials?.years_experience && (
                            <span className="flex items-center">
                              <Users className="w-4 h-4 mr-1" />
                              {provider.credentials.years_experience} years experience
                            </span>
                          )}
                          {provider.isRecommended && (
                            <span className="bg-secondary-100 text-secondary-700 px-2 py-1 rounded-full text-xs font-medium">
                              <Star className="w-3 h-3 inline mr-1" />
                              Recommended
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 mt-2 md:mt-0">
                        {provider.credentials?.is_accepting_new_clients && (
                          <span className="bg-secondary-100 text-secondary-700 px-3 py-1 rounded-full text-sm font-medium">
                            Accepting new clients
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Specialties */}
                    {provider.credentials?.specialties && (
                      <div className="mb-3">
                        <p className="text-sm font-medium text-neutral-700 mb-2">Specialties:</p>
                        <div className="flex flex-wrap gap-2">
                          {provider.credentials.specialties.slice(0, 4).map((specialty, index) => (
                            <span
                              key={index}
                              className="bg-primary-50 text-primary-700 px-3 py-1 rounded-full text-sm"
                            >
                              {specialty}
                            </span>
                          ))}
                          {provider.credentials.specialties.length > 4 && (
                            <span className="text-neutral-500 text-sm">+{provider.credentials.specialties.length - 4} more</span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Bio */}
                    {provider.credentials?.bio && (
                      <p className="text-neutral-600 text-sm mb-4 line-clamp-2">
                        {provider.credentials.bio}
                      </p>
                    )}

                    {/* Match Reasons */}
                    {provider.matchReasons && provider.matchReasons.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm font-medium text-neutral-700 mb-2">Why this is a good match:</p>
                        <div className="flex flex-wrap gap-2">
                          {provider.matchReasons.map((reason, index) => (
                            <span
                              key={index}
                              className="bg-therapeutic-calm/20 text-primary-700 px-2 py-1 rounded text-xs"
                            >
                              {reason}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Insurance Information */}
                    {provider.credentials?.insurance_accepted && (
                      <div className="mb-3">
                        <p className="text-sm font-medium text-neutral-700 mb-2">Accepts Insurance:</p>
                        <div className="flex flex-wrap gap-2">
                          {provider.credentials.insurance_accepted.slice(0, 3).map((insurance, index) => (
                            <span
                              key={index}
                              className={`px-2 py-1 rounded text-xs ${
                                insurance === insuranceCompany
                                  ? 'bg-green-100 text-green-700 font-medium'
                                  : 'bg-neutral-100 text-neutral-600'
                              }`}
                            >
                              {insurance}
                            </span>
                          ))}
                          {provider.credentials.insurance_accepted.length > 3 && (
                            <span className="text-neutral-500 text-xs">+{provider.credentials.insurance_accepted.length - 3} more</span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Languages & Insurance Status */}
                    <div className="flex flex-col md:flex-row md:items-center md:space-x-6 space-y-2 md:space-y-0 text-sm text-neutral-600">
                      {provider.credentials?.languages && (
                        <span>Languages: {provider.credentials.languages.join(', ')}</span>
                      )}
                      {insuranceCompany && provider.credentials?.insurance_accepted?.includes(insuranceCompany) && (
                        <span className="flex items-center text-green-600 font-medium">
                          <Shield className="w-4 h-4 mr-1" />
                          In-network with {insuranceCompany}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="flex-shrink-0">
                    <button className="w-full md:w-auto bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 transition-colors font-medium flex items-center justify-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Book Appointment
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-neutral-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-neutral-900 mb-2">No providers found</h3>
            <p className="text-neutral-600 mb-4">
              Try adjusting your search criteria or removing some filters.
            </p>
            <button
              onClick={() => {
                setSelectedSpecialties([])
                setLocationFilter('')
                setSearchTerm('')
              }}
              className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </div>
  )
}