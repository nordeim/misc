import React from 'react'
import { Link } from 'react-router-dom'

interface LayoutProps {
  children: React.ReactNode
  className?: string
}

export function Layout({ children, className = '' }: LayoutProps) {
  // Simple layout without authentication - direct access to all features
  return (
    <div className="min-h-screen bg-therapeutic-safety">
      <main className={`min-h-screen ${className}`}>
        {children}
      </main>
    </div>
  )
}

export function PublicLayout({ children, className = '' }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-therapeutic-safety via-white to-primary-50">
      <header className="bg-white/80 backdrop-blur-sm border-b border-neutral-200/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-neutral-900">AT-AI</h1>
                <p className="text-sm text-neutral-600">Therapy Platform</p>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-neutral-700 hover:text-primary-600 font-medium transition-colors">
                Features
              </a>
              <a href="#how-it-works" className="text-neutral-700 hover:text-primary-600 font-medium transition-colors">
                How It Works
              </a>
              <Link to="/client" className="text-primary-600 hover:text-primary-700 font-medium transition-colors">
                Client Portal
              </Link>
              <Link to="/provider" className="bg-primary-500 text-white px-6 py-2 rounded-lg hover:bg-primary-600 transition-colors font-medium">
                Provider Portal
              </Link>
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Link to="/client" className="text-primary-600 hover:text-primary-700 font-medium transition-colors mr-4">
                Try App
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className={className}>
        {children}
      </main>

      <footer className="bg-neutral-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                  </svg>
                </div>
                <span className="text-xl font-bold">AT-AI</span>
              </div>
              <p className="text-neutral-400 max-w-md">
                HIPAA-compliant mental health platform connecting clients with licensed therapists. 
                Secure, accessible, and designed for healing.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">For Clients</h3>
              <ul className="space-y-2 text-neutral-400">
                <li><Link to="/client" className="hover:text-white transition-colors">Find Therapists</Link></li>
                <li><Link to="/client/insurance" className="hover:text-white transition-colors">Insurance Coverage</Link></li>
                <li><Link to="/client" className="hover:text-white transition-colors">Crisis Support</Link></li>
                <li><Link to="/client" className="hover:text-white transition-colors">Session History</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">For Providers</h3>
              <ul className="space-y-2 text-neutral-400">
                <li><Link to="/provider" className="hover:text-white transition-colors">Practice Management</Link></li>
                <li><Link to="/provider" className="hover:text-white transition-colors">Session Tools</Link></li>
                <li><Link to="/provider" className="hover:text-white transition-colors">Documentation</Link></li>
                <li><Link to="/provider" className="hover:text-white transition-colors">Credentialing</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-neutral-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-neutral-400 text-sm">
              © 2025 AT-AI Therapy Platform. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">HIPAA Notice</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}