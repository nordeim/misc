import React from 'react'
import { Heart, Shield, Users, Video, FileText, Calendar, UserCheck, Phone } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'

interface NavigationProps {
  className?: string
}

export function Navigation({ className = '' }: NavigationProps) {
  const location = useLocation()
  
  // Determine user type based on current path for demo purposes
  const isProvider = location.pathname.startsWith('/provider')
  const isClient = location.pathname.startsWith('/client')

  const providerNavItems = [
    { name: 'Dashboard', href: '/provider/dashboard', icon: Users },
    { name: 'Clients', href: '/provider/clients', icon: UserCheck },
    { name: 'Schedule', href: '/provider/schedule', icon: Calendar },
    { name: 'Sessions', href: '/provider/sessions', icon: Video },
    { name: 'Notes', href: '/provider/notes', icon: FileText },
  ]

  const clientNavItems = [
    { name: 'Dashboard', href: '/client/dashboard', icon: Heart },
    { name: 'Find Providers', href: '/client/find-providers', icon: Users },
    { name: 'Appointments', href: '/client/appointments', icon: Calendar },
    { name: 'Sessions', href: '/client/sessions', icon: Video },
    { name: 'Insurance', href: '/client/insurance', icon: Shield },
    { name: 'Crisis Support', href: '/client/crisis-support', icon: Phone },
  ]

  const navItems = isProvider ? providerNavItems : isClient ? clientNavItems : []

  const isActive = (href: string) => location.pathname === href

  return (
    <nav className={`bg-therapeutic-safety border-r border-neutral-200 ${className}`}>
      <div className="p-6">
        <Link to="/" className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-neutral-900">AT-AI</h1>
            <p className="text-sm text-neutral-600">Therapy Platform</p>
          </div>
        </Link>

        {/* User Profile Section - Demo Mode */}
        {(isProvider || isClient) && (
          <div className="mb-8 p-4 bg-white rounded-xl shadow-soft">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                <span className="text-primary-600 font-semibold text-lg">
                  {isProvider ? 'DS' : 'AC'}
                </span>
              </div>
              <div>
                <p className="font-semibold text-neutral-900">
                  {isProvider ? 'Dr. Smith' : 'Alex Chen'}
                </p>
                <p className="text-sm text-neutral-600 capitalize">
                  {isProvider ? 'Provider' : 'Client'}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive(item.href)
                    ? 'bg-primary-500 text-white shadow-therapeutic'
                    : 'text-neutral-700 hover:bg-white hover:shadow-soft'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </Link>
            )
          })}
        </div>

        {/* Back to Home Option */}
        {(isProvider || isClient) && (
          <div className="mt-8 pt-6 border-t border-neutral-200">
            <Link
              to="/"
              className="w-full flex items-center justify-center px-4 py-3 text-sm font-medium text-neutral-700 hover:text-neutral-900 hover:bg-white rounded-lg transition-colors duration-200"
            >
              Back to Home
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}

export function MobileNavigation() {
  const location = useLocation()

  // Determine user type based on current path for demo purposes
  const isProvider = location.pathname.startsWith('/provider')
  const isClient = location.pathname.startsWith('/client')

  const providerNavItems = [
    { name: 'Dashboard', href: '/provider/dashboard', icon: Users },
    { name: 'Schedule', href: '/provider/schedule', icon: Calendar },
    { name: 'Sessions', href: '/provider/sessions', icon: Video },
    { name: 'Notes', href: '/provider/notes', icon: FileText },
  ]

  const clientNavItems = [
    { name: 'Home', href: '/client/dashboard', icon: Heart },
    { name: 'Providers', href: '/client/find-providers', icon: Users },
    { name: 'Sessions', href: '/client/sessions', icon: Video },
    { name: 'Support', href: '/client/crisis-support', icon: Phone },
  ]

  const navItems = isProvider ? providerNavItems : isClient ? clientNavItems : []

  const isActive = (href: string) => location.pathname === href

  // Only show mobile nav when in app sections
  if (!isProvider && !isClient) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 z-50 md:hidden">
      <div className="flex">
        {navItems.map((item) => {
          const Icon = item.icon
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`flex-1 flex flex-col items-center justify-center py-2 px-1 transition-colors duration-200 ${
                isActive(item.href)
                  ? 'text-primary-600'
                  : 'text-neutral-600'
              }`}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs font-medium">{item.name}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}