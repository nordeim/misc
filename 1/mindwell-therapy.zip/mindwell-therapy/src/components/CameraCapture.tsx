import React, { useRef, useState, useCallback } from 'react'
import { Camera, X, RotateCcw, CheckCircle, AlertCircle } from 'lucide-react'

interface CameraCaptureProps {
  onCapture: (imageData: string) => void
  onCancel: () => void
  className?: string
}

export function CameraCapture({ onCapture, onCancel, className = '' }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [isStreaming, setIsStreaming] = useState(false)
  const [error, setError] = useState('')
  const [capturedImage, setCapturedImage] = useState<string | null>(null)

  const startCamera = useCallback(async () => {
    try {
      setError('')
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Use back camera on mobile
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      })
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        videoRef.current.play()
        setStream(mediaStream)
        setIsStreaming(true)
      }
    } catch (err) {
      console.error('Camera access error:', err)
      setError('Unable to access camera. Please ensure camera permissions are granted.')
    }
  }, [])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
      setStream(null)
      setIsStreaming(false)
    }
  }, [stream])

  const captureImage = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')

    if (!context) return

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Draw the current video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Convert to base64 image data
    const imageData = canvas.toDataURL('image/jpeg', 0.9)
    setCapturedImage(imageData)
  }, [])

  const confirmCapture = useCallback(() => {
    if (capturedImage) {
      stopCamera()
      onCapture(capturedImage)
    }
  }, [capturedImage, stopCamera, onCapture])

  const retakePhoto = useCallback(() => {
    setCapturedImage(null)
  }, [])

  const handleCancel = useCallback(() => {
    stopCamera()
    onCancel()
  }, [stopCamera, onCancel])

  React.useEffect(() => {
    startCamera()
    return () => stopCamera()
  }, [startCamera, stopCamera])

  return (
    <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-neutral-900">Scan Insurance Card</h3>
        <button
          onClick={handleCancel}
          className="text-neutral-400 hover:text-neutral-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {error ? (
        <div className="text-center py-8">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h4 className="text-lg font-semibold text-neutral-900 mb-2">Camera Access Error</h4>
          <p className="text-neutral-600 mb-4">{error}</p>
          <button
            onClick={startCamera}
            className="bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 transition-colors"
          >
            Try Again
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Camera Guidelines */}
          <div className="bg-therapeutic-safety p-4 rounded-lg">
            <h4 className="font-semibold text-neutral-900 mb-2">Scanning Tips:</h4>
            <ul className="text-sm text-neutral-600 space-y-1">
              <li>• Ensure good lighting on your insurance card</li>
              <li>• Hold the card flat and steady</li>
              <li>• Make sure all text is clearly visible</li>
              <li>• Avoid shadows and glare</li>
            </ul>
          </div>

          {/* Camera Interface */}
          <div className="relative bg-neutral-900 rounded-lg overflow-hidden">
            {capturedImage ? (
              // Show captured image for confirmation
              <div className="relative">
                <img
                  src={capturedImage}
                  alt="Captured insurance card"
                  className="w-full h-auto max-h-96 object-contain"
                />
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                  <div className="text-center">
                    <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                    <p className="text-white text-lg font-semibold mb-4">Image Captured!</p>
                    <div className="flex space-x-4">
                      <button
                        onClick={retakePhoto}
                        className="flex items-center space-x-2 bg-neutral-600 text-white px-4 py-2 rounded-lg hover:bg-neutral-700 transition-colors"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Retake</span>
                      </button>
                      <button
                        onClick={confirmCapture}
                        className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Use Photo</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              // Live camera feed
              <div className="relative">
                <video
                  ref={videoRef}
                  className="w-full h-auto max-h-96 object-contain"
                  autoPlay
                  muted
                  playsInline
                />
                
                {/* Card outline guide */}
                <div className="absolute inset-4 border-2 border-dashed border-white opacity-60 rounded-lg flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="text-sm font-medium mb-1">Position your insurance card here</div>
                    <div className="text-xs opacity-80">Fill the frame as much as possible</div>
                  </div>
                </div>

                {/* Capture button */}
                {isStreaming && (
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                    <button
                      onClick={captureImage}
                      className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-neutral-100 transition-colors"
                    >
                      <Camera className="w-8 h-8 text-neutral-700" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Hidden canvas for image processing */}
          <canvas ref={canvasRef} className="hidden" />

          {!isStreaming && !error && (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-neutral-600">Starting camera...</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
