import React, { useState, useRef } from 'react'
import { Camera, Upload, X, CheckCircle, AlertCircle, Loader2, Edit } from 'lucide-react'
import { CameraCapture } from './CameraCapture'
import { ocrService, InsuranceCardData } from '@/lib/ocrService'
import { supabase } from '@/lib/supabase'
import { DEMO_CLIENT_ID } from '@/lib/publicData'

interface InsuranceCardScannerProps {
  onScanComplete?: (insuranceData: any) => void
  className?: string
}

type ScannerState = 'idle' | 'camera' | 'processing' | 'review' | 'complete'

export function InsuranceCardScanner({ onScanComplete, className = '' }: InsuranceCardScannerProps) {
  const [state, setState] = useState<ScannerState>('idle')
  const [ocrResult, setOcrResult] = useState<InsuranceCardData | null>(null)
  const [editableData, setEditableData] = useState<Partial<InsuranceCardData>>({})
  const [error, setError] = useState('')
  const [processingProgress, setProcessingProgress] = useState(0)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [saveLoading, setSaveLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = async (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const imageData = e.target?.result as string
      processImage(imageData)
    }
    reader.readAsDataURL(file)
  }

  const handleCameraCapture = (imageData: string) => {
    setCapturedImage(imageData)
    setState('camera')
    processImage(imageData)
  }

  const processImage = async (imageData: string) => {
    setState('processing')
    setError('')
    setProcessingProgress(0)

    try {
      // Initialize OCR service
      await ocrService.initialize()
      setProcessingProgress(25)

      // Process the image
      const result = await ocrService.processInsuranceCard(imageData)
      setProcessingProgress(75)

      console.log('OCR Result:', result)
      setOcrResult(result)
      setEditableData({
        insuranceCompany: result.insuranceCompany,
        memberID: result.memberID,
        groupNumber: result.groupNumber,
        planName: result.planName,
        copayAmount: result.copayAmount,
        phoneNumber: result.phoneNumber
      })
      
      setProcessingProgress(100)
      setState('review')
    } catch (err: any) {
      console.error('OCR processing error:', err)
      setError(err.message || 'Failed to process insurance card. Please try again.')
      setState('idle')
    }
  }

  const handleSaveInsuranceData = async () => {
    try {
      setSaveLoading(true)
      setError('')

      // Save to database
      const insurancePlan = {
        client_id: DEMO_CLIENT_ID,
        insurance_company: editableData.insuranceCompany || 'Unknown',
        plan_name: editableData.planName || 'Unknown Plan',
        member_id: editableData.memberID || '',
        group_number: editableData.groupNumber || '',
        copay_amount: editableData.copayAmount ? parseInt(editableData.copayAmount.replace(/\D/g, '')) : null,
        phone_number: editableData.phoneNumber || '',
        verification_status: 'pending',
        card_image_url: capturedImage,
        ocr_confidence: ocrResult?.confidence || 0,
        raw_ocr_text: ocrResult?.rawText || ''
      }

      const { data, error: insertError } = await supabase
        .from('insurance_plans')
        .insert([insurancePlan])
        .select()
        .single()

      if (insertError) {
        throw new Error(insertError.message)
      }

      setState('complete')
      
      if (onScanComplete) {
        onScanComplete({
          insurancePlan: data,
          ocrResults: editableData
        })
      }
    } catch (err: any) {
      console.error('Save error:', err)
      setError(err.message || 'Failed to save insurance information')
    } finally {
      setSaveLoading(false)
    }
  }

  const resetScanner = () => {
    setState('idle')
    setOcrResult(null)
    setEditableData({})
    setError('')
    setProcessingProgress(0)
    setCapturedImage(null)
    setSaveLoading(false)
  }

  const startCamera = () => {
    setState('camera')
    setError('')
  }

  const cancelCamera = () => {
    setState('idle')
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  if (state === 'camera') {
    return (
      <CameraCapture
        onCapture={handleCameraCapture}
        onCancel={cancelCamera}
        className={className}
      />
    )
  }

  if (state === 'processing') {
    return (
      <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 p-6 ${className}`}>
        <div className="text-center py-8">
          <Loader2 className="w-12 h-12 text-primary-500 mx-auto mb-4 animate-spin" />
          <h3 className="text-xl font-bold text-neutral-900 mb-2">Processing Insurance Card</h3>
          <p className="text-neutral-600 mb-4">Extracting information from your card...</p>
          
          <div className="w-full bg-neutral-200 rounded-full h-2 mb-4">
            <div 
              className="bg-primary-500 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${processingProgress}%` }}
            ></div>
          </div>
          
          <p className="text-sm text-neutral-500">
            {processingProgress < 25 && 'Initializing OCR engine...'}
            {processingProgress >= 25 && processingProgress < 75 && 'Reading text from image...'}
            {processingProgress >= 75 && processingProgress < 100 && 'Parsing insurance information...'}
            {processingProgress === 100 && 'Almost done!'}
          </p>
        </div>
      </div>
    )
  }

  if (state === 'review' && ocrResult) {
    return (
      <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 p-6 ${className}`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-secondary-600" />
            </div>
            <h3 className="text-xl font-bold text-neutral-900">Review Extracted Information</h3>
          </div>
          <button
            onClick={resetScanner}
            className="text-neutral-400 hover:text-neutral-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-6">
          <div className="bg-therapeutic-safety p-4 rounded-lg mb-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertCircle className="w-4 h-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-700">Please verify the information below</span>
            </div>
            <p className="text-sm text-orange-600">
              OCR confidence: {Math.round(ocrResult.confidence)}%. Please check and correct any errors.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Insurance Company</label>
              <input
                type="text"
                value={editableData.insuranceCompany || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, insuranceCompany: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="Enter insurance company name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Plan Name</label>
              <input
                type="text"
                value={editableData.planName || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, planName: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="Enter plan name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Member ID</label>
              <input
                type="text"
                value={editableData.memberID || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, memberID: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="Enter member ID"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Group Number</label>
              <input
                type="text"
                value={editableData.groupNumber || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, groupNumber: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="Enter group number"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Copay Amount</label>
              <input
                type="text"
                value={editableData.copayAmount || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, copayAmount: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="e.g., $25"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Phone Number</label>
              <input
                type="text"
                value={editableData.phoneNumber || ''}
                onChange={(e) => setEditableData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                className="w-full border border-neutral-300 rounded-lg p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors"
                placeholder="Customer service phone"
              />
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Error</span>
            </div>
            <p className="text-sm text-red-600 mt-1">{error}</p>
          </div>
        )}

        <div className="flex space-x-4">
          <button
            onClick={resetScanner}
            className="flex-1 bg-neutral-100 text-neutral-700 py-3 px-6 rounded-lg font-medium hover:bg-neutral-200 transition-colors"
          >
            Scan Again
          </button>
          <button
            onClick={handleSaveInsuranceData}
            disabled={saveLoading}
            className="flex-1 bg-primary-500 text-white py-3 px-6 rounded-lg font-medium hover:bg-primary-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saveLoading ? 'Saving...' : 'Save Information'}
          </button>
        </div>
      </div>
    )
  }

  if (state === 'complete') {
    return (
      <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 p-6 ${className}`}>
        <div className="text-center py-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-neutral-900 mb-2">Insurance Card Scanned Successfully!</h3>
          <p className="text-neutral-600 mb-6">
            Your insurance information has been saved and verified. You can now search for in-network providers.
          </p>
          <button
            onClick={resetScanner}
            className="bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 transition-colors font-medium"
          >
            Scan Another Card
          </button>
        </div>
      </div>
    )
  }

  // Default idle state
  return (
    <div className={`bg-white rounded-xl shadow-soft border border-neutral-100 p-6 ${className}`}>
      <div className="text-center">
        <h3 className="text-xl font-bold text-neutral-900 mb-4">Scan Your Insurance Card</h3>
        <p className="text-neutral-600 mb-6">
          Use your camera or upload a photo to automatically extract your insurance information.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <button
            onClick={startCamera}
            className="flex flex-col items-center p-6 border-2 border-dashed border-primary-300 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors group"
          >
            <Camera className="w-12 h-12 text-primary-500 mb-3 group-hover:text-primary-600" />
            <span className="font-semibold text-neutral-900 mb-1">Use Camera</span>
            <span className="text-sm text-neutral-600">Take a photo of your card</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center p-6 border-2 border-dashed border-secondary-300 rounded-lg hover:border-secondary-500 hover:bg-secondary-50 transition-colors group"
          >
            <Upload className="w-12 h-12 text-secondary-500 mb-3 group-hover:text-secondary-600" />
            <span className="font-semibold text-neutral-900 mb-1">Upload Photo</span>
            <span className="text-sm text-neutral-600">Choose from your device</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Error</span>
            </div>
            <p className="text-sm text-red-600 mt-1">{error}</p>
          </div>
        )}

        <div className="bg-therapeutic-safety p-4 rounded-lg">
          <h4 className="font-semibold text-neutral-900 mb-2">Tips for best results:</h4>
          <ul className="text-sm text-neutral-600 space-y-1 text-left">
            <li>• Ensure good lighting and avoid shadows</li>
            <li>• Keep the card flat and all text visible</li>
            <li>• Make sure the image is clear and not blurry</li>
            <li>• Include the entire front of your insurance card</li>
          </ul>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
    </div>
  )
}
