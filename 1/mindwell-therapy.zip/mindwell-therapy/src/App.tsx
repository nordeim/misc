import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { LandingPage } from '@/pages/LandingPage'
import { ClientDashboard } from '@/pages/client/ClientDashboard'
import { ClientInsurancePage } from '@/pages/client/ClientInsurancePage'
import { ProviderDashboard } from '@/pages/provider/ProviderDashboard'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          {/* Public Routes - Direct Access */}
          <Route path="/" element={<LandingPage />} />
          
          {/* Direct Dashboard Access */}
          <Route path="/client" element={<ClientDashboard />} />
          <Route path="/client/dashboard" element={<ClientDashboard />} />
          <Route path="/client/insurance" element={<ClientInsurancePage />} />
          
          <Route path="/provider" element={<ProviderDashboard />} />
          <Route path="/provider/dashboard" element={<ProviderDashboard />} />
          
          {/* Legacy redirects */}
          <Route path="/dashboard" element={<Navigate to="/client" replace />} />
          <Route path="/auth/*" element={<Navigate to="/" replace />} />
          
          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </QueryClientProvider>
  )
}

export default App