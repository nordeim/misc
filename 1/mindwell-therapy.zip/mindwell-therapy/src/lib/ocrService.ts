import { createWorker, Worker } from 'tesseract.js'

export interface InsuranceCardData {
  insuranceCompany?: string
  memberID?: string
  groupNumber?: string
  planName?: string
  copayAmount?: string
  deductible?: string
  phoneNumber?: string
  rxBin?: string
  rxPcn?: string
  rawText: string
  confidence: number
}

export class OCRService {
  private worker: Worker | null = null
  private isInitialized = false

  async initialize(): Promise<void> {
    if (this.isInitialized) return

    try {
      this.worker = await createWorker('eng', 1, {
        logger: m => {
          if (m.status === 'recognizing text') {
            console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`)
          }
        }
      })
      
      await this.worker.setParameters({
        tessedit_char_whitelist: '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()-.,'
      })
      
      this.isInitialized = true
    } catch (error) {
      console.error('OCR initialization failed:', error)
      throw new Error('Failed to initialize OCR engine')
    }
  }

  async processInsuranceCard(imageData: string): Promise<InsuranceCardData> {
    if (!this.worker) {
      await this.initialize()
    }

    if (!this.worker) {
      throw new Error('OCR worker not initialized')
    }

    try {
      const { data } = await this.worker.recognize(imageData)
      const extractedData = this.parseInsuranceText(data.text, data.confidence)
      
      return extractedData
    } catch (error) {
      console.error('OCR processing failed:', error)
      throw new Error('Failed to process insurance card image')
    }
  }

  private parseInsuranceText(text: string, confidence: number): InsuranceCardData {
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0)
    const upperText = text.toUpperCase()
    
    console.log('OCR Raw Text:', text)
    console.log('OCR Confidence:', confidence)

    const result: InsuranceCardData = {
      rawText: text,
      confidence: confidence
    }

    // Insurance Company Detection
    result.insuranceCompany = this.extractInsuranceCompany(upperText, lines)

    // Member ID Detection
    result.memberID = this.extractMemberID(upperText, lines)

    // Group Number Detection
    result.groupNumber = this.extractGroupNumber(upperText, lines)

    // Plan Name Detection
    result.planName = this.extractPlanName(upperText, lines)

    // Copay Amount Detection
    result.copayAmount = this.extractCopayAmount(upperText, lines)

    // Phone Number Detection
    result.phoneNumber = this.extractPhoneNumber(text)

    // RX Information
    result.rxBin = this.extractRxBin(upperText, lines)
    result.rxPcn = this.extractRxPcn(upperText, lines)

    return result
  }

  private extractInsuranceCompany(upperText: string, lines: string[]): string | undefined {
    const commonInsurers = [
      'BLUE CROSS BLUE SHIELD', 'BCBS', 'BLUE CROSS',
      'AETNA', 'CIGNA', 'UNITED HEALTHCARE', 'UNITEDHEALTHCARE',
      'ANTHEM', 'KAISER PERMANENTE', 'HUMANA', 'MOLINA',
      'WELLCARE', 'CENTENE', 'HEALTH NET', 'MEDICARE',
      'MEDICAID', 'TRICARE', 'OSCAR', 'BRIGHT HEALTH'
    ]

    for (const insurer of commonInsurers) {
      if (upperText.includes(insurer)) {
        return this.normalizeInsuranceName(insurer)
      }
    }

    // Look for company-like names in early lines
    for (let i = 0; i < Math.min(3, lines.length); i++) {
      const line = lines[i].toUpperCase()
      if (line.length > 5 && line.length < 50 && !line.match(/^[0-9]+/) && !line.includes('MEMBER')) {
        return line
      }
    }

    return undefined
  }

  private normalizeInsuranceName(name: string): string {
    const mapping: { [key: string]: string } = {
      'BCBS': 'Blue Cross Blue Shield',
      'BLUE CROSS': 'Blue Cross Blue Shield',
      'UNITEDHEALTHCARE': 'United Healthcare',
      'KAISER PERMANENTE': 'Kaiser Permanente'
    }
    return mapping[name] || name
  }

  private extractMemberID(upperText: string, lines: string[]): string | undefined {
    // Look for patterns like "MEMBER ID", "ID", "MEMBER #"
    const memberPatterns = [
      /MEMBER\s*(?:ID|#)?\s*:?\s*([A-Z0-9]{6,20})/i,
      /ID\s*:?\s*([A-Z0-9]{6,20})/i,
      /MEMBER\s*:?\s*([A-Z0-9]{6,20})/i,
      /^([A-Z0-9]{8,15})$/  // Standalone alphanumeric string
    ]

    for (const pattern of memberPatterns) {
      const match = upperText.match(pattern)
      if (match && match[1]) {
        return match[1]
      }
    }

    // Look in individual lines for ID-like strings
    for (const line of lines) {
      const cleanLine = line.replace(/[^A-Z0-9]/g, '')
      if (cleanLine.length >= 8 && cleanLine.length <= 15 && /[0-9]/.test(cleanLine) && /[A-Z]/.test(cleanLine)) {
        return cleanLine
      }
    }

    return undefined
  }

  private extractGroupNumber(upperText: string, lines: string[]): string | undefined {
    const groupPatterns = [
      /GROUP\s*(?:NUMBER|#)?\s*:?\s*([A-Z0-9]{3,15})/i,
      /GRP\s*:?\s*([A-Z0-9]{3,15})/i,
      /GROUP\s*:?\s*([A-Z0-9]{3,15})/i
    ]

    for (const pattern of groupPatterns) {
      const match = upperText.match(pattern)
      if (match && match[1]) {
        return match[1]
      }
    }

    return undefined
  }

  private extractPlanName(upperText: string, lines: string[]): string | undefined {
    const planPatterns = [
      /PLAN\s*:?\s*([A-Z\s]{3,30})/i,
      /(PPO|HMO|EPO|POS)\s*([A-Z\s]*)/i
    ]

    for (const pattern of planPatterns) {
      const match = upperText.match(pattern)
      if (match && match[1]) {
        return match[1].trim()
      }
    }

    return undefined
  }

  private extractCopayAmount(upperText: string, lines: string[]): string | undefined {
    const copayPatterns = [
      /COPAY\s*:?\s*\$?([0-9]{1,3})/i,
      /CO-?PAY\s*:?\s*\$?([0-9]{1,3})/i,
      /OFFICE\s*(?:VISIT)?\s*:?\s*\$?([0-9]{1,3})/i
    ]

    for (const pattern of copayPatterns) {
      const match = upperText.match(pattern)
      if (match && match[1]) {
        return `$${match[1]}`
      }
    }

    return undefined
  }

  private extractPhoneNumber(text: string): string | undefined {
    const phonePattern = /(?:\(?(\d{3})\)?[-\s]?)?(\d{3})[-\s]?(\d{4})/
    const match = text.match(phonePattern)
    
    if (match && match[0].replace(/\D/g, '').length === 10) {
      const digits = match[0].replace(/\D/g, '')
      return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`
    }

    return undefined
  }

  private extractRxBin(upperText: string, lines: string[]): string | undefined {
    const rxBinPattern = /(?:RX\s*)?BIN\s*:?\s*([0-9]{6})/i
    const match = upperText.match(rxBinPattern)
    return match ? match[1] : undefined
  }

  private extractRxPcn(upperText: string, lines: string[]): string | undefined {
    const rxPcnPattern = /PCN\s*:?\s*([A-Z0-9]{2,10})/i
    const match = upperText.match(rxPcnPattern)
    return match ? match[1] : undefined
  }

  async terminate(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate()
      this.worker = null
      this.isInitialized = false
    }
  }
}

// Singleton instance
export const ocrService = new OCRService()
