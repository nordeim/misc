// Public data access layer for demo purposes
import { supabase } from './supabase'

// Demo user IDs for public access
export const DEMO_CLIENT_ID = '8def8017-0b91-4a28-bc6b-3145cdbf12c3'
export const DEMO_PROVIDER_ID = 'dde959be-7b06-46d2-893f-8fddaa92a956'

// Fetch demo appointments for client dashboard
export async function getDemoClientAppointments() {
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .eq('client_id', DEMO_CLIENT_ID)
    .in('status', ['scheduled', 'confirmed'])
    .gte('scheduled_at', new Date().toISOString())
    .order('scheduled_at', { ascending: true })
    .limit(3)

  if (error) {
    console.error('Error fetching demo appointments:', error)
    return []
  }
  
  return data || []
}

// Fetch demo therapy sessions for client dashboard
export async function getDemoClientSessions() {
  const { data, error } = await supabase
    .from('therapy_sessions')
    .select('*')
    .eq('client_id', DEMO_CLIENT_ID)
    .not('ended_at', 'is', null)
    .order('ended_at', { ascending: false })
    .limit(5)

  if (error) {
    console.error('Error fetching demo sessions:', error)
    return []
  }
  
  return data || []
}

// Fetch demo provider appointments
export async function getDemoProviderAppointments() {
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .eq('provider_id', DEMO_PROVIDER_ID)
    .in('status', ['scheduled', 'confirmed'])
    .gte('scheduled_at', new Date().toISOString())
    .order('scheduled_at', { ascending: true })
    .limit(5)

  if (error) {
    console.error('Error fetching demo provider appointments:', error)
    return []
  }
  
  return data || []
}

// Fetch demo provider sessions
export async function getDemoProviderSessions() {
  const { data, error } = await supabase
    .from('therapy_sessions')
    .select('*')
    .eq('provider_id', DEMO_PROVIDER_ID)
    .not('ended_at', 'is', null)
    .order('ended_at', { ascending: false })
    .limit(5)

  if (error) {
    console.error('Error fetching demo provider sessions:', error)
    return []
  }
  
  return data || []
}

// Fetch demo insurance plan
export async function getDemoInsurancePlan() {
  const { data, error } = await supabase
    .from('insurance_plans')
    .select('*')
    .eq('client_id', DEMO_CLIENT_ID)
    .order('created_at', { ascending: false })
    .maybeSingle()

  if (error) {
    console.error('Error fetching demo insurance plan:', error)
    return null
  }
  
  return data
}

// Fetch demo providers with credentials
export async function getDemoProviders() {
  const { data: profiles, error: profileError } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_type', 'provider')
    .limit(10)

  if (profileError) {
    console.error('Error fetching demo provider profiles:', profileError)
    return []
  }

  if (!profiles || profiles.length === 0) {
    return []
  }

  const providerIds = profiles.map(p => p.user_id)
  const { data: credentials, error: credError } = await supabase
    .from('provider_credentials')
    .select('*')
    .in('provider_id', providerIds)
    .eq('verification_status', 'verified')

  if (credError) {
    console.error('Error fetching demo provider credentials:', credError)
    return profiles.map(profile => ({ ...profile, credentials: null }))
  }

  const providersWithCredentials = profiles.map(profile => ({
    ...profile,
    credentials: credentials?.find(c => c.provider_id === profile.user_id)
  }))

  return providersWithCredentials
}

// Get demo user profiles
export function getDemoClientProfile() {
  return {
    user_id: DEMO_CLIENT_ID,
    first_name: 'Sarah',
    last_name: 'Johnson',
    user_type: 'client' as const
  }
}

export function getDemoProviderProfile() {
  return {
    user_id: DEMO_PROVIDER_ID,
    first_name: 'Dr. Michael',
    last_name: 'Thompson',
    user_type: 'provider' as const
  }
}
