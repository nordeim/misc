import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://ftfozjjvfsakhfaendbj.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ0Zm96amp2ZnNha2hmYWVuZGJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Mzk2MDUsImV4cCI6MjA2OTQxNTYwNX0.-Qpz4oy_j6HDcjJWXWBNYCplMCrmdjbu4vbuQNp0ugc'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type UserProfile = {
  id: string
  user_id: string
  user_type: 'provider' | 'client'
  first_name: string
  last_name: string
  email: string
  phone?: string
  date_of_birth?: string
  address?: any
  emergency_contact?: any
  created_at: string
  updated_at: string
}

export type ProviderCredentials = {
  id: string
  provider_id: string
  license_number: string
  license_state: string
  license_type: string
  specialties: string[]
  credentials: string[]
  bio?: string
  years_experience?: number
  education?: any
  certifications?: any
  languages: string[]
  insurance_accepted: string[]
  is_accepting_new_clients: boolean
  verification_status: 'pending' | 'verified' | 'rejected'
  created_at: string
  updated_at: string
}

export type Appointment = {
  id: string
  provider_id: string
  client_id: string
  appointment_type: 'initial_consultation' | 'therapy_session' | 'medication_management' | 'crisis_intervention' | 'group_therapy'
  status: 'scheduled' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled' | 'no_show'
  scheduled_at: string
  duration_minutes: number
  session_format: 'video' | 'audio' | 'in_person'
  notes?: string
  cancellation_reason?: string
  created_at: string
  updated_at: string
}

export type TherapySession = {
  id: string
  appointment_id: string
  provider_id: string
  client_id: string
  session_type: string
  started_at?: string
  ended_at?: string
  recording_url?: string
  transcript_url?: string
  session_notes?: string
  progress_notes?: string
  mood_before?: number
  mood_after?: number
  goals_addressed: string[]
  homework_assigned: string[]
  next_session_goals: string[]
  crisis_flags: string[]
  recording_consent_given: boolean
  transcript_consent_given: boolean
  created_at: string
  updated_at: string
}

export type InsurancePlan = {
  id: string
  client_id: string
  plan_name: string
  insurance_company: string
  member_id: string
  group_number?: string
  plan_type?: string
  copay_amount?: number
  deductible_amount?: number
  out_of_pocket_max?: number
  card_image_url?: string
  verification_status: 'pending' | 'verified' | 'rejected'
  last_verified_at?: string
  created_at: string
  updated_at: string
}