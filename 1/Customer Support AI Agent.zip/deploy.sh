#!/bin/bash

# =============================================================================
# Customer Support AI Agent - Deployment Script
# =============================================================================

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="customer-support-ai-agent"
COMPOSE_FILE="docker-compose.yml"
PROD_COMPOSE_FILE="docker-compose.prod.yml"
ENV_FILE=".env"
PROD_ENV_FILE=".env.prod"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_dependencies() {
    log_info "Checking dependencies..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    log_success "All dependencies are installed."
}

check_env_file() {
    local env_file=$1
    if [ ! -f "$env_file" ]; then
        log_warning "Environment file $env_file not found."
        if [ "$env_file" = ".env" ]; then
            log_info "Creating .env from .env.example..."
            cp .env.example .env
            log_warning "Please edit .env file with your configuration before continuing."
            read -p "Press Enter to continue after editing .env file..."
        else
            log_error "Please create $env_file file before deployment."
            exit 1
        fi
    fi
}

setup_directories() {
    log_info "Creating necessary directories..."
    
    mkdir -p ./data/{postgres,redis,chromadb,prometheus,grafana}
    mkdir -p ./logs
    mkdir -p ./backups
    mkdir -p ./docker/ssl
    
    # Set proper permissions
    chmod 755 ./data ./logs ./backups ./docker/ssl
    
    log_success "Directories created."
}

start_development() {
    log_info "Starting development environment..."
    
    check_env_file ".env"
    setup_directories
    
    log_info "Pulling latest images..."
    docker-compose pull
    
    log_info "Starting services..."
    docker-compose up -d
    
    log_info "Waiting for services to be healthy..."
    sleep 30
    
    # Check service health
    if docker-compose ps | grep -q "Up (healthy)"; then
        log_success "Development environment is running!"
        echo ""
        echo "Services:"
        echo "  Frontend: http://localhost:3000"
        echo "  Backend:  http://localhost:8000"
        echo "  API Docs: http://localhost:8000/docs"
        echo "  Database: localhost:5432"
        echo "  Redis:    localhost:6379"
        echo ""
        echo "To view logs: docker-compose logs -f"
        echo "To stop:      docker-compose down"
    else
        log_error "Some services failed to start. Check logs with: docker-compose logs"
        exit 1
    fi
}

start_production() {
    log_info "Starting production environment..."
    
    check_env_file "$PROD_ENV_FILE"
    setup_directories
    
    # Security check
    if grep -q "your-secret-key-here" "$PROD_ENV_FILE" 2>/dev/null; then
        log_error "SECRET_KEY not configured in $PROD_ENV_FILE"
        exit 1
    fi
    
    if grep -q "your-secure-password" "$PROD_ENV_FILE" 2>/dev/null; then
        log_error "Database password not configured in $PROD_ENV_FILE"
        exit 1
    fi
    
    log_info "Pulling latest images..."
    docker-compose -f "$PROD_COMPOSE_FILE" --env-file "$PROD_ENV_FILE" pull
    
    log_info "Starting production services..."
    docker-compose -f "$PROD_COMPOSE_FILE" --env-file "$PROD_ENV_FILE" up -d
    
    log_info "Waiting for services to be healthy..."
    sleep 60
    
    # Check service health
    if docker-compose -f "$PROD_COMPOSE_FILE" --env-file "$PROD_ENV_FILE" ps | grep -q "Up (healthy)"; then
        log_success "Production environment is running!"
        echo ""
        echo "Services:"
        echo "  Frontend: http://localhost"
        echo "  Backend:  http://localhost/api"
        echo "  Database: localhost:5432"
        echo "  Redis:    localhost:6379"
        echo ""
        if [ -f "$PROD_ENV_FILE" ] && grep -q "PROMETHEUS_ENABLED=true" "$PROD_ENV_FILE"; then
            echo "  Prometheus: http://localhost:9090"
            echo "  Grafana:    http://localhost:3001"
        fi
        echo ""
        echo "To view logs: docker-compose -f $PROD_COMPOSE_FILE --env-file $PROD_ENV_FILE logs -f"
        echo "To stop:      docker-compose -f $PROD_COMPOSE_FILE --env-file $PROD_ENV_FILE down"
    else
        log_error "Some services failed to start. Check logs with: docker-compose -f $PROD_COMPOSE_FILE --env-file $PROD_ENV_FILE logs"
        exit 1
    fi
}

start_with_monitoring() {
    log_info "Starting with monitoring stack..."
    
    check_env_file "$PROD_ENV_FILE"
    setup_directories
    
    log_info "Starting services with monitoring..."
    docker-compose -f "$PROD_COMPOSE_FILE" --env-file "$PROD_ENV_FILE" --profile monitoring up -d
    
    log_success "Services with monitoring started!"
    echo ""
    echo "Access URLs:"
    echo "  Application: http://localhost"
    echo "  Prometheus:  http://localhost:9090"
    echo "  Grafana:     http://localhost:3001 (admin/your-grafana-password)"
}

stop_services() {
    local compose_file=$1
    local env_file=$2
    
    log_info "Stopping services..."
    
    if [ -n "$env_file" ]; then
        docker-compose -f "$compose_file" --env-file "$env_file" down
    else
        docker-compose -f "$compose_file" down
    fi
    
    log_success "Services stopped."
}

show_logs() {
    local compose_file=$1
    local env_file=$2
    
    if [ -n "$env_file" ]; then
        docker-compose -f "$compose_file" --env-file "$env_file" logs -f
    else
        docker-compose -f "$compose_file" logs -f
    fi
}

show_status() {
    local compose_file=$1
    local env_file=$2
    
    if [ -n "$env_file" ]; then
        docker-compose -f "$compose_file" --env-file "$env_file" ps
    else
        docker-compose -f "$compose_file" ps
    fi
}

backup_database() {
    local env_file=$1
    local backup_file="backup_$(date +%Y%m%d_%H%M%S).sql"
    
    log_info "Creating database backup..."
    
    if [ -n "$env_file" ]; then
        docker-compose -f "$PROD_COMPOSE_FILE" --env-file "$env_file" exec -T postgres pg_dump -U postgres customer_support > "./backups/$backup_file"
    else
        docker-compose exec -T postgres pg_dump -U postgres customer_support > "./backups/$backup_file"
    fi
    
    log_success "Database backup created: ./backups/$backup_file"
}

update_services() {
    local compose_file=$1
    local env_file=$2
    
    log_info "Updating services..."
    
    # Pull latest images
    if [ -n "$env_file" ]; then
        docker-compose -f "$compose_file" --env-file "$env_file" pull
        docker-compose -f "$compose_file" --env-file "$env_file" up -d
    else
        docker-compose -f "$compose_file" pull
        docker-compose -f "$compose_file" up -d
    fi
    
    log_success "Services updated."
}

show_help() {
    echo "Customer Support AI Agent - Deployment Script"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  dev              Start development environment"
    echo "  prod             Start production environment"
    echo "  prod-monitoring  Start production with monitoring stack"
    echo "  stop             Stop all services"
    echo "  stop-prod        Stop production services"
    echo "  logs             Show development logs"
    echo "  logs-prod        Show production logs"
    echo "  status           Show development status"
    echo "  status-prod      Show production status"
    echo "  backup           Create database backup"
    echo "  update           Update development services"
    echo "  update-prod      Update production services"
    echo "  help             Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 dev              # Start development"
    echo "  $0 prod             # Start production"
    echo "  $0 logs-prod        # View production logs"
    echo "  $0 backup           # Backup database"
}

# Main script
case "$1" in
    "dev")
        check_dependencies
        start_development
        ;;
    "prod")
        check_dependencies
        start_production
        ;;
    "prod-monitoring")
        check_dependencies
        start_with_monitoring
        ;;
    "stop")
        stop_services "$COMPOSE_FILE"
        ;;
    "stop-prod")
        stop_services "$PROD_COMPOSE_FILE" "$PROD_ENV_FILE"
        ;;
    "logs")
        show_logs "$COMPOSE_FILE"
        ;;
    "logs-prod")
        show_logs "$PROD_COMPOSE_FILE" "$PROD_ENV_FILE"
        ;;
    "status")
        show_status "$COMPOSE_FILE"
        ;;
    "status-prod")
        show_status "$PROD_COMPOSE_FILE" "$PROD_ENV_FILE"
        ;;
    "backup")
        backup_database "$PROD_ENV_FILE"
        ;;
    "update")
        update_services "$COMPOSE_FILE"
        ;;
    "update-prod")
        update_services "$PROD_COMPOSE_FILE" "$PROD_ENV_FILE"
        ;;
    "help"|"--help"|"-h")
        show_help
        ;;
    "")
        log_error "No command specified."
        show_help
        exit 1
        ;;
    *)
        log_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac