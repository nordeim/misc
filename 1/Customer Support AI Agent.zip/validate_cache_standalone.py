#!/usr/bin/env python3
"""
Standalone Cache Service Validation

This script validates the cache implementation without requiring
the full application context.
"""

import asyncio
import sys
import logging
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def test_cache_service_basic():
    """Test basic cache service functionality."""
    logger.info("=" * 60)
    logger.info("STANDALONE CACHE SERVICE VALIDATION")
    logger.info("=" * 60)
    
    # Test 1: Import the cache service
    logger.info("1. Testing imports...")
    try:
        # Import Redis components
        try:
            import redis.asyncio as aioredis
            REDIS_AVAILABLE = True
            logger.info("   ✓ Redis async library available")
        except ImportError:
            REDIS_AVAILABLE = False
            logger.warning("   ⚠ Redis async library not available (expected for validation)")
        
        # Import our cache components
        sys.path.insert(0, str(Path(__file__).parent / "backend" / "app" / "services"))
        sys.path.insert(0, str(Path(__file__).parent / "backend" / "app" / "utils"))
        
        # Test individual components
        from cache_service import (
            RedisCacheService,
            InMemoryFallbackCache,
            SerializationManager,
            CacheTagManager,
            CacheAnalytics
        )
        logger.info("   ✓ All cache service components imported successfully")
        
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Import failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_in_memory_fallback():
    """Test in-memory fallback cache."""
    logger.info("2. Testing InMemoryFallbackCache...")
    
    try:
        from cache_service import InMemoryFallbackCache
        
        # Create cache
        cache = InMemoryFallbackCache(max_size=100, default_ttl=60)
        
        # Test basic operations
        await cache.set("test_key", {"data": "test_value"})
        value = await cache.get("test_key")
        assert value == {"data": "test_value"}, "Get operation failed"
        
        # Test exists
        exists = await cache.exists("test_key")
        assert exists, "Exists check failed"
        
        # Test delete
        deleted = await cache.delete("test_key")
        assert deleted, "Delete operation failed"
        
        # Test non-existent
        value = await cache.get("non_existent")
        assert value is None, "Non-existent key should return None"
        
        logger.info("   ✓ InMemoryFallbackCache working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ InMemoryFallbackCache test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_serialization():
    """Test serialization manager."""
    logger.info("3. Testing SerializationManager...")
    
    try:
        from cache_service import SerializationManager
        
        # Test different data types
        test_data = [
            "simple string",
            42,
            3.14159,
            True,
            {"nested": {"data": "value"}},
            [1, 2, 3, "test"],
            None
        ]
        
        for data in test_data:
            # Serialize
            serialized, format_type = SerializationManager.serialize(data)
            assert isinstance(serialized, bytes), "Serialization should return bytes"
            
            # Deserialize
            deserialized = SerializationManager.deserialize(serialized, format_type)
            assert deserialized == data, f"Deserialization failed for {type(data)}"
        
        logger.info("   ✓ SerializationManager working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ SerializationManager test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_decorators():
    """Test cache decorators."""
    logger.info("4. Testing cache decorators...")
    
    try:
        # Test memoize decorator
        call_count = 0
        
        from cache_decorators import memoize
        
        @memoize(ttl=60)
        def test_function(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        # First call
        result1 = test_function(5)
        assert result1 == 10, "First call should return 10"
        assert call_count == 1, "Function should be called once"
        
        # Second call (cached)
        result2 = test_function(5)
        assert result2 == 10, "Second call should return 10"
        assert call_count == 1, "Function should still be called once"
        
        # Different argument
        result3 = test_function(10)
        assert result3 == 20, "Different argument should work"
        assert call_count == 2, "Function should be called for new argument"
        
        logger.info("   ✓ Cache decorators working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Cache decorators test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_configuration():
    """Test configuration management."""
    logger.info("5. Testing configuration...")
    
    try:
        from cache_config import CacheConfigManager, CachePerformanceConfig
        
        # Test config creation
        config_manager = CacheConfigManager()
        
        # Test validation
        validation = config_manager.validate_config()
        assert 'valid' in validation, "Validation should return valid field"
        assert 'issues' in validation, "Validation should return issues"
        assert 'warnings' in validation, "Validation should return warnings"
        
        # Test environment config
        config_manager.apply_environment_config('development')
        
        # Test TTL mapping
        ttl = config_manager.get_ttl_for_category('session')
        assert isinstance(ttl, int), "TTL should be integer"
        
        logger.info("   ✓ Configuration management working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Configuration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_analytics():
    """Test analytics components."""
    logger.info("6. Testing analytics...")
    
    try:
        from cache_service import CacheAnalytics, InMemoryFallbackCache
        
        # Create mock cache service
        class MockCacheService:
            def __init__(self):
                self.redis_client = None
                self.fallback_cache = InMemoryFallbackCache()
        
        mock_service = MockCacheService()
        analytics = CacheAnalytics(mock_service)
        
        # Test metrics collection
        metrics = await analytics.collect_metrics()
        assert hasattr(metrics, 'hits'), "Metrics should have hits"
        assert hasattr(metrics, 'misses'), "Metrics should have misses"
        
        # Test health status
        health_status = analytics._get_health_status(metrics)
        assert health_status in ['unknown', 'excellent', 'good', 'fair', 'poor']
        
        logger.info("   ✓ Analytics working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Analytics test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_migration():
    """Test migration components."""
    logger.info("7. Testing migration...")
    
    try:
        from cache_migration import CacheMigrator
        
        # Test migrator creation
        migrator = CacheMigrator()
        assert hasattr(migrator, 'migration_stats'), "Migrator should have stats"
        
        # Test backup metadata
        from cache_migration import CacheBackupMetadata
        metadata = CacheBackupMetadata(
            backup_id="test_backup",
            created_at=1000.0,
            version="1.0",
            total_keys=10,
            total_size_bytes=1024,
            backend_type="redis",
            tags=["test"],
            compression_enabled=False,
            encryption_enabled=False
        )
        
        assert metadata.backup_id == "test_backup", "Metadata creation failed"
        
        logger.info("   ✓ Migration components working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Migration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_testing_utilities():
    """Test testing utilities."""
    logger.info("8. Testing utilities...")
    
    try:
        from cache_testing import CacheTestResult, CacheValidator
        
        # Test result creation
        result = CacheTestResult(
            test_name="test",
            passed=True,
            duration_ms=100.0,
            operations_count=5,
            hit_rate=0.8,
            errors=[],
            details={'test': 'data'}
        )
        
        assert result.test_name == "test", "Result creation failed"
        assert result.passed == True, "Result passed flag failed"
        
        # Test to_dict conversion
        result_dict = result.to_dict()
        assert isinstance(result_dict, dict), "to_dict should return dict"
        assert 'test_name' in result_dict, "to_dict should include test_name"
        
        logger.info("   ✓ Testing utilities working correctly")
        return True
        
    except Exception as e:
        logger.error(f"   ✗ Testing utilities test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Run all validation tests."""
    tests = [
        ("Import Test", test_cache_service_basic),
        ("InMemory Fallback", test_in_memory_fallback),
        ("Serialization", test_serialization),
        ("Decorators", test_decorators),
        ("Configuration", test_configuration),
        ("Analytics", test_analytics),
        ("Migration", test_migration),
        ("Testing Utilities", test_testing_utilities),
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            logger.info(f"\nRunning {test_name}...")
            success = await test_func()
            results[test_name] = success
        except Exception as e:
            logger.error(f"Test {test_name} failed with exception: {e}")
            results[test_name] = False
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("VALIDATION SUMMARY")
    logger.info("=" * 60)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, success in results.items():
        status = "✓ PASS" if success else "✗ FAIL"
        logger.info(f"{test_name:30} {status}")
    
    logger.info("=" * 60)
    if passed == total:
        logger.info("🎉 ALL TESTS PASSED!")
        logger.info("The Redis Cache Service implementation is valid and ready for use!")
        return 0
    else:
        logger.warning(f"⚠ {passed}/{total} tests passed")
        logger.warning("Some components may need attention")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
