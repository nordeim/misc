# 🚀 Deployment Guide

This guide provides comprehensive instructions for deploying the Customer Support AI Agent in various environments.

## Table of Contents

- [Overview](#overview)
- [Environment Setup](#environment-setup)
- [Docker Deployment](#docker-deployment)
- [Kubernetes Deployment](#kubernetes-deployment)
- [Cloud Provider Deployments](#cloud-provider-deployments)
- [Production Configuration](#production-configuration)
- [Monitoring and Observability](#monitoring-and-observability)
- [Scaling and Performance](#scaling-and-performance)
- [Security Considerations](#security-considerations)
- [Backup and Recovery](#backup-and-recovery)
- [Troubleshooting](#troubleshooting)

---

## Overview

The Customer Support AI Agent can be deployed in multiple environments:

- **Development**: Local Docker Compose setup
- **Staging**: Production-like environment for testing
- **Production**: High-availability, scalable deployment

### Deployment Architecture

```mermaid
graph TB
    subgraph "Load Balancer"
        LB[Nginx/ALB]
    end
    
    subgraph "Application Tier"
        API1[FastAPI Instance 1]
        API2[FastAPI Instance 2]
        API3[FastAPI Instance 3]
    end
    
    subgraph "Cache Layer"
        REDIS[(Redis Cluster)]
    end
    
    subgraph "Database Tier"
        PG[(PostgreSQL Primary)]
        PG_R[(PostgreSQL Read Replica)]
    end
    
    subgraph "Vector Database"
        CHROMA[(ChromaDB Cluster)]
    end
    
    subgraph "Monitoring"
        PROM[Prometheus]
        GRAF[Grafana]
        LOGS[Logging]
    end
    
    LB --> API1
    LB --> API2
    LB --> API3
    
    API1 --> REDIS
    API2 --> REDIS
    API3 --> REDIS
    
    API1 --> PG
    API2 --> PG
    API3 --> PG
    
    API1 --> PG_R
    API2 --> PG_R
    API3 --> PG_R
    
    API1 --> CHROMA
    API2 --> CHROMA
    API3 --> CHROMA
    
    API1 --> PROM
    API2 --> PROM
    API3 --> PROM
    
    PROM --> GRAF
```

---

## Environment Setup

### Prerequisites

| Component | Development | Staging | Production |
|-----------|-------------|---------|------------|
| **CPU** | 2 cores | 4 cores | 8+ cores |
| **Memory** | 4 GB | 8 GB | 16+ GB |
| **Storage** | 20 GB | 50 GB | 100+ GB SSD |
| **Network** | 1 Gbps | 1 Gbps | 10 Gbps |

### Required Software

```bash
# Install required software
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install kubectl (for Kubernetes)
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Install Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

---

## Docker Deployment

### Development Deployment

#### 1. Environment Configuration

```bash
# Clone repository
git clone https://github.com/yourusername/customer-support-ai-agent.git
cd customer-support-ai-agent

# Create environment file
cp .env.example .env
```

**Development `.env` file:**
```env
# Environment
DEBUG=true
ENVIRONMENT=development
LOG_LEVEL=DEBUG

# Database
DATABASE_URL=sqlite:///./customer_support.db

# Redis (optional - will fallback to in-memory if unavailable)
REDIS_URL=redis://localhost:6379

# ChromaDB
CHROMA_PERSIST_DIRECTORY=./chroma_db

# OpenAI
OPENAI_API_KEY=your-openai-api-key
AGENT_MODEL=gpt-4o-mini

# Frontend
FRONTEND_URL=http://localhost:3000

# Security (development only)
SECRET_KEY=dev-secret-key-change-in-production
JWT_SECRET_KEY=dev-jwt-secret-change-in-production
```

#### 2. Start Services

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Check service status
docker-compose ps

# Stop services
docker-compose down
```

#### 3. Verify Deployment

```bash
# Check backend health
curl http://localhost:8000/health

# Check frontend
curl http://localhost:3000

# Check API docs
open http://localhost:8000/docs
```

### Staging Deployment

#### 1. Staging Environment Configuration

```bash
# Create staging environment file
cp .env.example .env.staging
```

**Staging `.env.staging` file:**
```env
# Environment
DEBUG=false
ENVIRONMENT=staging
LOG_LEVEL=INFO

# Database (PostgreSQL)
DATABASE_URL=postgresql://postgres:password@postgres:5432/customer_support_staging

# Redis
REDIS_URL=redis://redis:6379/0

# ChromaDB
CHROMA_PERSIST_DIRECTORY=/data/chromadb_staging

# OpenAI
OPENAI_API_KEY=your-openai-api-key
AGENT_MODEL=gpt-4o-mini

# Frontend
FRONTEND_URL=https://staging.yourdomain.com

# Security
SECRET_KEY=staging-secret-key-very-secure
JWT_SECRET_KEY=staging-jwt-secret-very-secure

# Monitoring
ENABLE_TELEMETRY=true
OTLP_ENDPOINT=http://otel-collector:4317
```

#### 2. Build and Deploy

```bash
# Build staging images
docker-compose -f docker-compose.yml -f docker-compose.staging.yml build

# Deploy staging stack
docker-compose -f docker-compose.yml -f docker-compose.staging.yml up -d

# Run database migrations
docker-compose exec backend alembic upgrade head

# Index documents
docker-compose exec backend python scripts/index_docs.py
```

#### 3. Staging Docker Compose Configuration

Create `docker-compose.staging.yml`:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: customer_support_staging
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 2G
          cpus: '1.0'

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 1G
          cpus: '0.5'

  chromadb:
    image: chromadb/chroma:latest
    environment:
      CHROMA_SERVER_AUTHN_CREDENTIALS: admin:admin
      CHROMA_SERVER_AUTHN_PROVIDER: chromadb.auth.basic.BasicAuthenticationServerProvider
    volumes:
      - chromadb_data:/chroma/chroma
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 2G
          cpus: '1.0'

volumes:
  postgres_data:
  redis_data:
  chromadb_data:
```

### Production Deployment

#### 1. Production Environment Configuration

```bash
# Create production environment file
cp .env.example .env.production
```

**Production `.env.production` file:**
```env
# Environment
DEBUG=false
ENVIRONMENT=production
LOG_LEVEL=WARNING

# Database (PostgreSQL with connection pool)
DATABASE_URL=postgresql://postgres:${DB_PASSWORD}@postgres:5432/customer_support

# Redis Cluster
REDIS_URL=redis://:${REDIS_PASSWORD}@redis:6379/0

# ChromaDB Cluster
CHROMA_PERSIST_DIRECTORY=/data/chromadb

# OpenAI/Azure OpenAI
OPENAI_API_KEY=${OPENAI_API_KEY}
AGENT_MODEL=gpt-4o-mini

# Frontend
FRONTEND_URL=https://yourdomain.com

# Security (use strong, random secrets)
SECRET_KEY=${APP_SECRET_KEY}
JWT_SECRET_KEY=${JWT_SECRET_KEY}

# Production URLs
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com,api.yourdomain.com

# Database
DB_SSL_MODE=require
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=30

# Redis
REDIS_SSL=true
REDIS_SENTINEL_URL=${REDIS_SENTINEL_URL}

# Monitoring
ENABLE_TELEMETRY=true
OTLP_ENDPOINT=${OTLP_ENDPOINT}
PROMETHEUS_ENDPOINT=http://prometheus:9090

# Rate Limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS_PER_MINUTE=1000

# File Upload Limits
MAX_FILE_SIZE=10485760  # 10MB
ALLOWED_FILE_TYPES=pdf,doc,docx,txt,jpg,png
```

#### 2. Production Docker Compose Configuration

Create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  # Load Balancer
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/ssl:/etc/nginx/ssl
      - ./nginx/logs:/var/log/nginx
    depends_on:
      - backend
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 512M
          cpus: '0.5'

  # Backend API (scaled)
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.prod
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
      - SECRET_KEY=${SECRET_KEY}
    volumes:
      - ./data/chromadb:/data/chromadb
      - ./logs:/app/logs
    depends_on:
      - postgres
      - redis
      - chromadb
    restart: unless-stopped
    deploy:
      replicas: 3
      resources:
        limits:
          memory: 2G
          cpus: '1.0'
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3

  # Frontend
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.prod
    environment:
      - REACT_APP_API_URL=https://api.yourdomain.com
    volumes:
      - ./nginx/html:/usr/share/nginx/html
    depends_on:
      - backend
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 512M
          cpus: '0.5'

  # Database
  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=customer_support
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 4G
          cpus: '2.0'
      placement:
        constraints:
          - node.role == manager

  # Redis Cache
  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 2G
          cpus: '1.0'
      placement:
        constraints:
          - node.role == manager

  # ChromaDB Vector Database
  chromadb:
    image: chromadb/chroma:latest
    environment:
      - CHROMA_SERVER_HOST=0.0.0.0
      - CHROMA_SERVER_HTTP_PORT=8000
      - CHROMA_SERVER_AUTHN_CREDENTIALS=${CHROMA_AUTH}
    volumes:
      - chromadb_data:/chroma/chroma
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 4G
          cpus: '2.0'
      placement:
        constraints:
          - node.role == manager

  # Monitoring
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=200h'
      - '--web.enable-lifecycle'
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 2G
          cpus: '1.0'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD}
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/var/lib/grafana/dashboards
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning
    restart: unless-stopped
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 1G
          cpus: '0.5'

volumes:
  postgres_data:
  redis_data:
  chromadb_data:
  prometheus_data:
  grafana_data:

networks:
  default:
    driver: overlay
```

#### 3. Production Build Scripts

Create `scripts/deploy-prod.sh`:

```bash
#!/bin/bash

set -e

echo "🚀 Starting production deployment..."

# Load environment variables
source .env.production

# Pull latest code
git pull origin main

# Build images
echo "📦 Building Docker images..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Create network
echo "🌐 Creating Docker network..."
docker network create --driver overlay customer-support-net

# Deploy services
echo "🚀 Deploying services..."
docker stack deploy -c docker-compose.prod.yml customer-support

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 30

# Run database migrations
echo "🗄️ Running database migrations..."
docker exec $(docker ps -q -f name=customer-support_backend) alembic upgrade head

# Index documents
echo "📚 Indexing documents..."
docker exec $(docker ps -q -f name=customer-support_backend) python scripts/index_docs.py

# Verify deployment
echo "✅ Verifying deployment..."
curl -f http://localhost/health || exit 1

echo "🎉 Production deployment completed successfully!"
```

#### 4. Deployment Process

```bash
# Make deploy script executable
chmod +x scripts/deploy-prod.sh

# Run production deployment
./scripts/deploy-prod.sh

# Monitor deployment
docker service ls
docker service logs -f customer-support_backend
```

---

## Kubernetes Deployment

### Prerequisites

```bash
# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Install helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Create namespace
kubectl create namespace customer-support
```

### Kubernetes Manifests

#### 1. Namespace and ConfigMap

```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: customer-support

---
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: customer-support-config
  namespace: customer-support
data:
  ENVIRONMENT: "production"
  LOG_LEVEL: "INFO"
  FRONTEND_URL: "https://yourdomain.com"
  ALLOWED_HOSTS: "yourdomain.com,www.yourdomain.com"
```

#### 2. Database and Cache

```yaml
# k8s/postgres.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: customer-support
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        env:
        - name: POSTGRES_DB
          value: customer_support
        - name: POSTGRES_USER
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: username
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: password
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 100Gi

---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: customer-support
spec:
  clusterIP: None
  selector:
    app: postgres
  ports:
  - port: 5432
    targetPort: 5432

---
# k8s/redis.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: customer-support
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        command: ["redis-server", "--appendonly", "yes"]
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: redis-secret
              key: password
        ports:
        - containerPort: 6379
        volumeMounts:
        - name: redis-storage
          mountPath: /data
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
      volumes:
      - name: redis-storage
        emptyDir: {}

---
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: customer-support
spec:
  selector:
    app: redis
  ports:
  - port: 6379
    targetPort: 6379
```

#### 3. Application Deployment

```yaml
# k8s/backend.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  namespace: customer-support
spec:
  replicas: 3
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: backend
        image: your-registry/customer-support-backend:latest
        envFrom:
        - configMapRef:
            name: customer-support-config
        - secretRef:
            name: app-secrets
        env:
        - name: DATABASE_URL
          value: "postgresql://$(POSTGRES_USER):$(POSTGRES_PASSWORD)@postgres:5432/customer_support"
        - name: REDIS_URL
          value: "redis://:$(REDIS_PASSWORD)@redis:6379/0"
        ports:
        - containerPort: 8000
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        volumeMounts:
        - name: chromadb-storage
          mountPath: /data/chromadb
        - name: logs
          mountPath: /app/logs
      volumes:
      - name: chromadb-storage
        persistentVolumeClaim:
          claimName: chromadb-pvc
      - name: logs
        emptyDir: {}

---
apiVersion: v1
kind: Service
metadata:
  name: backend
  namespace: customer-support
spec:
  selector:
    app: backend
  ports:
  - port: 8000
    targetPort: 8000
  type: ClusterIP

---
# k8s/frontend.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
  namespace: customer-support
spec:
  replicas: 2
  selector:
    matchLabels:
      app: frontend
  template:
    metadata:
      labels:
        app: frontend
    spec:
      containers:
      - name: frontend
        image: your-registry/customer-support-frontend:latest
        env:
        - name: REACT_APP_API_URL
          value: "https://api.yourdomain.com"
        ports:
        - containerPort: 80
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "500m"

---
apiVersion: v1
kind: Service
metadata:
  name: frontend
  namespace: customer-support
spec:
  selector:
    app: frontend
  ports:
  - port: 80
    targetPort: 80
  type: ClusterIP
```

#### 4. Ingress and Load Balancer

```yaml
# k8s/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: customer-support-ingress
  namespace: customer-support
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/use-regex: "true"
spec:
  tls:
  - hosts:
    - yourdomain.com
    - www.yourdomain.com
    secretName: customer-support-tls
  rules:
  - host: yourdomain.com
    http:
      paths:
      - path: /api/(.*)
        pathType: Prefix
        backend:
          service:
            name: backend
            port:
              number: 8000
      - path: /ws/(.*)
        pathType: Prefix
        backend:
          service:
            name: backend
            port:
              number: 8000
      - path: /
        pathType: Prefix
        backend:
          service:
            name: frontend
            port:
              number: 80

---
# k8s/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: backend-hpa
  namespace: customer-support
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

#### 5. Secrets

```yaml
# k8s/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-secrets
  namespace: customer-support
type: Opaque
data:
  SECRET_KEY: <base64-encoded-secret>
  JWT_SECRET_KEY: <base64-encoded-jwt-secret>
  OPENAI_API_KEY: <base64-encoded-openai-key>
---
apiVersion: v1
kind: Secret
metadata:
  name: db-secret
  namespace: customer-support
type: Opaque
data:
  username: <base64-encoded-db-username>
  password: <base64-encoded-db-password>
---
apiVersion: v1
kind: Secret
metadata:
  name: redis-secret
  namespace: customer-support
type: Opaque
data:
  password: <base64-encoded-redis-password>
```

#### 6. Deployment Commands

```bash
# Apply all manifests
kubectl apply -f k8s/

# Check deployment status
kubectl get pods -n customer-support
kubectl get services -n customer-support
kubectl get ingress -n customer-support

# View logs
kubectl logs -f deployment/backend -n customer-support

# Scale deployment
kubectl scale deployment backend --replicas=5 -n customer-support

# Update deployment
kubectl set image deployment/backend backend=your-registry/customer-support-backend:v1.1.0 -n customer-support

# Rollback deployment
kubectl rollout undo deployment/backend -n customer-support
```

### Helm Chart

#### 1. Create Helm Chart

```bash
# Create Helm chart structure
helm create customer-support

# Chart structure
customer-support/
├── Chart.yaml
├── values.yaml
├── templates/
│   ├── backend-deployment.yaml
│   ├── backend-service.yaml
│   ├── frontend-deployment.yaml
│   ├── frontend-service.yaml
│   ├── ingress.yaml
│   ├── hpa.yaml
│   └── secrets.yaml
```

#### 2. Helm Values

```yaml
# customer-support/values.yaml
replicaCount: 3

image:
  backend:
    repository: your-registry/customer-support-backend
    tag: "latest"
  frontend:
    repository: your-registry/customer-support-frontend
    tag: "latest"

service:
  type: ClusterIP
  port: 80

ingress:
  enabled: true
  className: nginx
  hosts:
    - host: yourdomain.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    enabled: true
    secretName: customer-support-tls

resources:
  backend:
    requests:
      memory: "1Gi"
      cpu: "500m"
    limits:
      memory: "2Gi"
      cpu: "1000m"
  frontend:
    requests:
      memory: "256Mi"
      cpu: "200m"
    limits:
      memory: "512Mi"
      cpu: "500m"

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
  targetMemoryUtilizationPercentage: 80

nodeSelector: {}
tolerations: []
affinity: {}

# Environment variables
env:
  ENVIRONMENT: "production"
  LOG_LEVEL: "INFO"
  FRONTEND_URL: "https://yourdomain.com"
```

#### 3. Deploy with Helm

```bash
# Install chart
helm install customer-support ./customer-support \
  --namespace customer-support \
  --create-namespace \
  --values customer-support/values.yaml

# Update deployment
helm upgrade customer-support ./customer-support \
  --namespace customer-support \
  --values customer-support/values.yaml

# Rollback
helm rollback customer-support 1 -n customer-support

# Uninstall
helm uninstall customer-support -n customer-support
```

---

## Cloud Provider Deployments

### AWS Deployment

#### 1. EKS Cluster Setup

```bash
# Install eksctl
curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
sudo mv /tmp/eksctl /usr/local/bin

# Create EKS cluster
eksctl create cluster \
  --name customer-support \
  --version 1.28 \
  --region us-west-2 \
  --nodegroup-name standard-workers \
  --node-type t3.large \
  --nodes 3 \
  --nodes-min 2 \
  --nodes-max 5 \
  --managed

# Configure kubectl
aws eks update-kubeconfig --region us-west-2 --name customer-support
```

#### 2. RDS PostgreSQL

```bash
# Create RDS instance
aws rds create-db-instance \
  --db-instance-identifier customer-support-db \
  --db-instance-class db.t3.medium \
  --engine postgres \
  --engine-version 15.4 \
  --master-username postgres \
  --master-user-password YourSecurePassword \
  --allocated-storage 100 \
  --vpc-security-group-ids sg-xxxxxxxxx \
  --db-subnet-group-name customer-support-subnet-group \
  --backup-retention-period 7 \
  --storage-encrypted
```

#### 3. ElastiCache Redis

```bash
# Create ElastiCache cluster
aws elasticache create-cache-cluster \
  --cache-cluster-id customer-support-redis \
  --cache-node-type cache.t3.micro \
  --engine redis \
  --num-cache-nodes 1 \
  --cache-subnet-group-name customer-support-subnet-group \
  --security-group-ids sg-xxxxxxxxx
```

#### 4. ECR Repositories

```bash
# Create ECR repositories
aws ecr create-repository --repository-name customer-support-backend
aws ecr create-repository --repository-name customer-support-frontend

# Get login token
aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.us-west-2.amazonaws.com

# Build and push images
docker build -t customer-support-backend ./backend
docker tag customer-support-backend:latest 123456789012.dkr.ecr.us-west-2.amazonaws.com/customer-support-backend:latest
docker push 123456789012.dkr.ecr.us-west-2.amazonaws.com/customer-support-backend:latest
```

#### 5. Application Load Balancer

```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name customer-support-alb \
  --subnets subnet-xxxxxxxxx subnet-yyyyyyyyy \
  --security-groups sg-xxxxxxxxx
```

### Azure Deployment

#### 1. AKS Cluster Setup

```bash
# Create resource group
az group create --name customer-support-rg --location eastus

# Create AKS cluster
az aks create \
  --resource-group customer-support-rg \
  --name customer-support-aks \
  --node-count 3 \
  --node-vm-size Standard_D2s_v3 \
  --enable-addons monitoring \
  --generate-ssh-keys

# Get credentials
az aks get-credentials --resource-group customer-support-rg --name customer-support-aks
```

#### 2. Azure Database for PostgreSQL

```bash
# Create PostgreSQL server
az postgres server create \
  --resource-group customer-support-rg \
  --name customer-support-postgres \
  --location eastus \
  --admin-user postgres \
  --admin-password YourSecurePassword \
  --sku-name GP_Gen5_2

# Create database
az postgres db create \
  --resource-group customer-support-rg \
  --server-name customer-support-postgres \
  --name customer_support
```

#### 3. Azure Cache for Redis

```bash
# Create Redis cache
az redis create \
  --resource-group customer-support-rg \
  --name customer-support-redis \
  --location eastus \
  --sku Standard \
  --vm-size c0
```

#### 4. Azure Container Registry

```bash
# Create container registry
az acr create \
  --resource-group customer-support-rg \
  --name customer-support-registry \
  --sku Basic

# Build and push images
az acr build --registry customer-support-registry --image customer-support-backend:latest ./backend
```

### Google Cloud Deployment

#### 1. GKE Cluster Setup

```bash
# Create GKE cluster
gcloud container clusters create customer-support \
  --zone us-central1-a \
  --num-nodes 3 \
  --machine-type n1-standard-2 \
  --enable-autoscaling \
  --min-nodes 2 \
  --max-nodes 5

# Get credentials
gcloud container clusters get-credentials customer-support --zone us-central1-a
```

#### 2. Cloud SQL PostgreSQL

```bash
# Create Cloud SQL instance
gcloud sql instances create customer-support-postgres \
  --database-version POSTGRES_15 \
  --tier db-custom-2-7680 \
  --region us-central1

# Create database
gcloud sql databases create customer_support --instance customer-support-postgres
```

#### 3. Memorystore Redis

```bash
# Create Redis instance
gcloud redis instances create customer-support-redis \
  --size 1 \
  --region us-central1 \
  --redis-version redis_6_x
```

#### 4. Container Registry

```bash
# Build and push to GCR
docker build -t gcr.io/PROJECT-ID/customer-support-backend:latest ./backend
docker push gcr.io/PROJECT-ID/customer-support-backend:latest

# Configure cluster to pull from GCR
kubectl create secret docker-registry gcr-secret \
  --docker-server=gcr.io \
  --docker-username=_json_key \
  --docker-password="$(cat ~/gcloud-key.json)" \
  --docker-email=user@example.com
```

---

## Production Configuration

### Environment Variables

#### Security Configuration

```env
# Application Security
SECRET_KEY=<64-character-random-string>
JWT_SECRET_KEY=<64-character-random-string>
ENCRYPTION_KEY=<32-character-random-string>

# Database Security
DB_SSL_MODE=require
DB_SSL_CERT=/path/to/client-cert.pem
DB_SSL_KEY=/path/to/client-key.pem
DB_SSL_ROOT_CERT=/path/to/ca-cert.pem

# Redis Security
REDIS_PASSWORD=<redis-password>
REDIS_SSL=true
REDIS_SENTINEL_URL=redis-sentinel://sentinel1:26379,sentinel2:26379/service-name

# API Security
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS_PER_MINUTE=1000
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
```

#### Performance Configuration

```env
# Database Performance
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=30
DB_POOL_TIMEOUT=30
DB_POOL_RECYCLE=3600

# Redis Performance
REDIS_CONNECTION_POOL_SIZE=50
REDIS_MAX_CONNECTIONS=100
REDIS_CONNECTION_TIMEOUT=5

# Application Performance
WORKER_PROCESSES=4
WORKER_CONNECTIONS=1000
MAX_WORKER_CONNECTIONS=4000
KEEPALIVE_TIMEOUT=65
```

#### Monitoring Configuration

```env
# Prometheus
ENABLE_METRICS=true
METRICS_PORT=9090

# OpenTelemetry
ENABLE_TELEMETRY=true
OTLP_ENDPOINT=http://otel-collector:4317
OTLP_SERVICE_NAME=customer-support-backend

# Logging
LOG_FORMAT=json
LOG_LEVEL=INFO
LOG_SENTRY_DSN=<sentry-dsn>
LOG_DATADOG_API_KEY=<datadog-api-key>
```

### SSL/TLS Configuration

#### Nginx SSL Configuration

```nginx
# /etc/nginx/sites-available/customer-support
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/ssl/certs/yourdomain.com.crt;
    ssl_certificate_key /etc/ssl/private/yourdomain.com.key;
    
    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 1d;
    ssl_session_tickets off;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=63072000" always;
    
    # Security Headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Gzip Compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=100r/m;
    limit_req_zone $binary_remote_addr zone=chat:10m rate=30r/m;
    
    # Frontend
    location / {
        root /var/www/html;
        try_files $uri $uri/ /index.html;
        
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
    
    # API
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # WebSocket
    location /ws/ {
        limit_req zone=chat burst=10 nodelay;
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Health checks
    location /health {
        access_log off;
        proxy_pass http://backend;
    }
}

upstream backend {
    least_conn;
    server backend1:8000 weight=1 max_fails=3 fail_timeout=30s;
    server backend2:8000 weight=1 max_fails=3 fail_timeout=30s;
    server backend3:8000 weight=1 max_fails=3 fail_timeout=30s;
    
    # Health check
    keepalive 32;
}
```

#### Let's Encrypt SSL Setup

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## Monitoring and Observability

### Prometheus Configuration

```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  - job_name: 'customer-support-backend'
    static_configs:
      - targets: ['backend:8000']
    metrics_path: '/metrics'
    scrape_interval: 5s
    scrape_timeout: 5s

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']

  - job_name: 'nginx'
    static_configs:
      - targets: ['nginx-exporter:9113']

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

### Grafana Dashboards

#### Backend Metrics Dashboard

```json
{
  "dashboard": {
    "title": "Customer Support Backend",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          }
        ]
      },
      {
        "title": "Error Rate",
        "type": "singlestat",
        "targets": [
          {
            "expr": "rate(http_requests_total{status=~\"5..\"}[5m]) / rate(http_requests_total[5m]) * 100",
            "legendFormat": "Error Rate"
          }
        ],
        "valueName": "current",
        "thresholds": "1,5",
        "colorBackground": true
      }
    ]
  }
}
```

### Alert Rules

```yaml
# monitoring/alert_rules.yml
groups:
  - name: customer-support-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value }}% for the last 5 minutes"

      - alert: HighResponseTime
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High response time detected"
          description: "95th percentile response time is {{ $value }}s"

      - alert: DatabaseDown
        expr: up{job="postgres"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Database is down"
          description: "PostgreSQL database has been down for more than 1 minute"

      - alert: HighMemoryUsage
        expr: (node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes > 0.9
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage"
          description: "Memory usage is above 90% for more than 5 minutes"
```

### Health Check Endpoints

```python
# backend/app/api/routes/health.py
from fastapi import APIRouter, HTTPException
from app.services.database import check_database_health
from app.services.cache import check_redis_health
from app.services.vector_db import check_chromadb_health

router = APIRouter()

@router.get("/health")
async def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "version": APP_VERSION
    }

@router.get("/health/ready")
async def readiness_check():
    """Readiness check for Kubernetes."""
    try:
        # Check all dependencies
        db_healthy = await check_database_health()
        redis_healthy = await check_redis_health()
        chromadb_healthy = await check_chromadb_health()
        
        if not all([db_healthy, redis_healthy, chromadb_healthy]):
            raise HTTPException(
                status_code=503,
                detail="One or more dependencies are unhealthy"
            )
        
        return {"status": "ready"}
        
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))

@router.get("/health/live")
async def liveness_check():
    """Liveness check for Kubernetes."""
    return {"status": "alive"}
```

---

## Scaling and Performance

### Horizontal Scaling

#### Database Scaling

```sql
-- Read replica configuration
-- In postgresql.conf on read replicas
wal_level = replica
max_wal_senders = 3
wal_keep_segments = 32
hot_standby = on

-- Query optimization indexes
CREATE INDEX CONCURRENTLY idx_messages_session_created 
ON messages(session_id, created_at);

CREATE INDEX CONCURRENTLY idx_memories_session_timestamp 
ON memories(session_id, timestamp DESC);

-- Connection pool settings
-- In application
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30
DATABASE_POOL_TIMEOUT=30
```

#### Redis Clustering

```bash
# Redis cluster configuration
# redis.conf
cluster-enabled yes
cluster-config-file nodes.conf
cluster-node-timeout 5000
appendonly yes
protected-mode no
bind 0.0.0.0
port 7000

# Docker Compose for Redis cluster
version: '3.8'
services:
  redis-node-1:
    image: redis:7-alpine
    command: redis-server /usr/local/etc/redis/redis.conf
    volumes:
      - ./redis/redis-1.conf:/usr/local/etc/redis/redis.conf
    ports:
      - "7000:7000"

  redis-node-2:
    image: redis:7-alpine
    command: redis-server /usr/local/etc/redis/redis.conf
    volumes:
      - ./redis/redis-2.conf:/usr/local/etc/redis/redis.conf
    ports:
      - "7001:7000"

  redis-node-3:
    image: redis:7-alpine
    command: redis-server /usr/local/etc/redis/redis.conf
    volumes:
      - ./redis/redis-3.conf:/usr/local/etc/redis/redis.conf
    ports:
      - "7002:7000"
```

### Load Balancing

#### Nginx Load Balancing

```nginx
upstream backend {
    # Load balancing method
    least_conn;
    
    # Backend servers
    server backend1:8000 weight=1 max_fails=3 fail_timeout=30s;
    server backend2:8000 weight=1 max_fails=3 fail_timeout=30s;
    server backend3:8000 weight=1 max_fails=3 fail_timeout=30s;
    
    # Health check
    keepalive 32;
}

# Backend server configuration
server {
    location /api/ {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Load balancing
        proxy_next_upstream error timeout invalid_header http_500 http_502 http_503;
        proxy_next_upstream_tries 3;
        proxy_next_upstream_timeout 30s;
        
        # Timeouts
        proxy_connect_timeout 5s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # Buffer settings
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 4k;
    }
}
```

### Performance Optimization

#### Database Optimization

```sql
-- PostgreSQL optimization settings
-- postgresql.conf
shared_buffers = 256MB
effective_cache_size = 1GB
work_mem = 4MB
maintenance_work_mem = 64MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
```

#### Application Optimization

```python
# Backend optimization settings
# app/config.py
class ProductionSettings(BaseSettings):
    # Database optimization
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 30
    DATABASE_POOL_TIMEOUT: int = 30
    
    # Redis optimization
    REDIS_POOL_SIZE: int = 50
    REDIS_MAX_CONNECTIONS: int = 100
    
    # Worker settings
    WORKER_PROCESSES: int = 4
    WORKER_CONNECTIONS: int = 1000
    
    # Caching
    ENABLE_CACHING: bool = True
    CACHE_TTL: int = 3600
    
    # Rate limiting
    ENABLE_RATE_LIMITING: bool = True
    RATE_LIMIT_PER_MINUTE: int = 1000

# Optimization middleware
@app.middleware("http")
async def optimize_requests(request: Request, call_next):
    start_time = time.time()
    
    # Enable response compression
    request.state.enable_compression = True
    
    response = await call_next(request)
    
    # Add performance headers
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["X-Content-Type-Options"] = "nosniff"
    
    return response
```

---

## Backup and Recovery

### Automated Backup Script

```bash
#!/bin/bash
# scripts/backup.sh

set -e

BACKUP_DIR="/backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR

echo "Starting backup at $(date)"

# Database backup
echo "Backing up database..."
docker exec customer-support_postgres_1 pg_dump -U postgres customer_support > $BACKUP_DIR/database.sql

# Redis backup
echo "Backing up Redis..."
docker cp customer-support_redis_1:/data/dump.rdb $BACKUP_DIR/redis.rdb

# ChromaDB backup
echo "Backing up ChromaDB..."
tar -czf $BACKUP_DIR/chromadb.tar.gz ./data/chromadb

# Application data
echo "Backing up application data..."
cp -r ./uploads $BACKUP_DIR/ 2>/dev/null || true
cp .env $BACKUP_DIR/
cp docker-compose.prod.yml $BACKUP_DIR/

# Upload to S3 (optional)
if [ ! -z "$AWS_S3_BUCKET" ]; then
    echo "Uploading backup to S3..."
    aws s3 sync $BACKUP_DIR s3://$AWS_S3_BUCKET/backups/$(basename $BACKUP_DIR)/
fi

# Cleanup old backups (keep last 7 days)
find /backups -type d -mtime +7 -exec rm -rf {} +

echo "Backup completed at $(date)"
echo "Backup location: $BACKUP_DIR"
```

### Recovery Script

```bash
#!/bin/bash
# scripts/recovery.sh

BACKUP_DATE=$1
if [ -z "$BACKUP_DATE" ]; then
    echo "Usage: $0 <backup_date> (format: YYYYMMDD_HHMMSS)"
    exit 1
fi

BACKUP_DIR="/backups/$BACKUP_DATE"

if [ ! -d "$BACKUP_DIR" ]; then
    echo "Backup directory not found: $BACKUP_DIR"
    exit 1
fi

echo "Starting recovery from backup: $BACKUP_DATE"
echo "WARNING: This will overwrite current data!"

read -p "Are you sure? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Recovery cancelled."
    exit 1
fi

# Stop services
docker-compose -f docker-compose.prod.yml down

# Restore database
echo "Restoring database..."
docker run --rm -v $(pwd)/$BACKUP_DIR:/backup -v customer-support_postgres_data:/var/lib/postgresql/data \
    postgres:15-alpine \
    bash -c "psql -h postgres -U postgres -d customer_support < /backup/database.sql"

# Restore Redis
echo "Restoring Redis..."
docker cp $BACKUP_DIR/redis.rdb customer-support_redis_1:/data/dump.rdb

# Restore ChromaDB
echo "Restoring ChromaDB..."
rm -rf ./data/chromadb
tar -xzf $BACKUP_DIR/chromadb.tar.gz -C ./data/

# Restore application data
echo "Restoring application data..."
cp -r $BACKUP_DIR/uploads ./ 2>/dev/null || true

# Restart services
docker-compose -f docker-compose.prod.yml up -d

echo "Recovery completed successfully!"
```

### Scheduled Backups

```bash
# Add to crontab
crontab -e

# Backup daily at 2 AM
0 2 * * * /path/to/customer-support/scripts/backup.sh >> /var/log/backup.log 2>&1

# Weekly cleanup ( Sundays at 3 AM)
0 3 * * 0 find /backups -type d -mtime +30 -exec rm -rf {} + >> /var/log/cleanup.log 2>&1
```

---

## Troubleshooting

### Common Issues

#### Backend Won't Start

```bash
# Check logs
docker-compose logs backend

# Check environment variables
docker-compose exec backend env | grep -E "(DATABASE|REDIS|OPENAI)"

# Check database connectivity
docker-compose exec backend python -c "
from app.database import engine
try:
    with engine.connect() as conn:
        result = conn.execute('SELECT 1')
        print('Database connection: OK')
except Exception as e:
    print(f'Database connection failed: {e}')
"

# Check Redis connectivity
docker-compose exec backend python -c "
import redis
try:
    r = redis.from_url('redis://redis:6379')
    r.ping()
    print('Redis connection: OK')
except Exception as e:
    print(f'Redis connection failed: {e}')
"
```

#### High Memory Usage

```bash
# Check memory usage
docker stats

# Check for memory leaks
docker-compose exec backend python -c "
import psutil
import os
process = psutil.Process(os.getpid())
print(f'Memory usage: {process.memory_info().rss / 1024 / 1024:.2f} MB')
print(f'Memory percent: {process.memory_percent():.2f}%')
"

# Check for database connections
docker-compose exec postgres psql -U postgres -d customer_support -c "
SELECT count(*) as active_connections 
FROM pg_stat_activity 
WHERE state = 'active';
"
```

#### Slow Response Times

```bash
# Check response times
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:8000/health

# Where curl-format.txt contains:
cat > curl-format.txt << EOF
     time_namelookup:  %{time_namelookup}\n
        time_connect:  %{time_connect}\n
     time_appconnect:  %{time_appconnect}\n
    time_pretransfer:  %{time_pretransfer}\n
       time_redirect:  %{time_redirect}\n
  time_starttransfer:  %{time_starttransfer}\n
                     ----------\n
          time_total:  %{time_total}\n
EOF

# Check database query performance
docker-compose exec postgres psql -U postgres -d customer_support -c "
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
"

# Check ChromaDB performance
docker-compose exec backend python -c "
import time
import chromadb
client = chromadb.Client()
start = time.time()
# Simulate search
collection = client.get_collection('knowledge_base')
results = collection.query(query_texts=['test'], n_results=5)
print(f'Search time: {time.time() - start:.3f}s')
print(f'Results: {len(results[\"documents\"][0])}')
"
```

### Performance Monitoring

```bash
# CPU usage
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"

# Memory analysis
docker-compose exec backend python -c "
import tracemalloc
tracemalloc.start()
# Your code here
current, peak = tracemalloc.get_traced_memory()
print(f'Current memory usage: {current / 1024 / 1024:.1f} MB')
print(f'Peak memory usage: {peak / 1024 / 1024:.1f} MB')
"

# Database connection pool monitoring
docker-compose exec backend python -c "
from sqlalchemy import create_engine
engine = create_engine('${DATABASE_URL}')
with engine.connect() as conn:
    pool = engine.pool
    print(f'Pool size: {pool.size()}')
    print(f'Checked in: {pool.checkedin()}')
    print(f'Checked out: {pool.checkedout()}')
    print(f'Overflow: {pool.overflow()}')
"
```

### Log Analysis

```bash
# View recent logs
docker-compose logs --tail=100 backend

# Follow logs in real-time
docker-compose logs -f backend

# Search for errors
docker-compose logs backend | grep -i error

# Count error types
docker-compose logs backend | grep -oE 'ERROR \w+' | sort | uniq -c

# Monitor slow requests
docker-compose logs backend | grep -E 'duration=[0-9.]+s' | sort -k5 -nr | head -20
```

This comprehensive deployment guide provides all the necessary information to deploy the Customer Support AI Agent in various environments with proper monitoring, scaling, and security configurations.
