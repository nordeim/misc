/**
 * Custom React hook for managing application theme.
 * 
 * Provides light/dark theme switching with local storage persistence
 * and system preference detection.
 */

import { useState, useEffect, useCallback } from 'react';

type Theme = 'light' | 'dark';

interface UseAppThemeReturn {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
  isDark: boolean;
  isLight: boolean;
}

export const useAppTheme = (): UseAppThemeReturn => {
  const [theme, setThemeState] = useState<Theme>(() => {
    // Check local storage first
    const saved = localStorage.getItem('app_theme');
    if (saved === 'light' || saved === 'dark') {
      return saved;
    }
    
    // Check system preference
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    
    return 'light';
  });

  const [isDark, setIsDark] = useState(theme === 'dark');
  const [isLight, setIsLight] = useState(theme === 'light');

  // Apply theme to document
  const applyTheme = useCallback((newTheme: Theme) => {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove('light', 'dark');
    
    // Add new theme class
    root.classList.add(newTheme);
    
    // Update meta theme-color for mobile browsers
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute(
        'content', 
        newTheme === 'dark' ? '#111827' : '#ffffff'
      );
    }
  }, []);

  // Update localStorage and document when theme changes
  useEffect(() => {
    localStorage.setItem('app_theme', theme);
    applyTheme(theme);
    setIsDark(theme === 'dark');
    setIsLight(theme === 'light');
  }, [theme, applyTheme]);

  // Listen for system theme changes
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      // Only auto-switch if user hasn't explicitly set a preference
      const saved = localStorage.getItem('app_theme');
      if (!saved) {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };

    // Modern browsers
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
    
    // Fallback for older browsers
    mediaQuery.addListener(handleChange);
    return () => mediaQuery.removeListener(handleChange);
  }, []);

  // Theme switching functions
  const toggleTheme = useCallback(() => {
    setThemeState(prev => prev === 'light' ? 'dark' : 'light');
  }, []);

  const setTheme = useCallback((newTheme: Theme) => {
    setThemeState(newTheme);
  }, []);

  return {
    theme,
    toggleTheme,
    setTheme,
    isDark,
    isLight,
  };
};