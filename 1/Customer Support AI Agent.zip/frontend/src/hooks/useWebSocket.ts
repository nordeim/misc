/**
 * Custom React hook for managing WebSocket connections.
 * 
 * Provides comprehensive WebSocket functionality with reconnection,
 * message handling, typing indicators, and connection status monitoring.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

interface UseWebSocketOptions {
  onMessage?: (data: any) => void;
  onTyping?: (isTyping: boolean) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: any) => void;
  autoConnect?: boolean;
  reconnectAttempts?: number;
  reconnectDelay?: number;
  heartbeatInterval?: number;
}

interface UseWebSocketReturn {
  sendMessage: (message: any) => void;
  isConnected: boolean;
  isConnecting: boolean;
  isTyping: boolean;
  connectionError: string | null;
  lastMessage: any;
  connect: () => void;
  disconnect: () => void;
  reconnect: () => void;
}

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000';

export const useWebSocket = (options: UseWebSocketOptions = {}): UseWebSocketReturn => {
  const {
    onMessage,
    onTyping,
    onConnect,
    onDisconnect,
    onError,
    autoConnect = true,
    reconnectAttempts = 5,
    reconnectDelay = 1000,
    heartbeatInterval = 30000,
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [lastMessage, setLastMessage] = useState<any>(null);

  const socketRef = useRef<Socket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const heartbeatTimeoutRef = useRef<NodeJS.Timeout>();
  const clientId = useRef(`client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const reconnectAttemptsLeft = useRef(reconnectAttempts);
  const connectionStartTime = useRef<number>(0);

  const connect = useCallback(() => {
    if (socketRef.current?.connected) {
      return;
    }

    if (isConnecting) {
      return;
    }

    setIsConnecting(true);
    setConnectionError(null);
    connectionStartTime.current = Date.now();
    reconnectAttemptsLeft.current = reconnectAttempts;

    try {
      socketRef.current = io(WS_URL, {
        transports: ['websocket'],
        upgrade: false,
        reconnection: true,
        reconnectionDelay: reconnectDelay,
        reconnectionDelayMax: reconnectDelay * 5,
        reconnectionAttempts: reconnectAttempts,
        timeout: 10000,
      });

      const socket = socketRef.current;

      socket.on('connect', () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        setIsConnecting(false);
        setConnectionError(null);
        reconnectAttemptsLeft.current = reconnectAttempts;
        
        // Start heartbeat
        startHeartbeat();
        
        // Send connection info
        socket.emit('connection', {
          client_id: clientId.current,
          timestamp: new Date().toISOString(),
        });
        
        onConnect?.();
      });

      socket.on('disconnect', (reason) => {
        console.log('WebSocket disconnected:', reason);
        setIsConnected(false);
        setIsConnecting(false);
        setIsTyping(false);
        stopHeartbeat();
        onDisconnect?.(reason);
        
        // Auto-reconnect unless it was a manual disconnect
        if (reason !== 'io client disconnect' && reconnectAttemptsLeft.current > 0) {
          scheduleReconnect();
        }
      });

      socket.on('connect_error', (error) => {
        console.error('WebSocket connection error:', error);
        setIsConnected(false);
        setIsConnecting(false);
        setConnectionError(error.message || 'Connection failed');
        onError?.(error);
        
        // Schedule retry if attempts left
        if (reconnectAttemptsLeft.current > 0) {
          scheduleReconnect();
        }
      });

      socket.on('message', (data) => {
        console.log('WebSocket message received:', data);
        setLastMessage(data);
        
        if (data.type === 'typing_indicator' && data.client_id === 'agent') {
          setIsTyping(data.is_typing);
          onTyping?.(data.is_typing);
        } else if (data.type === 'chat_response' || data.type === 'error') {
          onMessage?.(data);
        }
      });

      socket.on('chat_response', (data) => {
        console.log('Chat response received:', data);
        setLastMessage(data);
        onMessage?.(data);
      });

      socket.on('error', (error) => {
        console.error('WebSocket error:', error);
        setConnectionError(error.message || 'WebSocket error');
        onError?.(error);
      });

    } catch (error: any) {
      console.error('Failed to create WebSocket connection:', error);
      setIsConnecting(false);
      setConnectionError(error.message || 'Failed to create connection');
      onError?.(error);
    }
  }, [onMessage, onTyping, onConnect, onDisconnect, onError, isConnecting, reconnectAttempts, reconnectDelay]);

  const scheduleReconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }

    if (reconnectAttemptsLeft.current > 0) {
      const delay = reconnectDelay * Math.pow(1.5, (reconnectAttempts - reconnectAttemptsLeft.current));
      
      reconnectTimeoutRef.current = setTimeout(() => {
        reconnectAttemptsLeft.current -= 1;
        connect();
      }, delay);
    } else {
      setConnectionError('Max reconnection attempts reached');
    }
  }, [connect, reconnectAttempts, reconnectDelay]);

  const startHeartbeat = useCallback(() => {
    if (heartbeatTimeoutRef.current) {
      clearTimeout(heartbeatTimeoutRef.current);
    }

    const sendHeartbeat = () => {
      if (socketRef.current?.connected) {
        socketRef.current.emit('heartbeat', {
          client_id: clientId.current,
          timestamp: new Date().toISOString(),
        });
        
        heartbeatTimeoutRef.current = setTimeout(sendHeartbeat, heartbeatInterval);
      }
    };

    sendHeartbeat();
  }, [heartbeatInterval]);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatTimeoutRef.current) {
      clearTimeout(heartbeatTimeoutRef.current);
    }
  }, []);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    stopHeartbeat();
    
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    
    setIsConnected(false);
    setIsConnecting(false);
    setIsTyping(false);
    setConnectionError(null);
    reconnectAttemptsLeft.current = 0;
  }, [stopHeartbeat]);

  const reconnect = useCallback(() => {
    disconnect();
    setTimeout(connect, 100);
  }, [disconnect, connect]);

  const sendMessage = useCallback((message: any) => {
    if (!socketRef.current?.connected) {
      console.warn('WebSocket not connected, cannot send message');
      return;
    }

    try {
      socketRef.current.emit('message', {
        ...message,
        client_id: clientId.current,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Failed to send WebSocket message:', error);
      onError?.(error);
    }
  }, [onError]);

  // Auto-connect on mount
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [connect, disconnect, autoConnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      stopHeartbeat();
    };
  }, [stopHeartbeat]);

  return {
    sendMessage,
    isConnected,
    isConnecting,
    isTyping,
    connectionError,
    lastMessage,
    connect,
    disconnect,
    reconnect,
  };
};