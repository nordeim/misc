/**
 * Custom React hook for managing file uploads.
 * 
 * Provides file selection, validation, upload progress tracking,
 * and error handling for file uploads.
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { apiService } from '../services/api';
import { toast } from 'react-hot-toast';
import { UploadedFile } from '../types';

interface FileValidationOptions {
  maxSize?: number; // in bytes
  maxFiles?: number;
  allowedTypes?: string[];
  allowedExtensions?: string[];
}

interface UploadProgress {
  fileId: string;
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  uploadedPath?: string;
}

interface UseFileUploadOptions {
  sessionId?: string;
  validation?: FileValidationOptions;
  onUploadComplete?: (files: UploadedFile[]) => void;
  onUploadError?: (error: string, fileId: string) => void;
}

interface UseFileUploadReturn {
  // State
  files: File[];
  uploadProgress: UploadProgress[];
  isUploading: boolean;
  uploadError: string | null;
  
  // Actions
  selectFiles: (fileList: FileList | File[]) => void;
  removeFile: (index: number) => void;
  clearFiles: () => void;
  uploadFiles: () => Promise<UploadedFile[]>;
  uploadFile: (index: number) => Promise<UploadedFile>;
  
  // Validation
  validateFiles: (files: FileList | File[]) => { valid: File[]; errors: string[] };
  getFileIcon: (fileName: string) => string;
  formatFileSize: (bytes: number) => string;
}

const DEFAULT_VALIDATION: Required<FileValidationOptions> = {
  maxSize: 10 * 1024 * 1024, // 10MB
  maxFiles: 5,
  allowedTypes: [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'application/pdf', 'text/plain', 'text/csv',
    'application/json', 'application/xml',
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  ],
  allowedExtensions: ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.pdf', '.txt', '.csv', '.json', '.xml', '.doc', '.docx', '.xls', '.xlsx']
};

export const useFileUpload = (options: UseFileUploadOptions = {}): UseFileUploadReturn => {
  const {
    sessionId,
    validation = {},
    onUploadComplete,
    onUploadError,
  } = options;

  // State
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const fileIdCounter = useRef(0);

  // Merge default validation with options
  const mergedValidation = {
    ...DEFAULT_VALIDATION,
    ...validation,
  };

  const generateFileId = useCallback(() => {
    fileIdCounter.current += 1;
    return `file_${Date.now()}_${fileIdCounter.current}`;
  }, []);

  const selectFiles = useCallback((fileList: FileList | File[]) => {
    const newFiles = Array.from(fileList);
    
    // Validate files
    const validationResult = validateFiles(newFiles);
    
    if (validationResult.errors.length > 0) {
      const errorMessage = validationResult.errors.join(', ');
      setUploadError(errorMessage);
      toast.error(`File validation failed: ${errorMessage}`);
      return;
    }

    // Check total file count limit
    if (files.length + validationResult.valid.length > mergedValidation.maxFiles) {
      const errorMessage = `Maximum ${mergedValidation.maxFiles} files allowed`;
      setUploadError(errorMessage);
      toast.error(errorMessage);
      return;
    }

    setFiles(prev => [...prev, ...validationResult.valid]);
    setUploadError(null);

    // Show success message
    if (validationResult.valid.length > 0) {
      toast.success(`${validationResult.valid.length} file(s) selected`);
    }
  }, [files, mergedValidation]);

  const removeFile = useCallback((index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setUploadProgress(prev => prev.filter(progress => !progress.fileName.startsWith(files[index]?.name || '')));
  }, [files]);

  const clearFiles = useCallback(() => {
    setFiles([]);
    setUploadProgress([]);
    setUploadError(null);
  }, []);

  const validateFiles = useCallback((filesToValidate: FileList | File[]): { valid: File[]; errors: string[] } => {
    const filesArray = Array.from(filesToValidate);
    const valid: File[] = [];
    const errors: string[] = [];

    filesArray.forEach((file) => {
      // Check file size
      if (file.size > mergedValidation.maxSize) {
        errors.push(`${file.name}: File too large (${formatFileSize(file.size)} > ${formatFileSize(mergedValidation.maxSize)})`);
        return;
      }

      // Check file type
      if (mergedValidation.allowedTypes.length > 0 && !mergedValidation.allowedTypes.includes(file.type)) {
        // Check extension as fallback
        const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
        if (!mergedValidation.allowedExtensions.includes(fileExtension)) {
          errors.push(`${file.name}: File type not supported`);
          return;
        }
      }

      // Check for duplicate files
      if (files.some(existingFile => existingFile.name === file.name && existingFile.size === file.size)) {
        errors.push(`${file.name}: Duplicate file`);
        return;
      }

      valid.push(file);
    });

    return { valid, errors };
  }, [files, mergedValidation]);

  const uploadFiles = useCallback(async (): Promise<UploadedFile[]> => {
    if (files.length === 0) {
      throw new Error('No files to upload');
    }

    if (!sessionId) {
      throw new Error('Session ID is required for file upload');
    }

    setIsUploading(true);
    setUploadError(null);
    
    // Initialize progress tracking
    const progressMap = files.map(file => ({
      fileId: generateFileId(),
      fileName: file.name,
      progress: 0,
      status: 'pending' as const,
    }));
    setUploadProgress(progressMap);

    const uploadedFiles: UploadedFile[] = [];
    const errors: string[] = [];

    try {
      // Upload all files
      const uploadPromises = files.map(async (file, index) => {
        const fileId = progressMap[index].fileId;
        
        try {
          // Update progress to uploading
          setUploadProgress(prev => prev.map(p => 
            p.fileId === fileId ? { ...p, status: 'uploading', progress: 0 } : p
          ));

          // Simulate progress updates (in real implementation, you'd get this from the upload service)
          const progressInterval = setInterval(() => {
            setUploadProgress(prev => prev.map(p => 
              p.fileId === fileId && p.progress < 90 
                ? { ...p, progress: p.progress + 10 } 
                : p
            ));
          }, 200);

          const result = await apiService.uploadFile(file, sessionId);
          
          clearInterval(progressInterval);
          
          // Update progress to success
          setUploadProgress(prev => prev.map(p => 
            p.fileId === fileId ? { 
              ...p, 
              progress: 100, 
              status: 'success',
              uploadedPath: result.path 
            } : p
          ));

          const uploadedFile: UploadedFile = {
            name: result.path,
            size: file.size,
            type: file.type,
            lastModified: file.lastModified,
          };

          uploadedFiles.push(uploadedFile);
          return uploadedFile;

        } catch (error: any) {
          const errorMessage = `Failed to upload ${file.name}: ${error.message}`;
          errors.push(errorMessage);
          
          setUploadProgress(prev => prev.map(p => 
            p.fileId === fileId ? { 
              ...p, 
              status: 'error', 
              error: errorMessage 
            } : p
          ));
          
          onUploadError?.(errorMessage, fileId);
          return null;
        }
      });

      const results = await Promise.all(uploadPromises);
      const successfulUploads = results.filter((result): result is UploadedFile => result !== null);

      if (errors.length > 0) {
        const errorMessage = `${errors.length} file(s) failed to upload`;
        setUploadError(errorMessage);
        toast.error(errorMessage);
      }

      if (successfulUploads.length > 0) {
        toast.success(`${successfulUploads.length} file(s) uploaded successfully`);
        onUploadComplete?.(successfulUploads);
      }

      // Clear successfully uploaded files from selection
      if (successfulUploads.length > 0) {
        setFiles([]);
      }

      return successfulUploads;

    } finally {
      setIsUploading(false);
    }
  }, [files, sessionId, generateFileId, onUploadComplete, onUploadError]);

  const uploadFile = useCallback(async (index: number): Promise<UploadedFile> => {
    if (index < 0 || index >= files.length) {
      throw new Error('Invalid file index');
    }

    const singleFile = files[index];
    const result = await uploadFiles(); // This will upload all files
    // Return the first uploaded file (could be improved to upload specific file)
    return result[0];
  }, [files, uploadFiles]);

  const getFileIcon = useCallback((fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    switch (extension) {
      case 'pdf':
        return '📄';
      case 'doc':
      case 'docx':
        return '📝';
      case 'txt':
        return '📃';
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
      case 'webp':
        return '🖼️';
      case 'xls':
      case 'xlsx':
        return '📊';
      case 'csv':
        return '📈';
      case 'json':
        return '📋';
      case 'xml':
        return '📋';
      default:
        return '📎';
    }
  }, []);

  const formatFileSize = useCallback((bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }, []);

  // Cleanup progress tracking for removed files
  useEffect(() => {
    setUploadProgress(prev => prev.filter(progress => 
      files.some(file => file.name.startsWith(progress.fileName.split('.')[0]))
    ));
  }, [files]);

  return {
    // State
    files,
    uploadProgress,
    isUploading,
    uploadError,
    
    // Actions
    selectFiles,
    removeFile,
    clearFiles,
    uploadFiles,
    uploadFile,
    
    // Utility
    validateFiles,
    getFileIcon,
    formatFileSize,
  };
};