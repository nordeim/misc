import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import axios from 'axios'
import * as api from '../services/api'

// Mock axios
vi.mock('axios', () => ({
  default: {
    create: vi.fn(() => ({
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      delete: vi.fn(),
      interceptors: {
        request: {
          use: vi.fn(),
        },
        response: {
          use: vi.fn(),
        },
      },
    })),
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
  },
}))

describe('API Service', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  describe('Authentication API', () => {
    it('should login successfully', async () => {
      const mockResponse = {
        data: {
          access_token: 'mock-token',
          token_type: 'bearer',
          user: {
            id: '1',
            username: 'testuser',
            email: 'test@example.com',
          },
        },
      }

      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.login('testuser', 'password')
      
      expect(axios.post).toHaveBeenCalledWith('/api/auth/login', {
        username: 'testuser',
        password: 'password',
      })
      expect(result).toEqual(mockResponse.data)
    })

    it('should handle login error', async () => {
      const error = new Error('Invalid credentials')
      vi.mocked(axios.post).mockRejectedValue(error)

      await expect(api.login('testuser', 'wrongpassword')).rejects.toThrow('Invalid credentials')
    })

    it('should logout successfully', async () => {
      const mockResponse = { data: { message: 'Logged out' } }
      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.logout()
      
      expect(axios.post).toHaveBeenCalledWith('/api/auth/logout')
      expect(result).toEqual(mockResponse.data)
    })

    it('should get current user', async () => {
      const mockResponse = {
        data: {
          id: '1',
          username: 'testuser',
          email: 'test@example.com',
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.getCurrentUser()
      
      expect(axios.get).toHaveBeenCalledWith('/api/auth/me')
      expect(result).toEqual(mockResponse.data)
    })
  })

  describe('Chat API', () => {
    it('should send message successfully', async () => {
      const mockResponse = {
        data: {
          id: '1',
          content: 'Hello',
          sender: 'user',
          timestamp: new Date().toISOString(),
        },
      }
      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.sendMessage('Hello')
      
      expect(axios.post).toHaveBeenCalledWith('/api/chat/messages', {
        content: 'Hello',
      })
      expect(result).toEqual(mockResponse.data)
    })

    it('should get chat messages', async () => {
      const mockResponse = {
        data: {
          messages: [
            {
              id: '1',
              content: 'Hello',
              sender: 'user',
            },
            {
              id: '2',
              content: 'Hi there',
              sender: 'agent',
            },
          ],
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.getMessages('session-1')
      
      expect(axios.get).toHaveBeenCalledWith('/api/chat/messages?session_id=session-1')
      expect(result).toEqual(mockResponse.data)
    })

    it('should get chat history', async () => {
      const mockResponse = {
        data: {
          sessions: [
            {
              session_id: 'session-1',
              last_message: 'Hello',
              timestamp: new Date().toISOString(),
            },
          ],
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.getChatHistory()
      
      expect(axios.get).toHaveBeenCalledWith('/api/chat/history')
      expect(result).toEqual(mockResponse.data)
    })

    it('should search messages', async () => {
      const mockResponse = {
        data: {
          results: [
            {
              id: '1',
              content: 'Hello world',
              sender: 'user',
            },
          ],
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.searchMessages('hello')
      
      expect(axios.get).toHaveBeenCalledWith('/api/chat/search?q=hello')
      expect(result).toEqual(mockResponse.data)
    })
  })

  describe('File Upload API', () => {
    it('should upload file successfully', async () => {
      const mockFile = new File(['test'], 'test.pdf', { type: 'application/pdf' })
      const mockResponse = {
        data: {
          success: true,
          file_id: 'file-123',
          filename: 'test.pdf',
        },
      }
      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.uploadFile(mockFile)
      
      expect(axios.post).toHaveBeenCalledWith(
        '/api/upload',
        expect.any(FormData),
        expect.objectContaining({
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        })
      )
      expect(result).toEqual(mockResponse.data)
    })

    it('should handle upload progress', async () => {
      const mockFile = new File(['test'], 'test.pdf', { type: 'application/pdf' })
      const onProgress = vi.fn()
      vi.mocked(axios.post).mockImplementation((url, data, config) => {
        if (config?.onUploadProgress) {
          config.onUploadProgress({ loaded: 50, total: 100 })
        }
        return Promise.resolve({ data: { success: true } })
      })

      await api.uploadFile(mockFile, onProgress)
      
      expect(onProgress).toHaveBeenCalledWith(50, 100)
    })

    it('should delete file', async () => {
      const mockResponse = { data: { message: 'File deleted' } }
      vi.mocked(axios.delete).mockResolvedValue(mockResponse)

      const result = await api.deleteFile('file-123')
      
      expect(axios.delete).toHaveBeenCalledWith('/api/upload/file-123')
      expect(result).toEqual(mockResponse.data)
    })
  })

  describe('Session API', () => {
    it('should create new session', async () => {
      const mockResponse = {
        data: {
          session_id: 'session-123',
          created_at: new Date().toISOString(),
          status: 'active',
        },
      }
      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.createSession()
      
      expect(axios.post).toHaveBeenCalledWith('/api/sessions')
      expect(result).toEqual(mockResponse.data)
    })

    it('should get session details', async () => {
      const mockResponse = {
        data: {
          session_id: 'session-123',
          status: 'active',
          message_count: 5,
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.getSession('session-123')
      
      expect(axios.get).toHaveBeenCalledWith('/api/sessions/session-123')
      expect(result).toEqual(mockResponse.data)
    })

    it('should end session', async () => {
      const mockResponse = { data: { message: 'Session ended' } }
      vi.mocked(axios.post).mockResolvedValue(mockResponse)

      const result = await api.endSession('session-123')
      
      expect(axios.post).toHaveBeenCalledWith('/api/sessions/session-123/end')
      expect(result).toEqual(mockResponse.data)
    })
  })

  describe('Health Check API', () => {
    it('should perform health check', async () => {
      const mockResponse = {
        data: {
          status: 'healthy',
          timestamp: new Date().toISOString(),
          version: '1.0.0',
        },
      }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      const result = await api.healthCheck()
      
      expect(axios.get).toHaveBeenCalledWith('/api/health')
      expect(result).toEqual(mockResponse.data)
    })
  })

  describe('Error Handling', () => {
    it('should handle network errors', async () => {
      const networkError = new Error('Network Error')
      vi.mocked(axios.get).mockRejectedValue(networkError)

      await expect(api.healthCheck()).rejects.toThrow('Network Error')
    })

    it('should handle HTTP errors', async () => {
      const httpError = {
        response: {
          status: 404,
          data: { error: 'Not found' },
        },
      }
      vi.mocked(axios.get).mockRejectedValue(httpError)

      await expect(api.healthCheck()).rejects.toThrow('Not found')
    })

    it('should handle timeout errors', async () => {
      const timeoutError = {
        code: 'ECONNABORTED',
        message: 'Request timeout',
      }
      vi.mocked(axios.get).mockRejectedValue(timeoutError)

      await expect(api.healthCheck()).rejects.toThrow('Request timeout')
    })
  })

  describe('Request Interceptors', () => {
    it('should add auth token to requests', async () => {
      const mockResponse = { data: { message: 'success' } }
      vi.mocked(axios.get).mockResolvedValue(mockResponse)

      // Set auth token
      api.setAuthToken('Bearer token123')
      
      await api.healthCheck()
      
      expect(axios.get).toHaveBeenCalledWith('/api/health', {
        headers: {
          Authorization: 'Bearer token123',
        },
      })
    })

    it('should remove auth token', async () => {
      vi.mocked(axios.get).mockResolvedValue({ data: {} })

      api.setAuthToken('Bearer token123')
      api.clearAuthToken()
      
      await api.healthCheck()
      
      // Should not have auth header
      const call = axios.get.mock.calls[0]
      expect(call[1]?.headers?.Authorization).toBeUndefined()
    })
  })

  describe('Rate Limiting', () => {
    it('should handle rate limit responses', async () => {
      const rateLimitError = {
        response: {
          status: 429,
          data: { error: 'Too many requests' },
          headers: {
            'retry-after': '60',
          },
        },
      }
      vi.mocked(axios.post).mockRejectedValue(rateLimitError)

      await expect(api.sendMessage('test')).rejects.toThrow('Too many requests')
    })
  })
})