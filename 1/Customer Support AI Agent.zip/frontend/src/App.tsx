/**
 * Main React application component.

Entry point for the frontend application with routing, global state,
error boundaries, theme management, and loading states.
Integrates service worker, push notifications, offline support,
and responsive design.
 */

import React, { Suspense, lazy, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './hooks/useAuth';
import { ThemeProvider } from './components/ThemeProvider';
import Header from './components/Header';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorBoundary from './components/ErrorBoundary';
import ConnectionStatus from './components/ConnectionStatus';
import { useAuth } from './hooks/useAuth';
import { registerServiceWorker } from './utils/serviceWorker';
import { requestNotificationPermission } from './utils/pushNotifications';
import { loadTheme, loadUserPreferences } from './utils/localStorage';
import { showInfo, showError } from './utils/errorHandling';
import { BROWSER_INFO, FEATURES } from './utils';
import './styles/index.css';

// Lazy load components for better performance
const ChatInterface = lazy(() => import('./components/ChatInterface'));
const Settings = lazy(() => import('./components/Settings'));
const Login = lazy(() => import('./components/Login'));
const Register = lazy(() => import('./components/Register'));



// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// Public Route Component (redirect if authenticated)
const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }
  
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

// Layout Component
const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { theme } = useAppTheme();
  
  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' 
        ? 'bg-gray-900 text-white' 
        : 'bg-gray-50 text-gray-900'
    }`}>
      <Header />
      
      {/* Connection Status - Mobile responsive */}
      <div className="fixed top-4 right-4 z-50 md:top-6 md:right-6">
        <ConnectionStatus 
          showDetails={false}
          className="shadow-lg"
        />
      </div>
      
      <main className="container mx-auto px-4 py-4 md:py-8 max-w-7xl">
        {children}
      </main>
      
      {/* PWA Install Prompt */}
      {FEATURES.serviceWorker && (
        <PWAInstallPrompt />
      )}
    </div>
  );
};

// PWA Install Prompt Component
const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = React.useState<any>(null);
  const [showPrompt, setShowPrompt] = React.useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      showInfo('App installed successfully!');
    }
    
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-4 z-50">
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white">
            Install Customer Support AI
          </h4>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Get quick access and offline support by installing our app.
          </p>
          <div className="flex space-x-2 mt-3">
            <button
              onClick={handleInstall}
              className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md transition-colors"
            >
              Install
            </button>
            <button
              onClick={handleDismiss}
              className="text-xs bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 px-3 py-1 rounded-md transition-colors"
            >
              Not now
            </button>
          </div>
        </div>
        <button
          onClick={handleDismiss}
          className="flex-shrink-0 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
};

// Main App Routes
const AppRoutes: React.FC = () => {
  return (
    <Suspense fallback={<LoadingSpinner size="lg" />}>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        } />
        <Route path="/register" element={
          <PublicRoute>
            <Register />
          </PublicRoute>
        } />
        
        {/* Protected Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout>
              <ChatInterface />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/chat/:sessionId" element={
          <ProtectedRoute>
            <Layout>
              <ChatInterface />
            </Layout>
          </ProtectedRoute>
        } />
        <Route path="/settings" element={
          <ProtectedRoute>
            <Layout>
              <Settings />
            </Layout>
          </ProtectedRoute>
        } />
        
        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
};

// Initialize application services
const initializeApp = async () => {
  try {
    // Register service worker for offline support
    if (FEATURES.serviceWorker && import.meta.env.PROD) {
      registerServiceWorker({
        onSuccess: () => {
          console.log('Service Worker registered successfully');
          showInfo('App is ready for offline use');
        },
        onUpdate: () => {
          showInfo('App update available. Refresh to get the latest version.');
        },
        onOfflineReady: () => {
          showInfo('App ready to work offline');
        }
      });
    }

    // Request notification permission
    if (FEATURES.pushNotifications) {
      try {
        const permission = await requestNotificationPermission();
        if (permission === 'granted') {
          console.log('Notification permission granted');
        }
      } catch (error) {
        console.warn('Failed to request notification permission:', error);
      }
    }

    // Load saved user preferences
    try {
      const preferences = await loadUserPreferences();
      if (preferences) {
        console.log('User preferences loaded');
      }
    } catch (error) {
      console.warn('Failed to load user preferences:', error);
    }

    // Log browser information in development
    if (import.meta.env.DEV) {
      console.log('Browser Info:', BROWSER_INFO);
      console.log('Features:', FEATURES);
    }

  } catch (error) {
    console.error('Failed to initialize app:', error);
    showError('Failed to initialize application. Some features may not work properly.');
  }
};

function App() {
  const { theme } = useAppTheme();

  // Initialize app services on mount
  useEffect(() => {
    initializeApp();
  }, []);
  
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <div className="app" data-theme={theme}>
            <AppRoutes />
            
            {/* Global Toast Notifications - Mobile responsive */}
            <Toaster 
              position={BROWSER_INFO.device.mobile ? "top-center" : "top-right"}
              toastOptions={{
                duration: 4000,
                className: 'toast',
                success: {
                  iconTheme: {
                    primary: '#10B981',
                    secondary: '#FFFFFF',
                  },
                },
                error: {
                  iconTheme: {
                    primary: '#EF4444',
                    secondary: '#FFFFFF',
                  },
                },
                loading: {
                  iconTheme: {
                    primary: '#3B82F6',
                    secondary: '#FFFFFF',
                  },
                },
                style: {
                  background: theme === 'dark' ? '#374151' : '#ffffff',
                  color: theme === 'dark' ? '#ffffff' : '#1f2937',
                  borderRadius: '8px',
                  fontSize: '14px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
                  maxWidth: BROWSER_INFO.device.mobile ? 'calc(100vw - 2rem)' : '400px',
                },
              }}
            />
          </div>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;