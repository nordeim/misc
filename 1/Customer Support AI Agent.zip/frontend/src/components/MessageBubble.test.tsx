import { describe, it, expect, vi } from 'vitest'
import { screen } from '@testing-library/react'
import { renderWithProviders, createMockMessage } from '@/test/utils'
import MessageBubble from './MessageBubble'

// Mock icons
vi.mock('@heroicons/react/24/outline', () => ({
  UserIcon: ({ className }: { className?: string }) => (
    <svg data-testid="user-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  ),
  UserCircleIcon: ({ className }: { className?: string }) => (
    <svg data-testid="user-circle-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
}))

describe('MessageBubble', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders user message correctly', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Hello, this is a user message',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    expect(screen.getByText('Hello, this is a user message')).toBeInTheDocument()
    expect(screen.getByTestId('user-icon')).toBeInTheDocument()
  })

  it('renders agent message correctly', () => {
    const message = createMockMessage({
      id: '2',
      content: 'Hello, I am an AI assistant',
      sender: 'agent',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    expect(screen.getByText('Hello, I am an AI assistant')).toBeInTheDocument()
    expect(screen.getByTestId('user-circle-icon')).toBeInTheDocument()
  })

  it('applies correct styling for user messages', () => {
    const message = createMockMessage({
      id: '1',
      content: 'User message',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toHaveClass(
      'bg-blue-500',
      'text-white',
      'ml-auto',
      'max-w-xs',
      'lg:max-w-md'
    )
  })

  it('applies correct styling for agent messages', () => {
    const message = createMockMessage({
      id: '2',
      content: 'Agent message',
      sender: 'agent',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toHaveClass(
      'bg-white',
      'text-gray-900',
      'shadow',
      'mr-auto',
      'max-w-xs',
      'lg:max-w-md'
    )
  })

  it('formats timestamps correctly', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Message with timestamp',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    const timestamp = screen.getByTestId('message-timestamp')
    expect(timestamp).toBeInTheDocument()
    expect(timestamp).toHaveClass('text-xs', 'opacity-75')
  })

  it('handles long messages gracefully', () => {
    const longMessage = createMockMessage({
      id: '1',
      content: 'This is a very long message that should be wrapped properly and not break the layout of the message bubble component. It contains multiple sentences and should demonstrate how the component handles longer content while maintaining proper spacing and readability.',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={longMessage} />)
    
    expect(screen.getByText(longMessage.content)).toBeInTheDocument()
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toHaveClass('break-words')
  })

  it('handles empty messages', () => {
    const emptyMessage = createMockMessage({
      id: '1',
      content: '',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={emptyMessage} />)
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toBeInTheDocument()
  })

  it('displays sender name correctly', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Message with sender',
      sender: 'agent',
      sender_name: 'AI Assistant',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    expect(screen.getByText('AI Assistant')).toBeInTheDocument()
  })

  it('has proper accessibility attributes', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Accessible message',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toHaveAttribute('role', 'article')
    expect(bubble).toHaveAttribute('aria-label', 'Message from user')
  })

  it('supports message reactions', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Message with reactions',
      sender: 'user',
      reactions: [
        { emoji: '👍', count: 2 },
        { emoji: '❤️', count: 1 },
      ],
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    expect(screen.getByText('👍 2')).toBeInTheDocument()
    expect(screen.getByText('❤️ 1')).toBeInTheDocument()
  })

  it('displays file attachments', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Message with file',
      sender: 'user',
      file_attachments: [
        {
          id: 'file-1',
          filename: 'document.pdf',
          size: 1024,
          mime_type: 'application/pdf',
        },
      ],
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    expect(screen.getByText('document.pdf')).toBeInTheDocument()
  })

  it('handles message status indicators', () => {
    const message = createMockMessage({
      id: '1',
      content: 'Status message',
      sender: 'user',
      status: 'delivered',
    })

    renderWithProviders(<MessageBubble message={message} />)
    
    const statusIndicator = screen.getByTestId('message-status')
    expect(statusIndicator).toBeInTheDocument()
  })

  it('supports quoted messages', () => {
    const quotedMessage = createMockMessage({
      id: '1',
      content: 'This is a reply',
      sender: 'user',
      quoted_message: createMockMessage({
        id: '2',
        content: 'Original message',
        sender: 'agent',
      }),
    })

    renderWithProviders(<MessageBubble message={quotedMessage} />)
    
    expect(screen.getByText('Original message')).toBeInTheDocument()
  })

  it('formats code blocks correctly', () => {
    const codeMessage = createMockMessage({
      id: '1',
      content: 'Here is some code:\n```javascript\nconst hello = "world";\n```',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={codeMessage} />)
    
    const codeBlock = screen.getByTestId('code-block')
    expect(codeBlock).toBeInTheDocument()
    expect(codeBlock).toHaveClass('font-mono', 'bg-gray-100', 'p-2', 'rounded')
  })

  it('handles mentions and links', () => {
    const mentionMessage = createMockMessage({
      id: '1',
      content: 'Hello @user and visit https://example.com',
      sender: 'user',
    })

    renderWithProviders(<MessageBubble message={mentionMessage} />)
    
    const mention = screen.getByText('@user')
    const link = screen.getByText('https://example.com')
    
    expect(mention).toHaveClass('text-blue-600', 'font-medium')
    expect(link).toHaveAttribute('href', 'https://example.com')
  })

  it('maintains message sequence order', () => {
    const messages = [
      createMockMessage({ id: '1', content: 'First', sender: 'user', index: 0 }),
      createMockMessage({ id: '2', content: 'Second', sender: 'agent', index: 1 }),
    ]

    renderWithProviders(<MessageBubble message={messages[0]} />)
    
    const bubble = screen.getByTestId('message-bubble')
    expect(bubble).toHaveAttribute('data-index', '0')
  })
})