/**
 * ConnectionStatus Component

Shows the current WebSocket connection status with visual indicators
and allows manual reconnection attempts.
 */

import React, { useState, useEffect } from 'react';
import { 
  WifiIcon, 
  ExclamationTriangleIcon, 
  ArrowPathIcon,
  CheckCircleIcon,
  XCircleIcon 
} from '@heroicons/react/24/outline';
import { useWebSocket } from '../hooks/useWebSocket';

interface ConnectionStatusProps {
  className?: string;
  showDetails?: boolean;
  onConnectionChange?: (isConnected: boolean) => void;
}

type ConnectionState = 'connected' | 'disconnected' | 'connecting' | 'error';

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({
  className = '',
  showDetails = false,
  onConnectionChange,
}) => {
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [lastError, setLastError] = useState<string | null>(null);
  const [connectionTime, setConnectionTime] = useState<Date | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);

  const { isConnected, isTyping, connect, disconnect } = useWebSocket({
    onConnect: () => {
      setConnectionState('connected');
      setConnectionTime(new Date());
      setLastError(null);
      setReconnectAttempts(0);
      onConnectionChange?.(true);
    },
    onDisconnect: () => {
      setConnectionState('disconnected');
      setConnectionTime(null);
      onConnectionChange?.(false);
    },
    onError: (error) => {
      setConnectionState('error');
      setLastError(error.message || 'Connection error');
      setReconnectAttempts(prev => prev + 1);
      onConnectionChange?.(false);
    },
  });

  // Update connection state based on WebSocket status
  useEffect(() => {
    if (isConnected) {
      setConnectionState('connected');
    } else {
      setConnectionState('disconnected');
    }
  }, [isConnected]);

  // Get status color and icon based on connection state
  const getStatusDisplay = () => {
    switch (connectionState) {
      case 'connected':
        return {
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          borderColor: 'border-green-200',
          icon: CheckCircleIcon,
          iconColor: 'text-green-600',
          text: 'Connected',
          description: 'Real-time communication active',
        };
      case 'connecting':
        return {
          color: 'text-yellow-600',
          bgColor: 'bg-yellow-100',
          borderColor: 'border-yellow-200',
          icon: ArrowPathIcon,
          iconColor: 'text-yellow-600',
          text: 'Connecting',
          description: 'Establishing connection...',
        };
      case 'error':
        return {
          color: 'text-red-600',
          bgColor: 'bg-red-100',
          borderColor: 'border-red-200',
          icon: ExclamationTriangleIcon,
          iconColor: 'text-red-600',
          text: 'Error',
          description: lastError || 'Connection failed',
        };
      default:
        return {
          color: 'text-gray-600',
          bgColor: 'bg-gray-100',
          borderColor: 'border-gray-200',
          icon: XCircleIcon,
          iconColor: 'text-gray-600',
          text: 'Disconnected',
          description: 'Connection lost',
        };
    }
  };

  // Handle manual reconnection
  const handleReconnect = async () => {
    try {
      setConnectionState('connecting');
      await connect();
    } catch (error) {
      console.error('Manual reconnection failed:', error);
    }
  };

  // Handle manual disconnection
  const handleDisconnect = () => {
    disconnect();
  };

  // Format connection duration
  const getConnectionDuration = () => {
    if (!connectionTime) return null;
    
    const now = new Date();
    const duration = now.getTime() - connectionTime.getTime();
    const minutes = Math.floor(duration / 60000);
    const seconds = Math.floor((duration % 60000) / 1000);
    
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    }
    return `${seconds}s`;
  };

  const statusDisplay = getStatusDisplay();
  const StatusIcon = statusDisplay.icon;
  const isInteractive = connectionState === 'disconnected' || connectionState === 'error';

  return (
    <div className={`relative ${className}`}>
      <div
        className={`flex items-center space-x-2 px-3 py-2 rounded-lg border transition-all duration-200 ${
          statusDisplay.bgColor
        } ${statusDisplay.borderColor} ${
          isInteractive ? 'cursor-pointer hover:shadow-md' : ''
        }`}
        onClick={isInteractive ? handleReconnect : undefined}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {/* Status icon */}
        <div className="flex items-center space-x-2">
          <StatusIcon 
            className={`w-4 h-4 ${statusDisplay.iconColor} ${
              connectionState === 'connecting' ? 'animate-spin' : ''
            }`} 
          />
          
          {/* Connection indicator dot */}
          <div className={`w-2 h-2 rounded-full ${
            connectionState === 'connected' ? 'bg-green-500' :
            connectionState === 'connecting' ? 'bg-yellow-500 animate-pulse' :
            connectionState === 'error' ? 'bg-red-500' :
            'bg-gray-400'
          }`} />
        </div>

        {/* Status text */}
        <span className={`text-sm font-medium ${statusDisplay.color}`}>
          {statusDisplay.text}
        </span>

        {/* Reconnect button (when disconnected) */}
        {isInteractive && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleReconnect();
            }}
            className="text-xs text-gray-600 hover:text-gray-800 transition-colors"
            title="Reconnect"
          >
            <ArrowPathIcon className="w-4 h-4" />
          </button>
        )}

        {/* Typing indicator */}
        {isTyping && (
          <div className="flex items-center space-x-1">
            <div className="flex space-x-1">
              <div className="w-1 h-1 bg-blue-500 rounded-full animate-bounce"></div>
              <div className="w-1 h-1 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-1 h-1 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-xs text-blue-600">AI typing</span>
          </div>
        )}
      </div>

      {/* Tooltip with details */}
      {showTooltip && showDetails && (
        <div className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white text-xs rounded-lg py-2 px-3 whitespace-nowrap z-50 shadow-lg">
          <div className="space-y-1">
            <div>{statusDisplay.description}</div>
            {connectionTime && connectionState === 'connected' && (
              <div>Connected for {getConnectionDuration()}</div>
            )}
            {reconnectAttempts > 0 && connectionState !== 'connected' && (
              <div>Reconnect attempts: {reconnectAttempts}</div>
            )}
            {lastError && connectionState === 'error' && (
              <div className="text-red-300 max-w-xs truncate" title={lastError}>
                Error: {lastError}
              </div>
            )}
          </div>
          {/* Arrow */}
          <div className="absolute top-full left-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      )}

      {/* Compact version for smaller spaces */}
      {!showDetails && (
        <div className="flex items-center space-x-1">
          <div className={`w-2 h-2 rounded-full ${
            connectionState === 'connected' ? 'bg-green-500' :
            connectionState === 'connecting' ? 'bg-yellow-500 animate-pulse' :
            connectionState === 'error' ? 'bg-red-500' :
            'bg-gray-400'
          }`} />
          <span className={`text-xs font-medium ${statusDisplay.color}`}>
            {connectionState === 'connected' ? 'Online' : 'Offline'}
          </span>
        </div>
      )}
    </div>
  );
};

export default ConnectionStatus;