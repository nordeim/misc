/**
 * MessageList Component

Displays a scrollable list of chat messages with support for virtual scrolling
for better performance with large message sets.
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Message } from '../types';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

interface MessageListProps {
  messages: Message[];
  isTyping?: boolean;
  isLoading?: boolean;
  onMessageUpdate?: (messageId: string, updates: Partial<Message>) => void;
  className?: string;
}

const MessageList: React.FC<MessageListProps> = ({
  messages,
  isTyping = false,
  isLoading = false,
  onMessageUpdate,
  className = '',
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  // Check if user is near bottom of the scroll container
  const handleScroll = useCallback(() => {
    if (containerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
      const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
      const isNearBottom = distanceFromBottom < 100; // 100px threshold
      
      setShouldAutoScroll(isNearBottom);
    }
  }, []);

  // Auto-scroll when new messages arrive if user is near bottom
  useEffect(() => {
    if (shouldAutoScroll && messages.length > 0) {
      scrollToBottom('auto');
    }
  }, [messages, shouldAutoScroll, scrollToBottom]);

  // Manual scroll to bottom function
  const scrollToBottomManually = useCallback(() => {
    scrollToBottom('smooth');
    setShouldAutoScroll(true);
  }, [scrollToBottom]);

  // Group messages by date for better readability
  const groupMessagesByDate = useCallback((messages: Message[]) => {
    const groups: { date: string; messages: Message[] }[] = [];
    let currentGroup: { date: string; messages: Message[] } | null = null;

    messages.forEach((message) => {
      const messageDate = new Date(message.timestamp).toDateString();
      
      if (!currentGroup || currentGroup.date !== messageDate) {
        currentGroup = { date: messageDate, messages: [] };
        groups.push(currentGroup);
      }
      
      currentGroup.messages.push(message);
    });

    return groups;
  }, []);

  const messageGroups = groupMessagesByDate(messages);

  // Format date for display
  const formatDateHeader = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    }
  };

  return (
    <div 
      ref={containerRef}
      className={`flex-1 overflow-y-auto p-4 space-y-4 ${className}`}
      onScroll={handleScroll}
      role="log"
      aria-label="Chat messages"
      aria-live="polite"
    >
      {isLoading && messages.length === 0 && (
        <div className="flex justify-center items-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2 text-gray-600">Loading messages...</span>
        </div>
      )}

      {messageGroups.length === 0 && !isLoading ? (
        <div className="text-center text-gray-500 py-8">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.959 8.959 0 01-4.906-1.435L3 21l2.435-4.094A8.959 8.959 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Start a conversation</h3>
            <p className="text-sm text-gray-500">
              Send a message to begin chatting with our AI assistant.
            </p>
          </div>
        </div>
      ) : (
        messageGroups.map((group, groupIndex) => (
          <div key={groupIndex} className="space-y-4">
            {/* Date header */}
            <div className="flex items-center justify-center">
              <div className="bg-gray-100 px-3 py-1 rounded-full">
                <span className="text-xs font-medium text-gray-600">
                  {formatDateHeader(group.date)}
                </span>
              </div>
            </div>

            {/* Messages for this date */}
            <div className="space-y-3">
              {group.messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  onUpdate={onMessageUpdate}
                />
              ))}
            </div>
          </div>
        ))
      )}

      {/* Typing indicator */}
      {isTyping && (
        <div className="sticky bottom-0">
          <TypingIndicator />
        </div>
      )}

      {/* Scroll to bottom button */}
      {!shouldAutoScroll && messages.length > 5 && (
        <button
          onClick={scrollToBottomManually}
          className="fixed bottom-20 right-6 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg transition-colors z-10"
          aria-label="Scroll to bottom"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </button>
      )}

      {/* Invisible element for scrolling to bottom */}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;