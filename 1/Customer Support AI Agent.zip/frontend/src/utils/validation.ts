/**
 * Client-side Validation Utilities

Provides validation functions for form inputs, file uploads, API responses,
and other user data to ensure data integrity and security.
 */

// Email validation
export const validateEmail = (email: string): { isValid: boolean; error?: string } => {
  if (!email) {
    return { isValid: false, error: 'Email is required' };
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { isValid: false, error: 'Please enter a valid email address' };
  }
  
  return { isValid: true };
};

// Password validation
export const validatePassword = (password: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  if (!password) {
    errors.push('Password is required');
    return { isValid: false, errors };
  }
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }
  
  return { isValid: errors.length === 0, errors };
};

// Phone number validation
export const validatePhoneNumber = (phone: string): { isValid: boolean; error?: string } => {
  if (!phone) {
    return { isValid: false, error: 'Phone number is required' };
  }
  
  const cleaned = phone.replace(/\D/g, '');
  
  if (cleaned.length !== 10 && !(cleaned.length === 11 && cleaned[0] === '1')) {
    return { isValid: false, error: 'Please enter a valid 10-digit phone number' };
  }
  
  return { isValid: true };
};

// URL validation
export const validateUrl = (url: string): { isValid: boolean; error?: string } => {
  if (!url) {
    return { isValid: false, error: 'URL is required' };
  }
  
  try {
    new URL(url);
    return { isValid: true };
  } catch {
    return { isValid: false, error: 'Please enter a valid URL' };
  }
};

// File validation
export const validateFile = (
  file: File,
  options: {
    maxSize?: number;
    allowedTypes?: string[];
    maxFiles?: number;
  } = {}
): { isValid: boolean; errors: string[] } => {
  const { maxSize = 10 * 1024 * 1024, allowedTypes = [], maxFiles = 1 } = options;
  const errors: string[] = [];
  
  if (!file) {
    errors.push('File is required');
    return { isValid: false, errors };
  }
  
  if (file.size > maxSize) {
    const maxSizeMB = Math.round(maxSize / (1024 * 1024));
    errors.push(`File size must not exceed ${maxSizeMB}MB`);
  }
  
  if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
    errors.push(`File type "${file.type}" is not allowed`);
  }
  
  const dangerousExtensions = ['.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js'];
  const fileName = file.name.toLowerCase();
  if (dangerousExtensions.some(ext => fileName.endsWith(ext))) {
    errors.push('This file type is not allowed for security reasons');
  }
  
  return { isValid: errors.length === 0, errors };
};

// Multiple files validation
export const validateFiles = (
  files: FileList | File[],
  options: {
    maxSize?: number;
    allowedTypes?: string[];
    maxFiles?: number;
    minFiles?: number;
  } = {}
): { isValid: boolean; errors: string[]; validFiles: File[] } => {
  const { maxSize, allowedTypes, maxFiles, minFiles = 1 } = options;
  const errors: string[] = [];
  const validFiles: File[] = [];
  
  const fileArray = Array.from(files);
  
  if (fileArray.length < minFiles) {
    errors.push(`Please select at least ${minFiles} file${minFiles !== 1 ? 's' : ''}`);
  }
  
  if (maxFiles && fileArray.length > maxFiles) {
    errors.push(`Maximum ${maxFiles} files allowed`);
  }
  
  // Validate each file
  fileArray.forEach((file, index) => {
    const fileValidation = validateFile(file, { maxSize, allowedTypes, maxFiles: 1 });
    
    if (!fileValidation.isValid) {
      errors.push(`${file.name}: ${fileValidation.errors.join(', ')}`);
    } else {
      validFiles.push(file);
    }
  });
  
  return { isValid: errors.length === 0, errors, validFiles };
};

// Text content validation
export const validateTextContent = (
  text: string,
  options: {
    minLength?: number;
    maxLength?: number;
    required?: boolean;
    allowHtml?: boolean;
  } = {}
): { isValid: boolean; errors: string[] } => {
  const { minLength = 0, maxLength = 1000, required = false, allowHtml = false } = options;
  const errors: string[] = [];
  
  if (required && !text.trim()) {
    errors.push('This field is required');
    return { isValid: false, errors };
  }
  
  if (text.length < minLength) {
    errors.push(`Minimum ${minLength} characters required`);
  }
  
  if (text.length > maxLength) {
    errors.push(`Maximum ${maxLength} characters allowed`);
  }
  
  if (!allowHtml) {
    const htmlRegex = /<[^>]*>/g;
    if (htmlRegex.test(text)) {
      errors.push('HTML tags are not allowed');
    }
  }
  
  // Check for potentially dangerous content
  if (text.includes('<script>') || text.includes('javascript:')) {
    errors.push('Potentially dangerous content detected');
  }
  
  return { isValid: errors.length === 0, errors };
};

// API response validation
export const validateApiResponse = <T>(
  response: any,
  schema: {
    requiredFields?: string[];
    dataType?: 'object' | 'array' | 'string' | 'number' | 'boolean';
  }
): { isValid: boolean; errors: string[]; data?: T } => {
  const errors: string[] = [];
  
  if (!response) {
    errors.push('API response is empty');
    return { isValid: false, errors };
  }
  
  if (schema.requiredFields) {
    schema.requiredFields.forEach(field => {
      if (!(field in response)) {
        errors.push(`Required field "${field}" is missing`);
      }
    });
  }
  
  if (schema.dataType) {
    const actualType = Array.isArray(response) ? 'array' : typeof response;
    if (actualType !== schema.dataType) {
      errors.push(`Expected ${schema.dataType}, got ${actualType}`);
    }
  }
  
  return { isValid: errors.length === 0, errors, data: response as T };
};

// Form validation
export interface ValidationRule<T = any> {
  field: string;
  value: T;
  validators: ((value: T) => { isValid: boolean; error?: string })[];
}

export const validateForm = (rules: ValidationRule[]): {
  isValid: boolean;
  errors: Record<string, string>;
} => {
  const errors: Record<string, string> = {};
  
  rules.forEach(rule => {
    for (const validator of rule.validators) {
      const result = validator(rule.value);
      if (!result.isValid) {
        errors[rule.field] = result.error || 'Validation failed';
        break;
      }
    }
  });
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

// Sanitize input
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/javascript:/gi, '') // Remove javascript: protocols
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
};

// XSS prevention
export const preventXSS = (input: string): string => {
  const div = document.createElement('div');
  div.textContent = input;
  return div.innerHTML;
};

// CSRF token validation
export const validateCSRFToken = (token: string, sessionToken: string): boolean => {
  return token === sessionToken;
};

// File name validation
export const validateFileName = (fileName: string): { isValid: boolean; error?: string } => {
  if (!fileName) {
    return { isValid: false, error: 'File name is required' };
  }
  
  // Check for dangerous characters
  const dangerousChars = /[<>:"|?*\x00-\x1f]/;
  if (dangerousChars.test(fileName)) {
    return { isValid: false, error: 'File name contains invalid characters' };
  }
  
  // Check length
  if (fileName.length > 255) {
    return { isValid: false, error: 'File name is too long' };
  }
  
  // Check for reserved names (Windows)
  const reservedNames = ['CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'];
  const nameWithoutExt = fileName.split('.')[0].toUpperCase();
  if (reservedNames.includes(nameWithoutExt)) {
    return { isValid: false, error: 'File name uses a reserved word' };
  }
  
  return { isValid: true };
};

// Session validation
export const validateSession = (session: any): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  if (!session.id) {
    errors.push('Session ID is required');
  }
  
  if (!session.title) {
    errors.push('Session title is required');
  }
  
  if (!session.created_at) {
    errors.push('Creation date is required');
  }
  
  // Validate date format
  if (session.created_at && isNaN(new Date(session.created_at).getTime())) {
    errors.push('Invalid creation date format');
  }
  
  return { isValid: errors.length === 0, errors };
};

// Message validation
export const validateMessage = (message: any): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  if (!message.id) {
    errors.push('Message ID is required');
  }
  
  if (!message.content) {
    errors.push('Message content is required');
  }
  
  if (!['user', 'assistant'].includes(message.role)) {
    errors.push('Message role must be either "user" or "assistant"');
  }
  
  if (!message.timestamp) {
    errors.push('Message timestamp is required');
  }
  
  // Validate timestamp format
  if (message.timestamp && isNaN(new Date(message.timestamp).getTime())) {
    errors.push('Invalid timestamp format');
  }
  
  return { isValid: errors.length === 0, errors };
};

// Rating validation (for feedback)
export const validateRating = (rating: number): { isValid: boolean; error?: string } => {
  if (typeof rating !== 'number' || isNaN(rating)) {
    return { isValid: false, error: 'Rating must be a number' };
  }
  
  if (rating < 1 || rating > 5) {
    return { isValid: false, error: 'Rating must be between 1 and 5' };
  }
  
  return { isValid: true };
};

// Credit card validation (basic)
export const validateCreditCard = (cardNumber: string): { isValid: boolean; error?: string } => {
  if (!cardNumber) {
    return { isValid: false, error: 'Card number is required' };
  }
  
  // Remove spaces and hyphens
  const cleaned = cardNumber.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) {
    return { isValid: false, error: 'Card number must contain only digits' };
  }
  
  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return { isValid: false, error: 'Card number must be 13-19 digits long' };
  }
  
  // Luhn algorithm check
  let sum = 0;
  let isEven = false;
  
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  if (sum % 10 !== 0) {
    return { isValid: false, error: 'Invalid card number' };
  }
  
  return { isValid: true };
};

// Postal code validation (international)
export const validatePostalCode = (code: string, country: string = 'US'): { isValid: boolean; error?: string } => {
  if (!code) {
    return { isValid: false, error: 'Postal code is required' };
  }
  
  const patterns: Record<string, RegExp> = {
    US: /^\d{5}(-\d{4})?$/,
    CA: /^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$/,
    UK: /^[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}$/,
    DE: /^\d{5}$/,
    FR: /^\d{5}$/,
    JP: /^\d{3}-\d{4}$/,
    AU: /^\d{4}$/,
  };
  
  const pattern = patterns[country.toUpperCase()];
  if (!pattern || !pattern.test(code)) {
    return { isValid: false, error: 'Invalid postal code format' };
  }
  
  return { isValid: true };
};