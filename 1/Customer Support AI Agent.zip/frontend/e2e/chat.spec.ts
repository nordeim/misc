import { test, expect } from '@playwright/test'

test.describe('Chat Interface E2E', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to the chat interface
    await page.goto('/')
    await page.waitForLoadState('networkidle')
  })

  test('should load the chat interface', async ({ page }) => {
    // Check if the main elements are visible
    await expect(page.getByRole('banner')).toBeVisible()
    await expect(page.getByLabel('Chat messages')).toBeVisible()
    await expect(page.getByPlaceholder('Type your message...')).toBeVisible()
  })

  test('should send a message', async ({ page }) => {
    const messageInput = page.getByPlaceholder('Type your message...')
    const sendButton = page.getByRole('button', { name: /send/i })

    // Type a message
    await messageInput.fill('Hello, this is a test message')
    
    // Click send button
    await sendButton.click()

    // Verify the message appears in the chat
    await expect(page.getByText('Hello, this is a test message')).toBeVisible()
    
    // Verify the input is cleared
    await expect(messageInput).toBeEmpty()
  })

  test('should send message on Enter key', async ({ page }) => {
    const messageInput = page.getByPlaceholder('Type your message...')

    // Type message and press Enter
    await messageInput.fill('Testing Enter key')
    await messageInput.press('Enter')

    // Verify the message appears
    await expect(page.getByText('Testing Enter key')).toBeVisible()
  })

  test('should handle file upload', async ({ page }) => {
    // Mock file upload API
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: 'file-123',
          filename: 'test-file.pdf',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    
    // Upload a file
    const filePath = 'e2e/test-files/sample.pdf'
    await fileInput.setInputFiles(filePath)

    // Verify upload success message
    await expect(page.getByText(/uploaded/i)).toBeVisible()
  })

  test('should maintain typing indicator', async ({ page }) => {
    const messageInput = page.getByPlaceholder('Type your message...')

    // Type a long message
    await messageInput.fill('This is a very long message that might trigger typing indicator...')

    // The typing indicator should appear when agent is typing
    // This would be tested with actual WebSocket mocking
    await expect(page.getByTestId('typing-indicator')).toBeVisible()
  })

  test('should handle multiple messages', async ({ page }) => {
    const messages = [
      'First message',
      'Second message',
      'Third message',
    ]

    for (const message of messages) {
      await page.getByPlaceholder('Type your message...').fill(message)
      await page.getByRole('button', { name: /send/i }).click()
      await expect(page.getByText(message)).toBeVisible()
    }

    // Verify all messages are visible
    for (const message of messages) {
      await expect(page.getByText(message)).toBeVisible()
    }
  })

  test('should handle message history', async ({ page }) => {
    // Mock messages API
    await page.route('/api/chat/messages', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          messages: [
            {
              id: '1',
              content: 'Previous message',
              sender: 'user',
              timestamp: new Date().toISOString(),
            },
          ],
        }),
      })
    })

    // Refresh page to load history
    await page.reload()
    await page.waitForLoadState('networkidle')

    // Verify previous messages are loaded
    await expect(page.getByText('Previous message')).toBeVisible()
  })

  test('should handle connection status', async ({ page }) => {
    // Check for connection status indicator
    await expect(page.getByTestId('connection-status')).toBeVisible()
    
    // Check status text
    await expect(page.getByText(/connected|disconnected/i)).toBeVisible()
  })

  test('should handle chat session creation', async ({ page }) => {
    // Mock session creation API
    await page.route('/api/sessions', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          session_id: 'session-123',
          created_at: new Date().toISOString(),
          status: 'active',
        }),
      })
    })

    // Should create a new session on load
    await expect(page.getByTestId('session-indicator')).toBeVisible()
  })

  test('should be accessible', async ({ page }) => {
    // Test keyboard navigation
    await page.keyboard.press('Tab')
    await expect(page.getByPlaceholder('Type your message...')).toBeFocused()

    // Test ARIA labels
    await expect(page.getByLabel('Chat messages')).toBeVisible()
    await expect(page.getByLabel('Type your message')).toBeVisible()

    // Test screen reader announcements
    const chatContainer = page.getByLabel('Chat messages')
    await expect(chatContainer).toHaveAttribute('aria-live', 'polite')
  })

  test('should handle responsive design', async ({ page }) => {
    // Test mobile viewport
    await page.setViewportSize({ width: 375, height: 667 })
    await page.reload()
    
    // Check mobile layout
    await expect(page.getByRole('banner')).toBeVisible()
    await expect(page.getByPlaceholder('Type your message...')).toBeVisible()

    // Test tablet viewport
    await page.setViewportSize({ width: 768, height: 1024 })
    await page.reload()
    
    await expect(page.getByRole('banner')).toBeVisible()

    // Test desktop viewport
    await page.setViewportSize({ width: 1920, height: 1080 })
    await page.reload()
    
    await expect(page.getByRole('banner')).toBeVisible()
  })

  test('should handle error states', async ({ page }) => {
    // Mock API error
    await page.route('/api/chat/messages', async route => {
      await route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'Internal Server Error' }),
      })
    })

    await page.reload()

    // Check error message display
    await expect(page.getByText(/error|failed/i)).toBeVisible()
  })

  test('should persist user input', async ({ page }) => {
    const messageInput = page.getByPlaceholder('Type your message...')
    
    // Type some text
    await messageInput.fill('Draft message')
    
    // Refresh the page
    await page.reload()
    
    // Check if text is preserved (if implemented)
    // This test would depend on actual implementation
  })

  test('should handle scroll behavior', async ({ page }) => {
    // Send multiple messages to create scroll
    for (let i = 0; i < 20; i++) {
      await page.getByPlaceholder('Type your message...').fill(`Message ${i + 1}`)
      await page.getByRole('button', { name: /send/i }).click()
    }

    // Check if scroll position is maintained
    const chatContainer = page.getByLabel('Chat messages')
    await expect(chatContainer).toBeVisible()

    // Verify latest message is visible
    await expect(page.getByText('Message 20')).toBeVisible()
  })

  test('should support dark mode', async ({ page }) => {
    // This would depend on actual dark mode implementation
    // For now, just check that the toggle exists if present
    const darkModeToggle = page.getByRole('button', { name: /dark|light/i })
    if (await darkModeToggle.isVisible()) {
      await darkModeToggle.click()
      await expect(page.locator('html')).toHaveClass(/dark/)
    }
  })
})