import { test, expect } from '@playwright/test'

test.describe('File Upload E2E', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/')
    await page.waitForLoadState('networkidle')
  })

  test('should upload a file successfully', async ({ page }) => {
    // Mock upload API
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: 'file-123',
          filename: 'test-document.pdf',
          size: 1024,
          mime_type: 'application/pdf',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    
    // Upload test file
    await fileInput.setInputFiles('e2e/test-files/test-document.pdf')

    // Verify upload success
    await expect(page.getByText('test-document.pdf')).toBeVisible()
    await expect(page.getByText('1.0 KB')).toBeVisible()
  })

  test('should show upload progress', async ({ page }) => {
    // Mock upload with progress
    let progressCallback: ((progress: any) => void) | null = null
    
    await page.route('/api/upload', async route => {
      // Simulate upload progress
      progressCallback && progressCallback({ loaded: 50, total: 100 })
      
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: 'file-123',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/large-file.pdf')

    // Verify progress bar is shown
    await expect(page.getByTestId('upload-progress')).toBeVisible()
  })

  test('should handle upload errors', async ({ page }) => {
    // Mock upload error
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 500,
        contentType: 'application/json',
        body: JSON.stringify({
          error: 'Upload failed',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/test-document.pdf')

    // Verify error message
    await expect(page.getByText(/upload failed/i)).toBeVisible()
  })

  test('should validate file types', async ({ page }) => {
    // Try to upload an unsupported file type
    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/invalid.exe')

    // Should show validation error
    await expect(page.getByText(/unsupported file type/i)).toBeVisible()
  })

  test('should validate file size', async ({ page }) => {
    // Mock file size validation
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 400,
        contentType: 'application/json',
        body: JSON.stringify({
          error: 'File size exceeds limit',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/large-file.pdf')

    // Should show size error
    await expect(page.getByText(/file size/i)).toBeVisible()
  })

  test('should support drag and drop', async ({ page }) => {
    const dropZone = page.getByTestId('file-upload-area')

    // Mock drag and drop file
    await dropZone.dispatchEvent('dragenter')
    await dropZone.dispatchEvent('dragover')
    await dropZone.dispatchEvent('drop', {
      dataTransfer: {
        files: ['e2e/test-files/test-document.pdf'],
      },
    })

    // Verify file is uploaded
    await expect(page.getByText('test-document.pdf')).toBeVisible()
  })

  test('should show file preview for images', async ({ page }) => {
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: 'file-123',
          filename: 'test-image.png',
          mime_type: 'image/png',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/test-image.png')

    // Should show image preview
    await expect(page.getByTestId('image-preview')).toBeVisible()
  })

  test('should allow file removal', async ({ page }) => {
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: 'file-123',
          filename: 'test-document.pdf',
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles('e2e/test-files/test-document.pdf')

    // Remove file
    await page.getByTestId('remove-file').click()

    // File should be removed
    await expect(page.getByText('test-document.pdf')).not.toBeVisible()
  })

  test('should support multiple file upload', async ({ page }) => {
    await page.route('/api/upload', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          success: true,
          file_id: `file-${Date.now()}`,
        }),
      })
    })

    const fileInput = page.locator('input[type="file"]')
    await fileInput.setInputFiles([
      'e2e/test-files/test-document.pdf',
      'e2e/test-files/test-image.png',
      'e2e/test-files/test-spreadsheet.xlsx',
    ])

    // Verify all files are uploaded
    await expect(page.getByText('test-document.pdf')).toBeVisible()
    await expect(page.getByText('test-image.png')).toBeVisible()
    await expect(page.getByText('test-spreadsheet.xlsx')).toBeVisible()
  })
})

test.describe('Accessibility E2E', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/')
    await page.waitForLoadState('networkidle')
  })

  test('should be keyboard navigable', async ({ page }) => {
    // Test Tab navigation
    await page.keyboard.press('Tab')
    await expect(page.getByRole('banner')).toBeFocused()

    await page.keyboard.press('Tab')
    await expect(page.getByPlaceholder('Type your message...')).toBeFocused()

    // Test Enter key activation
    await page.getByPlaceholder('Type your message...').fill('Keyboard test')
    await page.keyboard.press('Enter')
    await expect(page.getByText('Keyboard test')).toBeVisible()
  })

  test('should have proper ARIA labels', async ({ page }) => {
    // Check main regions
    await expect(page.getByRole('banner')).toHaveAttribute('aria-label', 'Application header')
    await expect(page.getByLabel('Chat messages')).toBeVisible()
    await expect(page.getByLabel('Type your message')).toBeVisible()

    // Check buttons
    await expect(page.getByRole('button', { name: /send/i })).toHaveAttribute('aria-label', 'Send message')
  })

  test('should announce new messages', async ({ page }) => {
    const messageInput = page.getByPlaceholder('Type your message...')
    await messageInput.fill('Test message for screen reader')
    await page.getByRole('button', { name: /send/i }).click()

    // Chat container should have live region
    const chatContainer = page.getByLabel('Chat messages')
    await expect(chatContainer).toHaveAttribute('aria-live', 'polite')
  })

  test('should have proper focus management', async ({ page }) => {
    // Focus should be managed when sending messages
    const messageInput = page.getByPlaceholder('Type your message...')
    
    await messageInput.click()
    await messageInput.fill('Focus test')
    await page.getByRole('button', { name: /send/i }).click()

    // Focus should return to input after sending
    await expect(messageInput).toBeFocused()
  })

  test('should support skip navigation', async ({ page }) => {
    // Should have skip link
    const skipLink = page.getByRole('link', { name: /skip to main content/i })
    if (await skipLink.isVisible()) {
      await skipLink.click()
      await expect(page.getByLabel('Chat messages')).toBeFocused()
    }
  })

  test('should have sufficient color contrast', async ({ page }) => {
    // This would require checking computed styles
    // For now, just verify basic styling exists
    const messageInput = page.getByPlaceholder('Type your message...')
    await expect(messageInput).toHaveCSS('border', expect.stringContaining('px'))
  })

  test('should be readable by screen readers', async ({ page }) => {
    // Test basic content accessibility
    await expect(page.getByRole('banner')).toContainText('Customer Support AI')
    await expect(page.getByLabel('Chat messages')).toBeVisible()
    
    // Add a message and verify it's announced
    const messageInput = page.getByPlaceholder('Type your message...')
    await messageInput.fill('Screen reader test')
    await page.getByRole('button', { name: /send/i }).click()
    
    // The message should be readable
    await expect(page.getByText('Screen reader test')).toBeVisible()
  })

  test('should handle form validation', async ({ page }) => {
    // Try to send empty message
    const sendButton = page.getByRole('button', { name: /send/i })
    await expect(sendButton).toBeDisabled()

    // Type invalid input
    const messageInput = page.getByPlaceholder('Type your message...')
    await messageInput.fill('x'.repeat(1001)) // Exceed max length
    
    // Should show validation error
    await expect(page.getByText(/too long/i)).toBeVisible()
  })

  test('should support reduced motion', async ({ page }) => {
    // Simulate reduced motion preference
    await page.addStyleTag({
      content: '@media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }',
    })

    // Verify elements still work without animations
    const messageInput = page.getByPlaceholder('Type your message...')
    await messageInput.fill('Reduced motion test')
    await page.getByRole('button', { name: /send/i }).click()
    
    await expect(page.getByText('Reduced motion test')).toBeVisible()
  })
})

test.describe('Performance E2E', () => {
  test('should load quickly', async ({ page }) => {
    const startTime = Date.now()
    await page.goto('/')
    await page.waitForLoadState('networkidle')
    const loadTime = Date.now() - startTime

    // Should load within 3 seconds
    expect(loadTime).toBeLessThan(3000)
  })

  test('should respond to user interactions quickly', async ({ page }) => {
    await page.goto('/')
    await page.waitForLoadState('networkidle')

    const startTime = Date.now()
    
    const messageInput = page.getByPlaceholder('Type your message...')
    await messageInput.fill('Performance test')
    await page.getByRole('button', { name: /send/i }).click()
    
    const responseTime = Date.now() - startTime

    // Should respond within 500ms
    expect(responseTime).toBeLessThan(500)
  })

  test('should handle many messages efficiently', async ({ page }) => {
    await page.goto('/')
    await page.waitForLoadState('networkidle')

    // Send many messages quickly
    for (let i = 0; i < 50; i++) {
      await page.getByPlaceholder('Type your message...').fill(`Message ${i + 1}`)
      await page.getByRole('button', { name: /send/i }).click()
    }

    // Should still be responsive
    await page.getByPlaceholder('Type your message...').fill('Still responsive')
    await expect(page.getByPlaceholder('Type your message...')).toHaveValue('Still responsive')
  })
})