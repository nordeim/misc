# Docker Compose Configurations Summary
## Customer Support AI Agent

This document provides an overview of all Docker Compose configurations and supporting files created for the Customer Support AI Agent project.

## 📁 File Structure

```
├── docker-compose.yml              # Development environment
├── docker-compose.prod.yml         # Production environment  
├── docker-compose.override.yml     # Development overrides
├── docker/
│   ├── nginx.conf                  # Development nginx config
│   ├── nginx.prod.conf             # Production nginx config
│   ├── prometheus.yml              # Prometheus monitoring config
│   └── README.md                   # Detailed Docker setup guide
├── backend/
│   ├── Dockerfile                  # Production backend Dockerfile
│   └── Dockerfile.dev             # Development backend Dockerfile
├── frontend/
│   ├── Dockerfile                  # Production frontend Dockerfile
│   ├── Dockerfile.dev             # Development frontend Dockerfile
│   └── nginx.conf                  # Frontend nginx config
├── .env.example                    # Environment variables template
├── deploy.sh                       # Deployment script
└── Makefile                        # Convenient shortcuts
```

## 🏗️ Architecture Overview

### Services Overview

| Service | Technology | Port(s) | Purpose |
|---------|------------|---------|---------|
| **Frontend** | React + TypeScript + Vite + Nginx | 3000 (dev), 80 (prod) | User interface |
| **Backend** | Python 3.11 + FastAPI + Gunicorn | 8000 | API and AI processing |
| **PostgreSQL** | PostgreSQL 15 | 5432 | Primary database |
| **Redis** | Redis 7 | 6379 | Caching and sessions |
| **ChromaDB** | ChromaDB | 8000 | Vector database for RAG |
| **Nginx** | Nginx 1.25 | 80, 443 | Reverse proxy and load balancer |
| **Prometheus** | Prometheus | 9090 | Metrics collection |
| **Grafana** | Grafana | 3001 | Visualization and monitoring |

## 🚀 Quick Start Commands

### Using Make (Recommended)

```bash
# Development
make setup          # Initial setup
make dev           # Start development environment
make dev-logs      # View logs
make dev-status    # Check status

# Production
make prod          # Start production
make prod-mon      # Start with monitoring
make stop-prod     # Stop production

# Utilities
make backup        # Database backup
make health        # Check all services
make logs          # View logs
```

### Using Deploy Script

```bash
# Development
./deploy.sh dev           # Start development
./deploy.sh logs          # View logs

# Production  
./deploy.sh prod          # Start production
./deploy.sh prod-monitoring # Start with monitoring
./deploy.sh backup        # Database backup
```

### Direct Docker Compose

```bash
# Development
docker-compose up -d
docker-compose logs -f
docker-compose down

# Production
docker-compose -f docker-compose.prod.yml --env-file .env.prod up -d
docker-compose -f docker-compose.prod.yml --env-file .env.prod logs -f
docker-compose -f docker-compose.prod.yml --env-file .env.prod down
```

## 🔧 Configuration Details

### Development Environment (`docker-compose.yml`)

**Features:**
- Hot reload enabled for both frontend and backend
- Volume mounts for live code changes
- SQLite database support
- Development-friendly logging
- Accessible ports for debugging

**Services:**
- Backend with uvicorn hot reload
- Frontend with Vite dev server
- PostgreSQL (development settings)
- Redis (no password)
- ChromaDB (persisted data)
- Nginx (optional with profile)

**Key Environment Variables:**
```bash
ENVIRONMENT=development
DATABASE_URL=postgresql://postgres:postgres123@postgres:5432/customer_support
REDIS_URL=redis://redis:6379/0
LOG_LEVEL=DEBUG
```

### Production Environment (`docker-compose.prod.yml`)

**Features:**
- Multi-stage optimized builds
- Resource limits and scaling
- Health checks on all services
- Security hardening
- SSL/TLS support
- Load balancing
- Monitoring stack (optional)

**Services:**
- Backend with Gunicorn workers
- Frontend with Nginx static serving
- PostgreSQL with performance tuning
- Redis with authentication and limits
- ChromaDB with persistence
- Nginx with rate limiting and security headers
- Prometheus and Grafana (profile-based)

**Key Environment Variables:**
```bash
ENVIRONMENT=production
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@postgres:5432/customer_support
REDIS_URL=redis://:${REDIS_PASSWORD}@redis:6379/0
BACKEND_REPLICAS=2
FRONTEND_REPLICAS=2
```

## 🐳 Dockerfile Configurations

### Backend Dockerfiles

**Development (`Dockerfile.dev`):**
- Base: Python 3.11-slim
- Features: Hot reload, development dependencies
- Command: `uvicorn app.main:app --reload`
- User: Non-root appuser
- Volumes: Code mounted for live updates

**Production (`Dockerfile`):**
- Base: Python 3.11-slim
- Features: Multi-stage build, Gunicorn, optimized
- Command: `gunicorn app.main:app -w ${WORKERS:-4}...`
- User: Non-root appuser
- Security: Minimal attack surface

### Frontend Dockerfiles

**Development (`Dockerfile.dev`):**
- Base: Node.js 18-alpine
- Features: Live development server
- Command: `npm run dev -- --host 0.0.0.0`
- Volumes: Code and node_modules mounted
- User: Non-root nextjs user

**Production (`Dockerfile`):**
- Base: Node.js 18-alpine → Nginx alpine
- Features: Multi-stage build, static serving
- Command: `nginx -g "daemon off;"`
- Optimization: Minified assets, gzip compression
- User: Non-root nginx user

## 🌐 Nginx Configurations

### Development (`nginx.conf`)
- Basic reverse proxy setup
- WebSocket support for real-time features
- Security headers (development level)
- Load balancing (single backend)
- Health check endpoint

### Production (`nginx.prod.conf`)
- Advanced load balancing (least_conn)
- Rate limiting (api: 10r/s, login: 1r/s)
- Comprehensive security headers
- SSL/TLS termination ready
- Gzip compression
- Static asset caching
- HSTS headers

### Frontend (`nginx.conf`)
- SPA routing support (try_files)
- API proxy configuration
- WebSocket proxy
- Static asset optimization
- Compression enabled

## 📊 Monitoring Stack

### Prometheus (`prometheus.yml`)
- Backend metrics scraping (15s)
- Service discovery via static configs
- Ready for Node exporter
- Custom application metrics

### Grafana
- Pre-configured dashboards
- Data source provisioning
- User management
- Plugin support

## 🔐 Security Features

### Development
- Basic authentication (development only)
- No SSL/TLS
- Full CORS access
- Debug logging enabled

### Production
- Strong password requirements
- SSL/TLS encryption (configurable)
- Restricted CORS origins
- Security headers enabled
- Rate limiting
- Non-root containers
- Minimal base images

## 🚢 Scaling Configuration

### Resource Limits

| Service | CPU Limit | Memory Limit | Replicas (Default) |
|---------|-----------|--------------|-------------------|
| Backend | 2.0 cores | 4GB | 2 |
| Frontend | 1.0 cores | 1GB | 2 |
| Database | 2.0 cores | 4GB | 1 |
| Redis | 1.0 cores | 1GB | 1 |
| ChromaDB | 2.0 cores | 4GB | 1 |
| Nginx | 1.0 cores | 512MB | 1 |

### Scaling Commands

```bash
# Scale specific services
make scale-backend NUM=4
make scale-frontend NUM=3

# Or using Docker Compose directly
docker-compose -f docker-compose.prod.yml up -d --scale backend=4
docker-compose -f docker-compose.prod.yml up -d --scale frontend=3
```

## 🔄 Health Checks

All services include comprehensive health checks:

- **Backend**: HTTP health endpoint (30s interval)
- **Frontend**: HTTP status check (30s interval)
- **PostgreSQL**: pg_isready command (30s interval)
- **Redis**: Redis-cli ping (30s interval)
- **ChromaDB**: HTTP heartbeat (30s interval)
- **Nginx**: HTTP health endpoint (30s interval)

## 💾 Data Persistence

### Volumes

| Volume | Purpose | Backup Strategy |
|--------|---------|----------------|
| `postgres_data` | Database files | Daily automated backups |
| `redis_data` | Cache persistence | Not critical (rebuildable) |
| `chromadb_data` | Vector embeddings | Regular backups recommended |
| `prometheus_data` | Metrics storage | Optional retention policies |
| `grafana_data` | Dashboards & configs | Backup before updates |

### Backup Strategy

```bash
# Manual backup
make backup

# Automatic backup script (add to crontab)
0 2 * * * /path/to/project/make backup
```

## 🛠️ Troubleshooting

### Common Issues and Solutions

1. **Port Conflicts**
   ```bash
   # Check port usage
   netstat -tulpn | grep :8000
   # Solution: Change ports in compose files
   ```

2. **Permission Issues**
   ```bash
   # Fix volume permissions
   sudo chown -R $USER:$USER ./data
   ```

3. **Memory Issues**
   ```bash
   # Monitor resource usage
   make stats
   # Adjust limits in compose files
   ```

4. **Service Not Starting**
   ```bash
   # Check logs
   make logs-<service>
   # Verify environment variables
   make env-show
   ```

### Log Locations

- **Application logs**: `./logs/` (mounted volume)
- **Container logs**: `docker-compose logs -f`
- **Nginx logs**: `/var/log/nginx/` (container)
- **Database logs**: Docker logs output

## 📈 Performance Optimization

### Development Optimizations
- Volume mounts for live code changes
- Hot reload reduces build times
- SQLite for faster local development

### Production Optimizations
- Multi-stage Docker builds
- Nginx static file serving
- Connection pooling
- Caching layers
- Gzip compression
- Resource limits prevent resource exhaustion

## 🔄 CI/CD Integration

The Docker configurations are designed for easy CI/CD integration:

```yaml
# Example GitHub Actions workflow
- name: Deploy to Production
  run: |
    docker-compose -f docker-compose.prod.yml --env-file .env.prod up -d --build
    make health
```

## 📚 Additional Resources

- **Detailed Setup Guide**: `./docker/README.md`
- **Environment Template**: `.env.example`
- **Makefile Commands**: `make help`
- **Deploy Script**: `./deploy.sh --help`

## 🎯 Next Steps

1. **Setup Environment**: Copy and configure `.env` files
2. **Development**: Start with `make dev`
3. **Testing**: Verify all services are healthy
4. **Production**: Deploy with `make prod`
5. **Monitoring**: Enable with `make prod-mon`
6. **Scaling**: Adjust replica counts as needed

For detailed instructions and troubleshooting, refer to `./docker/README.md`.