# Streaming Response System Documentation

## Overview

The Streaming Response System provides comprehensive real-time streaming capabilities for the Customer Support Agent system. It enables token-by-token streaming, real-time progress tracking, and Server-Sent Events (SSE) for smooth user experiences.

## Features

### 🔌 Server-Sent Events (SSE)
- Real-time event streaming to clients
- Automatic connection management and heartbeat monitoring
- Event resumption and recovery capabilities
- Built-in authentication and security validation

### 💬 Chat Streaming
- Token-by-token streaming for chat responses
- Real-time typing indicators and status updates
- Stream cancellation and timeout handling
- Buffer management and optimization

### 🤖 Agent Streaming
- Streaming agent responses with reasoning steps
- Metadata and context information streaming
- Agent-specific progress tracking
- Error handling and recovery

### 📊 Progress Tracking
- Real-time progress updates for long-running operations
- Estimated completion time calculation
- Step-by-step progress reporting
- Custom metadata support

### 🔧 Stream Management
- Active stream monitoring and analytics
- Stream lifecycle management
- Connection pooling and load balancing
- Automatic cleanup of expired streams

### 📈 Performance Monitoring
- Real-time performance metrics collection
- Stream analytics and reporting
- Buffer utilization monitoring
- Error rate tracking

## Architecture

### Core Components

#### StreamManager
- Central coordination of all streaming sessions
- Connection lifecycle management
- Stream state tracking
- Resource allocation and cleanup

#### StreamHandlers
- `ChatStreamHandler`: Handles chat message streaming
- `AgentStreamHandler`: Handles agent response streaming
- `ProgressTracker`: Manages progress tracking for operations

#### SSE Implementation
- `SSEEndpoint`: HTTP endpoint for SSE connections
- `SSEConnectionManager`: Manages SSE client connections
- `SSEEventFormatter`: Formats events for SSE protocol

#### Middleware Stack
- `StreamingMiddleware`: Base streaming request/response processing
- `StreamLoggingMiddleware`: Comprehensive request/response logging
- `StreamValidationMiddleware`: Request validation and sanitization
- `StreamPerformanceMiddleware`: Performance optimization and monitoring
- `StreamSecurityMiddleware`: Security validation and rate limiting

### Models

#### StreamEvent
```python
{
    "id": "uuid",
    "type": "connect|data|progress|complete|error",
    "session_id": "session identifier",
    "timestamp": "ISO datetime",
    "data": { ... },
    "metadata": { ... }
}
```

#### TokenChunk
```python
{
    "content": "text content",
    "token_count": 1,
    "chunk_index": 0,
    "is_final": false,
    "metadata": { ... }
}
```

#### ProgressUpdate
```python
{
    "session_id": "session identifier",
    "operation_id": "operation identifier",
    "progress_percentage": 75.5,
    "current_step": "Processing data",
    "total_steps": 10,
    "estimated_completion": "2023-11-04T12:00:00Z"
}
```

## API Endpoints

### SSE Endpoints

#### GET `/api/v1/streaming/sse/{session_id}`
Establish SSE connection for real-time streaming.

**Parameters:**
- `session_id`: Unique session identifier
- `stream_type`: Type of stream (chat, agent, progress, status)

**Response:** SSE stream with events

#### GET `/api/v1/streaming/sse/status`
Get SSE connection status and metrics.

#### DELETE `/api/v1/streaming/sse/cancel/{connection_id}`
Cancel an active SSE connection.

### Chat Streaming

#### POST `/api/v1/streaming/chat/start`
Start a new chat streaming session.

**Request Body:**
```json
{
    "session_id": "chat_session_1",
    "message": "Hello, how can you help?",
    "stream_type": "chat",
    "enable_token_streaming": true
}
```

#### POST `/api/v1/streaming/chat/stream/{session_id}`
Initiate streaming response for chat session.

#### POST `/api/v1/streaming/chat/cancel/{session_id}`
Cancel an active chat stream.

### Agent Streaming

#### POST `/api/v1/streaming/agent/start`
Start agent response streaming session.

#### POST `/api/v1/streaming/agent/stream/{session_id}`
Initiate agent response streaming.

#### POST `/api/v1/streaming/agent/cancel/{session_id}`
Cancel agent streaming session.

### Progress Tracking

#### POST `/api/v1/streaming/progress/start`
Start progress tracking for an operation.

#### POST `/api/v1/streaming/progress/update`
Update progress for ongoing operation.

#### POST `/api/v1/streaming/progress/complete`
Mark progress tracking as complete.

### Stream Management

#### GET `/api/v1/streaming/streams`
List all active streaming sessions.

#### GET `/api/v1/streaming/streams/{session_id}`
Get detailed information about specific stream.

#### DELETE `/api/v1/streaming/streams/{session_id}`
Terminate a streaming session.

### Monitoring & Analytics

#### GET `/api/v1/streaming/monitoring/performance`
Get streaming performance metrics.

#### GET `/api/v1/streaming/monitoring/analytics`
Get streaming analytics data.

#### GET `/api/v1/streaming/monitoring/health`
Get overall streaming system health.

### Configuration

#### POST `/api/v1/streaming/config/validate`
Validate streaming configuration parameters.

#### POST `/api/v1/streaming/recovery/create`
Create recovery point for stream resumption.

#### POST `/api/v1/streaming/recovery/{session_id}`
Recover stream from recovery point.

## Usage Examples

### JavaScript Client Example

```javascript
// Establish SSE connection
const sessionId = 'chat_session_123';
const eventSource = new EventSource(
    `/api/v1/streaming/sse/${sessionId}?stream_type=chat`
);

// Listen for events
eventSource.addEventListener('connect', (event) => {
    console.log('Connected to stream:', event.data);
});

eventSource.addEventListener('data', (event) => {
    const data = JSON.parse(event.data);
    if (data.token) {
        // Stream token to UI
        appendToResponse(data.token);
    }
});

eventSource.addEventListener('progress', (event) => {
    const progress = JSON.parse(event.data);
    updateProgressBar(progress.progress_percentage);
});

eventSource.addEventListener('complete', (event) => {
    console.log('Stream completed');
    eventSource.close();
});

eventSource.addEventListener('error', (event) => {
    console.error('Stream error:', event.data);
});
```

### Python Client Example

```python
import aiohttp
import asyncio

async def stream_chat_response(message):
    session_id = "chat_session_123"
    
    async with aiohttp.ClientSession() as session:
        # Start chat stream
        start_data = {
            "session_id": session_id,
            "message": message,
            "stream_type": "chat",
            "enable_token_streaming": True
        }
        
        async with session.post(
            f"http://localhost:8000/api/v1/streaming/chat/start",
            json=start_data
        ) as response:
            start_result = await response.json()
            print(f"Stream started: {start_result}")
        
        # Initiate streaming
        async with session.post(
            f"http://localhost:8000/api/v1/streaming/chat/stream/{session_id}",
            json=start_data
        ) as response:
            stream_result = await response.json()
            print(f"Streaming initiated: {stream_result}")

# Run the stream
asyncio.run(stream_chat_response("Hello, how are you?"))
```

### SSE Client Example

```python
import asyncio
import aiohttp

async def listen_to_sse(session_id):
    url = f"http://localhost:8000/api/v1/streaming/sse/{session_id}?stream_type=chat"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers={"Accept": "text/event-stream"}) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    event_data = json.loads(line[6:])  # Remove 'data: ' prefix
                    handle_stream_event(event_data)

async def handle_stream_event(event_data):
    event_type = event_data.get('type')
    data = event_data.get('data', {})
    
    if event_type == 'data':
        if 'token' in data:
            print(f"Received token: {data['token']}", end='', flush=True)
    elif event_type == 'progress':
        print(f"\nProgress: {data.get('progress_percentage', 0)}%")
    elif event_type == 'complete':
        print("\nStream completed")

# Listen to stream
asyncio.run(listen_to_sse('chat_session_123'))
```

## Configuration

### Stream Configuration

```python
StreamConfig(
    chunk_size=50,              # Tokens per chunk
    buffer_size=100,            # Event buffer size
    timeout=300,                # Stream timeout in seconds
    max_concurrent_streams=100, # Maximum concurrent streams
    heartbeat_interval=30,      # Heartbeat frequency
    retry_attempts=3,           # Retry attempts for failed streams
    compression_enabled=True,   # Enable response compression
    encryption_enabled=False,   # Enable stream encryption
    rate_limit=60              # Events per minute limit
)
```

### Middleware Configuration

```python
# Enable comprehensive streaming middleware
setup_streaming_middleware(
    app=app,
    stream_manager=stream_manager,
    enable_logging=True,        # Enable request/response logging
    enable_validation=True,     # Enable input validation
    enable_performance=True,    # Enable performance monitoring
    enable_security=True,       # Enable security validation
    log_all_requests=False      # Log all requests vs. only slow ones
)
```

## Performance Optimization

### Buffer Management
- FIFO, LIFO, and priority-based buffer strategies
- Automatic buffer overflow handling
- Configurable buffer sizes and cleanup intervals

### Connection Pooling
- Automatic connection cleanup and reuse
- Configurable connection timeouts
- Load balancing across multiple connections

### Compression
- Gzip compression for large responses
- Configurable compression thresholds
- Bandwidth optimization for slow connections

### Monitoring & Alerting
- Real-time performance metrics
- Automatic alert generation for degraded performance
- Historical performance analytics

## Security

### Authentication
- JWT token validation for streaming endpoints
- Session-based authentication support
- API key authentication for service-to-service communication

### Rate Limiting
- Per-session rate limiting
- Global rate limiting for system protection
- Configurable rate limits and window sizes

### Input Validation
- Comprehensive request validation
- Input sanitization and XSS protection
- SQL injection prevention

### Security Headers
- CSP headers for streaming responses
- CORS configuration for cross-origin requests
- Security headers middleware integration

## Error Handling

### Stream Errors
```json
{
    "type": "error",
    "session_id": "session_123",
    "data": {
        "error_code": "stream_timeout",
        "error_message": "Stream timeout after 300 seconds",
        "error_type": "timeout_error",
        "recoverable": true
    }
}
```

### Error Recovery
- Automatic retry with exponential backoff
- Stream resumption from recovery points
- Graceful degradation for failed components

## Testing

### Test Suite
Run the comprehensive test suite:

```bash
cd backend
python test_streaming_system.py
```

### Test Coverage
- SSE connection establishment and maintenance
- Chat and agent response streaming
- Progress tracking functionality
- Stream management operations
- Performance monitoring and analytics
- Error handling and recovery

### Manual Testing
1. Start the application: `python -m app.main`
2. Open API documentation: `http://localhost:8000/docs`
3. Test endpoints using the interactive API documentation
4. Monitor streaming metrics: `http://localhost:8000/api/v1/streaming/monitoring/health`

## Troubleshooting

### Common Issues

#### Connection Timeouts
- Check network connectivity and firewall settings
- Verify SSE endpoint accessibility
- Monitor connection limits and timeout configurations

#### Stream Interruptions
- Check for client-side network issues
- Monitor server resource utilization
- Verify stream timeout configurations

#### Performance Issues
- Monitor buffer sizes and utilization
- Check connection pooling settings
- Analyze performance metrics for bottlenecks

### Debug Logging
Enable debug logging for detailed troubleshooting:

```python
import structlog
structlog.configure(
    processors=[...],
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)
```

### Health Checks
Monitor system health through dedicated endpoints:
- `/health` - Basic application health
- `/api/v1/streaming/monitoring/health` - Streaming system health
- `/api/v1/streaming/monitoring/performance` - Performance metrics

## Integration

### Agent System Integration
The streaming system integrates seamlessly with the existing agent system:
- Real-time agent response streaming
- Agent state and progress tracking
- Automatic error handling and escalation

### Database Integration
- Stream metadata persistence
- Progress tracking storage
- Analytics data collection

### Monitoring Integration
- Prometheus metrics collection
- Structured logging integration
- Health check integration

## Future Enhancements

### Planned Features
- WebSocket support for bidirectional streaming
- Advanced stream analytics and ML-powered optimization
- Multi-region stream replication
- Advanced compression algorithms
- Stream encryption and privacy features

### Performance Improvements
- Stream prefetching and caching
- Adaptive chunk sizing based on network conditions
- Connection multiplexing for improved efficiency
- Advanced load balancing algorithms

This comprehensive streaming system provides a robust foundation for real-time communication in the Customer Support Agent system, enabling smooth user experiences and efficient resource utilization.