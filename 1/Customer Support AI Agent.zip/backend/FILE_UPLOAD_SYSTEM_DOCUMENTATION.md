# File Upload and Processing System Documentation

## Overview

This document describes the comprehensive file upload and processing system that has been implemented. The system provides secure, efficient file handling with advanced features including multipart uploads, processing queues, security scanning, and analytics.

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Core Components](#core-components)
3. [API Endpoints](#api-endpoints)
4. [File Processing Pipeline](#file-processing-pipeline)
5. [Security Features](#security-features)
6. [Storage Management](#storage-management)
7. [Analytics and Monitoring](#analytics-and-monitoring)
8. [Usage Examples](#usage-examples)
9. [Configuration](#configuration)
10. [Troubleshooting](#troubleshooting)

## Architecture Overview

The file upload system is built on a modern, scalable architecture with the following key components:

```
┌─────────────────────────────────────────────────────────────────┐
│                    File Upload System                           │
├─────────────────────────────────────────────────────────────────┤
│  API Layer (FastAPI)                                            │
│  ├── Upload Endpoints    ├── Processing Endpoints              │
│  ├── Management Endpoints ├── Search Endpoints                 │
│  ├── Security Endpoints  ├── Analytics Endpoints              │
├─────────────────────────────────────────────────────────────────┤
│  Business Logic Layer                                           │
│  ├── Upload Session Manager  ├── Processing Queue              │
│  ├── File Validator         ├── Storage Manager                │
│  ├── Security Scanner       ├── Analytics Engine               │
├─────────────────────────────────────────────────────────────────┤
│  Infrastructure Layer                                           │
│  ├── Attachment Tool       ├── Database Storage                │
│  ├── File Storage          ├── Temporary Storage               │
│  ├── Background Workers    ├── Caching Layer                   │
└─────────────────────────────────────────────────────────────────┘
```

### Key Features

- **Multipart Upload Support**: Handle large files by splitting into chunks
- **Real-time Progress Tracking**: Monitor upload progress with WebSocket updates
- **Security Scanning**: Comprehensive malware and threat detection
- **Background Processing**: Asynchronous file processing with priority queues
- **File Organization**: Session-based organization with metadata and tags
- **Search and Discovery**: Advanced search with filtering and pagination
- **Version Control**: File versioning with history tracking
- **Sharing and Collaboration**: Secure file sharing with access controls
- **Analytics and Monitoring**: Comprehensive usage and performance analytics
- **Audit Logging**: Complete audit trail for compliance

## Core Components

### 1. Upload Session Manager

Manages file upload sessions with progress tracking:

```python
class UploadSessionManager:
    def create_upload_session(self, filename, total_size, user_id)
    def update_upload_progress(self, upload_id, bytes_uploaded)
    def get_upload_progress(self, upload_id)
```

**Features:**
- Session-based tracking
- Chunk management
- Progress monitoring
- Automatic cleanup

### 2. Processing Queue

Background task queue for file processing:

```python
class FileProcessingQueue:
    async def add_file_processing_task(self, upload_id, file_data, priority)
    async def process_queue_worker(self)
```

**Features:**
- Priority-based processing
- Background workers
- Status tracking
- Retry mechanisms

### 3. Attachment Tool

Core file processing engine with MarkItDown integration:

```python
class AttachmentTool:
    async def process_attachments(self, file_paths)
    async def validate_file(self, file_path)
    async def extract_text_from_file(self, file_path)
```

**Features:**
- Multi-format support (PDF, Office docs, images, text)
- Content extraction and analysis
- Metadata extraction
- OCR capabilities
- Security scanning

### 4. Storage Manager

Comprehensive file storage management:

```python
class StorageManager:
    async def store_file(self, content, session_id, filename)
    async def get_file(self, record_id)
    async def delete_file(self, record_id)
```

**Features:**
- Database-backed file records
- File deduplication
- Quota management
- Backup and archival
- Access control

### 5. Analytics Engine

File processing analytics and monitoring:

```python
class FileAnalyticsEngine:
    async def get_comprehensive_analytics(self, time_window_hours)
    async def record_file_processing(self, session_id, file_type, ...)
```

**Features:**
- Processing metrics
- Performance monitoring
- Error tracking
- Usage analytics
- Predictive insights

## API Endpoints

### File Upload Endpoints

#### Initiate Upload

```http
POST /api/v1/files/upload/initiate
```

**Parameters:**
- `filename` (string): Name of the file to upload
- `total_size` (integer): Total file size in bytes
- `metadata` (string, optional): JSON metadata

**Response:**
```json
{
    "upload_id": "uuid-string",
    "filename": "document.pdf",
    "progress": 0.0,
    "status": "initializing",
    "bytes_uploaded": 0,
    "total_bytes": 1048576,
    "created_at": "2024-01-01T00:00:00"
}
```

#### Upload Chunk

```http
POST /api/v1/files/upload/chunk
```

**Parameters:**
- `upload_id` (string): Upload session ID
- `chunk_data` (file): Binary chunk data
- `chunk_index` (integer): Index of this chunk (0-based)
- `total_chunks` (integer): Total number of chunks

#### Complete Upload

```http
POST /api/v1/files/upload/complete
```

**Parameters:**
- `upload_id` (string): Upload session ID

**Response:**
```json
{
    "upload_id": "uuid-string",
    "file_id": 12345,
    "status": "processing",
    "progress": 0,
    "message": "File queued for processing",
    "created_at": "2024-01-01T00:00:00"
}
```

#### Get Upload Progress

```http
GET /api/v1/files/upload/progress/{upload_id}
```

### File Processing Endpoints

#### Get Processing Status

```http
GET /api/v1/files/processing/status/{upload_id}
```

**Response:**
```json
{
    "upload_id": "uuid-string",
    "file_id": 12345,
    "status": "completed",
    "progress": 100,
    "message": "Processing completed",
    "processed_content": "Extracted text content...",
    "metadata": {...},
    "processing_time": 2.5,
    "created_at": "2024-01-01T00:00:00",
    "completed_at": "2024-01-01T00:00:02"
}
```

#### Batch Upload

```http
POST /api/v1/files/batch/upload
```

**Parameters:**
- `files` (array): Multiple file uploads

**Response:**
```json
{
    "upload_ids": ["uuid1", "uuid2", "uuid3"],
    "total_files": 3,
    "successful_uploads": 3,
    "failed_uploads": 0
}
```

#### Batch Processing

```http
POST /api/v1/files/batch/process
```

**Body:**
```json
{
    "file_ids": [123, 124, 125],
    "processing_options": {
        "extract_metadata": true,
        "perform_ocr": false
    },
    "priority": "high"
}
```

### File Management Endpoints

#### List Files

```http
GET /api/v1/files/files/list
```

**Parameters:**
- `session_id` (string, optional): Filter by session
- `file_type` (string, optional): Filter by file type
- `status` (string, optional): Filter by status
- `limit` (integer): Number of files to return (max 500)
- `offset` (integer): Pagination offset

#### Download File

```http
GET /api/v1/files/files/{file_id}/download
```

#### Get File Metadata

```http
GET /api/v1/files/files/{file_id}/metadata
```

#### Update File Metadata

```http
PUT /api/v1/files/files/{file_id}/metadata
```

**Body:**
```json
{
    "title": "My Document",
    "description": "Important business document",
    "tags": ["contract", "legal", "2024"],
    "category": "contracts",
    "custom_metadata": {
        "client": "ABC Corp",
        "department": "Legal"
    }
}
```

#### Delete File

```http
DELETE /api/v1/files/files/{file_id}
```

#### Archive File

```http
POST /api/v1/files/files/{file_id}/archive
```

### Search and Discovery

#### Search Files

```http
POST /api/v1/files/files/search
```

**Body:**
```json
{
    "query": "contract",
    "file_types": ["pdf", "docx"],
    "tags": ["legal"],
    "date_from": "2024-01-01T00:00:00",
    "date_to": "2024-12-31T23:59:59",
    "size_min": 100000,
    "size_max": 5000000,
    "limit": 50,
    "offset": 0
}
```

#### Get Search Suggestions

```http
GET /api/v1/files/files/search/suggestions
```

**Parameters:**
- `query` (string): Partial query for suggestions
- `limit` (integer): Number of suggestions (max 50)

### File Sharing and Collaboration

#### Share File

```http
POST /api/v1/files/files/{file_id}/share
```

**Body:**
```json
{
    "share_with_users": ["user1", "user2"],
    "permissions": {
        "user1": "read",
        "user2": "write"
    },
    "expires_at": "2024-12-31T23:59:59",
    "generate_link": true
}
```

#### Access Shared File

```http
GET /api/v1/files/shared/{token}
```

### File Versioning and History

#### Get File Versions

```http
GET /api/v1/files/files/{file_id}/versions
```

**Response:**
```json
{
    "versions": [
        {
            "version_id": 1,
            "created_at": "2024-01-01T00:00:00",
            "created_by": "user1",
            "size": 1048576,
            "hash": "abc123...",
            "note": "Initial version",
            "is_current": true
        }
    ],
    "current_version": 1,
    "total_versions": 1
}
```

#### Create File Version

```http
POST /api/v1/files/files/{file_id}/versions
```

**Body:**
```json
{
    "version_note": "Updated with new content",
    "make_current": true
}
```

### File Security and Audit

#### Get Audit Log

```http
GET /api/v1/files/security/audit/files
```

**Parameters:**
- `file_id` (integer, optional): Filter by specific file
- `limit` (integer): Number of events (max 1000)

#### Security Scan

```http
GET /api/v1/files/security/scan/{file_id}
```

**Response:**
```json
{
    "file_id": 12345,
    "scan_time": "2024-01-01T00:00:00",
    "status": "clean",
    "threats": [],
    "warnings": ["Large file size"],
    "scan_engine": "BasicFileScanner v1.0",
    "definitions_version": "2024.1.1"
}
```

### File Utilities

#### Detect File Format

```http
POST /api/v1/files/utils/detect-format
```

**Parameters:**
- `file` (file): File to analyze

**Response:**
```json
{
    "filename": "document.pdf",
    "detected_format": {
        "file_type": "document",
        "mime_type": "application/pdf",
        "extension": "pdf"
    },
    "file_info": {
        "size": 1048576,
        "hash": "abc123...",
        "created_at": "2024-01-01T00:00:00"
    },
    "validation": {
        "is_supported": true,
        "is_safe": true
    }
}
```

#### Compress File

```http
POST /api/v1/files/utils/compress/{file_id}
```

**Body:**
```json
{
    "compression_level": 6,
    "output_format": "gzip"
}
```

### Analytics and Monitoring

#### Get File Analytics

```http
GET /api/v1/files/analytics/files
```

**Parameters:**
- `time_window_hours` (integer): Hours of data to include (max 168)

**Response:**
```json
{
    "time_window_hours": 24,
    "analytics": {
        "storage": {
            "database": {...},
            "physical": {...},
            "quotas": {...}
        },
        "processing": {
            "summary": {...},
            "performance": {...},
            "errors": {...}
        },
        "attachment_tool": {...}
    },
    "generated_at": "2024-01-01T00:00:00"
}
```

#### Maintenance Cleanup

```http
POST /api/v1/files/maintenance/cleanup
```

**Response:**
```json
{
    "message": "Maintenance cleanup completed",
    "cleanup_results": {
        "expired_files_cleaned": 10,
        "temp_files_cleaned": 25,
        "old_upload_sessions_cleaned": 5,
        "old_analytics_cleaned": true
    },
    "cleanup_time": "2024-01-01T00:00:00"
}
```

## File Processing Pipeline

### 1. Upload Phase

```
Client → Upload Initiation → Chunk Upload → Upload Completion → Processing Queue
```

**Steps:**
1. Client initiates upload and receives upload ID
2. Client uploads file in chunks (optional for large files)
3. Client completes upload and file is validated
4. File is queued for background processing

### 2. Processing Phase

```
Queue Worker → File Validation → Security Scan → Content Extraction → Storage
```

**Steps:**
1. Background worker picks up file from queue
2. File is validated (size, type, format)
3. Security scanning is performed
4. Content is extracted using appropriate processors
5. File is stored with metadata
6. Results are saved to database

### 3. Storage Phase

```
Content Storage → Metadata Storage → Index Creation → Backup
```

**Steps:**
1. File content is stored in physical storage
2. File metadata is stored in database
3. Search indexes are updated
4. Optional backup is performed

## Security Features

### File Validation

- **Extension Validation**: Only allowed file types
- **Size Limits**: Configurable maximum file sizes
- **MIME Type Verification**: Magic number detection
- **Content Scanning**: Basic pattern detection

### Security Scanning

- **Executable Detection**: Blocks dangerous file types
- **Script Detection**: Identifies script content
- **Signature Checking**: Malware signature detection
- **Threat Intelligence**: Integration with threat feeds

### Access Control

- **User Authentication**: JWT-based authentication
- **Permission Management**: Role-based access control
- **Session Tracking**: Upload session security
- **Audit Logging**: Complete access audit trail

### Data Protection

- **Encryption at Rest**: File content encryption
- **Secure Transmission**: HTTPS/TLS encryption
- **Data Sanitization**: Content sanitization
- **Privacy Controls**: PII detection and protection

## Storage Management

### Storage Types

- **Upload Storage**: Temporary upload storage
- **Processed Storage**: Processed file storage
- **Temporary Storage**: Processing temporary files
- **Backup Storage**: Long-term backup storage
- **Archive Storage**: Long-term archival storage

### Quota Management

- **File Count Limits**: Maximum files per storage type
- **Size Limits**: Maximum storage usage per type
- **Time Limits**: Automatic cleanup after expiry
- **Priority Handling**: High-priority processing

### Cleanup Policies

- **Automatic Cleanup**: Scheduled cleanup tasks
- **Manual Cleanup**: On-demand cleanup operations
- **Retention Policies**: Configurable retention periods
- **Archive Policies**: Automatic archival rules

## Analytics and Monitoring

### Processing Metrics

- **File Count**: Total files processed
- **Processing Time**: Average and distribution
- **Success Rate**: Processing success percentage
- **File Types**: Distribution by file type

### Performance Metrics

- **Throughput**: Files processed per hour
- **Response Time**: API response times
- **Resource Usage**: CPU, memory, disk usage
- **Queue Length**: Processing queue status

### Error Tracking

- **Error Categories**: Classification of errors
- **Error Patterns**: Identification of patterns
- **Resolution Suggestions**: Automated suggestions
- **Alerting**: Error threshold alerting

### Usage Analytics

- **User Activity**: User file operations
- **Storage Trends**: Storage usage over time
- **Popular Features**: Most used functionality
- **Growth Patterns**: File growth trends

## Usage Examples

### Basic File Upload

```python
import aiohttp

async def upload_file(filepath):
    async with aiohttp.ClientSession() as session:
        # Initiate upload
        async with session.post(
            'http://localhost:8000/api/v1/files/upload/initiate',
            data={
                'filename': 'document.pdf',
                'total_size': 1048576,
                'metadata': json.dumps({'description': 'My document'})
            }
        ) as response:
            upload_data = await response.json()
            upload_id = upload_data['upload_id']
        
        # Upload file (for small files)
        with open(filepath, 'rb') as f:
            async with session.post(
                'http://localhost:8000/api/v1/files/upload/complete',
                data={'upload_id': upload_id},
                data={'file': ('document.pdf', f.read(), 'application/pdf')}
            ) as response:
                return await response.json()
```

### Monitor Processing Status

```python
async def monitor_processing(upload_id):
    async with aiohttp.ClientSession() as session:
        while True:
            async with session.get(
                f'http://localhost:8000/api/v1/files/processing/status/{upload_id}'
            ) as response:
                status = await response.json()
                
                if status['status'] in ['completed', 'failed']:
                    return status
                
                print(f"Progress: {status['progress']}%")
                await asyncio.sleep(5)
```

### Search Files

```python
async def search_files(query):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            'http://localhost:8000/api/v1/files/files/search',
            json={
                'query': query,
                'file_types': ['pdf', 'docx'],
                'limit': 20
            }
        ) as response:
            return await response.json()
```

### Batch Process Files

```python
async def batch_process_files(file_ids):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            'http://localhost:8000/api/v1/files/batch/process',
            json={
                'file_ids': file_ids,
                'priority': 'high'
            }
        ) as response:
            return await response.json()
```

## Configuration

### File Size Limits

```python
# In app/config.py
UPLOAD_MAX_FILE_SIZE_MB = 50
ALLOWED_FILE_EXTENSIONS = ['pdf', 'docx', 'txt', 'jpg', 'png']
BLOCKED_FILE_EXTENSIONS = ['exe', 'bat', 'cmd', 'scr']
```

### Processing Settings

```python
# In app/config.py
MAX_PROCESSING_TIME_SECONDS = 300
MAX_CONCURRENT_PROCESSING = 10
PROCESSING_QUEUE_SIZE = 100
```

### Storage Settings

```python
# In app/config.py
UPLOAD_PATH = "./data/uploads"
PERMANENT_PATH = "./data/processed"
TEMP_PATH = "./data/temp"
```

### Security Settings

```python
# In app/config.py
ENABLE_VIRUS_SCANNING = True
ENABLE_CONTENT_SANITIZATION = True
ENABLE_AUDIT_LOGGING = True
```

### Analytics Settings

```python
# In app/config.py
ANALYTICS_RETENTION_DAYS = 30
ANALYTICS_BATCH_SIZE = 100
ENABLE_REAL_TIME_METRICS = True
```

## Troubleshooting

### Common Issues

#### Upload Fails

**Symptoms:**
- Upload initiation returns error
- Upload progress shows 0%

**Solutions:**
1. Check file size limits
2. Verify file type is allowed
3. Ensure server has sufficient storage
4. Check network connectivity

#### Processing Stuck

**Symptoms:**
- Processing status remains "processing"
- No progress updates

**Solutions:**
1. Check processing queue length
2. Verify background workers are running
3. Check file format compatibility
4. Review error logs

#### Storage Issues

**Symptoms:**
- Files not persisting
- Quota exceeded errors
- Slow file access

**Solutions:**
1. Check storage quota settings
2. Verify database connectivity
3. Run maintenance cleanup
4. Check disk space

### Log Analysis

#### Upload Logs

```bash
# Check upload progress
grep "upload.*progress" /var/log/app.log

# Check upload errors
grep "upload.*error" /var/log/app.log
```

#### Processing Logs

```bash
# Check processing status
grep "processing.*status" /var/log/app.log

# Check processing errors
grep "processing.*failed" /var/log/app.log
```

#### Storage Logs

```bash
# Check storage operations
grep "storage.*operation" /var/log/app.log

# Check cleanup operations
grep "cleanup.*completed" /var/log/app.log
```

### Monitoring

#### Health Checks

```bash
# Basic health check
curl http://localhost:8000/health

# Detailed health check
curl http://localhost:8000/health/detailed

# Storage health check
curl http://localhost:8000/api/v1/files/analytics/files
```

#### Metrics

```bash
# System metrics
curl http://localhost:8000/metrics

# Processing metrics
curl http://localhost:8000/api/v1/files/analytics/files
```

### Performance Optimization

#### Configuration Tuning

1. **Increase concurrent processing** for high throughput
2. **Adjust chunk size** for large file uploads
3. **Configure caching** for frequently accessed files
4. **Optimize database queries** for large datasets

#### Scaling Considerations

1. **Horizontal scaling** for multiple API instances
2. **Background workers** for processing queue
3. **Database optimization** for metadata queries
4. **CDN integration** for file delivery

## Conclusion

The file upload and processing system provides a comprehensive solution for handling file operations with security, scalability, and reliability. The modular architecture allows for easy customization and extension while maintaining high performance and security standards.

For additional support or feature requests, please refer to the project repository or contact the development team.
