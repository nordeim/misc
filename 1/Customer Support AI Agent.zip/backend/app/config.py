"""
Enhanced backend configuration using Pydantic Settings for environment-based configuration.

This module provides a comprehensive configuration management system using Pydantic Settings.
It supports different environments (development, production, testing) with proper validation,
security considerations, encryption, hot-reloading, and advanced features.

Features:
- Environment-specific configurations
- Type validation and conversion
- Security key generation and encryption
- Database URL construction
- CORS configuration
- Configuration hot-reloading
- Configuration validation on startup
- Comprehensive settings documentation
"""

import os
import json
import logging
import secrets
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Union, Any, Callable
from functools import lru_cache
from dataclasses import dataclass

from pydantic import (
    validator,
    Field,
    AnyHttpUrl,
    PostgresDsn,
    RedisDsn,
    SecretStr,
    root_validator,
)
from pydantic_settings import BaseSettings
from pydantic import model_validator  # Import model_validator separately

# Import configuration modules
try:
    from config.database import DatabaseConfig, database_config
    from config.redis import RedisConfig, redis_config
    from config.security import SecurityConfig, security_config
    from config.ai import AIConfig, ai_config
    from config.monitoring import MonitoringConfig, monitoring_config
    from config.config_validator import configuration_validator
    from config.config_loader import configuration_loader, Environment
    from config.config_migration import configuration_migrator
except ImportError:
    # Fallback if config modules are not available
    DatabaseConfig = None
    RedisConfig = None
    SecurityConfig = None
    AIConfig = None
    MonitoringConfig = None
    configuration_validator = None
    configuration_loader = None
    configuration_migrator = None
    Environment = None
    
    logger = logging.getLogger(__name__)
    logger.warning("Configuration modules not available, using fallback configuration")


@dataclass
class ConfigurationChange:
    """Represents a configuration change event."""
    field_name: str
    old_value: Any
    new_value: Any
    timestamp: float
    environment: str


class ConfigurationMonitor:
    """Monitor configuration changes for hot-reloading."""
    
    def __init__(self, settings_instance: "Settings"):
        self.settings = settings_instance
        self._last_config = {}
        self._callbacks: List[Callable[[ConfigurationChange], None]] = []
        self._monitoring = False
        self._lock = threading.Lock()
        
    def add_callback(self, callback: Callable[[ConfigurationChange], None]):
        """Add a callback for configuration changes."""
        with self._lock:
            self._callbacks.append(callback)
            
    def start_monitoring(self, interval: int = 5):
        """Start monitoring configuration changes."""
        if self._monitoring:
            return
            
        self._monitoring = True
        self._last_config = self._get_current_config()
        
        def monitor():
            while self._monitoring:
                time.sleep(interval)
                current_config = self._get_current_config()
                
                changes = self._detect_changes(current_config)
                for change in changes:
                    for callback in self._callbacks:
                        try:
                            callback(change)
                        except Exception as e:
                            logging.error(f"Error in configuration change callback: {e}")
                            
        monitor_thread = threading.Thread(target=monitor, daemon=True)
        monitor_thread.start()
        
    def stop_monitoring(self):
        """Stop monitoring configuration changes."""
        self._monitoring = False
        
    def _get_current_config(self) -> Dict[str, Any]:
        """Get current configuration as dictionary."""
        config = {}
        for field_name, field in self.settings.__fields__.items():
            value = getattr(self.settings, field_name)
            if isinstance(value, SecretStr):
                value = value.get_secret_value() if value else None
            config[field_name] = value
        return config
        
    def _detect_changes(self, current_config: Dict[str, Any]) -> List[ConfigurationChange]:
        """Detect configuration changes."""
        changes = []
        for key, new_value in current_config.items():
            old_value = self._last_config.get(key)
            if old_value != new_value:
                changes.append(ConfigurationChange(
                    field_name=key,
                    old_value=old_value,
                    new_value=new_value,
                    timestamp=time.time(),
                    environment=self.settings.environment
                ))
        self._last_config = current_config
        return changes


class Settings(BaseSettings):
    """
    Application settings with environment-based configuration.
    
    This class uses Pydantic Settings to manage all configuration variables
    with proper validation, type checking, and environment variable loading.
    """
    
    # ==============================================================================
    # APPLICATION ENVIRONMENT
    # ==============================================================================
    environment: str = Field(default="development", description="Application environment")
    app_name: str = Field(default="Customer Support AI Agent", description="Application name")
    app_version: str = Field(default="1.0.0", description="Application version")
    app_debug: bool = Field(default=True, description="Enable debug mode")
    
    # ==============================================================================
    # API SERVER CONFIGURATION
    # ==============================================================================
    api_host: str = Field(default="0.0.0.0", description="API server host")
    api_port: int = Field(default=8000, ge=1, le=65535, description="API server port")
    
    # CORS settings
    cors_origins: List[AnyHttpUrl] = Field(
        default=["http://localhost:3000", "http://localhost:5173"],
        description="CORS allowed origins"
    )
    cors_allow_credentials: bool = Field(default=True, description="Allow CORS credentials")
    cors_allow_methods: List[str] = Field(
        default=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        description="CORS allowed methods"
    )
    cors_allow_headers: List[str] = Field(
        default=["*"],
        description="CORS allowed headers"
    )
    
    # ==============================================================================
    # SECURITY CONFIGURATION
    # ==============================================================================
    secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="Secret key for encryption and JWT signing"
    )
    jwt_secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="JWT secret key"
    )
    jwt_algorithm: str = Field(default="HS256", description="JWT algorithm")
    jwt_expire_minutes: int = Field(default=30, ge=1, description="JWT expiration in minutes")
    jwt_refresh_expire_days: int = Field(default=7, ge=1, description="JWT refresh expiration in days")
    
    # API and session keys
    api_key: Optional[SecretStr] = Field(default=None, description="API key for authentication")
    session_secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="Session secret key"
    )
    
    # ==============================================================================
    # DATABASE CONFIGURATION
    # ==============================================================================
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/sqlite/customer_support.db",
        description="Database connection URL"
    )
    
    # Database connection pool settings
    db_pool_size: int = Field(default=10, ge=1, description="Database pool size")
    db_max_overflow: int = Field(default=20, ge=0, description="Database max overflow")
    db_pool_timeout: int = Field(default=30, ge=1, description="Database pool timeout")
    db_pool_recycle: int = Field(default=3600, ge=1, description="Database pool recycle time")
    
    # ==============================================================================
    # REDIS CONFIGURATION
    # ==============================================================================
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL"
    )
    redis_password: Optional[str] = Field(default=None, description="Redis password")
    
    # Redis connection settings
    redis_host: str = Field(default="localhost", description="Redis host")
    redis_port: int = Field(default=6379, ge=1, le=65535, description="Redis port")
    redis_db: int = Field(default=0, ge=0, le=15, description="Redis database number")
    redis_timeout: int = Field(default=5, ge=1, description="Redis timeout")
    redis_max_connections: int = Field(default=20, ge=1, description="Redis max connections")
    
    # Redis expiration settings
    redis_session_expire: int = Field(default=86400, ge=1, description="Session expiration in seconds")
    redis_cache_expire: int = Field(default=3600, ge=1, description="Cache expiration in seconds")
    
    # ==============================================================================
    # AI/LLM CONFIGURATION
    # ==============================================================================
    # OpenAI Configuration
    openai_api_key: Optional[SecretStr] = Field(default=None, description="OpenAI API key")
    openai_model: str = Field(default="gpt-3.5-turbo", description="OpenAI model name")
    openai_max_tokens: int = Field(default=2000, ge=1, description="OpenAI max tokens")
    openai_temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="OpenAI temperature")
    openai_timeout: int = Field(default=60, ge=1, description="OpenAI timeout")
    
    # Azure OpenAI Configuration
    azure_openai_api_key: Optional[SecretStr] = Field(default=None, description="Azure OpenAI API key")
    azure_openai_endpoint: Optional[str] = Field(default=None, description="Azure OpenAI endpoint")
    azure_openai_deployment_name: Optional[str] = Field(default=None, description="Azure OpenAI deployment name")
    azure_openai_api_version: str = Field(default="2024-02-01", description="Azure OpenAI API version")
    
    # Embedding model for RAG
    embedding_model: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2",
        description="Embedding model for vector generation"
    )
    embedding_dimension: int = Field(default=384, ge=1, description="Embedding dimension")
    embedding_batch_size: int = Field(default=32, ge=1, description="Embedding batch size")
    
    # ==============================================================================
    # CHROMADB CONFIGURATION
    # ==============================================================================
    chroma_host: str = Field(default="localhost", description="ChromaDB host")
    chroma_port: int = Field(default=8001, ge=1, le=65535, description="ChromaDB port")
    chroma_persist_directory: str = Field(
        default="./data/chromadb",
        description="ChromaDB persistence directory"
    )
    chroma_collection_name: str = Field(
        default="customer_support_docs",
        description="ChromaDB collection name"
    )
    chroma_tenant_name: str = Field(default="customer_support", description="ChromaDB tenant name")
    chroma_database_name: str = Field(default="customer_support", description="ChromaDB database name")
    
    # Vector search settings
    vector_search_top_k: int = Field(default=5, ge=1, description="Top K results for vector search")
    vector_search_score_threshold: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum score threshold for vector search"
    )
    vector_chunk_size: int = Field(default=1000, ge=100, description="Vector chunk size")
    vector_chunk_overlap: int = Field(default=200, ge=0, description="Vector chunk overlap")
    
    # ==============================================================================
    # RAG CONFIGURATION
    # ==============================================================================
    rag_enabled: bool = Field(default=True, description="Enable RAG functionality")
    rag_return_metadata: bool = Field(default=True, description="Return metadata in RAG results")
    rag_max_chunks_per_query: int = Field(default=5, ge=1, description="Max chunks per query")
    rag_chunk_size: int = Field(default=1000, ge=100, description="RAG chunk size")
    rag_chunk_overlap: int = Field(default=200, ge=0, description="RAG chunk overlap")
    
    # Document processing
    document_chunking_enabled: bool = Field(default=True, description="Enable document chunking")
    document_supported_formats: List[str] = Field(
        default=["pdf", "docx", "txt", "md", "html"],
        description="Supported document formats"
    )
    document_max_size_mb: int = Field(default=50, ge=1, description="Max document size in MB")
    document_upload_path: str = Field(default="./data/uploads", description="Document upload path")
    
    # ==============================================================================
    # MEMORY MANAGEMENT
    # ==============================================================================
    memory_enabled: bool = Field(default=True, description="Enable conversation memory")
    memory_max_history: int = Field(default=50, ge=1, description="Max conversation history")
    memory_ttl_hours: int = Field(default=24, ge=1, description="Memory TTL in hours")
    memory_auto_cleanup: bool = Field(default=True, description="Enable automatic memory cleanup")
    
    # Session settings
    session_timeout_minutes: int = Field(default=30, ge=1, description="Session timeout")
    session_cleanup_interval_hours: int = Field(default=1, ge=1, description="Session cleanup interval")
    
    # ==============================================================================
    # FILE UPLOAD CONFIGURATION
    # ==============================================================================
    upload_enabled: bool = Field(default=True, description="Enable file uploads")
    upload_max_file_size_mb: int = Field(default=50, ge=1, description="Max file size in MB")
    upload_allowed_extensions: List[str] = Field(
        default=["pdf", "docx", "txt", "md", "jpg", "jpeg", "png", "gif"],
        description="Allowed file extensions"
    )
    upload_temp_path: str = Field(default="./data/temp_uploads", description="Temporary upload path")
    upload_permanent_path: str = Field(default="./data/uploads", description="Permanent upload path")
    
    # File processing
    file_processing_enabled: bool = Field(default=True, description="Enable file processing")
    file_processing_timeout: int = Field(default=300, ge=1, description="File processing timeout")
    file_max_concurrent: int = Field(default=5, ge=1, description="Max concurrent file processing")
    
    # ==============================================================================
    # LOGGING AND MONITORING
    # ==============================================================================
    log_level: str = Field(default="INFO", description="Logging level")
    log_format: str = Field(default="json", description="Logging format")
    log_file_path: str = Field(default="./data/logs/app.log", description="Log file path")
    log_max_file_size_mb: int = Field(default=100, ge=1, description="Max log file size in MB")
    log_backup_count: int = Field(default=10, ge=1, description="Log backup count")
    
    # Prometheus metrics
    prometheus_enabled: bool = Field(default=True, description="Enable Prometheus metrics")
    prometheus_port: int = Field(default=9090, ge=1, le=65535, description="Prometheus port")
    metrics_endpoint: str = Field(default="/metrics", description="Metrics endpoint")
    
    # Health check
    health_check_enabled: bool = Field(default=True, description="Enable health checks")
    health_check_endpoint: str = Field(default="/health", description="Health check endpoint")
    
    # ==============================================================================
    # RATE LIMITING
    # ==============================================================================
    rate_limit_enabled: bool = Field(default=True, description="Enable rate limiting")
    rate_limit_requests_per_minute: int = Field(default=100, ge=1, description="Requests per minute")
    rate_limit_burst_size: int = Field(default=20, ge=1, description="Rate limit burst size")
    rate_limit_storage: str = Field(default="redis", description="Rate limit storage backend")
    
    # ==============================================================================
    # ESCALATION CONFIGURATION
    # ==============================================================================
    escalation_enabled: bool = Field(default=True, description="Enable escalation")
    escalation_threshold: float = Field(default=0.8, ge=0.0, le=1.0, description="Escalation threshold")
    escalation_auto_escalate: bool = Field(default=True, description="Auto escalate")
    
    # ==============================================================================
    # NOTIFICATION CONFIGURATION
    # ==============================================================================
    notification_enabled: bool = Field(default=False, description="Enable notifications")
    
    # SMTP settings
    smtp_host: Optional[str] = Field(default=None, description="SMTP host")
    smtp_port: int = Field(default=587, ge=1, le=65535, description="SMTP port")
    smtp_username: Optional[str] = Field(default=None, description="SMTP username")
    smtp_password: Optional[str] = Field(default=None, description="SMTP password")
    smtp_use_tls: bool = Field(default=True, description="Use TLS for SMTP")
    
    # Slack integration
    slack_webhook_url: Optional[str] = Field(default=None, description="Slack webhook URL")
    
    # Email settings
    email_from: Optional[str] = Field(default=None, description="Email from address")
    email_to: Optional[str] = Field(default=None, description="Email to address")
    
    # ==============================================================================
    # EXTERNAL SERVICES
    # ==============================================================================
    # CRM integration
    crm_api_url: Optional[str] = Field(default=None, description="CRM API URL")
    crm_api_key: Optional[str] = Field(default=None, description="CRM API key")
    
    # Knowledge base API
    kb_api_url: Optional[str] = Field(default=None, description="Knowledge base API URL")
    kb_api_key: Optional[str] = Field(default=None, description="Knowledge base API key")
    
    # ==============================================================================
    # DEVELOPMENT SETTINGS
    # ==============================================================================
    debug_sql: bool = Field(default=False, description="Enable SQL debugging")
    debug_asyncio: bool = Field(default=False, description="Enable asyncio debugging")
    profiling_enabled: bool = Field(default=False, description="Enable profiling")
    hot_reload: bool = Field(default=True, description="Enable hot reload")
    
    # Frontend URL
    frontend_url: str = Field(default="http://localhost:3000", description="Frontend URL")
    
    # ==============================================================================
    # PRODUCTION SETTINGS
    # ==============================================================================
    ssl_enabled: bool = Field(default=False, description="Enable SSL/TLS")
    ssl_cert_path: Optional[str] = Field(default=None, description="SSL certificate path")
    ssl_key_path: Optional[str] = Field(default=None, description="SSL key path")
    
    # Load balancer settings
    trust_proxy: bool = Field(default=False, description="Trust proxy headers")
    trust_proxy_headers: bool = Field(default=True, description="Trust proxy headers")
    
    # Performance settings
    worker_processes: int = Field(default=4, ge=1, description="Worker processes")
    worker_threads: int = Field(default=2, ge=1, description="Worker threads")
    
    # Backup settings
    backup_enabled: bool = Field(default=False, description="Enable backups")
    backup_schedule: str = Field(default="0 2 * * *", description="Backup schedule")
    backup_retention_days: int = Field(default=30, ge=1, description="Backup retention days")
    backup_path: str = Field(default="./data/backups", description="Backup path")
    
    # ==============================================================================
    # SECURITY HEADERS
    # ==============================================================================
    security_headers_enabled: bool = Field(default=True, description="Enable security headers")
    hsts_max_age: int = Field(default=31536000, ge=0, description="HSTS max age")
    content_security_policy: str = Field(
        default="default-src 'self'",
        description="Content Security Policy"
    )
    
    class Config:
        """
        Pydantic configuration for settings.
        
        This configuration controls how Pydantic handles environment variables,
        case sensitivity, and other settings behavior.
        """
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        env_prefix = ""
        env_nested_delimiter = "__"
        
        # Custom environment variable mappings
        fields = {
            "secret_key": {"env": ["SECRET_KEY", "SECRET"]},
            "jwt_secret_key": {"env": ["JWT_SECRET_KEY", "JWT_SECRET"]},
            "session_secret_key": {"env": ["SESSION_SECRET_KEY", "SESSION_SECRET"]},
            "openai_api_key": {"env": ["OPENAI_API_KEY"]},
            "azure_openai_api_key": {"env": ["AZURE_OPENAI_API_KEY"]},
            "api_key": {"env": ["API_KEY", "API_ACCESS_KEY"]},
        }
    
    # ==============================================================================
    # VALIDATORS
    # ==============================================================================
    
    @validator("environment")
    def validate_environment(cls, v):
        """Validate environment is one of the allowed values."""
        allowed_environments = ["development", "production", "testing"]
        if v not in allowed_environments:
            raise ValueError(f"Environment must be one of: {allowed_environments}")
        return v
    
    @validator("log_level")
    def validate_log_level(cls, v):
        """Validate log level is one of the allowed values."""
        allowed_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in allowed_levels:
            raise ValueError(f"Log level must be one of: {allowed_levels}")
        return v.upper()
    
    @validator("database_url")
    def validate_database_url(cls, v, values):
        """Construct database URL based on environment if not provided."""
        environment = values.get("environment", "development")
        
        if environment == "development" and "sqlite" not in v.lower():
            # Use SQLite for development if no specific URL provided
            return "sqlite+aiosqlite:///./data/sqlite/customer_support.db"
        
        return v
    
    @validator("cors_origins", pre=True)
    def parse_cors_origins(cls, v):
        """Parse CORS origins from string or list."""
        if isinstance(v, str):
            import json
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                # Split by comma if JSON parsing fails
                return [origin.strip() for origin in v.split(",")]
        return v
    
    @validator("upload_allowed_extensions", pre=True)
    def parse_upload_extensions(cls, v):
        """Parse upload extensions from string or list."""
        if isinstance(v, str):
            import json
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return [ext.strip() for ext in v.split(",")]
        return v
    
    @validator("chroma_persist_directory", pre=True)
    def create_chroma_directory(cls, v):
        """Create ChromaDB directory if it doesn't exist."""
        if isinstance(v, str):
            v = Path(v)
        v.mkdir(parents=True, exist_ok=True)
        return str(v)
    
    @validator("upload_temp_path", "upload_permanent_path", "log_file_path", "backup_path", pre=True)
    def create_directories(cls, v):
        """Create necessary directories if they don't exist."""
        if isinstance(v, str):
            v = Path(v)
        v.mkdir(parents=True, exist_ok=True)
        return str(v)
    
    # ==============================================================================
    # PROPERTY METHODS
    # ==============================================================================
    
    @property
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.environment == "development"
    
    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment == "production"
    
    @property
    def is_testing(self) -> bool:
        """Check if running in testing environment."""
        return self.environment == "testing"
    
    @property
    def jwt_expire_delta(self) -> timedelta:
        """Get JWT expiration delta."""
        return timedelta(minutes=self.jwt_expire_minutes)
    
    @property
    def jwt_refresh_expire_delta(self) -> timedelta:
        """Get JWT refresh expiration delta."""
        return timedelta(days=self.jwt_refresh_expire_days)
    
    @property
    def upload_max_size_bytes(self) -> int:
        """Get upload max size in bytes."""
        return self.upload_max_file_size_mb * 1024 * 1024
    
    @property
    def document_max_size_bytes(self) -> int:
        """Get document max size in bytes."""
        return self.document_max_size_mb * 1024 * 1024
    
    @property
    def log_max_size_bytes(self) -> int:
        """Get log max size in bytes."""
        return self.log_max_file_size_mb * 1024 * 1024
    
    @property
    def chroma_persist_path(self) -> Path:
        """Get ChromaDB persist path."""
        return Path(self.chroma_persist_directory)
    
    @property
    def upload_temp_path_obj(self) -> Path:
        """Get upload temp path as Path object."""
        return Path(self.upload_temp_path)
    
    @property
    def upload_permanent_path_obj(self) -> Path:
        """Get upload permanent path as Path object."""
        return Path(self.upload_permanent_path)
    
    @property
    def backup_path_obj(self) -> Path:
        """Get backup path as Path object."""
        return Path(self.backup_path)
    
    @property
    def log_file_path_obj(self) -> Path:
        """Get log file path as Path object."""
        return Path(self.log_file_path)
    
    @property
    def debug(self) -> bool:
        """Get debug flag for compatibility with other modules."""
        return self.app_debug
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    def create_directories(self) -> None:
        """Create necessary directories if they don't exist."""
        directories = [
            self.chroma_persist_path,
            Path(self.upload_temp_path),
            Path(self.upload_permanent_path),
            Path(self.backup_path),
            Path(self.log_file_path).parent,
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def get_database_url_for_worker(self, worker_id: int) -> str:
        """Get database URL for a specific worker."""
        if "sqlite" in self.database_url.lower():
            base_db = self.database_url.replace(".db", "")
            return f"{base_db}_worker_{worker_id}.db"
        return self.database_url
    
    def get_redis_url_for_worker(self, worker_id: int) -> str:
        """Get Redis URL for a specific worker."""
        if "redis://" in self.redis_url:
            return f"{self.redis_url.rstrip('/')}/{worker_id}"
        return f"redis://{self.redis_host}:{self.redis_port}/{worker_id}"
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._config_monitor = None
        self._setup_monitoring()
        self._encrypt_sensitive_data()
        
    def _setup_monitoring(self):
        """Setup configuration monitoring for hot-reloading."""
        if self.is_development and self.hot_reload:
            self._config_monitor = ConfigurationMonitor(self)
            self._config_monitor.start_monitoring(interval=10)
            
    def _encrypt_sensitive_data(self):
        """Encrypt sensitive configuration data."""
        try:
            from cryptography.fernet import Fernet
            
            # Use a derived key from the secret key for encryption
            key = self.secret_key.get_secret_value()[:32].encode()
            key = key.ljust(32, b'0')[:32]  # Ensure exactly 32 bytes
            fernet = Fernet(key)
            
            # Encrypt sensitive fields that are not already encrypted
            sensitive_fields = [
                'api_key', 'session_secret_key', 'smtp_password', 
                'crm_api_key', 'kb_api_key', 'slack_webhook_url'
            ]
            
            for field_name in sensitive_fields:
                field_value = getattr(self, field_name, None)
                if field_value and isinstance(field_value, str) and not field_value.startswith('gpg:'):
                    encrypted_value = f"gpg:{fernet.encrypt(field_value.encode()).decode()}"
                    setattr(self, field_name, encrypted_value)
                    
        except ImportError:
            logging.warning("Cryptography package not available. Encryption disabled.")
        except Exception as e:
            logging.error(f"Error encrypting sensitive data: {e}")
            
    def decrypt_sensitive_data(self, field_name: str) -> Optional[str]:
        """Decrypt a specific sensitive field."""
        try:
            from cryptography.fernet import Fernet
            
            field_value = getattr(self, field_name, None)
            if not field_value or not isinstance(field_value, str) or not field_value.startswith('gpg:'):
                return field_value
                
            key = self.secret_key.get_secret_value()[:32].encode()
            key = key.ljust(32, b'0')[:32]
            fernet = Fernet(key)
            
            encrypted_data = field_value[4:]  # Remove 'gpg:' prefix
            return fernet.decrypt(encrypted_data.encode()).decode()
            
        except ImportError:
            logging.warning("Cryptography package not available for decryption.")
            return field_value
        except Exception as e:
            logging.error(f"Error decrypting {field_name}: {e}")
            return None
            
    def _validate_environment_specific(self):
        """Validate environment-specific requirements."""
        issues = []
        
        if self.is_production:
            # Production requirements
            if not self.secret_key.get_secret_value() or len(self.secret_key.get_secret_value()) < 32:
                issues.append("Production requires a strong secret key (min 32 characters)")
            
            if "sqlite" in self.database_url.lower():
                issues.append("Production should use PostgreSQL, not SQLite")
            
            if not self.ssl_enabled:
                issues.append("Production should enable SSL/TLS")
                
            if not self.backup_enabled:
                issues.append("Production should enable backup functionality")
                
        elif self.is_development:
            # Development optimizations
            if self.debug_sql:
                logging.warning("SQL debugging enabled in development mode")
                
        elif self.is_testing:
            # Testing requirements
            if "sqlite" not in self.database_url.lower():
                logging.warning("Testing environment should use SQLite for isolation")
                
        return issues
        
    def _validate_service_dependencies(self):
        """Validate service dependencies and configurations."""
        issues = []
        
        # LLM service validation
        if not self.openai_api_key and not self.azure_openai_api_key:
            issues.append("No LLM API key configured (OpenAI or Azure OpenAI)")
            
        # Database connectivity validation
        try:
            if "postgresql" in self.database_url.lower():
                if "localhost" in self.database_url.lower():
                    issues.append("PostgreSQL configured with localhost - ensure PostgreSQL is running")
        except Exception:
            pass
            
        # Redis connectivity validation
        try:
            if not self.redis_host:
                issues.append("Redis host not configured")
        except Exception:
            pass
            
        return issues
        
    def _validate_security_settings(self):
        """Validate security-related configurations."""
        issues = []
        
        # Security headers
        if self.is_production and not self.security_headers_enabled:
            issues.append("Production should enable security headers")
            
        # HSTS configuration
        if self.security_headers_enabled and self.hsts_max_age < 31536000:
            logging.warning(f"HSTS max age ({self.hsts_max_age}) is below recommended 31536000 seconds")
            
        return issues
        
    @model_validator(mode='before')
    @classmethod
    def validate_configuration_root(cls, values):
        """Root validator for comprehensive configuration validation."""
        if isinstance(values, dict):
            issues = []
            
            # Environment validation
            env = values.get('environment', 'development')
            allowed_envs = ['development', 'production', 'testing']
            if env not in allowed_envs:
                raise ValueError(f"Environment must be one of: {allowed_envs}")
                
            # CORS validation
            cors_origins = values.get('cors_origins', [])
            if env == 'production' and '*' in cors_origins:
                issues.append("Production should not allow wildcard CORS origins")
                
            # File upload validation
            upload_max_size = values.get('upload_max_file_size_mb', 50)
            if upload_max_size > 100:
                issues.append("Upload file size should not exceed 100MB")
                
            if issues:
                raise ValueError(f"Configuration validation failed: {'; '.join(issues)}")
                
        return values
        
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate the current configuration and return detailed results."""
        all_issues = []
        
        # Environment-specific validation
        all_issues.extend(self._validate_environment_specific())
        
        # Service dependency validation
        all_issues.extend(self._validate_service_dependencies())
        
        # Security validation
        all_issues.extend(self._validate_security_settings())
        
        # Additional validations
        if not self.chroma_persist_path.parent.exists():
            all_issues.append(f"ChromaDB persist directory parent does not exist: {self.chroma_persist_path.parent}")
            
        return {
            "valid": len(all_issues) == 0,
            "issues": all_issues,
            "configuration_summary": {
                "environment": self.environment,
                "database": self.database_url.split("://")[0],
                "redis": bool(self.redis_host),
                "llm_configured": bool(self.openai_api_key or self.azure_openai_api_key),
                "chromadb_path": str(self.chroma_persist_path),
                "security_headers": self.security_headers_enabled,
                "ssl_enabled": self.ssl_enabled,
                "hot_reload": self.hot_reload,
            },
            "validation_timestamp": time.time(),
        }
        
    def reload_configuration(self):
        """Reload configuration from environment variables."""
        if self._config_monitor:
            self._config_monitor.stop_monitoring()
            
        # Re-initialize settings
        new_settings = Settings()
        for field_name, field in self.__fields__.items():
            if hasattr(new_settings, field_name):
                setattr(self, field_name, getattr(new_settings, field_name))
                
        self._setup_monitoring()
        
    def get_configuration_report(self) -> Dict[str, Any]:
        """Generate a comprehensive configuration report."""
        validation_result = self.validate_configuration()
        
        return {
            "application_info": {
                "name": self.app_name,
                "version": self.app_version,
                "environment": self.environment,
                "debug": self.app_debug,
            },
            "validation": validation_result,
            "security_status": {
                "secret_key_configured": bool(self.secret_key.get_secret_value()),
                "jwt_configured": bool(self.jwt_secret_key.get_secret_value()),
                "api_key_configured": bool(self.api_key),
                "security_headers": self.security_headers_enabled,
            },
            "services": {
                "database": {
                    "type": self.database_url.split("://")[0],
                    "pool_size": self.db_pool_size,
                    "max_overflow": self.db_max_overflow,
                },
                "redis": {
                    "host": self.redis_host,
                    "port": self.redis_port,
                    "db": self.redis_db,
                    "configured": bool(self.redis_host),
                },
                "llm": {
                    "openai_configured": bool(self.openai_api_key),
                    "azure_configured": bool(self.azure_openai_api_key),
                    "model": self.openai_model,
                },
                "chromadb": {
                    "path": str(self.chroma_persist_path),
                    "collection": self.chroma_collection_name,
                },
            },
            "monitoring": {
                "prometheus_enabled": self.prometheus_enabled,
                "health_check_enabled": self.health_check_enabled,
                "hot_reload": self.hot_reload,
            },
        }
        
    def export_to_env_file(self, file_path: str, encrypt_secrets: bool = True):
        """Export configuration to .env file."""
        env_content = []
        
        for field_name, field in self.__fields__.items():
            value = getattr(self, field_name)
            
            # Handle secrets
            if isinstance(value, SecretStr):
                if value and value.get_secret_value():
                    if encrypt_secrets and not str(value).startswith('gpg:'):
                        # Keep as-is, encryption handled separately
                        env_value = value.get_secret_value()
                    else:
                        env_value = value.get_secret_value()
                else:
                    continue
            else:
                env_value = str(value)
                
            # Skip complex types
            if isinstance(value, (list, dict)):
                env_value = json.dumps(value)
                
            env_content.append(f"{field_name.upper()}={env_value}")
            
        with open(file_path, 'w') as f:
            f.write('\n'.join(env_content))
            
        logging.info(f"Configuration exported to {file_path}")


# Global settings instance
settings = Settings()

# Environment-specific settings
DevelopmentSettings = Settings
ProductionSettings = Settings
TestingSettings = Settings