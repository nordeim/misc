"""
Services module for the Customer Support AI Agent.

Provides high-level business logic services for:
- Memory management and conversation context
- Message processing and analytics
- Security and content validation
- Utility operations (backup, export, etc.)
- Session management
- Notification handling
- Analytics and reporting

Author: Customer Support AI Agent
Version: 3.0.0
"""

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .memory_service import ConversationMemoryManager, MemoryOptimizationService
    from .message_service import MessageService
    from .message_analytics_service import MessageAnalyticsService
    from .message_security_service import MessageSecurityService
    from .message_utilities_service import MessageUtilitiesService

# Configure module logger
logger = logging.getLogger(__name__)

# Import all services
try:
    from .memory_service import (
        ConversationMemoryManager, 
        MemoryOptimizationService,
        get_conversation_memory_manager,
        get_memory_optimization_service
    )
    
    from .message_service import MessageService
    from .message_analytics_service import MessageAnalyticsService
    from .message_security_service import MessageSecurityService
    from .message_utilities_service import MessageUtilitiesService
    
    __all__ = [
        "ConversationMemoryManager",
        "MemoryOptimizationService", 
        "get_conversation_memory_manager",
        "get_memory_optimization_service",
        "MessageService",
        "MessageAnalyticsService",
        "MessageSecurityService",
        "MessageUtilitiesService"
    ]
    
    logger.info("All services initialized successfully")
    
except ImportError as e:
    logger.warning(f"Failed to import some services: {e}")
    
    # Provide fallbacks for missing services
    class ConversationMemoryManager:
        def __init__(self, memory_tool):
            logger.warning("ConversationMemoryManager not available - using fallback")
    
    class MemoryOptimizationService:
        def __init__(self, memory_tool):
            logger.warning("MemoryOptimizationService not available - using fallback")
    
    class MessageService:
        def __init__(self):
            logger.warning("MessageService not available - using fallback")
    
    class MessageAnalyticsService:
        def __init__(self):
            logger.warning("MessageAnalyticsService not available - using fallback")
    
    class MessageSecurityService:
        def __init__(self):
            logger.warning("MessageSecurityService not available - using fallback")
    
    class MessageUtilitiesService:
        def __init__(self):
            logger.warning("MessageUtilitiesService not available - using fallback")
    
    def get_conversation_memory_manager():
        logger.warning("get_conversation_memory_manager not available - using fallback")
        return None
    
    def get_memory_optimization_service():
        logger.warning("get_memory_optimization_service not available - using fallback")
        return None
    
    __all__ = [
        "ConversationMemoryManager",
        "MemoryOptimizationService",
        "get_conversation_memory_manager", 
        "get_memory_optimization_service",
        "MessageService",
        "MessageAnalyticsService",
        "MessageSecurityService",
        "MessageUtilitiesService"
    ]


def get_service(service_name: str):
    """
    Get a service instance by name.
    
    Args:
        service_name: Name of the service to retrieve
        
    Returns:
        Service instance or None if not found
    """
    services = {
        'conversation_memory': get_conversation_memory_manager(),
        'memory_optimization': get_memory_optimization_service(),
        'message': MessageService(),
        'message_analytics': MessageAnalyticsService(),
        'message_security': MessageSecurityService(),
        'message_utilities': MessageUtilitiesService()
    }
    
    return services.get(service_name.lower())


def get_all_services():
    """
    Get all available service instances.
    
    Returns:
        Dictionary of service instances
    """
    return {
        'conversation_memory': get_conversation_memory_manager(),
        'memory_optimization': get_memory_optimization_service(),
        'message': MessageService(),
        'message_analytics': MessageAnalyticsService(),
        'message_security': MessageSecurityService(),
        'message_utilities': MessageUtilitiesService()
    }


def get_message_service() -> MessageService:
    """
    Get message service instance.
    
    Returns:
        MessageService instance
    """
    return MessageService()


def get_message_analytics_service() -> MessageAnalyticsService:
    """
    Get message analytics service instance.
    
    Returns:
        MessageAnalyticsService instance
    """
    return MessageAnalyticsService()


def get_message_security_service() -> MessageSecurityService:
    """
    Get message security service instance.
    
    Returns:
        MessageSecurityService instance
    """
    return MessageSecurityService()


def get_message_utilities_service() -> MessageUtilitiesService:
    """
    Get message utilities service instance.
    
    Returns:
        MessageUtilitiesService instance
    """
    return MessageUtilitiesService()


# Add to __all__
__all__.extend([
    "get_message_service",
    "get_message_analytics_service", 
    "get_message_security_service",
    "get_message_utilities_service"
])
