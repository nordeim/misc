"""
Memory Management Service for advanced conversation context management.

Provides high-level memory operations for application integration including:
- Conversation memory patterns
- Context-aware memory storage
- Automatic memory optimization
- Memory lifecycle management
- Performance monitoring and analytics

Author: Customer Support AI Agent
Version: 2.0.0
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass

from app.tools.memory_tool import (
    MemoryTool, MemoryType, MemoryQuery, MemoryAnalytics, 
    MemorySearchResult, ImportanceLevel
)

logger = logging.getLogger(__name__)


@dataclass
class ConversationContext:
    """Conversation context data structure."""
    session_id: str
    user_id: str
    current_topic: Optional[str] = None
    conversation_length: int = 0
    important_facts: List[str] = None
    user_preferences: Dict[str, Any] = None
    conversation_summary: Optional[str] = None
    context_relevance_threshold: float = 0.5


@dataclass
class MemoryPattern:
    """Detected memory usage pattern."""
    pattern_type: str
    frequency: int
    importance: float
    recommendations: List[str]


class ConversationMemoryManager:
    """Manages conversation-specific memory operations."""
    
    def __init__(self, memory_tool: MemoryTool):
        self.memory_tool = memory_tool
        self.default_context_length = 10
        self.importance_threshold = 0.6
        
        # Memory type mappings
        self.conversation_memory_types = [
            MemoryType.CONVERSATION.value,
            MemoryType.CONTEXT.value,
            MemoryType.USER_INFO.value
        ]
        
        logger.info("ConversationMemoryManager initialized")
    
    async def store_conversation_turn(
        self,
        session_id: str,
        turn_number: int,
        user_message: str,
        assistant_response: str,
        importance_score: Optional[float] = None,
        context_tags: Optional[List[str]] = None
    ) -> Tuple[str, str]:
        """
        Store a conversation turn as separate user and assistant memories.
        
        Args:
            session_id: Session identifier
            turn_number: Turn number in conversation
            user_message: User's message
            assistant_response: Assistant's response
            importance_score: Optional importance score
            context_tags: Optional context tags
            
        Returns:
            Tuple of (user_memory_id, assistant_memory_id)
        """
        timestamp = datetime.utcnow()
        
        # Calculate importance based on message characteristics
        if importance_score is None:
            importance_score = self._calculate_turn_importance(user_message, assistant_response)
        
        # Determine memory type based on content
        memory_type = self._determine_memory_type(user_message, assistant_response)
        
        # Store user message
        user_key = f"turn_{turn_number}_user"
        user_metadata = {
            "turn_number": turn_number,
            "role": "user",
            "timestamp": timestamp.isoformat(),
            "length": len(user_message),
            "has_questions": "?" in user_message,
            "has_requests": any(word in user_message.lower() for word in ["please", "can you", "help", "need"])
        }
        
        user_memory_id = await self.memory_tool.store_memory(
            session_id=session_id,
            key=user_key,
            value=user_message,
            memory_type=memory_type,
            importance_score=importance_score,
            metadata=user_metadata,
            tags=context_tags,
            ttl_days=30
        )
        
        # Store assistant response
        assistant_key = f"turn_{turn_number}_assistant"
        assistant_metadata = {
            "turn_number": turn_number,
            "role": "assistant",
            "timestamp": timestamp.isoformat(),
            "length": len(assistant_response),
            "response_type": self._classify_response_type(assistant_response)
        }
        
        assistant_memory_id = await self.memory_tool.store_memory(
            session_id=session_id,
            key=assistant_key,
            value=assistant_response,
            memory_type=memory_type,
            importance_score=importance_score * 0.9,  # Slightly lower importance
            metadata=assistant_metadata,
            tags=context_tags,
            ttl_days=30
        )
        
        logger.debug(f"Stored conversation turn {turn_number} for session {session_id}")
        return user_memory_id, assistant_memory_id
    
    async def get_conversation_context(
        self,
        session_id: str,
        recent_turns: int = 5,
        include_summaries: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Get conversation context with recent turns and summaries.
        
        Args:
            session_id: Session identifier
            recent_turns: Number of recent turns to include
            include_summaries: Whether to include conversation summaries
            
        Returns:
            List of context memories
        """
        context = []
        
        # Get recent conversation memories
        recent_context = await self.memory_tool.get_context(
            session_id=session_id,
            memory_types=self.conversation_memory_types,
            limit=recent_turns * 2,  # User + assistant memories
            min_importance=0.3
        )
        
        # Add recent memories
        context.extend(recent_context)
        
        # Add summaries if requested
        if include_summaries:
            summary_context = await self.memory_tool.get_context(
                session_id=session_id,
                memory_types=[MemoryType.SUMMARY.value],
                limit=3,
                min_importance=0.5
            )
            context.extend(summary_context)
        
        # Sort by timestamp for chronological order
        context.sort(key=lambda x: x.get('created_at', ''))
        
        return context[-recent_turns * 2:]  # Return only the most recent items
    
    async def generate_conversation_summary(
        self,
        session_id: str,
        summary_length: int = 200
    ) -> str:
        """
        Generate a summary of the conversation.
        
        Args:
            session_id: Session identifier
            summary_length: Target length for summary
            
        Returns:
            Generated summary text
        """
        # Get all conversation memories
        all_memories = await self.memory_tool.get_context(
            session_id=session_id,
            memory_types=self.conversation_memory_types,
            limit=100,
            min_importance=0.4
        )
        
        if not all_memories:
            return "No conversation history available."
        
        # Sort by importance and recency
        important_memories = sorted(
            all_memories,
            key=lambda x: (x['importance_score'], x['created_at']),
            reverse=True
        )
        
        # Create summary from important memories
        summary_parts = []
        for memory in important_memories[:5]:  # Top 5 important memories
            summary_parts.append(f"- {memory['value'][:100]}...")
        
        summary = f"Conversation summary: {len(all_memories)} interactions. " + " | ".join(summary_parts)
        
        # Store the summary
        summary_key = f"conversation_summary_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        await self.memory_tool.store_memory(
            session_id=session_id,
            key=summary_key,
            value=summary,
            memory_type=MemoryType.SUMMARY.value,
            importance_score=0.7,
            metadata={
                "generated_at": datetime.utcnow().isoformat(),
                "based_on_memories": len(all_memories),
                "summary_length": len(summary)
            },
            ttl_days=7  # Summaries expire sooner
        )
        
        return summary
    
    async def track_user_preferences(
        self,
        session_id: str,
        user_message: str,
        extracted_preferences: Dict[str, Any]
    ) -> List[str]:
        """
        Extract and store user preferences from messages.
        
        Args:
            session_id: Session identifier
            user_message: User's message
            extracted_preferences: Dictionary of extracted preferences
            
        Returns:
            List of stored preference keys
        """
        stored_preferences = []
        
        for pref_key, pref_value in extracted_preferences.items():
            memory_key = f"user_preference_{pref_key}"
            
            # Store preference with high importance
            await self.memory_tool.store_memory(
                session_id=session_id,
                key=memory_key,
                value=str(pref_value),
                memory_type=MemoryType.USER_PREFERENCE.value,
                importance_score=0.8,
                metadata={
                    "preference_type": pref_key,
                    "extracted_from_message": user_message[:200],
                    "extraction_timestamp": datetime.utcnow().isoformat()
                },
                ttl_days=90  # Preferences last longer
            )
            
            stored_preferences.append(pref_key)
        
        logger.info(f"Stored {len(stored_preferences)} user preferences for session {session_id}")
        return stored_preferences
    
    async def identify_important_facts(
        self,
        session_id: str,
        messages: List[str]
    ) -> List[str]:
        """
        Identify important facts from conversation messages.
        
        Args:
            session_id: Session identifier
            messages: List of messages to analyze
            
        Returns:
            List of identified important facts
        """
        important_facts = []
        
        for i, message in enumerate(messages):
            # Simple fact extraction (can be enhanced with NLP)
            if self._is_fact_statement(message):
                fact_score = self._calculate_fact_importance(message)
                
                if fact_score > 0.6:
                    fact_key = f"important_fact_{i}_{datetime.utcnow().strftime('%H%M%S')}"
                    
                    await self.memory_tool.store_memory(
                        session_id=session_id,
                        key=fact_key,
                        value=message,
                        memory_type=MemoryType.FACT.value,
                        importance_score=fact_score,
                        metadata={
                            "extraction_method": "pattern_matching",
                            "fact_type": self._classify_fact_type(message),
                            "confidence": fact_score
                        },
                        ttl_days=60
                    )
                    
                    important_facts.append(message)
        
        logger.info(f"Identified and stored {len(important_facts)} important facts")
        return important_facts
    
    def _calculate_turn_importance(self, user_message: str, assistant_response: str) -> float:
        """Calculate importance score for a conversation turn."""
        importance = 0.5  # Base importance
        
        # Increase importance for questions
        if "?" in user_message:
            importance += 0.1
        
        # Increase importance for requests for help
        if any(word in user_message.lower() for word in ["help", "urgent", "problem", "issue", "error"]):
            importance += 0.2
        
        # Increase importance for long, detailed responses
        if len(assistant_response) > 200:
            importance += 0.1
        
        # Increase importance for specific requests
        if any(word in user_message.lower() for word in ["please", "need", "want", "request"]):
            importance += 0.1
        
        return min(1.0, importance)
    
    def _determine_memory_type(self, user_message: str, assistant_response: str) -> str:
        """Determine memory type based on message content."""
        message_lower = (user_message + " " + assistant_response).lower()
        
        if any(word in message_lower for word in ["preference", "like", "prefer", "favorite"]):
            return MemoryType.USER_PREFERENCE.value
        elif any(word in message_lower for word in ["fact", "information", "remember"]):
            return MemoryType.FACT.value
        else:
            return MemoryType.CONVERSATION.value
    
    def _classify_response_type(self, response: str) -> str:
        """Classify the type of assistant response."""
        response_lower = response.lower()
        
        if any(word in response_lower for word in ["help", "assist", "support"]):
            return "assistance"
        elif any(word in response_lower for word in ["answer", "respond", "reply"]):
            return "response"
        elif any(word in response_lower for word in ["explain", "describe", "tell"]):
            return "explanation"
        else:
            return "general"
    
    def _is_fact_statement(self, message: str) -> bool:
        """Check if a message contains a fact statement."""
        message_lower = message.lower()
        
        # Look for fact indicators
        fact_indicators = [
            "i am", "i'm", "my", "i have", "i've", "i need", "i want",
            "i prefer", "i like", "i don't like", "i hate",
            "my preference", "my favorite", "my favorite is"
        ]
        
        return any(indicator in message_lower for indicator in fact_indicators)
    
    def _calculate_fact_importance(self, fact: str) -> float:
        """Calculate importance score for a fact."""
        importance = 0.6  # Base importance for facts
        
        fact_lower = fact.lower()
        
        # Higher importance for personal information
        if any(word in fact_lower for word in ["name", "email", "phone", "address", "birthday"]):
            importance += 0.3
        
        # Higher importance for preferences
        if any(word in fact_lower for word in ["prefer", "favorite", "like", "dislike"]):
            importance += 0.2
        
        # Higher importance for specific information
        if any(char.isdigit() for char in fact) or len(fact) > 50:
            importance += 0.1
        
        return min(1.0, importance)
    
    def _classify_fact_type(self, fact: str) -> str:
        """Classify the type of fact."""
        fact_lower = fact.lower()
        
        if any(word in fact_lower for word in ["name", "email", "phone", "address"]):
            return "personal_info"
        elif any(word in fact_lower for word in ["prefer", "like", "favorite", "dislike"]):
            return "preference"
        elif any(word in fact_lower for word in ["need", "require", "want"]):
            return "requirement"
        else:
            return "general_fact"


class MemoryOptimizationService:
    """Service for optimizing memory usage and performance."""
    
    def __init__(self, memory_tool: MemoryTool):
        self.memory_tool = memory_tool
        self.optimization_threshold = 100  # Number of memories before optimization
        self.cleanup_interval_hours = 24
        
        logger.info("MemoryOptimizationService initialized")
    
    async def optimize_session_memories(
        self,
        session_id: str,
        force: bool = False
    ) -> Dict[str, int]:
        """
        Optimize memories for a session.
        
        Args:
            session_id: Session identifier
            force: Force optimization regardless of thresholds
            
        Returns:
            Dictionary with optimization results
        """
        # Check if optimization is needed
        if not force:
            analytics = await self.memory_tool.get_memory_analytics(session_id, days=7)
            if analytics.total_memories < self.optimization_threshold:
                return {"status": "skipped", "reason": "below_threshold"}
        
        results = {
            "expired_cleaned": 0,
            "compressed": 0,
            "summaries_created": 0,
            "total_optimized": 0
        }
        
        try:
            # Clean up expired memories
            expired_count = await self.memory_tool.cleanup_expired_memories(session_id)
            results["expired_cleaned"] = expired_count
            
            # Compress old, low-importance memories
            compressed_count = await self.memory_tool.compress_old_memories(
                session_id, older_than_days=7, min_importance=0.3
            )
            results["compressed"] = compressed_count
            
            # Generate summary if conversation is long enough
            recent_memories = await self.memory_tool.get_recent_memories(session_id, hours=24)
            if len(recent_memories) > 20:
                summary = await self._create_optimized_summary(session_id, recent_memories)
                results["summaries_created"] = 1 if summary else 0
            
            results["total_optimized"] = sum(results.values())
            
            logger.info(f"Optimized {results['total_optimized']} items for session {session_id}")
            return results
            
        except Exception as e:
            logger.error(f"Failed to optimize memories for session {session_id}: {e}")
            raise
    
    async def _create_optimized_summary(
        self,
        session_id: str,
        memories: List[Dict[str, Any]]
    ) -> Optional[str]:
        """Create an optimized summary of memories."""
        # Get the most important memories
        important_memories = sorted(
            memories,
            key=lambda x: x['importance_score'],
            reverse=True
        )[:10]
        
        # Create concise summary
        summary_parts = []
        for memory in important_memories:
            if memory['memory_type'] == MemoryType.USER_PREFERENCE.value:
                summary_parts.append(f"Pref: {memory['value'][:50]}...")
            elif memory['memory_type'] == MemoryType.FACT.value:
                summary_parts.append(f"Fact: {memory['value'][:50]}...")
            else:
                summary_parts.append(memory['value'][:30] + "...")
        
        summary = " | ".join(summary_parts[:5])  # Max 5 items
        
        summary_key = f"optimized_summary_{datetime.utcnow().strftime('%Y%m%d_%H%M')}"
        
        await self.memory_tool.store_memory(
            session_id=session_id,
            key=summary_key,
            value=summary,
            memory_type=MemoryType.SUMMARY.value,
            importance_score=0.8,
            metadata={
                "summary_type": "optimized",
                "based_on_memories": len(memories),
                "created_by": "optimization_service"
            },
            ttl_days=14
        )
        
        return summary
    
    async def analyze_memory_patterns(
        self,
        session_id: str
    ) -> List[MemoryPattern]:
        """Analyze memory usage patterns for a session."""
        analytics = await self.memory_tool.get_memory_analytics(session_id, days=30)
        
        patterns = []
        
        # High memory usage pattern
        if analytics.total_memories > 1000:
            patterns.append(MemoryPattern(
                pattern_type="high_usage",
                frequency=analytics.total_memories,
                importance=0.8,
                recommendations=[
                    "Consider enabling automatic memory compression",
                    "Increase TTL for important memories only",
                    "Create summaries to reduce memory count"
                ]
            ))
        
        # Low retention pattern
        if analytics.retention_stats['retention_rate'] < 60:
            patterns.append(MemoryPattern(
                pattern_type="low_retention",
                frequency=analytics.retention_stats['expired_memories'],
                importance=0.7,
                recommendations=[
                    "Review memory expiration settings",
                    "Mark more memories as persistent",
                    "Increase importance scores for key memories"
                ]
            ))
        
        # High importance memory concentration
        important_memories = sum(1 for count in analytics.importance_distribution.values() 
                               if 'critical' in str(count) or 'high' in str(count))
        if important_memories > analytics.total_memories * 0.3:
            patterns.append(MemoryPattern(
                pattern_type="high_importance_concentration",
                frequency=important_memories,
                importance=0.6,
                recommendations=[
                    "Review importance scoring criteria",
                    "Consider creating memory categories",
                    "Implement importance-based TTL"
                ]
            ))
        
        return patterns


# Global instance
def get_conversation_memory_manager() -> ConversationMemoryManager:
    """Get the global conversation memory manager instance."""
    from app.tools import memory_tool
    return ConversationMemoryManager(memory_tool)


def get_memory_optimization_service() -> MemoryOptimizationService:
    """Get the global memory optimization service instance."""
    from app.tools import memory_tool
    return MemoryOptimizationService(memory_tool)


__all__ = [
    "ConversationContext",
    "ConversationMemoryManager", 
    "MemoryOptimizationService",
    "MemoryPattern",
    "get_conversation_memory_manager",
    "get_memory_optimization_service"
]
