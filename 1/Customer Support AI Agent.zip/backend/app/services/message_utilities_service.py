"""
Message Utilities Service for preprocessing, validation, backup, and archival operations.
"""

import logging
import json
import csv
import gzip
import shutil
import uuid
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Iterator, Union, Tuple
from pathlib import Path
from io import StringIO, BytesIO
import asyncio
from concurrent.futures import ThreadPoolExecutor
import re

from sqlalchemy import select, func, desc, and_, or_, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.message import MessageORM
from app.models.session import SessionORM

logger = logging.getLogger(__name__)


class MessageUtilitiesService:
    """Comprehensive message utilities and operations service."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.backup_base_path = Path("./data/backups")
        self.backup_base_path.mkdir(parents=True, exist_ok=True)
        self.archive_base_path = Path("./data/archives")
        self.archive_base_path.mkdir(parents=True, exist_ok=True)
        self.executor = ThreadPoolExecutor(max_workers=4)
    
    # ============================================================================
    # MESSAGE PREPROCESSING
    # ============================================================================
    
    async def preprocess_messages(
        self,
        preprocess_config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Preprocess and clean messages using various techniques.
        
        Args:
            preprocess_config: Preprocessing configuration
            db: Database session
            
        Returns:
            Preprocessing results
        """
        try:
            config = preprocess_config
            results = {
                "preprocessing_id": str(uuid.uuid4()),
                "config_applied": config,
                "processing_summary": {},
                "processed_messages": [],
                "errors": [],
                "preprocessing_timestamp": datetime.utcnow().isoformat()
            }
            
            # Get messages to process
            messages = await self._get_messages_for_preprocessing(config, db)
            results["total_messages_found"] = len(messages)
            
            if not messages:
                results["errors"].append("No messages found matching criteria")
                return results
            
            # Apply preprocessing techniques
            for technique in config.get("techniques", []):
                technique_result = await self._apply_preprocessing_technique(
                    messages, technique, config, db
                )
                
                results["processing_summary"][technique] = technique_result
                
                # Update messages in database if configured
                if config.get("apply_to_database", False):
                    await self._apply_preprocessing_to_database(
                        technique, technique_result, db
                    )
            
            # Generate preprocessing statistics
            results["statistics"] = await self._generate_preprocessing_statistics(messages, config)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error in message preprocessing: {str(e)}")
            return {
                "error": str(e),
                "preprocessing_id": str(uuid.uuid4()),
                "preprocessing_timestamp": datetime.utcnow().isoformat()
            }
    
    async def _get_messages_for_preprocessing(
        self, 
        config: Dict[str, Any], 
        db: AsyncSession
    ) -> List[MessageORM]:
        """Get messages matching preprocessing criteria."""
        try:
            query = select(MessageORM)
            conditions = []
            
            # Apply filters based on config
            if config.get("session_ids"):
                query = query.where(MessageORM.session_id.in_(config["session_ids"]))
            
            if config.get("message_ids"):
                query = query.where(MessageORM.id.in_(config["message_ids"]))
            
            if config.get("date_from"):
                query = query.where(MessageORM.created_at >= config["date_from"])
            
            if config.get("date_to"):
                query = query.where(MessageORM.created_at <= config["date_to"])
            
            if config.get("roles"):
                query = query.where(MessageORM.role.in_(config["roles"]))
            
            # Apply limits
            limit = config.get("limit", 1000)
            query = query.limit(limit)
            
            result = await db.execute(query)
            return result.scalars().all()
            
        except Exception as e:
            self.logger.error(f"Error getting messages for preprocessing: {str(e)}")
            return []
    
    async def _apply_preprocessing_technique(
        self,
        messages: List[MessageORM],
        technique: str,
        config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Apply a specific preprocessing technique."""
        try:
            technique_handlers = {
                "clean_whitespace": self._clean_whitespace,
                "normalize_encoding": self._normalize_encoding,
                "remove_urls": self._remove_urls,
                "remove_special_chars": self._remove_special_characters,
                "split_long_messages": self._split_long_messages,
                "merge_short_messages": self._merge_short_messages,
                "detect_language": self._detect_language,
                "extract_keywords": self._extract_keywords,
                "summarize_content": self._summarize_content
            }
            
            handler = technique_handlers.get(technique)
            if not handler:
                return {"error": f"Unknown technique: {technique}"}
            
            return await handler(messages, config, db)
            
        except Exception as e:
            self.logger.error(f"Error applying preprocessing technique {technique}: {str(e)}")
            return {"error": str(e)}
    
    # ============================================================================
    # MESSAGE VALIDATION AND TESTING
    # ============================================================================
    
    async def validate_message_structure(
        self,
        message_data: Dict[str, Any],
        schema_config: Optional[Dict[str, Any]] = None,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """
        Validate message structure against schema.
        
        Args:
            message_data: Message data to validate
            schema_config: Optional schema configuration
            db: Database session
            
        Returns:
            Structure validation results
        """
        try:
            validation_result = {
                "is_valid": True,
                "validation_timestamp": datetime.utcnow().isoformat(),
                "schema_version": "1.0",
                "errors": [],
                "warnings": [],
                "field_analysis": {},
                "compliance_check": {}
            }
            
            # Basic structure validation
            required_fields = ["content", "role"]
            for field in required_fields:
                if field not in message_data:
                    validation_result["errors"].append(f"Missing required field: {field}")
                    validation_result["is_valid"] = False
            
            # Content validation
            content = message_data.get("content", "")
            if content:
                content_analysis = await self._validate_content_structure(content, message_data)
                validation_result["field_analysis"]["content"] = content_analysis
                
                if not content_analysis["valid"]:
                    validation_result["errors"].extend(content_analysis["errors"])
                    validation_result["is_valid"] = False
                
                validation_result["warnings"].extend(content_analysis["warnings"])
            
            # Role validation
            role = message_data.get("role")
            valid_roles = ["user", "assistant", "system"]
            if role and role not in valid_roles:
                validation_result["errors"].append(f"Invalid role: {role}. Must be one of {valid_roles}")
                validation_result["is_valid"] = False
            
            # Metadata validation
            if "metadata" in message_data:
                metadata_analysis = await self._validate_metadata_structure(message_data["metadata"])
                validation_result["field_analysis"]["metadata"] = metadata_analysis
                
                if not metadata_analysis["valid"]:
                    validation_result["errors"].extend(metadata_analysis["errors"])
                    validation_result["is_valid"] = False
            
            # Custom schema validation
            if schema_config:
                schema_result = await self._validate_against_custom_schema(message_data, schema_config)
                validation_result["compliance_check"] = schema_result
                
                if not schema_result["compliant"]:
                    validation_result["errors"].extend(schema_result["violations"])
                    validation_result["is_valid"] = False
            
            return validation_result
            
        except Exception as e:
            self.logger.error(f"Error validating message structure: {str(e)}")
            return {
                "is_valid": False,
                "error": str(e),
                "validation_timestamp": datetime.utcnow().isoformat()
            }
    
    # ============================================================================
    # BULK IMPORT/EXPORT OPERATIONS
    # ============================================================================
    
    async def import_csv_messages(
        self,
        csv_content: str,
        session_id: str,
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Import messages from CSV format.
        
        Args:
            csv_content: CSV content as string
            session_id: Target session ID
            db: Database session
            
        Returns:
            Import results
        """
        try:
            import_result = {
                "import_id": str(uuid.uuid4()),
                "session_id": session_id,
                "format": "csv",
                "import_timestamp": datetime.utcnow().isoformat(),
                "statistics": {},
                "errors": [],
                "warnings": []
            }
            
            # Parse CSV
            csv_reader = csv.DictReader(StringIO(csv_content))
            messages_to_import = []
            
            for row_num, row in enumerate(csv_reader, 1):
                try:
                    # Validate and prepare message data
                    message_data = {
                        "session_id": session_id,
                        "role": row.get("role", "user"),
                        "content": row.get("content", ""),
                        "content_type": row.get("content_type", "text"),
                        "sequence_number": await self._get_next_sequence_number(session_id, db)
                    }
                    
                    # Validate structure
                    validation_result = await self.validate_message_structure(message_data, db=db)
                    
                    if validation_result["is_valid"]:
                        messages_to_import.append(message_data)
                    else:
                        import_result["warnings"].append(f"Row {row_num}: Invalid structure - {validation_result['errors']}")
                
                except Exception as e:
                    import_result["errors"].append(f"Row {row_num}: {str(e)}")
            
            # Bulk insert messages
            if messages_to_import:
                await self._bulk_insert_messages(messages_to_import, db)
            
            import_result["statistics"] = {
                "total_rows": row_num,
                "valid_messages": len(messages_to_import),
                "invalid_rows": len(import_result["warnings"]),
                "errors": len(import_result["errors"])
            }
            
            return import_result
            
        except Exception as e:
            self.logger.error(f"Error importing CSV messages: {str(e)}")
            return {
                "error": str(e),
                "import_timestamp": datetime.utcnow().isoformat()
            }
    
    async def import_json_messages(
        self,
        json_data: Dict[str, Any],
        session_id: str,
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Import messages from JSON format.
        
        Args:
            json_data: JSON data structure
            session_id: Target session ID
            db: Database session
            
        Returns:
            Import results
        """
        try:
            import_result = {
                "import_id": str(uuid.uuid4()),
                "session_id": session_id,
                "format": "json",
                "import_timestamp": datetime.utcnow().isoformat(),
                "statistics": {},
                "errors": [],
                "warnings": []
            }
            
            # Handle different JSON structures
            messages_data = []
            if isinstance(json_data, list):
                messages_data = json_data
            elif isinstance(json_data, dict) and "messages" in json_data:
                messages_data = json_data["messages"]
            else:
                import_result["errors"].append("Invalid JSON structure. Expected array or object with 'messages' key.")
                return import_result
            
            # Process messages
            valid_messages = 0
            for idx, message_data in enumerate(messages_data, 1):
                try:
                    # Add session ID and sequence number
                    message_data["session_id"] = session_id
                    message_data["sequence_number"] = await self._get_next_sequence_number(session_id, db)
                    
                    # Validate structure
                    validation_result = await self.validate_message_structure(message_data, db=db)
                    
                    if validation_result["is_valid"]:
                        valid_messages += 1
                    else:
                        import_result["warnings"].append(f"Message {idx}: Invalid structure - {validation_result['errors']}")
                
                except Exception as e:
                    import_result["errors"].append(f"Message {idx}: {str(e)}")
            
            import_result["statistics"] = {
                "total_messages": len(messages_data),
                "valid_messages": valid_messages,
                "invalid_messages": len(import_result["warnings"]),
                "errors": len(import_result["errors"])
            }
            
            return import_result
            
        except Exception as e:
            self.logger.error(f"Error importing JSON messages: {str(e)}")
            return {
                "error": str(e),
                "import_timestamp": datetime.utcnow().isoformat()
            }
    
    async def create_export_job(
        self,
        export_config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Create export job for messages.
        
        Args:
            export_config: Export configuration
            db: Database session
            
        Returns:
            Export job information
        """
        try:
            job_id = str(uuid.uuid4())
            
            # Calculate estimated completion time
            estimated_duration = await self._estimate_export_duration(export_config, db)
            estimated_completion = datetime.utcnow() + timedelta(seconds=estimated_duration)
            
            export_job = {
                "job_id": job_id,
                "status": "created",
                "export_config": export_config,
                "created_at": datetime.utcnow(),
                "estimated_completion": estimated_completion.isoformat(),
                "progress": 0,
                "output_file": None,
                "statistics": {}
            }
            
            # Store job information (in real implementation, this would go to a job queue or database)
            logger.info(f"Created export job {job_id} with config: {export_config}")
            
            return export_job
            
        except Exception as e:
            self.logger.error(f"Error creating export job: {str(e)}")
            raise
    
    async def process_export_job(
        self,
        job_id: str,
        export_config: Dict[str, Any],
        db: AsyncSession
    ):
        """Process export job in background."""
        try:
            logger.info(f"Starting export job {job_id}")
            
            # Get messages to export
            messages = await self._get_messages_for_export(export_config, db)
            total_messages = len(messages)
            
            if total_messages == 0:
                logger.warning(f"No messages found for export job {job_id}")
                return
            
            # Generate export file
            export_format = export_config.get("format", "json")
            output_path = self.backup_base_path / f"export_{job_id}.{export_format}"
            
            if export_format == "json":
                await self._export_to_json(messages, output_path, export_config)
            elif export_format == "csv":
                await self._export_to_csv(messages, output_path, export_config)
            elif export_format == "xml":
                await self._export_to_xml(messages, output_path, export_config)
            
            # Update job status
            logger.info(f"Export job {job_id} completed successfully")
            
        except Exception as e:
            logger.error(f"Error processing export job {job_id}: {str(e)}")
    
    # ============================================================================
    # BACKUP AND ARCHIVAL
    # ============================================================================
    
    async def create_backup_job(
        self,
        backup_config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Create backup job for messages.
        
        Args:
            backup_config: Backup configuration
            db: Database session
            
        Returns:
            Backup job information
        """
        try:
            job_id = str(uuid.uuid4())
            
            # Calculate estimated completion time
            estimated_duration = await self._estimate_backup_duration(backup_config, db)
            estimated_completion = datetime.utcnow() + timedelta(seconds=estimated_duration)
            
            backup_job = {
                "job_id": job_id,
                "status": "created",
                "backup_config": backup_config,
                "created_at": datetime.utcnow(),
                "estimated_completion": estimated_completion.isoformat(),
                "progress": 0,
                "backup_file": None,
                "statistics": {}
            }
            
            logger.info(f"Created backup job {job_id} with config: {backup_config}")
            
            return backup_job
            
        except Exception as e:
            self.logger.error(f"Error creating backup job: {str(e)}")
            raise
    
    async def process_backup_job(
        self,
        job_id: str,
        backup_config: Dict[str, Any],
        db: AsyncSession
    ):
        """Process backup job in background."""
        try:
            logger.info(f"Starting backup job {job_id}")
            
            # Get messages to backup
            messages = await self._get_messages_for_backup(backup_config, db)
            total_messages = len(messages)
            
            if total_messages == 0:
                logger.warning(f"No messages found for backup job {job_id}")
                return
            
            # Create compressed backup
            backup_path = self.backup_base_path / f"backup_{job_id}.json.gz"
            
            with gzip.open(backup_path, 'wt', encoding='utf-8') as f:
                json.dump({
                    "backup_id": job_id,
                    "created_at": datetime.utcnow().isoformat(),
                    "config": backup_config,
                    "total_messages": total_messages,
                    "messages": [msg.dict() for msg in messages]
                }, f, indent=2)
            
            # Calculate and store backup statistics
            backup_size = backup_path.stat().st_size
            logger.info(f"Backup job {job_id} completed: {total_messages} messages, {backup_size} bytes")
            
        except Exception as e:
            logger.error(f"Error processing backup job {job_id}: {str(e)}")
    
    async def create_archive_job(
        self,
        archive_config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """
        Create archive job for old messages.
        
        Args:
            archive_config: Archive configuration
            db: Database session
            
        Returns:
            Archive job information
        """
        try:
            job_id = str(uuid.uuid4())
            
            # Get count of messages to archive for estimation
            messages_to_archive = await self._get_messages_for_archiving_count(archive_config, db)
            
            # Estimate duration (assume ~1000 messages per second)
            estimated_duration = max(1, messages_to_archive / 1000)
            estimated_completion = datetime.utcnow() + timedelta(seconds=estimated_duration)
            
            archive_job = {
                "job_id": job_id,
                "status": "created",
                "archive_config": archive_config,
                "created_at": datetime.utcnow(),
                "estimated_completion": estimated_completion.isoformat(),
                "estimated_messages": messages_to_archive,
                "progress": 0,
                "statistics": {}
            }
            
            logger.info(f"Created archive job {job_id} for approximately {messages_to_archive} messages")
            
            return archive_job
            
        except Exception as e:
            self.logger.error(f"Error creating archive job: {str(e)}")
            raise
    
    async def process_archive_job(
        self,
        job_id: str,
        archive_config: Dict[str, Any],
        db: AsyncSession
    ):
        """Process archive job in background."""
        try:
            logger.info(f"Starting archive job {job_id}")
            
            # Archive messages based on retention policy
            retention_days = archive_config.get("retention_days", 365)
            archive_threshold = datetime.utcnow() - timedelta(days=retention_days)
            
            # Move old messages to archived status
            archived_count = await self._archive_old_messages(archive_threshold, db)
            
            logger.info(f"Archive job {job_id} completed: {archived_count} messages archived")
            
        except Exception as e:
            logger.error(f"Error processing archive job {job_id}: {str(e)}")
    
    # ============================================================================
    # STATUS AND PROGRESS TRACKING
    # ============================================================================
    
    async def get_export_status(
        self,
        export_job_id: str,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get export job status."""
        try:
            # In real implementation, this would query a job status database
            # For now, return placeholder status
            return {
                "job_id": export_job_id,
                "status": "completed",
                "progress": 100,
                "output_file": f"/data/backups/export_{export_job_id}.json",
                "completed_at": datetime.utcnow().isoformat(),
                "message": "Export completed successfully"
            }
            
        except Exception as e:
            self.logger.error(f"Error getting export status: {str(e)}")
            return {
                "job_id": export_job_id,
                "status": "error",
                "error": str(e)
            }
    
    async def get_export_file(
        self,
        export_job_id: str,
        db: AsyncSession = None
    ) -> Tuple[Optional[Path], Optional[str]]:
        """Get export file path and filename."""
        try:
            export_file = self.backup_base_path / f"export_{export_job_id}.json"
            
            if export_file.exists():
                return export_file, export_file.name
            else:
                return None, None
                
        except Exception as e:
            self.logger.error(f"Error getting export file: {str(e)}")
            return None, None
    
    async def get_backup_status(
        self,
        backup_job_id: str,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get backup job status."""
        try:
            backup_file = self.backup_base_path / f"backup_{backup_job_id}.json.gz"
            
            if backup_file.exists():
                file_size = backup_file.stat().st_size
                return {
                    "job_id": backup_job_id,
                    "status": "completed",
                    "backup_file": str(backup_file),
                    "file_size": file_size,
                    "completed_at": datetime.utcnow().isoformat(),
                    "message": "Backup completed successfully"
                }
            else:
                return {
                    "job_id": backup_job_id,
                    "status": "not_found",
                    "message": "Backup file not found"
                }
                
        except Exception as e:
            self.logger.error(f"Error getting backup status: {str(e)}")
            return {
                "job_id": backup_job_id,
                "status": "error",
                "error": str(e)
            }
    
    # ============================================================================
    # PRIVATE HELPER METHODS
    # ============================================================================
    
    async def _get_next_sequence_number(self, session_id: str, db: AsyncSession) -> int:
        """Get next sequence number for a session."""
        try:
            result = await db.execute(
                select(func.max(MessageORM.sequence_number))
                .where(MessageORM.session_id == session_id)
            )
            max_sequence = result.scalar() or 0
            return max_sequence + 1
        except Exception:
            return 1
    
    async def _bulk_insert_messages(self, messages_data: List[Dict[str, Any]], db: AsyncSession):
        """Bulk insert messages into database."""
        try:
            for message_data in messages_data:
                message = MessageORM(**message_data)
                db.add(message)
            
            await db.flush()
            
        except Exception as e:
            self.logger.error(f"Error bulk inserting messages: {str(e)}")
            raise
    
    async def _estimate_export_duration(self, config: Dict[str, Any], db: AsyncSession) -> int:
        """Estimate export job duration in seconds."""
        try:
            # Get message count for estimation
            query = select(func.count(MessageORM.id))
            
            if config.get("session_ids"):
                query = query.where(MessageORM.session_id.in_(config["session_ids"]))
            
            if config.get("date_from"):
                query = query.where(MessageORM.created_at >= config["date_from"])
            
            if config.get("date_to"):
                query = query.where(MessageORM.created_at <= config["date_to"])
            
            result = await db.execute(query)
            message_count = result.scalar() or 0
            
            # Estimate based on message count (assume ~100 messages per second)
            estimated_seconds = max(1, message_count / 100)
            return int(estimated_seconds)
            
        except Exception:
            return 60  # Default 1 minute estimate
    
    async def _estimate_backup_duration(self, config: Dict[str, Any], db: AsyncSession) -> int:
        """Estimate backup job duration in seconds."""
        # Similar to export estimation
        return await self._estimate_export_duration(config, db)
    
    async def _get_messages_for_export(self, config: Dict[str, Any], db: AsyncSession) -> List[MessageORM]:
        """Get messages for export."""
        query = select(MessageORM)
        
        # Apply filters
        if config.get("session_ids"):
            query = query.where(MessageORM.session_id.in_(config["session_ids"]))
        
        if config.get("date_from"):
            query = query.where(MessageORM.created_at >= config["date_from"])
        
        if config.get("date_to"):
            query = query.where(MessageORM.created_at <= config["date_to"])
        
        # Apply limits
        limit = config.get("limit", 10000)
        query = query.limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    async def _get_messages_for_backup(self, config: Dict[str, Any], db: AsyncSession) -> List[MessageORM]:
        """Get messages for backup."""
        return await self._get_messages_for_export(config, db)
    
    async def _get_messages_for_archiving_count(self, config: Dict[str, Any], db: AsyncSession) -> int:
        """Get count of messages to archive."""
        retention_days = config.get("retention_days", 365)
        archive_threshold = datetime.utcnow() - timedelta(days=retention_days)
        
        query = select(func.count(MessageORM.id)).where(MessageORM.created_at < archive_threshold)
        
        result = await db.execute(query)
        return result.scalar() or 0
    
    async def _archive_old_messages(self, archive_threshold: datetime, db: AsyncSession) -> int:
        """Archive messages older than threshold."""
        try:
            # Update messages to archived status
            result = await db.execute(
                select(MessageORM).where(MessageORM.created_at < archive_threshold)
            )
            messages = result.scalars().all()
            
            for message in messages:
                if message.metadata is None:
                    message.metadata = {}
                message.metadata["archived"] = True
                message.metadata["archived_at"] = datetime.utcnow().isoformat()
            
            await db.flush()
            
            return len(messages)
            
        except Exception as e:
            self.logger.error(f"Error archiving old messages: {str(e)}")
            return 0
    
    # Placeholder methods for complex operations
    async def _apply_preprocessing_to_database(self, technique: str, result: Dict[str, Any], db: AsyncSession):
        """Apply preprocessing results to database."""
        pass
    
    async def _generate_preprocessing_statistics(self, messages: List[MessageORM], config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate preprocessing statistics."""
        return {"total_messages": len(messages), "techniques_applied": len(config.get("techniques", []))}
    
    async def _validate_content_structure(self, content: str, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate content structure."""
        return {"valid": True, "errors": [], "warnings": []}
    
    async def _validate_metadata_structure(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Validate metadata structure."""
        return {"valid": True, "errors": []}
    
    async def _validate_against_custom_schema(self, message_data: Dict[str, Any], schema_config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate against custom schema."""
        return {"compliant": True, "violations": []}
    
    async def _export_to_json(self, messages: List[MessageORM], output_path: Path, config: Dict[str, Any]):
        """Export messages to JSON format."""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                "export_id": str(uuid.uuid4()),
                "exported_at": datetime.utcnow().isoformat(),
                "config": config,
                "total_messages": len(messages),
                "messages": [msg.dict() for msg in messages]
            }, f, indent=2, default=str)
    
    async def _export_to_csv(self, messages: List[MessageORM], output_path: Path, config: Dict[str, Any]):
        """Export messages to CSV format."""
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            if messages:
                fieldnames = messages[0].dict().keys()
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for message in messages:
                    writer.writerow(message.dict(default=str))
    
    async def _export_to_xml(self, messages: List[MessageORM], output_path: Path, config: Dict[str, Any]):
        """Export messages to XML format."""
        import xml.etree.ElementTree as ET
        
        root = ET.Element("messages")
        root.set("export_id", str(uuid.uuid4()))
        root.set("exported_at", datetime.utcnow().isoformat())
        
        for message in messages:
            msg_elem = ET.SubElement(root, "message")
            for key, value in message.dict(default=str).items():
                elem = ET.SubElement(msg_elem, key)
                elem.text = str(value)
        
        tree = ET.ElementTree(root)
        tree.write(output_path, encoding='utf-8', xml_declaration=True)
    
    # Preprocessing technique handlers
    async def _clean_whitespace(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Clean whitespace from messages."""
        return {"messages_processed": len(messages), "changes_made": []}
    
    async def _normalize_encoding(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Normalize encoding of messages."""
        return {"messages_processed": len(messages), "encoding_issues": 0}
    
    async def _remove_urls(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Remove URLs from messages."""
        return {"messages_processed": len(messages), "urls_removed": 0}
    
    async def _remove_special_characters(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Remove special characters from messages."""
        return {"messages_processed": len(messages), "chars_removed": 0}
    
    async def _split_long_messages(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Split long messages."""
        return {"messages_processed": len(messages), "messages_split": 0}
    
    async def _merge_short_messages(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Merge short messages."""
        return {"messages_processed": len(messages), "messages_merged": 0}
    
    async def _detect_language(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Detect message language."""
        return {"messages_processed": len(messages), "languages_detected": {}}
    
    async def _extract_keywords(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Extract keywords from messages."""
        return {"messages_processed": len(messages), "keywords_extracted": []}
    
    async def _summarize_content(self, messages: List[MessageORM], config: Dict[str, Any], db: AsyncSession) -> Dict[str, Any]:
        """Summarize message content."""
        return {"messages_processed": len(messages), "summaries_created": 0}