"""
Compatibility layer for HuggingFace Hub imports.

This module provides backward compatibility for sentence-transformers
when using newer versions of huggingface_hub where cached_download
has been deprecated in favor of hf_hub_download.
"""

import warnings
from typing import Any, Dict, Optional, Union

try:
    # Try to import the new function
    from huggingface_hub import hf_hub_download
    CACHED_DOWNLOAD_AVAILABLE = True
except ImportError:
    CACHED_DOWNLOAD_AVAILABLE = False

try:
    # Legacy import
    from huggingface_hub import cached_download
    LEGACY_CACHED_DOWNLOAD = True
except ImportError:
    LEGACY_CACHED_DOWNLOAD = False

if not LEGACY_CACHED_DOWNLOAD and CACHED_DOWNLOAD_AVAILABLE:
    # Create a compatibility wrapper
    def cached_download(*args, **kwargs):
        """
        Compatibility wrapper for cached_download function.
        
        This function provides backward compatibility by wrapping
        the new hf_hub_download function with the old cached_download
        API signature.
        """
        warnings.warn(
            "cached_download is deprecated. Use hf_hub_download instead.",
            DeprecationWarning,
            stacklevel=2
        )
        
        # Map old parameters to new ones
        if 'url' in kwargs:
            kwargs['repo_url'] = kwargs.pop('url')
        if 'cache_dir' in kwargs:
            kwargs['local_dir'] = kwargs.pop('cache_dir')
        
        return hf_hub_download(*args, **kwargs)

# Export the function for use by sentence-transformers
__all__ = ['cached_download']