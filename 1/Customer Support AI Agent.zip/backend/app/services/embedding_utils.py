"""
Embedding Utilities and Analytics Module.

This module provides comprehensive utilities for:
- Text preprocessing and optimization for embeddings
- Embedding similarity calculations and comparisons
- Embedding validation and quality assessment
- Embedding analytics and insights generation
- Performance monitoring and benchmarking
- Distance metrics and clustering utilities

Features:
- Multiple text preprocessing strategies
- Various similarity and distance metrics
- Embedding quality validation
- Performance benchmarking
- Analytics and visualization utilities
- Export and import capabilities

Author: AI Agent System
Version: 2.0.0
"""

import asyncio
import json
import logging
import math
import statistics
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Set
from datetime import datetime, timedelta
import warnings

import numpy as np
from sklearn.metrics import pairwise_distances
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import spatial, stats
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import dendrogram, linkage
import pandas as pd

logger = logging.getLogger(__name__)

# ==============================================================================
# DATA STRUCTURES
# ==============================================================================

@dataclass
class TextStats:
    """Statistics about text preprocessing."""
    original_length: int
    processed_length: int
    word_count: int
    sentence_count: int
    character_reduction: float
    preprocessing_steps: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

@dataclass
class SimilarityResult:
    """Result of similarity calculation."""
    id1: str
    id2: str
    similarity_score: float
    distance_score: float
    metric_used: str
    additional_info: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        return data

@dataclass
class ValidationReport:
    """Comprehensive validation report for embeddings."""
    valid: bool
    issues: List[str]
    warnings: List[str]
    quality_score: float
    statistics: Dict[str, Any]
    recommendations: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

@dataclass
class AnalyticsReport:
    """Comprehensive analytics report."""
    summary: Dict[str, Any]
    quality_metrics: Dict[str, Any]
    distribution_analysis: Dict[str, Any]
    clustering_analysis: Dict[str, Any]
    outlier_detection: Dict[str, Any]
    performance_metrics: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

# ==============================================================================
# TEXT PREPROCESSING UTILITIES
# ==============================================================================

class TextPreprocessingUtils:
    """Advanced text preprocessing utilities for embeddings."""
    
    def __init__(self):
        self.stopwords = self._load_stopwords()
        self.special_patterns = self._compile_patterns()
    
    def _load_stopwords(self) -> Set[str]:
        """Load common stopwords."""
        # Basic English stopwords - in production, use NLTK or spaCy
        return {
            'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
            'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
            'to', 'was', 'will', 'with', 'the', 'this', 'but', 'they', 'have',
            'had', 'what', 'said', 'each', 'which', 'their', 'time', 'if',
            'up', 'out', 'many', 'then', 'them', 'these', 'so', 'some', 'her'
        }
    
    def _compile_patterns(self) -> Dict[str, Any]:
        """Compile regex patterns for text cleaning."""
        import re
        
        return {
            'whitespace': re.compile(r'\s+'),
            'special_chars': re.compile(r'[^\w\s\.\!\?\;\:\,\-\(\)]'),
            'multiple_punctuation': re.compile(r'([\!\?\.])\1+'),
            'html_tags': re.compile(r'<[^>]+>'),
            'urls': re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'),
            'emails': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'extra_spaces': re.compile(r' +'),
            'line_breaks': re.compile(r'\n+'),
        }
    
    def clean_basic(self, text: str) -> Tuple[str, TextStats]:
        """Basic text cleaning."""
        original_length = len(text)
        steps = []
        
        # Remove HTML tags
        text = self.special_patterns['html_tags'].sub('', text)
        if len(text) < original_length:
            steps.append('removed_html')
        
        # Remove URLs
        text = self.special_patterns['urls'].sub('', text)
        if len(text) < original_length:
            steps.append('removed_urls')
        
        # Remove emails
        text = self.special_patterns['emails'].sub('', text)
        if len(text) < original_length:
            steps.append('removed_emails')
        
        # Normalize whitespace
        text = self.special_patterns['line_breaks'].sub(' ', text)
        text = self.special_patterns['extra_spaces'].sub(' ', text)
        steps.append('normalized_whitespace')
        
        # Remove special characters (keep basic punctuation)
        text = self.special_patterns['special_chars'].sub('', text)
        if len(text) < original_length:
            steps.append('removed_special_chars')
        
        processed_length = len(text)
        
        # Calculate word and sentence counts
        words = text.split()
        word_count = len(words)
        sentence_count = len([s for s in text.split('.') if s.strip()])
        
        stats = TextStats(
            original_length=original_length,
            processed_length=processed_length,
            word_count=word_count,
            sentence_count=sentence_count,
            character_reduction=(original_length - processed_length) / original_length,
            preprocessing_steps=steps
        )
        
        return text.strip(), stats
    
    def clean_advanced(self, text: str) -> Tuple[str, TextStats]:
        """Advanced text cleaning with more sophisticated processing."""
        original_length = len(text)
        steps = []
        
        # Start with basic cleaning
        text, basic_stats = self.clean_basic(text)
        
        # Remove excessive punctuation
        text = self.special_patterns['multiple_punctuation'].sub(r'\1', text)
        steps.append('normalized_punctuation')
        
        # Remove very short words (less than 2 characters)
        words = text.split()
        filtered_words = [word for word in words if len(word) >= 2 or word.lower() in {'a', 'i'}]
        if len(filtered_words) < len(words):
            text = ' '.join(filtered_words)
            steps.append('filtered_short_words')
        
        # Capitalize first letter of sentences
        sentences = text.split('.')
        sentences = [s.strip().capitalize() if s.strip() else s.strip() for s in sentences]
        text = '. '.join(sentences)
        
        processed_length = len(text)
        word_count = len(text.split())
        sentence_count = len([s for s in text.split('.') if s.strip()])
        
        advanced_stats = TextStats(
            original_length=original_length,
            processed_length=processed_length,
            word_count=word_count,
            sentence_count=sentence_count,
            character_reduction=(original_length - processed_length) / original_length,
            preprocessing_steps=basic_stats.preprocessing_steps + steps
        )
        
        return text, advanced_stats
    
    def optimize_for_embedding(self, text: str, max_length: int = 512) -> Tuple[str, Dict[str, Any]]:
        """Optimize text specifically for embedding models."""
        optimization_info = {}
        
        # Apply advanced cleaning
        cleaned_text, stats = self.clean_advanced(text)
        optimization_info['cleaning_stats'] = stats.to_dict()
        
        # Check length and truncate if necessary
        if len(cleaned_text) > max_length:
            # Try to truncate at sentence boundary
            sentences = cleaned_text.split('.')
            truncated = ""
            
            for sentence in sentences:
                if len(truncated + sentence + '.') <= max_length:
                    truncated += sentence + '.'
                else:
                    break
            
            if truncated:
                cleaned_text = truncated.strip()
            else:
                # Fallback to word boundary
                words = cleaned_text.split()
                truncated = ""
                for word in words:
                    if len(truncated + ' ' + word) <= max_length:
                        truncated += ' ' + word if truncated else word
                    else:
                        break
                cleaned_text = truncated
            
            optimization_info['truncated'] = True
            optimization_info['truncation_reason'] = 'length_limit'
        else:
            optimization_info['truncated'] = False
        
        optimization_info['final_length'] = len(cleaned_text)
        optimization_info['length_reduction'] = (len(text) - len(cleaned_text)) / len(text) if text else 0
        
        return cleaned_text, optimization_info
    
    def batch_preprocess(self, texts: List[str], method: str = 'basic', max_length: int = None) -> Tuple[List[str], List[Dict[str, Any]]]:
        """Preprocess a batch of texts."""
        if method not in ['basic', 'advanced']:
            raise ValueError(f"Unknown preprocessing method: {method}")
        
        processed_texts = []
        processing_reports = []
        
        for text in texts:
            if method == 'basic':
                processed_text, stats = self.clean_basic(text)
            else:
                processed_text, stats = self.clean_advanced(text)
            
            # Apply length optimization if specified
            if max_length:
                processed_text, optimization_info = self.optimize_for_embedding(processed_text, max_length)
                stats.preprocessing_steps.extend(['length_optimization'])
            
            processed_texts.append(processed_text)
            
            report = {
                'original_length': len(text),
                'processed_length': len(processed_text),
                'stats': stats.to_dict(),
                'optimization_info': optimization_info if max_length else {}
            }
            processing_reports.append(report)
        
        return processed_texts, processing_reports

# ==============================================================================
# SIMILARITY CALCULATION UTILITIES
# ==============================================================================

class SimilarityUtils:
    """Advanced similarity calculation utilities."""
    
    # Available distance metrics
    DISTANCE_METRICS = {
        'cosine': lambda x, y: 1 - cosine_similarity([x], [y])[0, 0],
        'euclidean': lambda x, y: euclidean_distances([x], [y])[0, 0],
        'manhattan': lambda x, y: np.sum(np.abs(np.array(x) - np.array(y))),
        'dot_product': lambda x, y: -np.dot(x, y),  # Negative because smaller is better for distance
        'pearson': lambda x, y: 1 - stats.pearsonr(x, y)[0] if stats.pearsonr(x, y)[0] is not None else 1,
        'spearman': lambda x, y: 1 - stats.spearmanr(x, y)[0] if stats.spearmanr(x, y)[0] is not None else 1,
    }
    
    @classmethod
    def calculate_pairwise_similarity(
        cls,
        embeddings1: List[List[float]],
        embeddings2: List[List[float]] = None,
        metric: str = 'cosine'
    ) -> np.ndarray:
        """Calculate pairwise similarities between embeddings."""
        if embeddings2 is None:
            embeddings2 = embeddings1
        
        if metric == 'cosine':
            similarity_matrix = cosine_similarity(embeddings1, embeddings2)
        elif metric == 'euclidean':
            # Convert distances to similarities (closer = more similar)
            distances = euclidean_distances(embeddings1, embeddings2)
            # Normalize and invert distances to get similarities
            max_distance = np.max(distances)
            similarity_matrix = 1 - (distances / max_distance)
        else:
            # Calculate custom metric for each pair
            similarity_matrix = np.zeros((len(embeddings1), len(embeddings2)))
            for i, emb1 in enumerate(embeddings1):
                for j, emb2 in enumerate(embeddings2):
                    similarity_matrix[i, j] = cls.DISTANCE_METRICS[metric](emb1, emb2)
        
        return similarity_matrix
    
    @classmethod
    def find_most_similar(
        cls,
        query_embedding: List[float],
        candidate_embeddings: List[Tuple[str, List[float]]],
        top_k: int = 5,
        metric: str = 'cosine',
        threshold: float = None
    ) -> List[SimilarityResult]:
        """Find most similar embeddings to a query."""
        if not candidate_embeddings:
            return []
        
        # Extract embeddings
        candidate_ids = [item[0] for item in candidate_embeddings]
        embeddings = [item[1] for item in candidate_embeddings]
        
        # Calculate similarities
        similarity_scores = cls.calculate_pairwise_similarity([query_embedding], embeddings, metric)[0]
        
        # Create results
        results = []
        for i, (candidate_id, score) in enumerate(zip(candidate_ids, similarity_scores)):
            if threshold is None or score >= threshold:
                distance_score = 1 - score if metric == 'cosine' else score
                result = SimilarityResult(
                    id1="query",
                    id2=candidate_id,
                    similarity_score=score,
                    distance_score=distance_score,
                    metric_used=metric,
                    additional_info={
                        "rank": i + 1,
                        "raw_score": score
                    }
                )
                results.append(result)
        
        # Sort by similarity score (descending)
        results.sort(key=lambda x: x.similarity_score, reverse=True)
        
        return results[:top_k]
    
    @classmethod
    def calculate_clustering_similarity(
        cls,
        embeddings: List[Tuple[str, List[float]]],
        n_clusters: int = 5,
        algorithm: str = 'kmeans',
        metric: str = 'cosine'
    ) -> Dict[str, Any]:
        """Calculate clustering and analyze similarity within clusters."""
        if len(embeddings) < n_clusters:
            n_clusters = max(1, len(embeddings))
        
        # Extract embedding vectors
        embedding_matrix = np.array([emb[1] for emb in embeddings])
        ids = [emb[0] for emb in embeddings]
        
        # Perform clustering
        if algorithm == 'kmeans':
            clusterer = KMeans(n_clusters=n_clusters, random_state=42)
            cluster_labels = clusterer.fit_predict(embedding_matrix)
        elif algorithm == 'dbscan':
            clusterer = DBSCAN(min_samples=2, metric='cosine' if metric == 'cosine' else 'euclidean')
            cluster_labels = clusterer.fit_predict(embedding_matrix)
        elif algorithm == 'agglomerative':
            clusterer = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward')
            cluster_labels = clusterer.fit_predict(embedding_matrix)
        else:
            raise ValueError(f"Unknown clustering algorithm: {algorithm}")
        
        # Analyze clusters
        cluster_analysis = {}
        cluster_similarities = []
        
        for cluster_id in np.unique(cluster_labels):
            cluster_mask = cluster_labels == cluster_id
            cluster_ids = [ids[i] for i in range(len(ids)) if cluster_mask[i]]
            cluster_embeddings = embedding_matrix[cluster_mask]
            
            # Calculate average similarity within cluster
            if len(cluster_embeddings) > 1:
                cluster_sims = cosine_similarity(cluster_embeddings)
                # Get upper triangle (excluding diagonal)
                upper_triangle = np.triu(cluster_sims, k=1)
                avg_similarity = np.mean(upper_triangle[upper_triangle > 0])
            else:
                avg_similarity = 1.0
            
            cluster_similarities.append(avg_similarity)
            
            cluster_analysis[f"cluster_{cluster_id}"] = {
                "size": len(cluster_ids),
                "ids": cluster_ids,
                "average_similarity": avg_similarity
            }
        
        # Calculate overall metrics
        silhouette_score = cls._calculate_silhouette_score(embedding_matrix, cluster_labels)
        
        return {
            "cluster_labels": cluster_labels.tolist(),
            "cluster_analysis": cluster_analysis,
            "average_cluster_similarity": np.mean(cluster_similarities),
            "silhouette_score": silhouette_score,
            "n_clusters": len(np.unique(cluster_labels)),
            "algorithm": algorithm
        }
    
    @classmethod
    def _calculate_silhouette_score(cls, embeddings: np.ndarray, labels: np.ndarray) -> float:
        """Calculate silhouette score for clustering quality."""
        try:
            from sklearn.metrics import silhouette_score
            return silhouette_score(embeddings, labels)
        except ImportError:
            logger.warning("sklearn.metrics.silhouette_score not available")
            return None
    
    @classmethod
    def calculate_distance_distribution(
        cls,
        embeddings: List[List[float]],
        sample_size: int = 1000,
        metric: str = 'cosine'
    ) -> Dict[str, Any]:
        """Calculate distribution of pairwise distances."""
        if len(embeddings) < 2:
            return {"error": "Need at least 2 embeddings"}
        
        # Sample pairs if too many
        n_embeddings = len(embeddings)
        max_pairs = min(sample_size, (n_embeddings * (n_embeddings - 1)) // 2)
        
        if n_embeddings > 100:  # Sample for large datasets
            # Random sampling of pairs
            distances = []
            for _ in range(max_pairs):
                i, j = np.random.choice(n_embeddings, 2, replace=False)
                if metric == 'cosine':
                    dist = 1 - cosine_similarity([embeddings[i]], [embeddings[j]])[0, 0]
                else:
                    dist = euclidean_distances([embeddings[i]], [embeddings[j]])[0, 0]
                distances.append(dist)
        else:
            # Calculate all pairs
            embedding_matrix = np.array(embeddings)
            if metric == 'cosine':
                similarity_matrix = cosine_similarity(embedding_matrix)
                # Get upper triangle (excluding diagonal)
                distances = 1 - np.triu(similarity_matrix, k=1)
                distances = distances[distances > 0]
            else:
                distance_matrix = euclidean_distances(embedding_matrix)
                distances = np.triu(distance_matrix, k=1)
                distances = distances[distances > 0]
        
        return {
            "count": len(distances),
            "mean": float(np.mean(distances)),
            "std": float(np.std(distances)),
            "min": float(np.min(distances)),
            "max": float(np.max(distances)),
            "percentiles": {
                "25": float(np.percentile(distances, 25)),
                "50": float(np.percentile(distances, 50)),
                "75": float(np.percentile(distances, 75)),
                "90": float(np.percentile(distances, 90)),
                "95": float(np.percentile(distances, 95))
            }
        }

# ==============================================================================
# VALIDATION UTILITIES
# ==============================================================================

class ValidationUtils:
    """Comprehensive validation utilities for embeddings."""
    
    @classmethod
    def validate_embedding_quality(
        cls,
        embeddings: List[List[float]],
        dimension_range: Tuple[int, int] = (100, 2048),
        value_range: Tuple[float, float] = (-10.0, 10.0),
        require_unit_norm: bool = False
    ) -> ValidationReport:
        """Comprehensive validation of embedding quality."""
        issues = []
        warnings = []
        quality_metrics = {}
        
        if not embeddings:
            return ValidationReport(
                valid=False,
                issues=["No embeddings provided"],
                warnings=[],
                quality_score=0.0,
                statistics={},
                recommendations=["Provide embeddings for validation"]
            )
        
        # Basic structure validation
        if not isinstance(embeddings, list):
            issues.append("Embeddings must be a list")
            return ValidationReport(
                valid=False,
                issues=issues,
                warnings=warnings,
                quality_score=0.0,
                statistics={},
                recommendations=["Ensure embeddings are provided as a list"]
            )
        
        # Check if all items are lists/arrays
        if not all(isinstance(emb, (list, np.ndarray)) for emb in embeddings):
            issues.append("All embeddings must be list or array objects")
        
        # Convert to numpy array for analysis
        try:
            embedding_array = np.array(embeddings)
        except Exception as e:
            issues.append(f"Cannot convert embeddings to array: {e}")
            return ValidationReport(
                valid=False,
                issues=issues,
                warnings=warnings,
                quality_score=0.0,
                statistics={},
                recommendations=["Ensure all embeddings are numeric and properly formatted"]
            )
        
        # Dimension validation
        n_embeddings, dimension = embedding_array.shape
        min_dim, max_dim = dimension_range
        
        if dimension < min_dim or dimension > max_dim:
            issues.append(f"Embedding dimension ({dimension}) outside expected range ({min_dim}-{max_dim})")
        
        # Check for consistent dimensions
        dimensions = [len(emb) for emb in embeddings]
        if len(set(dimensions)) > 1:
            issues.append(f"Inconsistent embedding dimensions: {set(dimensions)}")
        
        # Value range validation
        min_val = float(np.min(embedding_array))
        max_val = float(np.max(embedding_array))
        quality_metrics["value_range"] = (min_val, max_val)
        
        if min_val < value_range[0] or max_val > value_range[1]:
            warnings.append(f"Values outside expected range [{value_range[0]}, {value_range[1]}]")
        
        # Check for NaN and infinite values
        nan_count = np.sum(np.isnan(embedding_array))
        inf_count = np.sum(np.isinf(embedding_array))
        
        if nan_count > 0:
            issues.append(f"Found {nan_count} NaN values")
        if inf_count > 0:
            issues.append(f"Found {inf_count} infinite values")
        
        # Check for zero vectors
        norms = np.linalg.norm(embedding_array, axis=1)
        zero_norm_count = np.sum(norms == 0)
        if zero_norm_count > 0:
            issues.append(f"Found {zero_norm_count} zero vectors")
        
        # Statistical analysis
        mean_vals = np.mean(embedding_array, axis=1)
        std_vals = np.std(embedding_array, axis=1)
        
        quality_metrics.update({
            "n_embeddings": n_embeddings,
            "dimension": dimension,
            "mean_value": float(np.mean(embedding_array)),
            "std_value": float(np.std(embedding_array)),
            "mean_norm": float(np.mean(norms)),
            "std_norm": float(np.std(norms)),
            "mean_per_embedding": float(np.mean(mean_vals)),
            "std_per_embedding": float(np.mean(std_vals))
        })
        
        # Unit norm validation
        if require_unit_norm:
            norm_deviations = np.abs(norms - 1.0)
            max_deviation = float(np.max(norm_deviations))
            if max_deviation > 0.1:  # Allow 10% deviation
                warnings.append(f"Embeddings not unit normalized (max deviation: {max_deviation:.3f})")
        
        # Quality score calculation
        quality_score = cls._calculate_quality_score(
            n_embeddings, nan_count, inf_count, zero_norm_count, dimension_range, issues, warnings
        )
        
        # Generate recommendations
        recommendations = cls._generate_recommendations(issues, warnings, quality_metrics)
        
        return ValidationReport(
            valid=len(issues) == 0,
            issues=issues,
            warnings=warnings,
            quality_score=quality_score,
            statistics=quality_metrics,
            recommendations=recommendations
        )
    
    @classmethod
    def _calculate_quality_score(
        cls,
        n_embeddings: int,
        nan_count: int,
        inf_count: int,
        zero_norm_count: int,
        dimension_range: Tuple[int, int],
        issues: List[str],
        warnings: List[str]
    ) -> float:
        """Calculate overall quality score (0-1)."""
        score = 1.0
        
        # Penalize issues
        score -= len(issues) * 0.1
        score -= len(warnings) * 0.05
        
        # Penalize problematic embeddings
        total_embeddings = n_embeddings
        
        if total_embeddings > 0:
            # Penalize NaN values
            score -= (nan_count / total_embeddings) * 0.3
            
            # Penalize infinite values
            score -= (inf_count / total_embeddings) * 0.3
            
            # Penalize zero vectors
            score -= (zero_norm_count / total_embeddings) * 0.2
        
        # Bonus for having reasonable number of embeddings
        if n_embeddings >= 10:
            score += 0.1
        if n_embeddings >= 100:
            score += 0.1
        
        return max(0.0, min(1.0, score))
    
    @classmethod
    def _generate_recommendations(
        cls,
        issues: List[str],
        warnings: List[str],
        quality_metrics: Dict[str, Any]
    ) -> List[str]:
        """Generate recommendations based on validation results."""
        recommendations = []
        
        # Issue-based recommendations
        if any("dimension" in issue.lower() for issue in issues):
            recommendations.append("Ensure all embeddings have consistent dimensions")
        
        if any("nan" in issue.lower() or "infinite" in issue.lower() for issue in issues):
            recommendations.append("Check data preprocessing to remove NaN and infinite values")
        
        if any("zero" in issue.lower() for issue in issues):
            recommendations.append("Remove or handle zero vectors in the embedding set")
        
        # Warning-based recommendations
        if any("range" in warning.lower() for warning in warnings):
            recommendations.append("Consider normalizing embedding values")
        
        if any("normaliz" in warning.lower() for warning in warnings):
            recommendations.append("Apply unit normalization to embeddings")
        
        # Quality-based recommendations
        if quality_metrics.get("n_embeddings", 0) < 10:
            recommendations.append("Consider using a larger set of embeddings for better analysis")
        
        if quality_metrics.get("std_value", 0) < 0.1:
            recommendations.append("Embeddings may have low variance - check data quality")
        
        return recommendations
    
    @classmethod
    def benchmark_embeddings(
        cls,
        embeddings: List[List[float]],
        metrics: List[str] = None
    ) -> Dict[str, Any]:
        """Benchmark embedding quality across different metrics."""
        if metrics is None:
            metrics = ['cosine', 'euclidean', 'manhattan']
        
        if not embeddings:
            return {"error": "No embeddings provided"}
        
        embedding_array = np.array(embeddings)
        n_embeddings = len(embeddings)
        
        # Calculate statistics for each metric
        benchmark_results = {}
        
        for metric in metrics:
            try:
                if metric == 'cosine':
                    similarity_matrix = cosine_similarity(embedding_array)
                    # Get upper triangle (excluding diagonal)
                    similarities = np.triu(similarity_matrix, k=1)
                    similarities = similarities[similarities > 0]
                    
                    benchmark_results[metric] = {
                        "mean_similarity": float(np.mean(similarities)),
                        "std_similarity": float(np.std(similarities)),
                        "min_similarity": float(np.min(similarities)),
                        "max_similarity": float(np.max(similarities)),
                        "diversity_score": float(np.std(similarities))
                    }
                
                elif metric == 'euclidean':
                    distance_matrix = euclidean_distances(embedding_array)
                    distances = np.triu(distance_matrix, k=1)
                    distances = distances[distances > 0]
                    
                    benchmark_results[metric] = {
                        "mean_distance": float(np.mean(distances)),
                        "std_distance": float(np.std(distances)),
                        "min_distance": float(np.min(distances)),
                        "max_distance": float(np.max(distances)),
                        "spread_score": float(np.std(distances))
                    }
                
                elif metric == 'manhattan':
                    distances = []
                    for i in range(n_embeddings):
                        for j in range(i + 1, n_embeddings):
                            dist = np.sum(np.abs(embedding_array[i] - embedding_array[j]))
                            distances.append(dist)
                    
                    benchmark_results[metric] = {
                        "mean_distance": float(np.mean(distances)),
                        "std_distance": float(np.std(distances)),
                        "min_distance": float(np.min(distances)),
                        "max_distance": float(np.max(distances))
                    }
            
            except Exception as e:
                benchmark_results[metric] = {"error": str(e)}
        
        # Overall diversity assessment
        if 'cosine' in benchmark_results and 'error' not in benchmark_results['cosine']:
            diversity = benchmark_results['cosine']['diversity_score']
            if diversity > 0.3:
                diversity_assessment = "High diversity - embeddings are well spread"
            elif diversity > 0.1:
                diversity_assessment = "Medium diversity - embeddings have good spread"
            else:
                diversity_assessment = "Low diversity - embeddings may be too similar"
        else:
            diversity_assessment = "Unable to assess diversity"
        
        return {
            "n_embeddings": n_embeddings,
            "dimension": embedding_array.shape[1],
            "metrics": benchmark_results,
            "diversity_assessment": diversity_assessment,
            "benchmark_timestamp": datetime.now().isoformat()
        }

# ==============================================================================
# ANALYTICS UTILITIES
# ==============================================================================

class AnalyticsUtils:
    """Advanced analytics and insights utilities."""
    
    @classmethod
    def analyze_embedding_space(
        cls,
        embeddings: List[Tuple[str, List[float]]],
        analysis_type: str = 'comprehensive'
    ) -> AnalyticsReport:
        """Comprehensive analysis of embedding space."""
        if not embeddings:
            return AnalyticsReport(
                summary={"error": "No embeddings provided"},
                quality_metrics={},
                distribution_analysis={},
                clustering_analysis={},
                outlier_detection={},
                performance_metrics={}
            )
        
        # Extract IDs and embedding vectors
        ids = [item[0] for item in embeddings]
        embedding_vectors = [item[1] for item in embeddings]
        embedding_array = np.array(embedding_vectors)
        
        # Summary statistics
        summary = {
            "total_embeddings": len(embeddings),
            "dimension": embedding_array.shape[1],
            "data_type": str(embedding_array.dtype),
            "memory_usage_mb": embedding_array.nbytes / (1024 * 1024)
        }
        
        # Quality metrics
        validation_report = ValidationUtils.validate_embedding_quality(embedding_vectors)
        quality_metrics = validation_report.to_dict()
        
        # Distribution analysis
        distribution_analysis = cls._analyze_distribution(embedding_array)
        
        # Clustering analysis
        clustering_analysis = {}
        if len(embeddings) >= 10:
            clustering_analysis = SimilarityUtils.calculate_clustering_similarity(embeddings)
        
        # Outlier detection
        outlier_detection = cls._detect_outliers(embedding_array)
        
        # Performance metrics
        performance_metrics = {}
        if len(embeddings) >= 2:
            performance_metrics = {
                "pairwise_distances": SimilarityUtils.calculate_distance_distribution(embedding_vectors),
                "space_density": cls._calculate_space_density(embedding_array)
            }
        
        return AnalyticsReport(
            summary=summary,
            quality_metrics=quality_metrics,
            distribution_analysis=distribution_analysis,
            clustering_analysis=clustering_analysis,
            outlier_detection=outlier_detection,
            performance_metrics=performance_metrics
        )
    
    @classmethod
    def _analyze_distribution(cls, embedding_array: np.ndarray) -> Dict[str, Any]:
        """Analyze the distribution of embeddings."""
        # Per-dimension statistics
        dim_stats = {}
        for i in range(embedding_array.shape[1]):
            dim_values = embedding_array[:, i]
            dim_stats[f"dim_{i}"] = {
                "mean": float(np.mean(dim_values)),
                "std": float(np.std(dim_values)),
                "min": float(np.min(dim_values)),
                "max": float(np.max(dim_values)),
                "q25": float(np.percentile(dim_values, 25)),
                "q75": float(np.percentile(dim_values, 75))
            }
        
        # Global statistics
        global_stats = {
            "mean": float(np.mean(embedding_array)),
            "std": float(np.std(embedding_array)),
            "min": float(np.min(embedding_array)),
            "max": float(np.max(embedding_array)),
            "q25": float(np.percentile(embedding_array, 25)),
            "q75": float(np.percentile(embedding_array, 75)),
            "skewness": float(stats.skew(embedding_array.flatten())),
            "kurtosis": float(stats.kurtosis(embedding_array.flatten()))
        }
        
        # Norm statistics
        norms = np.linalg.norm(embedding_array, axis=1)
        norm_stats = {
            "mean_norm": float(np.mean(norms)),
            "std_norm": float(np.std(norms)),
            "min_norm": float(np.min(norms)),
            "max_norm": float(np.max(norms))
        }
        
        return {
            "global_stats": global_stats,
            "norm_stats": norm_stats,
            "dimension_stats": dim_stats
        }
    
    @classmethod
    def _detect_outliers(cls, embedding_array: np.ndarray) -> Dict[str, Any]:
        """Detect outliers in embedding space."""
        # Calculate distances from centroid
        centroid = np.mean(embedding_array, axis=0)
        distances_from_centroid = np.linalg.norm(embedding_array - centroid, axis=1)
        
        # Z-score based outlier detection
        z_scores = np.abs(stats.zscore(distances_from_centroid))
        z_threshold = 2.5
        z_outliers = np.where(z_scores > z_threshold)[0]
        
        # IQR based outlier detection
        q1 = np.percentile(distances_from_centroid, 25)
        q3 = np.percentile(distances_from_centroid, 75)
        iqr = q3 - q1
        iqr_threshold = 1.5
        iqr_outliers = np.where(
            (distances_from_centroid < q1 - iqr_threshold * iqr) |
            (distances_from_centroid > q3 + iqr_threshold * iqr)
        )[0]
        
        # Isolation Forest (if available)
        try:
            from sklearn.ensemble import IsolationForest
            iso_forest = IsolationForest(contamination=0.1, random_state=42)
            outlier_labels = iso_forest.fit_predict(embedding_array)
            isolation_outliers = np.where(outlier_labels == -1)[0]
        except ImportError:
            isolation_outliers = np.array([])
        
        return {
            "centroid_distance_stats": {
                "mean": float(np.mean(distances_from_centroid)),
                "std": float(np.std(distances_from_centroid)),
                "min": float(np.min(distances_from_centroid)),
                "max": float(np.max(distances_from_centroid))
            },
            "outlier_counts": {
                "z_score_method": len(z_outliers),
                "iqr_method": len(iqr_outliers),
                "isolation_forest": len(isolation_outliers)
            },
            "outlier_indices": {
                "z_score_outliers": z_outliers.tolist(),
                "iqr_outliers": iqr_outliers.tolist(),
                "isolation_outliers": isolation_outliers.tolist()
            }
        }
    
    @classmethod
    def _calculate_space_density(cls, embedding_array: np.ndarray) -> Dict[str, Any]:
        """Calculate density metrics for the embedding space."""
        # Nearest neighbor distances
        distances = []
        for i in range(len(embedding_array)):
            other_embeddings = np.delete(embedding_array, i, axis=0)
            nearest_dist = np.min(np.linalg.norm(embedding_array[i] - other_embeddings, axis=1))
            distances.append(nearest_dist)
        
        return {
            "mean_nearest_neighbor_distance": float(np.mean(distances)),
            "std_nearest_neighbor_distance": float(np.std(distances)),
            "density_score": 1.0 / (1.0 + np.mean(distances))  # Higher density = smaller distances
        }
    
    @classmethod
    def generate_insights(
        cls,
        analytics_report: AnalyticsReport,
        context: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Generate actionable insights from analytics report."""
        insights = []
        recommendations = []
        
        # Quality insights
        quality_score = analytics_report.quality_metrics.get('quality_score', 0)
        if quality_score < 0.7:
            insights.append(f"Low embedding quality detected (score: {quality_score:.2f})")
            recommendations.append("Review data preprocessing and model quality")
        
        # Distribution insights
        global_stats = analytics_report.distribution_analysis.get('global_stats', {})
        skewness = global_stats.get('skewness', 0)
        if abs(skewness) > 2:
            insights.append(f"High skewness detected ({skewness:.2f}) - embeddings may be unbalanced")
            recommendations.append("Consider data balancing or normalization")
        
        # Outlier insights
        outlier_counts = analytics_report.outlier_detection.get('outlier_counts', {})
        total_outliers = sum(outlier_counts.values())
        if total_outliers > len(analytics_report.summary.get('total_embeddings', [])) * 0.1:
            insights.append(f"High number of outliers detected ({total_outliers})")
            recommendations.append("Investigate outlier data points and consider removal")
        
        # Clustering insights
        clustering_analysis = analytics_report.clustering_analysis
        if clustering_analysis and 'silhouette_score' in clustering_analysis:
            silhouette_score = clustering_analysis['silhouette_score']
            if silhouette_score and silhouette_score < 0.3:
                insights.append(f"Poor clustering quality (silhouette score: {silhouette_score:.3f})")
                recommendations.append("Consider different clustering parameters or algorithms")
        
        # Performance insights
        performance_metrics = analytics_report.performance_metrics
        if 'pairwise_distances' in performance_metrics:
            dist_stats = performance_metrics['pairwise_distances']
            std_dev = dist_stats.get('std', 0)
            if std_dev < 0.1:
                insights.append("Low diversity in embedding distances")
                recommendations.append("Consider increasing data diversity or model complexity")
        
        return {
            "insights": insights,
            "recommendations": recommendations,
            "generated_at": datetime.now().isoformat(),
            "context": context or {}
        }

# ==============================================================================
# VISUALIZATION UTILITIES
# ==============================================================================

class VisualizationUtils:
    """Utilities for creating visualizations of embedding analysis."""
    
    @classmethod
    def create_2d_visualization(
        cls,
        embeddings: List[Tuple[str, List[float]]],
        method: str = 'pca',
        n_components: int = 2,
        save_path: str = None
    ) -> Optional[str]:
        """Create 2D visualization of embeddings using dimensionality reduction."""
        try:
            # Extract embedding vectors
            embedding_vectors = [item[1] for item in embeddings]
            labels = [item[0] for item in embeddings]
            embedding_array = np.array(embedding_vectors)
            
            # Apply dimensionality reduction
            if method == 'pca':
                reducer = PCA(n_components=n_components, random_state=42)
                reduced_embeddings = reducer.fit_transform(embedding_array)
                explained_variance = reducer.explained_variance_ratio_
            elif method == 'tsne':
                reducer = TSNE(n_components=n_components, random_state=42, perplexity=min(30, len(embeddings)//4))
                reduced_embeddings = reducer.fit_transform(embedding_array)
                explained_variance = None
            else:
                raise ValueError(f"Unknown dimensionality reduction method: {method}")
            
            # Create plot
            plt.figure(figsize=(10, 8))
            
            # If we have many embeddings, use scatter plot
            if len(embeddings) > 1000:
                plt.scatter(reduced_embeddings[:, 0], reduced_embeddings[:, 1], alpha=0.6, s=20)
                plt.title(f'2D Visualization of {len(embeddings)} Embeddings using {method.upper()}')
            else:
                # Use different colors for different embeddings
                colors = plt.cm.tab20(np.linspace(0, 1, len(embeddings)))
                for i, (x, y) in enumerate(reduced_embeddings):
                    plt.scatter(x, y, c=[colors[i]], s=50, alpha=0.8)
                    if len(embeddings) <= 50:  # Only show labels for small datasets
                        plt.annotate(str(labels[i])[:20], (x, y), fontsize=8, alpha=0.7)
                
                plt.title(f'2D Visualization of {len(embeddings)} Embeddings using {method.upper()}')
            
            plt.xlabel(f'Component 1{" (explained var: {:.1%})".format(explained_variance[0]) if explained_variance is not None else ""}')
            plt.ylabel(f'Component 2{" (explained var: {:.1%})".format(explained_variance[1]) if explained_variance is not None else ""}')
            plt.grid(True, alpha=0.3)
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                plt.close()
                return save_path
            else:
                # Save to a temporary file
                import tempfile
                temp_path = f"{tempfile.gettempdir()}/embedding_visualization_{int(time.time())}.png"
                plt.savefig(temp_path, dpi=300, bbox_inches='tight')
                plt.close()
                return temp_path
                
        except Exception as e:
            logger.error(f"Failed to create visualization: {e}")
            return None
    
    @classmethod
    def create_similarity_heatmap(
        cls,
        similarity_matrix: np.ndarray,
        labels: List[str] = None,
        title: str = "Embedding Similarity Matrix",
        save_path: str = None
    ) -> Optional[str]:
        """Create heatmap of similarity matrix."""
        try:
            # Limit size for visualization
            max_size = 50
            if similarity_matrix.shape[0] > max_size:
                # Sample to show structure
                indices = np.linspace(0, similarity_matrix.shape[0]-1, max_size, dtype=int)
                similarity_matrix = similarity_matrix[np.ix_(indices, indices)]
                if labels:
                    labels = [labels[i] for i in indices]
            
            # Create heatmap
            plt.figure(figsize=(12, 10))
            
            sns.heatmap(
                similarity_matrix,
                annot=False,
                cmap='viridis',
                square=True,
                cbar_kws={'label': 'Similarity Score'}
            )
            
            if labels and len(labels) <= max_size:
                plt.xticks(range(len(labels)), labels, rotation=45, ha='right')
                plt.yticks(range(len(labels)), labels, rotation=0)
            
            plt.title(title)
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                plt.close()
                return save_path
            else:
                import tempfile
                temp_path = f"{tempfile.gettempdir()}/similarity_heatmap_{int(time.time())}.png"
                plt.savefig(temp_path, dpi=300, bbox_inches='tight')
                plt.close()
                return temp_path
                
        except Exception as e:
            logger.error(f"Failed to create similarity heatmap: {e}")
            return None

# ==============================================================================
# EXPORT/IMPORT UTILITIES
# ==============================================================================

class ExportImportUtils:
    """Utilities for exporting and importing embedding data."""
    
    @classmethod
    def export_to_json(
        cls,
        embeddings: List[Tuple[str, List[float]]],
        metadata: Dict[str, Any] = None,
        file_path: str = None
    ) -> str:
        """Export embeddings to JSON format."""
        export_data = {
            "format_version": "2.0",
            "export_timestamp": datetime.now().isoformat(),
            "total_embeddings": len(embeddings),
            "dimension": len(embeddings[0][1]) if embeddings else 0,
            "embeddings": [
                {
                    "id": emb_id,
                    "embedding": embedding,
                    "metadata": {}
                }
                for emb_id, embedding in embeddings
            ],
            "metadata": metadata or {}
        }
        
        if file_path:
            with open(file_path, 'w') as f:
                json.dump(export_data, f, indent=2)
            return file_path
        else:
            import tempfile
            temp_path = f"{tempfile.gettempdir()}/embeddings_export_{int(time.time())}.json"
            with open(temp_path, 'w') as f:
                json.dump(export_data, f, indent=2)
            return temp_path
    
    @classmethod
    def import_from_json(cls, file_path: str) -> Tuple[List[Tuple[str, List[float]]], Dict[str, Any]]:
        """Import embeddings from JSON format."""
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        embeddings = [
            (item["id"], item["embedding"])
            for item in data["embeddings"]
        ]
        
        metadata = data.get("metadata", {})
        return embeddings, metadata
    
    @classmethod
    def export_to_csv(
        cls,
        embeddings: List[Tuple[str, List[float]]],
        file_path: str = None
    ) -> str:
        """Export embeddings to CSV format."""
        if not embeddings:
            raise ValueError("No embeddings to export")
        
        # Create DataFrame
        data = []
        for emb_id, embedding in embeddings:
            row = {"id": emb_id}
            for i, value in enumerate(embedding):
                row[f"dim_{i}"] = value
            data.append(row)
        
        df = pd.DataFrame(data)
        
        if file_path:
            df.to_csv(file_path, index=False)
            return file_path
        else:
            import tempfile
            temp_path = f"{tempfile.gettempdir()}/embeddings_export_{int(time.time())}.csv"
            df.to_csv(temp_path, index=False)
            return temp_path

# ==============================================================================
# GLOBAL INSTANCE
# ==============================================================================

# Create global instances for easy access
text_preprocessor = TextPreprocessingUtils()
similarity_utils = SimilarityUtils()
validation_utils = ValidationUtils()
analytics_utils = AnalyticsUtils()
visualization_utils = VisualizationUtils()
export_import_utils = ExportImportUtils()