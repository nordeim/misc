"""
Preprocessing Utilities Module

This module provides comprehensive preprocessing utilities for text preprocessing,
data cleaning, content normalization, and format conversion.
"""

import re
import json
import html
import unicodedata
from typing import Any, Dict, List, Optional, Union, Tuple, Callable, Type
from datetime import datetime, date
from urllib.parse import quote, unquote
import base64
from io import StringIO
import csv
from collections import Counter
import string
import logging

try:
    import nltk
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize, sent_tokenize
    from nltk.stem import PorterStemmer, WordNetLemmatizer
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False

try:
    import spacy
    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False

logger = logging.getLogger(__name__)


class TextPreprocessor:
    """Advanced text preprocessing utilities"""
    
    # Common abbreviations and their expansions
    ABBREVIATIONS = {
        'u': 'you',
        'ur': 'your',
        'r': 'are',
        'n': 'and',
        'w/': 'with',
        'w/o': 'without',
        'b/c': 'because',
        'b/w': 'between',
        'tho': 'though',
        'thru': 'through',
        'wknd': 'weekend',
        'tho': 'though',
        'plz': 'please',
        'thx': 'thanks',
        'omg': 'oh my god',
        'lol': 'laugh out loud',
        'wtf': 'what the f',
        'btw': 'by the way',
        'fyi': 'for your information',
        'imo': 'in my opinion',
        'imho': 'in my humble opinion',
        'aka': 'also known as',
        'asap': 'as soon as possible',
        'eta': 'estimated time of arrival',
        'etc': 'etcetera',
        'aka': 'also known as'
    }
    
    # Regular expressions for text cleaning
    URL_PATTERN = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
    EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    HTML_TAG_PATTERN = re.compile(r'<[^>]+>')
    HASHTAG_PATTERN = re.compile(r'#\w+')
    MENTION_PATTERN = re.compile(r'@\w+')
    EMOJI_PATTERN = re.compile(r'[\U00010000-\U0010ffff]', flags=re.UNICODE)
    MULTIPLE_SPACES_PATTERN = re.compile(r'\s+')
    NON_ALPHANUMERIC_PATTERN = re.compile(r'[^a-zA-Z0-9\s]')
    
    @classmethod
    def clean_text(cls, text: str, remove_urls: bool = True, remove_emails: bool = True,
                   remove_html: bool = True, remove_hashtags: bool = False,
                   remove_mentions: bool = False, remove_emojis: bool = True,
                   normalize_whitespace: bool = True) -> str:
        """Comprehensive text cleaning"""
        if not isinstance(text, str):
            return str(text)
        
        # Remove HTML tags
        if remove_html:
            text = cls.HTML_TAG_PATTERN.sub(' ', text)
            text = html.unescape(text)
        
        # Remove URLs
        if remove_urls:
            text = cls.URL_PATTERN.sub(' ', text)
        
        # Remove email addresses
        if remove_emails:
            text = cls.EMAIL_PATTERN.sub(' ', text)
        
        # Remove hashtags
        if remove_hashtags:
            text = cls.HASHTAG_PATTERN.sub(' ', text)
        
        # Remove mentions
        if remove_mentions:
            text = cls.MENTION_PATTERN.sub(' ', text)
        
        # Remove emojis
        if remove_emojis:
            text = cls.EMOJI_PATTERN.sub(' ', text)
        
        # Normalize whitespace
        if normalize_whitespace:
            text = cls.MULTIPLE_SPACES_PATTERN.sub(' ', text)
        
        return text.strip()
    
    @classmethod
    def expand_abbreviations(cls, text: str) -> str:
        """Expand common abbreviations"""
        words = text.split()
        expanded_words = []
        
        for word in words:
            # Remove punctuation for comparison
            clean_word = word.lower().strip(string.punctuation)
            if clean_word in cls.ABBREVIATIONS:
                expanded = cls.ABBREVIATIONS[clean_word]
                # Preserve original capitalization and punctuation
                if word[0].isupper():
                    expanded = expanded.capitalize()
                # Add back original punctuation
                punctuation = ''
                for char in word:
                    if char in string.punctuation:
                        punctuation += char
                expanded_words.append(expanded + punctuation)
            else:
                expanded_words.append(word)
        
        return ' '.join(expanded_words)
    
    @classmethod
    def normalize_text(cls, text: str, lowercase: bool = True, remove_accents: bool = True) -> str:
        """Normalize text encoding and formatting"""
        if not isinstance(text, str):
            return str(text)
        
        # Remove accents
        if remove_accents:
            text = unicodedata.normalize('NFD', text)
            text = ''.join(char for char in text if unicodedata.category(char) != 'Mn')
        
        # Convert to lowercase
        if lowercase:
            text = text.lower()
        
        return text
    
    @classmethod
    def tokenize_text(cls, text: str, method: str = 'word') -> List[str]:
        """Tokenize text using various methods"""
        if not isinstance(text, str) or not text.strip():
            return []
        
        if NLTK_AVAILABLE:
            try:
                if method == 'word':
                    return word_tokenize(text)
                elif method == 'sentence':
                    return sent_tokenize(text)
            except Exception as e:
                logger.warning(f"NLTK tokenization failed: {e}")
        
        # Fallback tokenization
        if method == 'word':
            return text.split()
        elif method == 'sentence':
            return re.split(r'[.!?]+', text)
        else:
            return text.split()
    
    @classmethod
    def remove_stopwords(cls, tokens: List[str], language: str = 'english') -> List[str]:
        """Remove stopwords from token list"""
        if not tokens:
            return []
        
        if NLTK_AVAILABLE:
            try:
                stop_words = set(stopwords.words(language))
                return [token for token in tokens if token.lower() not in stop_words]
            except Exception as e:
                logger.warning(f"Stopwords removal failed: {e}")
        
        # Basic English stopwords
        basic_stopwords = {
            'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
            'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
            'to', 'was', 'will', 'with', 'you', 'your', 'i', 'me', 'my',
            'we', 'our', 'us', 'they', 'them', 'their', 'this', 'that',
            'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been',
            'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
            'would', 'could', 'should', 'may', 'might', 'can', 'must',
            'shall', 'ought', 'need', 'dare', 'used', 'able', 'about',
            'above', 'after', 'again', 'against', 'all', 'almost', 'also',
            'am', 'among', 'an', 'and', 'any', 'anyone', 'anything', 'are',
            'around', 'as', 'ask', 'at', 'away', 'back', 'because', 'been',
            'before', 'below', 'between', 'both', 'but', 'by', 'can',
            'cannot', 'could', 'did', 'do', 'does', 'doing', 'down', 'during',
            'each', 'either', 'else', 'enough', 'ever', 'every', 'few',
            'first', 'for', 'from', 'further', 'get', 'give', 'go', 'good',
            'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers',
            'herself', 'him', 'himself', 'his', 'how', 'however', 'if',
            'in', 'into', 'is', 'it', 'its', 'itself', 'just', 'know',
            'last', 'least', 'less', 'let', 'like', 'likely', 'little',
            'made', 'make', 'many', 'may', 'me', 'might', 'more', 'most',
            'much', 'must', 'my', 'myself', 'never', 'new', 'no', 'nobody',
            'non', 'not', 'now', 'of', 'off', 'often', 'on', 'once', 'only',
            'or', 'other', 'our', 'ours', 'ourselves', 'out', 'over', 'own',
            'same', 'she', 'should', 'show', 'so', 'some', 'such', 'than',
            'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then',
            'there', 'these', 'they', 'this', 'those', 'through', 'to',
            'too', 'under', 'until', 'up', 'very', 'was', 'way', 'we',
            'were', 'what', 'when', 'where', 'which', 'while', 'who', 'whom',
            'why', 'with', 'within', 'would', 'you', 'your', 'yours',
            'yourself', 'yourselves'
        }
        
        return [token for token in tokens if token.lower() not in basic_stopwords]
    
    @classmethod
    def stem_words(cls, tokens: List[str]) -> List[str]:
        """Stem words using Porter stemming"""
        if not tokens:
            return []
        
        if NLTK_AVAILABLE:
            try:
                stemmer = PorterStemmer()
                return [stemmer.stem(token) for token in tokens]
            except Exception as e:
                logger.warning(f"Stemming failed: {e}")
        
        # Simple fallback stemming (remove common suffixes)
        suffixes = ['ing', 'ly', 'ed', 'ies', 'ied', 'ied', 'ies', 'ing', 'ed', 's']
        stemmed = []
        for token in tokens:
            for suffix in suffixes:
                if token.endswith(suffix) and len(token) > len(suffix) + 2:
                    token = token[:-len(suffix)]
                    break
            stemmed.append(token)
        return stemmed
    
    @classmethod
    def lemmatize_words(cls, tokens: List[str]) -> List[str]:
        """Lemmatize words using WordNet lemmatizer"""
        if not tokens:
            return []
        
        if NLTK_AVAILABLE:
            try:
                lemmatizer = WordNetLemmatizer()
                return [lemmatizer.lemmatize(token) for token in tokens]
            except Exception as e:
                logger.warning(f"Lemmatization failed: {e}")
        
        # Fallback to simple stemming
        return cls.stem_words(tokens)
    
    @classmethod
    def extract_keywords(cls, text: str, max_keywords: int = 10, remove_stopwords: bool = True,
                        include_frequencies: bool = False) -> Union[List[str], List[Tuple[str, int]]]:
        """Extract keywords from text"""
        # Clean and tokenize text
        cleaned_text = cls.clean_text(text)
        tokens = cls.tokenize_text(cleaned_text)
        
        # Remove stopwords
        if remove_stopwords:
            tokens = cls.remove_stopwords(tokens)
        
        # Count word frequencies
        word_freq = Counter(tokens)
        
        # Get most common words
        if include_frequencies:
            return word_freq.most_common(max_keywords)
        else:
            return [word for word, freq in word_freq.most_common(max_keywords)]


class DataCleaner:
    """Data cleaning utilities for various data formats"""
    
    @classmethod
    def clean_dict(cls, data: Dict[str, Any], remove_empty: bool = True,
                   remove_none: bool = True, remove_null_strings: bool = True) -> Dict[str, Any]:
        """Clean dictionary by removing empty/null values"""
        if not isinstance(data, dict):
            return data
        
        cleaned = {}
        for key, value in data.items():
            if value is None and remove_none:
                continue
            if value == '' and remove_null_strings:
                continue
            if isinstance(value, dict):
                cleaned_value = cls.clean_dict(value, remove_empty, remove_none, remove_null_strings)
                if not remove_empty or cleaned_value:
                    cleaned[key] = cleaned_value
            elif isinstance(value, list):
                cleaned_value = cls.clean_list(value, remove_empty, remove_none, remove_null_strings)
                if not remove_empty or cleaned_value:
                    cleaned[key] = cleaned_value
            else:
                cleaned[key] = value
        
        return cleaned
    
    @classmethod
    def clean_list(cls, data: List[Any], remove_empty: bool = True,
                   remove_none: bool = True, remove_null_strings: bool = True) -> List[Any]:
        """Clean list by removing empty/null values"""
        if not isinstance(data, list):
            return data
        
        cleaned = []
        for item in data:
            if item is None and remove_none:
                continue
            if item == '' and remove_null_strings:
                continue
            if isinstance(item, dict):
                cleaned_item = cls.clean_dict(item, remove_empty, remove_none, remove_null_strings)
                if not remove_empty or cleaned_item:
                    cleaned.append(cleaned_item)
            elif isinstance(item, list):
                cleaned_item = cls.clean_list(item, remove_empty, remove_none, remove_null_strings)
                if not remove_empty or cleaned_item:
                    cleaned.append(cleaned_item)
            else:
                cleaned.append(item)
        
        return cleaned
    
    @classmethod
    def remove_duplicates(cls, data: Union[List[Any], Dict[str, Any]]) -> Union[List[Any], Dict[str, Any]]:
        """Remove duplicate values from data structures"""
        if isinstance(data, list):
            return list(dict.fromkeys(data))  # Preserves order
        elif isinstance(data, dict):
            return {k: v for k, v in data.items()}
        else:
            return data
    
    @classmethod
    def standardize_keys(cls, data: Dict[str, Any], case_style: str = 'snake') -> Dict[str, Any]:
        """Standardize dictionary keys to specified case style"""
        if not isinstance(data, dict):
            return data
        
        def convert_key(key: str) -> str:
            if case_style == 'snake':
                # Convert to snake_case
                s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', key)
                return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
            elif case_style == 'camel':
                # Convert to camelCase
                components = key.replace('-', '_').replace(' ', '_').split('_')
                return components[0].lower() + ''.join(x.capitalize() for x in components[1:])
            elif case_style == 'pascal':
                # Convert to PascalCase
                return ''.join(x.capitalize() for x in key.replace('-', '_').replace(' ', '_').split('_'))
            else:
                return key.lower()
        
        return {convert_key(k): v for k, v in data.items()}
    
    @classmethod
    def type_cast_data(cls, data: Dict[str, Any], type_mapping: Dict[str, Type]) -> Dict[str, Any]:
        """Cast data types according to mapping"""
        if not isinstance(data, dict):
            return data
        
        for field, expected_type in type_mapping.items():
            if field in data and data[field] is not None:
                try:
                    if expected_type == bool and isinstance(data[field], str):
                        # Handle string to boolean conversion
                        data[field] = data[field].lower() in ('true', '1', 'yes', 'on')
                    else:
                        data[field] = expected_type(data[field])
                except (ValueError, TypeError):
                    logger.warning(f"Failed to cast field '{field}' to {expected_type.__name__}")
        
        return data
    
    @classmethod
    def normalize_numeric_values(cls, data: Dict[str, Any], decimal_places: int = 2) -> Dict[str, Any]:
        """Normalize numeric values to specified decimal places"""
        if not isinstance(data, dict):
            return data
        
        for key, value in data.items():
            if isinstance(value, (int, float)):
                if isinstance(value, float):
                    data[key] = round(value, decimal_places)
            elif isinstance(value, dict):
                data[key] = cls.normalize_numeric_values(value, decimal_places)
            elif isinstance(value, list):
                data[key] = [cls.normalize_numeric_values(item, decimal_places) 
                           if isinstance(item, dict) else item for item in value]
        
        return data


class ContentNormalizer:
    """Content normalization utilities"""
    
    @classmethod
    def normalize_text_content(cls, text: str, normalize_unicode: bool = True,
                              remove_control_chars: bool = True,
                              normalize_newlines: bool = True) -> str:
        """Normalize text content"""
        if not isinstance(text, str):
            return str(text)
        
        # Normalize Unicode
        if normalize_unicode:
            text = unicodedata.normalize('NFC', text)
        
        # Remove control characters
        if remove_control_chars:
            text = ''.join(char for char in text if not unicodedata.category(char).startswith('C'))
        
        # Normalize newlines
        if normalize_newlines:
            text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        return text
    
    @classmethod
    def normalize_json_content(cls, json_content: str) -> str:
        """Normalize JSON content formatting"""
        try:
            data = json.loads(json_content)
            return json.dumps(data, sort_keys=True, indent=2)
        except (json.JSONDecodeError, TypeError):
            return json_content
    
    @classmethod
    def normalize_url_content(cls, url: str) -> str:
        """Normalize URL encoding"""
        try:
            # Decode any existing percent encoding
            decoded = unquote(url)
            # Re-encode to ensure consistent formatting
            return quote(decoded, safe=':/?#[]@!$&\'()*+,;=')
        except Exception:
            return url
    
    @classmethod
    def normalize_base64_content(cls, base64_string: str) -> str:
        """Normalize base64 content"""
        try:
            # Remove whitespace and newlines
            clean = re.sub(r'\s+', '', base64_string)
            # Add padding if necessary
            missing_padding = len(clean) % 4
            if missing_padding:
                clean += '=' * (4 - missing_padding)
            return clean
        except Exception:
            return base64_string


class FormatConverter:
    """Format conversion utilities"""
    
    @classmethod
    def csv_to_dict_list(cls, csv_content: str, delimiter: str = ',',
                        encoding: str = 'utf-8') -> List[Dict[str, str]]:
        """Convert CSV content to list of dictionaries"""
        try:
            csv_file = StringIO(csv_content)
            reader = csv.DictReader(csv_file, delimiter=delimiter)
            return list(reader)
        except Exception as e:
            logger.error(f"CSV conversion failed: {e}")
            return []
    
    @classmethod
    def dict_list_to_csv(cls, data: List[Dict[str, Any]], delimiter: str = ',',
                        encoding: str = 'utf-8') -> str:
        """Convert list of dictionaries to CSV format"""
        try:
            if not data:
                return ""
            
            output = StringIO()
            writer = csv.DictWriter(output, fieldnames=data[0].keys(), delimiter=delimiter)
            writer.writeheader()
            writer.writerows(data)
            return output.getvalue()
        except Exception as e:
            logger.error(f"CSV conversion failed: {e}")
            return ""
    
    @classmethod
    def string_to_list(cls, string: str, separator: str = ',', strip_whitespace: bool = True) -> List[str]:
        """Convert string to list using separator"""
        if not string:
            return []
        
        items = string.split(separator)
        if strip_whitespace:
            items = [item.strip() for item in items]
        
        return [item for item in items if item]
    
    @classmethod
    def list_to_string(cls, items: List[Any], separator: str = ',') -> str:
        """Convert list to string using separator"""
        if not items:
            return ""
        
        return separator.join(str(item) for item in items)
    
    @classmethod
    def bytes_to_base64(cls, data: bytes) -> str:
        """Convert bytes to base64 string"""
        try:
            return base64.b64encode(data).decode('utf-8')
        except Exception:
            return ""
    
    @classmethod
    def base64_to_bytes(cls, base64_string: str) -> bytes:
        """Convert base64 string to bytes"""
        try:
            return base64.b64decode(base64_string)
        except Exception:
            return b""
    
    @classmethod
    def dict_to_query_string(cls, data: Dict[str, Any]) -> str:
        """Convert dictionary to URL query string"""
        if not data:
            return ""
        
        params = []
        for key, value in data.items():
            if value is not None:
                if isinstance(value, list):
                    for item in value:
                        params.append(f"{quote(str(key))}={quote(str(item))}")
                else:
                    params.append(f"{quote(str(key))}={quote(str(value))}")
        
        return "&".join(params)
    
    @classmethod
    def query_string_to_dict(cls, query_string: str) -> Dict[str, List[str]]:
        """Convert URL query string to dictionary"""
        if not query_string:
            return {}
        
        result = {}
        for param in query_string.split('&'):
            if '=' in param:
                key, value = param.split('=', 1)
                key = unquote(key)
                value = unquote(value)
                
                if key in result:
                    if not isinstance(result[key], list):
                        result[key] = [result[key]]
                    result[key].append(value)
                else:
                    result[key] = [value]
        
        return result


class PreprocessingPipeline:
    """Preprocessing pipeline for batch processing"""
    
    def __init__(self):
        self.steps = []
    
    def add_step(self, step_function: Callable, **kwargs):
        """Add preprocessing step to pipeline"""
        self.steps.append((step_function, kwargs))
    
    def process(self, data: Any) -> Any:
        """Process data through all pipeline steps"""
        result = data
        for step_function, kwargs in self.steps:
            try:
                result = step_function(result, **kwargs)
            except Exception as e:
                logger.error(f"Preprocessing step failed: {e}")
                continue
        return result
    
    def process_batch(self, data_list: List[Any]) -> List[Any]:
        """Process batch of data through pipeline"""
        return [self.process(data) for data in data_list]


# Utility functions
def preprocess_text_for_search(text: str, remove_stopwords: bool = True,
                              lemmatize: bool = True, min_word_length: int = 2) -> str:
    """Preprocess text for search indexing"""
    # Clean text
    cleaned = TextPreprocessor.clean_text(text, remove_urls=True, remove_emails=True, remove_html=True)
    
    # Normalize
    normalized = TextPreprocessor.normalize_text(cleaned, lowercase=True, remove_accents=True)
    
    # Tokenize
    tokens = TextPreprocessor.tokenize_text(normalized)
    
    # Remove short words
    tokens = [token for token in tokens if len(token) >= min_word_length]
    
    # Remove stopwords
    if remove_stopwords:
        tokens = TextPreprocessor.remove_stopwords(tokens)
    
    # Lemmatize
    if lemmatize:
        tokens = TextPreprocessor.lemmatize_words(tokens)
    
    return ' '.join(tokens)

def extract_entities_from_text(text: str) -> Dict[str, List[str]]:
    """Extract entities from text using basic pattern matching"""
    entities = {
        'emails': TextPreprocessor.EMAIL_PATTERN.findall(text),
        'urls': TextPreprocessor.URL_PATTERN.findall(text),
        'hashtags': TextPreprocessor.HASHTAG_PATTERN.findall(text),
        'mentions': TextPreprocessor.MENTION_PATTERN.findall(text),
        'phone_numbers': re.findall(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', text),
        'dates': re.findall(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', text)
    }
    
    return entities

def calculate_text_similarity(text1: str, text2: str) -> float:
    """Calculate simple text similarity using Jaccard coefficient"""
    # Simple word-based similarity
    words1 = set(TextPreprocessor.tokenize_text(text1.lower()))
    words2 = set(TextPreprocessor.tokenize_text(text2.lower()))
    
    if not words1 and not words2:
        return 1.0
    if not words1 or not words2:
        return 0.0
    
    intersection = words1.intersection(words2)
    union = words1.union(words2)
    
    return len(intersection) / len(union) if union else 0.0


# Export main classes and functions
__all__ = [
    'TextPreprocessor',
    'DataCleaner',
    'ContentNormalizer', 
    'FormatConverter',
    'PreprocessingPipeline',
    'preprocess_text_for_search',
    'extract_entities_from_text',
    'calculate_text_similarity'
]