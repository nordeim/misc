"""
Cache Decorators and Utilities.

This module provides additional cache decorators and utility functions
for common caching patterns and operations.
"""

import asyncio
import functools
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Union
from dataclasses import dataclass

from app.services.cache_service import get_cache_service, cached

logger = logging.getLogger(__name__)


@dataclass
class CacheKey:
    """Cache key with metadata."""
    key: str
    ttl: Optional[int] = None
    tags: List[str] = None
    serializer: Optional[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []


class CacheKeyGenerator:
    """Generate cache keys from function parameters."""
    
    @staticmethod
    def simple_key(func_name: str, args: tuple, kwargs: dict) -> str:
        """Generate simple key from function name and parameters."""
        import hashlib
        import json
        
        key_data = {
            'func': func_name,
            'args': args,
            'kwargs': sorted(kwargs.items())
        }
        key_string = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    @staticmethod
    def prefix_key(prefix: str, func_name: str, args: tuple, kwargs: dict) -> str:
        """Generate key with custom prefix."""
        base_key = CacheKeyGenerator.simple_key(func_name, args, kwargs)
        return f"{prefix}:{base_key}"
    
    @staticmethod
    def args_key(args_to_include: List[str], func_name: str, args: tuple, kwargs: dict) -> str:
        """Generate key including only specific arguments."""
        import hashlib
        import json
        
        # Filter kwargs to only include specified arguments
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in args_to_include}
        
        key_data = {
            'func': func_name,
            'args': args,
            'kwargs': sorted(filtered_kwargs.items())
        }
        key_string = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.md5(key_string.encode()).hexdigest()


def cache_result(
    ttl: Optional[int] = None,
    key_prefix: Optional[str] = None,
    include_args: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
    condition: Optional[Callable] = None,
    serializer: Optional[str] = None
):
    """
    Decorator for caching function results with advanced options.
    
    Args:
        ttl: Time to live in seconds
        key_prefix: Prefix for cache keys
        include_args: Specific arguments to include in key generation
        tags: Tags for cache invalidation
        condition: Function to determine if result should be cached
        serializer: Specific serializer to use
    
    Usage:
        @cache_result(ttl=300, key_prefix="user_data", tags=['user'])
        async def get_user_profile(user_id: int):
            # Expensive operation
            return profile_data
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Check condition
            if condition and not condition(*args, **kwargs):
                return await func(*args, **kwargs)
            
            service = await get_cache_service()
            
            # Generate cache key
            if include_args:
                cache_key = CacheKeyGenerator.args_key(
                    include_args, func.__name__, args, kwargs
                )
            elif key_prefix:
                cache_key = CacheKeyGenerator.prefix_key(
                    key_prefix, func.__name__, args, kwargs
                )
            else:
                cache_key = CacheKeyGenerator.simple_key(
                    func.__name__, args, kwargs
                )
            
            # Try to get from cache
            cached_value = await service.get(cache_key, serializer=serializer)
            if cached_value is not None:
                logger.debug(f"Cache hit for {func.__name__}")
                return cached_value
            
            # Execute function
            logger.debug(f"Cache miss for {func.__name__}")
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Cache the result
            if result is not None:
                await service.set(
                    cache_key, result, ttl=ttl, tags=tags, serializer=serializer
                )
            
            return result
        
        return wrapper
    return decorator


def cache_method(
    ttl: Optional[int] = None,
    key_prefix: Optional[str] = None,
    include_args: Optional[List[str]] = None,
    tags: Optional[List[str]] = None,
    instance_cache: bool = False
):
    """
    Decorator for caching method results.
    
    Args:
        ttl: Time to live in seconds
        key_prefix: Prefix for cache keys
        include_args: Specific arguments to include in key generation
        tags: Tags for cache invalidation
        instance_cache: Use instance-level cache instead of global
    
    Usage:
        class UserService:
            @cache_method(ttl=300, key_prefix="user")
            async def get_user(self, user_id: int):
                # Expensive operation
                return user_data
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs):
            service = await get_cache_service()
            
            # Generate cache key
            if include_args:
                cache_key = CacheKeyGenerator.args_key(
                    include_args, f"{self.__class__.__name__}.{func.__name__}", 
                    args, kwargs
                )
            elif key_prefix:
                cache_key = CacheKeyGenerator.prefix_key(
                    key_prefix, f"{self.__class__.__name__}.{func.__name__}", 
                    args, kwargs
                )
            else:
                cache_key = CacheKeyGenerator.simple_key(
                    f"{self.__class__.__name__}.{func.__name__}", args, kwargs
                )
            
            # Try to get from cache
            cached_value = await service.get(cache_key)
            if cached_value is not None:
                return cached_value
            
            # Execute method
            if asyncio.iscoroutinefunction(func):
                result = await func(self, *args, **kwargs)
            else:
                result = func(self, *args, **kwargs)
            
            # Cache the result
            if result is not None:
                await service.set(cache_key, result, ttl=ttl, tags=tags)
            
            return result
        
        return wrapper
    return decorator


def cache_property(ttl: Optional[int] = None, key_prefix: Optional[str] = None):
    """
    Decorator for caching property results.
    
    Usage:
        class User:
            @cache_property(ttl=3600)
            def full_name(self):
                return f"{self.first_name} {self.last_name}"
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self):
            # Generate cache key
            cache_key = f"{self.__class__.__name__}:{func.__name__}"
            if key_prefix:
                cache_key = f"{key_prefix}:{cache_key}"
            
            service = get_cache_service()
            
            # Try to get from cache
            if hasattr(self, '_cached_properties'):
                cached_value = self._cached_properties.get(cache_key)
                if cached_value is not None:
                    return cached_value
            else:
                self._cached_properties = {}
            
            # Execute function
            result = func(self)
            
            # Cache the result
            self._cached_properties[cache_key] = result
            
            return result
        
        return wrapper
    return decorator


def memoize(ttl: Optional[int] = None):
    """
    Simple memoization decorator for synchronous functions.
    
    Usage:
        @memoize(ttl=300)
        def fibonacci(n):
            if n <= 1:
                return n
            return fibonacci(n-1) + fibonacci(n-2)
    """
    cache = {}
    locks = {}
    
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key
            key = str(args) + str(sorted(kwargs.items()))
            
            # Check cache
            if key in cache:
                value, timestamp = cache[key]
                if ttl is None or time.time() - timestamp < ttl:
                    return value
            
            # Execute function
            result = func(*args, **kwargs)
            
            # Update cache
            cache[key] = (result, time.time())
            
            # Clean expired entries if no TTL
            if ttl is None and len(cache) > 100:
                current_time = time.time()
                expired_keys = [
                    k for k, (_, timestamp) in cache.items()
                    if current_time - timestamp > 3600
                ]
                for k in expired_keys:
                    cache.pop(k, None)
            
            return result
        
        return wrapper
    return decorator


async def cache_invalidate(
    pattern: Optional[str] = None,
    tags: Optional[List[str]] = None,
    key: Optional[str] = None
):
    """
    Invalidate cache entries by pattern or tags.
    
    Args:
        pattern: Key pattern to match
        tags: Tags to invalidate
        key: Specific key to delete
    
    Usage:
        await cache_invalidate(pattern="user:*", tags=['user'])
        await cache_invalidate(key="specific_key")
    """
    service = await get_cache_service()
    
    if key:
        await service.delete(key)
    elif pattern:
        await service.clear_by_pattern(pattern)
    elif tags:
        await service.invalidate_by_tags(tags)


class CacheContext:
    """Context manager for temporary cache operations."""
    
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.original_service = None
        self.temp_service = None
    
    async def __aenter__(self):
        if not self.enabled:
            return self
        
        from app.services.cache_service import InMemoryFallbackCache
        
        # Create temporary in-memory cache
        self.temp_service = InMemoryFallbackCache(max_size=1000)
        return self.temp_service
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.temp_service:
            await self.temp_service.clear()


def with_cache_disabled():
    """Context manager to temporarily disable caching."""
    return CacheContext(enabled=False)


class CacheStatsCollector:
    """Collect cache statistics over time."""
    
    def __init__(self, interval: int = 60):
        self.interval = interval
        self.stats_history = []
        self.collecting = False
        self.task = None
    
    async def start(self):
        """Start collecting statistics."""
        if self.collecting:
            return
        
        self.collecting = True
        self.task = asyncio.create_task(self._collect_loop())
    
    async def stop(self):
        """Stop collecting statistics."""
        self.collecting = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
    
    async def _collect_loop(self):
        """Internal collection loop."""
        while self.collecting:
            try:
                service = await get_cache_service()
                stats = await service.get_stats()
                
                self.stats_history.append({
                    'timestamp': time.time(),
                    'stats': stats.to_dict() if hasattr(stats, 'to_dict') else stats.__dict__
                })
                
                # Keep only last 1000 entries
                if len(self.stats_history) > 1000:
                    self.stats_history = self.stats_history[-1000:]
                
                await asyncio.sleep(self.interval)
                
            except Exception as e:
                logger.error(f"Error collecting cache stats: {e}")
                await asyncio.sleep(self.interval)
    
    def get_recent_stats(self, count: int = 10) -> List[Dict]:
        """Get recent statistics."""
        return self.stats_history[-count:] if self.stats_history else []
    
    def get_stats_summary(self) -> Dict:
        """Get statistics summary."""
        if not self.stats_history:
            return {}
        
        recent = self.get_recent_stats(10)
        if not recent:
            return {}
        
        # Calculate averages
        total_hits = sum(s['stats'].get('hits', 0) for s in recent)
        total_misses = sum(s['stats'].get('misses', 0) for s in recent)
        
        return {
            'total_operations': total_hits + total_misses,
            'total_hits': total_hits,
            'total_misses': total_misses,
            'hit_rate': total_hits / (total_hits + total_misses) if (total_hits + total_misses) > 0 else 0,
            'samples': len(recent),
            'first_sample': recent[0]['timestamp'],
            'last_sample': recent[-1]['timestamp'],
        }


# Global stats collector
stats_collector = CacheStatsCollector()


# Export decorators and utilities
__all__ = [
    'CacheKey',
    'CacheKeyGenerator',
    'cache_result',
    'cache_method',
    'cache_property',
    'memoize',
    'cache_invalidate',
    'with_cache_disabled',
    'CacheStatsCollector',
    'stats_collector'
]
