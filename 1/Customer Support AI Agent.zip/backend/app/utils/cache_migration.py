"""
Cache Migration and Backup Utilities.

This module provides utilities for migrating cache data between different backends,
creating backups, restoring cache data, and managing cache lifecycle operations.
"""

import asyncio
import json
import logging
import pickle
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Iterator
from dataclasses import dataclass, asdict
import hashlib

from app.services.cache_service import get_cache_service
from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class CacheBackupMetadata:
    """Metadata for cache backup."""
    backup_id: str
    created_at: float
    version: str
    total_keys: int
    total_size_bytes: int
    backend_type: str
    tags: List[str]
    compression_enabled: bool
    encryption_enabled: bool
    description: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CacheMigrator:
    """Migrate cache data between different backends."""
    
    def __init__(self, source_service=None, target_service=None):
        self.source_service = source_service
        self.target_service = target_service
        self.migration_stats = {
            'total_keys': 0,
            'migrated_keys': 0,
            'failed_keys': 0,
            'skipped_keys': 0,
            'start_time': None,
            'end_time': None
        }
    
    async def migrate_all(
        self,
        pattern: Optional[str] = None,
        key_filter: Optional[callable] = None,
        preserve_ttl: bool = True,
        batch_size: int = 1000,
        dry_run: bool = False
    ) -> Dict[str, Any]:
        """
        Migrate all cache data from source to target.
        
        Args:
            pattern: Key pattern to migrate (default: all keys)
            key_filter: Function to filter keys to migrate
            preserve_ttl: Whether to preserve TTL during migration
            batch_size: Number of keys to process per batch
            dry_run: If True, only report what would be migrated
        
        Returns:
            Migration statistics
        """
        if not self.source_service:
            self.source_service = await get_cache_service()
        
        if not self.target_service:
            self.target_service = await get_cache_service()
        
        self.migration_stats = {
            'total_keys': 0,
            'migrated_keys': 0,
            'failed_keys': 0,
            'skipped_keys': 0,
            'start_time': time.time(),
            'end_time': None,
            'dry_run': dry_run,
            'pattern': pattern,
            'preserve_ttl': preserve_ttl
        }
        
        try:
            logger.info("Starting cache migration")
            
            # Get all keys from source
            if pattern:
                keys = await self.source_service.get_keys_by_pattern(pattern)
            else:
                # Get all keys (this might be expensive for large caches)
                keys = await self._get_all_keys_from_source()
            
            # Apply key filter if provided
            if key_filter:
                keys = [key for key in keys if key_filter(key)]
            
            self.migration_stats['total_keys'] = len(keys)
            logger.info(f"Found {len(keys)} keys to migrate")
            
            # Migrate in batches
            for i in range(0, len(keys), batch_size):
                batch = keys[i:i + batch_size]
                await self._migrate_batch(batch, preserve_ttl, dry_run)
                
                # Log progress
                progress = min(i + batch_size, len(keys))
                logger.info(f"Migration progress: {progress}/{len(keys)} ({progress/len(keys)*100:.1f}%)")
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            self.migration_stats['errors'] = str(e)
        
        finally:
            self.migration_stats['end_time'] = time.time()
            self.migration_stats['duration_seconds'] = (
                self.migration_stats['end_time'] - self.migration_stats['start_time']
            )
            logger.info("Cache migration completed")
        
        return self.migration_stats
    
    async def migrate_by_tags(
        self,
        tags: List[str],
        target_tags: Optional[List[str]] = None,
        preserve_ttl: bool = True,
        dry_run: bool = False
    ) -> Dict[str, Any]:
        """Migrate cache entries by tags."""
        if not self.source_service:
            self.source_service = await get_cache_service()
        
        if not self.target_service:
            self.target_service = await get_cache_service()
        
        self.migration_stats = {
            'total_keys': 0,
            'migrated_keys': 0,
            'failed_keys': 0,
            'skipped_keys': 0,
            'start_time': time.time(),
            'end_time': None,
            'dry_run': dry_run,
            'tags': tags,
            'target_tags': target_tags or tags
        }
        
        try:
            logger.info(f"Starting migration by tags: {tags}")
            
            # Get all keys for each tag
            all_keys = set()
            for tag in tags:
                if self.source_service.tag_manager:
                    tag_keys = await self.source_service.tag_manager.get_keys_by_tag(tag)
                    all_keys.update(tag_keys)
                else:
                    logger.warning(f"No tag manager available for tag: {tag}")
            
            keys = list(all_keys)
            self.migration_stats['total_keys'] = len(keys)
            logger.info(f"Found {len(keys)} keys to migrate for tags: {tags}")
            
            # Migrate keys
            for key in keys:
                await self._migrate_single_key(key, preserve_ttl, dry_run, target_tags)
            
        except Exception as e:
            logger.error(f"Tag migration failed: {e}")
            self.migration_stats['errors'] = str(e)
        
        finally:
            self.migration_stats['end_time'] = time.time()
            self.migration_stats['duration_seconds'] = (
                self.migration_stats['end_time'] - self.migration_stats['start_time']
            )
            logger.info("Tag migration completed")
        
        return self.migration_stats
    
    async def _get_all_keys_from_source(self) -> List[str]:
        """Get all keys from source cache."""
        try:
            # This is implementation-specific and may vary by backend
            if hasattr(self.source_service, 'redis_client') and self.source_service.redis_client:
                # For Redis, we can scan all keys
                keys = []
                cursor = 0
                while True:
                    cursor, partial_keys = await self.source_service.redis_client.scan(
                        cursor=cursor,
                        match='*',
                        count=1000
                    )
                    keys.extend([k.decode('utf-8') if isinstance(k, bytes) else k for k in partial_keys])
                    if cursor == 0:
                        break
                return keys
            else:
                # Fallback for other backends
                return []
        except Exception as e:
            logger.error(f"Failed to get all keys: {e}")
            return []
    
    async def _migrate_batch(self, keys: List[str], preserve_ttl: bool, dry_run: bool):
        """Migrate a batch of keys."""
        batch_stats = {'success': 0, 'failed': 0}
        
        for key in keys:
            success = await self._migrate_single_key(key, preserve_ttl, dry_run)
            if success:
                batch_stats['success'] += 1
            else:
                batch_stats['failed'] += 1
        
        self.migration_stats['migrated_keys'] += batch_stats['success']
        self.migration_stats['failed_keys'] += batch_stats['failed']
    
    async def _migrate_single_key(
        self,
        key: str,
        preserve_ttl: bool,
        dry_run: bool,
        target_tags: Optional[List[str]] = None
    ) -> bool:
        """Migrate a single key."""
        try:
            # Get value and metadata from source
            value = await self.source_service.get(key)
            if value is None:
                self.migration_stats['skipped_keys'] += 1
                return False
            
            # Get TTL if preserving
            ttl = None
            if preserve_ttl:
                ttl = await self.source_service.get_ttl(key)
            
            # Get tags if source has tag manager
            tags = target_tags
            if tags is None and self.source_service.tag_manager:
                # This would require getting the tags for the specific key
                # Implementation depends on tag manager structure
                tags = []
            
            # Migrate to target (or simulate if dry run)
            if not dry_run:
                success = await self.target_service.set(
                    key=key,
                    value=value,
                    ttl=ttl,
                    tags=tags
                )
                
                if not success:
                    self.migration_stats['failed_keys'] += 1
                    return False
            
            self.migration_stats['migrated_keys'] += 1
            return True
            
        except Exception as e:
            logger.error(f"Failed to migrate key {key}: {e}")
            self.migration_stats['failed_keys'] += 1
            return False


class CacheBackup:
    """Create and manage cache backups."""
    
    def __init__(self, service=None, backup_dir: Optional[Path] = None):
        self.service = service
        self.backup_dir = backup_dir or Path(settings.upload_permanent_path) / "cache_backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    async def create_backup(
        self,
        pattern: Optional[str] = None,
        include_metadata: bool = True,
        compress: bool = True,
        encryption_key: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> CacheBackupMetadata:
        """
        Create a backup of cache data.
        
        Args:
            pattern: Key pattern to backup (default: all keys)
            include_metadata: Include TTL and tags metadata
            compress: Compress backup file
            encryption_key: Key for encryption (if None, no encryption)
            description: Backup description
            tags: Tags for the backup
        
        Returns:
            Backup metadata
        """
        if not self.service:
            self.service = await get_cache_service()
        
        backup_id = self._generate_backup_id()
        timestamp = time.time()
        
        # Create backup file
        backup_file = self.backup_dir / f"{backup_id}.cache"
        
        try:
            logger.info(f"Creating cache backup: {backup_id}")
            
            # Get all keys
            if pattern:
                keys = await self.service.get_keys_by_pattern(pattern)
            else:
                keys = await self._get_all_keys_backup()
            
            # Prepare backup data
            backup_data = {
                'metadata': {
                    'backup_id': backup_id,
                    'created_at': timestamp,
                    'version': '1.0',
                    'pattern': pattern,
                    'include_metadata': include_metadata,
                    'compression': compress,
                    'encryption': encryption_key is not None,
                    'description': description,
                    'tags': tags or []
                },
                'data': []
            }
            
            # Backup each key
            total_size = 0
            for key in keys:
                try:
                    # Get value
                    value = await self.service.get(key)
                    if value is None:
                        continue
                    
                    # Get metadata if requested
                    key_metadata = {}
                    if include_metadata:
                        key_metadata = {
                            'ttl': await self.service.get_ttl(key),
                            # Tags would need to be retrieved from tag manager
                        }
                    
                    # Serialize value
                    try:
                        serialized_value = json.dumps(value, default=str)
                        size_bytes = len(serialized_value.encode('utf-8'))
                    except:
                        # Fallback to pickle
                        serialized_value = pickle.dumps(value)
                        size_bytes = len(serialized_value)
                    
                    backup_data['data'].append({
                        'key': key,
                        'value': serialized_value,
                        'metadata': key_metadata,
                        'size_bytes': size_bytes
                    })
                    
                    total_size += size_bytes
                    
                except Exception as e:
                    logger.warning(f"Failed to backup key {key}: {e}")
            
            # Write backup file
            backup_content = json.dumps(backup_data)
            
            if compress:
                import gzip
                backup_content = gzip.compress(backup_content.encode('utf-8'))
            
            if encryption_key:
                # Simple encryption (in production, use proper encryption)
                backup_content = self._simple_encrypt(backup_content, encryption_key)
            
            backup_file.write_bytes(backup_content)
            
            # Create metadata file
            metadata = CacheBackupMetadata(
                backup_id=backup_id,
                created_at=timestamp,
                version='1.0',
                total_keys=len(backup_data['data']),
                total_size_bytes=total_size,
                backend_type='redis',
                tags=tags or [],
                compression_enabled=compress,
                encryption_enabled=encryption_key is not None,
                description=description
            )
            
            metadata_file = self.backup_dir / f"{backup_id}.metadata.json"
            metadata_file.write_text(json.dumps(metadata.to_dict(), indent=2))
            
            logger.info(f"Backup created successfully: {backup_id}")
            return metadata
            
        except Exception as e:
            logger.error(f"Backup creation failed: {e}")
            # Cleanup partial backup
            if backup_file.exists():
                backup_file.unlink()
            raise
    
    async def restore_backup(
        self,
        backup_id: str,
        pattern: Optional[str] = None,
        key_filter: Optional[callable] = None,
        dry_run: bool = False,
        overwrite_existing: bool = True
    ) -> Dict[str, Any]:
        """
        Restore cache data from backup.
        
        Args:
            backup_id: ID of backup to restore
            pattern: Key pattern to restore (default: all keys)
            key_filter: Function to filter keys to restore
            dry_run: If True, only report what would be restored
            overwrite_existing: Overwrite existing keys
        
        Returns:
            Restore statistics
        """
        backup_file = self.backup_dir / f"{backup_id}.cache"
        metadata_file = self.backup_dir / f"{backup_id}.metadata.json"
        
        if not backup_file.exists():
            raise FileNotFoundError(f"Backup file not found: {backup_file}")
        
        if not self.service:
            self.service = await get_cache_service()
        
        restore_stats = {
            'total_keys': 0,
            'restored_keys': 0,
            'skipped_keys': 0,
            'failed_keys': 0,
            'start_time': time.time(),
            'end_time': None,
            'backup_id': backup_id,
            'dry_run': dry_run
        }
        
        try:
            logger.info(f"Starting backup restore: {backup_id}")
            
            # Load backup data
            backup_data = self._load_backup_file(backup_file, metadata_file)
            
            # Filter data
            data_items = backup_data['data']
            
            if pattern:
                data_items = [item for item in data_items if self._match_pattern(item['key'], pattern)]
            
            if key_filter:
                data_items = [item for item in data_items if key_filter(item['key'])]
            
            restore_stats['total_keys'] = len(data_items)
            logger.info(f"Found {len(data_items)} keys to restore")
            
            # Restore keys
            for item in data_items:
                await self._restore_key(item, restore_stats, dry_run, overwrite_existing)
            
        except Exception as e:
            logger.error(f"Backup restore failed: {e}")
            restore_stats['errors'] = str(e)
        
        finally:
            restore_stats['end_time'] = time.time()
            restore_stats['duration_seconds'] = (
                restore_stats['end_time'] - restore_stats['start_time']
            )
            logger.info("Backup restore completed")
        
        return restore_stats
    
    async def list_backups(self) -> List[CacheBackupMetadata]:
        """List all available backups."""
        backups = []
        
        try:
            metadata_files = self.backup_dir.glob("*.metadata.json")
            
            for metadata_file in metadata_files:
                try:
                    metadata_data = json.loads(metadata_file.read_text())
                    backups.append(CacheBackupMetadata(**metadata_data))
                except Exception as e:
                    logger.warning(f"Failed to load metadata from {metadata_file}: {e}")
            
            # Sort by creation time (newest first)
            backups.sort(key=lambda x: x.created_at, reverse=True)
            
        except Exception as e:
            logger.error(f"Failed to list backups: {e}")
        
        return backups
    
    async def delete_backup(self, backup_id: str) -> bool:
        """Delete a backup."""
        try:
            backup_file = self.backup_dir / f"{backup_id}.cache"
            metadata_file = self.backup_dir / f"{backup_id}.metadata.json"
            
            deleted = False
            if backup_file.exists():
                backup_file.unlink()
                deleted = True
            
            if metadata_file.exists():
                metadata_file.unlink()
                deleted = True
            
            if deleted:
                logger.info(f"Backup deleted: {backup_id}")
            
            return deleted
            
        except Exception as e:
            logger.error(f"Failed to delete backup {backup_id}: {e}")
            return False
    
    async def cleanup_old_backups(self, retention_days: int = 30) -> int:
        """Clean up old backups based on retention policy."""
        try:
            backups = await self.list_backups()
            cutoff_time = time.time() - (retention_days * 24 * 3600)
            
            deleted_count = 0
            for backup in backups:
                if backup.created_at < cutoff_time:
                    success = await self.delete_backup(backup.backup_id)
                    if success:
                        deleted_count += 1
            
            logger.info(f"Cleaned up {deleted_count} old backups")
            return deleted_count
            
        except Exception as e:
            logger.error(f"Failed to cleanup old backups: {e}")
            return 0
    
    def _generate_backup_id(self) -> str:
        """Generate unique backup ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = hashlib.md5(str(time.time()).encode()).hexdigest()[:8]
        return f"backup_{timestamp}_{random_suffix}"
    
    async def _get_all_keys_backup(self) -> List[str]:
        """Get all keys for backup (implementation-specific)."""
        try:
            if hasattr(self.service, 'redis_client') and self.service.redis_client:
                keys = []
                cursor = 0
                while True:
                    cursor, partial_keys = await self.service.redis_client.scan(
                        cursor=cursor,
                        match='*',
                        count=1000
                    )
                    keys.extend([k.decode('utf-8') if isinstance(k, bytes) else k for k in partial_keys])
                    if cursor == 0:
                        break
                return keys
            return []
        except Exception as e:
            logger.error(f"Failed to get keys for backup: {e}")
            return []
    
    def _load_backup_file(self, backup_file: Path, metadata_file: Path) -> Dict[str, Any]:
        """Load backup data from file."""
        try:
            backup_content = backup_file.read_bytes()
            
            # Decrypt if needed
            if metadata_file.exists():
                metadata_data = json.loads(metadata_file.read_text())
                if metadata_data.get('encryption_enabled'):
                    # This would need the encryption key - simplified for demo
                    pass
            
            # Decompress if needed
            if metadata_data.get('compression_enabled'):
                import gzip
                backup_content = gzip.decompress(backup_content)
            
            backup_data = json.loads(backup_content.decode('utf-8'))
            return backup_data
            
        except Exception as e:
            logger.error(f"Failed to load backup file: {e}")
            raise
    
    def _simple_encrypt(self, data: bytes, key: str) -> bytes:
        """Simple encryption (for demonstration - use proper encryption in production)."""
        # This is a simplified encryption - in production, use proper encryption libraries
        key_bytes = key.encode('utf-8')
        encrypted = bytearray()
        
        for i, byte in enumerate(data):
            encrypted.append(byte ^ key_bytes[i % len(key_bytes)])
        
        return bytes(encrypted)
    
    def _match_pattern(self, key: str, pattern: str) -> bool:
        """Check if key matches pattern (simple glob-like matching)."""
        # Simplified pattern matching - could use fnmatch or more sophisticated matching
        if pattern == "*":
            return True
        
        if pattern.endswith("*"):
            return key.startswith(pattern[:-1])
        
        if pattern.startswith("*"):
            return key.endswith(pattern[1:])
        
        return key == pattern
    
    async def _restore_key(self, item: Dict, stats: Dict, dry_run: bool, overwrite: bool):
        """Restore a single key from backup."""
        key = item['key']
        
        try:
            # Check if key exists and should be skipped
            if not overwrite and await self.service.exists(key):
                stats['skipped_keys'] += 1
                return
            
            # Deserialize value
            try:
                value = json.loads(item['value'])
            except:
                value = pickle.loads(item['value'].encode('utf-8') if isinstance(item['value'], str) else item['value'])
            
            # Set value
            if not dry_run:
                metadata = item.get('metadata', {})
                ttl = metadata.get('ttl')
                
                success = await self.service.set(key, value, ttl=ttl)
                if not success:
                    stats['failed_keys'] += 1
                    return
            
            stats['restored_keys'] += 1
            
        except Exception as e:
            logger.error(f"Failed to restore key {key}: {e}")
            stats['failed_keys'] += 1


# Export migration and backup classes
__all__ = [
    'CacheBackupMetadata',
    'CacheMigrator',
    'CacheBackup'
]
