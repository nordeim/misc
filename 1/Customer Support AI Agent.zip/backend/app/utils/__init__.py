"""
Utility Functions Package

This package provides comprehensive utility functions for validation, preprocessing,
and common operations used throughout the application.

Modules:
- validation_utils: Input validation, data sanitization, format validation, business rules
- preprocessing_utils: Text preprocessing, data cleaning, content normalization, format conversion  
- common_utils: Common utilities, helper classes, decorators, file system utilities, error handling
"""

# Import all utility classes and functions for easy access
from .validation_utils import (
    InputValidator,
    DataSanitizer,
    FormatValidator,
    BusinessRuleValidator,
    ValidationDecorators,
    ValidationError,
    validate_required_fields,
    validate_field_types,
    validate_field_values
)

from .preprocessing_utils import (
    TextPreprocessor,
    DataCleaner,
    ContentNormalizer,
    FormatConverter,
    PreprocessingPipeline,
    preprocess_text_for_search,
    extract_entities_from_text,
    calculate_text_similarity
)

from .common_utils import (
    ErrorHandling,
    PerformanceMonitor,
    CachingDecorators,
    FileSystemUtils,
    StringUtils,
    DataUtils,
    ConfigurationUtils,
    AsyncUtils,
    ThreadingUtils,
    LoggingUtils,
    ValidationDecorators as CommonValidationDecorators,
    TestingUtils,
    RateLimiter,
    CircuitBreaker
)

# Package metadata
__version__ = "1.0.0"
__author__ = "Backend Development Team"
__description__ = "Comprehensive utility functions for validation, preprocessing, and common operations"

# Create common instances for easy access
input_validator = InputValidator()
data_sanitizer = DataSanitizer()
text_preprocessor = TextPreprocessor()
data_cleaner = DataCleaner()
file_system_utils = FileSystemUtils()
string_utils = StringUtils()
data_utils = DataUtils()

# Export package-level functions for common use cases
def validate_email(email: str) -> bool:
    """Quick email validation"""
    return InputValidator.validate_email(email)

def validate_phone(phone: str, region: str = 'US') -> bool:
    """Quick phone validation"""
    return InputValidator.validate_phone_number(phone, region)

def sanitize_input(user_input: str) -> str:
    """Quick input sanitization"""
    return DataSanitizer.sanitize_input(user_input)

def preprocess_text(text: str) -> str:
    """Quick text preprocessing for search"""
    return preprocess_text_for_search(text)

def get_safe_filename(filename: str) -> str:
    """Quick filename sanitization"""
    return FileSystemUtils.safe_filename(filename)

def generate_id(length: int = 10) -> str:
    """Quick ID generation"""
    return StringUtils.generate_random_string(length)

# Convenience decorators
def retry(max_attempts: int = 3, delay: float = 1.0, exceptions: tuple = (Exception,)):
    """Quick retry decorator"""
    return ErrorHandling.retry(max_attempts, delay, exceptions=exceptions)

def timeout(seconds: float):
    """Quick timeout decorator"""
    return ErrorHandling.timeout(seconds)

def measure_time(func):
    """Quick performance monitoring decorator"""
    return PerformanceMonitor.measure_time(func)

def cache_file(cache_dir: str, max_age: int = 3600):
    """Quick file caching decorator"""
    return CachingDecorators.file_cache(cache_dir, max_age)

def safe_execute(fallback_return=None):
    """Quick safe execution decorator"""
    return ErrorHandling.safe_execute(fallback_return)

def log_calls(func):
    """Quick logging decorator"""
    return LoggingUtils.log_function_call(func)

# Common configuration presets
VALIDATION_CONFIG = {
    'email_validation': True,
    'phone_validation': True,
    'password_min_length': 8,
    'file_type_restrictions': True,
    'max_file_size_mb': {
        'image': 10,
        'document': 50,
        'audio': 100,
        'video': 500
    }
}

PREPROCESSING_CONFIG = {
    'remove_stopwords': True,
    'lemmatize': True,
    'normalize_unicode': True,
    'remove_special_chars': False,
    'max_text_length': 10000
}

COMMON_CONFIG = {
    'temp_dir': '/tmp/app_temp',
    'cache_dir': '/tmp/app_cache',
    'max_retries': 3,
    'timeout_seconds': 30,
    'log_level': 'INFO'
}

# Quick setup functions
def setup_logging(name: str = 'app', level: str = 'INFO', log_file: str = None):
    """Quick logging setup"""
    return LoggingUtils.setup_logger(name, level, log_file)

def load_config(config_path: str) -> dict:
    """Quick configuration loading"""
    return ConfigurationUtils.load_json_config(config_path)

def create_preprocessing_pipeline(steps: list = None):
    """Quick preprocessing pipeline creation"""
    if steps is None:
        steps = [
            (TextPreprocessor.clean_text, {}),
            (TextPreprocessor.normalize_text, {}),
            (TextPreprocessor.remove_stopwords, {})
        ]
    
    pipeline = PreprocessingPipeline()
    for step_func, step_kwargs in steps:
        pipeline.add_step(step_func, **step_kwargs)
    
    return pipeline

# Validation helpers for common data types
USER_VALIDATION_RULES = {
    'username': {
        'required': True,
        'type': str,
        'min_length': 3,
        'max_length': 30,
        'pattern': r'^[a-zA-Z0-9_]+$'
    },
    'email': {
        'required': True,
        'type': str,
        'validation': InputValidator.validate_email
    },
    'password': {
        'required': True,
        'type': str,
        'min_length': 8,
        'validation': lambda p: InputValidator.validate_password(p)['is_valid']
    },
    'age': {
        'required': False,
        'type': int,
        'min': 13,
        'max': 120
    }
}

FILE_VALIDATION_RULES = {
    'filename': {
        'required': True,
        'type': str,
        'sanitizer': DataSanitizer.sanitize_filename
    },
    'content_type': {
        'required': True,
        'type': str,
        'allowed_values': ['image/jpeg', 'image/png', 'application/pdf', 'text/plain']
    },
    'size': {
        'required': True,
        'type': int,
        'max': 50 * 1024 * 1024  # 50MB
    }
}

# Export everything for comprehensive access
__all__ = [
    # Core utility classes
    'InputValidator',
    'DataSanitizer', 
    'FormatValidator',
    'BusinessRuleValidator',
    'ValidationDecorators',
    'ValidationError',
    
    'TextPreprocessor',
    'DataCleaner',
    'ContentNormalizer',
    'FormatConverter',
    'PreprocessingPipeline',
    
    'ErrorHandling',
    'PerformanceMonitor',
    'CachingDecorators',
    'FileSystemUtils',
    'StringUtils',
    'DataUtils',
    'ConfigurationUtils',
    'AsyncUtils',
    'ThreadingUtils',
    'LoggingUtils',
    'TestingUtils',
    'RateLimiter',
    'CircuitBreaker',
    
    # Convenience instances
    'input_validator',
    'data_sanitizer',
    'text_preprocessor',
    'data_cleaner',
    'file_system_utils',
    'string_utils',
    'data_utils',
    
    # Quick functions
    'validate_email',
    'validate_phone',
    'sanitize_input',
    'preprocess_text',
    'get_safe_filename',
    'generate_id',
    
    # Quick decorators
    'retry',
    'timeout',
    'measure_time',
    'cache_file',
    'safe_execute',
    'log_calls',
    
    # Configuration
    'VALIDATION_CONFIG',
    'PREPROCESSING_CONFIG', 
    'COMMON_CONFIG',
    
    # Setup functions
    'setup_logging',
    'load_config',
    'create_preprocessing_pipeline',
    
    # Validation rules
    'USER_VALIDATION_RULES',
    'FILE_VALIDATION_RULES'
]