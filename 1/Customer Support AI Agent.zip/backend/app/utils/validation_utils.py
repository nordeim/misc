"""
Validation Utilities Module

This module provides comprehensive validation utilities for input validation,
data sanitization, format validation, and business rule validation.
"""

import re
import html
import json
import logging
from typing import Any, Dict, List, Optional, Union, Callable, Type
from datetime import datetime, date
from urllib.parse import urlparse
try:
    from email_validator import validate_email, EmailNotValidError
    EMAIL_VALIDATOR_AVAILABLE = True
except ImportError:
    EMAIL_VALIDATOR_AVAILABLE = False

try:
    from pydantic import ValidationError, validator, BaseModel
    PYDANTIC_AVAILABLE = True
except ImportError:
    PYDANTIC_AVAILABLE = False

try:
    import phonenumbers
    from phonenumbers import NumberParseException
    PHONE_VALIDATOR_AVAILABLE = True
except ImportError:
    PHONE_VALIDATOR_AVAILABLE = False

try:
    import bleach
    BLEACH_AVAILABLE = True
except ImportError:
    BLEACH_AVAILABLE = False

# Set up basic ValidationError if pydantic is not available
if not PYDANTIC_AVAILABLE:
    class ValidationError(Exception):
        """Basic validation error when pydantic is not available"""
        pass

logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Custom validation error exception"""
    pass


class InputValidator:
    """Main input validation class with comprehensive validation methods"""
    
    # Common patterns for validation
    EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    PHONE_PATTERN = re.compile(r'^\+?1?[-.\s]?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$')
    PASSWORD_PATTERN = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$')
    URL_PATTERN = re.compile(r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w)*)?)?')
    USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9_]{3,30}$')
    
    # File type restrictions
    ALLOWED_IMAGE_TYPES = {'image/jpeg', 'image/png', 'image/gif', 'image/webp'}
    ALLOWED_DOCUMENT_TYPES = {'application/pdf', 'text/plain', 'application/msword', 
                             'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}
    ALLOWED_AUDIO_TYPES = {'audio/mpeg', 'audio/wav', 'audio/ogg'}
    ALLOWED_VIDEO_TYPES = {'video/mp4', 'video/avi', 'video/mov'}
    
    # Content size limits (in bytes)
    MAX_IMAGE_SIZE = 10 * 1024 * 1024  # 10MB
    MAX_DOCUMENT_SIZE = 50 * 1024 * 1024  # 50MB
    MAX_AUDIO_SIZE = 100 * 1024 * 1024  # 100MB
    MAX_VIDEO_SIZE = 500 * 1024 * 1024  # 500MB

    @classmethod
    def validate_email(cls, email: str) -> bool:
        """Validate email format and existence"""
        if not EMAIL_VALIDATOR_AVAILABLE:
            # Fallback validation using regex when email-validator is not available
            pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            return bool(pattern.match(email.strip()))
        
        try:
            validate_email(email)
            return True
        except EmailNotValidError:
            return False

    @classmethod
    def validate_phone_number(cls, phone: str, region: str = 'US') -> bool:
        """Validate phone number format"""
        if not PHONE_VALIDATOR_AVAILABLE:
            # Fallback validation using regex when phonenumbers is not available
            pattern = re.compile(r'^\+?1?[-.\s]?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$')
            return bool(pattern.match(phone))
        
        try:
            parsed = phonenumbers.parse(phone, region)
            return phonenumbers.is_valid_number(parsed)
        except NumberParseException:
            return False

    @classmethod
    def validate_url(cls, url: str) -> bool:
        """Validate URL format and accessibility"""
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except Exception:
            return False

    @classmethod
    def validate_username(cls, username: str) -> bool:
        """Validate username format"""
        return bool(cls.USERNAME_PATTERN.match(username))

    @classmethod
    def validate_password(cls, password: str, min_length: int = 8) -> Dict[str, Any]:
        """Validate password strength and return detailed feedback"""
        feedback = {
            'is_valid': True,
            'errors': [],
            'score': 0
        }
        
        if len(password) < min_length:
            feedback['errors'].append(f'Password must be at least {min_length} characters long')
            feedback['is_valid'] = False
        
        if not re.search(r'[a-z]', password):
            feedback['errors'].append('Password must contain at least one lowercase letter')
            feedback['is_valid'] = False
        
        if not re.search(r'[A-Z]', password):
            feedback['errors'].append('Password must contain at least one uppercase letter')
            feedback['is_valid'] = False
        
        if not re.search(r'\d', password):
            feedback['errors'].append('Password must contain at least one digit')
            feedback['is_valid'] = False
        
        if not re.search(r'[@$!%*?&]', password):
            feedback['errors'].append('Password must contain at least one special character')
            feedback['is_valid'] = False
        
        # Calculate password strength score
        score = 0
        if len(password) >= 8:
            score += 20
        if len(password) >= 12:
            score += 10
        if re.search(r'[a-z]', password):
            score += 15
        if re.search(r'[A-Z]', password):
            score += 15
        if re.search(r'\d', password):
            score += 15
        if re.search(r'[@$!%*?&]', password):
            score += 15
        if len(password) >= 16:
            score += 10
        
        feedback['score'] = min(score, 100)
        return feedback

    @classmethod
    def validate_file_type(cls, content_type: str, file_type_category: str = 'image') -> bool:
        """Validate file type based on category"""
        allowed_types = {
            'image': cls.ALLOWED_IMAGE_TYPES,
            'document': cls.ALLOWED_DOCUMENT_TYPES,
            'audio': cls.ALLOWED_AUDIO_TYPES,
            'video': cls.ALLOWED_VIDEO_TYPES
        }
        
        return content_type in allowed_types.get(file_type_category, set())

    @classmethod
    def validate_file_size(cls, file_size: int, file_type_category: str = 'image') -> bool:
        """Validate file size based on category"""
        size_limits = {
            'image': cls.MAX_IMAGE_SIZE,
            'document': cls.MAX_DOCUMENT_SIZE,
            'audio': cls.MAX_AUDIO_SIZE,
            'video': cls.MAX_VIDEO_SIZE
        }
        
        return file_size <= size_limits.get(file_type_category, cls.MAX_IMAGE_SIZE)

    @classmethod
    def validate_date_range(cls, start_date: date, end_date: date) -> bool:
        """Validate date range"""
        return start_date <= end_date

    @classmethod
    def validate_age(cls, birth_date: date, min_age: int = 13, max_age: int = 120) -> bool:
        """Validate age based on birth date"""
        today = date.today()
        age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        return min_age <= age <= max_age

    @classmethod
    def validate_ip_address(cls, ip: str) -> bool:
        """Validate IP address format"""
        parts = ip.split('.')
        return len(parts) == 4 and all(0 <= int(part) <= 255 for part in parts)

    @classmethod
    def validate_json_format(cls, json_string: str) -> bool:
        """Validate JSON format"""
        try:
            json.loads(json_string)
            return True
        except (json.JSONDecodeError, TypeError):
            return False


class DataSanitizer:
    """Data sanitization utilities to prevent injection attacks and data corruption"""
    
    # HTML tags to allow
    ALLOWED_TAGS = ['p', 'br', 'strong', 'em', 'u', 'ol', 'ul', 'li', 'a']
    ALLOWED_ATTRIBUTES = {
        'a': ['href', 'title'],
        'p': ['style'],
        'strong': ['style'],
        'em': ['style'],
        'u': ['style']
    }

    @classmethod
    def sanitize_html(cls, html_content: str, allowed_tags: List[str] = None) -> str:
        """Sanitize HTML content to prevent XSS attacks"""
        if not BLEACH_AVAILABLE:
            # Fallback: Simple HTML tag removal when bleach is not available
            import re
            return re.sub(r'<[^>]+>', '', html_content)
        
        return bleach.clean(
            html_content,
            tags=allowed_tags or cls.ALLOWED_TAGS,
            attributes=cls.ALLOWED_ATTRIBUTES,
            protocols=['http', 'https', 'mailto'],
            strip=True
        )

    @classmethod
    def sanitize_input(cls, user_input: str) -> str:
        """Basic input sanitization"""
        if not isinstance(user_input, str):
            return str(user_input)
        
        # Remove null bytes and control characters
        sanitized = ''.join(char for char in user_input if ord(char) >= 32 or char in ['\n', '\r', '\t'])
        
        # HTML escape
        sanitized = html.escape(sanitized)
        
        # Remove potential SQL injection patterns
        sql_patterns = [
            r'\b(union|select|insert|update|delete|drop|create|alter)\b',
            r'[\'";].*?[\'";]',
            r'--.*?$',
            r'/\*.*?\*/',
            r'\bor\b\s+\d+\s*=\s*\d+',
            r'\band\b\s+\d+\s*=\s*\d+'
        ]
        
        for pattern in sql_patterns:
            sanitized = re.sub(pattern, '', sanitized, flags=re.IGNORECASE | re.MULTILINE)
        
        return sanitized.strip()

    @classmethod
    def sanitize_filename(cls, filename: str) -> str:
        """Sanitize filename to prevent path traversal"""
        # Remove path traversal attempts
        sanitized = re.sub(r'\.\./', '', filename)
        
        # Remove or replace dangerous characters
        sanitized = re.sub(r'[<>:"/\\|?*]', '_', sanitized)
        
        # Limit length
        if len(sanitized) > 255:
            name, ext = sanitized.rsplit('.', 1) if '.' in sanitized else (sanitized, '')
            sanitized = f"{name[:250-len(ext)]}.{ext}" if ext else sanitized[:255]
        
        return sanitized.strip()

    @classmethod
    def sanitize_email(cls, email: str) -> str:
        """Sanitize email address"""
        return email.lower().strip()

    @classmethod
    def sanitize_phone_number(cls, phone: str) -> str:
        """Sanitize phone number"""
        # Remove all non-numeric characters except +
        sanitized = re.sub(r'[^\d+]', '', phone)
        
        # Ensure it starts with + if international
        if sanitized.startswith('+') and len(sanitized) > 1:
            return sanitized
        
        # Add +1 for US numbers if they start with 1 or 10 digits
        if len(sanitized) == 10:
            return f"+1{sanitized}"
        
        return sanitized

    @classmethod
    def sanitize_text(cls, text: str, remove_special_chars: bool = False) -> str:
        """General text sanitization"""
        if not isinstance(text, str):
            return str(text)
        
        # Remove control characters
        sanitized = ''.join(char for char in text if ord(char) >= 32 or char in ['\n', '\r', '\t'])
        
        if remove_special_chars:
            # Keep only alphanumeric, spaces, and basic punctuation
            sanitized = re.sub(r'[^a-zA-Z0-9\s.,!?-]', '', sanitized)
        
        return sanitized.strip()

    @classmethod
    def sanitize_json(cls, json_data: Union[str, Dict, List]) -> str:
        """Sanitize JSON data"""
        if isinstance(json_data, str):
            # Clean the JSON string first
            cleaned = re.sub(r'[^\x20-\x7E]', '', json_data)  # Keep only printable ASCII
            return cleaned
        
        # For dict/list objects, serialize and clean
        try:
            json_str = json.dumps(json_data, ensure_ascii=False)
            return re.sub(r'[^\x20-\x7E]', '', json_str)
        except (TypeError, ValueError):
            return str(json_data)


class FormatValidator:
    """Format validation utilities for common data formats"""
    
    @classmethod
    def validate_date_format(cls, date_string: str, format_str: str = '%Y-%m-%d') -> bool:
        """Validate date format"""
        try:
            datetime.strptime(date_string, format_str)
            return True
        except ValueError:
            return False

    @classmethod
    def validate_uuid_format(cls, uuid_string: str) -> bool:
        """Validate UUID format"""
        pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
        return bool(pattern.match(uuid_string.lower()))

    @classmethod
    def validate_credit_card_format(cls, card_number: str) -> bool:
        """Validate credit card number format using Luhn algorithm"""
        # Remove spaces and dashes
        digits = re.sub(r'[\s-]', '', card_number)
        
        # Check if all digits
        if not digits.isdigit():
            return False
        
        # Luhn algorithm
        def luhn_checksum(card_num):
            def digits_of(number):
                return [int(d) for d in str(number)]
            digits = digits_of(card_num)
            odd_digits = digits[-1::-2]
            even_digits = digits[-2::-2]
            checksum = sum(odd_digits)
            for digit in even_digits:
                checksum += sum(digits_of(digit * 2))
            return checksum % 10
        
        return len(digits) >= 13 and len(digits) <= 19 and luhn_checksum(digits) == 0

    @classmethod
    def validate_postal_code(cls, postal_code: str, country_code: str = 'US') -> bool:
        """Validate postal code format"""
        patterns = {
            'US': r'^\d{5}(-\d{4})?$',
            'UK': r'^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$',
            'CA': r'^[A-Z]\d[A-Z]\s?\d[A-Z]\d$',
            'DE': r'^\d{5}$',
            'FR': r'^\d{5}$'
        }
        
        pattern = patterns.get(country_code.upper(), patterns['US'])
        return bool(re.match(pattern, postal_code.upper()))

    @classmethod
    def validate_coordinates(cls, latitude: float, longitude: float) -> bool:
        """Validate GPS coordinates"""
        return -90 <= latitude <= 90 and -180 <= longitude <= 180

    @classmethod
    def validate_color_code(cls, color_code: str) -> bool:
        """Validate color code (hex, rgb, rgba)"""
        hex_pattern = re.compile(r'^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$')
        rgb_pattern = re.compile(r'^rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)$')
        rgba_pattern = re.compile(r'^rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*[\d.]+\s*\)$')
        
        return any(pattern.match(color_code) for pattern in [hex_pattern, rgb_pattern, rgba_pattern])


class BusinessRuleValidator:
    """Business rule validation utilities"""
    
    @classmethod
    def validate_user_registration(cls, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate user registration data according to business rules"""
        errors = []
        warnings = []
        
        # Age restrictions
        if 'birth_date' in user_data:
            birth_date = datetime.strptime(user_data['birth_date'], '%Y-%m-%d').date()
            if not InputValidator.validate_age(birth_date):
                errors.append("User must be at least 13 years old to register")
        
        # Username uniqueness (would need database check)
        if 'username' in user_data:
            if len(user_data['username']) < 3:
                errors.append("Username must be at least 3 characters long")
            if not InputValidator.validate_username(user_data['username']):
                errors.append("Username contains invalid characters")
        
        # Email validation
        if 'email' in user_data:
            if not InputValidator.validate_email(user_data['email']):
                errors.append("Invalid email format")
        
        # Password strength
        if 'password' in user_data:
            password_feedback = InputValidator.validate_password(user_data['password'])
            if not password_feedback['is_valid']:
                errors.extend(password_feedback['errors'])
            if password_feedback['score'] < 50:
                warnings.append("Password strength is weak. Consider using a stronger password.")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }

    @classmethod
    def validate_transaction(cls, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate transaction data according to business rules"""
        errors = []
        warnings = []
        
        # Amount validation
        if 'amount' in transaction_data:
            amount = transaction_data['amount']
            if not isinstance(amount, (int, float)) or amount <= 0:
                errors.append("Transaction amount must be a positive number")
            elif amount > 10000:
                warnings.append("Large transaction amount detected")
        
        # Currency validation
        if 'currency' in transaction_data:
            valid_currencies = ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY']
            if transaction_data['currency'] not in valid_currencies:
                errors.append("Invalid currency code")
        
        # Account validation
        if 'account_id' in transaction_data:
            if not FormatValidator.validate_uuid_format(transaction_data['account_id']):
                errors.append("Invalid account ID format")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }

    @classmethod
    def validate_content_upload(cls, content_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate content upload according to business rules"""
        errors = []
        warnings = []
        
        # File type validation
        if 'content_type' in content_data and 'file_type_category' in content_data:
            if not InputValidator.validate_file_type(content_data['content_type'], content_data['file_type_category']):
                errors.append("File type not allowed")
        
        # File size validation
        if 'file_size' in content_data and 'file_type_category' in content_data:
            if not InputValidator.validate_file_size(content_data['file_size'], content_data['file_type_category']):
                errors.append("File size exceeds limit")
        
        # Content length validation
        if 'content' in content_data and isinstance(content_data['content'], str):
            if len(content_data['content']) > 10000:
                warnings.append("Content length is very long, consider shortening")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }


class ValidationDecorators:
    """Decorators for automatic validation"""
    
    @staticmethod
    def validate_input(validation_rules: Dict[str, Callable]):
        """Decorator to validate function inputs"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                # Simple validation logic - would need more sophisticated implementation
                for param_name, validator_func in validation_rules.items():
                    if param_name in kwargs:
                        if not validator_func(kwargs[param_name]):
                            raise ValidationError(f"Validation failed for parameter: {param_name}")
                return func(*args, **kwargs)
            return wrapper
        return decorator
    
    @staticmethod
    def validate_output(validator_func: Callable):
        """Decorator to validate function output"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                result = func(*args, **kwargs)
                if not validator_func(result):
                    raise ValidationError("Output validation failed")
                return result
            return wrapper
        return decorator


# Utility functions for common validation tasks
def validate_required_fields(data: Dict[str, Any], required_fields: List[str]) -> List[str]:
    """Validate that all required fields are present and not empty"""
    missing_fields = []
    for field in required_fields:
        if field not in data or data[field] is None or data[field] == '':
            missing_fields.append(field)
    return missing_fields

def validate_field_types(data: Dict[str, Any], field_types: Dict[str, Type]) -> List[str]:
    """Validate that fields have expected types"""
    type_errors = []
    for field, expected_type in field_types.items():
        if field in data and data[field] is not None:
            if not isinstance(data[field], expected_type):
                type_errors.append(f"Field '{field}' should be of type {expected_type.__name__}")
    return type_errors

def validate_field_values(data: Dict[str, Any], field_constraints: Dict[str, Dict]) -> List[str]:
    """Validate field values against constraints"""
    value_errors = []
    for field, constraints in field_constraints.items():
        if field in data and data[field] is not None:
            value = data[field]
            
            # Check min/max for numeric values
            if 'min' in constraints and value < constraints['min']:
                value_errors.append(f"Field '{field}' is below minimum value: {constraints['min']}")
            if 'max' in constraints and value > constraints['max']:
                value_errors.append(f"Field '{field}' exceeds maximum value: {constraints['max']}")
            
            # Check allowed values
            if 'allowed_values' in constraints and value not in constraints['allowed_values']:
                value_errors.append(f"Field '{field}' has invalid value. Allowed: {constraints['allowed_values']}")
            
            # Check regex pattern
            if 'pattern' in constraints and not re.match(constraints['pattern'], str(value)):
                value_errors.append(f"Field '{field}' does not match required pattern")
    
    return value_errors


# Export main classes and functions
__all__ = [
    'InputValidator',
    'DataSanitizer', 
    'FormatValidator',
    'BusinessRuleValidator',
    'ValidationDecorators',
    'ValidationError',
    'validate_required_fields',
    'validate_field_types',
    'validate_field_values'
]