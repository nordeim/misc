"""
Enhanced API monitoring and analytics system.

Provides comprehensive monitoring including:
- API usage analytics and reporting
- Performance monitoring and alerting
- API health checks and diagnostics
- Usage patterns and insights
- Request/response tracking
- Error rate monitoring
- Custom metrics collection
"""

import asyncio
import time
import json
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from enum import Enum
import statistics

from fastapi import Request, Response, HTTPException, status
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class MetricType(Enum):
    """Types of metrics."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"

class AlertSeverity(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class APIMetricPoint:
    """Single metric data point."""
    def __init__(
        self,
        name: str,
        value: Union[int, float],
        metric_type: MetricType,
        labels: Optional[Dict[str, str]] = None,
        timestamp: Optional[datetime] = None
    ):
        self.name = name
        self.value = value
        self.metric_type = metric_type
        self.labels = labels or {}
        self.timestamp = timestamp or datetime.utcnow()

@dataclass
class APIAnalytics:
    """API analytics data."""
    endpoint: str
    method: str
    timestamp: datetime
    response_time: float
    status_code: int
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    request_size: Optional[int] = None
    response_size: Optional[int] = None
    error_category: Optional[str] = None

@dataclass
class PerformanceMetrics:
    """Performance metrics."""
    endpoint: str
    response_time_p50: float
    response_time_p95: float
    response_time_p99: float
    throughput_per_minute: float
    error_rate: float
    active_requests: int

@dataclass
class HealthMetrics:
    """System health metrics."""
    timestamp: datetime
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    database_response_time: float
    redis_response_time: float
    active_connections: int
    cache_hit_rate: float

class APIMonitoringMiddleware(BaseHTTPMiddleware):
    """Comprehensive API monitoring middleware."""
    
    def __init__(self, app):
        super().__init__(app)
        self.metrics = APIMetricsCollector()
        self.analytics = APIAnalyticsCollector()
        self.alerts = AlertingSystem()
        self.health_checks = HealthMonitoringSystem()
        
        # Start background tasks
        self._start_monitoring_tasks()
        
        logger.info("API monitoring middleware initialized")
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Monitor API requests and responses."""
        start_time = time.time()
        request_id = getattr(request.state, 'correlation_id', 'unknown')
        
        # Track request start
        self.metrics.increment_counter('api_requests_total', labels={
            'method': request.method,
            'endpoint': request.url.path
        })
        
        try:
            # Process request
            response = await call_next(request)
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Track successful request
            self.metrics.record_timer('api_request_duration', response_time, labels={
                'method': request.method,
                'endpoint': request.url.path,
                'status_code': str(response.status_code)
            })
            
            # Record analytics
            self.analytics.record_request(APIAnalytics(
                endpoint=request.url.path,
                method=request.method,
                timestamp=datetime.utcnow(),
                response_time=response_time,
                status_code=response.status_code,
                user_id=getattr(request.state, 'user_id', None),
                session_id=getattr(request.state, 'session_id', None),
                request_size=int(request.headers.get('content-length', 0)),
                response_size=int(response.headers.get('content-length', 0)) if 'content-length' in response.headers else None
            ))
            
            # Check performance thresholds
            await self._check_performance_thresholds(
                request.url.path, request.method, response_time, response.status_code
            )
            
            # Add monitoring headers
            response.headers["X-Request-ID"] = request_id
            response.headers["X-Response-Time"] = f"{response_time:.3f}"
            
            return response
            
        except HTTPException as e:
            # Track HTTP errors
            response_time = time.time() - start_time
            error_category = self._categorize_error(e.status_code)
            
            self.metrics.increment_counter('api_errors_total', labels={
                'method': request.method,
                'endpoint': request.url.path,
                'status_code': str(e.status_code),
                'error_category': error_category
            })
            
            self.metrics.record_timer('api_request_duration', response_time, labels={
                'method': request.method,
                'endpoint': request.url.path,
                'status_code': str(e.status_code)
            })
            
            # Record error analytics
            self.analytics.record_request(APIAnalytics(
                endpoint=request.url.path,
                method=request.method,
                timestamp=datetime.utcnow(),
                response_time=response_time,
                status_code=e.status_code,
                user_id=getattr(request.state, 'user_id', None),
                error_category=error_category
            ))
            
            # Check error rate thresholds
            await self._check_error_thresholds(
                request.url.path, request.method, e.status_code, error_category
            )
            
            raise e
            
        except Exception as e:
            # Track unexpected errors
            response_time = time.time() - start_time
            
            self.metrics.increment_counter('api_unexpected_errors_total', labels={
                'method': request.method,
                'endpoint': request.url.path,
                'error_type': type(e).__name__
            })
            
            logger.error("Unexpected error in request processing",
                        request_id=request_id,
                        endpoint=request.url.path,
                        method=request.method,
                        error=str(e),
                        response_time=response_time)
            
            raise
    
    def _categorize_error(self, status_code: int) -> str:
        """Categorize error by status code."""
        if 400 <= status_code < 500:
            return "client_error"
        elif 500 <= status_code < 600:
            return "server_error"
        else:
            return "unknown"
    
    async def _check_performance_thresholds(self, endpoint: str, method: str, response_time: float, status_code: int):
        """Check performance thresholds and trigger alerts."""
        # High response time threshold (5 seconds)
        if response_time > 5.0:
            self.alerts.trigger_alert(
                "high_response_time",
                AlertSeverity.WARNING,
                f"Slow response detected",
                {
                    "endpoint": endpoint,
                    "method": method,
                    "response_time": response_time,
                    "status_code": status_code
                }
            )
        
        # Critical response time threshold (10 seconds)
        if response_time > 10.0:
            self.alerts.trigger_alert(
                "critical_response_time",
                AlertSeverity.ERROR,
                f"Very slow response detected",
                {
                    "endpoint": endpoint,
                    "method": method,
                    "response_time": response_time,
                    "status_code": status_code
                }
            )
    
    async def _check_error_thresholds(self, endpoint: str, method: str, status_code: int, error_category: str):
        """Check error rate thresholds and trigger alerts."""
        # Get recent error rate
        recent_errors = self.analytics.get_recent_error_count(endpoint, method, minutes=5)
        recent_requests = self.analytics.get_recent_request_count(endpoint, method, minutes=5)
        
        if recent_requests > 0:
            error_rate = recent_errors / recent_requests
            
            # High error rate threshold (20%)
            if error_rate > 0.2:
                self.alerts.trigger_alert(
                    "high_error_rate",
                    AlertSeverity.WARNING,
                    f"High error rate detected",
                    {
                        "endpoint": endpoint,
                        "method": method,
                        "error_rate": error_rate,
                        "recent_errors": recent_errors,
                        "recent_requests": recent_requests
                    }
                )
    
    def _start_monitoring_tasks(self):
        """Start background monitoring tasks."""
        # Performance metrics collection
        asyncio.create_task(self._collect_performance_metrics())
        
        # Health metrics collection
        asyncio.create_task(self._collect_health_metrics())
        
        # Alert processing
        asyncio.create_task(self._process_alerts())
        
        # Analytics aggregation
        asyncio.create_task(self._aggregate_analytics())
    
    async def _collect_performance_metrics(self):
        """Collect performance metrics periodically."""
        while True:
            try:
                # Get performance metrics for each endpoint
                endpoints = self.analytics.get_unique_endpoints()
                
                for endpoint in endpoints:
                    metrics = self.analytics.calculate_performance_metrics(endpoint, window_minutes=15)
                    if metrics:
                        # Record metrics
                        self.metrics.set_gauge('api_performance_response_time_p50', 
                                             metrics.response_time_p50, 
                                             labels={'endpoint': endpoint})
                        self.metrics.set_gauge('api_performance_response_time_p95', 
                                             metrics.response_time_p95, 
                                             labels={'endpoint': endpoint})
                        self.metrics.set_gauge('api_performance_throughput', 
                                             metrics.throughput_per_minute, 
                                             labels={'endpoint': endpoint})
                        self.metrics.set_gauge('api_performance_error_rate', 
                                             metrics.error_rate, 
                                             labels={'endpoint': endpoint})
                
                await asyncio.sleep(60)  # Collect every minute
                
            except Exception as e:
                logger.error("Error collecting performance metrics", error=str(e))
                await asyncio.sleep(60)
    
    async def _collect_health_metrics(self):
        """Collect system health metrics."""
        while True:
            try:
                # This would integrate with actual system monitoring
                # For now, generate mock data
                health_metrics = HealthMetrics(
                    timestamp=datetime.utcnow(),
                    cpu_usage=45.2,  # Would get from psutil
                    memory_usage=67.8,
                    disk_usage=34.5,
                    database_response_time=0.025,
                    redis_response_time=0.015,
                    active_connections=25,
                    cache_hit_rate=0.89
                )
                
                # Record health metrics
                self.metrics.set_gauge('system_health_cpu_usage', health_metrics.cpu_usage)
                self.metrics.set_gauge('system_health_memory_usage', health_metrics.memory_usage)
                self.metrics.set_gauge('system_health_disk_usage', health_metrics.disk_usage)
                self.metrics.set_gauge('system_health_db_response_time', health_metrics.database_response_time)
                self.metrics.set_gauge('system_health_redis_response_time', health_metrics.redis_response_time)
                self.metrics.set_gauge('system_health_active_connections', health_metrics.active_connections)
                self.metrics.set_gauge('system_health_cache_hit_rate', health_metrics.cache_hit_rate)
                
                # Check health thresholds
                if health_metrics.cpu_usage > 80:
                    self.alerts.trigger_alert(
                        "high_cpu_usage",
                        AlertSeverity.WARNING,
                        f"High CPU usage: {health_metrics.cpu_usage}%",
                        {"cpu_usage": health_metrics.cpu_usage}
                    )
                
                if health_metrics.memory_usage > 90:
                    self.alerts.trigger_alert(
                        "high_memory_usage",
                        AlertSeverity.ERROR,
                        f"High memory usage: {health_metrics.memory_usage}%",
                        {"memory_usage": health_metrics.memory_usage}
                    )
                
                await asyncio.sleep(30)  # Collect every 30 seconds
                
            except Exception as e:
                logger.error("Error collecting health metrics", error=str(e))
                await asyncio.sleep(30)
    
    async def _process_alerts(self):
        """Process and handle alerts."""
        while True:
            try:
                alerts = self.alerts.get_pending_alerts()
                
                for alert in alerts:
                    # Log alert
                    logger.info("Processing alert",
                               alert_type=alert.alert_type,
                               severity=alert.severity.value,
                               message=alert.message,
                               data=alert.data)
                    
                    # Here you would integrate with your alerting system
                    # e.g., send to email, Slack, PagerDuty, etc.
                
                # Mark alerts as processed
                self.alerts.mark_alerts_processed()
                
                await asyncio.sleep(10)  # Process alerts every 10 seconds
                
            except Exception as e:
                logger.error("Error processing alerts", error=str(e))
                await asyncio.sleep(10)
    
    async def _aggregate_analytics(self):
        """Aggregate analytics data."""
        while True:
            try:
                # Generate hourly analytics summary
                summary = self.analytics.generate_hourly_summary()
                
                if summary:
                    self.metrics.record_histogram('api_analytics_hourly_requests', 
                                                summary['total_requests'],
                                                labels={'hour': summary['hour']})
                    self.metrics.record_histogram('api_analytics_hourly_errors', 
                                                summary['total_errors'],
                                                labels={'hour': summary['hour']})
                
                # Generate daily report
                daily_report = self.analytics.generate_daily_report()
                
                logger.info("Daily API analytics report generated",
                           total_requests=daily_report.get('total_requests', 0),
                           total_errors=daily_report.get('total_errors', 0),
                           avg_response_time=daily_report.get('avg_response_time', 0))
                
                await asyncio.sleep(3600)  # Aggregate every hour
                
            except Exception as e:
                logger.error("Error aggregating analytics", error=str(e))
                await asyncio.sleep(3600)

class APIMetricsCollector:
    """Collect and store API metrics."""
    
    def __init__(self):
        self.counters = defaultdict(int)
        self.gauges = {}
        self.histograms = defaultdict(list)
        self.timers = defaultdict(list)
        self.max_data_points = 1000  # Limit memory usage
        
        logger.info("API metrics collector initialized")
    
    def increment_counter(self, name: str, value: int = 1, labels: Optional[Dict[str, str]] = None):
        """Increment a counter metric."""
        key = self._make_key(name, labels)
        self.counters[key] += value
        
        logger.debug("Counter incremented", 
                    metric=name, 
                    value=value, 
                    total=self.counters[key],
                    labels=labels)
    
    def set_gauge(self, name: str, value: Union[int, float], labels: Optional[Dict[str, str]] = None):
        """Set a gauge metric."""
        key = self._make_key(name, labels)
        self.gauges[key] = value
        
        logger.debug("Gauge set", 
                    metric=name, 
                    value=value, 
                    labels=labels)
    
    def record_histogram(self, name: str, value: Union[int, float], labels: Optional[Dict[str, str]] = None):
        """Record a histogram metric."""
        key = self._make_key(name, labels)
        self.histograms[key].append(value)
        
        # Limit data points
        if len(self.histograms[key]) > self.max_data_points:
            self.histograms[key] = self.histograms[key][-self.max_data_points//2:]
        
        logger.debug("Histogram recorded", 
                    metric=name, 
                    value=value, 
                    labels=labels)
    
    def record_timer(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """Record a timer metric (special type of histogram)."""
        self.record_histogram(name, value, labels)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get all metrics in a standardized format."""
        metrics = {
            "counters": {},
            "gauges": {},
            "histograms": {}
        }
        
        # Convert counters
        for key, value in self.counters.items():
            metric_name = key.split("|")[0]
            labels = self._parse_labels(key)
            metrics["counters"][metric_name] = {
                "value": value,
                "labels": labels,
                "timestamp": datetime.utcnow().isoformat()
            }
        
        # Convert gauges
        for key, value in self.gauges.items():
            metric_name = key.split("|")[0]
            labels = self._parse_labels(key)
            metrics["gauges"][metric_name] = {
                "value": value,
                "labels": labels,
                "timestamp": datetime.utcnow().isoformat()
            }
        
        # Convert histograms
        for key, values in self.histograms.items():
            if values:  # Only include if we have data
                metric_name = key.split("|")[0]
                labels = self._parse_labels(key)
                
                sorted_values = sorted(values)
                count = len(sorted_values)
                
                metrics["histograms"][metric_name] = {
                    "count": count,
                    "min": sorted_values[0] if count > 0 else 0,
                    "max": sorted_values[-1] if count > 0 else 0,
                    "avg": sum(sorted_values) / count if count > 0 else 0,
                    "p50": sorted_values[int(count * 0.5)] if count > 0 else 0,
                    "p95": sorted_values[int(count * 0.95)] if count > 0 else 0,
                    "p99": sorted_values[int(count * 0.99)] if count > 0 else 0,
                    "labels": labels,
                    "timestamp": datetime.utcnow().isoformat()
                }
        
        return metrics
    
    def _make_key(self, name: str, labels: Optional[Dict[str, str]] = None) -> str:
        """Create a unique key for a metric."""
        if not labels:
            return name
        
        label_str = "|".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}|{label_str}"
    
    def _parse_labels(self, key: str) -> Dict[str, str]:
        """Parse labels from metric key."""
        parts = key.split("|")
        if len(parts) <= 1:
            return {}
        
        labels = {}
        label_part = "|".join(parts[1:])
        
        for label in label_part.split("|"):
            if "=" in label:
                k, v = label.split("=", 1)
                labels[k] = v
        
        return labels

class APIAnalyticsCollector:
    """Collect and analyze API analytics data."""
    
    def __init__(self):
        self.requests = deque(maxlen=10000)  # Store last 10k requests
        self.request_indices = {
            'by_endpoint': defaultdict(list),
            'by_user': defaultdict(list),
            'by_timestamp': defaultdict(list)
        }
        
        logger.info("API analytics collector initialized")
    
    def record_request(self, analytics: APIAnalytics):
        """Record an API request for analytics."""
        # Add to deque
        self.requests.append(analytics)
        
        # Build indices for fast queries
        request_id = len(self.requests) - 1
        self.request_indices['by_endpoint'][analytics.endpoint].append(request_id)
        self.request_indices['by_user'][analytics.user_id or 'anonymous'].append(request_id)
        
        # Index by hour for time-based queries
        hour_key = analytics.timestamp.strftime('%Y-%m-%d_%H')
        self.request_indices['by_timestamp'][hour_key].append(request_id)
        
        logger.debug("Request recorded for analytics",
                    endpoint=analytics.endpoint,
                    method=analytics.method,
                    status_code=analytics.status_code,
                    response_time=analytics.response_time)
    
    def get_recent_request_count(self, endpoint: str, method: str, minutes: int = 5) -> int:
        """Get recent request count for an endpoint."""
        cutoff_time = datetime.utcnow() - timedelta(minutes=minutes)
        
        count = 0
        for request in self.requests:
            if (request.endpoint == endpoint and 
                request.method == method and 
                request.timestamp >= cutoff_time):
                count += 1
        
        return count
    
    def get_recent_error_count(self, endpoint: str, method: str, minutes: int = 5) -> int:
        """Get recent error count for an endpoint."""
        cutoff_time = datetime.utcnow() - timedelta(minutes=minutes)
        
        count = 0
        for request in self.requests:
            if (request.endpoint == endpoint and 
                request.method == method and 
                request.status_code >= 400 and
                request.timestamp >= cutoff_time):
                count += 1
        
        return count
    
    def calculate_performance_metrics(self, endpoint: str, window_minutes: int = 15) -> Optional[PerformanceMetrics]:
        """Calculate performance metrics for an endpoint."""
        cutoff_time = datetime.utcnow() - timedelta(minutes=window_minutes)
        
        response_times = []
        error_count = 0
        total_requests = 0
        
        for request in self.requests:
            if (request.endpoint == endpoint and 
                request.timestamp >= cutoff_time):
                response_times.append(request.response_time)
                total_requests += 1
                
                if request.status_code >= 400:
                    error_count += 1
        
        if not response_times:
            return None
        
        # Calculate percentiles
        sorted_times = sorted(response_times)
        count = len(sorted_times)
        
        metrics = PerformanceMetrics(
            endpoint=endpoint,
            response_time_p50=sorted_times[int(count * 0.5)],
            response_time_p95=sorted_times[int(count * 0.95)],
            response_time_p99=sorted_times[int(count * 0.99)],
            throughput_per_minute=total_requests / window_minutes,
            error_rate=error_count / total_requests if total_requests > 0 else 0,
            active_requests=0  # Would need separate tracking
        )
        
        return metrics
    
    def get_unique_endpoints(self) -> List[str]:
        """Get list of unique endpoints that have been called."""
        return list(set(request.endpoint for request in self.requests))
    
    def generate_hourly_summary(self) -> Optional[Dict[str, Any]]:
        """Generate hourly analytics summary."""
        current_hour = datetime.utcnow().strftime('%Y-%m-%d_%H')
        
        if current_hour not in self.request_indices['by_timestamp']:
            return None
        
        request_ids = self.request_indices['by_timestamp'][current_hour]
        
        total_requests = len(request_ids)
        total_errors = sum(1 for req_id in request_ids 
                          if self.requests[req_id].status_code >= 400)
        
        response_times = [self.requests[req_id].response_time for req_id in request_ids]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        return {
            "hour": current_hour,
            "total_requests": total_requests,
            "total_errors": total_errors,
            "error_rate": total_errors / total_requests if total_requests > 0 else 0,
            "avg_response_time": avg_response_time,
            "unique_endpoints": len(set(self.requests[req_id].endpoint for req_id in request_ids))
        }
    
    def generate_daily_report(self) -> Dict[str, Any]:
        """Generate daily analytics report."""
        today = datetime.utcnow().date()
        
        daily_requests = []
        for request in self.requests:
            if request.timestamp.date() == today:
                daily_requests.append(request)
        
        if not daily_requests:
            return {}
        
        total_requests = len(daily_requests)
        total_errors = sum(1 for req in daily_requests if req.status_code >= 400)
        response_times = [req.response_time for req in daily_requests]
        
        # Group by endpoint
        endpoint_stats = defaultdict(lambda: {'requests': 0, 'errors': 0, 'response_times': []})
        for req in daily_requests:
            stats = endpoint_stats[req.endpoint]
            stats['requests'] += 1
            if req.status_code >= 400:
                stats['errors'] += 1
            stats['response_times'].append(req.response_time)
        
        # Calculate endpoint metrics
        endpoint_metrics = {}
        for endpoint, stats in endpoint_stats.items():
            response_times = stats['response_times']
            endpoint_metrics[endpoint] = {
                "requests": stats['requests'],
                "errors": stats['errors'],
                "error_rate": stats['errors'] / stats['requests'] if stats['requests'] > 0 else 0,
                "avg_response_time": sum(response_times) / len(response_times) if response_times else 0,
                "p95_response_time": sorted(response_times)[int(len(response_times) * 0.95)] if response_times else 0
            }
        
        return {
            "date": today.isoformat(),
            "total_requests": total_requests,
            "total_errors": total_errors,
            "error_rate": total_errors / total_requests if total_requests > 0 else 0,
            "avg_response_time": sum(response_times) / len(response_times) if response_times else 0,
            "endpoint_metrics": endpoint_metrics,
            "top_endpoints_by_traffic": sorted(
                endpoint_metrics.items(),
                key=lambda x: x[1]['requests'],
                reverse=True
            )[:10],
            "top_endpoints_by_errors": sorted(
                endpoint_metrics.items(),
                key=lambda x: x[1]['errors'],
                reverse=True
            )[:10]
        }

class AlertingSystem:
    """Handle alerting for API monitoring."""
    
    def __init__(self):
        self.pending_alerts = []
        self.processed_alerts = []
        self.alert_rules = self._load_alert_rules()
        
        logger.info("Alerting system initialized")
    
    def _load_alert_rules(self) -> Dict[str, Dict[str, Any]]:
        """Load alert rules and thresholds."""
        return {
            "high_response_time": {
                "threshold": 5.0,
                "severity": AlertSeverity.WARNING,
                "cooldown_minutes": 5
            },
            "critical_response_time": {
                "threshold": 10.0,
                "severity": AlertSeverity.ERROR,
                "cooldown_minutes": 2
            },
            "high_error_rate": {
                "threshold": 0.2,  # 20%
                "severity": AlertSeverity.WARNING,
                "cooldown_minutes": 5
            },
            "high_cpu_usage": {
                "threshold": 80.0,
                "severity": AlertSeverity.WARNING,
                "cooldown_minutes": 10
            },
            "high_memory_usage": {
                "threshold": 90.0,
                "severity": AlertSeverity.ERROR,
                "cooldown_minutes": 5
            }
        }
    
    def trigger_alert(
        self, 
        alert_type: str, 
        severity: AlertSeverity, 
        message: str, 
        data: Optional[Dict[str, Any]] = None
    ):
        """Trigger an alert."""
        alert = {
            "id": f"alert_{int(time.time() * 1000)}",
            "type": alert_type,
            "severity": severity,
            "message": message,
            "data": data or {},
            "timestamp": datetime.utcnow(),
            "processed": False
        }
        
        self.pending_alerts.append(alert)
        
        logger.warning("Alert triggered",
                      alert_type=alert_type,
                      severity=severity.value,
                      message=message,
                      data=data)
    
    def get_pending_alerts(self) -> List[Dict[str, Any]]:
        """Get list of pending alerts."""
        return [alert for alert in self.pending_alerts if not alert["processed"]]
    
    def mark_alerts_processed(self):
        """Mark all pending alerts as processed."""
        for alert in self.pending_alerts:
            if not alert["processed"]:
                alert["processed"] = True
                self.processed_alerts.append(alert)
        
        # Remove processed alerts from pending list
        self.pending_alerts = [alert for alert in self.pending_alerts if not alert["processed"]]

class HealthMonitoringSystem:
    """System health monitoring."""
    
    def __init__(self):
        self.health_history = deque(maxlen=288)  # 24 hours at 5-minute intervals
        
        logger.info("Health monitoring system initialized")
    
    def record_health_metrics(self, metrics: HealthMetrics):
        """Record health metrics."""
        self.health_history.append(metrics)
    
    def get_current_health(self) -> Dict[str, Any]:
        """Get current system health status."""
        if not self.health_history:
            return {"status": "unknown", "message": "No health data available"}
        
        latest = self.health_history[-1]
        
        # Determine overall health status
        issues = []
        
        if latest.cpu_usage > 80:
            issues.append(f"High CPU usage: {latest.cpu_usage}%")
        
        if latest.memory_usage > 90:
            issues.append(f"High memory usage: {latest.memory_usage}%")
        
        if latest.disk_usage > 90:
            issues.append(f"High disk usage: {latest.disk_usage}%")
        
        if latest.database_response_time > 0.1:
            issues.append(f"Slow database response: {latest.database_response_time}s")
        
        if latest.cache_hit_rate < 0.8:
            issues.append(f"Low cache hit rate: {latest.cache_hit_rate:.2%}")
        
        if issues:
            status = "degraded" if len(issues) < 3 else "unhealthy"
            message = "; ".join(issues)
        else:
            status = "healthy"
            message = "All systems operational"
        
        return {
            "status": status,
            "message": message,
            "timestamp": latest.timestamp.isoformat(),
            "metrics": asdict(latest),
            "issues": issues
        }

# Setup function
def setup_api_monitoring(app):
    """Setup API monitoring middleware."""
    app.add_middleware(APIMonitoringMiddleware)
    logger.info("API monitoring middleware configured")

# Analytics endpoints
def create_analytics_endpoints(app):
    """Create analytics and monitoring endpoints."""
    
    @app.get("/analytics/metrics")
    async def get_metrics():
        """Get current API metrics."""
        # This would access the middleware's metrics collector
        # For simplicity, returning a placeholder response
        return {
            "status": "success",
            "metrics": {
                "api_requests_total": 1234,
                "api_errors_total": 23,
                "avg_response_time": 0.245,
                "cpu_usage": 45.2,
                "memory_usage": 67.8
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    @app.get("/analytics/daily-report")
    async def get_daily_report():
        """Get daily analytics report."""
        # This would access the analytics collector
        return {
            "status": "success",
            "report": {
                "date": datetime.utcnow().date().isoformat(),
                "total_requests": 15420,
                "total_errors": 234,
                "error_rate": 0.015,
                "avg_response_time": 0.189,
                "top_endpoints": [
                    {"endpoint": "/api/v1/chat", "requests": 8234, "errors": 45},
                    {"endpoint": "/api/v1/auth/login", "requests": 2156, "errors": 12}
                ]
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    @app.get("/health/monitoring")
    async def get_monitoring_health():
        """Get monitoring system health."""
        return {
            "status": "healthy",
            "components": {
                "metrics_collection": "active",
                "analytics_aggregation": "active", 
                "alerting_system": "active",
                "health_monitoring": "active"
            },
            "timestamp": datetime.utcnow().isoformat()
        }