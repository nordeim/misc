"""
Monitoring and health checking package.

This package provides comprehensive monitoring capabilities including:
- Prometheus metrics collection and export
- Health check orchestration and reporting
- System resource monitoring
- Dependency health checking
- Structured logging integration

Modules:
- backend_monitoring: Core monitoring utilities and Prometheus metrics
- health_check: Health check orchestration and base classes
- dependency_checker: Service dependency health check implementations
"""

from .backend_monitoring import (
    metrics,
    SystemInfo,
    init_monitoring,
    shutdown_monitoring
)

from .health_check import (
    HealthStatus,
    HealthCheckResult,
    BaseHealthCheck,
    HealthCheckOrchestrator,
    health_orchestrator,
    register_health_check,
    run_health_checks,
    get_health_summary
)

from .dependency_checker import (
    DatabaseHealthCheck,
    RedisHealthCheck,
    ChromaDBHealthCheck,
    OpenAIHealthCheck,
    AzureOpenAIHealthCheck,
    FileSystemHealthCheck,
    register_dependency_checks
)

__all__ = [
    # Monitoring
    "metrics",
    "SystemInfo",
    "init_monitoring",
    "shutdown_monitoring",
    
    # Health Checks
    "HealthStatus",
    "HealthCheckResult", 
    "BaseHealthCheck",
    "HealthCheckOrchestrator",
    "health_orchestrator",
    "register_health_check",
    "run_health_checks",
    "get_health_summary",
    
    # Dependency Checks
    "DatabaseHealthCheck",
    "RedisHealthCheck",
    "ChromaDBHealthCheck", 
    "OpenAIHealthCheck",
    "AzureOpenAIHealthCheck",
    "FileSystemHealthCheck",
    "register_dependency_checks"
]