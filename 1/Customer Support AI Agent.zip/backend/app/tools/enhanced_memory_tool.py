"""
Enhanced MemoryTool using BaseTool pattern.

Demonstrates how to upgrade existing tools to use the new BaseTool architecture
with all the advanced features like resilience patterns, metrics, configuration, etc.
"""

import logging
import asyncio
import hashlib
from typing import List, Dict, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import json
import re
from collections import defaultdict, Counter

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc, asc, func, text, not_, exists
from sqlalchemy.orm import selectinload

from .base_tool import BaseTool, ToolMetadata, ToolExecutionContext, ToolStatus, ToolPriority
from .patterns import create_resilient_method, RetryConfig
from .config import ConfigParameter
from app.models.memory import MemoryORM, MemoryCreate, MemoryUpdate, MemoryRead, MemoryStats
from app.models.session import SessionORM
from app.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


class MemoryType(Enum):
    """Enumeration of memory types."""
    CONVERSATION = "conversation"
    CONTEXT = "context"
    USER_PREFERENCE = "user_preference"
    KNOWLEDGE = "knowledge"
    FACT = "fact"
    USER_INFO = "user_info"
    SUMMARY = "summary"
    POLICY = "policy"
    ERROR = "error"


class ImportanceLevel(Enum):
    """Memory importance levels."""
    CRITICAL = 1.0
    HIGH = 0.8
    MEDIUM = 0.6
    LOW = 0.4
    MINIMAL = 0.2


@dataclass
class MemoryQuery:
    """Query parameters for memory search."""
    session_id: str
    memory_type: Optional[MemoryType] = None
    importance_min: Optional[float] = None
    keywords: Optional[List[str]] = None
    since: Optional[datetime] = None
    until: Optional[datetime] = None
    limit: int = 50
    offset: int = 0


@dataclass
class MemorySearchResult:
    """Result of memory search operation."""
    memories: List[Dict[str, Any]]
    total_count: int
    search_time_ms: float
    relevance_scores: Optional[List[float]] = None


class MemoryCompressor:
    """Compresses and summarizes memories for storage efficiency."""
    
    @staticmethod
    def compress_memory(value: str, max_length: int = 1000) -> str:
        """Compress memory value to maximum length."""
        if len(value) <= max_length:
            return value
        
        # Simple compression: truncate and add ellipsis
        return value[:max_length-3] + "..."
    
    @staticmethod
    def extract_summary(value: str, max_length: int = 200) -> str:
        """Extract a summary from memory value."""
        if len(value) <= max_length:
            return value
        
        # Try to find a natural break point
        sentences = value.split('. ')
        summary = ""
        
        for sentence in sentences:
            if len(summary + sentence) <= max_length:
                summary += sentence + ". "
            else:
                break
        
        return summary.strip() if summary else value[:max_length] + "..."


class MemoryRelevanceScorer:
    """Scores memory relevance based on various factors."""
    
    def __init__(self):
        self.keyword_weights = {
            'critical': 2.0,
            'urgent': 1.8,
            'important': 1.5,
            'note': 1.2,
            'remember': 1.3
        }
    
    def calculate_relevance(
        self, 
        memory: MemoryORM, 
        context: Optional[Dict[str, Any]] = None
    ) -> float:
        """Calculate relevance score for a memory."""
        score = memory.importance_score
        
        # Boost score for recent memories
        age_hours = (datetime.utcnow() - memory.created_at).total_seconds() / 3600
        if age_hours < 24:
            score *= 1.2
        elif age_hours < 168:  # 1 week
            score *= 1.1
        
        # Keyword-based boosting
        if memory.tags:
            for tag in memory.tags:
                weight = self.keyword_weights.get(tag.lower(), 1.0)
                score *= weight
        
        # Context-based boosting
        if context and 'keywords' in context:
            memory_text = f"{memory.key} {memory.value}".lower()
            for keyword in context['keywords']:
                if keyword.lower() in memory_text:
                    score *= 1.1
        
        return min(1.0, score)


class EnhancedMemoryTool(BaseTool):
    """
    Enhanced MemoryTool using BaseTool pattern.
    
    Demonstrates all the advanced features:
    - Standardized interface and lifecycle management
    - Built-in resilience patterns and error handling
    - Comprehensive metrics and monitoring
    - Configuration management
    - Execution context and isolation
    - Health monitoring
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        # Initialize BaseTool first
        super().__init__(config)
        
        # Initialize compression and relevance scoring
        self.compressor = MemoryCompressor()
        self.relevance_scorer = MemoryRelevanceScorer()
        
        # Apply configuration
        self.default_ttl_days = self.get_config("default_ttl_days", 30)
        self.max_memories_per_session = self.get_config("max_memories_per_session", 10000)
        self.cleanup_batch_size = self.get_config("cleanup_batch_size", 1000)
        
        logger.info(f"Enhanced MemoryTool initialized with config: {self.config}")
    
    @property
    def name(self) -> str:
        """Get the tool name."""
        return "enhanced_memory_tool"
    
    def _get_metadata(self) -> ToolMetadata:
        """Get tool metadata with enhanced information."""
        return ToolMetadata(
            name=self.name,
            version="4.0.0",
            description="Enhanced conversation memory management with BaseTool pattern",
            category="memory",
            tags=["conversation", "memory", "context", "storage"],
            dependencies=["sqlalchemy", "asyncpg"],
            supported_formats=["json", "memory_orm"],
            
            # Execution constraints
            timeout_seconds=60,
            max_retries=3,
            retry_delay_seconds=1.0,
            circuit_breaker_threshold=5,
            circuit_breaker_timeout_seconds=30,
            
            # Resource limits
            max_concurrent_executions=20,
            memory_limit_mb=256,
            cpu_limit_percent=50,
            
            # Health and monitoring
            health_check_enabled=True,
            health_check_interval_seconds=120,
            metrics_enabled=True,
            logging_enabled=True,
            
            # Configuration schema
            config_schema={
                "type": "object",
                "properties": {
                    "default_ttl_days": {"type": "integer", "minimum": 1, "maximum": 365},
                    "max_memories_per_session": {"type": "integer", "minimum": 100},
                    "cleanup_batch_size": {"type": "integer", "minimum": 10, "maximum": 10000},
                    "enable_compression": {"type": "boolean"},
                    "enable_relevance_scoring": {"type": "boolean"}
                }
            },
            default_config={
                "default_ttl_days": 30,
                "max_memories_per_session": 10000,
                "cleanup_batch_size": 1000,
                "enable_compression": True,
                "enable_relevance_scoring": True
            }
        )
    
    async def initialize(self) -> bool:
        """Initialize the memory tool."""
        try:
            # Run parent initialization
            if not await super().initialize():
                return False
            
            # Test database connection
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count()).select_from(MemoryORM))
                logger.info(f"Memory tool database connection test passed. Total memories: {result.scalar()}")
            
            self.status = ToolStatus.SUCCESS
            logger.info("Enhanced MemoryTool initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Enhanced MemoryTool: {e}")
            self.status = ToolStatus.FAILED
            return False
    
    async def health_check(self) -> bool:
        """Enhanced health check with database connectivity test."""
        try:
            # Basic health checks
            if not await super().health_check():
                return False
            
            # Database connectivity test
            async with AsyncSessionLocal() as db:
                result = await db.execute(select(func.count()).select_from(MemoryORM).limit(1))
                count = result.scalar()
                
                if count is None:
                    return False
            
            # Check configuration validity
            if not self.config:
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Enhanced MemoryTool health check failed: {e}")
            return False
    
    @create_resilient_method(
        retry_config=RetryConfig(max_attempts=3, strategy="exponential"),
        circuit_breaker_config=None,  # Use default from metadata
        isolation_level="default"
    )
    async def store_memory(
        self,
        session_id: str,
        key: str,
        value: str,
        memory_type: MemoryType = MemoryType.CONVERSATION,
        importance_score: float = 0.5,
        ttl_days: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ) -> str:
        """
        Store a memory with enhanced features using BaseTool resilience patterns.
        
        Args:
            session_id: Session identifier
            key: Memory key
            value: Memory value
            memory_type: Type of memory
            importance_score: Importance score (0.0 to 1.0)
            ttl_days: Time to live in days
            metadata: Optional metadata
            tags: Optional tags
            
        Returns:
            Memory ID
        """
        ttl_days = ttl_days or self.default_ttl_days
        
        async with AsyncSessionLocal() as db:
            # Calculate expiry
            expires_at = None
            if ttl_days > 0:
                expires_at = datetime.utcnow() + timedelta(days=ttl_days)
            
            # Create memory record
            memory = MemoryORM(
                session_id=session_id,
                key=key,
                value=self.compressor.compress_memory(value) if self.get_config("enable_compression", True) else value,
                memory_type=memory_type.value,
                importance_score=importance_score,
                expires_at=expires_at,
                meta_data=metadata or {},
                tags=tags or []
            )
            
            db.add(memory)
            await db.commit()
            await db.refresh(memory)
            
            memory_id = str(memory.id)
            
            logger.info(
                f"Stored memory '{key}' for session {session_id}",
                extra={
                    "memory_id": memory_id,
                    "session_id": session_id,
                    "memory_type": memory_type.value,
                    "importance_score": importance_score,
                    "expires_at": expires_at.isoformat() if expires_at else None
                }
            )
            
            return memory_id
    
    @create_resilient_method(
        retry_config=RetryConfig(max_attempts=2),
        isolation_level="read_only"
    )
    async def get_memories(
        self,
        session_id: str,
        memory_type: Optional[MemoryType] = None,
        importance_min: Optional[float] = None,
        limit: int = 50,
        since: Optional[datetime] = None,
        include_expired: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Get memories with filtering and enhanced features.
        
        Args:
            session_id: Session identifier
            memory_type: Optional memory type filter
            importance_min: Minimum importance score filter
            limit: Maximum number of memories to return
            since: Optional datetime filter
            include_expired: Whether to include expired memories
            
        Returns:
            List of memory dictionaries
        """
        async with AsyncSessionLocal() as db:
            # Build query
            query = select(MemoryORM).where(MemoryORM.session_id == session_id)
            
            # Apply filters
            if memory_type:
                query = query.where(MemoryORM.memory_type == memory_type.value)
            
            if importance_min:
                query = query.where(MemoryORM.importance_score >= importance_min)
            
            if since:
                query = query.where(MemoryORM.created_at >= since)
            
            if not include_expired:
                query = query.where(
                    or_(MemoryORM.expires_at.is_(None), MemoryORM.expires_at > datetime.utcnow())
                )
            
            # Order by importance and creation time
            query = query.order_by(
                desc(MemoryORM.importance_score),
                desc(MemoryORM.created_at)
            ).limit(limit)
            
            result = await db.execute(query)
            memories = result.scalars().all()
            
            # Convert to dictionaries with enhanced data
            memory_list = []
            for memory in memories:
                memory_dict = {
                    "id": str(memory.id),
                    "key": memory.key,
                    "value": memory.value,
                    "memory_type": memory.memory_type,
                    "importance_score": memory.importance_score,
                    "confidence_score": memory.confidence_score,
                    "access_count": memory.access_count,
                    "created_at": memory.created_at.isoformat(),
                    "updated_at": memory.updated_at.isoformat(),
                    "expires_at": memory.expires_at.isoformat() if memory.expires_at else None,
                    "tags": memory.tags or [],
                    "metadata": memory.meta_data or {}
                }
                
                # Add relevance scoring if enabled
                if self.get_config("enable_relevance_scoring", True):
                    memory_dict["relevance_score"] = self.relevance_scorer.calculate_relevance(memory)
                
                memory_list.append(memory_dict)
            
            logger.debug(f"Retrieved {len(memory_list)} memories for session {session_id}")
            return memory_list
    
    @create_resilient_method(
        retry_config=RetryConfig(max_attempts=2)
    )
    async def search_memories(
        self,
        query: MemoryQuery
    ) -> MemorySearchResult:
        """
        Search memories using advanced query parameters.
        
        Args:
            query: MemoryQuery with search parameters
            
        Returns:
            MemorySearchResult with results and metadata
        """
        start_time = datetime.utcnow()
        
        async with AsyncSessionLocal() as db:
            # Build complex query
            sql_query = select(MemoryORM).where(MemoryORM.session_id == query.session_id)
            
            # Apply filters
            if query.memory_type:
                sql_query = sql_query.where(MemoryORM.memory_type == query.memory_type.value)
            
            if query.importance_min:
                sql_query = sql_query.where(MemoryORM.importance_score >= query.importance_min)
            
            if query.since:
                sql_query = sql_query.where(MemoryORM.created_at >= query.since)
            
            if query.until:
                sql_query = sql_query.where(MemoryORM.created_at <= query.until)
            
            # Text search if keywords provided
            if query.keywords:
                keyword_filters = []
                for keyword in query.keywords:
                    keyword_filters.append(
                        or_(
                            MemoryORM.key.ilike(f"%{keyword}%"),
                            MemoryORM.value.ilike(f"%{keyword}%")
                        )
                    )
                sql_query = sql_query.where(or_(*keyword_filters))
            
            # Exclude expired memories
            sql_query = sql_query.where(
                or_(MemoryORM.expires_at.is_(None), MemoryORM.expires_at > datetime.utcnow())
            )
            
            # Get total count
            count_query = select(func.count()).select_from(
                sql_query.subquery()
            )
            count_result = await db.execute(count_query)
            total_count = count_result.scalar()
            
            # Apply pagination and ordering
            sql_query = sql_query.order_by(
                desc(MemoryORM.importance_score),
                desc(MemoryORM.created_at)
            ).offset(query.offset).limit(query.limit)
            
            # Execute search
            result = await db.execute(sql_query)
            memories = result.scalars().all()
            
            # Process results
            search_results = []
            relevance_scores = []
            
            for memory in memories:
                memory_dict = {
                    "id": str(memory.id),
                    "key": memory.key,
                    "value": memory.value,
                    "memory_type": memory.memory_type,
                    "importance_score": memory.importance_score,
                    "created_at": memory.created_at.isoformat(),
                    "tags": memory.tags or [],
                    "metadata": memory.meta_data or {}
                }
                
                # Calculate relevance score
                relevance = self.relevance_scorer.calculate_relevance(
                    memory, 
                    {"keywords": query.keywords}
                )
                
                memory_dict["relevance_score"] = relevance
                relevance_scores.append(relevance)
                search_results.append(memory_dict)
            
            # Calculate search time
            search_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            
            return MemorySearchResult(
                memories=search_results,
                total_count=total_count,
                search_time_ms=search_time,
                relevance_scores=relevance_scores
            )
    
    async def update_memory(
        self,
        session_id: str,
        key: str,
        new_value: str,
        importance_score: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Update an existing memory."""
        async with AsyncSessionLocal() as db:
            # Find existing memory
            query = select(MemoryORM).where(
                and_(
                    MemoryORM.session_id == session_id,
                    MemoryORM.key == key
                )
            ).order_by(desc(MemoryORM.created_at)).limit(1)
            
            result = await db.execute(query)
            memory = result.scalar_one_or_none()
            
            if not memory:
                return False
            
            # Update memory
            if new_value:
                memory.value = self.compressor.compress_memory(new_value) if self.get_config("enable_compression", True) else new_value
            
            if importance_score is not None:
                memory.importance_score = importance_score
            
            if metadata is not None:
                memory.meta_data = metadata
            
            memory.update()
            await db.commit()
            
            logger.info(f"Updated memory '{key}' for session {session_id}")
            return True
    
    async def delete_memory(
        self,
        session_id: str,
        key: str
    ) -> bool:
        """Delete a specific memory."""
        async with AsyncSessionLocal() as db:
            query = select(MemoryORM).where(
                and_(
                    MemoryORM.session_id == session_id,
                    MemoryORM.key == key
                )
            )
            
            result = await db.execute(query)
            memory = result.scalar_one_or_none()
            
            if not memory:
                return False
            
            await db.delete(memory)
            await db.commit()
            
            logger.info(f"Deleted memory '{key}' for session {session_id}")
            return True
    
    async def cleanup_expired_memories(self) -> int:
        """Clean up expired memories."""
        async with AsyncSessionLocal() as db:
            # Find expired memories
            expired_query = select(MemoryORM).where(
                and_(
                    MemoryORM.expires_at.isnot(None),
                    MemoryORM.expires_at <= datetime.utcnow()
                )
            )
            
            result = await db.execute(expired_query)
            expired_memories = result.scalars().all()
            
            # Delete in batches
            deleted_count = 0
            for i in range(0, len(expired_memories), self.cleanup_batch_size):
                batch = expired_memories[i:i + self.cleanup_batch_size]
                
                for memory in batch:
                    await db.delete(memory)
                    deleted_count += 1
                
                await db.commit()
                
                logger.debug(f"Deleted batch of {len(batch)} expired memories")
            
            if deleted_count > 0:
                logger.info(f"Cleaned up {deleted_count} expired memories")
            
            return deleted_count
    
    async def get_memory_statistics(
        self,
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get memory statistics."""
        async with AsyncSessionLocal() as db:
            base_query = select(MemoryORM)
            
            if session_id:
                base_query = base_query.where(MemoryORM.session_id == session_id)
            
            # Total memories
            total_result = await db.execute(select(func.count()).select_from(base_query.subquery()))
            total_memories = total_result.scalar()
            
            # Memory types distribution
            type_query = select(
                MemoryORM.memory_type,
                func.count(MemoryORM.id)
            ).group_by(MemoryORM.memory_type)
            
            if session_id:
                type_query = type_query.where(MemoryORM.session_id == session_id)
            
            type_result = await db.execute(type_query)
            type_distribution = dict(type_result.all())
            
            # Importance distribution
            importance_query = select(
                func.avg(MemoryORM.importance_score),
                func.min(MemoryORM.importance_score),
                func.max(MemoryORM.importance_score)
            )
            
            if session_id:
                importance_query = importance_query.where(MemoryORM.session_id == session_id)
            
            importance_result = await db.execute(importance_query)
            importance_stats = importance_result.first()
            
            # Expired memories count
            expired_query = select(func.count()).select_from(MemoryORM).where(
                and_(
                    MemoryORM.expires_at.isnot(None),
                    MemoryORM.expires_at <= datetime.utcnow()
                )
            )
            
            if session_id:
                expired_query = expired_query.where(MemoryORM.session_id == session_id)
            
            expired_result = await db.execute(expired_query)
            expired_count = expired_result.scalar()
            
            return {
                "total_memories": total_memories,
                "type_distribution": type_distribution,
                "importance_stats": {
                    "average": float(importance_stats[0]) if importance_stats[0] else 0.0,
                    "minimum": float(importance_stats[1]) if importance_stats[1] else 0.0,
                    "maximum": float(importance_stats[2]) if importance_stats[2] else 0.0
                },
                "expired_memories": expired_count,
                "session_id": session_id,
                "calculated_at": datetime.utcnow().isoformat()
            }
    
    async def execute(self, *args, **kwargs) -> Any:
        """Execute the primary memory tool function."""
        # This method can be used as a general entry point
        # For now, we'll use the specific methods above
        if len(args) == 0:
            return {"status": "ready", "tool": self.name}
        
        # Handle simple execute calls
        operation = args[0] if args else None
        
        if operation == "stats":
            return await self.get_memory_statistics()
        elif operation == "cleanup":
            return {"deleted_count": await self.cleanup_expired_memories()}
        else:
            return {"error": f"Unknown operation: {operation}"}
    
    async def shutdown(self) -> bool:
        """Shutdown the memory tool gracefully."""
        try:
            # Run any cleanup tasks
            await self.cleanup_expired_memories()
            
            # Call parent shutdown
            return await super().shutdown()
            
        except Exception as e:
            logger.error(f"Error during Enhanced MemoryTool shutdown: {e}")
            return False


# Create an instance for backward compatibility
enhanced_memory_tool = EnhancedMemoryTool()
