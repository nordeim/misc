"""
BaseTool abstract class with standardized interfaces.

Provides the foundation for all tool implementations with common patterns
for execution, error handling, lifecycle management, and monitoring.
"""

import logging
import time
import asyncio
import traceback
from abc import ABC, abstractmethod
from typing import (
    Any, Dict, List, Optional, Type, Union, Callable, Awaitable,
    Generic, TypeVar, Protocol
)
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from contextlib import asynccontextmanager, contextmanager
from functools import wraps
import json
import uuid

# Type variables for generic tool implementations
T = TypeVar('T')
ToolResult = TypeVar('ToolResult')
ToolConfig = TypeVar('ToolConfig')


class ToolStatus(Enum):
    """Tool execution status enumeration."""
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    CIRCUIT_OPEN = "circuit_open"
    CIRCUIT_HALF_OPEN = "circuit_half_open"


class ToolPriority(Enum):
    """Tool execution priority levels."""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5


class ToolError(Exception):
    """Base exception for tool-related errors."""
    
    def __init__(
        self, 
        message: str, 
        tool_name: str = None,
        tool_instance: Any = None,
        original_error: Exception = None,
        context: Dict[str, Any] = None
    ):
        self.tool_name = tool_name or (tool_instance.__class__.__name__ if tool_instance else "Unknown")
        self.tool_instance = tool_instance
        self.original_error = original_error
        self.context = context or {}
        self.timestamp = datetime.utcnow()
        super().__init__(message)


class ToolValidationError(ToolError):
    """Raised when tool input validation fails."""
    pass


class ToolExecutionError(ToolError):
    """Raised when tool execution fails."""
    pass


class ToolTimeoutError(ToolError):
    """Raised when tool execution times out."""
    pass


class ToolResourceError(ToolError):
    """Raised when tool resource constraints are exceeded."""
    pass


@dataclass
class ToolMetadata:
    """Metadata for tool registration and management."""
    name: str
    version: str
    description: str
    category: str
    tags: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    supported_formats: List[str] = field(default_factory=list)
    
    # Execution constraints
    timeout_seconds: int = 300  # 5 minutes default
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout_seconds: int = 60
    
    # Resource limits
    max_concurrent_executions: int = 10
    memory_limit_mb: int = 512
    cpu_limit_percent: int = 80
    
    # Health and monitoring
    health_check_enabled: bool = True
    health_check_interval_seconds: int = 300  # 5 minutes
    metrics_enabled: bool = True
    logging_enabled: bool = True
    
    # Configuration
    config_schema: Optional[Dict[str, Any]] = None
    default_config: Optional[Dict[str, Any]] = None
    environment_variables: List[str] = field(default_factory=list)


@dataclass
class ToolExecutionContext:
    """Context for tool execution with tracking and isolation."""
    execution_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parent_execution_id: Optional[str] = None
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    request_id: Optional[str] = None
    
    # Execution metadata
    started_at: datetime = field(default_factory=datetime.utcnow)
    priority: ToolPriority = ToolPriority.NORMAL
    
    # Resource tracking
    timeout_seconds: Optional[int] = None
    max_memory_mb: Optional[int] = None
    max_cpu_percent: Optional[int] = None
    
    # Isolation and security
    isolation_level: str = "default"
    permissions: List[str] = field(default_factory=list)
    sensitive_data_masking: bool = True
    
    # Monitoring and tracing
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary for logging/monitoring."""
        return {
            "execution_id": self.execution_id,
            "parent_execution_id": self.parent_execution_id,
            "session_id": self.session_id,
            "user_id": self.user_id,
            "request_id": self.request_id,
            "started_at": self.started_at.isoformat(),
            "priority": self.priority.value,
            "timeout_seconds": self.timeout_seconds,
            "isolation_level": self.isolation_level,
            "permissions": self.permissions,
            "metadata": self.metadata,
            "tags": self.tags,
        }


@dataclass
class ToolMetrics:
    """Tool execution metrics and performance data."""
    # Execution metrics
    total_executions: int = 0
    successful_executions: int = 0
    failed_executions: int = 0
    timeout_executions: int = 0
    cancelled_executions: int = 0
    
    # Performance metrics
    average_execution_time_ms: float = 0.0
    min_execution_time_ms: float = float('inf')
    max_execution_time_ms: float = 0.0
    
    # Resource metrics
    peak_memory_usage_mb: float = 0.0
    peak_cpu_usage_percent: float = 0.0
    total_memory_allocated_mb: float = 0.0
    
    # Error metrics
    error_rate: float = 0.0
    last_error: Optional[ToolError] = None
    error_history: List[ToolError] = field(default_factory=list)
    
    # Circuit breaker metrics
    circuit_breaker_state: ToolStatus = ToolStatus.IDLE
    circuit_breaker_failures: int = 0
    circuit_breaker_last_failure: Optional[datetime] = None
    
    # Health metrics
    health_status: str = "unknown"
    last_health_check: Optional[datetime] = None
    health_check_failures: int = 0
    
    # Timing metrics
    last_execution_time: Optional[datetime] = None
    last_successful_execution: Optional[datetime] = None
    last_failed_execution: Optional[datetime] = None
    
    def update_on_execution(self, execution_time_ms: float, success: bool, error: Optional[Exception] = None):
        """Update metrics after an execution."""
        self.total_executions += 1
        self.last_execution_time = datetime.utcnow()
        
        if success:
            self.successful_executions += 1
            self.last_successful_execution = datetime.utcnow()
        else:
            self.failed_executions += 1
            self.last_failed_execution = datetime.utcnow()
            if isinstance(error, ToolError):
                self.last_error = error
                self.error_history.append(error)
                # Keep only last 100 errors
                if len(self.error_history) > 100:
                    self.error_history = self.error_history[-100:]
        
        # Update timing metrics
        self.min_execution_time_ms = min(self.min_execution_time_ms, execution_time_ms)
        self.max_execution_time_ms = max(self.max_execution_time_ms, execution_time_ms)
        
        # Calculate running average
        if self.successful_executions + self.failed_executions > 0:
            total_time = (self.average_execution_time_ms * 
                         (self.successful_executions + self.failed_executions - 1) + 
                         execution_time_ms)
            self.average_execution_time_ms = total_time / (
                self.successful_executions + self.failed_executions
            )
        
        # Update error rate
        if self.total_executions > 0:
            self.error_rate = self.failed_executions / self.total_executions
    
    def get_health_score(self) -> float:
        """Calculate tool health score (0.0 to 1.0)."""
        if self.total_executions == 0:
            return 1.0
        
        # Start with success rate
        health = 1.0 - self.error_rate
        
        # Factor in performance
        if self.average_execution_time_ms > 0:
            # Penalize slow execution times
            if self.average_execution_time_ms > 10000:  # > 10 seconds
                health *= 0.5
            elif self.average_execution_time_ms > 5000:  # > 5 seconds
                health *= 0.75
        
        # Factor in circuit breaker state
        if self.circuit_breaker_state == ToolStatus.CIRCUIT_OPEN:
            health *= 0.1
        elif self.circuit_breaker_state == ToolStatus.CIRCUIT_HALF_OPEN:
            health *= 0.5
        
        return max(0.0, min(1.0, health))


class ToolDecorator:
    """Decorator factory for tool methods with common patterns."""
    
    @staticmethod
    def retry(max_attempts: int = 3, delay: float = 1.0, exceptions: tuple = (Exception,)):
        """Retry decorator for tool methods."""
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                last_exception = None
                for attempt in range(max_attempts):
                    try:
                        if asyncio.iscoroutinefunction(func):
                            return await func(*args, **kwargs)
                        else:
                            return func(*args, **kwargs)
                    except exceptions as e:
                        last_exception = e
                        if attempt < max_attempts - 1:
                            await asyncio.sleep(delay * (2 ** attempt))  # Exponential backoff
                        continue
                
                # All attempts failed
                raise ToolExecutionError(
                    f"Method {func.__name__} failed after {max_attempts} attempts",
                    tool_instance=args[0] if args else None,
                    original_error=last_exception
                ) from last_exception
            
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                last_exception = None
                for attempt in range(max_attempts):
                    try:
                        if asyncio.iscoroutinefunction(func):
                            # For sync wrapper, run async function in event loop
                            loop = asyncio.get_event_loop()
                            if loop.is_running():
                                # If we're already in an event loop, create a new task
                                import concurrent.futures
                                with concurrent.futures.ThreadPoolExecutor() as executor:
                                    future = executor.submit(asyncio.run, func(*args, **kwargs))
                                    return future.result()
                            else:
                                return loop.run_until_complete(func(*args, **kwargs))
                        else:
                            return func(*args, **kwargs)
                    except exceptions as e:
                        last_exception = e
                        if attempt < max_attempts - 1:
                            time.sleep(delay * (2 ** attempt))  # Exponential backoff
                        continue
                
                raise ToolExecutionError(
                    f"Method {func.__name__} failed after {max_attempts} attempts",
                    tool_instance=args[0] if args else None,
                    original_error=last_exception
                ) from last_exception
            
            return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
        
        return decorator
    
    @staticmethod
    def timeout(seconds: float):
        """Timeout decorator for tool methods."""
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                try:
                    return await asyncio.wait_for(func(*args, **kwargs), timeout=seconds)
                except asyncio.TimeoutError:
                    tool_instance = args[0] if args else None
                    raise ToolTimeoutError(
                        f"Method {func.__name__} timed out after {seconds} seconds",
                        tool_instance=tool_instance
                    )
            
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    if asyncio.iscoroutinefunction(func):
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        try:
                            return loop.run_until_complete(
                                asyncio.wait_for(func(*args, **kwargs), timeout=seconds)
                            )
                        finally:
                            loop.close()
                    else:
                        # For sync functions, implement timeout check
                        import signal
                        raise NotImplementedError("Sync timeout decorator requires signal implementation")
                except Exception as e:
                    elapsed = time.time() - start_time
                    if elapsed >= seconds:
                        tool_instance = args[0] if args else None
                        raise ToolTimeoutError(
                            f"Method {func.__name__} timed out after {elapsed:.2f} seconds",
                            tool_instance=tool_instance
                        ) from e
                    raise
            
            return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
        
        return decorator
    
    @staticmethod
    def measure_performance(func: Callable) -> Callable:
        """Performance measurement decorator for tool methods."""
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            tool_instance = args[0] if args else None
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                execution_time = (time.time() - start_time) * 1000  # Convert to ms
                
                # Update metrics if tool instance has metrics
                if tool_instance and hasattr(tool_instance, 'metrics'):
                    tool_instance.metrics.update_on_execution(execution_time, True)
                
                return result
            except Exception as error:
                execution_time = (time.time() - start_time) * 1000
                
                # Update metrics if tool instance has metrics
                if tool_instance and hasattr(tool_instance, 'metrics'):
                    tool_instance.metrics.update_on_execution(execution_time, False, error)
                
                raise
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            tool_instance = args[0] if args else None
            start_time = time.time()
            
            try:
                if asyncio.iscoroutinefunction(func):
                    # Handle async function in sync context
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(func(*args, **kwargs))
                    finally:
                        loop.close()
                else:
                    result = func(*args, **kwargs)
                
                execution_time = (time.time() - start_time) * 1000
                
                # Update metrics if tool instance has metrics
                if tool_instance and hasattr(tool_instance, 'metrics'):
                    tool_instance.metrics.update_on_execution(execution_time, True)
                
                return result
            except Exception as error:
                execution_time = (time.time() - start_time) * 1000
                
                # Update metrics if tool instance has metrics
                if tool_instance and hasattr(tool_instance, 'metrics'):
                    tool_instance.metrics.update_on_execution(execution_time, False, error)
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper


class CircuitBreaker:
    """Circuit breaker implementation for tool resilience."""
    
    def __init__(
        self, 
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: tuple = (Exception,)
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        
        self.failure_count = 0
        self.last_failure_time = None
        self.state = ToolStatus.IDLE
        self.lock = asyncio.Lock() if asyncio.iscoroutinefunction(self.call) else None
    
    async def call(self, func: Callable, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        if self.lock:
            async with self.lock:
                return await self._execute_with_circuit_breaker(func, *args, **kwargs)
        else:
            return self._execute_with_circuit_breaker(func, *args, **kwargs)
    
    async def _execute_with_circuit_breaker(self, func: Callable, *args, **kwargs):
        """Execute function with circuit breaker logic."""
        if self.state == ToolStatus.CIRCUIT_OPEN:
            if self._should_attempt_reset():
                self.state = ToolStatus.CIRCUIT_HALF_OPEN
            else:
                raise ToolResourceError(
                    f"Circuit breaker is OPEN. Last failure: {self.last_failure_time}"
                )
        
        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            await self._on_success()
            return result
            
        except self.expected_exception as e:
            await self._on_failure()
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if circuit breaker should attempt to reset."""
        if not self.last_failure_time:
            return True
        
        return (datetime.utcnow() - self.last_failure_time).seconds >= self.recovery_timeout
    
    async def _on_success(self):
        """Handle successful execution."""
        self.failure_count = 0
        self.state = ToolStatus.SUCCESS
    
    async def _on_failure(self):
        """Handle failed execution."""
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()
        
        if self.failure_count >= self.failure_threshold:
            self.state = ToolStatus.CIRCUIT_OPEN


class BaseTool(ABC):
    """
    Abstract base class for all tools in the system.
    
    Provides standardized interfaces for tool execution, lifecycle management,
    error handling, monitoring, and configuration.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the base tool."""
        self.metadata = self._get_metadata()
        self.config = config or self.metadata.default_config or {}
        self.status = ToolStatus.IDLE
        self.metrics = ToolMetrics()
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=self.metadata.circuit_breaker_threshold,
            recovery_timeout=self.metadata.circuit_breaker_timeout_seconds
        )
        self.logger = logging.getLogger(f"tool.{self.metadata.name}")
        self._start_time = None
        self._execution_lock = asyncio.Lock() if self._has_async_methods() else None
        
        # Validate configuration
        if self.metadata.config_schema:
            self._validate_config(self.config)
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Get the tool name."""
        pass
    
    @property
    def version(self) -> str:
        """Get the tool version."""
        return getattr(self, '__version__', '1.0.0')
    
    @property
    def execution_count(self) -> int:
        """Get total execution count."""
        return self.metrics.total_executions
    
    @property
    def error_rate(self) -> float:
        """Get current error rate."""
        return self.metrics.error_rate
    
    @property
    def health_score(self) -> float:
        """Get current health score."""
        return self.metrics.get_health_score()
    
    def _get_metadata(self) -> ToolMetadata:
        """Get tool metadata. Override in subclasses for custom metadata."""
        return ToolMetadata(
            name=self.name,
            version=self.version,
            description=f"Tool: {self.name}",
            category="base"
        )
    
    def _has_async_methods(self) -> bool:
        """Check if the tool has async methods that need event loop."""
        return any(
            asyncio.iscoroutinefunction(getattr(self, method_name))
            for method_name in dir(self)
            if not method_name.startswith('_') and callable(getattr(self, method_name))
        )
    
    def _validate_config(self, config: Dict[str, Any]):
        """Validate tool configuration against schema."""
        if not self.metadata.config_schema:
            return
        
        # Basic validation - in production, use a proper JSON schema validator
        required_fields = self.metadata.config_schema.get('required', [])
        for field in required_fields:
            if field not in config:
                raise ToolValidationError(
                    f"Required configuration field '{field}' is missing",
                    tool_instance=self
                )
    
    async def initialize(self) -> bool:
        """
        Initialize the tool. Override in subclasses for custom initialization.
        
        Returns:
            True if initialization successful, False otherwise
        """
        try:
            self.logger.info(f"Initializing tool: {self.name}")
            self.status = ToolStatus.IDLE
            self._start_time = datetime.utcnow()
            
            # Run health check
            if self.metadata.health_check_enabled:
                health_ok = await self.health_check()
                if not health_ok:
                    self.logger.warning(f"Health check failed during initialization: {self.name}")
                    return False
            
            self.logger.info(f"Tool initialized successfully: {self.name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize tool {self.name}: {str(e)}")
            self.status = ToolStatus.FAILED
            return False
    
    async def shutdown(self) -> bool:
        """
        Shutdown the tool gracefully. Override in subclasses for custom shutdown.
        
        Returns:
            True if shutdown successful, False otherwise
        """
        try:
            self.logger.info(f"Shutting down tool: {self.name}")
            self.status = ToolStatus.IDLE
            
            # Add any custom cleanup logic here
            
            self.logger.info(f"Tool shutdown successfully: {self.name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error during tool shutdown {self.name}: {str(e)}")
            return False
    
    async def health_check(self) -> bool:
        """
        Perform health check on the tool. Override in subclasses for custom health checks.
        
        Returns:
            True if tool is healthy, False otherwise
        """
        try:
            # Basic health check - verify the tool can be instantiated and basic methods exist
            basic_checks = [
                hasattr(self, 'execute'),
                hasattr(self, 'name'),
                hasattr(self, 'metadata'),
            ]
            
            if not all(basic_checks):
                return False
            
            self.metrics.last_health_check = datetime.utcnow()
            return True
            
        except Exception as e:
            self.logger.error(f"Health check failed for tool {self.name}: {str(e)}")
            self.metrics.health_check_failures += 1
            return False
    
    @asynccontextmanager
    async def execution_context(self, context: ToolExecutionContext):
        """Execution context manager for tool execution."""
        # Set execution-specific configurations
        original_timeout = getattr(self, 'timeout_seconds', None)
        if context.timeout_seconds:
            self.timeout_seconds = context.timeout_seconds
        
        self.status = ToolStatus.RUNNING
        
        try:
            yield context
        except Exception as e:
            self.status = ToolStatus.FAILED
            self.logger.error(
                f"Tool execution failed: {self.name}",
                extra={
                    "context": context.to_dict(),
                    "error": str(e),
                    "traceback": traceback.format_exc()
                }
            )
            raise
        finally:
            self.status = ToolStatus.IDLE
            if hasattr(self, 'timeout_seconds') and original_timeout:
                self.timeout_seconds = original_timeout
    
    async def execute_with_context(
        self, 
        *args, 
        context: Optional[ToolExecutionContext] = None,
        **kwargs
    ) -> Any:
        """
        Execute tool with context and resilience patterns.
        
        Args:
            context: Execution context with tracking and isolation
            *args: Arguments to pass to execute method
            **kwargs: Keyword arguments to pass to execute method
            
        Returns:
            Tool execution result
        """
        if not context:
            context = ToolExecutionContext()
        
        async with self.execution_context(context):
            # Use circuit breaker for resilience
            return await self.circuit_breaker.call(self._execute_with_monitoring, context, *args, **kwargs)
    
    async def _execute_with_monitoring(
        self, 
        context: ToolExecutionContext, 
        *args, 
        **kwargs
    ) -> Any:
        """Internal method that wraps execution with monitoring."""
        start_time = time.time()
        
        try:
            # Execute the tool
            result = await self.execute(*args, **kwargs)
            
            # Update metrics
            execution_time = (time.time() - start_time) * 1000
            self.metrics.update_on_execution(execution_time, True)
            
            self.logger.info(
                f"Tool executed successfully: {self.name}",
                extra={
                    "context": context.to_dict(),
                    "execution_time_ms": execution_time,
                    "result_type": type(result).__name__
                }
            )
            
            return result
            
        except Exception as error:
            # Update metrics on failure
            execution_time = (time.time() - start_time) * 1000
            self.metrics.update_on_execution(execution_time, False, error)
            
            self.logger.error(
                f"Tool execution failed: {self.name}",
                extra={
                    "context": context.to_dict(),
                    "execution_time_ms": execution_time,
                    "error": str(error),
                    "error_type": type(error).__name__
                }
            )
            
            # Re-raise as ToolError if not already
            if not isinstance(error, ToolError):
                raise ToolExecutionError(
                    f"Tool execution failed: {str(error)}",
                    tool_instance=self,
                    original_error=error,
                    context=context.to_dict()
                ) from error
            else:
                raise
    
    @abstractmethod
    async def execute(self, *args, **kwargs) -> Any:
        """
        Execute the tool's primary function. Must be implemented by subclasses.
        
        Args:
            *args: Tool-specific arguments
            **kwargs: Tool-specific keyword arguments
            
        Returns:
            Tool execution result
        """
        pass
    
    def get_config(self, key: str, default: Any = None) -> Any:
        """Get configuration value with fallback."""
        return self.config.get(key, default)
    
    def set_config(self, key: str, value: Any):
        """Set configuration value."""
        self.config[key] = value
    
    def update_config(self, updates: Dict[str, Any]):
        """Update multiple configuration values."""
        self.config.update(updates)
        self._validate_config(self.config)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current tool metrics."""
        return {
            "name": self.name,
            "version": self.version,
            "status": self.status.value,
            "metrics": {
                "total_executions": self.metrics.total_executions,
                "successful_executions": self.metrics.successful_executions,
                "failed_executions": self.metrics.failed_executions,
                "error_rate": self.metrics.error_rate,
                "average_execution_time_ms": self.metrics.average_execution_time_ms,
                "health_score": self.metrics.get_health_score(),
                "circuit_breaker_state": self.metrics.circuit_breaker_state.value,
            },
            "metadata": {
                "start_time": self._start_time.isoformat() if self._start_time else None,
                "uptime_seconds": (
                    (datetime.utcnow() - self._start_time).total_seconds() 
                    if self._start_time else None
                )
            }
        }
    
    def __repr__(self) -> str:
        """String representation of the tool."""
        return f"<{self.__class__.__name__}(name='{self.name}', version='{self.version}', status='{self.status.value}')>"


# Protocol for tool factory functions
ToolFactory = Callable[[], BaseTool]


class ToolInterface(Protocol):
    """Protocol defining the interface for all tools."""
    
    @property
    def name(self) -> str: ...
    
    @property
    def version(self) -> str: ...
    
    async def execute(self, *args, **kwargs) -> Any: ...
    
    async def initialize(self) -> bool: ...
    
    async def shutdown(self) -> bool: ...
    
    async def health_check(self) -> bool: ...
