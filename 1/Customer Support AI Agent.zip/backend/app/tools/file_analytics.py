"""
File Analytics Module

This module provides comprehensive analytics and monitoring capabilities for file processing including:
- File processing statistics and insights
- Content analysis and pattern recognition
- Performance monitoring and optimization
- Error tracking and reporting
- Usage analytics and trend analysis
- Quality metrics and KPI tracking

Features:
- Real-time processing analytics
- Content analysis and insights
- Performance monitoring
- Error tracking and categorization
- Usage pattern analysis
- Quality assurance metrics
- Predictive analytics
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from collections import defaultdict, Counter
from enum import Enum
import statistics
import re

from app.config import settings

logger = logging.getLogger(__name__)


class ProcessingStatus(Enum):
    """Processing status enumeration."""
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial"
    SKIPPED = "skipped"


class ErrorCategory(Enum):
    """Error category enumeration."""
    FILE_NOT_FOUND = "file_not_found"
    INVALID_FORMAT = "invalid_format"
    PROCESSING_FAILED = "processing_failed"
    SIZE_LIMIT_EXCEEDED = "size_limit_exceeded"
    SECURITY_VIOLATION = "security_violation"
    STORAGE_ERROR = "storage_error"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"


class ContentType(Enum):
    """Content type enumeration."""
    TEXT = "text"
    DOCUMENT = "document"
    SPREADSHEET = "spreadsheet"
    PRESENTATION = "presentation"
    IMAGE = "image"
    ARCHIVE = "archive"
    CODE = "code"
    DATA = "data"
    UNKNOWN = "unknown"


@dataclass
class ProcessingMetrics:
    """Processing metrics data structure."""
    total_files: int
    successful_files: int
    failed_files: int
    pending_files: int
    processing_time_avg: float
    processing_time_median: float
    processing_time_p95: float
    file_size_avg: float
    file_size_median: float
    success_rate: float
    throughput_per_hour: float
    error_rate: float
    last_updated: str


@dataclass
class ContentInsights:
    """Content analysis insights."""
    content_types: Dict[str, int]
    language_distribution: Dict[str, int]
    complexity_metrics: Dict[str, Any]
    keyword_frequencies: Dict[str, int]
    entity_counts: Dict[str, int]
    quality_scores: Dict[str, float]
    metadata_completeness: float


@dataclass
class ErrorAnalytics:
    """Error analysis data."""
    total_errors: int
    error_by_category: Dict[str, int]
    error_by_file_type: Dict[str, int]
    error_trends: List[Dict[str, Any]]
    common_error_patterns: List[Dict[str, Any]]
    resolution_suggestions: List[str]


@dataclass
class PerformanceMetrics:
    """Performance monitoring metrics."""
    cpu_usage_avg: float
    memory_usage_avg: float
    disk_io_avg: float
    network_io_avg: float
    processing_queue_length: int
    cache_hit_rate: float
    response_time_p50: float
    response_time_p95: float
    response_time_p99: float


class ContentAnalyzer:
    """Advanced content analysis and insights."""
    
    def __init__(self):
        self.insight_cache = {}
        self.analysis_patterns = {
            "email_pattern": re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            "phone_pattern": re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'),
            "url_pattern": re.compile(r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w)*)?)?'),
            "currency_pattern": re.compile(r'[$€£¥]\s?\d+(?:[,\d]*\.?\d*)?'),
            "date_pattern": re.compile(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}-\d{2}-\d{2}\b'),
            "code_pattern": re.compile(r'\b(def|class|function|import|const|var|let)\b'),
            "security_patterns": [
                re.compile(r'password\s*[=:]\s*[\'"][^\'"]*[\'"]', re.IGNORECASE),
                re.compile(r'api_key\s*[=:]\s*[\'"][^\'"]*[\'"]', re.IGNORECASE),
                re.compile(r'secret\s*[=:]\s*[\'"][^\'"]*[\'"]', re.IGNORECASE)
            ]
        }
    
    async def analyze_content_batch(self, contents: List[Tuple[str, str, str]]) -> ContentInsights:
        """
        Analyze a batch of content for insights.
        
        Args:
            contents: List of (content, content_type, file_type) tuples
            
        Returns:
            Content insights
        """
        content_types = Counter()
        language_distribution = Counter()
        complexity_data = []
        keyword_data = []
        entity_data = defaultdict(int)
        quality_scores = []
        metadata_samples = 0
        
        for content, content_type, file_type in contents:
            if not content:
                continue
            
            # Count content types
            content_types[content_type] += 1
            
            # Analyze complexity
            complexity = self._analyze_complexity(content)
            complexity_data.append(complexity)
            
            # Extract entities
            entities = self._extract_entities(content)
            for entity_type, count in entities.items():
                entity_data[entity_type] += count
            
            # Extract keywords
            keywords = self._extract_keywords(content)
            keyword_data.extend(keywords)
            
            # Quality scoring
            quality = self._calculate_quality_score(content, content_type, file_type)
            quality_scores.append(quality)
            
            # Security scanning
            security_issues = self._detect_security_issues(content)
            if security_issues:
                entity_data['security_issues'] += len(security_issues)
        
        # Aggregate results
        insights = ContentInsights(
            content_types=dict(content_types),
            language_distribution=dict(language_distribution),
            complexity_metrics=self._aggregate_complexity_metrics(complexity_data),
            keyword_frequencies=dict(Counter(keyword_data).most_common(50)),
            entity_counts=dict(entity_data),
            quality_scores={
                "average": statistics.mean(quality_scores) if quality_scores else 0,
                "median": statistics.median(quality_scores) if quality_scores else 0,
                "min": min(quality_scores) if quality_scores else 0,
                "max": max(quality_scores) if quality_scores else 0
            },
            metadata_completeness=metadata_samples / max(len(contents), 1)
        )
        
        return insights
    
    def _analyze_complexity(self, content: str) -> Dict[str, Any]:
        """Analyze content complexity."""
        if not content:
            return {}
        
        words = content.split()
        sentences = content.split('.')
        paragraphs = content.split('\n\n')
        
        # Basic metrics
        word_count = len(words)
        sentence_count = len(sentences)
        paragraph_count = len(paragraphs)
        
        # Advanced metrics
        avg_words_per_sentence = word_count / max(sentence_count, 1)
        avg_sentences_per_paragraph = sentence_count / max(paragraph_count, 1)
        
        # Readability metrics (simplified)
        syllable_count = sum(self._count_syllables(word) for word in words)
        avg_syllables_per_word = syllable_count / max(word_count, 1)
        
        # Vocabulary richness
        unique_words = len(set(word.lower() for word in words if word.isalnum()))
        vocabulary_richness = unique_words / max(word_count, 1)
        
        return {
            "word_count": word_count,
            "sentence_count": sentence_count,
            "paragraph_count": paragraph_count,
            "avg_words_per_sentence": avg_words_per_sentence,
            "avg_sentences_per_paragraph": avg_sentences_per_paragraph,
            "avg_syllables_per_word": avg_syllables_per_word,
            "vocabulary_richness": vocabulary_richness
        }
    
    def _count_syllables(self, word: str) -> int:
        """Count syllables in a word."""
        word = word.lower()
        vowels = "aeiouy"
        syllable_count = 0
        previous_was_vowel = False
        
        for char in word:
            is_vowel = char in vowels
            if is_vowel and not previous_was_vowel:
                syllable_count += 1
            previous_was_vowel = is_vowel
        
        return max(syllable_count, 1)
    
    def _extract_entities(self, content: str) -> Dict[str, int]:
        """Extract entities from content."""
        entities = defaultdict(int)
        
        # Pattern matching
        entities['emails'] = len(self.analysis_patterns['email_pattern'].findall(content))
        entities['phone_numbers'] = len(self.analysis_patterns['phone_pattern'].findall(content))
        entities['urls'] = len(self.analysis_patterns['url_pattern'].findall(content))
        entities['currency_amounts'] = len(self.analysis_patterns['currency_pattern'].findall(content))
        entities['dates'] = len(self.analysis_patterns['date_pattern'].findall(content))
        entities['code_snippets'] = len(self.analysis_patterns['code_pattern'].findall(content))
        
        # Count security violations
        security_violations = self._detect_security_issues(content)
        entities['security_violations'] = len(security_violations)
        
        return entities
    
    def _extract_keywords(self, content: str) -> List[str]:
        """Extract keywords from content."""
        import re
        
        # Clean and tokenize
        text = re.sub(r'[^\w\s]', '', content.lower())
        words = text.split()
        
        # Filter stop words
        stop_words = {
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 
            'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 
            'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can'
        }
        
        keywords = [word for word in words if len(word) > 2 and word not in stop_words]
        
        return keywords
    
    def _detect_security_issues(self, content: str) -> List[Dict[str, Any]]:
        """Detect potential security issues in content."""
        issues = []
        
        for pattern in self.analysis_patterns['security_patterns']:
            matches = pattern.findall(content)
            for match in matches:
                issues.append({
                    "type": "security_pattern",
                    "description": "Potential sensitive data exposure",
                    "severity": "high" if "password" in match.lower() else "medium"
                })
        
        # Check for SQL injection patterns
        sql_patterns = [
            r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b)",
            r"(\b(UNION|JOIN|WHERE)\b)",
            r"('.*?')",
            r"(\d+\s*=\s*\d+)"
        ]
        
        for pattern in sql_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                issues.append({
                    "type": "sql_pattern",
                    "description": "Potential SQL injection pattern",
                    "severity": "high"
                })
        
        return issues
    
    def _calculate_quality_score(self, content: str, content_type: str, file_type: str) -> float:
        """Calculate content quality score."""
        if not content:
            return 0.0
        
        score = 0.0
        
        # Content completeness (0-30 points)
        word_count = len(content.split())
        if word_count > 100:
            score += 20
        elif word_count > 50:
            score += 15
        elif word_count > 10:
            score += 10
        else:
            score += 5
        
        # Structure quality (0-25 points)
        has_paragraphs = '\n\n' in content
        has_proper_formatting = bool(re.search(r'[.!?]', content))
        has_headers = bool(re.search(r'^#', content, re.MULTILINE))
        
        if has_paragraphs and has_proper_formatting:
            score += 20
        elif has_proper_formatting:
            score += 15
        elif has_paragraphs:
            score += 10
        else:
            score += 5
        
        # Content diversity (0-25 points)
        unique_words = len(set(word.lower() for word in content.split() if word.isalnum()))
        total_words = len(content.split())
        diversity = unique_words / max(total_words, 1)
        
        if diversity > 0.7:
            score += 25
        elif diversity > 0.5:
            score += 20
        elif diversity > 0.3:
            score += 15
        else:
            score += 10
        
        # Error detection (0-20 points)
        security_issues = self._detect_security_issues(content)
        if not security_issues:
            score += 20
        elif len(security_issues) == 1:
            score += 15
        elif len(security_issues) == 2:
            score += 10
        else:
            score += 5
        
        return min(score, 100.0)
    
    def _aggregate_complexity_metrics(self, complexity_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Aggregate complexity metrics from multiple documents."""
        if not complexity_data:
            return {}
        
        metrics = {}
        
        for key in complexity_data[0].keys():
            values = [data.get(key, 0) for data in complexity_data if data.get(key) is not None]
            if values:
                metrics[f"{key}_avg"] = statistics.mean(values)
                metrics[f"{key}_median"] = statistics.median(values)
                metrics[f"{key}_min"] = min(values)
                metrics[f"{key}_max"] = max(values)
        
        return metrics


class PerformanceMonitor:
    """Performance monitoring and optimization."""
    
    def __init__(self):
        self.metrics_history = []
        self.performance_thresholds = {
            "processing_time_max": 300,  # 5 minutes
            "memory_usage_max": 2048,    # 2GB
            "cpu_usage_max": 80,         # 80%
            "queue_length_max": 100,
            "error_rate_max": 10         # 10%
        }
    
    async def record_processing_event(
        self,
        file_type: str,
        processing_time: float,
        success: bool,
        file_size: int,
        memory_usage: Optional[float] = None,
        cpu_usage: Optional[float] = None
    ):
        """Record a processing event for analytics."""
        event = {
            "timestamp": datetime.utcnow(),
            "file_type": file_type,
            "processing_time": processing_time,
            "success": success,
            "file_size": file_size,
            "memory_usage": memory_usage,
            "cpu_usage": cpu_usage
        }
        
        self.metrics_history.append(event)
        
        # Keep only last 1000 events
        if len(self.metrics_history) > 1000:
            self.metrics_history = self.metrics_history[-1000:]
    
    async def get_performance_metrics(self, time_window_hours: int = 24) -> PerformanceMetrics:
        """Get performance metrics for specified time window."""
        cutoff_time = datetime.utcnow() - timedelta(hours=time_window_hours)
        recent_events = [e for e in self.metrics_history if e["timestamp"] >= cutoff_time]
        
        if not recent_events:
            return PerformanceMetrics(
                cpu_usage_avg=0, memory_usage_avg=0, disk_io_avg=0, network_io_avg=0,
                processing_queue_length=0, cache_hit_rate=0, response_time_p50=0,
                response_time_p95=0, response_time_p99=0
            )
        
        # Calculate metrics
        processing_times = [e["processing_time"] for e in recent_events if e["processing_time"]]
        memory_usage = [e["memory_usage"] for e in recent_events if e["memory_usage"]]
        cpu_usage = [e["cpu_usage"] for e in recent_events if e["cpu_usage"]]
        
        return PerformanceMetrics(
            cpu_usage_avg=statistics.mean(cpu_usage) if cpu_usage else 0,
            memory_usage_avg=statistics.mean(memory_usage) if memory_usage else 0,
            disk_io_avg=0,  # Would need OS-specific monitoring
            network_io_avg=0,  # Would need network monitoring
            processing_queue_length=0,  # Would need queue monitoring
            cache_hit_rate=0,  # Would need cache statistics
            response_time_p50=statistics.median(processing_times) if processing_times else 0,
            response_time_p95=self._calculate_percentile(processing_times, 95) if processing_times else 0,
            response_time_p99=self._calculate_percentile(processing_times, 99) if processing_times else 0
        )
    
    def _calculate_percentile(self, data: List[float], percentile: float) -> float:
        """Calculate percentile from data."""
        if not data:
            return 0.0
        
        sorted_data = sorted(data)
        index = (percentile / 100) * (len(sorted_data) - 1)
        
        if index == int(index):
            return sorted_data[int(index)]
        else:
            lower = sorted_data[int(index)]
            upper = sorted_data[int(index) + 1]
            return lower + (upper - lower) * (index - int(index))
    
    async def detect_performance_issues(self) -> List[Dict[str, Any]]:
        """Detect performance issues based on thresholds."""
        issues = []
        
        # Get recent performance metrics
        metrics = await self.get_performance_metrics(1)  # Last hour
        
        # Check thresholds
        if metrics.cpu_usage_avg > self.performance_thresholds["cpu_usage_max"]:
            issues.append({
                "type": "high_cpu_usage",
                "value": metrics.cpu_usage_avg,
                "threshold": self.performance_thresholds["cpu_usage_max"],
                "severity": "high"
            })
        
        if metrics.memory_usage_avg > self.performance_thresholds["memory_usage_max"]:
            issues.append({
                "type": "high_memory_usage",
                "value": metrics.memory_usage_avg,
                "threshold": self.performance_thresholds["memory_usage_max"],
                "severity": "high"
            })
        
        if metrics.processing_queue_length > self.performance_thresholds["queue_length_max"]:
            issues.append({
                "type": "high_queue_length",
                "value": metrics.processing_queue_length,
                "threshold": self.performance_thresholds["queue_length_max"],
                "severity": "medium"
            })
        
        return issues


class ErrorTracker:
    """Error tracking and analysis."""
    
    def __init__(self):
        self.error_history = []
        self.error_patterns = {}
    
    async def record_error(
        self,
        error_message: str,
        file_type: str,
        file_size: int,
        error_category: ErrorCategory = ErrorCategory.UNKNOWN,
        stack_trace: Optional[str] = None
    ):
        """Record an error for analysis."""
        error_record = {
            "timestamp": datetime.utcnow(),
            "error_message": error_message,
            "file_type": file_type,
            "file_size": file_size,
            "error_category": error_category,
            "stack_trace": stack_trace
        }
        
        self.error_history.append(error_record)
        
        # Update error patterns
        pattern_key = f"{error_category.value}_{file_type}"
        if pattern_key not in self.error_patterns:
            self.error_patterns[pattern_key] = []
        self.error_patterns[pattern_key].append(error_record)
        
        # Keep only last 1000 errors
        if len(self.error_history) > 1000:
            self.error_history = self.error_history[-1000:]
    
    async def get_error_analytics(self, time_window_hours: int = 24) -> ErrorAnalytics:
        """Get error analytics for specified time window."""
        cutoff_time = datetime.utcnow() - timedelta(hours=time_window_hours)
        recent_errors = [e for e in self.error_history if e["timestamp"] >= cutoff_time]
        
        if not recent_errors:
            return ErrorAnalytics(
                total_errors=0,
                error_by_category={},
                error_by_file_type={},
                error_trends=[],
                common_error_patterns=[],
                resolution_suggestions=[]
            )
        
        # Analyze errors
        error_by_category = Counter(e["error_category"].value for e in recent_errors)
        error_by_file_type = Counter(e["file_type"] for e in recent_errors)
        
        # Calculate trends
        error_trends = self._calculate_error_trends(recent_errors)
        
        # Identify common patterns
        common_patterns = self._identify_common_patterns(recent_errors)
        
        # Generate resolution suggestions
        suggestions = self._generate_resolution_suggestions(recent_errors)
        
        return ErrorAnalytics(
            total_errors=len(recent_errors),
            error_by_category=dict(error_by_category),
            error_by_file_type=dict(error_by_file_type),
            error_trends=error_trends,
            common_error_patterns=common_patterns,
            resolution_suggestions=suggestions
        )
    
    def _calculate_error_trends(self, errors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Calculate error trends over time."""
        # Group errors by hour
        hourly_errors = defaultdict(int)
        
        for error in errors:
            hour_key = error["timestamp"].strftime("%Y-%m-%d %H:00")
            hourly_errors[hour_key] += 1
        
        # Convert to trend data
        trends = []
        for hour, count in sorted(hourly_errors.items()):
            trends.append({
                "time": hour,
                "error_count": count,
                "error_rate": count / max(1, len(errors)) * 100
            })
        
        return trends
    
    def _identify_common_patterns(self, errors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Identify common error patterns."""
        patterns = []
        
        # Group by error category and file type
        pattern_groups = defaultdict(list)
        
        for error in errors:
            key = f"{error['error_category'].value}_{error['file_type']}"
            pattern_groups[key].append(error)
        
        # Identify patterns with multiple occurrences
        for pattern, error_list in pattern_groups.items():
            if len(error_list) > 1:
                patterns.append({
                    "pattern": pattern,
                    "occurrences": len(error_list),
                    "description": f"Pattern {pattern} occurred {len(error_list)} times",
                    "sample_error": error_list[0]["error_message"]
                })
        
        return sorted(patterns, key=lambda x: x["occurrences"], reverse=True)
    
    def _generate_resolution_suggestions(self, errors: List[Dict[str, Any]]) -> List[str]:
        """Generate resolution suggestions based on error analysis."""
        suggestions = []
        
        # Analyze error categories
        categories = Counter(e["error_category"] for e in errors)
        
        if ErrorCategory.FILE_NOT_FOUND in categories:
            suggestions.append("Check file path validity and ensure files exist before processing")
        
        if ErrorCategory.INVALID_FORMAT in categories:
            suggestions.append("Implement better file format validation and error handling")
        
        if ErrorCategory.SIZE_LIMIT_EXCEEDED in categories:
            suggestions.append("Consider increasing file size limits or implementing streaming processing")
        
        if ErrorCategory.PROCESSING_FAILED in categories:
            suggestions.append("Review processing libraries and error handling for better stability")
        
        if ErrorCategory.SECURITY_VIOLATION in categories:
            suggestions.append("Enhance security scanning and file validation procedures")
        
        # File type specific suggestions
        file_types = Counter(e["file_type"] for e in errors)
        
        if "pdf" in file_types:
            suggestions.append("Consider upgrading PDF processing libraries for better compatibility")
        
        if "docx" in file_types:
            suggestions.append("Review Word document processing for better format support")
        
        return suggestions


class FileAnalyticsEngine:
    """Main analytics engine for comprehensive file processing analytics."""
    
    def __init__(self):
        self.content_analyzer = ContentAnalyzer()
        self.performance_monitor = PerformanceMonitor()
        self.error_tracker = ErrorTracker()
        self.session_data = defaultdict(lambda: {
            "files_processed": 0,
            "total_processing_time": 0,
            "success_count": 0,
            "error_count": 0,
            "file_types": Counter(),
            "start_time": None,
            "last_activity": None
        })
    
    async def start_session(self, session_id: str):
        """Start analytics session."""
        session = self.session_data[session_id]
        if session["start_time"] is None:
            session["start_time"] = datetime.utcnow()
        session["last_activity"] = datetime.utcnow()
    
    async def record_file_processing(
        self,
        session_id: str,
        file_type: str,
        processing_time: float,
        success: bool,
        file_size: int,
        content: Optional[str] = None,
        error_message: Optional[str] = None
    ):
        """Record file processing event."""
        session = self.session_data[session_id]
        session["files_processed"] += 1
        session["total_processing_time"] += processing_time
        session["file_types"][file_type] += 1
        session["last_activity"] = datetime.utcnow()
        
        if success:
            session["success_count"] += 1
        else:
            session["error_count"] += 1
            # Record error
            error_category = self._classify_error(error_message or "Unknown error")
            await self.error_tracker.record_error(
                error_message or "Unknown error",
                file_type,
                file_size,
                error_category
            )
        
        # Record performance metrics
        await self.performance_monitor.record_processing_event(
            file_type, processing_time, success, file_size
        )
        
        # Analyze content if available
        if content:
            # This would typically be done in batches for efficiency
            pass
    
    def _classify_error(self, error_message: str) -> ErrorCategory:
        """Classify error message into category."""
        message_lower = error_message.lower()
        
        if "not found" in message_lower or "does not exist" in message_lower:
            return ErrorCategory.FILE_NOT_FOUND
        elif "format" in message_lower or "extension" in message_lower or "invalid" in message_lower:
            return ErrorCategory.INVALID_FORMAT
        elif "size" in message_lower or "too large" in message_lower:
            return ErrorCategory.SIZE_LIMIT_EXCEEDED
        elif "security" in message_lower or "blocked" in message_lower:
            return ErrorCategory.SECURITY_VIOLATION
        elif "timeout" in message_lower or "time" in message_lower:
            return ErrorCategory.TIMEOUT
        elif "storage" in message_lower or "disk" in message_lower:
            return ErrorCategory.STORAGE_ERROR
        else:
            return ErrorCategory.UNKNOWN
    
    async def get_session_analytics(self, session_id: str) -> Dict[str, Any]:
        """Get analytics for specific session."""
        session = self.session_data[session_id]
        
        if session["files_processed"] == 0:
            return {"error": "No data for session"}
        
        avg_processing_time = session["total_processing_time"] / session["files_processed"]
        success_rate = session["success_count"] / session["files_processed"] * 100
        session_duration = (datetime.utcnow() - session["start_time"]).total_seconds() if session["start_time"] else 0
        
        return {
            "session_id": session_id,
            "session_duration_hours": round(session_duration / 3600, 2),
            "files_processed": session["files_processed"],
            "success_count": session["success_count"],
            "error_count": session["error_count"],
            "success_rate": round(success_rate, 2),
            "avg_processing_time": round(avg_processing_time, 3),
            "total_processing_time": round(session["total_processing_time"], 3),
            "file_types": dict(session["file_types"]),
            "throughput_per_hour": round(session["files_processed"] / max(session_duration / 3600, 1), 2) if session_duration > 0 else 0,
            "started_at": session["start_time"].isoformat() if session["start_time"] else None,
            "last_activity": session["last_activity"].isoformat() if session["last_activity"] else None
        }
    
    async def get_comprehensive_analytics(self, time_window_hours: int = 24) -> Dict[str, Any]:
        """Get comprehensive analytics report."""
        # Performance metrics
        performance_metrics = await self.performance_monitor.get_performance_metrics(time_window_hours)
        performance_issues = await self.performance_monitor.detect_performance_issues()
        
        # Error analytics
        error_analytics = await self.error_tracker.get_error_analytics(time_window_hours)
        
        # Session analytics
        active_sessions = len([s for s in self.session_data.values() 
                              if s["last_activity"] and 
                              (datetime.utcnow() - s["last_activity"]).total_seconds() < time_window_hours * 3600])
        
        total_files_processed = sum(s["files_processed"] for s in self.session_data.values())
        total_processing_time = sum(s["total_processing_time"] for s in self.session_data.values())
        
        return {
            "summary": {
                "time_window_hours": time_window_hours,
                "active_sessions": active_sessions,
                "total_files_processed": total_files_processed,
                "total_processing_time": round(total_processing_time, 3),
                "overall_success_rate": self._calculate_overall_success_rate(),
                "generated_at": datetime.utcnow().isoformat()
            },
            "performance": {
                "metrics": asdict(performance_metrics),
                "issues": performance_issues,
                "status": "healthy" if not performance_issues else "degraded"
            },
            "errors": asdict(error_analytics),
            "sessions": {
                "active": active_sessions,
                "total": len(self.session_data),
                "session_details": [self.get_session_analytics(sid) for sid in self.session_data.keys()]
            },
            "recommendations": self._generate_recommendations(performance_metrics, error_analytics)
        }
    
    def _calculate_overall_success_rate(self) -> float:
        """Calculate overall success rate across all sessions."""
        total_success = sum(s["success_count"] for s in self.session_data.values())
        total_files = sum(s["files_processed"] for s in self.session_data.values())
        
        return round(total_success / max(total_files, 1) * 100, 2)
    
    def _generate_recommendations(self, performance_metrics: PerformanceMetrics, error_analytics: ErrorAnalytics) -> List[str]:
        """Generate recommendations based on analytics."""
        recommendations = []
        
        # Performance recommendations
        if performance_metrics.response_time_p95 > 30:
            recommendations.append("High processing times detected. Consider optimizing processing pipeline or scaling resources.")
        
        if performance_metrics.cpu_usage_avg > 70:
            recommendations.append("High CPU usage detected. Consider upgrading hardware or optimizing algorithms.")
        
        if performance_metrics.memory_usage_avg > 1500:
            recommendations.append("High memory usage detected. Consider implementing memory-efficient processing or scaling.")
        
        # Error recommendations
        if error_analytics.total_errors > 50:
            recommendations.append("High error rate detected. Review error patterns and improve error handling.")
        
        if error_analytics.error_by_category.get("security_violation", 0) > 0:
            recommendations.append("Security violations detected. Enhance security scanning and file validation.")
        
        if error_analytics.error_by_category.get("size_limit_exceeded", 0) > 10:
            recommendations.append("Frequent size limit exceeded. Consider adjusting limits or implementing chunking.")
        
        return recommendations
    
    async def cleanup_old_data(self, max_age_hours: int = 168):  # 1 week
        """Clean up old analytics data."""
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
        
        # Clean up performance metrics
        self.performance_monitor.metrics_history = [
            event for event in self.performance_monitor.metrics_history 
            if event["timestamp"] >= cutoff_time
        ]
        
        # Clean up error history
        self.error_tracker.error_history = [
            error for error in self.error_tracker.error_history
            if error["timestamp"] >= cutoff_time
        ]
        
        # Clean up old sessions
        old_sessions = [
            session_id for session_id, session in self.session_data.items()
            if session["last_activity"] and session["last_activity"] < cutoff_time
        ]
        
        for session_id in old_sessions:
            del self.session_data[session_id]
        
        logger.info(f"Cleaned up analytics data older than {max_age_hours} hours")
    
    async def export_analytics(self, output_path: str, time_window_hours: int = 24) -> str:
        """Export analytics to JSON file."""
        analytics = await self.get_comprehensive_analytics(time_window_hours)
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w') as f:
            json.dump(analytics, f, indent=2, default=str)
        
        return str(output_file)


# Global analytics engine instance
analytics_engine = FileAnalyticsEngine()

# Export convenience functions
async def start_analytics_session(session_id: str):
    """Start analytics session."""
    await analytics_engine.start_session(session_id)

async def record_file_processing(
    session_id: str,
    file_type: str,
    processing_time: float,
    success: bool,
    file_size: int,
    content: Optional[str] = None,
    error_message: Optional[str] = None
):
    """Record file processing event."""
    await analytics_engine.record_file_processing(
        session_id, file_type, processing_time, success, file_size, content, error_message
    )

async def get_comprehensive_analytics(time_window_hours: int = 24):
    """Get comprehensive analytics."""
    return await analytics_engine.get_comprehensive_analytics(time_window_hours)

async def get_session_analytics(session_id: str):
    """Get session analytics."""
    return await analytics_engine.get_session_analytics(session_id)

# Start periodic cleanup
asyncio.create_task(analytics_engine.cleanup_old_data())
