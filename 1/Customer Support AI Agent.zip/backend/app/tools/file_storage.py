"""
File Storage Module

This module provides comprehensive file storage management capabilities including:
- File storage management and organization
- File cleanup and retention policies
- Access control and permissions
- Storage optimization and cleanup
- Backup and recovery features
- Storage quota and usage tracking

Features:
- Session-based file organization
- Automatic file cleanup and retention
- Access control and permissions
- Storage optimization
- Backup and recovery
- Storage analytics and monitoring
"""

import os
import shutil
import asyncio
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple, Set
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import aiofiles
import asyncpg
from contextlib import asynccontextmanager

from app.config import settings

logger = logging.getLogger(__name__)


class StorageType(Enum):
    """Storage types for different purposes."""
    UPLOAD = "upload"
    PROCESSED = "processed"
    TEMPORARY = "temporary"
    BACKUP = "backup"
    ARCHIVE = "archive"


class FileStatus(Enum):
    """File status enumeration."""
    PENDING = "pending"
    PROCESSING = "processing"
    PROCESSED = "processed"
    ERROR = "error"
    ARCHIVED = "archived"
    DELETED = "deleted"


@dataclass
class StorageQuota:
    """Storage quota information."""
    max_files: int
    max_size_mb: int
    max_age_days: int
    cleanup_enabled: bool
    backup_enabled: bool


@dataclass
class FileRecord:
    """File record for database tracking."""
    id: Optional[int]
    session_id: str
    original_name: str
    stored_name: str
    file_path: str
    file_size: int
    file_type: str
    mime_type: str
    file_hash: str
    status: FileStatus
    storage_type: StorageType
    created_at: str
    modified_at: str
    accessed_at: str
    processing_started: Optional[str] = None
    processing_completed: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None


@dataclass
class StorageStats:
    """Storage statistics."""
    total_files: int
    total_size_bytes: int
    total_size_mb: float
    files_by_type: Dict[str, int]
    files_by_status: Dict[str, int]
    files_by_storage_type: Dict[str, int]
    oldest_file_age: Optional[float]
    newest_file_age: Optional[float]
    storage_utilization: float
    quota_usage: Dict[str, Any]


class DatabaseStorage:
    """Database storage manager for file records."""
    
    def __init__(self, database_url: str):
        self.database_url = database_url
        self._init_pool()
    
    def _init_pool(self):
        """Initialize database connection pool."""
        # This will be initialized asynchronously
        self.pool = None
    
    async def initialize(self):
        """Initialize database connection pool."""
        try:
            self.pool = await asyncpg.create_pool(
                self.database_url,
                min_size=5,
                max_size=20,
                command_timeout=60
            )
            await self._create_tables()
            logger.info("Database storage initialized")
        except Exception as e:
            logger.error(f"Failed to initialize database storage: {str(e)}")
            raise
    
    async def _create_tables(self):
        """Create necessary database tables."""
        async with self.pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS file_records (
                    id SERIAL PRIMARY KEY,
                    session_id VARCHAR(255) NOT NULL,
                    original_name VARCHAR(255) NOT NULL,
                    stored_name VARCHAR(255) NOT NULL,
                    file_path TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    file_type VARCHAR(50) NOT NULL,
                    mime_type VARCHAR(100),
                    file_hash VARCHAR(64) UNIQUE NOT NULL,
                    status VARCHAR(20) NOT NULL DEFAULT 'pending',
                    storage_type VARCHAR(20) NOT NULL DEFAULT 'upload',
                    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    modified_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    accessed_at TIMESTAMP NOT NULL DEFAULT NOW(),
                    processing_started TIMESTAMP,
                    processing_completed TIMESTAMP,
                    error_message TEXT,
                    metadata JSONB,
                    tags TEXT[]
                )
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_records_session_id 
                ON file_records(session_id)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_records_status 
                ON file_records(status)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_records_hash 
                ON file_records(file_hash)
            """)
            
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_records_created 
                ON file_records(created_at)
            """)
    
    async def create_file_record(self, file_record: FileRecord) -> int:
        """Create a new file record."""
        async with self.pool.acquire() as conn:
            query = """
                INSERT INTO file_records 
                (session_id, original_name, stored_name, file_path, file_size, 
                 file_type, mime_type, file_hash, status, storage_type, 
                 metadata, tags)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                RETURNING id
            """
            
            record_id = await conn.fetchval(
                query,
                file_record.session_id,
                file_record.original_name,
                file_record.stored_name,
                file_record.file_path,
                file_record.file_size,
                file_record.file_type,
                file_record.mime_type,
                file_record.file_hash,
                file_record.status.value,
                file_record.storage_type.value,
                json.dumps(file_record.metadata) if file_record.metadata else None,
                file_record.tags
            )
            
            return record_id
    
    async def get_file_record(self, record_id: int) -> Optional[FileRecord]:
        """Get file record by ID."""
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM file_records WHERE id = $1",
                record_id
            )
            
            if row:
                return self._row_to_file_record(row)
            return None
    
    async def get_file_by_hash(self, file_hash: str) -> Optional[FileRecord]:
        """Get file record by hash."""
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM file_records WHERE file_hash = $1",
                file_hash
            )
            
            if row:
                return self._row_to_file_record(row)
            return None
    
    async def get_files_by_session(self, session_id: str) -> List[FileRecord]:
        """Get all file records for a session."""
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM file_records WHERE session_id = $1 ORDER BY created_at DESC",
                session_id
            )
            
            return [self._row_to_file_record(row) for row in rows]
    
    async def update_file_status(
        self, 
        record_id: int, 
        status: FileStatus, 
        error_message: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Update file status."""
        async with self.pool.acquire() as conn:
            await conn.execute("""
                UPDATE file_records 
                SET status = $2, error_message = $3, metadata = $4, modified_at = NOW()
                WHERE id = $1
            """, record_id, status.value, error_message, json.dumps(metadata) if metadata else None)
    
    async def update_access_time(self, record_id: int):
        """Update file access time."""
        async with self.pool.acquire() as conn:
            await conn.execute(
                "UPDATE file_records SET accessed_at = NOW() WHERE id = $1",
                record_id
            )
    
    async def delete_file_record(self, record_id: int):
        """Delete file record."""
        async with self.pool.acquire() as conn:
            await conn.execute("DELETE FROM file_records WHERE id = $1", record_id)
    
    async def get_storage_stats(self) -> StorageStats:
        """Get comprehensive storage statistics."""
        async with self.pool.acquire() as conn:
            # Total counts and sizes
            totals = await conn.fetchrow("""
                SELECT 
                    COUNT(*) as total_files,
                    SUM(file_size) as total_size,
                    MIN(created_at) as oldest_file,
                    MAX(created_at) as newest_file
                FROM file_records
                WHERE status != 'deleted'
            """)
            
            # Files by type
            files_by_type = await conn.fetch("""
                SELECT file_type, COUNT(*) as count
                FROM file_records
                WHERE status != 'deleted'
                GROUP BY file_type
            """)
            
            # Files by status
            files_by_status = await conn.fetch("""
                SELECT status, COUNT(*) as count
                FROM file_records
                WHERE status != 'deleted'
                GROUP BY status
            """)
            
            # Files by storage type
            files_by_storage_type = await conn.fetch("""
                SELECT storage_type, COUNT(*) as count
                FROM file_records
                WHERE status != 'deleted'
                GROUP BY storage_type
            """)
            
            return StorageStats(
                total_files=totals['total_files'] or 0,
                total_size_bytes=totals['total_size'] or 0,
                total_size_mb=round((totals['total_size'] or 0) / (1024 * 1024), 2),
                files_by_type={row['file_type']: row['count'] for row in files_by_type},
                files_by_status={row['status']: row['count'] for row in files_by_status},
                files_by_storage_type={row['storage_type']: row['count'] for row in files_by_storage_type},
                oldest_file_age=self._calculate_age_hours(totals['oldest_file']) if totals['oldest_file'] else None,
                newest_file_age=self._calculate_age_hours(totals['newest_file']) if totals['newest_file'] else None,
                storage_utilization=0.0,  # Will be calculated separately
                quota_usage={}  # Will be calculated separately
            )
    
    def _row_to_file_record(self, row) -> FileRecord:
        """Convert database row to FileRecord."""
        return FileRecord(
            id=row['id'],
            session_id=row['session_id'],
            original_name=row['original_name'],
            stored_name=row['stored_name'],
            file_path=row['file_path'],
            file_size=row['file_size'],
            file_type=row['file_type'],
            mime_type=row['mime_type'],
            file_hash=row['file_hash'],
            status=FileStatus(row['status']),
            storage_type=StorageType(row['storage_type']),
            created_at=str(row['created_at']),
            modified_at=str(row['modified_at']),
            accessed_at=str(row['accessed_at']),
            processing_started=str(row['processing_started']) if row['processing_started'] else None,
            processing_completed=str(row['processing_completed']) if row['processing_completed'] else None,
            error_message=row['error_message'],
            metadata=json.loads(row['metadata']) if row['metadata'] else None,
            tags=row['tags']
        )
    
    def _calculate_age_hours(self, timestamp) -> float:
        """Calculate age in hours from timestamp."""
        if not timestamp:
            return 0
        return (datetime.utcnow() - timestamp).total_seconds() / 3600


class PhysicalStorage:
    """Physical file storage manager."""
    
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Storage subdirectories
        self.storage_dirs = {
            StorageType.UPLOAD: self.base_path / "uploads",
            StorageType.PROCESSED: self.base_path / "processed",
            StorageType.TEMPORARY: self.base_path / "temp",
            StorageType.BACKUP: self.base_path / "backup",
            StorageType.ARCHIVE: self.base_path / "archive"
        }
        
        for storage_dir in self.storage_dirs.values():
            storage_dir.mkdir(exist_ok=True)
    
    async def create_session_directory(self, session_id: str, storage_type: StorageType = StorageType.UPLOAD) -> Path:
        """Create session directory."""
        session_dir = self.storage_dirs[storage_type] / session_id
        session_dir.mkdir(parents=True, exist_ok=True)
        return session_dir
    
    async def save_file(
        self,
        content: bytes,
        session_id: str,
        filename: str,
        storage_type: StorageType = StorageType.UPLOAD
    ) -> Tuple[Path, str]:
        """
        Save file to storage.
        
        Returns:
            Tuple of (file_path, file_hash)
        """
        # Create session directory
        session_dir = await self.create_session_directory(session_id, storage_type)
        
        # Generate unique filename
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        safe_filename = f"{timestamp}_{filename}"
        file_path = session_dir / safe_filename
        
        # Save file
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(content)
        
        # Calculate hash
        file_hash = await self._calculate_file_hash(file_path)
        
        logger.info(f"Saved file: {file_path}")
        return file_path, file_hash
    
    async def get_file(self, file_path: str) -> Optional[bytes]:
        """Get file content."""
        path = Path(file_path)
        
        if not path.exists():
            return None
        
        async with aiofiles.open(path, 'rb') as f:
            return await f.read()
    
    async def delete_file(self, file_path: str) -> bool:
        """Delete file."""
        try:
            path = Path(file_path)
            if path.exists():
                path.unlink()
                logger.info(f"Deleted file: {file_path}")
                return True
        except Exception as e:
            logger.error(f"Error deleting file {file_path}: {str(e)}")
        
        return False
    
    async def move_file(
        self,
        source_path: str,
        target_session_id: str,
        target_storage_type: StorageType,
        new_filename: Optional[str] = None
    ) -> Tuple[Path, str]:
        """Move file to different storage location."""
        source = Path(source_path)
        
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source_path}")
        
        # Create target directory
        target_dir = await self.create_session_directory(target_session_id, target_storage_type)
        
        # Generate target filename
        if new_filename is None:
            new_filename = source.name
        
        target_path = target_dir / new_filename
        
        # Move file
        shutil.move(str(source), str(target_path))
        
        # Calculate new hash
        file_hash = await self._calculate_file_hash(target_path)
        
        logger.info(f"Moved file from {source_path} to {target_path}")
        return target_path, file_hash
    
    async def copy_file(
        self,
        source_path: str,
        target_session_id: str,
        target_storage_type: StorageType,
        new_filename: Optional[str] = None
    ) -> Tuple[Path, str]:
        """Copy file to different storage location."""
        source = Path(source_path)
        
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source_path}")
        
        # Create target directory
        target_dir = await self.create_session_directory(target_session_id, target_storage_type)
        
        # Generate target filename
        if new_filename is None:
            new_filename = source.name
        
        target_path = target_dir / new_filename
        
        # Copy file
        shutil.copy2(str(source), str(target_path))
        
        # Calculate hash
        file_hash = await self._calculate_file_hash(target_path)
        
        logger.info(f"Copied file from {source_path} to {target_path}")
        return target_path, file_hash
    
    async def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA256 hash of file."""
        import hashlib
        
        sha256_hash = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                sha256_hash.update(chunk)
        
        return sha256_hash.hexdigest()
    
    async def cleanup_old_files(self, max_age_days: int = 7, storage_type: Optional[StorageType] = None) -> int:
        """Clean up old files."""
        cutoff_date = datetime.utcnow() - timedelta(days=max_age_days)
        cleaned_count = 0
        
        # Determine which directories to clean
        dirs_to_clean = [storage_type] if storage_type else list(self.storage_dirs.values())
        
        for storage_dir in dirs_to_clean:
            if isinstance(storage_dir, StorageType):
                storage_dir = self.storage_dirs[storage_dir]
            
            try:
                for file_path in storage_dir.rglob("*"):
                    if file_path.is_file():
                        file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                        if file_time < cutoff_date:
                            file_path.unlink()
                            cleaned_count += 1
            except Exception as e:
                logger.error(f"Error cleaning up {storage_dir}: {str(e)}")
        
        logger.info(f"Cleaned up {cleaned_count} old files")
        return cleaned_count
    
    def get_storage_usage(self) -> Dict[str, Any]:
        """Get storage usage statistics."""
        total_size = 0
        total_files = 0
        usage_by_type = {}
        
        for storage_type, storage_dir in self.storage_dirs.items():
            type_size = 0
            type_files = 0
            
            try:
                for file_path in storage_dir.rglob("*"):
                    if file_path.is_file():
                        file_size = file_path.stat().st_size
                        type_size += file_size
                        total_size += file_size
                        type_files += 1
                        total_files += 1
            except Exception as e:
                logger.error(f"Error calculating usage for {storage_dir}: {str(e)}")
            
            usage_by_type[storage_type.value] = {
                "files": type_files,
                "size_bytes": type_size,
                "size_mb": round(type_size / (1024 * 1024), 2)
            }
        
        return {
            "total_files": total_files,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "usage_by_type": usage_by_type,
            "base_path": str(self.base_path)
        }


class StorageManager:
    """Comprehensive storage management system."""
    
    def __init__(self, database_url: str = None, base_path: str = "./data/storage"):
        """Initialize storage manager."""
        self.database_url = database_url or settings.database_url
        self.base_path = Path(base_path)
        
        # Initialize components
        self.db_storage = DatabaseStorage(self.database_url)
        self.physical_storage = PhysicalStorage(str(self.base_path))
        
        # Storage quotas (configurable)
        self.quotas = {
            StorageType.UPLOAD: StorageQuota(
                max_files=1000,
                max_size_mb=5000,
                max_age_days=30,
                cleanup_enabled=True,
                backup_enabled=False
            ),
            StorageType.PROCESSED: StorageQuota(
                max_files=5000,
                max_size_mb=10000,
                max_age_days=90,
                cleanup_enabled=True,
                backup_enabled=True
            ),
            StorageType.TEMPORARY: StorageQuota(
                max_files=500,
                max_size_mb=1000,
                max_age_days=1,
                cleanup_enabled=True,
                backup_enabled=False
            ),
            StorageType.BACKUP: StorageQuota(
                max_files=100,
                max_size_mb=5000,
                max_age_days=365,
                cleanup_enabled=False,
                backup_enabled=True
            ),
            StorageType.ARCHIVE: StorageQuota(
                max_files=10000,
                max_size_mb=50000,
                max_age_days=2555,  # 7 years
                cleanup_enabled=False,
                backup_enabled=True
            )
        }
        
        # Background tasks
        self._cleanup_task = None
        self._backup_task = None
    
    async def initialize(self):
        """Initialize storage manager."""
        await self.db_storage.initialize()
        
        # Start background tasks
        await self.start_background_tasks()
        
        logger.info("Storage manager initialized")
    
    async def start_background_tasks(self):
        """Start background cleanup and backup tasks."""
        # Start cleanup task
        if not self._cleanup_task or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._periodic_cleanup())
        
        # Start backup task (if enabled)
        if not self._backup_task or self._backup_task.done():
            self._backup_task = asyncio.create_task(self._periodic_backup())
    
    async def stop_background_tasks(self):
        """Stop background tasks."""
        for task in [self._cleanup_task, self._backup_task]:
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
    
    async def store_file(
        self,
        content: bytes,
        session_id: str,
        filename: str,
        file_type: str,
        mime_type: str,
        storage_type: StorageType = StorageType.UPLOAD,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ) -> Tuple[int, str]:
        """
        Store file with full tracking.
        
        Returns:
            Tuple of (record_id, file_hash)
        """
        # Check quota
        if not await self._check_quota(storage_type):
            raise Exception(f"Storage quota exceeded for {storage_type.value}")
        
        # Save to physical storage
        file_path, file_hash = await self.physical_storage.save_file(
            content, session_id, filename, storage_type
        )
        
        # Create database record
        file_record = FileRecord(
            id=None,
            session_id=session_id,
            original_name=filename,
            stored_name=Path(file_path).name,
            file_path=str(file_path),
            file_size=len(content),
            file_type=file_type,
            mime_type=mime_type,
            file_hash=file_hash,
            status=FileStatus.PENDING,
            storage_type=storage_type,
            created_at=datetime.utcnow().isoformat(),
            modified_at=datetime.utcnow().isoformat(),
            accessed_at=datetime.utcnow().isoformat(),
            metadata=metadata,
            tags=tags
        )
        
        record_id = await self.db_storage.create_file_record(file_record)
        
        logger.info(f"Stored file {filename} (record_id: {record_id})")
        return record_id, file_hash
    
    async def get_file(self, record_id: int) -> Optional[Dict[str, Any]]:
        """Get file by record ID."""
        # Get file record
        file_record = await self.db_storage.get_file_record(record_id)
        
        if not file_record:
            return None
        
        # Update access time
        await self.db_storage.update_access_time(record_id)
        
        # Get file content
        content = await self.physical_storage.get_file(file_record.file_path)
        
        return {
            "record": file_record,
            "content": content
        }
    
    async def update_file_status(
        self,
        record_id: int,
        status: FileStatus,
        error_message: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Update file status."""
        await self.db_storage.update_file_status(record_id, status, error_message, metadata)
    
    async def get_files_by_session(self, session_id: str) -> List[FileRecord]:
        """Get all files for a session."""
        return await self.db_storage.get_files_by_session(session_id)
    
    async def delete_file(self, record_id: int) -> bool:
        """Delete file completely."""
        file_record = await self.db_storage.get_file_record(record_id)
        
        if not file_record:
            return False
        
        # Delete from physical storage
        await self.physical_storage.delete_file(file_record.file_path)
        
        # Delete from database
        await self.db_storage.delete_file_record(record_id)
        
        logger.info(f"Deleted file record {record_id}")
        return True
    
    async def archive_file(self, record_id: int) -> bool:
        """Archive file to archive storage."""
        file_record = await self.db_storage.get_file_record(record_id)
        
        if not file_record:
            return False
        
        # Move to archive storage
        new_path, new_hash = await self.physical_storage.move_file(
            file_record.file_path,
            f"archive_{file_record.session_id}",
            StorageType.ARCHIVE
        )
        
        # Update database record
        await self.db_storage.update_file_status(record_id, FileStatus.ARCHIVED)
        
        logger.info(f"Archived file record {record_id}")
        return True
    
    async def cleanup_expired_files(self) -> Dict[str, int]:
        """Clean up expired files based on quotas."""
        cleanup_stats = {}
        
        for storage_type, quota in self.quotas.items():
            if not quota.cleanup_enabled:
                continue
            
            # Clean up old files
            cleaned = await self.physical_storage.cleanup_old_files(
                quota.max_age_days, storage_type
            )
            cleanup_stats[storage_type.value] = cleaned
        
        return cleanup_stats
    
    async def _check_quota(self, storage_type: StorageType) -> bool:
        """Check if storage quota allows new file."""
        quota = self.quotas[storage_type]
        
        # Get current usage
        files_by_type = await self.db_storage.get_storage_stats()
        
        # Check file count
        current_files = files_by_type.files_by_storage_type.get(storage_type.value, 0)
        if current_files >= quota.max_files:
            return False
        
        # Check size (approximate)
        current_size_mb = files_by_type.total_size_mb
        if current_size_mb >= quota.max_size_mb:
            return False
        
        return True
    
    async def _periodic_cleanup(self):
        """Periodic cleanup task."""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour
                await self.cleanup_expired_files()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic cleanup: {str(e)}")
    
    async def _periodic_backup(self):
        """Periodic backup task."""
        while True:
            try:
                await asyncio.sleep(86400)  # Run daily
                await self._perform_backup()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic backup: {str(e)}")
    
    async def _perform_backup(self):
        """Perform backup of important files."""
        # This is a placeholder for backup implementation
        # In a real implementation, you would:
        # 1. Identify files to backup
        # 2. Create backup archives
        # 3. Store in backup location
        # 4. Clean up old backups
        
        logger.info("Performed periodic backup")
    
    async def get_comprehensive_stats(self) -> Dict[str, Any]:
        """Get comprehensive storage statistics."""
        db_stats = await self.db_storage.get_storage_stats()
        physical_stats = self.physical_storage.get_storage_usage()
        
        return {
            "database": asdict(db_stats),
            "physical": physical_stats,
            "quotas": {st.value: asdict(quota) for st, quota in self.quotas.items()},
            "background_tasks": {
                "cleanup_running": self._cleanup_task and not self._cleanup_task.done(),
                "backup_running": self._backup_task and not self._backup_task.done()
            }
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform storage health check."""
        health = {
            "status": "healthy",
            "checks": {},
            "errors": []
        }
        
        try:
            # Check database connectivity
            stats = await self.db_storage.get_storage_stats()
            health["checks"]["database"] = "ok"
        except Exception as e:
            health["checks"]["database"] = f"error: {str(e)}"
            health["status"] = "degraded"
            health["errors"].append(str(e))
        
        try:
            # Check physical storage
            usage = self.physical_storage.get_storage_usage()
            health["checks"]["physical_storage"] = "ok"
        except Exception as e:
            health["checks"]["physical_storage"] = f"error: {str(e)}"
            health["status"] = "degraded"
            health["errors"].append(str(e))
        
        try:
            # Check background tasks
            health["checks"]["cleanup_task"] = "running" if self._cleanup_task and not self._cleanup_task.done() else "stopped"
            health["checks"]["backup_task"] = "running" if self._backup_task and not self._backup_task.done() else "stopped"
        except Exception as e:
            health["checks"]["background_tasks"] = f"error: {str(e)}"
        
        return health


# Global storage manager instance
storage_manager = None

async def get_storage_manager() -> StorageManager:
    """Get or create global storage manager instance."""
    global storage_manager
    if storage_manager is None:
        storage_manager = StorageManager()
        await storage_manager.initialize()
    return storage_manager
