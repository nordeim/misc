"""
File Utilities Module

This module provides additional utility functions for file processing,
validation, and management that complement the main attachment tool.

Features:
- File format detection and validation
- Content sanitization and cleaning
- File size and type limits management
- Temporary file management
- Content analysis utilities
"""

import os
import re
import mimetypes
import hashlib
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime, timedelta
import json
import csv
import io

import aiofiles
import magic
import bleach
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class FileValidator:
    """Advanced file validation utilities."""
    
    # Maximum file sizes (in bytes)
    SIZE_LIMITS = {
        "pdf": 50 * 1024 * 1024,      # 50MB
        "docx": 50 * 1024 * 1024,     # 50MB
        "doc": 25 * 1024 * 1024,      # 25MB
        "txt": 10 * 1024 * 1024,      # 10MB
        "md": 10 * 1024 * 1024,       # 10MB
        "json": 25 * 1024 * 1024,     # 25MB
        "csv": 25 * 1024 * 1024,      # 25MB
        "xlsx": 50 * 1024 * 1024,     # 50MB
        "xls": 25 * 1024 * 1024,      # 25MB
        "pptx": 50 * 1024 * 1024,     # 50MB
        "ppt": 25 * 1024 * 1024,      # 25MB
        "jpg": 10 * 1024 * 1024,      # 10MB
        "jpeg": 10 * 1024 * 1024,     # 10MB
        "png": 10 * 1024 * 1024,      # 10MB
        "gif": 5 * 1024 * 1024,       # 5MB
        "tiff": 25 * 1024 * 1024,     # 25MB
        "webp": 10 * 1024 * 1024,     # 10MB
    }
    
    # MIME type mappings
    MIME_TYPE_MAP = {
        "application/pdf": ["pdf"],
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ["docx"],
        "application/msword": ["doc"],
        "text/plain": ["txt"],
        "text/markdown": ["md"],
        "application/json": ["json"],
        "text/csv": ["csv"],
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ["xlsx"],
        "application/vnd.ms-excel": ["xls"],
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": ["pptx"],
        "application/vnd.ms-powerpoint": ["ppt"],
        "image/jpeg": ["jpg", "jpeg"],
        "image/png": ["png"],
        "image/gif": ["gif"],
        "image/tiff": ["tiff", "tif"],
        "image/webp": ["webp"],
        "image/svg+xml": ["svg"],
    }
    
    @staticmethod
    def validate_file_extension(filename: str) -> Dict[str, Any]:
        """
        Validate file extension.
        
        Args:
            filename: Name of the file
            
        Returns:
            Validation result dictionary
        """
        path = Path(filename)
        extension = path.suffix.lower()[1:] if path.suffix else ""
        
        if not extension:
            return {
                "valid": False,
                "error": "File must have an extension"
            }
        
        # Check if extension is in allowed list
        from app.tools.attachment_tool import ALLOWED_EXTENSIONS
        if extension not in ALLOWED_EXTENSIONS:
            return {
                "valid": False,
                "error": f"File extension .{extension} is not allowed"
            }
        
        # Check if extension is in blocked list
        from app.tools.attachment_tool import BLOCKED_EXTENSIONS
        if extension in BLOCKED_EXTENSIONS:
            return {
                "valid": False,
                "error": f"File extension .{extension} is blocked for security reasons"
            }
        
        return {
            "valid": True,
            "extension": extension
        }
    
    @staticmethod
    def validate_file_size(file_path: str, extension: str = None) -> Dict[str, Any]:
        """
        Validate file size against limits.
        
        Args:
            file_path: Path to the file
            extension: File extension (optional, will be extracted if not provided)
            
        Returns:
            Validation result dictionary
        """
        path = Path(file_path)
        
        if not path.exists():
            return {
                "valid": False,
                "error": "File does not exist"
            }
        
        file_size = path.stat().st_size
        
        # Get extension if not provided
        if not extension:
            extension = path.suffix.lower()[1:] if path.suffix else ""
        
        # Check against specific limit if available
        max_size = FileValidator.SIZE_LIMITS.get(extension, 50 * 1024 * 1024)  # Default 50MB
        
        if file_size > max_size:
            return {
                "valid": False,
                "error": f"File size ({file_size} bytes) exceeds maximum allowed size for .{extension} files ({max_size} bytes)"
            }
        
        return {
            "valid": True,
            "size": file_size,
            "max_size": max_size,
            "within_limit": True
        }
    
    @staticmethod
    def validate_mime_type(file_path: str) -> Dict[str, Any]:
        """
        Validate file MIME type against extension.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Validation result dictionary
        """
        try:
            # Get MIME type using python-magic
            with magic.Magic() as m:
                detected_mime = m.id_filename(file_path)
            
            # Get expected MIME type from extension
            extension = Path(file_path).suffix.lower()[1:] if Path(file_path).suffix else ""
            expected_mime = mimetypes.guess_type(file_path)[0]
            
            # Check if detected MIME type matches expected
            is_valid = True
            warnings = []
            
            if expected_mime and detected_mime != expected_mime:
                # Check if they're compatible (e.g., both are text formats)
                if not FileValidator._are_mime_types_compatible(detected_mime, expected_mime):
                    is_valid = False
                    warnings.append(f"MIME type mismatch: detected {detected_mime}, expected {expected_mime}")
            
            return {
                "valid": is_valid,
                "detected_mime": detected_mime,
                "expected_mime": expected_mime,
                "warnings": warnings
            }
            
        except Exception as e:
            return {
                "valid": False,
                "error": f"Failed to detect MIME type: {str(e)}"
            }
    
    @staticmethod
    def _are_mime_types_compatible(mime1: str, mime2: str) -> bool:
        """Check if two MIME types are compatible."""
        # Extract main types (e.g., 'text' from 'text/plain')
        main_type1 = mime1.split('/')[0] if '/' in mime1 else mime1
        main_type2 = mime2.split('/')[0] if '/' in mime2 else mime2
        
        # Same main type is considered compatible
        return main_type1 == main_type2
    
    @classmethod
    def comprehensive_validate(cls, file_path: str) -> Dict[str, Any]:
        """
        Perform comprehensive file validation.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Comprehensive validation result
        """
        validation_result = {
            "valid": True,
            "checks": {},
            "warnings": [],
            "errors": []
        }
        
        # Extension validation
        ext_result = cls.validate_file_extension(file_path)
        validation_result["checks"]["extension"] = ext_result
        if not ext_result["valid"]:
            validation_result["valid"] = False
            validation_result["errors"].append(ext_result["error"])
        
        # Size validation
        size_result = cls.validate_file_size(file_path, ext_result.get("extension"))
        validation_result["checks"]["size"] = size_result
        if not size_result["valid"]:
            validation_result["valid"] = False
            validation_result["errors"].append(size_result["error"])
        
        # MIME type validation
        mime_result = cls.validate_mime_type(file_path)
        validation_result["checks"]["mime_type"] = mime_result
        if not mime_result["valid"]:
            validation_result["valid"] = False
            validation_result["errors"].append(mime_result["error"])
        if mime_result.get("warnings"):
            validation_result["warnings"].extend(mime_result["warnings"])
        
        return validation_result


class ContentCleaner:
    """Content cleaning and sanitization utilities."""
    
    # HTML tags to allow during sanitization
    ALLOWED_TAGS = [
        'p', 'br', 'strong', 'em', 'u', 'i', 'b', 'ul', 'ol', 'li',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'code', 'pre'
    ]
    
    # HTML attributes to allow
    ALLOWED_ATTRIBUTES = {
        '*': ['class'],
        'a': ['href', 'title'],
        'img': ['src', 'alt', 'title', 'width', 'height']
    }
    
    @staticmethod
    async def clean_text_content(content: str, remove_excess_whitespace: bool = True) -> str:
        """
        Clean and sanitize text content.
        
        Args:
            content: Raw text content
            remove_excess_whitespace: Whether to remove excess whitespace
            
        Returns:
            Cleaned content
        """
        if not content:
            return ""
        
        # Remove null bytes
        content = content.replace('\x00', '')
        
        # Normalize line endings
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        
        # Remove potential script injections
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.IGNORECASE | re.DOTALL)
        content = re.sub(r'javascript:', '', content, flags=re.IGNORECASE)
        content = re.sub(r'on\w+\s*=', '', content, flags=re.IGNORECASE)
        
        # Remove potential SQL injection patterns (basic)
        sql_patterns = [
            r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b)",
            r"(\b(UNION|JOIN|WHERE)\b)",
            r"('.*?')",
            r"(\d+\s*=\s*\d+)"
        ]
        for pattern in sql_patterns:
            content = re.sub(pattern, '[FILTERED]', content, flags=re.IGNORECASE)
        
        if remove_excess_whitespace:
            # Remove excess whitespace but preserve paragraph structure
            content = re.sub(r'\n{3,}', '\n\n', content)  # Max 2 consecutive newlines
            content = re.sub(r'[ \t]+', ' ', content)  # Multiple spaces to single space
            content = content.strip()
        
        return content
    
    @staticmethod
    async def clean_html_content(html_content: str) -> str:
        """
        Clean and sanitize HTML content.
        
        Args:
            html_content: Raw HTML content
            
        Returns:
            Cleaned HTML content
        """
        if not html_content:
            return ""
        
        try:
            # Use bleach for HTML sanitization
            cleaned = bleach.clean(
                html_content,
                tags=ContentCleaner.ALLOWED_TAGS,
                attributes=ContentCleaner.ALLOWED_ATTRIBUTES,
                protocols=['http', 'https', 'mailto'],
                strip=True
            )
            
            # Additional cleanup with BeautifulSoup
            soup = BeautifulSoup(cleaned, 'html.parser')
            
            # Remove empty paragraphs
            for p in soup.find_all('p'):
                if not p.get_text(strip=True):
                    p.decompose()
            
            return str(soup)
            
        except Exception as e:
            logger.warning(f"HTML cleaning failed: {str(e)}")
            # Fallback to basic text extraction
            return BeautifulSoup(html_content, 'html.parser').get_text()
    
    @staticmethod
    async def extract_structured_data(content: str, content_type: str) -> Dict[str, Any]:
        """
        Extract structured data from content.
        
        Args:
            content: Raw content
            content_type: Type of content (e.g., 'json', 'csv', 'xml')
            
        Returns:
            Extracted structured data
        """
        try:
            if content_type.lower() == 'json':
                return json.loads(content)
            elif content_type.lower() == 'csv':
                return ContentCleaner._parse_csv_content(content)
            elif content_type.lower() == 'xml':
                return ContentCleaner._parse_xml_content(content)
            else:
                return {"raw_content": content, "type": content_type}
        except Exception as e:
            return {
                "error": str(e),
                "raw_content": content[:1000] + "..." if len(content) > 1000 else content
            }
    
    @staticmethod
    def _parse_csv_content(content: str) -> Dict[str, Any]:
        """Parse CSV content."""
        try:
            lines = content.splitlines()
            if not lines:
                return {"error": "Empty CSV content"}
            
            # Use CSV reader
            reader = csv.reader(lines)
            headers = next(reader)
            
            data = []
            for row in reader:
                if len(row) == len(headers):
                    data.append(dict(zip(headers, row)))
            
            return {
                "headers": headers,
                "row_count": len(data),
                "data": data[:100]  # Limit to first 100 rows
            }
        except Exception as e:
            return {"error": f"CSV parsing failed: {str(e)}"}
    
    @staticmethod
    def _parse_xml_content(content: str) -> Dict[str, Any]:
        """Parse XML content."""
        try:
            soup = BeautifulSoup(content, 'xml')
            
            # Extract basic structure
            return {
                "root_element": soup.name if soup.name else "unknown",
                "children": [child.name for child in soup.children if hasattr(child, 'name')],
                "content_preview": str(soup.get_text())[:500]
            }
        except Exception as e:
            return {"error": f"XML parsing failed: {str(e)}"}


class FileAnalyzer:
    """Advanced file analysis utilities."""
    
    @staticmethod
    async def analyze_text_content(content: str) -> Dict[str, Any]:
        """
        Analyze text content and extract insights.
        
        Args:
            content: Text content to analyze
            
        Returns:
            Analysis results
        """
        if not content:
            return {"error": "No content to analyze"}
        
        analysis = {
            "basic_stats": {
                "char_count": len(content),
                "word_count": len(content.split()),
                "line_count": len(content.splitlines()),
                "paragraph_count": len([p for p in content.split('\n\n') if p.strip()]),
            },
            "language_detection": {},
            "content_type": "unknown",
            "complexity_metrics": {},
            "entities": [],
            "keywords": []
        }
        
        try:
            # Detect content type
            analysis["content_type"] = FileAnalyzer._detect_content_type(content)
            
            # Language detection (basic)
            analysis["language_detection"] = FileAnalyzer._detect_language(content)
            
            # Complexity metrics
            analysis["complexity_metrics"] = FileAnalyzer._calculate_complexity_metrics(content)
            
            # Extract entities (basic)
            analysis["entities"] = FileAnalyzer._extract_entities(content)
            
            # Extract keywords (basic)
            analysis["keywords"] = FileAnalyzer._extract_keywords(content)
            
        except Exception as e:
            analysis["error"] = str(e)
        
        return analysis
    
    @staticmethod
    def _detect_content_type(content: str) -> str:
        """Detect content type from text patterns."""
        # Check for JSON
        content = content.strip()
        if content.startswith('{') and content.endswith('}'):
            try:
                json.loads(content)
                return "json"
            except:
                pass
        
        # Check for XML
        if content.startswith('<?xml') or '<' in content and '>' in content:
            return "xml"
        
        # Check for CSV (contains commas and newlines)
        if ',' in content and '\n' in content:
            # Simple heuristic - check if first line looks like headers
            lines = content.splitlines()
            if lines and ',' in lines[0]:
                return "csv"
        
        # Check for code
        code_indicators = ['def ', 'class ', 'function', 'import ', 'from ', '#include']
        if any(indicator in content.lower() for indicator in code_indicators):
            return "code"
        
        # Check for markdown
        markdown_indicators = ['# ', '## ', '```', '[', '](']
        if any(indicator in content for indicator in markdown_indicators):
            return "markdown"
        
        return "plain_text"
    
    @staticmethod
    def _detect_language(content: str) -> Dict[str, Any]:
        """Basic language detection."""
        # Simple heuristic-based language detection
        english_indicators = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by']
        
        words = content.lower().split()
        english_count = sum(1 for word in words if word in english_indicators)
        
        if english_count > len(words) * 0.01:  # If > 1% of words are English indicators
            return {"detected": "en", "confidence": min(english_count / len(words) * 100, 95)}
        
        return {"detected": "unknown", "confidence": 0}
    
    @staticmethod
    def _calculate_complexity_metrics(content: str) -> Dict[str, Any]:
        """Calculate text complexity metrics."""
        words = content.split()
        sentences = content.split('.')
        
        if not words:
            return {}
        
        # Average word length
        avg_word_length = sum(len(word) for word in words) / len(words)
        
        # Average sentence length
        avg_sentence_length = len(words) / len(sentences) if sentences else 0
        
        # Vocabulary richness (unique words / total words)
        unique_words = len(set(word.lower() for word in words if word.isalnum()))
        vocabulary_richness = unique_words / len(words) if words else 0
        
        # Readability score (Flesch Reading Ease approximation)
        # This is a simplified version
        syllable_count = sum(FileAnalyzer._count_syllables(word) for word in words)
        readability_score = 206.835 - 1.015 * (len(words) / len(sentences)) - 84.6 * (syllable_count / len(words)) if sentences and words else 0
        
        return {
            "avg_word_length": round(avg_word_length, 2),
            "avg_sentence_length": round(avg_sentence_length, 2),
            "vocabulary_richness": round(vocabulary_richness, 3),
            "readability_score": round(readability_score, 2),
            "syllables_per_word": round(syllable_count / len(words), 2) if words else 0
        }
    
    @staticmethod
    def _count_syllables(word: str) -> int:
        """Count syllables in a word (approximate)."""
        word = word.lower()
        vowels = "aeiouy"
        syllable_count = 0
        previous_was_vowel = False
        
        for char in word:
            is_vowel = char in vowels
            if is_vowel and not previous_was_vowel:
                syllable_count += 1
            previous_was_vowel = is_vowel
        
        # Handle silent 'e'
        if word.endswith('e') and syllable_count > 1:
            syllable_count -= 1
        
        return max(syllable_count, 1)
    
    @staticmethod
    def _extract_entities(content: str) -> List[Dict[str, str]]:
        """Extract basic named entities (very simple implementation)."""
        entities = []
        
        # Find email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, content)
        for email in set(emails):
            entities.append({"type": "email", "value": email})
        
        # Find URLs
        url_pattern = r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w)*)?)?'
        urls = re.findall(url_pattern, content)
        for url in set(urls):
            entities.append({"type": "url", "value": url})
        
        # Find phone numbers (basic pattern)
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        phones = re.findall(phone_pattern, content)
        for phone in set(phones):
            entities.append({"type": "phone", "value": phone})
        
        return entities
    
    @staticmethod
    def _extract_keywords(content: str) -> List[Dict[str, Any]]:
        """Extract keywords from content."""
        # Simple keyword extraction based on frequency
        import re
        from collections import Counter
        
        # Clean and tokenize
        text = re.sub(r'[^\w\s]', '', content.lower())
        words = text.split()
        
        # Filter out common stop words
        stop_words = {'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those'}
        filtered_words = [word for word in words if len(word) > 2 and word not in stop_words]
        
        # Count word frequency
        word_counts = Counter(filtered_words)
        
        # Return top keywords
        keywords = [{"word": word, "frequency": count} for word, count in word_counts.most_common(20)]
        
        return keywords


class TemporaryFileManager:
    """Temporary file management utilities."""
    
    def __init__(self, temp_dir: str = None):
        self.temp_dir = Path(temp_dir) if temp_dir else Path(tempfile.gettempdir()) / "attachment_tool"
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self._cleanup_task = None
    
    async def create_temp_file(self, prefix: str = "att_", suffix: str = "") -> Path:
        """
        Create a temporary file.
        
        Args:
            prefix: File prefix
            suffix: File suffix
            
        Returns:
            Path to temporary file
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"{prefix}{timestamp}{suffix}"
        temp_file = self.temp_dir / filename
        
        # Create empty file
        temp_file.touch()
        
        return temp_file
    
    async def save_to_temp_file(self, content: Union[str, bytes], prefix: str = "att_", suffix: str = "") -> Path:
        """
        Save content to a temporary file.
        
        Args:
            content: Content to save
            prefix: File prefix
            suffix: File suffix
            
        Returns:
            Path to temporary file
        """
        temp_file = await self.create_temp_file(prefix, suffix)
        
        try:
            if isinstance(content, str):
                async with aiofiles.open(temp_file, 'w', encoding='utf-8') as f:
                    await f.write(content)
            else:
                async with aiofiles.open(temp_file, 'wb') as f:
                    await f.write(content)
        except Exception as e:
            # Clean up on error
            if temp_file.exists():
                temp_file.unlink()
            raise e
        
        return temp_file
    
    async def cleanup_temp_files(self, max_age_hours: int = 24) -> int:
        """
        Clean up temporary files older than specified hours.
        
        Args:
            max_age_hours: Maximum age in hours
            
        Returns:
            Number of files cleaned up
        """
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
        cleaned_count = 0
        
        try:
            for temp_file in self.temp_dir.rglob("*"):
                if temp_file.is_file():
                    file_time = datetime.fromtimestamp(temp_file.stat().st_mtime)
                    if file_time < cutoff_time:
                        temp_file.unlink()
                        cleaned_count += 1
        except Exception as e:
            logger.error(f"Error cleaning up temp files: {str(e)}")
        
        logger.info(f"Cleaned up {cleaned_count} temporary files")
        return cleaned_count
    
    def get_temp_file_stats(self) -> Dict[str, Any]:
        """Get statistics about temporary files."""
        total_files = 0
        total_size = 0
        oldest_file = None
        newest_file = None
        
        try:
            for temp_file in self.temp_dir.rglob("*"):
                if temp_file.is_file():
                    total_files += 1
                    file_size = temp_file.stat().st_size
                    total_size += file_size
                    
                    file_time = datetime.fromtimestamp(temp_file.stat().st_mtime)
                    
                    if oldest_file is None or file_time < oldest_file[1]:
                        oldest_file = (temp_file, file_time)
                    if newest_file is None or file_time > newest_file[1]:
                        newest_file = (temp_file, file_time)
        except Exception as e:
            logger.error(f"Error getting temp file stats: {str(e)}")
        
        return {
            "total_files": total_files,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "oldest_file": {
                "path": str(oldest_file[0]) if oldest_file else None,
                "age_hours": round((datetime.utcnow() - oldest_file[1]).total_seconds() / 3600, 2) if oldest_file else None
            },
            "newest_file": {
                "path": str(newest_file[0]) if newest_file else None,
                "age_hours": round((datetime.utcnow() - newest_file[1]).total_seconds() / 3600, 2) if newest_file else None
            },
            "temp_directory": str(self.temp_dir)
        }
    
    async def start_auto_cleanup(self, interval_hours: int = 1):
        """Start automatic cleanup task."""
        if self._cleanup_task and not self._cleanup_task.done():
            return
        
        async def cleanup_loop():
            while True:
                try:
                    await asyncio.sleep(interval_hours * 3600)  # Convert to seconds
                    await self.cleanup_temp_files()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error in cleanup loop: {str(e)}")
        
        self._cleanup_task = asyncio.create_task(cleanup_loop())
        logger.info(f"Started auto cleanup with {interval_hours}h interval")
    
    async def stop_auto_cleanup(self):
        """Stop automatic cleanup task."""
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
            logger.info("Stopped auto cleanup")


# Global instances
file_validator = FileValidator()
content_cleaner = ContentCleaner()
file_analyzer = FileAnalyzer()
temp_file_manager = TemporaryFileManager()

# Start automatic cleanup
asyncio.create_task(temp_file_manager.start_auto_cleanup())
