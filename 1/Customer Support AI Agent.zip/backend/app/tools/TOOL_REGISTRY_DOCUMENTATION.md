# BaseTool and ToolRegistry Pattern Documentation

## Overview

This document describes the complete BaseTool and ToolRegistry pattern implementation for the Customer Support AI Agent tool system. The pattern provides a standardized, resilient, and scalable approach to tool management with advanced features for monitoring, configuration, and lifecycle management.

## Architecture Components

### 1. BaseTool (Abstract Base Class)

The `BaseTool` class provides the foundation for all tools in the system:

#### Core Features:
- **Standardized Interface**: All tools inherit from `BaseTool` ensuring consistent APIs
- **Lifecycle Management**: Built-in initialization, health checking, and shutdown
- **Error Handling**: Comprehensive error types and handling patterns
- **Metrics Collection**: Automatic execution metrics and performance monitoring
- **Configuration Management**: Built-in configuration validation and management
- **Resilience Patterns**: Integration with retry mechanisms and circuit breakers

#### Key Methods:
```python
class BaseTool(ABC):
    @property
    def name(self) -> str: ...
    
    @abstractmethod
    async def execute(self, *args, **kwargs) -> Any: ...
    
    async def initialize(self) -> bool: ...
    async def shutdown(self) -> bool: ...
    async def health_check(self) -> bool: ...
    
    async def execute_with_context(self, context: ToolExecutionContext, *args, **kwargs): ...
    
    def get_metrics(self) -> Dict[str, Any]: ...
    def update_config(self, updates: Dict[str, Any]): ...
```

#### Usage Example:
```python
class MyTool(BaseTool):
    @property
    def name(self) -> str:
        return "my_custom_tool"
    
    def _get_metadata(self) -> ToolMetadata:
        return ToolMetadata(
            name=self.name,
            version="1.0.0",
            description="My custom tool",
            category="custom",
            timeout_seconds=300,
            max_retries=3
        )
    
    async def execute(self, param1: str, param2: int = 10) -> Dict[str, Any]:
        # Tool implementation
        return {"result": f"{param1}_{param2}"}

# Create and use the tool
tool = MyTool(config={"param2": 20})
await tool.initialize()
result = await tool.execute("hello", param2=15)
await tool.shutdown()
```

### 2. ToolRegistry (Dynamic Tool Management)

The `ToolRegistry` provides centralized management for all tool instances:

#### Core Features:
- **Dynamic Tool Loading**: Automatic discovery and registration of tools
- **Instance Management**: Pool management and lifecycle coordination
- **Event System**: Comprehensive event handling for tool lifecycle events
- **Health Monitoring**: Automatic health checks and status tracking
- **Resource Management**: Concurrency control and resource limits
- **Configuration Integration**: Environment-specific tool configuration

#### Key Features:
```python
class ToolRegistry:
    async def start(self): ...
    async def stop(self): ...
    
    def register_tool(self, tool_class: Type[BaseTool], **kwargs) -> str: ...
    async def execute_tool(self, tool_name: str, *args, **kwargs) -> Any: ...
    
    def list_tools(self, enabled_only: bool = False) -> List[str]: ...
    def get_tool_info(self, tool_name: str) -> Dict[str, Any]: ...
    
    async def enable_tool(self, tool_name: str) -> bool: ...
    async def disable_tool(self, tool_name: str) -> bool: ...
```

#### Usage Example:
```python
# Create and start registry
async with ToolRegistry(auto_discover=True) as registry:
    # Register tools
    registry.register_tool(MyTool, config={"timeout": 60})
    
    # Execute through registry
    result = await registry.execute_tool("my_custom_tool", "hello", param2=25)
    
    # Monitor status
    stats = registry.get_registry_stats()
```

### 3. Resilience Patterns

The system includes comprehensive resilience patterns:

#### Retry Manager:
```python
retry_config = RetryConfig(
    max_attempts=3,
    strategy=RetryStrategy.EXPONENTIAL_BACKOFF,
    base_delay=1.0,
    max_delay=60.0
)

retry_manager = RetryManager(retry_config)
result = await retry_manager.execute_with_retry(risky_function)
```

#### Circuit Breaker:
```python
circuit_breaker = AdvancedCircuitBreaker(
    failure_threshold=5,
    recovery_timeout=60.0
)

# Use with any function
result = await circuit_breaker.call(unreliable_function, *args, **kwargs)
```

#### Decorator Pattern:
```python
@create_resilient_method(
    retry_config=RetryConfig(max_attempts=3),
    circuit_breaker_config=None,  # Use defaults
    isolation_level="default"
)
async def my_resilient_method(self, param1, param2):
    # This method automatically gets resilience features
    return await self.process_data(param1, param2)
```

### 4. Configuration Management

#### Tool Configuration:
```python
config = ToolConfiguration(
    tool_name="my_tool",
    environment="production"
)

config.add_parameter(ConfigParameter(
    name="timeout",
    type=int,
    default=300,
    description="Execution timeout",
    required=True
))

config.set_value("timeout", 600)
```

#### Environment Management:
```python
environment_manager = get_global_environment()

# Get environment-specific config
config = environment_manager.get_environment_config("my_tool", "production")

# Select appropriate tool variant
tool_name = environment_manager.select_tool_for_environment("my_tool", "staging")

# Get deployment strategy
strategy = environment_manager.get_deployment_strategy("my_tool", "production")
```

### 5. Monitoring and Analytics

#### Metrics Collection:
```python
# Automatic metrics collection
tool = MyTool()
result = await tool.execute("test")

# Get detailed metrics
metrics = tool.get_metrics()
# {
#     "name": "my_custom_tool",
#     "version": "1.0.0",
#     "status": "success",
#     "metrics": {
#         "total_executions": 1,
#         "successful_executions": 1,
#         "error_rate": 0.0,
#         "average_execution_time_ms": 15.5,
#         "health_score": 1.0
#     }
# }
```

#### Health Checks:
```python
# Individual tool health check
health_result = await check_tool_health(tool)
# {
#     "tool_name": "my_custom_tool",
#     "status": "healthy",
#     "timestamp": "2025-11-04T05:17:18Z",
#     "checks": {
#         "basic_health": {"status": "passed", "response": True},
#         "metrics": {"status": "passed", "health_score": 1.0},
#         "configuration": {"status": "passed", "config_keys": [...]}
#     }
# }

# Registry-wide health monitoring
registry_stats = registry.get_registry_stats()
```

### 6. Tool Validation and Testing

#### Validation:
```python
# Validate tool structure and functionality
validation_result = validate_tool(tool)
# ToolValidationResult(
#     is_valid=True,
#     errors=[],
#     warnings=["Consider adding more documentation"],
#     score=0.95
# )
```

#### Testing:
```python
# Quick functionality test
test_result = await quick_tool_test(MyTool, config={"test": True})
# {
#     "validation": {
#         "valid": True,
#         "score": 0.95,
#         "errors": [],
#         "warnings": [...]
#     },
#     "basic_test": {
#         "status": "passed",
#         "execution_time_ms": 25.3,
#         "result_type": "dict"
#     },
#     "overall_status": "passed"
# }
```

### 7. Documentation Generation

#### Schema Generation:
```python
# Generate JSON schema for tool configuration
schema = get_tool_schema(tool)
# {
#     "type": "object",
#     "properties": {
#         "timeout": {"type": "integer", "default": 300},
#         "max_retries": {"type": "integer", "default": 3},
#         "log_level": {"type": "string", "default": "INFO"}
#     },
#     "required": ["timeout"]
# }
```

## Quick Start Guide

### 1. Basic Tool Creation

```python
from app.tools import BaseTool, ToolMetadata

class SimpleTool(BaseTool):
    @property
    def name(self) -> str:
        return "simple_tool"
    
    def _get_metadata(self) -> ToolMetadata:
        return ToolMetadata(
            name=self.name,
            version="1.0.0",
            description="A simple example tool",
            category="example",
            default_config={"message": "Hello World"}
        )
    
    async def execute(self, name: str = "World") -> Dict[str, Any]:
        message = self.get_config("message", "Hello")
        return {
            "greeting": f"{message}, {name}!",
            "tool_name": self.name
        }

# Use the tool
tool = SimpleTool()
await tool.initialize()
result = await tool.execute("Alice")  # {"greeting": "Hello World, Alice!", "tool_name": "simple_tool"}
```

### 2. Registry Usage

```python
from app.tools import ToolRegistry, setup_registry

# Start registry
registry = await setup_registry(auto_discover=True)

# Register your tool
registry.register_tool(SimpleTool, config={"message": "Hi there"})

# Execute through registry
result = await registry.execute_tool("simple_tool", "Bob")

# Get status
stats = registry.get_registry_stats()
print(f"Total tools: {stats['total_tools']}")
```

### 3. Configuration Setup

```python
from app.tools import create_tool_config, get_global_config

# Create standard configuration
config = create_tool_config("my_tool", environment="production")

# Register with configuration manager
config_manager = get_global_config()
config_manager.register_tool_config(config)

# Load from environment
config_manager.load_from_environment(prefix="MY_TOOL_")
```

### 4. Resilience Patterns

```python
from app.tools import create_resilient_method, RetryConfig, RetryStrategy
from app.tools.patterns import RetryManager

# Method-level resilience
class ResilientTool(BaseTool):
    @create_resilient_method(
        retry_config=RetryConfig(
            max_attempts=5,
            strategy=RetryStrategy.EXPONENTIAL_BACKOFF
        )
    )
    async def execute_with_retries(self, data):
        return await self.process_data(data)

# Function-level resilience
retry_manager = RetryManager(RetryConfig(max_attempts=3))

async def risky_operation():
    # Your risky operation here
    return await some_api_call()

result = await retry_manager.execute_with_retry(risky_operation)
```

### 5. Monitoring Setup

```python
from app.tools import check_tool_health

# Monitor individual tool
tool = SimpleTool()
health = await check_tool_health(tool)

# Get comprehensive metrics
metrics = tool.get_metrics()
health_score = metrics["metrics"]["health_score"]

# Monitor registry-wide
registry = await setup_registry()
stats = registry.get_registry_stats()
```

## Advanced Features

### 1. Custom Tool Metadata

```python
def _get_metadata(self) -> ToolMetadata:
    return ToolMetadata(
        name=self.name,
        version="2.0.0",
        description="Advanced tool with custom metadata",
        category="advanced",
        tags=["tag1", "tag2", "tag3"],
        dependencies=["external_service"],
        supported_formats=["json", "xml"],
        
        # Execution constraints
        timeout_seconds=600,
        max_retries=5,
        circuit_breaker_threshold=10,
        
        # Resource limits
        max_concurrent_executions=50,
        memory_limit_mb=1024,
        cpu_limit_percent=90,
        
        # Health monitoring
        health_check_enabled=True,
        health_check_interval_seconds=60,
        metrics_enabled=True,
        
        # Configuration
        config_schema={
            "type": "object",
            "properties": {
                "api_key": {"type": "string", "secret": True},
                "timeout": {"type": "integer", "minimum": 30},
                "debug": {"type": "boolean", "default": False}
            },
            "required": ["api_key"]
        },
        default_config={
            "timeout": 300,
            "debug": False
        }
    )
```

### 2. Execution Context

```python
from app.tools import ToolExecutionContext, ToolPriority

# Create execution context
context = ToolExecutionContext(
    execution_id="exec_123",
    session_id="session_456", 
    user_id="user_789",
    priority=ToolPriority.HIGH,
    timeout_seconds=120,
    metadata={"workflow": "batch_processing"},
    tags=["batch", "priority"]
)

# Execute with context
result = await tool.execute_with_context(
    "data_to_process",
    context=context
)
```

### 3. Tool Versioning

```python
from app.tools.patterns import get_global_patterns

patterns = get_global_patterns()
version_manager = patterns["version_manager"]

# Register version
version_manager.register_tool_version("my_tool", "1.0.0")

# Check compatibility
is_compatible = version_manager.is_compatible("my_tool", "1.0.0")

# Update version
version_manager.update_tool_version("my_tool", "1.2.0")
```

### 4. Custom Validators

```python
from app.tools.utils import ToolValidator, ToolValidatorRegistry

class CustomValidator(ToolValidator):
    async def validate(self, tool: BaseTool) -> ToolValidationResult:
        result = ToolValidationResult(is_valid=True)
        
        # Custom validation logic
        if hasattr(tool, 'custom_feature'):
            result.add_warning("Consider implementing custom_feature")
        
        # Performance check
        start_time = time.time()
        try:
            await asyncio.wait_for(tool.execute(), timeout=5.0)
            execution_time = (time.time() - start_time) * 1000
            
            if execution_time > 1000:
                result.add_warning(f"Tool execution slow: {execution_time:.2f}ms")
                
        except asyncio.TimeoutError:
            result.add_error("Tool execution timed out")
        
        result.calculate_score()
        return result

# Register validator
validator_registry = ToolValidatorRegistry()
validator_registry.register_validator("custom", CustomValidator())
```

### 5. Event Handling

```python
from app.tools.registry import ToolRegistryEventHandler, RegistryEvent, RegistryEventType

class CustomEventHandler(ToolRegistryEventHandler):
    async def handle_event(self, event: RegistryEvent):
        if event.event_type == RegistryEventType.TOOL_ERROR:
            # Send alert for tool errors
            await self.send_alert(event.tool_name, event.data)
        elif event.event_type == RegistryEventType.TOOL_REGISTERED:
            # Log new tool registration
            logger.info(f"New tool registered: {event.tool_name}")

# Add custom handler
registry.add_event_handler(CustomEventHandler())
```

## Environment Configuration

### Development Environment

```yaml
# config/development.yaml
tools:
  simple_tool:
    parameters:
      timeout:
        type: int
        default: 60
        required: false
      debug:
        type: boolean
        default: true
    values:
      timeout: 60
      debug: true
  
  my_tool:
    parameters:
      api_endpoint:
        type: string
        default: "https://dev-api.example.com"
    values:
      api_endpoint: "https://dev-api.example.com"
```

### Production Environment

```yaml
# config/production.yaml
tools:
  simple_tool:
    parameters:
      timeout:
        type: int
        default: 300
        required: true
      debug:
        type: boolean
        default: false
    values:
      timeout: 300
      debug: false
  
  my_tool:
    parameters:
      api_endpoint:
        type: string
        default: "https://api.example.com"
    values:
      api_endpoint: "https://api.example.com"
      ssl_enabled: true
```

### Environment Variables

```bash
# Set environment-specific configuration
export TOOL_ENVIRONMENT=production

# Tool-specific environment variables
export TOOL_SIMPLE_TOOL_TIMEOUT=600
export TOOL_SIMPLE_TOOL_DEBUG=false
export TOOL_MY_TOOL_API_ENDPOINT="https://prod-api.example.com"
```

## Best Practices

### 1. Tool Development

- **Always inherit from BaseTool**: Use the standardized interface
- **Implement proper metadata**: Provide clear descriptions and constraints
- **Handle errors gracefully**: Use appropriate error types and recovery
- **Make tools idempotent**: Ensure repeated calls produce consistent results
- **Document thoroughly**: Provide clear docstrings and examples

### 2. Configuration Management

- **Use type validation**: Ensure configuration values match expected types
- **Provide sensible defaults**: Make tools work out-of-the-box
- **Version configurations**: Track changes to configuration schemas
- **Environment isolation**: Keep dev, staging, and prod configs separate

### 3. Error Handling

- **Use specific error types**: `ToolValidationError`, `ToolExecutionError`, etc.
- **Implement graceful degradation**: Tools should fail safely
- **Provide meaningful messages**: Include context in error messages
- **Log appropriately**: Use structured logging with context

### 4. Performance

- **Monitor resource usage**: Track memory and CPU consumption
- **Implement caching**: Cache expensive operations when appropriate
- **Use connection pooling**: Reuse database connections and HTTP sessions
- **Profile regularly**: Use metrics to identify performance bottlenecks

### 5. Testing

- **Unit test thoroughly**: Test all tool methods and edge cases
- **Integration test with registry**: Test tool behavior in registry context
- **Load test for performance**: Verify tools handle expected load
- **Chaos test for resilience**: Test failure scenarios and recovery

## Migration Guide

### Upgrading Existing Tools

To upgrade an existing tool to the new pattern:

```python
from app.tools import upgrade_existing_tool

# Upgrade existing tool class
UpgradedTool = upgrade_existing_tool(ExistingToolClass)

# Or manually migrate
class MigratedTool(ExistingToolClass, BaseTool):
    def __init__(self, config=None):
        BaseTool.__init__(self, config)
        ExistingToolClass.__init__(self)
    
    @property 
    def name(self) -> str:
        return self.__class__.__name__.lower()
    
    async def execute(self, *args, **kwargs):
        # Ensure execute method signature is compatible
        return await super().execute(*args, **kwargs)

# Test the migrated tool
tool = MigratedTool()
result = await quick_tool_test(MigratedTool)
```

### Gradual Adoption

1. **Phase 1**: Create new tools using BaseTool pattern
2. **Phase 2**: Register tools with registry for testing
3. **Phase 3**: Migrate existing tools incrementally
4. **Phase 4**: Enable full registry integration
5. **Phase 5**: Leverage advanced features (resilience, monitoring, etc.)

## Troubleshooting

### Common Issues

#### Tool Registration Fails
```python
# Check tool inheritance
if not issubclass(tool_class, BaseTool):
    raise ValueError("Tool must inherit from BaseTool")

# Verify tool has required methods
required_methods = ['execute']
for method in required_methods:
    if not hasattr(tool_class, method):
        raise ValueError(f"Tool must implement {method}")
```

#### Configuration Errors
```python
# Validate configuration schema
try:
    tool = MyTool(config=config)
    tool._validate_config(config)
except ToolValidationError as e:
    print(f"Configuration error: {e}")
```

#### Execution Failures
```python
# Check tool health
health = await tool.health_check()
if not health:
    print("Tool health check failed")

# Check metrics for patterns
metrics = tool.get_metrics()
if metrics['metrics']['error_rate'] > 0.5:
    print("High error rate detected")
```

#### Registry Issues
```python
# Check registry status
registry_stats = registry.get_registry_stats()
print(f"Registry status: {registry_stats}")

# Check tool registration
tools = registry.list_tools()
print(f"Registered tools: {tools}")
```

## Performance Considerations

### Memory Management
- Configure appropriate memory limits per tool
- Monitor memory usage through metrics
- Implement cleanup in shutdown methods
- Use weak references where appropriate

### Concurrency Management
- Set max_concurrent_executions based on resource availability
- Use execution context for resource isolation
- Implement proper locking for shared resources
- Monitor execution queue lengths

### Database Connections
- Use connection pooling for database-backed tools
- Implement proper session management
- Monitor connection pool metrics
- Handle connection failures gracefully

### Network Operations
- Implement timeouts for all network calls
- Use retry patterns for transient failures
- Cache responses when appropriate
- Monitor network latency and error rates

## Security Considerations

### Configuration Security
- Mark sensitive parameters with `secret=True`
- Use environment variables for secrets
- Implement configuration encryption for storage
- Audit configuration access

### Execution Isolation
- Use execution context for resource isolation
- Implement proper access controls
- Validate all inputs before execution
- Monitor for unusual execution patterns

### Tool Sandboxing
- Consider container isolation for untrusted tools
- Implement resource quotas and limits
- Monitor tool behavior for anomalies
- Maintain tool dependency security

## Conclusion

The BaseTool and ToolRegistry pattern provides a comprehensive foundation for building scalable, resilient, and maintainable tool systems. By following the patterns and best practices outlined in this documentation, you can build tools that integrate seamlessly with the registry system and leverage advanced features for monitoring, configuration, and lifecycle management.

The pattern supports gradual adoption, allowing existing tools to be migrated incrementally while new tools can take full advantage of the advanced features from day one.
