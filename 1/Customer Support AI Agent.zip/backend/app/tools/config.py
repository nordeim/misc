"""
Tool configuration system for settings, parameters, and environment-based management.

Provides:
- Tool settings and parameters management
- Tool-specific configurations with validation
- Environment-based tool selection and configuration
- Tool deployment and scaling configurations
- Configuration versioning and migration
"""

import os
import json
import yaml
import logging
from typing import (
    Any, Dict, List, Optional, Union, Callable, Type,
    Generic, TypeVar, Protocol
)
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from abc import ABC, abstractmethod
import jsonschema
from copy import deepcopy

from .base_tool import BaseTool, ToolError, ToolValidationError


T = TypeVar('T')


class ConfigSource(Enum):
    """Configuration source enumeration."""
    FILE = "file"
    ENVIRONMENT = "environment"
    DATABASE = "database"
    REMOTE = "remote"
    COMMAND_LINE = "command_line"
    DEFAULT = "default"
    RUNTIME = "runtime"


class ConfigFormat(Enum):
    """Configuration format enumeration."""
    JSON = "json"
    YAML = "yaml"
    ENV = "env"
    TOML = "toml"


class DeploymentMode(Enum):
    """Tool deployment mode enumeration."""
    STANDALONE = "standalone"
    CLUSTERED = "clustered"
    SCALED = "scaled"
    CONTAINER = "container"
    SERVERLESS = "serverless"


@dataclass
class ConfigParameter:
    """Definition of a configuration parameter."""
    name: str
    type: Type
    default: Any = None
    description: str = ""
    required: bool = False
    choices: Optional[List[Any]] = None
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    pattern: Optional[str] = None
    environment_variable: Optional[str] = None
    secret: bool = False
    validation_schema: Optional[Dict[str, Any]] = None
    
    def validate(self, value: Any) -> bool:
        """Validate a value against this parameter definition."""
        if value is None:
            return not self.required
        
        # Type validation
        if not isinstance(value, self.type):
            if self.type == bool and isinstance(value, str):
                # Handle string to bool conversion
                if value.lower() in ['true', '1', 'yes', 'on']:
                    return True
                elif value.lower() in ['false', '0', 'no', 'off']:
                    return True
            return False
        
        # Choices validation
        if self.choices and value not in self.choices:
            return False
        
        # Range validation
        if self.min_value is not None and value < self.min_value:
            return False
        
        if self.max_value is not None and value > self.max_value:
            return False
        
        # Pattern validation
        if self.pattern and isinstance(value, str):
            import re
            if not re.match(self.pattern, value):
                return False
        
        # Custom schema validation
        if self.validation_schema:
            try:
                jsonschema.validate(value, self.validation_schema)
            except jsonschema.ValidationError:
                return False
        
        return True
    
    def coerce_value(self, value: Any) -> Any:
        """Coerce a value to the correct type."""
        if value is None:
            return self.default
        
        if isinstance(value, self.type):
            return value
        
        # String to type conversion
        if self.type == bool and isinstance(value, str):
            return value.lower() in ['true', '1', 'yes', 'on']
        elif self.type == int and isinstance(value, str):
            return int(value)
        elif self.type == float and isinstance(value, (str, int)):
            return float(value)
        elif self.type == list and isinstance(value, str):
            return [item.strip() for item in value.split(',')]
        elif self.type == dict and isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return {}
        
        return value


@dataclass
class ToolConfiguration:
    """Configuration for a specific tool."""
    tool_name: str
    parameters: Dict[str, ConfigParameter] = field(default_factory=dict)
    values: Dict[str, Any] = field(default_factory=dict)
    source: ConfigSource = ConfigSource.DEFAULT
    environment: str = "default"
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        self.validate()
    
    def add_parameter(self, parameter: ConfigParameter):
        """Add a configuration parameter."""
        self.parameters[parameter.name] = parameter
        
        # Set default value if available
        if parameter.default is not None:
            self.values[parameter.name] = parameter.default
    
    def get_value(self, name: str, default: Any = None) -> Any:
        """Get a configuration value."""
        return self.values.get(name, default)
    
    def set_value(self, name: str, value: Any):
        """Set a configuration value."""
        if name not in self.parameters:
            raise ToolValidationError(f"Unknown parameter: {name}")
        
        parameter = self.parameters[name]
        
        if not parameter.validate(value):
            raise ToolValidationError(f"Invalid value for parameter {name}: {value}")
        
        self.values[name] = parameter.coerce_value(value)
        self.updated_at = datetime.utcnow()
    
    def validate(self) -> bool:
        """Validate all configuration values."""
        for name, value in self.values.items():
            if name not in self.parameters:
                raise ToolValidationError(f"Unknown parameter: {name}")
            
            parameter = self.parameters[name]
            if not parameter.validate(value):
                raise ToolValidationError(f"Invalid value for parameter {name}: {value}")
        
        # Check required parameters
        for name, parameter in self.parameters.items():
            if parameter.required and name not in self.values:
                raise ToolValidationError(f"Required parameter missing: {name}")
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "tool_name": self.tool_name,
            "parameters": {name: asdict(param) for name, param in self.parameters.items()},
            "values": self.values.copy(),
            "source": self.source.value,
            "environment": self.environment,
            "version": self.version,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
    
    def to_schema(self) -> Dict[str, Any]:
        """Generate JSON schema for this configuration."""
        properties = {}
        required = []
        
        for name, parameter in self.parameters.items():
            param_schema = {
                "type": self._python_type_to_json_type(parameter.type),
                "description": parameter.description
            }
            
            if parameter.default is not None:
                param_schema["default"] = parameter.default
            
            if parameter.choices:
                param_schema["enum"] = parameter.choices
            
            if parameter.min_value is not None:
                param_schema["minimum"] = parameter.min_value
            
            if parameter.max_value is not None:
                param_schema["maximum"] = parameter.max_value
            
            if parameter.pattern:
                param_schema["pattern"] = parameter.pattern
            
            properties[name] = param_schema
            
            if parameter.required:
                required.append(name)
        
        schema = {
            "type": "object",
            "properties": properties
        }
        
        if required:
            schema["required"] = required
        
        return schema
    
    def _python_type_to_json_type(self, python_type: Type) -> str:
        """Convert Python type to JSON schema type."""
        type_mapping = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object"
        }
        return type_mapping.get(python_type, "string")


@dataclass
class DeploymentConfiguration:
    """Configuration for tool deployment and scaling."""
    tool_name: str
    mode: DeploymentMode = DeploymentMode.STANDALONE
    instance_count: int = 1
    min_instances: int = 1
    max_instances: int = 10
    
    # Resource limits
    memory_limit_mb: int = 512
    cpu_limit_percent: int = 80
    disk_limit_gb: int = 10
    network_bandwidth_mbps: int = 100
    
    # Scaling configuration
    auto_scaling_enabled: bool = False
    scaling_metrics: List[str] = field(default_factory=lambda: ["cpu_usage", "memory_usage"])
    scaling_thresholds: Dict[str, float] = field(default_factory=dict)
    
    # Health and monitoring
    health_check_enabled: bool = True
    health_check_interval_seconds: int = 30
    health_check_timeout_seconds: int = 5
    restart_policy: str = "on_failure"
    max_restart_count: int = 3
    
    # Network and security
    port: Optional[int] = None
    host: str = "localhost"
    ssl_enabled: bool = False
    authentication_required: bool = False
    
    # Environment-specific settings
    environment_variables: Dict[str, str] = field(default_factory=dict)
    secrets_mount_path: Optional[str] = None
    
    # Logging and monitoring
    log_level: str = "INFO"
    log_format: str = "json"
    metrics_enabled: bool = True
    tracing_enabled: bool = False
    
    def get_resource_requirements(self) -> Dict[str, Any]:
        """Get resource requirements for deployment."""
        return {
            "memory_mb": self.memory_limit_mb,
            "cpu_percent": self.cpu_limit_percent,
            "disk_gb": self.disk_limit_gb,
            "network_mbps": self.network_bandwidth_mbps
        }
    
    def get_scaling_config(self) -> Dict[str, Any]:
        """Get auto-scaling configuration."""
        if not self.auto_scaling_enabled:
            return {"enabled": False}
        
        return {
            "enabled": True,
            "min_instances": self.min_instances,
            "max_instances": self.max_instances,
            "metrics": self.scaling_metrics,
            "thresholds": self.scaling_thresholds
        }


class ConfigurationManager:
    """Manages tool configurations from multiple sources."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.config")
        self._configurations: Dict[str, ToolConfiguration] = {}
        self._deployment_configs: Dict[str, DeploymentConfiguration] = {}
        self._config_sources: List[Callable] = []
        
        # Load default configurations
        self._load_default_configs()
    
    def _load_default_configs(self):
        """Load default configurations."""
        # Add default parameter definitions
        common_parameters = [
            ConfigParameter("timeout", int, default=300, description="Execution timeout in seconds"),
            ConfigParameter("max_retries", int, default=3, description="Maximum retry attempts"),
            ConfigParameter("log_level", str, default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"]),
            ConfigParameter("enabled", bool, default=True, description="Whether the tool is enabled"),
            ConfigParameter("health_check_interval", int, default=300, description="Health check interval in seconds"),
        ]
        
        # These would typically be loaded from a configuration file or database
        self.logger.info("Loaded default configurations")
    
    def add_config_source(self, source_func: Callable[[str], Dict[str, Any]]):
        """Add a configuration source function."""
        self._config_sources.append(source_func)
    
    def register_tool_config(self, config: ToolConfiguration):
        """Register a tool configuration."""
        self._configurations[config.tool_name] = config
        self.logger.info(f"Registered configuration for tool: {config.tool_name}")
    
    def get_tool_config(self, tool_name: str, environment: str = "default") -> Optional[ToolConfiguration]:
        """Get configuration for a tool."""
        # Try exact match first
        if tool_name in self._configurations:
            config = self._configurations[tool_name]
            if config.environment == environment:
                return config
        
        # Look for wildcard or default environment
        for name, config in self._configurations.items():
            if name == tool_name and config.environment in [environment, "default"]:
                return config
        
        return None
    
    def update_tool_config(self, tool_name: str, updates: Dict[str, Any], environment: str = "default") -> bool:
        """Update a tool's configuration."""
        config = self.get_tool_config(tool_name, environment)
        if not config:
            return False
        
        for key, value in updates.items():
            config.set_value(key, value)
        
        return True
    
    def load_from_file(self, config_path: Path, environment: str = "default"):
        """Load configurations from a file."""
        try:
            with open(config_path, 'r') as f:
                if config_path.suffix.lower() == '.json':
                    data = json.load(f)
                elif config_path.suffix.lower() in ['.yaml', '.yml']:
                    data = yaml.safe_load(f)
                else:
                    raise ToolError(f"Unsupported configuration file format: {config_path.suffix}")
            
            self._load_config_data(data, environment, ConfigSource.FILE)
            self.logger.info(f"Loaded configuration from file: {config_path}")
        
        except Exception as e:
            self.logger.error(f"Failed to load configuration from {config_path}: {e}")
            raise
    
    def load_from_environment(self, prefix: str = "TOOL_", environment: str = "default"):
        """Load configurations from environment variables."""
        configs = {}
        
        for key, value in os.environ.items():
            if key.startswith(prefix):
                # Parse tool configuration from environment variable
                # Format: TOOL_TOOLNAME_PARAMNAME=value
                parts = key[len(prefix):].split('_', 2)
                if len(parts) >= 2:
                    tool_name = parts[0].lower()
                    param_name = parts[1].lower()
                    
                    if tool_name not in configs:
                        configs[tool_name] = {}
                    
                    configs[tool_name][param_name] = value
        
        # Convert to ToolConfiguration objects
        for tool_name, params in configs.items():
            if tool_name not in self._configurations:
                config = ToolConfiguration(tool_name=tool_name, environment=environment, source=ConfigSource.ENVIRONMENT)
                self._configurations[tool_name] = config
            
            for param_name, param_value in params.items():
                # Auto-detect parameter type
                param_type = self._detect_parameter_type(param_value)
                parameter = ConfigParameter(
                    name=param_name,
                    type=param_type,
                    description=f"Configuration parameter from environment",
                    environment_variable=key
                )
                
                self._configurations[tool_name].add_parameter(parameter)
                self._configurations[tool_name].set_value(param_name, param_value)
        
        self.logger.info(f"Loaded {len(configs)} configurations from environment variables")
    
    def _load_config_data(self, data: Dict[str, Any], environment: str, source: ConfigSource):
        """Load configuration data into internal storage."""
        for tool_name, tool_data in data.items():
            if isinstance(tool_data, dict) and 'parameters' in tool_data:
                # New format with parameter definitions
                config = ToolConfiguration(
                    tool_name=tool_name,
                    environment=environment,
                    source=source
                )
                
                for param_name, param_config in tool_data['parameters'].items():
                    parameter = ConfigParameter(
                        name=param_name,
                        type=param_config.get('type', str),
                        default=param_config.get('default'),
                        description=param_config.get('description', ''),
                        required=param_config.get('required', False),
                        choices=param_config.get('choices'),
                        min_value=param_config.get('min_value'),
                        max_value=param_config.get('max_value'),
                        secret=param_config.get('secret', False)
                    )
                    config.add_parameter(parameter)
                
                # Set values
                for param_name, value in tool_data.get('values', {}).items():
                    config.set_value(param_name, value)
                
                self._configurations[tool_name] = config
            
            else:
                # Legacy format - simple key-value pairs
                if tool_name not in self._configurations:
                    config = ToolConfiguration(tool_name=tool_name, environment=environment, source=source)
                    self._configurations[tool_name] = config
                
                for param_name, value in tool_data.items():
                    config.set_value(param_name, value)
    
    def _detect_parameter_type(self, value: str) -> Type:
        """Auto-detect parameter type from string value."""
        if value.lower() in ['true', 'false']:
            return bool
        elif value.isdigit():
            return int
        else:
            try:
                float(value)
                return float
            except ValueError:
                return str
    
    def register_deployment_config(self, config: DeploymentConfiguration):
        """Register deployment configuration for a tool."""
        self._deployment_configs[config.tool_name] = config
        self.logger.info(f"Registered deployment configuration for tool: {config.tool_name}")
    
    def get_deployment_config(self, tool_name: str) -> Optional[DeploymentConfiguration]:
        """Get deployment configuration for a tool."""
        return self._deployment_configs.get(tool_name)
    
    def list_tool_configs(self, environment: Optional[str] = None) -> List[str]:
        """List all registered tool configurations."""
        if environment:
            return [name for name, config in self._configurations.items() 
                   if config.environment == environment]
        return list(self._configurations.keys())
    
    def export_config_schema(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """Export JSON schema for a tool's configuration."""
        config = self.get_tool_config(tool_name)
        return config.to_schema() if config else None
    
    def validate_all_configs(self) -> Dict[str, List[str]]:
        """Validate all registered configurations."""
        results = {}
        
        for tool_name, config in self._configurations.items():
            errors = []
            try:
                config.validate()
            except Exception as e:
                errors.append(str(e))
            
            results[tool_name] = errors
        
        return results
    
    def get_config_stats(self) -> Dict[str, Any]:
        """Get configuration statistics."""
        environments = {}
        for config in self._configurations.values():
            env = config.environment
            if env not in environments:
                environments[env] = 0
            environments[env] += 1
        
        return {
            "total_configs": len(self._configurations),
            "environments": environments,
            "deployment_configs": len(self._deployment_configs),
            "config_sources": len(self._config_sources)
        }


class EnvironmentManager:
    """Manages environment-specific tool configurations and deployments."""
    
    def __init__(self, config_manager: ConfigurationManager):
        self.config_manager = config_manager
        self.logger = logging.getLogger("tool.environment")
        self.current_environment = os.getenv("TOOL_ENVIRONMENT", "default")
        self.environment_configs: Dict[str, Dict[str, Any]] = {}
        
        # Load environment-specific configurations
        self._load_environment_configs()
    
    def _load_environment_configs(self):
        """Load configurations for all environments."""
        # This would typically load from a configuration management system
        # For now, we'll use environment variables and files
        
        environments = ["development", "staging", "production"]
        
        for env in environments:
            config_file = Path(f"config/{env}.yaml")
            if config_file.exists():
                try:
                    with open(config_file, 'r') as f:
                        self.environment_configs[env] = yaml.safe_load(f)
                    self.logger.info(f"Loaded configuration for environment: {env}")
                except Exception as e:
                    self.logger.error(f"Failed to load environment config {env}: {e}")
    
    def get_environment_config(self, tool_name: str, environment: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get configuration for a tool in a specific environment."""
        env = environment or self.current_environment
        
        if env in self.environment_configs and tool_name in self.environment_configs[env]:
            return self.environment_configs[env][tool_name]
        
        return None
    
    def select_tool_for_environment(self, tool_name: str, environment: Optional[str] = None) -> Optional[str]:
        """Select the appropriate tool variant for the environment."""
        env = environment or self.current_environment
        
        # Look for environment-specific variants
        variants = [
            f"{tool_name}_{env}",
            f"{tool_name}-{env}",
            f"{env}_{tool_name}"
        ]
        
        for variant in variants:
            if variant in self.config_manager.list_tool_configs():
                return variant
        
        # Fall back to default tool
        if tool_name in self.config_manager.list_tool_configs():
            return tool_name
        
        return None
    
    def get_deployment_strategy(self, tool_name: str, environment: Optional[str] = None) -> Dict[str, Any]:
        """Get deployment strategy for a tool in an environment."""
        env = environment or self.current_environment
        
        # Define deployment strategies by environment
        strategies = {
            "development": {
                "mode": DeploymentMode.STANDALONE,
                "instance_count": 1,
                "auto_scaling": False,
                "resource_limits": "minimal"
            },
            "staging": {
                "mode": DeploymentMode.STANDALONE,
                "instance_count": 1,
                "auto_scaling": False,
                "resource_limits": "standard"
            },
            "production": {
                "mode": DeploymentMode.SCALED,
                "instance_count": 3,
                "auto_scaling": True,
                "resource_limits": "high",
                "health_monitoring": True,
                "load_balancing": True
            }
        }
        
        return strategies.get(env, strategies["development"])
    
    def migrate_config(self, from_environment: str, to_environment: str, tool_name: str) -> bool:
        """Migrate configuration from one environment to another."""
        try:
            from_config = self.get_environment_config(tool_name, from_environment)
            if not from_config:
                return False
            
            # Create new config for target environment
            config = ToolConfiguration(
                tool_name=tool_name,
                environment=to_environment,
                source=ConfigSource.RUNTIME
            )
            
            # Migrate parameters
            for param_name, param_config in from_config.get('parameters', {}).items():
                parameter = ConfigParameter(
                    name=param_name,
                    type=param_config.get('type', str),
                    default=param_config.get('default'),
                    description=param_config.get('description', ''),
                    required=param_config.get('required', False)
                )
                config.add_parameter(parameter)
            
            # Migrate values
            for param_name, value in from_config.get('values', {}).items():
                config.set_value(param_name, value)
            
            self.config_manager.register_tool_config(config)
            
            self.logger.info(f"Migrated config for {tool_name} from {from_environment} to {to_environment}")
            return True
        
        except Exception as e:
            self.logger.error(f"Failed to migrate config: {e}")
            return False


# Global configuration instances
_global_config_manager = ConfigurationManager()
_global_environment_manager = EnvironmentManager(_global_config_manager)


def get_global_config() -> ConfigurationManager:
    """Get the global configuration manager."""
    return _global_config_manager


def get_global_environment() -> EnvironmentManager:
    """Get the global environment manager."""
    return _global_environment_manager


# Utility functions for common configuration patterns
def create_tool_config(
    tool_name: str,
    timeout: int = 300,
    max_retries: int = 3,
    log_level: str = "INFO",
    enabled: bool = True,
    environment: str = "default"
) -> ToolConfiguration:
    """Create a basic tool configuration."""
    config = ToolConfiguration(tool_name=tool_name, environment=environment)
    
    # Add standard parameters
    config.add_parameter(ConfigParameter("timeout", int, default=timeout, required=True))
    config.add_parameter(ConfigParameter("max_retries", int, default=max_retries))
    config.add_parameter(ConfigParameter("log_level", str, default=log_level))
    config.add_parameter(ConfigParameter("enabled", bool, default=enabled))
    
    # Set values
    config.set_value("timeout", timeout)
    config.set_value("max_retries", max_retries)
    config.set_value("log_level", log_level)
    config.set_value("enabled", enabled)
    
    return config


def create_deployment_config(
    tool_name: str,
    mode: DeploymentMode = DeploymentMode.STANDALONE,
    instance_count: int = 1,
    memory_limit_mb: int = 512,
    auto_scaling: bool = False
) -> DeploymentConfiguration:
    """Create a basic deployment configuration."""
    config = DeploymentConfiguration(
        tool_name=tool_name,
        mode=mode,
        instance_count=instance_count,
        memory_limit_mb=memory_limit_mb,
        auto_scaling_enabled=auto_scaling
    )
    
    return config
