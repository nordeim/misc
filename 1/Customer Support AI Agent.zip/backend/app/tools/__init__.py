"""
Tools module for the Customer Support AI Agent.

Provides comprehensive tools for conversation management, memory storage, RAG, escalation,
and advanced file attachment processing with MarkItDown integration.

Available tools:
- MemoryTool: Advanced conversation memory management
- RAGTool: Retrieval-Augmented Generation capabilities
- EscalationTool: Support escalation handling
- AttachmentTool: Enhanced file attachment management with MarkItDown integration
- FileUtils: File validation, cleaning, and analysis utilities
- FileStorage: Comprehensive file storage and management system
- FileAnalytics: Advanced analytics and monitoring for file processing

Enhanced Attachment System Features:
- Multi-format document processing (PDF, Office, images, etc.)
- MarkItDown integration for document parsing
- Security scanning and validation
- OCR capabilities for images and scanned documents
- Content extraction and metadata handling
- Advanced storage management with quotas and cleanup
- Comprehensive analytics and performance monitoring

New Tool System Features (v4.0.0):
- BaseTool abstract base class with standardized interfaces
- ToolRegistry for dynamic tool loading and management
- Advanced resilience patterns (retries, circuit breakers, isolation)
- Comprehensive metrics collection and monitoring
- Tool configuration management with environment support
- Tool factory patterns and utilities
- Tool validation and testing framework
- Documentation generation and optimization

Author: Customer Support AI Agent
Version: 4.0.0
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import TYPE_CHECKING, List, Dict, Any, Optional

if TYPE_CHECKING:
    # Existing tools
    from .memory_tool import MemoryTool, MemoryType, ImportanceLevel, MemoryQuery, MemoryAnalytics, MemorySearchResult
    from .rag_tool import RAGTool
    from .escalation_tool import EscalationTool
    from .attachment_tool import (
        AttachmentTool, FileMetadata, ProcessingResult, FileType, 
        SecurityScanner, MarkItDownProcessor, FileTypeDetector, 
        StorageManager, ProcessingAnalytics
    )
    from .file_utils import FileValidator, ContentCleaner, FileAnalyzer, TemporaryFileManager
    from .file_storage import StorageManager as FileStorageManager, DatabaseStorage, PhysicalStorage, StorageType, FileStatus, StorageStats
    from .file_analytics import FileAnalyticsEngine, ContentAnalyzer, PerformanceMonitor, ErrorTracker
    
    # New BaseTool and ToolRegistry components
    from .base_tool import (
        BaseTool, ToolMetadata, ToolExecutionContext, ToolMetrics,
        ToolStatus, ToolPriority, ToolError, ToolValidationError,
        ToolExecutionError, ToolTimeoutError, ToolResourceError,
        ToolDecorator, CircuitBreaker, ToolInterface, ToolFactory
    )
    from .registry import (
        ToolRegistry, ToolRegistration, ToolInstance, RegistryEvent,
        RegistryEventType, ToolRegistryEventHandler, LoggingEventHandler,
        HealthCheckEventHandler, get_registry, setup_registry, cleanup_registry
    )
    from .patterns import (
        RetryManager, RetryConfig, RetryStrategy, AdvancedCircuitBreaker,
        CircuitBreakerConfig, CircuitBreakerState, MetricsCollector,
        ExecutionMetrics, IsolationManager, VersionManager,
        create_resilient_method, get_global_patterns
    )
    from .utils import (
        ToolFactory, ToolFactoryConfig, ToolValidationResult, ToolValidator,
        BasicToolValidator, PerformanceToolValidator, ToolValidatorRegistry,
        ToolTester, ToolTestResult, ToolDocumentationGenerator, ToolOptimizer,
        get_global_utilities
    )
    from .config import (
        ConfigParameter, ToolConfiguration, DeploymentConfiguration,
        ConfigurationManager, EnvironmentManager, ConfigSource,
        ConfigFormat, DeploymentMode, create_tool_config, create_deployment_config,
        get_global_config, get_global_environment
    )

# Configure module logger
logger = logging.getLogger(__name__)

# Import all new BaseTool and ToolRegistry components
try:
    # Base tool classes and interfaces
    from .base_tool import (
        BaseTool, ToolMetadata, ToolExecutionContext, ToolMetrics,
        ToolStatus, ToolPriority, ToolError, ToolValidationError,
        ToolExecutionError, ToolTimeoutError, ToolResourceError,
        ToolDecorator, CircuitBreaker, ToolInterface, ToolFactory
    )
    
    # Tool registry and management
    from .registry import (
        ToolRegistry, ToolRegistration, ToolInstance, RegistryEvent,
        RegistryEventType, ToolRegistryEventHandler, LoggingEventHandler,
        HealthCheckEventHandler, get_registry, setup_registry, cleanup_registry
    )
    
    # Tool patterns and resilience
    from .patterns import (
        RetryManager, RetryConfig, RetryStrategy, AdvancedCircuitBreaker,
        CircuitBreakerConfig, CircuitBreakerState, MetricsCollector,
        ExecutionMetrics, IsolationManager, VersionManager,
        create_resilient_method, get_global_patterns
    )
    
    # Tool utilities
    from .utils import (
        ToolFactory, ToolFactoryConfig, ToolValidationResult, ToolValidator,
        BasicToolValidator, PerformanceToolValidator, ToolValidatorRegistry,
        ToolTester, ToolTestResult, ToolDocumentationGenerator, ToolOptimizer,
        get_global_utilities
    )
    
    # Tool configuration
    from .config import (
        ConfigParameter, ToolConfiguration, DeploymentConfiguration,
        ConfigurationManager, EnvironmentManager, ConfigSource,
        ConfigFormat, DeploymentMode, create_tool_config, create_deployment_config,
        get_global_config, get_global_environment
    )
    
    # Convenience functions
    from . import (
        create_tool, run_tool_safely, validate_tool, get_tool_schema,
        configure_tool_for_environment, check_tool_health, upgrade_existing_tool,
        initialize_tools, registry as global_registry,
        config as global_config, environment as global_environment,
        patterns as global_patterns, utilities as global_utilities
    )
    
    # Import the new components
    new_components_available = True
    
except ImportError as e:
    logger.warning(f"Failed to import new tool system components: {e}")
    new_components_available = False
    
    # Provide minimal fallbacks
    class BaseTool:
        def __init__(self, config=None):
            self.config = config or {}
            self.name = self.__class__.__name__
    
    class ToolRegistry:
        def __init__(self, **kwargs):
            logger.warning("ToolRegistry not available - using fallback")
    
    # Create dummy functions
    def create_tool(tool_class, name=None, config=None, registry=None):
        return tool_class(config=config) if tool_class else None
    
    async def run_tool_safely(tool, *args, **kwargs):
        return await tool.execute(*args, **kwargs) if tool else None
    
    def validate_tool(tool):
        return type('ValidationResult', (), {'is_valid': True, 'errors': []})()
    
    def get_tool_schema(tool):
        return {"type": "object", "properties": {}}
    
    def configure_tool_for_environment(tool, environment="default", config_manager=None):
        return tool
    
    async def check_tool_health(tool, timeout=30.0):
        return {"status": "unknown", "error": "Tool health check not available"}
    
    def upgrade_existing_tool(tool_class):
        return tool_class
    
    def initialize_tools(discovery_paths=None, auto_discover=True, environment="default"):
        return ToolRegistry()
    
    global_registry = lambda: None
    global_config = lambda: None
    global_environment = lambda: None
    global_patterns = lambda: None
    global_utilities = lambda: None

# Import all existing tools and utilities
try:
    from .memory_tool import MemoryTool, MemoryType, ImportanceLevel, MemoryQuery, MemoryAnalytics, MemorySearchResult
    from .rag_tool import RAGTool
    from .escalation_tool import EscalationTool
    
    # Enhanced attachment system
    from .attachment_tool import (
        AttachmentTool, FileMetadata, ProcessingResult, FileType, 
        SecurityScanner, MarkItDownProcessor, FileTypeDetector, 
        StorageManager, ProcessingAnalytics, attachment_tool as global_attachment_tool
    )
    from .file_utils import (
        FileValidator, ContentCleaner, FileAnalyzer, TemporaryFileManager,
        file_validator, content_cleaner, file_analyzer, temp_file_manager
    )
    from .file_storage import (
        StorageManager as FileStorageManager, DatabaseStorage, PhysicalStorage, 
        StorageType, FileStatus, StorageStats, get_storage_manager
    )
    from .file_analytics import (
        FileAnalyticsEngine, ContentAnalyzer, PerformanceMonitor, ErrorTracker,
        analytics_engine, start_analytics_session, record_file_processing,
        get_comprehensive_analytics, get_session_analytics
    )
    
    # Global instances
    memory_tool = MemoryTool()
    rag_tool = RAGTool()
    escalation_tool = EscalationTool()
    attachment_tool = global_attachment_tool
    file_storage_manager = None  # Will be initialized when needed
    
    # Global tool system instances
    tool_registry = get_registry() if new_components_available else None
    config_manager = get_global_config() if new_components_available else None
    environment_manager = get_global_environment() if new_components_available else None
    
    __all__ = [
        # Existing core tools
        "MemoryTool",
        "RAGTool", 
        "EscalationTool",
        "AttachmentTool",
        
        # Memory types and enums
        "MemoryType",
        "ImportanceLevel",
        "MemoryQuery",
        "MemoryAnalytics",
        "MemorySearchResult",
        
        # Attachment system types
        "FileMetadata",
        "ProcessingResult",
        "FileType",
        "StorageType",
        "FileStatus",
        "StorageStats",
        
        # Core components
        "SecurityScanner",
        "MarkItDownProcessor",
        "FileTypeDetector",
        "StorageManager",
        "ProcessingAnalytics",
        
        # Utility components
        "FileValidator",
        "ContentCleaner", 
        "FileAnalyzer",
        "TemporaryFileManager",
        "DatabaseStorage",
        "PhysicalStorage",
        
        # Analytics components
        "FileAnalyticsEngine",
        "ContentAnalyzer",
        "PerformanceMonitor",
        "ErrorTracker",
        
        # New BaseTool components
        "BaseTool",
        "ToolMetadata",
        "ToolExecutionContext",
        "ToolMetrics",
        "ToolStatus",
        "ToolPriority",
        "ToolError",
        "ToolValidationError",
        "ToolExecutionError",
        "ToolTimeoutError",
        "ToolResourceError",
        "ToolDecorator",
        "CircuitBreaker",
        "ToolInterface",
        "ToolFactory",
        
        # New ToolRegistry components
        "ToolRegistry",
        "ToolRegistration",
        "ToolInstance",
        "RegistryEvent",
        "RegistryEventType",
        "ToolRegistryEventHandler",
        "LoggingEventHandler",
        "HealthCheckEventHandler",
        
        # New Pattern components
        "RetryManager",
        "RetryConfig",
        "RetryStrategy",
        "AdvancedCircuitBreaker",
        "CircuitBreakerConfig",
        "CircuitBreakerState",
        "MetricsCollector",
        "ExecutionMetrics",
        "IsolationManager",
        "VersionManager",
        "create_resilient_method",
        
        # New Utility components
        "ToolFactory",
        "ToolFactoryConfig",
        "ToolValidationResult",
        "ToolValidator",
        "BasicToolValidator",
        "PerformanceToolValidator",
        "ToolValidatorRegistry",
        "ToolTester",
        "ToolTestResult",
        "ToolDocumentationGenerator",
        "ToolOptimizer",
        
        # New Configuration components
        "ConfigParameter",
        "ToolConfiguration",
        "DeploymentConfiguration",
        "ConfigurationManager",
        "EnvironmentManager",
        "ConfigSource",
        "ConfigFormat",
        "DeploymentMode",
        "create_tool_config",
        "create_deployment_config",
        
        # Global instances (existing)
        "memory_tool",
        "rag_tool", 
        "escalation_tool",
        "attachment_tool",
        "file_validator",
        "content_cleaner",
        "file_analyzer",
        "temp_file_manager",
        "analytics_engine",
        
        # Global instances (new)
        "tool_registry",
        "config_manager",
        "environment_manager",
        
        # Helper functions (existing)
        "get_tool",
        "get_all_tools",
        "get_storage_manager",
        "start_analytics_session",
        "record_file_processing",
        "get_comprehensive_analytics",
        "get_session_analytics",
        
        # Helper functions (new)
        "create_tool",
        "run_tool_safely",
        "validate_tool",
        "get_tool_schema",
        "configure_tool_for_environment",
        "check_tool_health",
        "upgrade_existing_tool",
        "initialize_tools",
        
        # Global access functions
        "global_registry",
        "global_config",
        "global_environment",
        "global_patterns",
        "global_utilities",
        
        # Legacy compatibility
        "registry",
        "config",
        "environment"
    ]
    
    logger.info("All tools and utilities initialized successfully")
    
except ImportError as e:
    logger.warning(f"Failed to import some tools: {e}")
    
    # Provide fallbacks for missing tools
    class MemoryTool:
        def __init__(self):
            logger.warning("MemoryTool not available - using fallback")
    
    class RAGTool:
        def __init__(self):
            logger.warning("RAGTool not available - using fallback")
    
    class EscalationTool:
        def __init__(self):
            logger.warning("EscalationTool not available - using fallback")
    
    class AttachmentTool:
        def __init__(self):
            logger.warning("AttachmentTool not available - using fallback")
    
    # Fallback attachment system components
    class FileMetadata:
        def __init__(self, **kwargs):
            pass
    
    class ProcessingResult:
        def __init__(self, **kwargs):
            pass
    
    class FileType:
        DOCUMENT = "document"
        TEXT = "text"
        IMAGE = "image"
    
    class SecurityScanner:
        @staticmethod
        async def scan_file(file_path):
            return {"safe": True, "threats": [], "warnings": []}
    
    class MarkItDownProcessor:
        def __init__(self):
            self.enabled = False
    
    class FileTypeDetector:
        @staticmethod
        def detect_file_type(file_path):
            return FileType.UNKNOWN, "application/octet-stream"
    
    # Fallback instances
    memory_tool = MemoryTool()
    rag_tool = RAGTool()
    escalation_tool = EscalationTool()
    attachment_tool = AttachmentTool()
    
    __all__ = [
        "MemoryTool",
        "RAGTool",
        "EscalationTool", 
        "AttachmentTool",
        "FileMetadata",
        "ProcessingResult",
        "FileType",
        "SecurityScanner",
        "MarkItDownProcessor",
        "FileTypeDetector",
        "memory_tool",
        "rag_tool",
        "escalation_tool",
        "attachment_tool"
    ]


def get_tool(tool_name: str):
    """
    Get a tool instance by name.
    
    Args:
        tool_name: Name of the tool to retrieve
        
    Returns:
        Tool instance or None if not found
    """
    tools = {
        'memory': memory_tool,
        'rag': rag_tool,
        'escalation': escalation_tool,
        'attachment': attachment_tool,
        'file_validator': file_validator,
        'content_cleaner': content_cleaner,
        'file_analyzer': file_analyzer,
        'temp_file_manager': temp_file_manager,
        'analytics': analytics_engine
    }
    
    return tools.get(tool_name.lower())


def get_all_tools():
    """
    Get all available tool instances.
    
    Returns:
        Dictionary of tool instances
    """
    return {
        'memory': memory_tool,
        'rag': rag_tool,
        'escalation': escalation_tool,
        'attachment': attachment_tool,
        'file_validator': file_validator,
        'content_cleaner': content_cleaner,
        'file_analyzer': file_analyzer,
        'temp_file_manager': temp_file_manager,
        'analytics': analytics_engine
    }


async def initialize_attachment_system():
    """
    Initialize the enhanced attachment system.
    
    This function should be called during application startup to properly
    initialize all attachment processing components.
    
    Returns:
        True if initialization was successful
    """
    try:
        global file_storage_manager
        
        # Initialize storage manager
        file_storage_manager = await get_storage_manager()
        
        # Start background analytics session cleanup
        asyncio.create_task(analytics_engine.cleanup_old_data())
        
        logger.info("Enhanced attachment system initialized successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize attachment system: {e}")
        return False


async def get_attachment_health_status():
    """
    Get health status of all attachment system components.
    
    Returns:
        Dictionary with health status of all components
    """
    health_status = {
        "attachment_tool": "unknown",
        "file_validator": "unknown",
        "content_cleaner": "unknown",
        "file_analyzer": "unknown",
        "temp_file_manager": "unknown",
        "storage_manager": "unknown",
        "analytics_engine": "unknown"
    }
    
    try:
        # Check attachment tool
        if attachment_tool:
            health_status["attachment_tool"] = "healthy"
        
        # Check file utilities
        if file_validator:
            health_status["file_validator"] = "healthy"
        
        if content_cleaner:
            health_status["content_cleaner"] = "healthy"
            
        if file_analyzer:
            health_status["file_analyzer"] = "healthy"
            
        if temp_file_manager:
            health_status["temp_file_manager"] = "healthy"
        
        # Check storage manager
        try:
            global file_storage_manager
            if file_storage_manager is None:
                file_storage_manager = await get_storage_manager()
            
            storage_health = await file_storage_manager.health_check()
            health_status["storage_manager"] = storage_health["status"]
        except Exception as e:
            health_status["storage_manager"] = f"error: {str(e)}"
        
        # Check analytics engine
        if analytics_engine:
            health_status["analytics_engine"] = "healthy"
    
    except Exception as e:
        logger.error(f"Error checking health status: {str(e)}")
        health_status["error"] = str(e)
    
    return health_status


# Enhanced helper functions for the new tool system
def get_tool_registry() -> Optional[ToolRegistry]:
    """Get the global tool registry instance."""
    return get_registry() if new_components_available else None


def get_configuration_manager() -> Optional[ConfigurationManager]:
    """Get the global configuration manager instance."""
    return get_global_config() if new_components_available else None


def get_environment_manager() -> Optional[EnvironmentManager]:
    """Get the global environment manager instance."""
    return get_global_environment() if new_components_available else None


async def quick_tool_test(tool_class, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Quick test of a tool class to verify it works.
    
    Args:
        tool_class: Tool class to test
        config: Optional configuration for the tool
        
    Returns:
        Test result dictionary
    """
    if not new_components_available:
        return {"status": "skipped", "reason": "New tool system not available"}
    
    try:
        # Create tool instance
        tool = tool_class(config=config)
        
        # Validate tool
        validation_result = validate_tool(tool)
        
        # Test basic functionality
        test_results = {
            "validation": {
                "valid": validation_result.is_valid,
                "score": validation_result.score,
                "errors": validation_result.errors,
                "warnings": validation_result.warnings
            },
            "basic_test": {
                "status": "pending",
                "execution_time_ms": 0
            }
        }
        
        # Try basic execution if validation passed
        if validation_result.is_valid:
            start_time = time.time()
            try:
                result = await tool.execute()
                execution_time = (time.time() - start_time) * 1000
                
                test_results["basic_test"] = {
                    "status": "passed",
                    "execution_time_ms": execution_time,
                    "result_type": type(result).__name__ if result else None
                }
            except Exception as e:
                execution_time = (time.time() - start_time) * 1000
                test_results["basic_test"] = {
                    "status": "failed",
                    "execution_time_ms": execution_time,
                    "error": str(e)
                }
        
        test_results["overall_status"] = "passed" if validation_result.is_valid and test_results["basic_test"]["status"] == "passed" else "failed"
        
        return test_results
        
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "validation": None,
            "basic_test": None
        }


def create_standard_tool_config(tool_name: str, environment: str = "default") -> Dict[str, Any]:
    """
    Create a standard configuration for a tool.
    
    Args:
        tool_name: Name of the tool
        environment: Environment for the configuration
        
    Returns:
        Standard configuration dictionary
    """
    return {
        "timeout": 300,
        "max_retries": 3,
        "log_level": "INFO",
        "enabled": True,
        "health_check_interval": 300,
        "environment": environment
    }


async def upgrade_existing_tools() -> List[str]:
    """
    Upgrade all existing tools to use the new BaseTool pattern.
    
    Returns:
        List of upgraded tool names
    """
    upgraded_tools = []
    
    # Map existing tools to upgrade
    tool_mappings = [
        (MemoryTool, "memory_tool"),
        (RAGTool, "rag_tool"),
        (EscalationTool, "escalation_tool"),
        (AttachmentTool, "attachment_tool")
    ]
    
    for tool_class, tool_name in tool_mappings:
        try:
            if new_components_available:
                upgraded_class = upgrade_existing_tool(tool_class)
                upgraded_tools.append(tool_name)
                logger.info(f"Upgraded tool: {tool_name}")
            else:
                logger.warning(f"Cannot upgrade {tool_name} - new tool system not available")
        except Exception as e:
            logger.error(f"Failed to upgrade tool {tool_name}: {e}")
    
    return upgraded_tools


# Legacy compatibility aliases
registry = get_tool_registry
config = get_configuration_manager
environment = get_environment_manager


# Package initialization information
TOOL_SYSTEM_INFO = {
    "version": "4.0.0",
    "new_components_available": new_components_available,
    "total_existing_tools": 4,  # MemoryTool, RAGTool, EscalationTool, AttachmentTool
    "features": {
        "base_tool_pattern": new_components_available,
        "tool_registry": new_components_available,
        "resilience_patterns": new_components_available,
        "metrics_monitoring": new_components_available,
        "configuration_management": new_components_available,
        "tool_validation": new_components_available,
        "documentation_generation": new_components_available,
        "environment_support": new_components_available
    }
}


def get_tool_system_info() -> Dict[str, Any]:
    """Get information about the tool system capabilities."""
    return TOOL_SYSTEM_INFO.copy()
