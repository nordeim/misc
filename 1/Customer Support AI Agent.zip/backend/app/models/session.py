"""
Session ORM model for conversation sessions.
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID, uuid4

from sqlalchemy import (
    Column, String, DateTime, Text, JSON, Boolean, 
    ForeignKey, Integer, UniqueConstraint
)
from sqlalchemy.orm import relationship

from .base import Base, ORMBase, BaseSchema
from .message import MessageORM
from .memory import MemoryORM
from pydantic import Field


class SessionORM(Base, ORMBase):
    """Session ORM model for conversation sessions."""
    
    __tablename__ = "sessions"
    __table_args__ = (
        UniqueConstraint('user_id', 'title', name='uq_user_session_title'),
    )
    
    # Core session information
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    
    # Session configuration
    status = Column(String(50), default="active", nullable=False, index=True)
    session_type = Column(String(50), default="chat", nullable=False, index=True)
    
    # Model and provider configuration
    model_name = Column(String(100), nullable=True)
    provider = Column(String(50), nullable=True)
    model_config = Column(JSON, nullable=True)
    
    # Session metadata
    meta_data = Column(JSON, nullable=True)
    tags = Column(JSON, nullable=True)
    
    # Usage tracking
    message_count = Column(Integer, default=0, nullable=False)
    token_count = Column(Integer, default=0, nullable=False)
    
    # Timestamps
    started_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    ended_at = Column(DateTime, nullable=True)
    last_activity = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # User interaction tracking
    user_feedback = Column(String(50), nullable=True)  # 'positive', 'negative', 'neutral'
    rating = Column(Integer, nullable=True)  # 1-5 rating
    
    # Relationships
    user = relationship("UserORM", back_populates="sessions")
    messages = relationship(
        "MessageORM", 
        back_populates="session", 
        cascade="all, delete-orphan",
        order_by="MessageORM.created_at"
    )
    memories = relationship(
        "MemoryORM",
        back_populates="session",
        cascade="all, delete-orphan"
    )
    
    def __repr__(self) -> str:
        return f"<SessionORM(id={self.id}, title='{self.title}', user_id='{self.user_id}')>"
    
    def add_message(self, message: "MessageORM") -> None:
        """Add a message to the session."""
        self.messages.append(message)
        self.message_count += 1
        self.last_activity = datetime.utcnow()
        self.update()
    
    def add_memory(self, memory: "MemoryORM") -> None:
        """Add a memory to the session."""
        self.memories.append(memory)
        self.update()
    
    def close_session(self) -> None:
        """Close the session."""
        self.status = "closed"
        self.ended_at = datetime.utcnow()
        self.update()
    
    def archive_session(self) -> None:
        """Archive the session."""
        self.status = "archived"
        self.update()
    
    def get_recent_messages(self, limit: int = 50) -> List["MessageORM"]:
        """Get recent messages from the session."""
        return self.messages[-limit:] if limit > 0 else self.messages
    
    def get_context_messages(self, limit: int = 10) -> List["MessageORM"]:
        """Get context messages for LLM processing."""
        return self.messages[-limit:] if limit > 0 else self.messages
    
    def get_user_messages(self) -> List["MessageORM"]:
        """Get all user messages from the session."""
        return [msg for msg in self.messages if msg.role == "user"]
    
    def get_assistant_messages(self) -> List["MessageORM"]:
        """Get all assistant messages from the session."""
        return [msg for msg in self.messages if msg.role == "assistant"]
    
    def update_activity(self) -> None:
        """Update last activity timestamp."""
        self.last_activity = datetime.utcnow()
        self.update()
    
    def set_feedback(self, feedback: str, rating: Optional[int] = None) -> None:
        """Set user feedback for the session."""
        self.user_feedback = feedback
        if rating is not None:
            self.rating = max(1, min(5, rating))  # Clamp rating between 1-5
        self.update()
    
    @classmethod
    def get_active_sessions(cls, session, user_id: str) -> List["SessionORM"]:
        """Get all active sessions for a user."""
        return (session.query(cls)
                .filter(cls.user_id == user_id, cls.status == "active")
                .order_by(cls.last_activity.desc())
                .all())
    
    @classmethod
    def create_session(cls, session, user_id: str, **kwargs) -> "SessionORM":
        """Create a new session."""
        session_obj = cls(user_id=user_id, **kwargs)
        session.add(session_obj)
        session.flush()
        return session_obj
    
    @classmethod
    def get_by_user_and_title(cls, session, user_id: str, title: str) -> Optional["SessionORM"]:
        """Get session by user and title."""
        return (session.query(cls)
                .filter(cls.user_id == user_id, cls.title == title)
                .first())
    
    def to_summary_dict(self) -> dict:
        """Get session summary without messages."""
        return {
            "id": self.id,
            "title": self.title,
            "status": self.status,
            "session_type": self.session_type,
            "model_name": self.model_name,
            "provider": self.provider,
            "message_count": self.message_count,
            "created_at": self.created_at,
            "last_activity": self.last_activity,
            "user_feedback": self.user_feedback,
            "rating": self.rating,
        }


# Pydantic Schemas for Session
class SessionBase(BaseSchema):
    """Base session schema."""
    title: str = Field(..., max_length=255)
    session_type: str = Field(default="chat", max_length=50)
    model_name: Optional[str] = Field(None, max_length=100)
    provider: Optional[str] = Field(None, max_length=50)
    model_config: Optional[dict] = None
    metadata: Optional[dict] = None
    tags: Optional[List[str]] = None


class SessionCreate(SessionBase):
    """Schema for creating a session."""
    pass


class SessionUpdate(BaseSchema):
    """Schema for updating a session."""
    title: Optional[str] = Field(None, max_length=255)
    session_type: Optional[str] = Field(None, max_length=50)
    model_name: Optional[str] = Field(None, max_length=100)
    provider: Optional[str] = Field(None, max_length=50)
    model_config: Optional[dict] = None
    metadata: Optional[dict] = None
    tags: Optional[List[str]] = None


class SessionRead(SessionBase):
    """Schema for reading session data."""
    id: str
    user_id: str
    status: str
    message_count: int
    token_count: int
    started_at: datetime
    ended_at: Optional[datetime]
    last_activity: datetime
    user_feedback: Optional[str]
    rating: Optional[int]
    created_at: datetime
    updated_at: datetime


class SessionSummary(BaseSchema):
    """Schema for session summary."""
    id: str
    title: str
    status: str
    session_type: str
    model_name: Optional[str]
    provider: Optional[str]
    message_count: int
    last_activity: datetime
    user_feedback: Optional[str]
    rating: Optional[int]


class SessionClose(BaseSchema):
    """Schema for closing a session."""
    user_feedback: Optional[str] = Field(None, max_length=50)
    rating: Optional[int] = Field(None, ge=1, le=5)