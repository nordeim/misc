"""
Pydantic schemas for escalation-related models.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, Field, validator


# Enums for escalation models
class EscalationStatus(str, Enum):
    """Status of escalation."""
    PENDING = "pending"
    ROUTED = "routed"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"
    ESCALATED_AGAIN = "escalated_again"


class EscalationPriority(str, Enum):
    """Priority levels for escalations."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    URGENT = "urgent"


class EscalationReason(str, Enum):
    """Reasons for escalation."""
    SENTIMENT = "sentiment"
    KEYWORDS = "keywords"
    CONVERSATION_LENGTH = "conversation_length"
    CONFIDENCE = "confidence"
    COMPLEXITY = "complexity"
    MANUAL_REQUEST = "manual_request"
    TECHNICAL_ISSUE = "technical_issue"
    BILLING_ISSUE = "billing_issue"
    POLICY_VIOLATION = "policy_violation"
    COMPLAINT = "complaint"
    FRAUD = "fraud"


class EscalationType(str, Enum):
    """Type of escalation."""
    AUTOMATIC = "automatic"
    MANUAL = "manual"
    SCHEDULED = "scheduled"


# Base schemas
class EscalationBase(BaseModel):
    """Base escalation schema."""
    
    session_id: str = Field(..., description="Session ID for the conversation")
    user_id: str = Field(..., description="User ID")
    escalation_type: EscalationType = Field(default=EscalationType.AUTOMATIC)
    priority: EscalationPriority = Field(default=EscalationPriority.MEDIUM)
    reasons: List[EscalationReason] = Field(..., description="Reasons for escalation")
    trigger_score: float = Field(..., ge=0.0, le=1.0, description="Escalation trigger score")
    trigger_context: Optional[Dict[str, Any]] = Field(None, description="Context that triggered escalation")


# Escalation schemas
class EscalationCreate(EscalationBase):
    """Schema for creating escalations."""
    
    policy_id: Optional[UUID] = Field(None, description="Policy that triggered escalation")
    queue_id: UUID = Field(..., description="Queue to route to")


class EscalationUpdate(BaseModel):
    """Schema for updating escalations."""
    
    status: Optional[EscalationStatus] = None
    priority: Optional[EscalationPriority] = None
    assigned_agent_id: Optional[str] = None
    assigned_agent_name: Optional[str] = None
    resolution_notes: Optional[str] = None
    customer_feedback: Optional[str] = None
    satisfaction_score: Optional[int] = Field(None, ge=1, le=5)


class EscalationRead(EscalationBase):
    """Schema for reading escalations."""
    
    id: UUID
    policy_id: Optional[UUID]
    queue_id: UUID
    status: EscalationStatus
    assigned_agent_id: Optional[str]
    assigned_agent_name: Optional[str]
    assigned_at: Optional[datetime]
    resolved_at: Optional[datetime]
    resolution_time_minutes: Optional[float]
    resolution_notes: Optional[str]
    customer_feedback: Optional[str]
    satisfaction_score: Optional[int]
    response_time_minutes: Optional[float]
    resolution_time_sla_minutes: int
    escalation_trend: Optional[str]
    complexity_score: float
    reintegration_needed: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True


class EscalationAssignment(BaseModel):
    """Schema for assigning escalations to agents."""
    
    agent_id: str = Field(..., description="Agent ID to assign")
    agent_name: str = Field(..., description="Agent name")
    estimated_duration_minutes: Optional[int] = Field(None, description="Estimated resolution time")


class EscalationResolution(BaseModel):
    """Schema for resolving escalations."""
    
    resolution_notes: str = Field(..., description="Resolution notes")
    customer_feedback: Optional[str] = Field(None, description="Customer feedback")
    satisfaction_score: int = Field(..., ge=1, le=5, description="Customer satisfaction score")
    escalation_trend: Optional[str] = Field(None, description="Trend (improving, stable, declining)")
    reintegration_needed: bool = Field(default=False, description="Whether reintegration is needed")


# Queue schemas
class EscalationQueueBase(BaseModel):
    """Base escalation queue schema."""
    
    name: str = Field(..., description="Queue name")
    description: Optional[str] = Field(None, description="Queue description")
    department: str = Field(..., description="Department")
    skill_requirements: Optional[List[str]] = Field(None, description="Required skills")
    business_hours: Optional[Dict[str, Any]] = Field(None, description="Business hours configuration")
    time_zone: str = Field(default="UTC", description="Time zone")
    max_wait_time_minutes: int = Field(default=30, description="Maximum wait time")
    capacity: int = Field(default=10, description="Maximum concurrent cases")
    routing_rules: Optional[Dict[str, Any]] = Field(None, description="Routing rules")


class EscalationQueueCreate(EscalationQueueBase):
    """Schema for creating escalation queues."""
    
    pass


class EscalationQueueUpdate(BaseModel):
    """Schema for updating escalation queues."""
    
    name: Optional[str] = None
    description: Optional[str] = None
    department: Optional[str] = None
    is_active: Optional[bool] = None
    capacity: Optional[int] = None
    routing_rules: Optional[Dict[str, Any]] = None
    business_hours: Optional[Dict[str, Any]] = None
    max_wait_time_minutes: Optional[int] = None


class EscalationQueueRead(EscalationQueueBase):
    """Schema for reading escalation queues."""
    
    id: UUID
    is_active: bool
    current_load: int
    auto_assignment: bool
    avg_resolution_time_minutes: float
    customer_satisfaction_score: float
    escalation_rate: float
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True


class QueueAssignment(BaseModel):
    """Schema for queue assignment."""
    
    priority_score: int = Field(default=1, ge=1, le=10, description="Assignment priority")
    load_balancing: bool = Field(default=True, description="Use load balancing")


# Policy schemas
class EscalationPolicyBase(BaseModel):
    """Base escalation policy schema."""
    
    name: str = Field(..., description="Policy name")
    description: Optional[str] = Field(None, description="Policy description")
    policy_type: str = Field(..., description="Policy type (sentiment, keywords, etc.)")
    rules: Dict[str, Any] = Field(..., description="Policy rules")
    thresholds: Optional[Dict[str, Any]] = Field(None, description="Escalation thresholds")
    target_department: str = Field(..., description="Target department")
    priority_score: int = Field(default=1, ge=1, le=10, description="Policy priority")
    time_conditions: Optional[Dict[str, Any]] = Field(None, description="Time-based conditions")


class EscalationPolicyCreate(EscalationPolicyBase):
    """Schema for creating escalation policies."""
    
    target_queue_id: UUID = Field(..., description="Target queue ID")


class EscalationPolicyUpdate(BaseModel):
    """Schema for updating escalation policies."""
    
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    rules: Optional[Dict[str, Any]] = None
    thresholds: Optional[Dict[str, Any]] = None
    target_department: Optional[str] = None
    priority_score: Optional[int] = None
    time_conditions: Optional[Dict[str, Any]] = None


class EscalationPolicyRead(EscalationPolicyBase):
    """Schema for reading escalation policies."""
    
    id: UUID
    target_queue_id: UUID
    is_active: bool
    version: int
    trigger_count: int
    success_rate: float
    created_at: datetime
    updated_at: datetime
    last_triggered: Optional[datetime]
    
    class Config:
        orm_mode = True


# Analytics schemas
class EscalationAnalyticsBase(BaseModel):
    """Base escalation analytics schema."""
    
    date: datetime = Field(default_factory=datetime.utcnow)
    hour: int = Field(..., ge=0, le=23)
    escalation_count: int = Field(default=1)
    avg_response_time_minutes: float = Field(default=0.0)
    avg_resolution_time_minutes: float = Field(default=0.0)
    customer_satisfaction_avg: float = Field(default=0.0)


class EscalationAnalyticsCreate(EscalationAnalyticsBase):
    """Schema for creating escalation analytics."""
    
    escalation_id: UUID = Field(..., description="Escalation ID")


class EscalationAnalyticsRead(EscalationAnalyticsBase):
    """Schema for reading escalation analytics."""
    
    id: UUID
    escalation_id: UUID
    queue_utilization: float
    wait_time_avg_minutes: float
    abandoned_rate: float
    first_contact_resolution_rate: float
    escalation_resolution_rate: float
    callback_required_rate: float
    agent_performance_score: float
    customer_reachability_rate: float
    issue_complexity_avg: float
    created_at: datetime
    
    class Config:
        orm_mode = True


# Analytics aggregation schemas
class EscalationMetrics(BaseModel):
    """Aggregated escalation metrics."""
    
    date_range: Dict[str, datetime]
    total_escalations: int
    avg_response_time_minutes: float
    avg_resolution_time_minutes: float
    customer_satisfaction_avg: float
    escalation_rate: float
    first_contact_resolution_rate: float
    abandoned_rate: float
    queue_performance: Dict[str, Dict[str, float]]


class QueuePerformance(BaseModel):
    """Queue performance metrics."""
    
    queue_id: UUID
    queue_name: str
    avg_response_time_minutes: float
    avg_resolution_time_minutes: float
    customer_satisfaction_score: float
    utilization_rate: float
    abandonment_rate: float
    agent_performance_score: float


class EscalationTrends(BaseModel):
    """Escalation trends and patterns."""
    
    daily_trends: List[Dict[str, Any]]
    hourly_distribution: List[Dict[str, int]]
    reason_distribution: Dict[str, int]
    priority_distribution: Dict[str, int]
    resolution_patterns: Dict[str, Any]
    seasonal_patterns: Optional[Dict[str, Any]]


# Decision schemas
class EscalationDecision(BaseModel):
    """Schema for escalation decision."""
    
    should_escalate: bool
    confidence_score: float
    escalation_score: float
    reasons: List[EscalationReason]
    recommended_queue_id: Optional[UUID]
    priority_level: EscalationPriority
    urgency_score: float
    complexity_assessment: Dict[str, Any]
    alternative_actions: List[str]


class EscalationContext(BaseModel):
    """Context for escalation decision."""
    
    message: str
    conversation_length: int
    user_sentiment: float
    rag_confidence: float
    technical_complexity: float
    business_impact: float
    compliance_risk: float
    previous_escalations: int
    time_since_last_response: float
    customer_tier: Optional[str]


# Notification schemas
class EscalationNotification(BaseModel):
    """Schema for escalation notifications."""
    
    escalation_id: UUID
    notification_type: str = Field(..., description="Type of notification")
    recipient_type: str = Field(..., description="Recipient type (agent, manager, system)")
    recipient_id: str = Field(..., description="Recipient ID")
    message: str = Field(..., description="Notification message")
    priority: EscalationPriority
    send_immediately: bool = Field(default=False)
    scheduled_for: Optional[datetime] = Field(None, description="Scheduled send time")


class NotificationStatus(BaseModel):
    """Schema for notification status."""
    
    notification_id: UUID
    status: str
    sent_at: Optional[datetime]
    delivered_at: Optional[datetime]
    read_at: Optional[datetime]
    error_message: Optional[str]