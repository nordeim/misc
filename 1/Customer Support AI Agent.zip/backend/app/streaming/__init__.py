"""
Streaming Response System for Real-time Agent Communication.

This module provides comprehensive streaming capabilities including:
- Server-Sent Events (SSE) implementation
- Token-by-token streaming for agent responses
- Progress tracking and cancellation handling
- Stream analytics and monitoring
"""

from .managers import (
    StreamManager,
    StreamSession,
    StreamConnection,
    StreamState
)

from .handlers import (
    ChatStreamHandler,
    AgentStreamHandler,
    ProgressTracker,
    StreamCancellable
)

from .sse import (
    SSEEndpoint,
    SSEConnectionManager,
    SSEEventFormatter,
    SSEMiddleware
)

from .utils import (
    BufferManager,
    StreamMonitor,
    StreamAnalytics,
    StreamRecovery
)

from .models import (
    StreamEvent,
    StreamMetadata,
    StreamConfig,
    StreamMetrics
)

from .middleware import (
    StreamingMiddleware,
    StreamLoggingMiddleware,
    StreamValidationMiddleware,
    StreamPerformanceMiddleware,
    StreamSecurityMiddleware
)

__all__ = [
    # Managers
    "StreamManager",
    "StreamSession", 
    "StreamConnection",
    "StreamState",
    
    # Handlers
    "ChatStreamHandler",
    "AgentStreamHandler", 
    "ProgressTracker",
    "StreamCancellable",
    
    # SSE
    "SSEEndpoint",
    "SSEConnectionManager",
    "SSEEventFormatter",
    "SSEMiddleware",
    
    # Utils
    "BufferManager",
    "StreamMonitor", 
    "StreamAnalytics",
    "StreamRecovery",
    
    # Models
    "StreamEvent",
    "StreamMetadata",
    "StreamConfig",
    "StreamMetrics",
    
    # Middleware
    "StreamingMiddleware",
    "StreamLoggingMiddleware", 
    "StreamValidationMiddleware",
    "StreamPerformanceMiddleware",
    "StreamSecurityMiddleware"
]