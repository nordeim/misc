"""
Streaming utilities including buffer management, monitoring, and analytics.
"""

import asyncio
import time
import json
from typing import Dict, Any, Optional, List, Deque
from datetime import datetime, timedelta
from collections import deque, defaultdict
from enum import Enum
import weakref

from .models import StreamEvent, StreamEventType, StreamConfig, StreamMetrics
from .managers import StreamManager, StreamConnection, StreamSession
import structlog

logger = structlog.get_logger(__name__)


class BufferStrategy(str, Enum):
    """Buffer management strategies."""
    FIFO = "fifo"  # First In, First Out
    LIFO = "lifo"  # Last In, First Out
    PRIORITY = "priority"  # Priority-based


class BufferManager:
    """Manage streaming buffers with optimization."""
    
    def __init__(self, max_size: int = 1000, strategy: BufferStrategy = BufferStrategy.FIFO):
        self.max_size = max_size
        self.strategy = strategy
        self.buffer: Deque[StreamEvent] = deque(maxlen=max_size)
        self.priority_queue: Dict[int, List[StreamEvent]] = defaultdict(list)
        self.current_priority = 0
        
        # Statistics
        self.total_events_added = 0
        self.total_events_removed = 0
        self.overflow_count = 0
        self.last_cleanup = datetime.utcnow()
    
    async def add_event(self, event: StreamEvent, priority: int = 0) -> bool:
        """Add event to buffer."""
        self.total_events_added += 1
        
        try:
            if self.strategy == BufferStrategy.FIFO:
                self.buffer.append(event)
                
            elif self.strategy == BufferStrategy.LIFO:
                self.buffer.appendleft(event)
                
            elif self.strategy == BufferStrategy.PRIORITY:
                # Add to priority queue
                self.priority_queue[priority].append(event)
                
                # Update current priority
                self.current_priority = max(self.current_priority, priority)
            
            # Handle overflow
            if len(self.buffer) > self.max_size:
                self.overflow_count += 1
                removed_event = self.buffer.popleft()
                logger.debug("Buffer overflow - removed oldest event",
                           event_type=removed_event.type.value,
                           buffer_size=len(self.buffer))
            
            return True
            
        except Exception as e:
            logger.error("Error adding event to buffer", error=str(e))
            return False
    
    async def get_event(self, timeout: Optional[float] = None) -> Optional[StreamEvent]:
        """Get event from buffer."""
        try:
            if self.strategy == BufferStrategy.PRIORITY:
                return await self._get_priority_event(timeout)
            else:
                return await self._get_regular_event(timeout)
                
        except Exception as e:
            logger.error("Error getting event from buffer", error=str(e))
            return None
    
    async def _get_regular_event(self, timeout: Optional[float] = None) -> Optional[StreamEvent]:
        """Get event from regular buffer."""
        if timeout:
            try:
                await asyncio.wait_for(asyncio.get_event_loop().create_future(), timeout=timeout)
            except asyncio.TimeoutError:
                return None
        
        if self.buffer:
            self.total_events_removed += 1
            return self.buffer.popleft()
        
        return None
    
    async def _get_priority_event(self, timeout: Optional[float] = None) -> Optional[StreamEvent]:
        """Get event from priority buffer."""
        start_time = time.time()
        
        while True:
            # Check if we have events with current priority
            if self.current_priority in self.priority_queue and self.priority_queue[self.current_priority]:
                event = self.priority_queue[self.current_priority].pop(0)
                self.total_events_removed += 1
                
                # Clean up empty priority levels
                if not self.priority_queue[self.current_priority]:
                    del self.priority_queue[self.current_priority]
                    self.current_priority = max(self.priority_queue.keys()) if self.priority_queue else 0
                
                return event
            
            # Check timeout
            if timeout and (time.time() - start_time) >= timeout:
                return None
            
            # Wait a bit before checking again
            await asyncio.sleep(0.01)
    
    async def clear_buffer(self):
        """Clear all events from buffer."""
        buffer_size = len(self.buffer)
        self.buffer.clear()
        self.priority_queue.clear()
        
        logger.info("Buffer cleared",
                   cleared_events=buffer_size,
                   total_added=self.total_events_added,
                   total_removed=self.total_events_removed)
    
    async def cleanup_old_events(self, max_age_minutes: int = 60):
        """Remove old events from buffer."""
        current_time = datetime.utcnow()
        cutoff_time = current_time - timedelta(minutes=max_age_minutes)
        
        original_size = len(self.buffer)
        
        # Filter out old events
        self.buffer = deque(
            [event for event in self.buffer if event.timestamp > cutoff_time],
            maxlen=self.max_size
        )
        
        # Clean up priority queue
        for priority in list(self.priority_queue.keys()):
            self.priority_queue[priority] = [
                event for event in self.priority_queue[priority]
                if event.timestamp > cutoff_time
            ]
            
            if not self.priority_queue[priority]:
                del self.priority_queue[priority]
        
        self.last_cleanup = current_time
        
        removed_count = original_size - len(self.buffer)
        if removed_count > 0:
            logger.info("Cleaned up old buffer events",
                       removed_count=removed_count,
                       remaining_count=len(self.buffer))
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get buffer statistics."""
        return {
            "buffer_size": len(self.buffer),
            "max_size": self.max_size,
            "strategy": self.strategy.value,
            "total_events_added": self.total_events_added,
            "total_events_removed": self.total_events_removed,
            "overflow_count": self.overflow_count,
            "current_priority": self.current_priority,
            "priority_levels": len(self.priority_queue),
            "last_cleanup": self.last_cleanup.isoformat()
        }


class StreamMonitor:
    """Monitor streaming performance and health."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.performance_metrics = defaultdict(list)
        self.error_tracking = defaultdict(list)
        self.connection_stats = defaultdict(dict)
        self.monitoring_tasks: Dict[str, asyncio.Task] = {}
        
        # Performance thresholds
        self.thresholds = {
            "max_response_time": 10.0,  # seconds
            "max_buffer_size": 500,
            "max_concurrent_streams": 100,
            "min_events_per_second": 1.0
        }
    
    async def start_monitoring(self):
        """Start monitoring tasks."""
        logger.info("Starting stream monitoring")
        
        # Start performance monitoring
        self.monitoring_tasks["performance"] = asyncio.create_task(
            self._monitor_performance()
        )
        
        # Start health monitoring
        self.monitoring_tasks["health"] = asyncio.create_task(
            self._monitor_health()
        )
        
        # Start connection monitoring
        self.monitoring_tasks["connections"] = asyncio.create_task(
            self._monitor_connections()
        )
    
    async def stop_monitoring(self):
        """Stop all monitoring tasks."""
        logger.info("Stopping stream monitoring")
        
        for task_name, task in self.monitoring_tasks.items():
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        self.monitoring_tasks.clear()
    
    async def record_performance_metric(self, session_id: str, metric_type: str, value: float):
        """Record performance metric."""
        timestamp = datetime.utcnow()
        
        self.performance_metrics[session_id].append({
            "type": metric_type,
            "value": value,
            "timestamp": timestamp.isoformat()
        })
        
        # Keep only recent metrics (last 1000 per session)
        if len(self.performance_metrics[session_id]) > 1000:
            self.performance_metrics[session_id] = self.performance_metrics[session_id][-1000:]
    
    async def record_error(self, session_id: str, error_type: str, error_message: str):
        """Record error occurrence."""
        timestamp = datetime.utcnow()
        
        self.error_tracking[session_id].append({
            "type": error_type,
            "message": error_message,
            "timestamp": timestamp.isoformat()
        })
        
        logger.warning("Stream error recorded",
                      session_id=session_id,
                      error_type=error_type,
                      error_message=error_message)
    
    async def get_performance_report(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get performance report."""
        if session_id:
            metrics = self.performance_metrics.get(session_id, [])
            errors = self.error_tracking.get(session_id, [])
        else:
            # Aggregate metrics across all sessions
            metrics = []
            for session_metrics in self.performance_metrics.values():
                metrics.extend(session_metrics)
            
            errors = []
            for session_errors in self.error_tracking.values():
                errors.extend(session_errors)
        
        # Calculate statistics
        if metrics:
            metric_values = [m["value"] for m in metrics if isinstance(m["value"], (int, float))]
            
            performance_stats = {
                "total_metrics": len(metrics),
                "average_value": sum(metric_values) / len(metric_values) if metric_values else 0,
                "min_value": min(metric_values) if metric_values else 0,
                "max_value": max(metric_values) if metric_values else 0,
                "metric_types": list(set(m["type"] for m in metrics))
            }
        else:
            performance_stats = {
                "total_metrics": 0,
                "average_value": 0,
                "min_value": 0,
                "max_value": 0,
                "metric_types": []
            }
        
        return {
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat(),
            "performance_stats": performance_stats,
            "error_count": len(errors),
            "errors": errors[-10:],  # Last 10 errors
            "health_status": self._assess_health_status(metrics, errors)
        }
    
    async def _monitor_performance(self):
        """Monitor streaming performance."""
        while True:
            try:
                await asyncio.sleep(30)  # Monitor every 30 seconds
                
                # Check each active session
                for session_id, session in self.stream_manager.sessions.items():
                    if session.is_alive():
                        await self._check_session_performance(session_id, session)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in performance monitoring", error=str(e))
    
    async def _monitor_health(self):
        """Monitor overall streaming health."""
        while True:
            try:
                await asyncio.sleep(60)  # Monitor every minute
                
                # Check overall health
                total_sessions = len(self.stream_manager.sessions)
                active_sessions = len([s for s in self.stream_manager.sessions.values() if s.is_alive()])
                
                # Record health metrics
                await self.record_performance_metric("system", "active_sessions", active_sessions)
                await self.record_performance_metric("system", "total_sessions", total_sessions)
                
                # Check thresholds
                if active_sessions > self.thresholds["max_concurrent_streams"]:
                    logger.warning("High concurrent stream count",
                                 active=active_sessions,
                                 threshold=self.thresholds["max_concurrent_streams"])
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in health monitoring", error=str(e))
    
    async def _monitor_connections(self):
        """Monitor individual connections."""
        while True:
            try:
                await asyncio.sleep(15)  # Monitor every 15 seconds
                
                # Monitor active connections
                for session_id, session in self.stream_manager.sessions.items():
                    for connection_id, connection in session.connections.items():
                        if connection.is_active():
                            await self._check_connection_health(connection_id, connection)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in connection monitoring", error=str(e))
    
    async def _check_session_performance(self, session_id: str, session: StreamSession):
        """Check performance of a specific session."""
        active_connections = session.get_active_connections()
        
        if active_connections:
            avg_buffer_size = sum(len(conn.buffer) for conn in active_connections) / len(active_connections)
            
            await self.record_performance_metric(
                session_id,
                "average_buffer_size",
                avg_buffer_size
            )
            
            # Check buffer threshold
            if avg_buffer_size > self.thresholds["max_buffer_size"]:
                await self.record_error(
                    session_id,
                    "high_buffer_size",
                    f"Average buffer size {avg_buffer_size} exceeds threshold"
                )
    
    async def _check_connection_health(self, connection_id: str, connection: StreamConnection):
        """Check health of a specific connection."""
        connection_duration = (datetime.utcnow() - connection.connected_at).total_seconds()
        
        # Record connection duration
        await self.record_performance_metric(connection.session_id, "connection_duration", connection_duration)
        
        # Check for stale connections
        if connection.is_expired(timeout=300):  # 5 minutes
            await self.record_error(
                connection.session_id,
                "stale_connection",
                f"Connection {connection_id} appears stale"
            )
    
    def _assess_health_status(self, metrics: List[Dict], errors: List[Dict]) -> str:
        """Assess overall health status based on metrics and errors."""
        if not metrics:
            return "unknown"
        
        error_rate = len(errors) / len(metrics) if metrics else 0
        
        if error_rate > 0.1:  # More than 10% error rate
            return "unhealthy"
        elif error_rate > 0.05:  # More than 5% error rate
            return "degraded"
        else:
            return "healthy"


class StreamAnalytics:
    """Analytics for streaming operations."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.analytics_data = defaultdict(dict)
        self.start_time = datetime.utcnow()
    
    async def track_event(self, session_id: str, event_type: str, event_data: Dict[str, Any]):
        """Track streaming event."""
        timestamp = datetime.utcnow()
        
        if "events" not in self.analytics_data[session_id]:
            self.analytics_data[session_id]["events"] = []
        
        self.analytics_data[session_id]["events"].append({
            "type": event_type,
            "data": event_data,
            "timestamp": timestamp.isoformat()
        })
        
        # Keep only recent events (last 10000 per session)
        if len(self.analytics_data[session_id]["events"]) > 10000:
            self.analytics_data[session_id]["events"] = self.analytics_data[session_id]["events"][-10000:]
    
    async def get_analytics_summary(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get analytics summary."""
        if session_id:
            data = self.analytics_data.get(session_id, {})
        else:
            # Aggregate analytics across all sessions
            data = self._aggregate_analytics()
        
        return {
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat(),
            "analytics": data
        }
    
    async def get_stream_timeline(self, session_id: str) -> List[Dict[str, Any]]:
        """Get chronological timeline of stream events."""
        if session_id not in self.analytics_data:
            return []
        
        events = self.analytics_data[session_id].get("events", [])
        
        # Sort by timestamp
        sorted_events = sorted(events, key=lambda x: x["timestamp"])
        
        return sorted_events
    
    def _aggregate_analytics(self) -> Dict[str, Any]:
        """Aggregate analytics across all sessions."""
        total_events = 0
        event_types = defaultdict(int)
        
        for session_data in self.analytics_data.values():
            events = session_data.get("events", [])
            total_events += len(events)
            
            for event in events:
                event_types[event["type"]] += 1
        
        return {
            "total_sessions": len(self.analytics_data),
            "total_events": total_events,
            "event_type_distribution": dict(event_types),
            "session_started": self.start_time.isoformat()
        }


class StreamRecovery:
    """Handle stream recovery and resumption."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.recovery_points: Dict[str, Dict[str, Any]] = {}
    
    async def create_recovery_point(self, session_id: str, stream_data: Dict[str, Any]):
        """Create a recovery point for a stream."""
        self.recovery_points[session_id] = {
            "timestamp": datetime.utcnow().isoformat(),
            "stream_data": stream_data,
            "stream_state": "paused"
        }
        
        logger.info("Created recovery point", session_id=session_id)
    
    async def recover_stream(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Recover a stream from recovery point."""
        if session_id not in self.recovery_points:
            logger.warning("No recovery point found", session_id=session_id)
            return None
        
        recovery_data = self.recovery_points[session_id]
        
        # Update state
        recovery_data["stream_state"] = "recovered"
        recovery_data["recovery_timestamp"] = datetime.utcnow().isoformat()
        
        logger.info("Recovered stream", session_id=session_id)
        
        return recovery_data["stream_data"]
    
    async def cleanup_recovery_point(self, session_id: str):
        """Clean up recovery point for a session."""
        if session_id in self.recovery_points:
            del self.recovery_points[session_id]
            logger.info("Cleaned up recovery point", session_id=session_id)
    
    async def cleanup_old_recovery_points(self, max_age_hours: int = 24):
        """Clean up old recovery points."""
        current_time = datetime.utcnow()
        cutoff_time = current_time - timedelta(hours=max_age_hours)
        
        expired_sessions = []
        for session_id, recovery_data in self.recovery_points.items():
            recovery_time = datetime.fromisoformat(recovery_data["timestamp"])
            if recovery_time < cutoff_time:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            await self.cleanup_recovery_point(session_id)
        
        if expired_sessions:
            logger.info("Cleaned up old recovery points",
                       count=len(expired_sessions),
                       max_age_hours=max_age_hours)
    
    def get_recovery_stats(self) -> Dict[str, Any]:
        """Get recovery statistics."""
        return {
            "total_recovery_points": len(self.recovery_points),
            "recovery_points": {
                session_id: {
                    "created_at": data["timestamp"],
                    "state": data["stream_state"]
                }
                for session_id, data in self.recovery_points.items()
            }
        }