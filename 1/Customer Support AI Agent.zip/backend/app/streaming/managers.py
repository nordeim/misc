"""
Stream Managers for handling streaming connections and sessions.
"""

import asyncio
import weakref
from typing import Dict, Any, Optional, List, Callable, Set
from datetime import datetime, timedelta
from collections import deque
import json
import uuid

from .models import (
    StreamState, StreamEvent, StreamEventType,
    StreamMetadata, StreamConfig, StreamContext,
    TokenChunk, StreamError, ProgressUpdate
)
import structlog

logger = structlog.get_logger(__name__)


class StreamConnection:
    """Represents a single stream connection."""
    
    def __init__(self, connection_id: str, session_id: str):
        self.connection_id = connection_id
        self.session_id = session_id
        self.state = StreamState.CONNECTED
        self.metadata = StreamMetadata(session_id=session_id)
        self.config = StreamConfig()
        self.queue = asyncio.Queue(maxsize=1000)
        self.buffer = deque(maxlen=10000)
        self.connected_at = datetime.utcnow()
        self.last_activity = datetime.utcnow()
        self.callbacks: Dict[str, Callable] = {}
        self.send_callback: Optional[Callable] = None
        self.close_callback: Optional[Callable] = None
        self.error_callback: Optional[Callable] = None
    
    async def send_event(self, event: StreamEvent) -> bool:
        """Send an event through the connection."""
        try:
            self.last_activity = datetime.utcnow()
            self.metadata.total_events += 1
            
            # Add to buffer for potential resumption
            self.buffer.append(event)
            
            # Put in queue for async processing
            await self.queue.put(event)
            
            # Call send callback if set
            if self.send_callback:
                await self._safe_callback("send_callback", event)
            
            return True
            
        except asyncio.QueueFull:
            logger.warning("Stream connection queue full", 
                         connection_id=self.connection_id)
            self.metadata.buffer_size = self.queue.qsize()
            return False
        except Exception as e:
            logger.error("Error sending event", 
                        connection_id=self.connection_id,
                        error=str(e))
            await self._handle_error(StreamError(
                error_code="send_failed",
                error_message=str(e),
                error_type="connection_error",
                recoverable=True
            ))
            return False
    
    async def receive_event(self, timeout: Optional[float] = None) -> Optional[StreamEvent]:
        """Receive an event from the connection."""
        try:
            event = await asyncio.wait_for(self.queue.get(), timeout=timeout)
            self.last_activity = datetime.utcnow()
            return event
        except asyncio.TimeoutError:
            return None
    
    async def send_token(self, token: TokenChunk) -> bool:
        """Send a token chunk through the connection."""
        event = StreamEvent(
            type=StreamEventType.DATA,
            session_id=self.session_id,
            data={
                "token": token.content,
                "token_count": token.token_count,
                "chunk_index": token.chunk_index,
                "is_final": token.is_final,
                "metadata": token.metadata
            },
            metadata={"timestamp": token.timestamp.isoformat()}
        )
        
        self.metadata.tokens_sent += token.token_count
        return await self.send_event(event)
    
    async def send_progress(self, progress: ProgressUpdate) -> bool:
        """Send progress update through the connection."""
        event = StreamEvent(
            type=StreamEventType.PROGRESS,
            session_id=self.session_id,
            data=progress.dict(),
            metadata={"timestamp": progress.timestamp.isoformat()}
        )
        return await self.send_event(event)
    
    async def complete(self) -> bool:
        """Mark stream as completed."""
        self.state = StreamState.COMPLETED
        self.metadata.end_time = datetime.utcnow()
        
        event = StreamEvent(
            type=StreamEventType.COMPLETE,
            session_id=self.session_id,
            data={
                "duration": (self.metadata.end_time - self.metadata.start_time).total_seconds(),
                "total_events": self.metadata.total_events,
                "total_tokens": self.metadata.tokens_sent,
                "bytes_sent": self.metadata.bytes_sent
            }
        )
        
        return await self.send_event(event)
    
    async def cancel(self, reason: Optional[str] = None) -> bool:
        """Cancel the stream."""
        self.state = StreamState.CANCELLED
        self.metadata.end_time = datetime.utcnow()
        
        event = StreamEvent(
            type=StreamEventType.CANCEL,
            session_id=self.session_id,
            data={"reason": reason or "User cancelled"}
        )
        
        success = await self.send_event(event)
        
        if self.close_callback:
            await self._safe_callback("close_callback")
        
        return success
    
    async def error(self, error: StreamError) -> bool:
        """Handle stream error."""
        self.state = StreamState.ERROR
        
        event = StreamEvent(
            type=StreamEventType.ERROR,
            session_id=self.session_id,
            data=error.dict(),
            metadata={"timestamp": error.timestamp.isoformat()}
        )
        
        success = await self.send_event(event)
        
        if self.error_callback:
            await self._safe_callback("error_callback", error)
        
        return success
    
    def is_active(self) -> bool:
        """Check if connection is active."""
        return self.state in [StreamState.CONNECTED, StreamState.ACTIVE]
    
    def is_expired(self, timeout: int = 300) -> bool:
        """Check if connection has expired due to inactivity."""
        if not self.last_activity:
            return False
        
        return (datetime.utcnow() - self.last_activity).total_seconds() > timeout
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get connection metrics."""
        duration = (datetime.utcnow() - self.connected_at).total_seconds()
        
        return {
            "connection_id": self.connection_id,
            "session_id": self.session_id,
            "state": self.state.value,
            "connected_at": self.connected_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
            "duration_seconds": duration,
            "total_events": self.metadata.total_events,
            "tokens_sent": self.metadata.tokens_sent,
            "buffer_size": len(self.buffer),
            "queue_size": self.queue.qsize()
        }
    
    async def _safe_callback(self, callback_name: str, *args):
        """Safely execute callback."""
        try:
            callback = getattr(self, callback_name, None)
            if callback:
                if asyncio.iscoroutinefunction(callback):
                    await callback(*args)
                else:
                    callback(*args)
        except Exception as e:
            logger.error("Callback execution failed",
                        callback=callback_name,
                        connection_id=self.connection_id,
                        error=str(e))
    
    async def _handle_error(self, error: StreamError):
        """Handle internal error."""
        if self.error_callback:
            await self._safe_callback("error_callback", error)


class StreamSession:
    """Represents a streaming session with multiple connections."""
    
    def __init__(self, session_id: str, context: StreamContext):
        self.session_id = session_id
        self.context = context
        self.connections: Dict[str, StreamConnection] = {}
        self.state = StreamState.CONNECTED
        self.created_at = datetime.utcnow()
        self.metadata = StreamMetadata(session_id=session_id)
        self.stream_data: List[TokenChunk] = []
        self.progress_tracking: Dict[str, ProgressUpdate] = {}
        self.callbacks: Dict[str, Callable] = {}
    
    def add_connection(self, connection: StreamConnection):
        """Add a connection to the session."""
        self.connections[connection.connection_id] = connection
        logger.info("Added connection to session",
                   session_id=self.session_id,
                   connection_id=connection.connection_id)
    
    def remove_connection(self, connection_id: str):
        """Remove a connection from the session."""
        if connection_id in self.connections:
            del self.connections[connection_id]
            logger.info("Removed connection from session",
                       session_id=self.session_id,
                       connection_id=connection_id)
    
    async def broadcast_event(self, event: StreamEvent, exclude_connection: Optional[str] = None):
        """Broadcast event to all active connections."""
        for conn_id, connection in self.connections.items():
            if conn_id != exclude_connection and connection.is_active():
                await connection.send_event(event)
    
    async def broadcast_token(self, token: TokenChunk, exclude_connection: Optional[str] = None):
        """Broadcast token to all active connections."""
        await self.broadcast_event(StreamEvent(
            type=StreamEventType.DATA,
            session_id=self.session_id,
            data={"token": token.content},
            metadata={"chunk_index": token.chunk_index}
        ), exclude_connection)
    
    async def send_to_connection(self, connection_id: str, event: StreamEvent) -> bool:
        """Send event to specific connection."""
        if connection_id in self.connections:
            return await self.connections[connection_id].send_event(event)
        return False
    
    def get_active_connections(self) -> List[StreamConnection]:
        """Get all active connections."""
        return [conn for conn in self.connections.values() if conn.is_active()]
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get session metrics."""
        active_connections = self.get_active_connections()
        
        return {
            "session_id": self.session_id,
            "state": self.state.value,
            "created_at": self.created_at.isoformat(),
            "total_connections": len(self.connections),
            "active_connections": len(active_connections),
            "stream_data_chunks": len(self.stream_data),
            "metadata": self.metadata.dict()
        }
    
    def is_alive(self) -> bool:
        """Check if session has any active connections."""
        return len(self.get_active_connections()) > 0


class StreamManager:
    """Central manager for all streaming sessions and connections."""
    
    def __init__(self, config: Optional[StreamConfig] = None):
        self.config = config or StreamConfig()
        self.sessions: Dict[str, StreamSession] = {}
        self.connections: Dict[str, StreamConnection] = {}
        self.stream_analytics = {}
        self.cleanup_task: Optional[asyncio.Task] = None
        self.monitoring_task: Optional[asyncio.Task] = None
        self._shutdown_event = asyncio.Event()
    
    async def start(self):
        """Start the stream manager."""
        logger.info("Starting Stream Manager")
        
        # Start cleanup task
        self.cleanup_task = asyncio.create_task(self._cleanup_expired_sessions())
        
        # Start monitoring task
        self.monitoring_task = asyncio.create_task(self._monitor_sessions())
    
    async def stop(self):
        """Stop the stream manager."""
        logger.info("Stopping Stream Manager")
        
        self._shutdown_event.set()
        
        # Cancel all tasks
        for task in [self.cleanup_task, self.monitoring_task]:
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        # Close all connections
        for session in self.sessions.values():
            for connection in session.get_active_connections():
                await connection.cancel("Stream manager shutting down")
    
    async def create_session(self, context: StreamContext) -> StreamSession:
        """Create a new streaming session."""
        session_id = str(uuid.uuid4())
        session = StreamSession(session_id, context)
        self.sessions[session_id] = session
        
        logger.info("Created streaming session",
                   session_id=session_id,
                   user_id=context.user_id)
        
        return session
    
    async def get_session(self, session_id: str) -> Optional[StreamSession]:
        """Get session by ID."""
        return self.sessions.get(session_id)
    
    async def create_connection(self, session_id: str, connection_id: Optional[str] = None) -> Optional[StreamConnection]:
        """Create a new connection for a session."""
        session = await self.get_session(session_id)
        if not session:
            logger.error("Session not found for connection creation",
                        session_id=session_id)
            return None
        
        conn_id = connection_id or str(uuid.uuid4())
        connection = StreamConnection(conn_id, session_id)
        
        # Set callbacks
        connection.send_callback = self._on_connection_send
        connection.close_callback = self._on_connection_close
        connection.error_callback = self._on_connection_error
        
        # Add to tracking
        self.connections[conn_id] = connection
        session.add_connection(connection)
        
        logger.info("Created stream connection",
                   session_id=session_id,
                   connection_id=conn_id)
        
        return connection
    
    async def remove_connection(self, connection_id: str):
        """Remove a connection."""
        if connection_id in self.connections:
            connection = self.connections[connection_id]
            session = await self.get_session(connection.session_id)
            
            if session:
                session.remove_connection(connection_id)
                
                # Remove session if no more connections
                if not session.is_alive():
                    del self.sessions[connection.session_id]
                    logger.info("Removed empty session",
                               session_id=connection.session_id)
            
            del self.connections[connection_id]
            logger.info("Removed stream connection", connection_id=connection_id)
    
    async def cleanup_expired_sessions(self):
        """Manually trigger cleanup of expired sessions."""
        await self._cleanup_expired_sessions()
    
    async def get_stream_metrics(self) -> Dict[str, Any]:
        """Get overall stream metrics."""
        total_connections = len(self.connections)
        active_connections = len([c for c in self.connections.values() if c.is_active()])
        total_sessions = len(self.sessions)
        active_sessions = len([s for s in self.sessions.values() if s.is_alive()])
        
        return {
            "total_connections": total_connections,
            "active_connections": active_connections,
            "total_sessions": total_sessions,
            "active_sessions": active_sessions,
            "config": self.config.dict()
        }
    
    async def _cleanup_expired_sessions(self):
        """Internal cleanup task for expired sessions."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.wait_for(self._shutdown_event.wait(), timeout=60)
                break
            except asyncio.TimeoutError:
                expired_connections = []
                for conn_id, connection in self.connections.items():
                    if connection.is_expired(self.config.timeout):
                        expired_connections.append(conn_id)
                
                if expired_connections:
                    logger.info("Cleaning up expired connections",
                               count=len(expired_connections))
                    
                    for conn_id in expired_connections:
                        await self.remove_connection(conn_id)
                
                # Clean up empty sessions
                empty_sessions = [
                    session_id for session_id, session in self.sessions.items()
                    if not session.is_alive()
                ]
                
                if empty_sessions:
                    for session_id in empty_sessions:
                        del self.sessions[session_id]
                        logger.info("Cleaned up empty session", session_id=session_id)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in cleanup task", error=str(e))
    
    async def _monitor_sessions(self):
        """Internal monitoring task for sessions."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.wait_for(self._shutdown_event.wait(), timeout=30)
                break
            except asyncio.TimeoutError:
                # Log session statistics
                metrics = await self.get_stream_metrics()
                logger.debug("Stream manager metrics", **metrics)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in monitoring task", error=str(e))
    
    async def _on_connection_send(self, connection: StreamConnection, event: StreamEvent):
        """Handle connection send callback."""
        self.stream_analytics[connection.session_id] = self.stream_analytics.get(
            connection.session_id, {}
        )
        self.stream_analytics[connection.session_id]["events_sent"] = \
            self.stream_analytics[connection.session_id].get("events_sent", 0) + 1
    
    async def _on_connection_close(self, connection: StreamConnection):
        """Handle connection close callback."""
        # Schedule removal after a short delay to allow for reconnection
        asyncio.create_task(self._delayed_connection_removal(connection.connection_id))
    
    async def _on_connection_error(self, connection: StreamConnection, error: StreamError):
        """Handle connection error callback."""
        logger.error("Stream connection error",
                    connection_id=connection.connection_id,
                    error=error.error_message)
    
    async def _delayed_connection_removal(self, connection_id: str, delay: float = 5.0):
        """Delayed removal of connection (allows for reconnection)."""
        await asyncio.sleep(delay)
        if connection_id in self.connections:
            connection = self.connections[connection_id]
            if not connection.is_active():
                await self.remove_connection(connection_id)