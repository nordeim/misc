"""
Streaming middleware for request/response processing, logging, validation, and performance optimization.
"""

import asyncio
import time
import json
from typing import Dict, Any, Optional, List, Callable, Union
from datetime import datetime
from urllib.parse import parse_qs

from fastapi import Request, Response, HTTPException
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from .models import StreamEvent, StreamEventType, StreamContext, StreamConfig
from .managers import StreamManager, StreamConnection
from .utils import StreamMonitor, BufferManager, StreamAnalytics
import structlog

logger = structlog.get_logger(__name__)


class StreamingRequestContext:
    """Context for streaming request processing."""
    
    def __init__(self, request: Request):
        self.request = request
        self.start_time = time.time()
        self.request_id = request.headers.get("x-request-id", str(id(request)))
        self.user_id = request.headers.get("x-user-id", "anonymous")
        self.session_id = request.query_params.get("session_id", "")
        self.stream_type = request.query_params.get("stream_type", "chat")
        
        # Request metadata
        self.client_ip = request.client.host if request.client else "unknown"
        self.user_agent = request.headers.get("user-agent", "")
        self.content_length = request.headers.get("content-length", "0")
        
        # Response tracking
        self.response_started = False
        self.bytes_sent = 0
        self.events_sent = 0


class StreamingMiddleware:
    """Base streaming middleware for request/response processing."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.monitoring = StreamMonitor(stream_manager)
        self.buffer_manager = BufferManager()
        self.analytics = StreamAnalytics(stream_manager)
    
    async def __call__(self, request: Request, call_next: Callable) -> Response:
        """Process request with streaming middleware."""
        
        # Create request context
        ctx = StreamingRequestContext(request)
        
        try:
            # Pre-processing
            await self.pre_process(request, ctx)
            
            # Process request
            start_time = time.time()
            response = await call_next(request)
            processing_time = time.time() - start_time
            
            # Post-processing
            await self.post_process(request, response, ctx, processing_time)
            
            return response
            
        except Exception as e:
            await self.handle_error(request, ctx, e)
            raise
    
    async def pre_process(self, request: Request, ctx: StreamingRequestContext):
        """Pre-process the request."""
        logger.debug("Processing streaming request",
                    request_id=ctx.request_id,
                    path=request.url.path,
                    client_ip=ctx.client_ip)
        
        # Track request in analytics
        await self.analytics.track_event(
            ctx.session_id,
            "request_received",
            {
                "path": str(request.url.path),
                "method": request.method,
                "stream_type": ctx.stream_type
            }
        )
    
    async def post_process(self, request: Request, response: Response, 
                          ctx: StreamingRequestContext, processing_time: float):
        """Post-process the response."""
        
        # Track response in analytics
        await self.analytics.track_event(
            ctx.session_id,
            "response_sent",
            {
                "status_code": response.status_code,
                "processing_time": processing_time,
                "bytes_sent": ctx.bytes_sent,
                "events_sent": ctx.events_sent
            }
        )
        
        # Record performance metrics
        await self.monitoring.record_performance_metric(
            ctx.session_id,
            "request_processing_time",
            processing_time
        )
        
        logger.debug("Completed streaming request",
                    request_id=ctx.request_id,
                    processing_time=processing_time,
                    status_code=response.status_code)
    
    async def handle_error(self, request: Request, ctx: StreamingRequestContext, error: Exception):
        """Handle request processing error."""
        
        # Track error in analytics
        await self.analytics.track_event(
            ctx.session_id,
            "request_error",
            {
                "error_type": type(error).__name__,
                "error_message": str(error),
                "path": str(request.url.path)
            }
        )
        
        # Record error in monitoring
        await self.monitoring.record_error(
            ctx.session_id,
            type(error).__name__,
            str(error)
        )
        
        logger.error("Streaming request failed",
                    request_id=ctx.request_id,
                    error_type=type(error).__name__,
                    error_message=str(error))


class StreamLoggingMiddleware(StreamingMiddleware):
    """Middleware for comprehensive streaming request/response logging."""
    
    def __init__(self, stream_manager: StreamManager, log_all_requests: bool = False):
        super().__init__(stream_manager)
        self.log_all_requests = log_all_requests
        self.performance_threshold = 2.0  # Log requests taking longer than 2 seconds
    
    async def post_process(self, request: Request, response: Response, 
                          ctx: StreamingRequestContext, processing_time: float):
        """Enhanced post-processing with detailed logging."""
        
        # Call parent method
        await super().post_process(request, response, ctx, processing_time)
        
        # Determine if we should log this request
        should_log = (
            self.log_all_requests or 
            processing_time > self.performance_threshold or
            response.status_code >= 400
        )
        
        if should_log:
            # Detailed logging
            logger.info("Streaming request completed",
                       request_id=ctx.request_id,
                       session_id=ctx.session_id,
                       client_ip=ctx.client_ip,
                       method=request.method,
                       path=str(request.url.path),
                       status_code=response.status_code,
                       processing_time=processing_time,
                       user_agent=ctx.user_agent[:100],  # Truncate long user agents
                       bytes_sent=ctx.bytes_sent,
                       events_sent=ctx.events_sent,
                       content_length=ctx.content_length)
    
    async def handle_error(self, request: Request, ctx: StreamingRequestContext, error: Exception):
        """Enhanced error handling with detailed logging."""
        
        # Call parent method
        await super().handle_error(request, ctx, error)
        
        # Detailed error logging
        logger.error("Streaming request error",
                    request_id=ctx.request_id,
                    session_id=ctx.session_id,
                    client_ip=ctx.client_ip,
                    method=request.method,
                    path=str(request.url.path),
                    error_type=type(error).__name__,
                    error_message=str(error),
                    user_agent=ctx.user_agent[:100])


class StreamValidationMiddleware(StreamingMiddleware):
    """Middleware for streaming request validation and sanitization."""
    
    def __init__(self, stream_manager: StreamManager):
        super().__init__(stream_manager)
        self.validation_rules = {
            "session_id": {"min_length": 1, "max_length": 100},
            "stream_type": {"allowed_values": ["chat", "agent", "progress", "status"]},
            "content_length": {"max_size": 1024 * 1024}  # 1MB
        }
    
    async def pre_process(self, request: Request, ctx: StreamingRequestContext):
        """Validate streaming request parameters."""
        
        # Call parent method
        await super().pre_process(request, ctx)
        
        # Validate required parameters
        if not ctx.session_id:
            raise HTTPException(
                status_code=400,
                detail="session_id is required for streaming requests"
            )
        
        # Validate session_id format
        session_validation = self._validate_parameter("session_id", ctx.session_id)
        if not session_validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid session_id: {session_validation['error']}"
            )
        
        # Validate stream_type
        stream_type_validation = self._validate_parameter("stream_type", ctx.stream_type)
        if not stream_type_validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid stream_type: {stream_type_validation['error']}"
            )
        
        # Validate content length
        try:
            content_length = int(ctx.content_length)
            content_validation = self._validate_parameter("content_length", content_length)
            if not content_validation["valid"]:
                raise HTTPException(
                    status_code=413,
                    detail="Request content too large"
                )
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid content-length header")
    
    def _validate_parameter(self, param_name: str, value: Any) -> Dict[str, Any]:
        """Validate a single parameter against rules."""
        if param_name not in self.validation_rules:
            return {"valid": True, "error": None}
        
        rules = self.validation_rules[param_name]
        
        # String length validation
        if "min_length" in rules or "max_length" in rules:
            if not isinstance(value, str):
                return {"valid": False, "error": f"{param_name} must be a string"}
            
            if "min_length" in rules and len(value) < rules["min_length"]:
                return {"valid": False, "error": f"{param_name} too short"}
            
            if "max_length" in rules and len(value) > rules["max_length"]:
                return {"valid": False, "error": f"{param_name} too long"}
        
        # Integer validation
        if "min_size" in rules or "max_size" in rules:
            if not isinstance(value, (int, float)):
                return {"valid": False, "error": f"{param_name} must be a number"}
            
            if "min_size" in rules and value < rules["min_size"]:
                return {"valid": False, "error": f"{param_name} too small"}
            
            if "max_size" in rules and value > rules["max_size"]:
                return {"valid": False, "error": f"{param_name} too large"}
        
        # Allowed values validation
        if "allowed_values" in rules:
            if value not in rules["allowed_values"]:
                return {"valid": False, "error": f"{param_name} not in allowed values"}
        
        return {"valid": True, "error": None}


class StreamPerformanceMiddleware(StreamingMiddleware):
    """Middleware for streaming performance optimization and monitoring."""
    
    def __init__(self, stream_manager: StreamManager, enable_compression: bool = True):
        super().__init__(stream_manager)
        self.enable_compression = enable_compression
        self.performance_metrics = {}
        self.optimization_threshold = 1.0  # Optimize requests taking longer than 1 second
        
        # Performance limits
        self.limits = {
            "max_concurrent_requests": 100,
            "max_request_duration": 30.0,
            "max_response_size": 1024 * 1024 * 10  # 10MB
        }
        
        # Request tracking
        self.active_requests: Dict[str, Dict[str, Any]] = {}
    
    async def pre_process(self, request: Request, ctx: StreamingRequestContext):
        """Pre-process with performance optimization."""
        
        # Check concurrent request limit
        if len(self.active_requests) >= self.limits["max_concurrent_requests"]:
            raise HTTPException(
                status_code=503,
                detail="Too many concurrent requests"
            )
        
        # Track active request
        self.active_requests[ctx.request_id] = {
            "start_time": time.time(),
            "session_id": ctx.session_id,
            "path": str(request.url.path)
        }
        
        # Call parent method
        await super().pre_process(request, ctx)
    
    async def post_process(self, request: Request, response: Response, 
                          ctx: StreamingRequestContext, processing_time: float):
        """Post-process with performance optimization."""
        
        # Check if optimization is needed
        if processing_time > self.optimization_threshold:
            await self._optimize_streaming_performance(request, ctx, processing_time)
        
        # Clean up active request
        if ctx.request_id in self.active_requests:
            del self.active_requests[ctx.request_id]
        
        # Update performance metrics
        self.performance_metrics[ctx.stream_type] = self.performance_metrics.get(
            ctx.stream_type, []
        )
        self.performance_metrics[ctx.stream_type].append({
            "timestamp": datetime.utcnow().isoformat(),
            "processing_time": processing_time,
            "bytes_sent": ctx.bytes_sent,
            "events_sent": ctx.events_sent
        })
        
        # Keep only recent metrics
        if len(self.performance_metrics[ctx.stream_type]) > 1000:
            self.performance_metrics[ctx.stream_type] = self.performance_metrics[ctx.stream_type][-1000:]
        
        # Call parent method
        await super().post_process(request, response, ctx, processing_time)
    
    async def _optimize_streaming_performance(self, request: Request, ctx: StreamingRequestContext, processing_time: float):
        """Apply performance optimizations for slow requests."""
        
        logger.info("Applying streaming performance optimization",
                   request_id=ctx.request_id,
                   processing_time=processing_time,
                   stream_type=ctx.stream_type)
        
        # Adjust buffer size for better performance
        if ctx.stream_type in ["chat", "agent"]:
            await self.buffer_manager.cleanup_old_events(max_age_minutes=30)
        
        # Record optimization event
        await self.analytics.track_event(
            ctx.session_id,
            "performance_optimization",
            {
                "optimization_applied": True,
                "processing_time": processing_time,
                "buffer_size": len(self.buffer_manager.buffer)
            }
        )
    
    async def handle_error(self, request: Request, ctx: StreamingRequestContext, error: Exception):
        """Handle error with performance context."""
        
        # Clean up active request
        if ctx.request_id in self.active_requests:
            del self.active_requests[ctx.request_id]
        
        # Call parent method
        await super().handle_error(request, ctx, error)
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get streaming performance statistics."""
        active_count = len(self.active_requests)
        
        # Calculate average processing times
        avg_times = {}
        for stream_type, metrics in self.performance_metrics.items():
            if metrics:
                avg_times[stream_type] = sum(m["processing_time"] for m in metrics) / len(metrics)
        
        return {
            "active_requests": active_count,
            "max_concurrent_requests": self.limits["max_concurrent_requests"],
            "average_processing_times": avg_times,
            "optimization_threshold": self.optimization_threshold,
            "compression_enabled": self.enable_compression
        }


class StreamSecurityMiddleware(StreamingMiddleware):
    """Middleware for streaming security validation."""
    
    def __init__(self, stream_manager: StreamManager):
        super().__init__(stream_manager)
        self.blocked_ips: set = set()
        self.rate_limits: Dict[str, Dict[str, int]] = {}  # session_id -> {count, reset_time}
        self.security_rules = {
            "max_events_per_minute": 60,
            "max_bytes_per_minute": 1024 * 1024,  # 1MB
            "max_concurrent_streams_per_session": 5
        }
    
    async def pre_process(self, request: Request, ctx: StreamingRequestContext):
        """Pre-process with security validation."""
        
        # Check if IP is blocked
        if ctx.client_ip in self.blocked_ips:
            raise HTTPException(status_code=403, detail="IP address blocked")
        
        # Check rate limiting
        rate_limit_result = await self._check_rate_limit(ctx)
        if not rate_limit_result["allowed"]:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: {rate_limit_result['reason']}"
            )
        
        # Check stream concurrency
        concurrent_streams = await self._check_concurrent_streams(ctx.session_id)
        if concurrent_streams > self.security_rules["max_concurrent_streams_per_session"]:
            raise HTTPException(
                status_code=429,
                detail="Too many concurrent streams for session"
            )
        
        # Call parent method
        await super().pre_process(request, ctx)
    
    async def _check_rate_limit(self, ctx: StreamingRequestContext) -> Dict[str, Any]:
        """Check rate limiting for session."""
        session_id = ctx.session_id
        current_time = time.time()
        
        if session_id not in self.rate_limits:
            self.rate_limits[session_id] = {"count": 1, "reset_time": current_time + 60}
            return {"allowed": True}
        
        rate_data = self.rate_limits[session_id]
        
        # Reset if time window has passed
        if current_time > rate_data["reset_time"]:
            self.rate_limits[session_id] = {"count": 1, "reset_time": current_time + 60}
            return {"allowed": True}
        
        # Check if under limit
        if rate_data["count"] < self.security_rules["max_events_per_minute"]:
            rate_data["count"] += 1
            return {"allowed": True}
        
        return {
            "allowed": False,
            "reason": f"Maximum {self.security_rules['max_events_per_minute']} events per minute exceeded"
        }
    
    async def _check_concurrent_streams(self, session_id: str) -> int:
        """Check number of concurrent streams for session."""
        active_streams = 0
        
        # Check current active streams
        for stream_session in self.stream_manager.sessions.values():
            if stream_session.session_id == session_id and stream_session.is_alive():
                active_streams += len(stream_session.get_active_connections())
        
        return active_streams
    
    async def post_process(self, request: Request, response: Response, 
                          ctx: StreamingRequestContext, processing_time: float):
        """Post-process with security logging."""
        
        # Add security headers for streaming responses
        if hasattr(response, "headers"):
            response.headers["X-Stream-Type"] = ctx.stream_type
            response.headers["X-Request-ID"] = ctx.request_id
            response.headers["X-Security-Middleware"] = "enabled"
        
        # Call parent method
        await super().post_process(request, response, ctx, processing_time)


def setup_streaming_middleware(
    app,
    stream_manager: StreamManager,
    enable_logging: bool = True,
    enable_validation: bool = True,
    enable_performance: bool = True,
    enable_security: bool = True,
    log_all_requests: bool = False
):
    """Setup comprehensive streaming middleware stack."""
    
    middleware_stack = []
    
    # Add security middleware first
    if enable_security:
        security_middleware = StreamSecurityMiddleware(stream_manager)
        middleware_stack.append(security_middleware)
    
    # Add validation middleware
    if enable_validation:
        validation_middleware = StreamValidationMiddleware(stream_manager)
        middleware_stack.append(validation_middleware)
    
    # Add performance middleware
    if enable_performance:
        performance_middleware = StreamPerformanceMiddleware(stream_manager)
        middleware_stack.append(performance_middleware)
    
    # Add logging middleware last
    if enable_logging:
        logging_middleware = StreamLoggingMiddleware(stream_manager, log_all_requests)
        middleware_stack.append(logging_middleware)
    
    # Apply middleware to app
    for middleware in middleware_stack:
        app.middleware("http")(middleware)
    
    logger.info("Streaming middleware stack configured",
                middleware_count=len(middleware_stack),
                components=[type(m).__name__ for m in middleware_stack])
    
    return middleware_stack