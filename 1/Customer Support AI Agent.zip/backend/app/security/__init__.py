"""
Security module for authentication, authorization, and data protection.

This module provides comprehensive security functionality including:
- JWT authentication and token management
- Password hashing and verification
- Role-based access control
- Security utilities and validation
- Encryption and data protection
"""

from .auth import (
    authenticate_user,
    create_access_token,
    get_current_user,
    get_current_active_user,
    verify_token,
)
from .password_utils import (
    get_password_hash,
    verify_password,
    validate_password_strength,
)
from .token_utils import (
    create_token_pair,
    verify_access_token,
    decode_token,
    revoke_token,
    is_token_revoked,
)
from .permissions import (
    Permission,
    Role,
    UserPermissions,
    require_permission,
    require_role,
    check_permission,
)
from .encryption_utils import (
    encrypt_data,
    decrypt_data,
    generate_key,
    secure_hash,
    verify_hash,
)

__all__ = [
    "authenticate_user",
    "create_access_token",
    "get_current_user",
    "get_current_active_user",
    "verify_token",
    "get_password_hash",
    "verify_password",
    "validate_password_strength",
    "create_token_pair",
    "verify_access_token",
    "decode_token",
    "revoke_token",
    "is_token_revoked",
    "Permission",
    "Role",
    "UserPermissions",
    "require_permission",
    "require_role",
    "check_permission",
    "encrypt_data",
    "decrypt_data",
    "generate_key",
    "secure_hash",
    "verify_hash",
]
