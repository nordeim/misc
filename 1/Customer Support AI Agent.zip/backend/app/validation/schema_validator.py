"""
Enhanced schema validation system.

Provides comprehensive schema validation including:
- Pydantic model validation
- Custom validation rules
- Type conversion and coercion
- Schema versioning and compatibility
- Cross-field validation
"""

import re
import json
import operator
from typing import Any, Dict, List, Optional, Union, Callable, Type, TypeVar
from datetime import datetime, date
from enum import Enum
from pathlib import Path

from pydantic import (
    BaseModel, 
    Field, 
    validator, 
    root_validator,
    ValidationError,
    constr,
    conint,
    confloat,
    conlist
)
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

# Type variables
T = TypeVar('T')

class ValidationType(Enum):
    """Types of validation."""
    EMAIL = "email"
    URL = "url"
    PHONE = "phone"
    CREDIT_CARD = "credit_card"
    UUID = "uuid"
    IP_ADDRESS = "ip_address"
    MAC_ADDRESS = "mac_address"
    PASSWORD = "password"
    USERNAME = "username"
    JSON = "json"
    DATE = "date"
    TIME = "time"
    DATETIME = "datetime"

class SchemaVersion(Enum):
    """Schema versions for compatibility."""
    V1 = "1.0"
    V2 = "2.0"
    LATEST = "latest"

class ValidationRule:
    """Represents a validation rule."""
    
    def __init__(
        self,
        field: str,
        rule_type: Union[ValidationType, str],
        params: Optional[Dict[str, Any]] = None,
        required: bool = True,
        custom_validator: Optional[Callable] = None
    ):
        self.field = field
        self.rule_type = rule_type
        self.params = params or {}
        self.required = required
        self.custom_validator = custom_validator

class ValidationResult:
    """Result of validation."""
    
    def __init__(
        self,
        is_valid: bool,
        errors: List[str] = None,
        warnings: List[str] = None,
        normalized_data: Optional[Dict[str, Any]] = None
    ):
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []
        self.normalized_data = normalized_data or {}
        self.timestamp = datetime.utcnow()
    
    def add_error(self, error: str):
        """Add an error to the result."""
        self.errors.append(error)
        self.is_valid = False
    
    def add_warning(self, warning: str):
        """Add a warning to the result."""
        self.warnings.append(warning)

class SchemaValidator:
    """Enhanced schema validation system."""
    
    def __init__(self):
        self.validation_patterns = self._compile_validation_patterns()
        self.custom_validators = {}
        
        logger.info("Schema validator initialized")
    
    def _compile_validation_patterns(self) -> Dict[str, re.Pattern]:
        """Compile validation patterns."""
        return {
            "email": re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),
            "url": re.compile(r'^https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.]*))?(?:#(?:\w)*)?)?$'),
            "phone": re.compile(r'^\+?1?-?\.?\s?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$'),
            "uuid": re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE),
            "ipv4": re.compile(r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'),
            "ipv6": re.compile(r'^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(([0-9a-fA-F]{1,4}:){1,7}|:):(([0-9a-fA-F]{1,4}:){1,6}|:){1,4}|([0-9a-fA-F]{1,4}:){1,5}:(([0-9a-fA-F]{1,4}:){1,4}|:){1,3}|([0-9a-fA-F]{1,4}:){1,4}:(([0-9a-fA-F]{1,4}:){1,3}|:){1,2}|([0-9a-fA-F]{1,4}:){1,3}:(([0-9a-fA-F]{1,4}:){1,2}|:){1,2}|([0-9a-fA-F]{1,4}:){1,2}:(([0-9a-fA-F]{1,4}:){1,1}|:){1,1}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$'),
            "mac_address": re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'),
            "username": re.compile(r'^[a-zA-Z0-9_.-]{3,50}$'),
            "password": re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'),
        }
    
    def validate_data(
        self, 
        data: Any, 
        schema: Type[BaseModel],
        version: SchemaVersion = SchemaVersion.LATEST,
        strict: bool = False,
        normalize: bool = True
    ) -> ValidationResult:
        """
        Validate data against a schema.
        
        Args:
            data: Data to validate
            schema: Pydantic schema class
            version: Schema version
            strict: Whether to use strict validation
            normalize: Whether to normalize the data
            
        Returns:
            ValidationResult with validation outcome
        """
        result = ValidationResult(is_valid=True)
        
        try:
            # Apply version-specific validation
            if version != SchemaVersion.LATEST:
                data = self._apply_version_compatibility(data, version)
            
            # Create model instance with validation settings
            model_config = {"strict": strict}
            
            # Validate using Pydantic
            validated_data = schema(**data)
            
            # Custom validation
            custom_errors = self._apply_custom_validators(data, schema)
            for error in custom_errors:
                result.add_error(error)
            
            # Cross-field validation
            cross_field_errors = self._validate_cross_fields(validated_data, schema)
            for error in cross_field_errors:
                result.add_error(error)
            
            # Normalization
            if normalize and result.is_valid:
                result.normalized_data = validated_data.dict()
            
            logger.info("Schema validation completed",
                       is_valid=result.is_valid,
                       error_count=len(result.errors),
                       data_type=type(data).__name__)
            
        except ValidationError as e:
            # Parse Pydantic validation errors
            for error in e.errors():
                field_path = "->".join(str(x) for x in error["loc"] if x != "body")
                error_msg = f"{field_path}: {error['msg']} (type: {error['type']})"
                result.add_error(error_msg)
            
            logger.warning("Pydantic validation failed",
                          errors=e.errors(),
                          data_type=type(data).__name__)
            
        except Exception as e:
            result.add_error(f"Validation error: {str(e)}")
            logger.error("Schema validation error",
                        error=str(e),
                        data_type=type(data).__name__)
        
        return result
    
    def validate_field(
        self, 
        value: Any, 
        validation_type: Union[ValidationType, str],
        params: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        """Validate a single field value."""
        result = ValidationResult(is_valid=True)
        params = params or {}
        
        # Handle None values
        if value is None:
            if params.get('required', True):
                result.add_error("Field is required")
            return result
        
        # Type-specific validation
        if isinstance(validation_type, ValidationType):
            type_name = validation_type.value
        else:
            type_name = validation_type
        
        # Built-in type validation
        if type_name in self.validation_patterns:
            pattern = self.validation_patterns[type_name]
            if not isinstance(value, str):
                result.add_error(f"Expected string for {type_name} validation")
            elif not pattern.match(str(value)):
                result.add_error(f"Invalid {type_name} format")
        
        # Custom validation parameters
        if type_name == "string":
            min_length = params.get('min_length')
            max_length = params.get('max_length')
            pattern = params.get('pattern')
            
            if isinstance(value, str):
                if min_length and len(value) < min_length:
                    result.add_error(f"String too short (min: {min_length})")
                if max_length and len(value) > max_length:
                    result.add_error(f"String too long (max: {max_length})")
                if pattern and not re.match(pattern, value):
                    result.add_error("String doesn't match required pattern")
        
        elif type_name == "number":
            min_value = params.get('min_value')
            max_value = params.get('max_value')
            
            try:
                num_value = float(value) if '.' in str(value) else int(value)
                if min_value is not None and num_value < min_value:
                    result.add_error(f"Number too small (min: {min_value})")
                if max_value is not None and num_value > max_value:
                    result.add_error(f"Number too large (max: {max_value})")
            except (ValueError, TypeError):
                result.add_error("Invalid number format")
        
        elif type_name == "array":
            if not isinstance(value, (list, tuple)):
                result.add_error("Expected array")
            else:
                max_items = params.get('max_items', 1000)
                min_items = params.get('min_items', 0)
                
                if len(value) > max_items:
                    result.add_error(f"Array too large (max: {max_items})")
                elif len(value) < min_items:
                    result.add_error(f"Array too small (min: {min_items})")
        
        elif type_name == "object":
            if not isinstance(value, dict):
                result.add_error("Expected object")
        
        return result
    
    def create_validation_schema(self, fields: List[ValidationRule]) -> Type[BaseModel]:
        """Create a Pydantic schema from validation rules."""
        field_definitions = {}
        
        for rule in fields:
            # Determine field type and constraints
            field_type = self._get_field_type(rule.rule_type)
            field_kwargs = self._get_field_constraints(rule)
            
            # Create field
            field_definitions[rule.field] = (field_type, field_kwargs)
        
        # Create dynamic model
        schema_class = type('DynamicSchema', (BaseModel,), field_definitions)
        return schema_class
    
    def _get_field_type(self, rule_type: Union[ValidationType, str]) -> type:
        """Get Python type for validation rule type."""
        if isinstance(rule_type, ValidationType):
            type_map = {
                ValidationType.EMAIL: str,
                ValidationType.URL: str,
                ValidationType.PHONE: str,
                ValidationType.UUID: str,
                ValidationType.IP_ADDRESS: str,
                ValidationType.MAC_ADDRESS: str,
                ValidationType.PASSWORD: str,
                ValidationType.USERNAME: str,
                ValidationType.JSON: str,
                ValidationType.DATE: date,
                ValidationType.DATETIME: datetime,
            }
            return type_map.get(rule_type, str)
        
        type_map = {
            "string": str,
            "number": (int, float),
            "integer": int,
            "float": float,
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        
        return type_map.get(rule_type, Any)
    
    def _get_field_constraints(self, rule: ValidationRule) -> dict:
        """Get field constraints for Pydantic."""
        constraints = {}
        
        # Required field
        if not rule.required:
            constraints["default"] = None
        
        # Type-specific constraints
        if isinstance(rule.rule_type, ValidationType):
            if rule.rule_type == ValidationType.EMAIL:
                constraints["regex"] = self.validation_patterns["email"]
            elif rule.rule_type == ValidationType.USERNAME:
                constraints["regex"] = self.validation_patterns["username"]
            elif rule.rule_type == ValidationType.PASSWORD:
                constraints["regex"] = self.validation_patterns["password"]
        
        # Custom constraints from params
        if "min_length" in rule.params:
            constraints["min_length"] = rule.params["min_length"]
        if "max_length" in rule.params:
            constraints["max_length"] = rule.params["max_length"]
        if "min_value" in rule.params:
            constraints["ge"] = rule.params["min_value"]
        if "max_value" in rule.params:
            constraints["le"] = rule.params["max_value"]
        if "pattern" in rule.params:
            constraints["regex"] = re.compile(rule.params["pattern"])
        
        return constraints
    
    def _apply_version_compatibility(self, data: Any, version: SchemaVersion) -> Any:
        """Apply version-specific compatibility transformations."""
        # This would implement schema evolution logic
        # For example, mapping old field names to new ones, etc.
        if version == SchemaVersion.V1:
            # Apply V1 compatibility transformations
            if isinstance(data, dict):
                # Example: map 'user_id' to 'userId'
                if 'user_id' in data and 'userId' not in data:
                    data['userId'] = data.pop('user_id')
        
        return data
    
    def _apply_custom_validators(self, data: Any, schema: Type[BaseModel]) -> List[str]:
        """Apply custom validators."""
        errors = []
        
        # Check for registered custom validators
        for field_name, field_info in schema.__fields__.items():
            if hasattr(field_info.type_, 'validate_custom'):
                try:
                    field_info.type_.validate_custom(data.get(field_name))
                except Exception as e:
                    errors.append(f"Custom validation failed for {field_name}: {str(e)}")
        
        return errors
    
    def _validate_cross_fields(self, validated_data: BaseModel, schema: Type[BaseModel]) -> List[str]:
        """Validate cross-field relationships."""
        errors = []
        
        # Look for root validators in the schema
        if hasattr(schema, 'root_validator'):
            try:
                # This would call the schema's root validators
                # Implementation depends on how root validators are defined
                pass
            except Exception as e:
                errors.append(f"Cross-field validation error: {str(e)}")
        
        return errors
    
    def add_custom_validator(self, name: str, validator_func: Callable):
        """Add a custom validator function."""
        self.custom_validators[name] = validator_func
        logger.info("Custom validator added", name=name)
    
    def remove_custom_validator(self, name: str):
        """Remove a custom validator function."""
        if name in self.custom_validators:
            del self.custom_validators[name]
            logger.info("Custom validator removed", name=name)
    
    def normalize_data(self, data: Any, rules: List[ValidationRule]) -> Dict[str, Any]:
        """Normalize data according to validation rules."""
        normalized = {}
        
        for rule in rules:
            value = data.get(rule.field)
            
            if value is not None:
                # Apply normalization based on type
                if isinstance(rule.rule_type, ValidationType):
                    if rule.rule_type == ValidationType.EMAIL:
                        normalized[rule.field] = str(value).lower().strip()
                    elif rule.rule_type == ValidationType.USERNAME:
                        normalized[rule.field] = str(value).strip().lower()
                    else:
                        normalized[rule.field] = value
                else:
                    normalized[rule.field] = value
            elif not rule.required:
                normalized[rule.field] = None
        
        return normalized
    
    def validate_schema_compatibility(
        self, 
        data: Any, 
        target_schema: Type[BaseModel],
        current_schema: Type[BaseModel]
    ) -> ValidationResult:
        """Validate compatibility between different schema versions."""
        result = ValidationResult(is_valid=True)
        
        # Check if all required fields in target schema are present
        target_fields = set(target_schema.__fields__.keys())
        data_fields = set(data.keys()) if isinstance(data, dict) else set()
        
        missing_fields = target_fields - data_fields
        if missing_fields:
            result.add_error(f"Missing required fields: {', '.join(missing_fields)}")
        
        # Check if extra fields are acceptable
        extra_fields = data_fields - target_fields
        if extra_fields:
            # This might be acceptable depending on schema evolution strategy
            result.add_warning(f"Extra fields present: {', '.join(extra_fields)}")
        
        return result

# Utility functions for common validation patterns
def validate_email(email: str) -> bool:
    """Validate email address."""
    pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    return bool(pattern.match(email))

def validate_url(url: str) -> bool:
    """Validate URL."""
    pattern = re.compile(r'^https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.]*))?(?:#(?:\w)*)?)?$')
    return bool(pattern.match(url))

def validate_phone(phone: str) -> bool:
    """Validate phone number."""
    pattern = re.compile(r'^\+?1?-?\.?\s?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$')
    return bool(pattern.match(phone))

def validate_password_strength(password: str) -> Dict[str, bool]:
    """Validate password strength."""
    return {
        "length_ok": len(password) >= 8,
        "has_lowercase": bool(re.search(r'[a-z]', password)),
        "has_uppercase": bool(re.search(r'[A-Z]', password)),
        "has_digit": bool(re.search(r'\d', password)),
        "has_special": bool(re.search(r'[@$!%*?&]', password)),
        "no_common_patterns": not any(pattern in password.lower() for pattern in ['password', '1234', 'qwerty'])
    }

# Predefined validation schemas
USER_REGISTRATION_SCHEMA = [
    ValidationRule("username", ValidationType.USERNAME, {"min_length": 3, "max_length": 50}),
    ValidationRule("email", ValidationType.EMAIL, required=True),
    ValidationRule("password", ValidationType.PASSWORD, required=True),
    ValidationRule("confirm_password", "string", {"min_length": 8}, required=True),
]

USER_LOGIN_SCHEMA = [
    ValidationRule("username", "string", {"min_length": 1, "max_length": 100}),
    ValidationRule("password", "string", {"min_length": 1}, required=True),
]

CHAT_MESSAGE_SCHEMA = [
    ValidationRule("message", "string", {"min_length": 1, "max_length": 2000}, required=True),
    ValidationRule("session_id", ValidationType.UUID, required=False),
    ValidationRule("metadata", "object", required=False),
]

FILE_UPLOAD_SCHEMA = [
    ValidationRule("filename", "string", {"min_length": 1, "max_length": 255}, required=True),
    ValidationRule("content_type", "string", {"min_length": 1}, required=True),
    ValidationRule("size", "integer", {"min_value": 0, "max_value": 50 * 1024 * 1024}, required=True),
]