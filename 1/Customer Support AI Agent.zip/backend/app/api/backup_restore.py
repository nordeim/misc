"""
Backup and Restore API endpoints.

Provides REST API endpoints for backup and restore operations including:
- Database backup and restore
- Configuration management
- File system operations
- Scheduling and automation
- Monitoring and reporting
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks, Depends, Query, Body
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging
import asyncio
import json

from app.utils.backup_restore_service import (
    BackupRestoreService,
    BackupSchedule,
    BackupMetadata,
    RestoreResult,
    backup_service
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/backup-restore", tags=["backup-restore"])

# Pydantic models for API requests/responses


class DatabaseBackupRequest(BaseModel):
    backup_type: str = Field(default="full", description="Type of backup (full, incremental)")
    compress: bool = Field(default=True, description="Whether to compress the backup")
    encrypt: bool = Field(default=False, description="Whether to encrypt the backup")
    backup_name: Optional[str] = Field(default=None, description="Custom backup name")


class ConfigurationBackupRequest(BaseModel):
    compress: bool = Field(default=True, description="Whether to compress the backup")
    encrypt: bool = Field(default=False, description="Whether to encrypt the backup")
    backup_name: Optional[str] = Field(default=None, description="Custom backup name")


class FileSystemBackupRequest(BaseModel):
    compress: bool = Field(default=True, description="Whether to compress the backup")
    encrypt: bool = Field(default=False, description="Whether to encrypt the backup")
    backup_name: Optional[str] = Field(default=None, description="Custom backup name")
    include_patterns: Optional[List[str]] = Field(default=None, description="Patterns to include")
    exclude_patterns: Optional[List[str]] = Field(default=None, description="Patterns to exclude")


class FullSystemBackupRequest(BaseModel):
    compress: bool = Field(default=True, description="Whether to compress the backup")
    encrypt: bool = Field(default=False, description="Whether to encrypt the backup")
    backup_name: Optional[str] = Field(default=None, description="Custom backup name")
    include_configs: bool = Field(default=True, description="Include configuration backup")
    include_files: bool = Field(default=True, description="Include file system backup")


class DatabaseRestoreRequest(BaseModel):
    target_location: Optional[str] = Field(default=None, description="Target database location")
    verify_checksum: bool = Field(default=True, description="Verify backup checksum before restore")


class ConfigurationRestoreRequest(BaseModel):
    verify_checksum: bool = Field(default=True, description="Verify backup checksum before restore")


class FileSystemRestoreRequest(BaseModel):
    target_location: Optional[str] = Field(default=None, description="Target location for restore")
    verify_checksum: bool = Field(default=True, description="Verify backup checksum before restore")
    selective_restore: Optional[List[str]] = Field(default=None, description="Specific files/directories to restore")


class ScheduleBackupRequest(BaseModel):
    name: str = Field(description="Schedule name")
    backup_type: str = Field(description="Type of backup to schedule")
    schedule_expression: str = Field(description="Schedule expression (daily, weekly, cron)")
    retention_days: int = Field(default=30, description="Retention period in days")
    enabled: bool = Field(default=True, description="Whether schedule is enabled")
    compression: bool = Field(default=True, description="Use compression")
    encryption: bool = Field(default=False, description="Use encryption")
    notification_email: Optional[str] = Field(default=None, description="Notification email")


class PointInTimeBackupRequest(BaseModel):
    target_timestamp: datetime = Field(description="Target point in time")
    backup_name: Optional[str] = Field(default=None, description="Custom backup name")


class DisasterRecoveryRequest(BaseModel):
    backup_ids: List[str] = Field(description="List of backup IDs to restore")
    validate_before_restore: bool = Field(default=True, description="Validate backups before restore")
    create_recovery_snapshot: bool = Field(default=True, description="Create snapshot before restore")


class BackupResponse(BaseModel):
    success: bool
    backup_id: str
    message: str
    metadata: Optional[Dict[str, Any]] = None


class RestoreResponse(BaseModel):
    success: bool
    restore_id: str
    message: str
    result: Optional[Dict[str, Any]] = None


class BackupListResponse(BaseModel):
    success: bool
    backups: List[Dict[str, Any]]
    total: int


class HealthReportResponse(BaseModel):
    success: bool
    health_report: Dict[str, Any]


@router.post("/backup/database", response_model=BackupResponse)
async def create_database_backup(
    request: DatabaseBackupRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Create a database backup.
    """
    try:
        backup_id = await backup_service.create_database_backup(
            backup_type=request.backup_type,
            compress=request.compress,
            encrypt=request.encrypt,
            backup_name=request.backup_name
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        return BackupResponse(
            success=True,
            backup_id=backup_id,
            message="Database backup created successfully",
            metadata={
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "database_type": metadata.database_type,
                "total_size": metadata.total_size,
                "file_count": metadata.file_count,
                "status": metadata.status
            }
        )
    
    except Exception as e:
        logger.error(f"Database backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/backup/configuration", response_model=BackupResponse)
async def create_configuration_backup(
    request: ConfigurationBackupRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Create a configuration backup.
    """
    try:
        backup_id = await backup_service.create_configuration_backup(
            backup_name=request.backup_name,
            compress=request.compress,
            encrypt=request.encrypt
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        return BackupResponse(
            success=True,
            backup_id=backup_id,
            message="Configuration backup created successfully",
            metadata={
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "total_size": metadata.total_size,
                "file_count": metadata.file_count,
                "status": metadata.status
            }
        )
    
    except Exception as e:
        logger.error(f"Configuration backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/backup/filesystem", response_model=BackupResponse)
async def create_filesystem_backup(
    request: FileSystemBackupRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Create a file system backup.
    """
    try:
        backup_id = await backup_service.create_file_system_backup(
            backup_name=request.backup_name,
            compress=request.compress,
            encrypt=request.encrypt,
            include_patterns=request.include_patterns,
            exclude_patterns=request.exclude_patterns
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        return BackupResponse(
            success=True,
            backup_id=backup_id,
            message="File system backup created successfully",
            metadata={
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "total_size": metadata.total_size,
                "file_count": metadata.file_count,
                "status": metadata.status
            }
        )
    
    except Exception as e:
        logger.error(f"File system backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/backup/full-system", response_model=BackupResponse)
async def create_full_system_backup(
    request: FullSystemBackupRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Create a complete system backup (database + configuration + file system).
    """
    try:
        backup_id = await backup_service.create_full_system_backup(
            backup_name=request.backup_name,
            compress=request.compress,
            encrypt=request.encrypt,
            include_configs=request.include_configs,
            include_files=request.include_files
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        return BackupResponse(
            success=True,
            backup_id=backup_id,
            message="Full system backup created successfully",
            metadata={
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "total_size": metadata.total_size,
                "file_count": metadata.file_count,
                "status": metadata.status
            }
        )
    
    except Exception as e:
        logger.error(f"Full system backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/backup/point-in-time", response_model=BackupResponse)
async def create_point_in_time_backup(
    request: PointInTimeBackupRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Create a point-in-time backup.
    """
    try:
        backup_id = await backup_service.create_point_in_time_backup(
            target_timestamp=request.target_timestamp,
            backup_name=request.backup_name
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        return BackupResponse(
            success=True,
            backup_id=backup_id,
            message="Point-in-time backup created successfully",
            metadata={
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "target_timestamp": request.target_timestamp.isoformat(),
                "total_size": metadata.total_size,
                "status": metadata.status
            }
        )
    
    except Exception as e:
        logger.error(f"Point-in-time backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restore/database/{backup_id}", response_model=RestoreResponse)
async def restore_database(
    backup_id: str,
    request: DatabaseRestoreRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Restore database from backup.
    """
    try:
        result = await backup_service.restore_database(
            backup_id=backup_id,
            target_location=request.target_location,
            verify_checksum=request.verify_checksum
        )
        
        return RestoreResponse(
            success=True,
            restore_id=result.restore_id,
            message="Database restore completed successfully",
            result={
                "source_backup": result.source_backup,
                "target_location": result.target_location,
                "restored_files": result.restored_files,
                "restored_size": result.restored_size,
                "warnings": result.warnings,
                "errors": result.errors
            }
        )
    
    except Exception as e:
        logger.error(f"Database restore API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restore/configuration/{backup_id}", response_model=RestoreResponse)
async def restore_configuration(
    backup_id: str,
    request: ConfigurationRestoreRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Restore configuration from backup.
    """
    try:
        result = await backup_service.restore_configuration(
            backup_id=backup_id,
            verify_checksum=request.verify_checksum
        )
        
        return RestoreResponse(
            success=True,
            restore_id=result.restore_id,
            message="Configuration restore completed successfully",
            result={
                "source_backup": result.source_backup,
                "restored_files": result.restored_files,
                "restored_size": result.restored_size,
                "warnings": result.warnings,
                "errors": result.errors
            }
        )
    
    except Exception as e:
        logger.error(f"Configuration restore API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restore/filesystem/{backup_id}", response_model=RestoreResponse)
async def restore_filesystem(
    backup_id: str,
    request: FileSystemRestoreRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Restore file system from backup.
    """
    try:
        result = await backup_service.restore_file_system(
            backup_id=backup_id,
            target_location=request.target_location,
            verify_checksum=request.verify_checksum,
            selective_restore=request.selective_restore
        )
        
        return RestoreResponse(
            success=True,
            restore_id=result.restore_id,
            message="File system restore completed successfully",
            result={
                "source_backup": result.source_backup,
                "target_location": result.target_location,
                "restored_files": result.restored_files,
                "restored_size": result.restored_size,
                "warnings": result.warnings,
                "errors": result.errors
            }
        )
    
    except Exception as e:
        logger.error(f"File system restore API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restore/disaster-recovery", response_model=Dict[str, Any])
async def disaster_recovery_restore(
    request: DisasterRecoveryRequest = Body(...),
    background_tasks: BackgroundTasks = None
):
    """
    Perform disaster recovery restore from multiple backups.
    """
    try:
        results = await backup_service.disaster_recovery_restore(
            backup_ids=request.backup_ids,
            validate_before_restore=request.validate_before_restore,
            create_recovery_snapshot=request.create_recovery_snapshot
        )
        
        # Convert results to dictionary
        results_dict = {}
        for backup_id, result in results.items():
            results_dict[backup_id] = {
                "restore_id": result.restore_id,
                "status": result.status,
                "restored_files": result.restored_files,
                "restored_size": result.restored_size,
                "warnings": result.warnings,
                "errors": result.errors
            }
        
        return {
            "success": True,
            "message": "Disaster recovery restore completed",
            "results": results_dict,
            "total_operations": len(results),
            "successful_operations": sum(1 for r in results.values() if r.status == "completed")
        }
    
    except Exception as e:
        logger.error(f"Disaster recovery API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/backups", response_model=BackupListResponse)
async def list_backups(
    backup_type: Optional[str] = Query(default=None, description="Filter by backup type"),
    limit: int = Query(default=50, description="Maximum number of backups to return"),
    offset: int = Query(default=0, description="Offset for pagination")
):
    """
    List all backups with optional filtering and pagination.
    """
    try:
        backups = backup_service.get_backup_list(backup_type=backup_type)
        
        # Apply pagination
        total = len(backups)
        paginated_backups = backups[offset:offset + limit]
        
        # Convert to dictionaries
        backups_dict = []
        for backup in paginated_backups:
            backups_dict.append({
                "backup_id": backup.backup_id,
                "backup_type": backup.backup_type,
                "timestamp": backup.timestamp.isoformat(),
                "database_type": backup.database_type,
                "compression": backup.compression,
                "encrypted": backup.encrypted,
                "total_size": backup.total_size,
                "file_count": backup.file_count,
                "status": backup.status,
                "error_message": backup.error_message
            })
        
        return BackupListResponse(
            success=True,
            backups=backups_dict,
            total=total
        )
    
    except Exception as e:
        logger.error(f"List backups API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/backups/{backup_id}", response_model=Dict[str, Any])
async def get_backup_info(backup_id: str):
    """
    Get detailed information about a specific backup.
    """
    try:
        metadata = backup_service.get_backup_info(backup_id)
        
        if not metadata:
            raise HTTPException(status_code=404, detail=f"Backup not found: {backup_id}")
        
        return {
            "success": True,
            "backup": {
                "backup_id": metadata.backup_id,
                "backup_type": metadata.backup_type,
                "timestamp": metadata.timestamp.isoformat(),
                "database_type": metadata.database_type,
                "compression": metadata.compression,
                "encrypted": metadata.encrypted,
                "source_paths": metadata.source_paths,
                "total_size": metadata.total_size,
                "file_count": metadata.file_count,
                "checksum": metadata.checksum,
                "status": metadata.status,
                "error_message": metadata.error_message
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get backup info API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/backups/{backup_id}/verify")
async def verify_backup(backup_id: str):
    """
    Verify the integrity of a backup.
    """
    try:
        is_valid = await backup_service.verify_backup(backup_id)
        
        return {
            "success": True,
            "backup_id": backup_id,
            "is_valid": is_valid,
            "message": "Backup verification completed"
        }
    
    except Exception as e:
        logger.error(f"Verify backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/schedule", response_model=Dict[str, Any])
async def schedule_backup(request: ScheduleBackupRequest = Body(...)):
    """
    Schedule an automated backup.
    """
    try:
        schedule_config = BackupSchedule(
            name=request.name,
            backup_type=request.backup_type,
            schedule_expression=request.schedule_expression,
            retention_days=request.retention_days,
            enabled=request.enabled,
            compression=request.compression,
            encryption=request.encryption,
            notification_email=request.notification_email
        )
        
        success = await backup_service.schedule_backup(schedule_config)
        
        return {
            "success": success,
            "message": "Backup scheduled successfully" if success else "Failed to schedule backup"
        }
    
    except Exception as e:
        logger.error(f"Schedule backup API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cleanup", response_model=Dict[str, Any])
async def cleanup_old_backups(
    retention_days: int = Query(default=30, description="Retention period in days")
):
    """
    Clean up old backups based on retention policy.
    """
    try:
        cleaned_up = backup_service.cleanup_old_backups(retention_days=retention_days)
        
        return {
            "success": True,
            "message": f"Cleanup completed: {cleaned_up} backups removed",
            "cleaned_up_count": cleaned_up
        }
    
    except Exception as e:
        logger.error(f"Cleanup backups API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/report/export", response_model=FileResponse)
async def export_backup_report():
    """
    Export backup report as CSV file.
    """
    try:
        report_path = backup_service.export_backup_report()
        
        return FileResponse(
            path=report_path,
            media_type="text/csv",
            filename=f"backup_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        )
    
    except Exception as e:
        logger.error(f"Export report API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health", response_model=HealthReportResponse)
async def get_system_health():
    """
    Get comprehensive system health report for backup/restore capabilities.
    """
    try:
        health_report = backup_service.get_system_health_report()
        
        return HealthReportResponse(
            success=True,
            health_report=health_report
        )
    
    except Exception as e:
        logger.error(f"Health report API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/statistics")
async def get_backup_statistics():
    """
    Get backup and restore statistics.
    """
    try:
        # Calculate statistics
        all_backups = backup_service.get_backup_list()
        
        stats = {
            "total_backups": len(all_backups),
            "completed_backups": len([b for b in all_backups if b.status == "completed"]),
            "failed_backups": len([b for b in all_backups if b.status == "failed"]),
            "backup_types": {},
            "recent_backups_24h": len([
                b for b in all_backups 
                if b.timestamp > datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            ]),
            "total_backup_size": sum(b.total_size for b in all_backups if b.status == "completed"),
            "largest_backup": max((b.total_size for b in all_backups if b.status == "completed"), default=0),
            "average_backup_size": 0
        }
        
        # Calculate backup type distribution
        for backup in all_backups:
            backup_type = backup.backup_type
            stats["backup_types"][backup_type] = stats["backup_types"].get(backup_type, 0) + 1
        
        # Calculate average backup size
        completed_backups = [b for b in all_backups if b.status == "completed"]
        if completed_backups:
            stats["average_backup_size"] = stats["total_backup_size"] / len(completed_backups)
        
        return {
            "success": True,
            "statistics": stats
        }
    
    except Exception as e:
        logger.error(f"Statistics API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/scheduler/start")
async def start_scheduler():
    """
    Start the backup scheduler.
    """
    try:
        backup_service.start_scheduler()
        return {
            "success": True,
            "message": "Backup scheduler started"
        }
    except Exception as e:
        logger.error(f"Start scheduler API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/scheduler/stop")
async def stop_scheduler():
    """
    Stop the backup scheduler.
    """
    try:
        backup_service.stop_scheduler()
        return {
            "success": True,
            "message": "Backup scheduler stopped"
        }
    except Exception as e:
        logger.error(f"Stop scheduler API error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
