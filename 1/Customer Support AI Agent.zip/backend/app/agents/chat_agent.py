"""
Customer Support Agent Orchestrator System.

This is the core of the application - a custom-built agent orchestrator that manages
the logic flow for processing user messages and generating intelligent responses.
The system includes conversation flow management, tool selection, metrics tracking,
and lifecycle management.
"""

import logging
import asyncio
import time
import uuid
from typing import List, Dict, Any, Optional, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from contextlib import asynccontextmanager
import json

from app.config import settings
from app.tools.rag_tool import RAGTool
from app.tools.memory_tool import MemoryTool
from app.tools.attachment_tool import AttachmentTool
from app.tools.escalation_tool import EscalationTool

logger = logging.getLogger(__name__)

class AgentState(str, Enum):
    """Agent lifecycle states."""
    IDLE = "idle"
    PROCESSING = "processing"
    WAITING = "waiting"
    ERROR = "error"
    TERMINATED = "terminated"


class EscalationType(str, Enum):
    """Types of escalation."""
    NONE = "none"
    SOFT = "soft"
    HARD = "hard"
    IMMEDIATE = "immediate"


class ToolExecutionStatus(str, Enum):
    """Tool execution status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class AgentContext:
    """Enhanced context for the agent conversation."""
    session_id: str
    user_id: str
    message_history: List[Dict[str, Any]] = field(default_factory=list)
    current_file_attachments: List[str] = field(default_factory=list)
    escalation_level: int = 0
    agent_state: AgentState = AgentState.IDLE
    current_step: str = ""
    context_data: Dict[str, Any] = field(default_factory=dict)
    tools_used: List[str] = field(default_factory=list)
    escalation_type: EscalationType = EscalationType.NONE
    user_intent: Optional[str] = None
    conversation_turn: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_activity: datetime = field(default_factory=datetime.utcnow)
    
    def update_activity(self):
        """Update last activity timestamp."""
        self.last_activity = datetime.utcnow()
    
    def add_message(self, message: Dict[str, Any]):
        """Add message to history."""
        self.message_history.append(message)
        self.conversation_turn += 1
        self.update_activity()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary."""
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "message_history": self.message_history,
            "current_file_attachments": self.current_file_attachments,
            "escalation_level": self.escalation_level,
            "agent_state": self.agent_state.value,
            "current_step": self.current_step,
            "context_data": self.context_data,
            "tools_used": self.tools_used,
            "escalation_type": self.escalation_type.value,
            "user_intent": self.user_intent,
            "conversation_turn": self.conversation_turn,
            "created_at": self.created_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
        }


@dataclass
class AgentMetrics:
    """Agent performance and usage metrics."""
    total_conversations: int = 0
    total_messages_processed: int = 0
    total_escalations: int = 0
    total_tools_executed: int = 0
    average_response_time: float = 0.0
    total_processing_time: float = 0.0
    successful_responses: int = 0
    failed_responses: int = 0
    escalation_rate: float = 0.0
    tool_usage_stats: Dict[str, int] = field(default_factory=dict)
    conversation_duration_stats: Dict[str, float] = field(default_factory=dict)
    
    def update_response_metrics(self, processing_time: float, success: bool, escalated: bool):
        """Update metrics after processing a response."""
        self.total_messages_processed += 1
        self.total_processing_time += processing_time
        self.average_response_time = self.total_processing_time / self.total_messages_processed
        
        if success:
            self.successful_responses += 1
        else:
            self.failed_responses += 1
            
        if escalated:
            self.total_escalations += 1
            
        # Update escalation rate
        if self.total_messages_processed > 0:
            self.escalation_rate = (self.total_escalations / self.total_messages_processed) * 100
    
    def update_tool_usage(self, tool_name: str, success: bool = True):
        """Update tool usage statistics."""
        self.total_tools_executed += 1
        if tool_name not in self.tool_usage_stats:
            self.tool_usage_stats[tool_name] = 0
        self.tool_usage_stats[tool_name] += 1
    
    def get_success_rate(self) -> float:
        """Calculate success rate percentage."""
        if self.total_messages_processed == 0:
            return 0.0
        return (self.successful_responses / self.total_messages_processed) * 100


@dataclass
class AgentToolResult:
    """Result from tool execution."""
    tool_name: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    status: ToolExecutionStatus = ToolExecutionStatus.COMPLETED
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert tool result to dictionary."""
        return {
            "tool_name": self.tool_name,
            "success": self.success,
            "result": self.result,
            "error": self.error,
            "execution_time": self.execution_time,
            "status": self.status.value,
        }


@dataclass
class AgentResponse:
    """Enhanced structured response from the agent."""
    content: str
    attachments_processed: List[str] = field(default_factory=list)
    escalation_triggered: bool = False
    escalation_type: EscalationType = EscalationType.NONE
    memory_updated: bool = False
    sources: List[Dict[str, Any]] = field(default_factory=list)
    confidence_score: float = 0.0
    processing_time: float = 0.0
    tool_results: List[AgentToolResult] = field(default_factory=list)
    context_updates: Dict[str, Any] = field(default_factory=dict)
    agent_metrics: Optional[AgentMetrics] = None
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary."""
        return {
            "content": self.content,
            "attachments_processed": self.attachments_processed,
            "escalation_triggered": self.escalation_triggered,
            "escalation_type": self.escalation_type.value,
            "memory_updated": self.memory_updated,
            "sources": self.sources,
            "confidence_score": self.confidence_score,
            "processing_time": self.processing_time,
            "tool_results": [tr.to_dict() for tr in self.tool_results],
            "context_updates": self.context_updates,
            "agent_metrics": self.agent_metrics.__dict__ if self.agent_metrics else None,
            "error": self.error,
            "warnings": self.warnings,
        }


@dataclass
class AgentConfiguration:
    """Configuration for agent behavior and performance."""
    max_history_length: int = 50
    max_processing_time: float = 30.0
    max_response_length: int = 4000
    confidence_threshold: float = 0.7
    escalation_threshold: float = 0.8
    enable_caching: bool = True
    cache_ttl: int = 3600
    enable_metrics: bool = True
    enable_tool_selection: bool = True
    tool_timeout: float = 10.0
    parallel_tool_execution: bool = False
    max_concurrent_tools: int = 3
    memory_optimization: bool = True
    response_streaming: bool = False
    auto_retry: bool = True
    max_retries: int = 3
    retry_delay: float = 1.0
    enable_conversation_cleanup: bool = True
    conversation_timeout_hours: int = 24
    enable_performance_monitoring: bool = True

class CustomerSupportAgent:
    """
    Enhanced Customer Support Agent Orchestrator.
    
    This agent implements sophisticated conversation flow management, tool orchestration,
    metrics tracking, and lifecycle management for customer support interactions.
    """
    
    def __init__(self, config: Optional[AgentConfiguration] = None):
        """Initialize the agent with tools and configuration."""
        self.config = config or AgentConfiguration()
        self.agent_id = str(uuid.uuid4())
        self.state = AgentState.IDLE
        self.metrics = AgentMetrics()
        self._active_sessions: Dict[str, AgentContext] = {}
        self._tool_registry = {}
        self._response_cache = {}
        self._shutdown_event = asyncio.Event()
        
        # Initialize tools with database session
        self.rag_tool = RAGTool()
        self.memory_tool = MemoryTool()
        self.attachment_tool = AttachmentTool()
        # Escalation tool will be initialized with database session when available
        self.escalation_tool = None
        
        # Register tools
        self._register_tools()
        
        logger.info(f"Customer Support Agent initialized with ID: {self.agent_id}")
    
    def initialize_escalation_tool(self, db_session: Session):
        """Initialize escalation tool with database session."""
        if not self.escalation_tool:
            self.escalation_tool = EscalationTool(db_session=db_session)
            self._tool_registry["escalation"] = self.escalation_tool
            
            # Initialize default policies and queues
            asyncio.create_task(self.escalation_tool.initialize_default_policies_and_queues())
            
            logger.info(f"Escalation tool initialized for agent {self.agent_id}")
        else:
            logger.warning("Escalation tool already initialized")
    
    def _register_tools(self):
        """Register available tools for the agent."""
        self._tool_registry = {
            "rag": self.rag_tool,
            "memory": self.memory_tool,
            "attachment": self.attachment_tool,
            "escalation": self.escalation_tool,
        }
    
    async def start(self):
        """Start the agent and initialize necessary components."""
        try:
            self.state = AgentState.PROCESSING
            logger.info(f"Starting Customer Support Agent {self.agent_id}")
            
            # Initialize tools
            await self._initialize_tools()
            
            # Start background tasks
            await asyncio.gather(
                self._start_metrics_collector(),
                self._start_conversation_cleanup(),
                self._start_performance_monitor()
            )
            
            logger.info(f"Agent {self.agent_id} started successfully")
            
        except Exception as e:
            logger.error(f"Failed to start agent {self.agent_id}: {e}")
            self.state = AgentState.ERROR
            raise
    
    async def stop(self):
        """Stop the agent and cleanup resources."""
        logger.info(f"Stopping Customer Support Agent {self.agent_id}")
        
        self.state = AgentState.TERMINATED
        self._shutdown_event.set()
        
        # Cleanup active sessions
        for session_id in list(self._active_sessions.keys()):
            await self.end_session(session_id)
        
        logger.info(f"Agent {self.agent_id} stopped successfully")
    
    async def create_session(
        self, 
        session_id: str, 
        user_id: str, 
        metadata: Optional[Dict[str, Any]] = None
    ) -> AgentContext:
        """Create a new conversation session."""
        context = AgentContext(
            session_id=session_id,
            user_id=user_id,
            context_data=metadata or {},
            agent_state=AgentState.IDLE
        )
        
        self._active_sessions[session_id] = context
        
        # Initialize session in memory
        await self.memory_tool.store_memory(
            session_id=session_id,
            key="session_start",
            value={
                "user_id": user_id,
                "agent_id": self.agent_id,
                "created_at": datetime.utcnow().isoformat(),
                "metadata": metadata
            },
            memory_type="session"
        )
        
        logger.info(f"Created session {session_id} for user {user_id}")
        return context
    
    async def end_session(self, session_id: str):
        """End a conversation session and cleanup resources."""
        if session_id in self._active_sessions:
            context = self._active_sessions[session_id]
            context.agent_state = AgentState.TERMINATED
            
            # Store session end timestamp
            await self.memory_tool.store_memory(
                session_id=session_id,
                key="session_end",
                value={
                    "ended_at": datetime.utcnow().isoformat(),
                    "conversation_turns": context.conversation_turn,
                    "tools_used": context.tools_used,
                    "escalation_level": context.escalation_level
                },
                memory_type="session"
            )
            
            del self._active_sessions[session_id]
            logger.info(f"Ended session {session_id}")
    
    def get_session(self, session_id: str) -> Optional[AgentContext]:
        """Get an active session context."""
        return self._active_sessions.get(session_id)
    
    async def process_message(
        self, 
        message: str, 
        context: AgentContext,
        enable_streaming: bool = False
    ) -> Union[AgentResponse, AsyncIterator[AgentResponse]]:
        """
        Process a user message through the enhanced agent orchestration pipeline.
        
        Args:
            message: The user's message content
            context: Current conversation context
            enable_streaming: Enable streaming response generation
            
        Returns:
            AgentResponse or async iterator of AgentResponse parts
        """
        start_time = time.time()
        context.agent_state = AgentState.PROCESSING
        context.current_step = "processing_message"
        
        try:
            # Add message to context
            context.add_message({
                "content": message,
                "timestamp": datetime.utcnow().isoformat(),
                "agent_id": self.agent_id
            })
            
            logger.info(f"Processing message for session {context.session_id}")
            
            if enable_streaming:
                return self._process_message_streaming(message, context, start_time)
            else:
                return await self._process_message_sync(message, context, start_time)
                
        except Exception as e:
            logger.error(f"Error processing message for session {context.session_id}: {e}")
            context.agent_state = AgentState.ERROR
            
            return AgentResponse(
                content="I apologize, but I'm having trouble processing your request right now. Please try again or contact support if the issue persists.",
                attachments_processed=[],
                escalation_triggered=False,
                escalation_type=EscalationType.NONE,
                memory_updated=False,
                sources=[],
                confidence_score=0.0,
                processing_time=time.time() - start_time,
                error=str(e)
            )
        finally:
            context.agent_state = AgentState.IDLE
    
    async def _process_message_sync(
        self, 
        message: str, 
        context: AgentContext, 
        start_time: float
    ) -> AgentResponse:
        """Process message synchronously."""
        tool_results = []
        
        try:
            # Step 1: Select tools to execute based on context
            selected_tools = await self._select_tools(message, context)
            context.tools_used.extend(selected_tools)
            
            # Step 2: Execute tools in parallel or sequentially
            if self.config.parallel_tool_execution:
                tool_results = await self._execute_tools_parallel(selected_tools, message, context)
            else:
                tool_results = await self._execute_tools_sequential(selected_tools, message, context)
            
            # Step 3: Analyze results and make escalation decision
            escalation_type = await self._analyze_for_escalation(tool_results, message, context)
            
            # Step 4: Generate response using tool results
            response_content = await self._generate_response(
                message=message,
                context=context,
                tool_results=tool_results,
                escalation_type=escalation_type
            )
            
            # Step 5: Update memory with conversation data
            memory_updated = await self._update_memory(context, tool_results)
            
            # Step 6: Update context with new information
            context_updates = await self._update_context(context, tool_results)
            
            processing_time = time.time() - start_time
            
            # Update metrics
            success = escalation_type == EscalationType.NONE
            self.metrics.update_response_metrics(processing_time, success, escalation_type != EscalationType.NONE)
            
            for tool_result in tool_results:
                if tool_result.success:
                    self.metrics.update_tool_usage(tool_result.tool_name)
            
            # Create response
            response = AgentResponse(
                content=response_content,
                attachments_processed=context.current_file_attachments,
                escalation_triggered=escalation_type != EscalationType.NONE,
                escalation_type=escalation_type,
                memory_updated=memory_updated,
                sources=self._extract_sources(tool_results),
                confidence_score=self._calculate_confidence_score(tool_results),
                processing_time=processing_time,
                tool_results=tool_results,
                context_updates=context_updates,
                agent_metrics=self.metrics if self.config.enable_metrics else None
            )
            
            context.agent_state = AgentState.IDLE
            return response
            
        except Exception as e:
            logger.error(f"Error in message processing: {e}")
            raise
    
    async def _process_message_streaming(
        self, 
        message: str, 
        context: AgentContext, 
        start_time: float
    ) -> AsyncIterator[AgentResponse]:
        """Process message with streaming response generation."""
        # This would implement streaming response generation
        # For now, fall back to synchronous processing
        response = await self._process_message_sync(message, context, start_time)
        yield response
    
    async def _select_tools(self, message: str, context: AgentContext) -> List[str]:
        """Select which tools to execute based on message content and context."""
        selected_tools = []
        
        # Always include memory tool for context
        selected_tools.append("memory")
        
        # RAG tool for knowledge retrieval
        if context.escalation_level == 0:  # Only if not already escalated
            selected_tools.append("rag")
        
        # Attachment tool if there are file attachments
        if context.current_file_attachments:
            selected_tools.append("attachment")
        
        # Escalation tool always included for escalation detection
        selected_tools.append("escalation")
        
        logger.debug(f"Selected tools for session {context.session_id}: {selected_tools}")
        return selected_tools
    
    async def _execute_tools_sequential(
        self, 
        tools: List[str], 
        message: str, 
        context: AgentContext
    ) -> List[AgentToolResult]:
        """Execute tools sequentially."""
        results = []
        
        for tool_name in tools:
            result = await self._execute_tool(tool_name, message, context)
            results.append(result)
            
            # Check if escalation should happen immediately
            if (tool_name == "escalation" and 
                isinstance(result.result, dict) and 
                result.result.get("immediate_escalation")):
                logger.info(f"Immediate escalation triggered for session {context.session_id}")
                break
        
        return results
    
    async def _execute_tools_parallel(
        self, 
        tools: List[str], 
        message: str, 
        context: AgentContext
    ) -> List[AgentToolResult]:
        """Execute tools in parallel with concurrency limits."""
        semaphore = asyncio.Semaphore(self.config.max_concurrent_tools)
        
        async def execute_with_semaphore(tool_name: str):
            async with semaphore:
                return await self._execute_tool(tool_name, message, context)
        
        tasks = [execute_with_semaphore(tool_name) for tool_name in tools]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Convert exceptions to failed tool results
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                results[i] = AgentToolResult(
                    tool_name=tools[i],
                    success=False,
                    error=str(result),
                    status=ToolExecutionStatus.FAILED
                )
        
        return results
    
    async def _execute_tool(
        self, 
        tool_name: str, 
        message: str, 
        context: AgentContext
    ) -> AgentToolResult:
        """Execute a specific tool with error handling and timeout."""
        start_time = time.time()
        
        if tool_name not in self._tool_registry:
            return AgentToolResult(
                tool_name=tool_name,
                success=False,
                error=f"Tool {tool_name} not found",
                status=ToolExecutionStatus.FAILED
            )
        
        tool = self._tool_registry[tool_name]
        
        try:
            # Execute tool with timeout
            result = await asyncio.wait_for(
                self._call_tool_method(tool, tool_name, message, context),
                timeout=self.config.tool_timeout
            )
            
            execution_time = time.time() - start_time
            
            return AgentToolResult(
                tool_name=tool_name,
                success=True,
                result=result,
                execution_time=execution_time,
                status=ToolExecutionStatus.COMPLETED
            )
            
        except asyncio.TimeoutError:
            return AgentToolResult(
                tool_name=tool_name,
                success=False,
                error=f"Tool execution timed out after {self.config.tool_timeout}s",
                execution_time=time.time() - start_time,
                status=ToolExecutionStatus.FAILED
            )
        except Exception as e:
            return AgentToolResult(
                tool_name=tool_name,
                success=False,
                error=str(e),
                execution_time=time.time() - start_time,
                status=ToolExecutionStatus.FAILED
            )
    
    async def _call_tool_method(
        self, 
        tool: Any, 
        tool_name: str, 
        message: str, 
        context: AgentContext
    ) -> Any:
        """Call the appropriate method on a tool based on its type."""
        if tool_name == "memory":
            # Get recent memories for context
            return await tool.get_context(
                session_id=context.session_id,
                limit=10
            )
        elif tool_name == "rag":
            return await tool.search(
                query=message,
                top_k=5,
                session_context=context.message_history[-5:]  # Last 5 messages
            )
        elif tool_name == "attachment":
            return await tool.process_attachments(context.current_file_attachments)
        elif tool_name == "escalation":
            # Get RAG results from previous tool execution
            rag_result = next((r for r in tool_results if r.tool_name == "rag"), None)
            rag_results = rag_result.result if rag_result and rag_result.success else None
            
            # Convert context to the format expected by enhanced escalation tool
            legacy_context = AgentContext(
                session_id=context.session_id,
                user_id=context.user_id,
                message_history=context.message_history,
                current_file_attachments=context.current_file_attachments,
                escalation_level=context.escalation_level
            )
            
            if hasattr(tool, 'get_escalation_decision'):
                # Use enhanced escalation tool
                escalation_decision = await tool.get_escalation_decision(
                    message=message,
                    context=legacy_context,
                    rag_results=rag_results
                )
                
                # Convert to legacy format for backward compatibility
                return {
                    "should_escalate": escalation_decision.should_escalate,
                    "escalation_score": escalation_decision.escalation_score,
                    "reasons": [reason.value for reason in escalation_decision.reasons],
                    "immediate_escalation": escalation_decision.priority_level.value in ['URGENT', 'CRITICAL'],
                    "hard_escalation": escalation_decision.priority_level.value == 'HIGH',
                    "soft_escalation": escalation_decision.priority_level.value == 'MEDIUM',
                    "queue_id": escalation_decision.recommended_queue_id,
                    "priority": escalation_decision.priority_level.value,
                    "confidence": escalation_decision.confidence_score,
                    "complexity": escalation_decision.complexity_assessment,
                    "alternative_actions": escalation_decision.alternative_actions
                }
            else:
                # Use legacy escalation tool
                return await tool.check_escalation(
                    message=message,
                    context=legacy_context,
                    rag_results=rag_results
                )
        else:
            raise ValueError(f"Unknown tool name: {tool_name}")
    
    async def _analyze_for_escalation(
        self, 
        tool_results: List[AgentToolResult], 
        message: str, 
        context: AgentContext
    ) -> EscalationType:
        """Analyze tool results to determine if escalation is needed."""
        for result in tool_results:
            if result.tool_name == "escalation" and result.success:
                escalation_data = result.result
                if isinstance(escalation_data, dict):
                    if escalation_data.get("immediate_escalation"):
                        return EscalationType.IMMEDIATE
                    elif escalation_data.get("hard_escalation"):
                        return EscalationType.HARD
                    elif escalation_data.get("soft_escalation"):
                        return EscalationType.SOFT
        
        return EscalationType.NONE
    
    async def _generate_response(
        self,
        message: str,
        context: AgentContext,
        tool_results: List[AgentToolResult],
        escalation_type: EscalationType
    ) -> str:
        """Generate the final response based on all processed information."""
        
        # Handle escalation responses
        if escalation_type == EscalationType.IMMEDIATE:
            return "I've transferred your conversation to a human agent who can better assist you with this urgent matter."
        elif escalation_type == EscalationType.HARD:
            return "I need to escalate this to a human agent for better assistance."
        elif escalation_type == EscalationType.SOFT:
            return "Would you like me to connect you with a human agent for more detailed assistance?"
        
        # Normal response generation
        response_parts = []
        
        # Process RAG results
        rag_result = next((r for r in tool_results if r.tool_name == "rag"), None)
        if rag_result and rag_result.success and rag_result.result:
            sources_info = ""
            if rag_result.result.get("sources"):
                sources_info = "\n\nSources: " + ", ".join([
                    source.get("title", "Unknown") for source in rag_result.result["sources"]
                ])
            response_parts.append(f"Based on your message: '{message}', here's what I found:{sources_info}")
        else:
            response_parts.append(f"Thank you for your message: '{message}'")
        
        # Process memory context
        memory_result = next((r for r in tool_results if r.tool_name == "memory"), None)
        if memory_result and memory_result.success and memory_result.result:
            memories = memory_result.result
            if memories:
                response_parts.append(f"\n\nBased on our previous conversation, {len(memories)} relevant memories were found.")
        
        # Process attachments
        if context.current_file_attachments:
            response_parts.append(f"\n\nI've processed the following files: {', '.join(context.current_file_attachments)}")
        
        # Combine all parts
        response = "".join(response_parts)
        
        # Truncate if too long
        if len(response) > self.config.max_response_length:
            response = response[:self.config.max_response_length-3] + "..."
        
        return response
    
    async def _update_memory(
        self, 
        context: AgentContext, 
        tool_results: List[AgentToolResult]
    ) -> bool:
        """Update conversation memory with new information."""
        try:
            # Store the current message
            await self.memory_tool.store_memory(
                session_id=context.session_id,
                key=f"message_{context.conversation_turn}",
                value={
                    "content": context.message_history[-1]["content"],
                    "timestamp": context.message_history[-1]["timestamp"],
                    "agent_id": self.agent_id,
                    "tools_used": context.tools_used
                },
                memory_type="conversation"
            )
            
            # Store conversation summary
            if context.conversation_turn % 10 == 0:  # Every 10 messages
                await self.memory_tool.store_memory(
                    session_id=context.session_id,
                    key="conversation_summary",
                    value={
                        "turns": context.conversation_turn,
                        "tools_used": context.tools_used,
                        "escalation_level": context.escalation_level,
                        "summary": f"Conversation has {context.conversation_turn} turns with {len(context.tools_used)} tool uses"
                    },
                    memory_type="summary"
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to update memory for session {context.session_id}: {e}")
            return False
    
    async def _update_context(
        self, 
        context: AgentContext, 
        tool_results: List[AgentToolResult]
    ) -> Dict[str, Any]:
        """Update context with new information from tool results."""
        updates = {}
        
        # Update escalation level
        escalation_result = next((r for r in tool_results if r.tool_name == "escalation"), None)
        if escalation_result and escalation_result.success:
            escalation_data = escalation_result.result
            if isinstance(escalation_data, dict):
                if escalation_data.get("escalation_level"):
                    context.escalation_level = escalation_data["escalation_level"]
                    updates["escalation_level"] = context.escalation_level
        
        # Update user intent if detected
        intent_result = next((r for r in tool_results if r.tool_name == "rag"), None)
        if intent_result and intent_result.success:
            rag_data = intent_result.result
            if isinstance(rag_data, dict) and rag_data.get("user_intent"):
                context.user_intent = rag_data["user_intent"]
                updates["user_intent"] = context.user_intent
        
        # Update last activity
        context.update_activity()
        updates["last_activity"] = context.last_activity.isoformat()
        
        return updates
    
    def _extract_sources(self, tool_results: List[AgentToolResult]) -> List[Dict[str, Any]]:
        """Extract sources from tool results."""
        sources = []
        
        rag_result = next((r for r in tool_results if r.tool_name == "rag"), None)
        if rag_result and rag_result.success and rag_result.result:
            if isinstance(rag_result.result, dict) and rag_result.result.get("sources"):
                sources.extend(rag_result.result["sources"])
        
        return sources
    
    def _calculate_confidence_score(self, tool_results: List[AgentToolResult]) -> float:
        """Calculate overall confidence score based on tool results."""
        if not tool_results:
            return 0.0
        
        successful_tools = [r for r in tool_results if r.success]
        if not successful_tools:
            return 0.0
        
        # Base confidence on tool success rate
        tool_confidence = len(successful_tools) / len(tool_results)
        
        # Adjust based on specific tools
        rag_result = next((r for r in tool_results if r.tool_name == "rag"), None)
        if rag_result and rag_result.success and isinstance(rag_result.result, dict):
            rag_confidence = rag_result.result.get("confidence", 0.5)
            return (tool_confidence * 0.3 + rag_confidence * 0.7)
        
        return tool_confidence
    
    async def _initialize_tools(self):
        """Initialize all tools."""
        logger.info("Initializing agent tools...")
        
        # Tools are initialized in __init__, but we can add validation here
        for tool_name, tool in self._tool_registry.items():
            try:
                # Validate tool is working
                if hasattr(tool, 'health_check'):
                    await tool.health_check()
                logger.debug(f"Tool {tool_name} initialized successfully")
            except Exception as e:
                logger.warning(f"Tool {tool_name} initialization issue: {e}")
    
    async def _start_metrics_collector(self):
        """Start background metrics collection."""
        while not self._shutdown_event.is_set():
            try:
                # Collect and log metrics periodically
                if self.config.enable_metrics:
                    metrics_data = {
                        "agent_id": self.agent_id,
                        "timestamp": datetime.utcnow().isoformat(),
                        "active_sessions": len(self._active_sessions),
                        "total_conversations": self.metrics.total_conversations,
                        "average_response_time": self.metrics.average_response_time,
                        "escalation_rate": self.metrics.escalation_rate,
                        "success_rate": self.metrics.get_success_rate(),
                        "tool_usage": self.metrics.tool_usage_stats
                    }
                    logger.info(f"Agent metrics: {json.dumps(metrics_data)}")
                
                await asyncio.sleep(60)  # Collect metrics every minute
                
            except Exception as e:
                logger.error(f"Error in metrics collection: {e}")
                await asyncio.sleep(60)
    
    async def _start_conversation_cleanup(self):
        """Start background conversation cleanup."""
        while not self._shutdown_event.is_set():
            try:
                if self.config.enable_conversation_cleanup:
                    cutoff_time = datetime.utcnow() - timedelta(hours=self.config.conversation_timeout_hours)
                    
                    expired_sessions = [
                        session_id for session_id, context in self._active_sessions.items()
                        if context.last_activity < cutoff_time
                    ]
                    
                    for session_id in expired_sessions:
                        logger.info(f"Cleaning up expired session: {session_id}")
                        await self.end_session(session_id)
                
                await asyncio.sleep(3600)  # Check every hour
                
            except Exception as e:
                logger.error(f"Error in conversation cleanup: {e}")
                await asyncio.sleep(3600)
    
    async def _start_performance_monitor(self):
        """Start performance monitoring."""
        while not self._shutdown_event.is_set():
            try:
                if self.config.enable_performance_monitoring:
                    # Monitor agent performance
                    active_count = len(self._active_sessions)
                    
                    if active_count > 100:  # High load threshold
                        logger.warning(f"High load detected: {active_count} active sessions")
                    
                    if self.metrics.average_response_time > 5.0:  # Slow response threshold
                        logger.warning(f"Slow responses detected: {self.metrics.average_response_time:.2f}s average")
                
                await asyncio.sleep(30)  # Monitor every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in performance monitoring: {e}")
                await asyncio.sleep(30)
    
    @asynccontextmanager
    async def session_context(self, session_id: str, user_id: str):
        """Context manager for session lifecycle."""
        context = await self.create_session(session_id, user_id)
        try:
            yield context
        finally:
            await self.end_session(session_id)
    
    def get_metrics(self) -> AgentMetrics:
        """Get current agent metrics."""
        return self.metrics
    
    def get_configuration(self) -> AgentConfiguration:
        """Get current agent configuration."""
        return self.config
    
    def update_configuration(self, config: AgentConfiguration):
        """Update agent configuration."""
        self.config = config
        logger.info(f"Agent {self.agent_id} configuration updated")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        return {
            "agent_id": self.agent_id,
            "state": self.state.value,
            "active_sessions": len(self._active_sessions),
            "metrics": self.metrics.__dict__,
            "configuration": self.config.__dict__,
            "uptime": time.time() - self.metrics.total_conversations,  # Approximate
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on the agent."""
        issues = []
        
        # Check tool availability
        for tool_name, tool in self._tool_registry.items():
            try:
                if hasattr(tool, 'health_check'):
                    await tool.health_check()
            except Exception as e:
                issues.append(f"Tool {tool_name} health check failed: {e}")
        
        # Check session health
        if len(self._active_sessions) > 1000:  # Arbitrary high threshold
            issues.append(f"High number of active sessions: {len(self._active_sessions)}")
        
        return {
            "healthy": len(issues) == 0,
            "agent_id": self.agent_id,
            "state": self.state.value,
            "active_sessions": len(self._active_sessions),
            "issues": issues,
            "timestamp": datetime.utcnow().isoformat()
        }