"""
Agent Monitoring Integration.

This module provides integration between the Customer Support Agent system and
the backend monitoring infrastructure, including Prometheus metrics, health checks,
and alerting.
"""

import logging
import asyncio
import time
import json
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from pathlib import Path

try:
    from prometheus_client import Counter, Histogram, Gauge, start_http_server
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    logging.warning("Prometheus client not available, metrics will be disabled")

from app.monitoring.backend_monitoring import BackendMonitor
from app.monitoring.health_check import HealthChecker
from .chat_agent import CustomerSupportAgent, AgentMetrics, AgentState
from .agent_factory import agent_factory
from .agent_utils import agent_monitor, performance_tracker, resource_manager

logger = logging.getLogger(__name__)


class AgentMetricsCollector:
    """Collects and exports agent metrics for monitoring systems."""
    
    def __init__(self):
        if PROMETHEUS_AVAILABLE:
            # Initialize Prometheus metrics
            self.agent_operations_total = Counter(
                'agent_operations_total',
                'Total number of agent operations',
                ['agent_id', 'operation_type', 'status']
            )
            
            self.agent_operation_duration = Histogram(
                'agent_operation_duration_seconds',
                'Duration of agent operations',
                ['agent_id', 'operation_type'],
                buckets=[0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0]
            )
            
            self.active_sessions_gauge = Gauge(
                'agent_active_sessions',
                'Number of active sessions per agent',
                ['agent_id']
            )
            
            self.agent_state_gauge = Gauge(
                'agent_state',
                'Current state of agents',
                ['agent_id']
            )
            
            self.escalation_rate_gauge = Gauge(
                'agent_escalation_rate',
                'Escalation rate percentage per agent',
                ['agent_id']
            )
            
            self.success_rate_gauge = Gauge(
                'agent_success_rate',
                'Success rate percentage per agent',
                ['agent_id']
            )
            
            self.tool_usage_counter = Counter(
                'agent_tool_usage_total',
                'Total tool usage per agent',
                ['agent_id', 'tool_name']
            )
            
            self.memory_usage_gauge = Gauge(
                'agent_memory_usage_bytes',
                'Memory usage per agent',
                ['agent_id']
            )
            
            self.cpu_usage_gauge = Gauge(
                'agent_cpu_usage_percent',
                'CPU usage percentage per agent',
                ['agent_id']
            )
        
        self._collection_active = False
        self._collection_task: Optional[asyncio.Task] = None
        self._metrics_interval = 30  # seconds
    
    async def start_collection(self):
        """Start metrics collection."""
        if self._collection_active:
            return
        
        self._collection_active = True
        self._collection_task = asyncio.create_task(self._collection_loop())
        logger.info("Started agent metrics collection")
    
    async def stop_collection(self):
        """Stop metrics collection."""
        self._collection_active = False
        if self._collection_task:
            self._collection_task.cancel()
            try:
                await self._collection_task
            except asyncio.CancelledError:
                pass
        logger.info("Stopped agent metrics collection")
    
    async def _collection_loop(self):
        """Main metrics collection loop."""
        while self._collection_active:
            try:
                await self._collect_agent_metrics()
                await asyncio.sleep(self._metrics_interval)
            except Exception as e:
                logger.error(f"Error in metrics collection loop: {e}")
                await asyncio.sleep(self._metrics_interval)
    
    async def _collect_agent_metrics(self):
        """Collect metrics from all agents."""
        agents = agent_factory.get_all_agents()
        
        for agent_id, agent in agents.items():
            try:
                await self._collect_single_agent_metrics(agent_id, agent)
            except Exception as e:
                logger.error(f"Error collecting metrics for agent {agent_id}: {e}")
    
    async def _collect_single_agent_metrics(self, agent_id: str, agent: CustomerSupportAgent):
        """Collect metrics from a single agent."""
        metrics = agent.get_metrics()
        
        if PROMETHEUS_AVAILABLE:
            # Update gauges
            self.active_sessions_gauge.labels(agent_id=agent_id).set(len(agent._active_sessions))
            self.agent_state_gauge.labels(agent_id=agent_id).set(self._get_state_numeric_value(agent.state))
            self.escalation_rate_gauge.labels(agent_id=agent_id).set(metrics.escalation_rate)
            self.success_rate_gauge.labels(agent_id=agent_id).set(metrics.get_success_rate())
            
            # Update tool usage counters
            for tool_name, count in metrics.tool_usage_stats.items():
                self.tool_usage_counter.labels(agent_id=agent_id, tool_name=tool_name).inc(count - self._get_previous_tool_count(agent_id, tool_name))
            
            # Update system resource gauges
            try:
                import psutil
                process = psutil.Process()
                self.memory_usage_gauge.labels(agent_id=agent_id).set(process.memory_info().rss)
                self.cpu_usage_gauge.labels(agent_id=agent_id).set(process.cpu_percent())
            except ImportError:
                pass  # psutil not available
            
            # Record operation metrics
            if hasattr(metrics, 'last_operation_time'):
                self.agent_operation_duration.labels(
                    agent_id=agent_id, 
                    operation_type="message_processing"
                ).observe(time.time() - metrics.last_operation_time)
            
            # Store current tool counts for next iteration
            self._store_tool_counts(agent_id, metrics.tool_usage_stats)
    
    def _get_state_numeric_value(self, state: AgentState) -> int:
        """Convert agent state to numeric value for Prometheus."""
        state_values = {
            AgentState.IDLE: 0,
            AgentState.PROCESSING: 1,
            AgentState.WAITING: 2,
            AgentState.ERROR: 3,
            AgentState.TERMINATED: 4
        }
        return state_values.get(state, 0)
    
    def _get_previous_tool_count(self, agent_id: str, tool_name: str) -> int:
        """Get previous tool count for delta calculation."""
        # This would be implemented with persistent storage
        # For now, return 0 (we'll track this in memory)
        return getattr(self, f'_last_tool_counts_{agent_id}', {}).get(tool_name, 0)
    
    def _store_tool_counts(self, agent_id: str, tool_counts: Dict[str, int]):
        """Store current tool counts for next iteration."""
        setattr(self, f'_last_tool_counts_{agent_id}', tool_counts.copy())
    
    def record_operation(self, agent_id: str, operation_type: str, duration: float, success: bool):
        """Record a single operation."""
        if PROMETHEUS_AVAILABLE:
            status = "success" if success else "failure"
            self.agent_operations_total.labels(
                agent_id=agent_id,
                operation_type=operation_type,
                status=status
            ).inc()
            
            self.agent_operation_duration.labels(
                agent_id=agent_id,
                operation_type=operation_type
            ).observe(duration)
    
    def start_prometheus_server(self, port: int = 8090):
        """Start Prometheus metrics server."""
        if PROMETHEUS_AVAILABLE:
            try:
                start_http_server(port)
                logger.info(f"Prometheus metrics server started on port {port}")
            except Exception as e:
                logger.error(f"Failed to start Prometheus server: {e}")
        else:
            logger.warning("Prometheus not available, cannot start metrics server")


class AgentHealthChecker:
    """Health checker for agents integrated with backend monitoring."""
    
    def __init__(self):
        self.health_checker = HealthChecker()
        self._custom_checks = {}
    
    def register_custom_check(self, name: str, check_func: callable):
        """Register a custom health check."""
        self._custom_checks[name] = check_func
    
    async def check_agent_health(self) -> Dict[str, Any]:
        """Perform comprehensive health check on agents."""
        health_status = {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": "healthy",
            "agents": {},
            "pools": {},
            "system": {},
            "issues": []
        }
        
        # Check individual agents
        agents = agent_factory.get_all_agents()
        healthy_agents = 0
        
        for agent_id, agent in agents.items():
            try:
                agent_health = await agent.health_check()
                health_status["agents"][agent_id] = agent_health
                
                if agent_health.get("healthy", False):
                    healthy_agents += 1
                else:
                    health_status["issues"].append(f"Agent {agent_id} is unhealthy")
                    
            except Exception as e:
                health_status["agents"][agent_id] = {
                    "healthy": False,
                    "error": str(e)
                }
                health_status["issues"].append(f"Agent {agent_id} check failed: {e}")
        
        # Check agent pools
        pools = agent_factory.get_all_pools()
        for pool_name, pool in pools.items():
            try:
                stats = pool.get_stats()
                health_status["pools"][pool_name] = {
                    "healthy": stats["available_agents"] > 0,
                    "stats": stats
                }
                
                if stats["available_agents"] == 0:
                    health_status["issues"].append(f"Agent pool '{pool_name}' has no available agents")
                    
            except Exception as e:
                health_status["pools"][pool_name] = {
                    "healthy": False,
                    "error": str(e)
                }
                health_status["issues"].append(f"Pool '{pool_name}' check failed: {e}")
        
        # Check system resources
        try:
            import psutil
            health_status["system"] = {
                "memory_usage_percent": psutil.virtual_memory().percent,
                "cpu_usage_percent": psutil.cpu_percent(),
                "disk_usage_percent": psutil.disk_usage('/').percent
            }
            
            # Add system issues
            if psutil.virtual_memory().percent > 90:
                health_status["issues"].append("System memory usage is critically high")
            if psutil.cpu_percent() > 90:
                health_status["issues"].append("System CPU usage is critically high")
            
        except ImportError:
            health_status["system"] = {"error": "psutil not available"}
        
        # Run custom checks
        for check_name, check_func in self._custom_checks.items():
            try:
                result = await check_func()
                health_status[f"custom_{check_name}"] = result
                if not result.get("healthy", True):
                    health_status["issues"].append(f"Custom check '{check_name}' failed")
            except Exception as e:
                health_status[f"custom_{check_name}"] = {
                    "healthy": False,
                    "error": str(e)
                }
                health_status["issues"].append(f"Custom check '{check_name}' failed: {e}")
        
        # Determine overall status
        if health_status["issues"]:
            if len([i for i in health_status["issues"] if "critical" in i.lower()]) > 0:
                health_status["overall_status"] = "critical"
            elif len(health_status["issues"]) > 5:
                health_status["overall_status"] = "unhealthy"
            else:
                health_status["overall_status"] = "degraded"
        
        # Register with backend health checker
        await self._register_with_backend(health_status)
        
        return health_status
    
    async def _register_with_backend(self, health_status: Dict[str, Any]):
        """Register health status with backend monitoring."""
        try:
            # This would integrate with the existing backend health check system
            # For now, we'll log the health status
            logger.info(f"Agent system health status: {health_status['overall_status']}")
            
            if health_status["issues"]:
                logger.warning(f"Agent health issues: {health_status['issues']}")
                
        except Exception as e:
            logger.error(f"Failed to register with backend health checker: {e}")
    
    def get_health_endpoint_data(self) -> Dict[str, Any]:
        """Get data for health check endpoint."""
        return {
            "service": "customer_support_agent",
            "status": "healthy",  # This would be determined by actual health checks
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0.0",
            "dependencies": {
                "agents": len(agent_factory.get_all_agents()),
                "pools": len(agent_factory.get_all_pools())
            }
        }


class AgentAlertManager:
    """Manages alerts and notifications for the agent system."""
    
    def __init__(self):
        self.alert_rules = {}
        self.active_alerts = {}
        self.notification_callbacks = []
    
    def add_alert_rule(self, rule_name: str, condition: callable, severity: str):
        """Add an alert rule."""
        self.alert_rules[rule_name] = {
            "condition": condition,
            "severity": severity,
            "triggered": False,
            "last_check": None
        }
        logger.info(f"Added alert rule: {rule_name}")
    
    def add_notification_callback(self, callback: callable):
        """Add notification callback."""
        self.notification_callbacks.append(callback)
    
    async def check_alerts(self):
        """Check all alert rules."""
        for rule_name, rule in self.alert_rules.items():
            try:
                should_alert = await rule["condition"]()
                
                if should_alert and not rule["triggered"]:
                    # Trigger alert
                    alert_id = f"{rule_name}_{int(time.time())}"
                    alert = {
                        "id": alert_id,
                        "rule": rule_name,
                        "severity": rule["severity"],
                        "timestamp": datetime.utcnow().isoformat(),
                        "message": f"Alert rule '{rule_name}' triggered"
                    }
                    
                    self.active_alerts[alert_id] = alert
                    rule["triggered"] = True
                    
                    # Send notifications
                    await self._send_notifications(alert)
                    
                    logger.warning(f"Alert triggered: {rule_name}")
                
                elif not should_alert and rule["triggered"]:
                    # Clear alert
                    rule["triggered"] = False
                    
                    # Remove active alerts for this rule
                    to_remove = [aid for aid, alert in self.active_alerts.items() if alert["rule"] == rule_name]
                    for aid in to_remove:
                        del self.active_alerts[aid]
                    
                    logger.info(f"Alert cleared: {rule_name}")
                
                rule["last_check"] = datetime.utcnow().isoformat()
                
            except Exception as e:
                logger.error(f"Error checking alert rule {rule_name}: {e}")
    
    async def _send_notifications(self, alert: Dict[str, Any]):
        """Send alert notifications."""
        for callback in self.notification_callbacks:
            try:
                await callback(alert)
            except Exception as e:
                logger.error(f"Error sending notification: {e}")
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Get list of active alerts."""
        return list(self.active_alerts.values())
    
    def get_alert_summary(self) -> Dict[str, Any]:
        """Get alert summary."""
        severity_counts = {}
        for alert in self.active_alerts.values():
            severity = alert["severity"]
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
        
        return {
            "total_active": len(self.active_alerts),
            "by_severity": severity_counts,
            "rules_configured": len(self.alert_rules)
        }


class AgentMonitoringIntegration:
    """Main integration class for agent monitoring."""
    
    def __init__(self):
        self.metrics_collector = AgentMetricsCollector()
        self.health_checker = AgentHealthChecker()
        self.alert_manager = AgentAlertManager()
        self.backend_monitor = None
        self._monitoring_active = False
        self._monitoring_task: Optional[asyncio.Task] = None
    
    async def initialize(self, backend_monitor: Optional[BackendMonitor] = None):
        """Initialize monitoring integration."""
        try:
            self.backend_monitor = backend_monitor
            
            # Start metrics collection
            await self.metrics_collector.start_collection()
            
            # Register health checks
            await self._register_health_checks()
            
            # Setup alert rules
            await self._setup_alert_rules()
            
            # Start monitoring loop
            self._monitoring_active = True
            self._monitoring_task = asyncio.create_task(self._monitoring_loop())
            
            logger.info("Agent monitoring integration initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize agent monitoring integration: {e}")
            raise
    
    async def shutdown(self):
        """Shutdown monitoring integration."""
        self._monitoring_active = False
        
        if self._monitoring_task:
            self._monitoring_task.cancel()
            try:
                await self._monitoring_task
            except asyncio.CancelledError:
                pass
        
        await self.metrics_collector.stop_collection()
        logger.info("Agent monitoring integration shutdown")
    
    async def _register_health_checks(self):
        """Register health checks with backend."""
        # Register agent health check with backend monitoring
        if self.backend_monitor:
            # This would integrate with the existing backend health check system
            pass
    
    async def _setup_alert_rules(self):
        """Setup default alert rules."""
        
        # High response time alert
        async def check_response_time():
            try:
                metrics = await agent_factory.get_metrics_summary()
                return metrics["aggregated_metrics"]["average_response_time"] > 10.0
            except:
                return False
        
        self.alert_manager.add_alert_rule(
            "high_response_time",
            check_response_time,
            "warning"
        )
        
        # Low success rate alert
        async def check_success_rate():
            try:
                metrics = await agent_factory.get_metrics_summary()
                return metrics["aggregated_metrics"]["success_rate"] < 80.0
            except:
                return False
        
        self.alert_manager.add_alert_rule(
            "low_success_rate",
            check_success_rate,
            "warning"
        )
        
        # No available agents alert
        async def check_agent_availability():
            try:
                agents = agent_factory.get_all_agents()
                available = sum(1 for agent in agents.values() if agent.state == AgentState.IDLE)
                return available == 0 and len(agents) > 0
            except:
                return False
        
        self.alert_manager.add_alert_rule(
            "no_available_agents",
            check_agent_availability,
            "critical"
        )
    
    async def _monitoring_loop(self):
        """Main monitoring loop."""
        while self._monitoring_active:
            try:
                # Check alerts
                await self.alert_manager.check_alerts()
                
                # Update backend monitoring
                if self.backend_monitor:
                    await self._update_backend_metrics()
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(30)
    
    async def _update_backend_metrics(self):
        """Update backend monitoring with agent metrics."""
        try:
            # Get current metrics
            metrics_summary = await agent_factory.get_metrics_summary()
            health_status = await self.health_checker.check_agent_health()
            
            # Update backend monitoring
            # This would integrate with the existing backend monitoring system
            logger.debug("Updated backend monitoring with agent metrics")
            
        except Exception as e:
            logger.error(f"Error updating backend metrics: {e}")
    
    def record_agent_operation(
        self, 
        agent_id: str, 
        operation_type: str, 
        duration: float, 
        success: bool
    ):
        """Record an agent operation for metrics."""
        self.metrics_collector.record_operation(agent_id, operation_type, duration, success)
    
    def get_monitoring_status(self) -> Dict[str, Any]:
        """Get current monitoring status."""
        return {
            "monitoring_active": self._monitoring_active,
            "metrics_collection_active": self.metrics_collector._collection_active,
            "backend_monitor_connected": self.backend_monitor is not None,
            "alert_summary": self.alert_manager.get_alert_summary()
        }


# Global monitoring integration instance
agent_monitoring = AgentMonitoringIntegration()


async def initialize_agent_monitoring_integration(backend_monitor: Optional[BackendMonitor] = None):
    """Initialize the complete agent monitoring integration."""
    try:
        await agent_monitoring.initialize(backend_monitor)
        
        # Start Prometheus server if available
        if PROMETHEUS_AVAILABLE:
            # Get port from settings or use default
            port = getattr(settings, 'prometheus_port', 8090)
            agent_monitoring.metrics_collector.start_prometheus_server(port)
        
        logger.info("Agent monitoring integration fully initialized")
        
    except Exception as e:
        logger.error(f"Failed to initialize agent monitoring integration: {e}")
        raise


async def shutdown_agent_monitoring_integration():
    """Shutdown the complete agent monitoring integration."""
    try:
        await agent_monitoring.shutdown()
        logger.info("Agent monitoring integration fully shutdown")
    except Exception as e:
        logger.error(f"Error shutting down agent monitoring integration: {e}")


# Decorator for automatic metrics collection
def monitor_agent_operation(operation_type: str):
    """Decorator to automatically monitor agent operations."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            agent = None
            start_time = time.time()
            success = False
            
            try:
                # Try to get agent instance from context
                for arg in args:
                    if isinstance(arg, CustomerSupportAgent):
                        agent = arg
                        break
                
                result = await func(*args, **kwargs)
                success = True
                return result
                
            except Exception as e:
                logger.error(f"Error in monitored operation {operation_type}: {e}")
                raise
            finally:
                duration = time.time() - start_time
                if agent:
                    agent_monitoring.record_agent_operation(
                        agent.agent_id, 
                        operation_type, 
                        duration, 
                        success
                    )
        
        return wrapper
    return decorator