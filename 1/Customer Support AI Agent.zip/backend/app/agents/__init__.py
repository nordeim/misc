"""
Agent System Package.

This package contains the complete Customer Support Agent orchestrator system
including agent orchestration, factory management, utilities, and monitoring.
"""

# Core agent classes
from .chat_agent import (
    CustomerSupportAgent,
    AgentContext,
    AgentResponse,
    AgentConfiguration,
    AgentMetrics,
    AgentToolResult,
    AgentState,
    EscalationType,
    ToolExecutionStatus
)

# Agent factory and management
from .agent_factory import (
    AgentRegistry,
    AgentConfigurationManager,
    AgentPool,
    AgentFactory,
    AgentStateManager,
    agent_factory,
    agent_state_manager
)

# Agent utilities and monitoring
from .agent_utils import (
    AgentMonitor,
    AgentPerformanceTracker,
    AgentResourceManager,
    AgentDiagnosticTool,
    AgentAlert,
    AlertSeverity,
    agent_monitor,
    performance_tracker,
    resource_manager,
    diagnostic_tool,
    initialize_agent_monitoring,
    shutdown_agent_monitoring,
    performance_timer
)

# Monitoring integration
from .monitoring_integration import (
    AgentMetricsCollector,
    AgentHealthChecker,
    AgentAlertManager,
    AgentMonitoringIntegration,
    agent_monitoring,
    initialize_agent_monitoring_integration,
    shutdown_agent_monitoring_integration,
    monitor_agent_operation
)

# Public API
__all__ = [
    # Core agent classes
    "CustomerSupportAgent",
    "AgentContext",
    "AgentResponse",
    "AgentConfiguration",
    "AgentMetrics",
    "AgentToolResult",
    "AgentState",
    "EscalationType",
    "ToolExecutionStatus",
    
    # Factory and management
    "AgentRegistry",
    "AgentConfigurationManager",
    "AgentPool",
    "AgentFactory",
    "AgentStateManager",
    "agent_factory",
    "agent_state_manager",
    
    # Utilities and monitoring
    "AgentMonitor",
    "AgentPerformanceTracker",
    "AgentResourceManager",
    "AgentDiagnosticTool",
    "AgentAlert",
    "AlertSeverity",
    "agent_monitor",
    "performance_tracker",
    "resource_manager",
    "diagnostic_tool",
    "initialize_agent_monitoring",
    "shutdown_agent_monitoring",
    "performance_timer",
    
    # Monitoring integration
    "AgentMetricsCollector",
    "AgentHealthChecker",
    "AgentAlertManager",
    "AgentMonitoringIntegration",
    "agent_monitoring",
    "initialize_agent_monitoring_integration",
    "shutdown_agent_monitoring_integration",
    "monitor_agent_operation",
]

# Package metadata
__version__ = "1.0.0"
__author__ = "Customer Support AI Team"
__description__ = "Complete Customer Support Agent Orchestrator System"