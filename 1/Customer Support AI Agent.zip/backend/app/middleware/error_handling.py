"""
Error handling middleware for FastAPI application.

Provides comprehensive error handling with:
- Global exception handlers
- HTTP status mapping
- Structured error responses
- Error logging and monitoring
- Rate limiting error responses
- Authentication error responses
"""

import traceback
import json
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timezone
from enum import Enum

from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse, Response
from fastapi.exceptions import RequestValidationError, HTTPException as FastAPIHTTPException
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response
from starlette.exceptions import HTTPException as StarletteHTTPException
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class ErrorSeverity(Enum):
    """Error severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ErrorCategory(Enum):
    """Error categories for classification."""
    VALIDATION_ERROR = "validation_error"
    AUTHENTICATION_ERROR = "authentication_error"
    AUTHORIZATION_ERROR = "authorization_error"
    NOT_FOUND_ERROR = "not_found_error"
    CONFLICT_ERROR = "conflict_error"
    RATE_LIMIT_ERROR = "rate_limit_error"
    BUSINESS_LOGIC_ERROR = "business_logic_error"
    EXTERNAL_SERVICE_ERROR = "external_service_error"
    DATABASE_ERROR = "database_error"
    SYSTEM_ERROR = "system_error"
    UNKNOWN_ERROR = "unknown_error"

class ErrorResponse:
    """Standardized error response structure."""
    
    def __init__(
        self,
        detail: str,
        error_type: str,
        category: ErrorCategory,
        severity: ErrorSeverity,
        status_code: int,
        correlation_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        suggestions: Optional[List[str]] = None
    ):
        self.detail = detail
        self.error_type = error_type
        self.category = category
        self.severity = severity
        self.status_code = status_code
        self.correlation_id = correlation_id
        self.details = details or {}
        self.suggestions = suggestions or []
        self.timestamp = datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error response to dictionary."""
        return {
            "error": {
                "type": self.error_type,
                "category": self.category.value,
                "severity": self.severity.value,
                "detail": self.detail,
                "status_code": self.status_code,
                "correlation_id": self.correlation_id,
                "timestamp": self.timestamp,
                "details": self.details,
                "suggestions": self.suggestions
            }
        }
    
    def to_response(self) -> JSONResponse:
        """Convert to FastAPI response."""
        return JSONResponse(
            content=self.to_dict(),
            status_code=self.status_code,
            headers={
                "X-Error-Type": self.error_type,
                "X-Error-Category": self.category.value,
                "X-Error-Severity": self.severity.value,
                "X-Request-ID": self.correlation_id or ""
            }
        )

class GlobalExceptionHandler:
    """Global exception handler for the application."""
    
    ERROR_MAPPINGS = {
        # HTTP Exceptions
        StarletteHTTPException: ErrorCategory.UNKNOWN_ERROR,
        FastAPIHTTPException: ErrorCategory.UNKNOWN_ERROR,
        HTTPException: ErrorCategory.UNKNOWN_ERROR,
        
        # Validation Errors
        RequestValidationError: ErrorCategory.VALIDATION_ERROR,
        ValueError: ErrorCategory.VALIDATION_ERROR,
        TypeError: ErrorCategory.VALIDATION_ERROR,
        
        # Authentication/Authorization
        PermissionError: ErrorCategory.AUTHORIZATION_ERROR,
        
        # Database Errors
        ConnectionError: ErrorCategory.DATABASE_ERROR,
        TimeoutError: ErrorCategory.EXTERNAL_SERVICE_ERROR,
        
        # System Errors
        MemoryError: ErrorCategory.SYSTEM_ERROR,
        OSError: ErrorCategory.SYSTEM_ERROR,
        RuntimeError: ErrorCategory.BUSINESS_LOGIC_ERROR,
        
        # Others
        Exception: ErrorCategory.UNKNOWN_ERROR
    }
    
    def __init__(self):
        self.error_counts = {}
        self.error_threshold = 10  # Alert after 10 similar errors in 5 minutes
    
    def map_exception_to_error_category(self, exception: Exception) -> ErrorCategory:
        """Map exception type to error category."""
        for exc_type, category in self.ERROR_MAPPINGS.items():
            if isinstance(exception, exc_type):
                return category
        return ErrorCategory.UNKNOWN_ERROR
    
    def determine_severity(
        self, 
        exception: Exception, 
        category: ErrorCategory, 
        status_code: int
    ) -> ErrorSeverity:
        """Determine error severity based on exception and context."""
        if status_code >= 500:
            return ErrorSeverity.CRITICAL
        elif status_code >= 400:
            if category in [ErrorCategory.AUTHORIZATION_ERROR, ErrorCategory.AUTHENTICATION_ERROR]:
                return ErrorSeverity.MEDIUM
            elif category == ErrorCategory.RATE_LIMIT_ERROR:
                return ErrorSeverity.LOW
            else:
                return ErrorSeverity.MEDIUM
        elif isinstance(exception, (ConnectionError, TimeoutError)):
            return ErrorSeverity.HIGH
        else:
            return ErrorSeverity.LOW
    
    def determine_status_code(self, exception: Exception, category: ErrorCategory) -> int:
        """Determine HTTP status code for exception."""
        if isinstance(exception, HTTPException):
            return exception.status_code
        elif isinstance(exception, RequestValidationError):
            return status.HTTP_422_UNPROCESSABLE_ENTITY
        elif isinstance(exception, PermissionError):
            return status.HTTP_403_FORBIDDEN
        elif isinstance(exception, ConnectionError):
            return status.HTTP_503_SERVICE_UNAVAILABLE
        elif isinstance(exception, TimeoutError):
            return status.HTTP_504_GATEWAY_TIMEOUT
        elif isinstance(exception, ValueError):
            return status.HTTP_400_BAD_REQUEST
        else:
            return status.HTTP_500_INTERNAL_SERVER_ERROR
    
    def generate_error_message(self, exception: Exception, category: ErrorCategory) -> str:
        """Generate user-friendly error message."""
        if isinstance(exception, HTTPException):
            return exception.detail
        
        error_messages = {
            ErrorCategory.VALIDATION_ERROR: "Invalid request data provided",
            ErrorCategory.AUTHENTICATION_ERROR: "Authentication required",
            ErrorCategory.AUTHORIZATION_ERROR: "Insufficient permissions",
            ErrorCategory.NOT_FOUND_ERROR: "Requested resource not found",
            ErrorCategory.CONFLICT_ERROR: "Resource conflict occurred",
            ErrorCategory.RATE_LIMIT_ERROR: "Too many requests. Please try again later",
            ErrorCategory.BUSINESS_LOGIC_ERROR: "Business rule violation",
            ErrorCategory.EXTERNAL_SERVICE_ERROR: "External service unavailable",
            ErrorCategory.DATABASE_ERROR: "Database operation failed",
            ErrorCategory.SYSTEM_ERROR: "System error occurred",
        }
        
        return error_messages.get(category, "An unexpected error occurred")
    
    def get_suggestions(self, category: ErrorCategory, exception: Exception) -> List[str]:
        """Get suggestions for error resolution."""
        suggestions = {
            ErrorCategory.VALIDATION_ERROR: [
                "Check the request data format",
                "Ensure all required fields are provided",
                "Verify data types match expected schema"
            ],
            ErrorCategory.AUTHENTICATION_ERROR: [
                "Provide valid authentication credentials",
                "Check if your session has expired",
                "Verify API key configuration"
            ],
            ErrorCategory.AUTHORIZATION_ERROR: [
                "Contact administrator for required permissions",
                "Check user role and access rights",
                "Verify resource ownership"
            ],
            ErrorCategory.RATE_LIMIT_ERROR: [
                "Wait before making more requests",
                "Consider reducing request frequency",
                "Contact support if limits are too restrictive"
            ],
            ErrorCategory.EXTERNAL_SERVICE_ERROR: [
                "Try again later",
                "Check external service status",
                "Verify network connectivity"
            ],
            ErrorCategory.DATABASE_ERROR: [
                "Try again in a few moments",
                "Check database connection",
                "Contact support if problem persists"
            ]
        }
        
        return suggestions.get(category, [])
    
    def should_alert(self, category: ErrorCategory, exception: Exception) -> bool:
        """Determine if error should trigger an alert."""
        error_key = f"{category.value}:{type(exception).__name__}"
        current_time = datetime.now(timezone.utc)
        
        # Initialize error tracking
        if error_key not in self.error_counts:
            self.error_counts[error_key] = []
        
        # Add current error
        self.error_counts[error_key].append(current_time)
        
        # Remove errors older than 5 minutes
        cutoff_time = current_time.timestamp() - 300
        self.error_counts[error_key] = [
            error_time for error_time in self.error_counts[error_key]
            if error_time.timestamp() > cutoff_time
        ]
        
        # Alert if threshold exceeded
        return len(self.error_counts[error_key]) > self.error_threshold

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware for comprehensive error handling."""
    
    def __init__(self, app):
        super().__init__(app)
        self.exception_handler = GlobalExceptionHandler()
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Handle exceptions during request processing."""
        try:
            response = await call_next(request)
            return response
            
        except Exception as exc:
            return await self._handle_exception(request, exc)
    
    async def _handle_exception(self, request: Request, exception: Exception) -> Response:
        """Handle exception and generate error response."""
        correlation_id = getattr(request.state, 'correlation_id', None)
        client_ip = getattr(request.state, 'client_ip', 'unknown')
        
        # Map exception to error category
        category = self.exception_handler.map_exception_to_error_category(exception)
        
        # Determine status code
        status_code = self.exception_handler.determine_status_code(exception, category)
        
        # Determine severity
        severity = self.exception_handler.determine_severity(exception, category, status_code)
        
        # Generate error message
        message = self.exception_handler.generate_error_message(exception, category)
        
        # Get suggestions
        suggestions = self.exception_handler.get_suggestions(category, exception)
        
        # Prepare additional details
        details = {
            "path": str(request.url.path),
            "method": request.method,
            "client_ip": client_ip,
            "exception_type": type(exception).__name__
        }
        
        # Add exception details in development
        if settings.is_development:
            details["exception_message"] = str(exception)
            details["traceback"] = traceback.format_exc()
        
        # Create error response
        error_response = ErrorResponse(
            detail=message,
            error_type=type(exception).__name__,
            category=category,
            severity=severity,
            status_code=status_code,
            correlation_id=correlation_id,
            details=details,
            suggestions=suggestions
        )
        
        # Log error
        await self._log_error(exception, error_response, request)
        
        # Check if alert should be sent
        if self.exception_handler.should_alert(category, exception):
            await self._send_alert(exception, error_response, request)
        
        return error_response.to_response()
    
    async def _log_error(
        self, 
        exception: Exception, 
        error_response: ErrorResponse, 
        request: Request
    ) -> None:
        """Log error with appropriate level."""
        log_data = {
            "error_type": error_response.error_type,
            "error_category": error_response.category.value,
            "error_severity": error_response.severity.value,
            "status_code": error_response.status_code,
            "correlation_id": error_response.correlation_id,
            "path": str(request.url.path),
            "method": request.method,
            "client_ip": getattr(request.state, 'client_ip', 'unknown'),
            "exception_message": str(exception)
        }
        
        if settings.is_development:
            log_data["traceback"] = traceback.format_exc()
        
        # Log at appropriate level based on severity
        if error_response.severity == ErrorSeverity.CRITICAL:
            logger.critical("Critical error occurred", **log_data)
        elif error_response.severity == ErrorSeverity.HIGH:
            logger.error("High severity error occurred", **log_data)
        elif error_response.severity == ErrorSeverity.MEDIUM:
            logger.warning("Medium severity error occurred", **log_data)
        else:
            logger.info("Low severity error occurred", **log_data)
    
    async def _send_alert(
        self, 
        exception: Exception, 
        error_response: ErrorResponse, 
        request: Request
    ) -> None:
        """Send alert for high-frequency errors."""
        alert_data = {
            "alert_type": "high_error_frequency",
            "error_category": error_response.category.value,
            "error_type": error_response.error_type,
            "severity": error_response.severity.value,
            "occurrence_count": len(self.exception_handler.error_counts.get(
                f"{error_response.category.value}:{type(exception).__name__}", []
            )),
            "path": str(request.url.path),
            "correlation_id": error_response.correlation_id,
            "timestamp": error_response.timestamp
        }
        
        logger.warning("High error frequency detected", **alert_data)
        
        # Here you would integrate with your alerting system
        # e.g., send to monitoring service, email, Slack, etc.

# Global exception handlers
def setup_global_exception_handlers(app) -> None:
    """
    Setup global exception handlers for the FastAPI app.
    
    Args:
        app: FastAPI application instance
    """
    # HTTP Exception handler
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException) -> Response:
        """Handle HTTP exceptions."""
        correlation_id = getattr(request.state, 'correlation_id', None)
        
        error_response = ErrorResponse(
            detail=exc.detail,
            error_type="HTTPException",
            category=ErrorCategory.UNKNOWN_ERROR,
            severity=ErrorSeverity.MEDIUM,
            status_code=exc.status_code,
            correlation_id=correlation_id,
            details={
                "headers": dict(exc.headers) if exc.headers else {},
                "path": str(request.url.path)
            }
        )
        
        return error_response.to_response()
    
    # Validation Error handler
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, 
        exc: RequestValidationError
    ) -> Response:
        """Handle request validation errors."""
        correlation_id = getattr(request.state, 'correlation_id', None)
        
        # Parse validation errors
        validation_errors = []
        for error in exc.errors():
            field = "->".join(str(x) for x in error["loc"] if x != "body")
            validation_errors.append({
                "field": field,
                "message": error["msg"],
                "type": error["type"]
            })
        
        error_response = ErrorResponse(
            detail="Request validation failed",
            error_type="RequestValidationError",
            category=ErrorCategory.VALIDATION_ERROR,
            severity=ErrorSeverity.MEDIUM,
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            correlation_id=correlation_id,
            details={
                "validation_errors": validation_errors,
                "path": str(request.url.path)
            },
            suggestions=[
                "Check request data format",
                "Ensure all required fields are provided",
                "Verify data types match expected schema"
            ]
        )
        
        logger.warning("Request validation failed", 
                      validation_errors=validation_errors,
                      correlation_id=correlation_id)
        
        return error_response.to_response()
    
    # General Exception handler
    @app.exception_handler(Exception)
    async def general_exception_handler(
        request: Request, 
        exc: Exception
    ) -> Response:
        """Handle all other exceptions."""
        correlation_id = getattr(request.state, 'correlation_id', None)
        
        error_response = ErrorResponse(
            detail="An unexpected error occurred",
            error_type="InternalServerError",
            category=ErrorCategory.UNKNOWN_ERROR,
            severity=ErrorSeverity.HIGH if settings.is_production else ErrorSeverity.MEDIUM,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            correlation_id=correlation_id,
            details={
                "path": str(request.url.path),
                "method": request.method,
                "exception_type": type(exc).__name__
            }
        )
        
        # Add detailed error info in development
        if settings.is_development:
            error_response.details["exception_message"] = str(exc)
            error_response.details["traceback"] = traceback.format_exc()
            error_response.detail = f"Internal server error: {str(exc)}"
        
        logger.error("Unhandled exception occurred",
                    exception_type=type(exc).__name__,
                    exception_message=str(exc),
                    correlation_id=correlation_id,
                    traceback=traceback.format_exc() if settings.is_development else None)
        
        return error_response.to_response()
    
    logger.info("Global exception handlers configured")

# Error response utilities
def create_error_response(
    detail: str,
    status_code: int,
    error_type: str = "CustomError",
    category: ErrorCategory = ErrorCategory.UNKNOWN_ERROR,
    correlation_id: Optional[str] = None,
    **kwargs
) -> JSONResponse:
    """Create a custom error response."""
    error_response = ErrorResponse(
        detail=detail,
        error_type=error_type,
        category=category,
        severity=ErrorSeverity.MEDIUM,
        status_code=status_code,
        correlation_id=correlation_id,
        details=kwargs
    )
    
    return error_response.to_response()

def create_validation_error_response(
    detail: str,
    field_errors: List[Dict[str, Any]],
    correlation_id: Optional[str] = None
) -> JSONResponse:
    """Create a validation error response."""
    error_response = ErrorResponse(
        detail=detail,
        error_type="ValidationError",
        category=ErrorCategory.VALIDATION_ERROR,
        severity=ErrorSeverity.MEDIUM,
        status_code=status.HTTP_400_BAD_REQUEST,
        correlation_id=correlation_id,
        details={"field_errors": field_errors},
        suggestions=[
            "Check the provided data format",
            "Ensure all required fields are present",
            "Verify data types and constraints"
        ]
    )
    
    return error_response.to_response()