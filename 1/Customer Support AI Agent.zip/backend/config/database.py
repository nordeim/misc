"""
Database configuration module.

This module provides specialized database configuration management with
connection pooling, migration settings, and database-specific validation.
"""

import logging
from typing import Optional, Dict, Any
from urllib.parse import quote_plus

from pydantic import BaseSettings, Field, validator, PostgresDsn


logger = logging.getLogger(__name__)


class DatabaseConfig(BaseSettings):
    """
    Database configuration with connection pooling and optimization settings.
    
    This class handles all database-related configuration including connection
    strings, pool settings, and database-specific validations.
    """
    
    # Connection settings
    database_url: str = Field(
        default="sqlite+aiosqlite:///./data/sqlite/customer_support.db",
        description="Database connection URL"
    )
    
    # Connection pool settings
    db_pool_size: int = Field(default=10, ge=1, description="Database pool size")
    db_max_overflow: int = Field(default=20, ge=0, description="Database max overflow")
    db_pool_timeout: int = Field(default=30, ge=1, description="Database pool timeout")
    db_pool_recycle: int = Field(default=3600, ge=1, description="Database pool recycle time")
    db_pool_pre_ping: bool = Field(default=True, description="Enable pool pre-ping")
    
    # Database connection settings
    db_connect_args: Dict[str, Any] = Field(default_factory=dict, description="Additional connection arguments")
    db_echo: bool = Field(default=False, description="Enable SQL query logging")
    
    # Migration settings
    migration_enabled: bool = Field(default=True, description="Enable database migrations")
    migration_path: str = Field(default="alembic", description="Migration files path")
    migration_version_table: str = Field(default="alembic_version", description="Migration version table")
    
    # Connection testing
    db_test_connection: bool = Field(default=True, description="Test database connection on startup")
    db_connection_timeout: int = Field(default=10, ge=1, description="Connection test timeout")
    
    # SSL settings (for PostgreSQL)
    db_ssl_enabled: bool = Field(default=False, description="Enable SSL for database connection")
    db_ssl_cert: Optional[str] = Field(default=None, description="SSL certificate path")
    db_ssl_key: Optional[str] = Field(default=None, description="SSL key path")
    db_ssl_ca: Optional[str] = Field(default=None, description="SSL CA certificate path")
    
    # Performance settings
    db_statement_timeout: Optional[int] = Field(default=None, ge=1, description="Statement timeout in seconds")
    db_idle_in_transaction_session_timeout: Optional[int] = Field(default=None, ge=1, description="Idle transaction timeout")
    
    # Backup settings
    db_backup_enabled: bool = Field(default=False, description="Enable automatic backups")
    db_backup_schedule: str = Field(default="0 2 * * *", description="Backup schedule (cron format)")
    db_backup_retention_days: int = Field(default=30, ge=1, description="Backup retention days")
    db_backup_path: str = Field(default="./data/backups", description="Backup file path")
    
    class Config:
        env_prefix = "DB_"
        case_sensitive = False
    
    @property
    def database_type(self) -> str:
        """Get database type from URL."""
        if "://" in self.database_url:
            return self.database_url.split("://")[0]
        return "unknown"
    
    @property
    def is_sqlite(self) -> bool:
        """Check if using SQLite database."""
        return "sqlite" in self.database_url.lower()
    
    @property
    def is_postgresql(self) -> bool:
        """Check if using PostgreSQL database."""
        return "postgresql" in self.database_url.lower() or "postgres" in self.database_url.lower()
    
    @property
    def is_mysql(self) -> bool:
        """Check if using MySQL database."""
        return "mysql" in self.database_url.lower()
    
    def get_sync_database_url(self) -> str:
        """Get synchronous database URL for Alembic migrations."""
        if self.is_sqlite:
            return self.database_url.replace("+aiosqlite", "")
        return self.database_url
    
    def get_async_database_url(self) -> str:
        """Get asynchronous database URL for async operations."""
        if self.is_sqlite and "+aiosqlite" not in self.database_url:
            return self.database_url.replace("sqlite://", "sqlite+aiosqlite://")
        return self.database_url
    
    def get_connection_args(self) -> Dict[str, Any]:
        """Get connection arguments including SSL settings."""
        args = self.db_connect_args.copy()
        
        if self.is_postgresql:
            if self.db_ssl_enabled:
                ssl_config = {}
                if self.db_ssl_cert:
                    ssl_config["sslcert"] = self.db_ssl_cert
                if self.db_ssl_key:
                    ssl_config["sslkey"] = self.db_ssl_key
                if self.db_ssl_ca:
                    ssl_config["sslca"] = self.db_ssl_ca
                    
                args.update(ssl_config)
                
        if self.db_statement_timeout:
            args["statement_timeout"] = f"{self.db_statement_timeout}s"
            
        if self.db_idle_in_transaction_session_timeout:
            args["idle_in_transaction_session_timeout"] = f"{self.db_idle_in_transaction_session_timeout}ms"
            
        return args
    
    def get_engine_kwargs(self) -> Dict[str, Any]:
        """Get SQLAlchemy engine arguments."""
        kwargs = {
            "pool_size": self.db_pool_size,
            "max_overflow": self.db_max_overflow,
            "pool_timeout": self.db_pool_timeout,
            "pool_recycle": self.db_pool_recycle,
            "pool_pre_ping": self.db_pool_pre_ping,
            "echo": self.db_echo,
            "connect_args": self.get_connection_args(),
        }
        
        return kwargs
    
    def get_async_engine_kwargs(self) -> Dict[str, Any]:
        """Get async SQLAlchemy engine arguments."""
        kwargs = self.get_engine_kwargs()
        kwargs["future"] = True
        return kwargs
    
    def validate_connection(self) -> Dict[str, Any]:
        """Validate database connection settings."""
        issues = []
        
        # Check database URL format
        if "://" not in self.database_url:
            issues.append("Invalid database URL format - missing protocol")
            
        # Check for common issues based on database type
        if self.is_postgresql:
            # PostgreSQL specific validations
            if "localhost" in self.database_url and not self.db_ssl_enabled:
                logger.warning("PostgreSQL connection without SSL may not be secure in production")
                
        elif self.is_sqlite:
            # SQLite specific validations
            if self.db_pool_size > 1:
                logger.warning("SQLite may not benefit from connection pooling")
                
        # Check SSL settings
        if self.db_ssl_enabled and self.is_postgresql:
            missing_ssl_files = []
            if not self.db_ssl_cert:
                missing_ssl_files.append("SSL certificate")
            if not self.db_ssl_ca:
                missing_ssl_files.append("SSL CA certificate")
                
            if missing_ssl_files:
                issues.append(f"SSL enabled but missing: {', '.join(missing_ssl_files)}")
                
        # Check backup settings
        if self.db_backup_enabled:
            import os
            backup_dir = os.path.dirname(self.db_backup_path)
            if not os.path.exists(backup_dir):
                issues.append(f"Backup directory does not exist: {backup_dir}")
                
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "database_type": self.database_type,
            "connection_pool_configured": self.db_pool_size > 0,
            "ssl_configured": self.db_ssl_enabled and self.is_postgresql,
            "backup_enabled": self.db_backup_enabled,
        }
    
    def create_backup(self, backup_name: Optional[str] = None) -> str:
        """Create a database backup."""
        import os
        import shutil
        from datetime import datetime
        
        if not self.db_backup_enabled:
            raise ValueError("Backup is not enabled in configuration")
            
        if backup_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"backup_{timestamp}"
            
        os.makedirs(self.db_backup_path, exist_ok=True)
        backup_file = os.path.join(self.db_backup_path, f"{backup_name}.db")
        
        if self.is_sqlite:
            # SQLite backup
            import sqlite3
            source_db = self.database_url.replace("sqlite+aiosqlite:///", "")
            source_db = source_db.replace("sqlite:///", "")
            
            if os.path.exists(source_db):
                shutil.copy2(source_db, backup_file)
                logger.info(f"SQLite backup created: {backup_file}")
            else:
                raise FileNotFoundError(f"Database file not found: {source_db}")
                
        elif self.is_postgresql:
            # PostgreSQL backup (requires pg_dump)
            logger.info("PostgreSQL backup requires pg_dump tool")
            # Implementation would depend on having pg_dump available
            
        else:
            raise ValueError(f"Backup not supported for database type: {self.database_type}")
            
        return backup_file


class DatabaseConnectionManager:
    """Manages database connections with lifecycle management."""
    
    def __init__(self, config: DatabaseConfig):
        self.config = config
        self._engine = None
        self._async_engine = None
        
    async def initialize(self):
        """Initialize database engines."""
        try:
            from sqlalchemy import create_engine
            from sqlalchemy.ext.asyncio import create_async_engine
            
            # Create sync engine for migrations
            self._engine = create_engine(
                self.config.get_sync_database_url(),
                **self.config.get_engine_kwargs()
            )
            
            # Create async engine for application
            self._async_engine = create_async_engine(
                self.config.get_async_database_url(),
                **self.config.get_async_engine_kwargs()
            )
            
            # Test connection if enabled
            if self.config.db_test_connection:
                await self.test_connection()
                
            logger.info("Database connection manager initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize database connection manager: {e}")
            raise
    
    async def test_connection(self) -> bool:
        """Test database connection."""
        try:
            async with self._async_engine.begin() as conn:
                result = await conn.execute("SELECT 1")
                if result.fetchone():
                    logger.info("Database connection test successful")
                    return True
        except Exception as e:
            logger.error(f"Database connection test failed: {e}")
            raise
            
        return False
    
    async def close(self):
        """Close database connections."""
        if self._async_engine:
            await self._async_engine.dispose()
        if self._engine:
            self._engine.dispose()
        logger.info("Database connection manager closed")
    
    @property
    def engine(self):
        """Get sync engine."""
        return self._engine
    
    @property
    def async_engine(self):
        """Get async engine."""
        return self._async_engine


# Database configuration instance
database_config = DatabaseConfig()
db_manager = DatabaseConnectionManager(database_config)