#!/usr/bin/env python3
"""
MemoryTool Demonstration Script

This script demonstrates the key features of the enhanced MemoryTool:
- Basic memory operations
- Advanced search and retrieval
- Memory compression
- Analytics and optimization
- Context management

Run this script to see the MemoryTool in action.

Usage:
    python demo_memory_tool.py

Author: Customer Support AI Agent
Version: 2.0.0
"""

import asyncio
import logging
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Add the backend directory to the path
sys.path.append('/workspace/backend')

from app.tools.memory_tool import (
    MemoryTool, MemoryType, MemoryQuery, MemoryAnalytics
)
from app.services.memory_service import (
    ConversationMemoryManager, MemoryOptimizationService
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MemoryToolDemo:
    """Demonstration class for MemoryTool features."""
    
    def __init__(self):
        self.memory_tool = MemoryTool()
        self.conv_manager = ConversationMemoryManager(self.memory_tool)
        self.opt_service = MemoryOptimizationService(self.memory_tool)
        self.session_id = f"demo_session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        
        logger.info("MemoryTool Demo initialized")
    
    async def run_demo(self):
        """Run the complete demonstration."""
        logger.info("=" * 60)
        logger.info("STARTING MEMORY TOOL DEMONSTRATION")
        logger.info("=" * 60)
        
        try:
            # 1. Basic Memory Operations
            await self.demo_basic_operations()
            
            # 2. Advanced Search
            await self.demo_search_functionality()
            
            # 3. Memory Compression
            await self.demo_memory_compression()
            
            # 4. Analytics
            await self.demo_analytics()
            
            # 5. Conversation Management
            await self.demo_conversation_management()
            
            # 6. Optimization
            await self.demo_optimization()
            
            # 7. Summary Generation
            await self.demo_summary_generation()
            
            logger.info("=" * 60)
            logger.info("DEMONSTRATION COMPLETED SUCCESSFULLY")
            logger.info("=" * 60)
            
        except Exception as e:
            logger.error(f"Demo failed: {e}")
            raise
    
    async def demo_basic_operations(self):
        """Demonstrate basic CRUD operations."""
        logger.info("\n1. BASIC MEMORY OPERATIONS")
        logger.info("-" * 40)
        
        # Store various types of memories
        memories = [
            ("user_name", "John Doe", MemoryType.USER_INFO.value, 0.9),
            ("user_email", "john.doe@example.com", MemoryType.USER_INFO.value, 0.9),
            ("support_ticket", "Ticket #12345 about billing issue", MemoryType.CONVERSATION.value, 0.8),
            ("user_preference", "Prefers email support", MemoryType.USER_PREFERENCE.value, 0.8),
            ("technical_fact", "Python 3.9+ required for feature X", MemoryType.KNOWLEDGE.value, 0.7),
            ("error_info", "Database connection timeout", MemoryType.ERROR.value, 0.9),
        ]
        
        stored_ids = []
        for key, value, mem_type, importance in memories:
            memory_id = await self.memory_tool.store_memory(
                session_id=self.session_id,
                key=key,
                value=value,
                memory_type=mem_type,
                importance_score=importance,
                metadata={"demo": True, "created_by": "demo_script"}
            )
            stored_ids.append(memory_id)
            logger.info(f"✓ Stored memory: {key} (ID: {memory_id[:8]}...)")
        
        # Retrieve all memories
        context = await self.memory_tool.get_context(
            session_id=self.session_id,
            limit=20
        )
        logger.info(f"✓ Retrieved {len(context)} memories")
        
        # Test update
        updated_id = await self.memory_tool.update_memory(
            self.session_id,
            "user_name",
            "John Smith",
            MemoryType.USER_INFO.value,
            importance_score=0.95
        )
        logger.info(f"✓ Updated memory: user_name (New importance: 0.95)")
        
        # Test search
        found = await self.memory_tool.get_memory(self.session_id, "user_name")
        if found:
            logger.info(f"✓ Found memory: {found['value']} (Importance: {found['importance_score']})")
    
    async def demo_search_functionality(self):
        """Demonstrate advanced search functionality."""
        logger.info("\n2. ADVANCED SEARCH FUNCTIONALITY")
        logger.info("-" * 40)
        
        # Add more memories for search testing
        search_memories = [
            ("python_info", "Python is a programming language"),
            ("javascript_info", "JavaScript is used for web development"),
            ("email_support", "Customer prefers email for support"),
            ("phone_contact", "User can be contacted by phone"),
            ("technical_issue", "Application crashes on startup"),
        ]
        
        for key, value in search_memories:
            await self.memory_tool.store_memory(
                session_id=self.session_id,
                key=key,
                value=value,
                memory_type=MemoryType.KNOWLEDGE.value,
                importance_score=0.6,
                tags=["technical", "development"]
            )
        
        # Search by keywords
        search_queries = [
            (["python"], "Python-related memories"),
            (["email", "support"], "Email support preferences"),
            (["technical", "issue"], "Technical issues"),
        ]
        
        for keywords, description in search_queries:
            query = MemoryQuery(
                session_id=self.session_id,
                keywords=keywords,
                limit=10,
                memory_types=[MemoryType.KNOWLEDGE.value, MemoryType.USER_PREFERENCE.value]
            )
            
            results = await self.memory_tool.search_memories(query)
            logger.info(f"✓ {description}: Found {len(results)} results")
            
            for result in results[:2]:  # Show top 2 results
                logger.info(f"  - {result.memory.key}: {result.memory.value[:50]}...")
    
    async def demo_memory_compression(self):
        """Demonstrate memory compression functionality."""
        logger.info("\n3. MEMORY COMPRESSION")
        logger.info("-" * 40)
        
        # Create a long conversation for compression
        long_conversation = """
        This is a very long conversation that demonstrates memory compression functionality. 
        The conversation contains many details about customer support interactions, technical troubleshooting steps, 
        and various user requests. This content is lengthy enough to trigger automatic compression 
        when the auto_compress parameter is enabled. The compression algorithm will identify key sentences 
        and create a condensed version while preserving the most important information. 
        This is useful for managing memory usage in long-running conversations where storage efficiency 
        is important. The system will automatically detect when compression is beneficial based on 
        content length and importance scores. Additional context about user preferences, technical requirements, 
        and support history may be included in the compressed memory to maintain context relevance.
        """ * 10  # Make it very long
        
        # Store with compression enabled
        compressed_id = await self.memory_tool.store_memory(
            session_id=self.session_id,
            key="long_conversation",
            value=long_conversation,
            memory_type=MemoryType.CONVERSATION.value,
            importance_score=0.4,  # Lower importance = good candidate for compression
            auto_compress=True
        )
        
        logger.info(f"✓ Stored long conversation with compression (ID: {compressed_id[:8]}...)")
        
        # Retrieve and check compression
        stored = await self.memory_tool.get_memory(self.session_id, "long_conversation")
        if stored:
            metadata = stored.get("metadata", {})
            if metadata.get("was_compressed"):
                original_length = metadata.get("original_length", len(long_conversation))
                current_length = len(stored["value"])
                compression_ratio = current_length / original_length
                logger.info(f"✓ Memory compressed: {original_length} → {current_length} chars (ratio: {compression_ratio:.2f})")
            else:
                logger.info("✓ Memory stored without compression (below threshold)")
    
    async def demo_analytics(self):
        """Demonstrate memory analytics functionality."""
        logger.info("\n4. MEMORY ANALYTICS")
        logger.info("-" * 40)
        
        # Add some diverse memories for analytics
        diverse_memories = [
            ("recent_interaction", "Customer contacted about delayed shipment", MemoryType.CONVERSATION.value, 0.6),
            ("payment_method", "Credit card on file", MemoryType.FACT.value, 0.8),
            ("language_preference", "English preferred", MemoryType.USER_PREFERENCE.value, 0.7),
            ("product_info", "Feature available in Pro plan", MemoryType.KNOWLEDGE.value, 0.5),
            ("escalation_case", "Case escalated to senior support", MemoryType.CONVERSATION.value, 0.9),
        ]
        
        for key, value, mem_type, importance in diverse_memories:
            await self.memory_tool.store_memory(
                session_id=self.session_id,
                key=key,
                value=value,
                memory_type=mem_type,
                importance_score=importance,
                ttl_days=30 if importance < 0.7 else None
            )
        
        # Generate analytics
        analytics = await self.memory_tool.get_memory_analytics(self.session_id, days=30)
        
        logger.info(f"✓ Analytics generated for session: {analytics.session_id}")
        logger.info(f"  - Total memories: {analytics.total_memories}")
        logger.info(f"  - Average importance: {analytics.avg_importance_score:.2f}")
        logger.info(f"  - Retention rate: {analytics.retention_stats['retention_rate']:.1f}%")
        logger.info(f"  - Memories by type: {analytics.memories_by_type}")
        logger.info(f"  - Compression ratio: {analytics.compression_ratio:.2f}" if analytics.compression_ratio else "  - No compressed memories")
    
    async def demo_conversation_management(self):
        """Demonstrate conversation management features."""
        logger.info("\n5. CONVERSATION MANAGEMENT")
        logger.info("-" * 40)
        
        # Simulate a conversation flow
        conversation_turns = [
            (1, "Hi, I need help with my account", "Hello! I'd be happy to help you with your account. What specific issue are you experiencing?"),
            (2, "I can't log in to my account", "I understand the login issue. Let's troubleshoot this. Can you tell me what error message you see?"),
            (3, "It says 'invalid credentials'", "The 'invalid credentials' error usually means either your username/email or password is incorrect. Do you remember your login email?"),
            (4, "It's john.doe@example.com", "Thank you. Let's reset your password. I'll send a reset link to john.doe@example.com. Please check your email."),
            (5, "I received the email and reset my password", "Great! You should now be able to log in with your new password. Is there anything else you need help with?"),
        ]
        
        # Store conversation turns
        for turn_num, user_msg, assistant_msg in conversation_turns:
            user_id, assistant_id = await self.conv_manager.store_conversation_turn(
                session_id=self.session_id,
                turn_number=turn_num,
                user_message=user_msg,
                assistant_response=assistant_msg,
                context_tags=["account_support", "login_issue", "password_reset"]
            )
        
        logger.info(f"✓ Stored {len(conversation_turns)} conversation turns")
        
        # Get conversation context
        context = await self.conv_manager.get_conversation_context(
            session_id=self.session_id,
            recent_turns=3,
            include_summaries=True
        )
        
        logger.info(f"✓ Retrieved conversation context: {len(context)} items")
        
        # Extract user preferences from conversation
        preferences = await self.conv_manager.track_user_preferences(
            session_id=self.session_id,
            user_message="I prefer email communication and formal tone",
            extracted_preferences={
                "communication_method": "email",
                "communication_style": "formal",
                "support_approach": "step_by_step"
            }
        )
        
        logger.info(f"✓ Tracked user preferences: {preferences}")
        
        # Identify important facts
        messages = [
            "My email is john.doe@example.com",
            "I need help with account access",
            "I prefer email support",
            "The issue started yesterday"
        ]
        
        facts = await self.conv_manager.identify_important_facts(
            session_id=self.session_id,
            messages=messages
        )
        
        logger.info(f"✓ Identified {len(facts)} important facts")
    
    async def demo_optimization(self):
        """Demonstrate memory optimization features."""
        logger.info("\n6. MEMORY OPTIMIZATION")
        logger.info("-" * 40)
        
        # Add many memories to trigger optimization
        optimization_memories = []
        for i in range(25):
            memory_id = await self.memory_tool.store_memory(
                session_id=self.session_id,
                key=f"opt_test_{i}",
                value=f"This is test memory number {i} with some additional content for optimization testing purposes",
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.3 + (i * 0.02),  # Varying importance
                ttl_days=1 if i < 10 else None  # Some will expire
            )
            optimization_memories.append(memory_id)
        
        logger.info(f"✓ Added {len(optimization_memories)} memories for optimization testing")
        
        # Run optimization
        optimization_results = await self.opt_service.optimize_session_memories(
            session_id=self.session_id,
            force=True  # Force optimization
        )
        
        logger.info("✓ Optimization completed:")
        for key, value in optimization_results.items():
            logger.info(f"  - {key}: {value}")
        
        # Analyze memory patterns
        patterns = await self.opt_service.analyze_memory_patterns(self.session_id)
        
        if patterns:
            logger.info(f"✓ Detected {len(patterns)} memory usage patterns:")
            for pattern in patterns:
                logger.info(f"  - {pattern.pattern_type}: {pattern.recommendations[:2]}")  # Show first 2 recommendations
        else:
            logger.info("✓ No specific patterns detected")
    
    async def demo_summary_generation(self):
        """Demonstrate summary generation."""
        logger.info("\n7. SUMMARY GENERATION")
        logger.info("-" * 40)
        
        # Generate conversation summary
        summary = await self.conv_manager.generate_conversation_summary(
            session_id=self.session_id,
            summary_length=300
        )
        
        logger.info("✓ Generated conversation summary:")
        logger.info(f"  {summary}")
        
        # Get comprehensive memory summary
        memory_summary = await self.memory_tool.get_memory_summary(
            session_id=self.session_id,
            max_memories=5
        )
        
        logger.info("✓ Memory summary generated:")
        logger.info(f"  - Important memories: {len(memory_summary['important_memories'])}")
        logger.info(f"  - Recent memories: {len(memory_summary['recent_memories'])}")
        logger.info(f"  - Total memories: {memory_summary['analytics']['total_memories']}")
        logger.info(f"  - Retention rate: {memory_summary['analytics']['retention_rate']}%")
        
        if memory_summary['recommendations']:
            logger.info("  - Recommendations:")
            for rec in memory_summary['recommendations'][:2]:  # Show first 2
                logger.info(f"    * {rec}")
    
    async def cleanup(self):
        """Clean up demo data."""
        logger.info("\nCLEANUP")
        logger.info("-" * 40)
        
        try:
            deleted_count = await self.memory_tool.clear_session_memories(self.session_id)
            logger.info(f"✓ Cleaned up {deleted_count} demo memories")
        except Exception as e:
            logger.warning(f"Cleanup failed (this is expected in some environments): {e}")


async def main():
    """Main demo function."""
    demo = MemoryToolDemo()
    
    try:
        await demo.run_demo()
    finally:
        await demo.cleanup()


if __name__ == "__main__":
    print("MemoryTool Enhanced Feature Demonstration")
    print("==========================================")
    print()
    
    # Run the demo
    asyncio.run(main())
