#!/usr/bin/env python3
"""
Script to seed the database with test data.

This script populates the database with sample data for development and testing.
"""

import sys
import os
import argparse
from datetime import datetime, timedelta
from pathlib import Path
import random
import uuid

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import UserORM, SessionORM, MessageORM, MemoryORM
from app.config import settings


def create_test_users(session):
    """Create test users."""
    users_data = [
        {
            "email": "admin@example.com",
            "username": "admin",
            "full_name": "Admin User",
            "hashed_password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/Le6LsmG/8xW4A3YcO",  # password: admin123
            "is_active": True,
            "is_verified": True,
            "is_superuser": True,
            "login_count": 5,
            "timezone": "UTC",
            "language": "en"
        },
        {
            "email": "test@example.com",
            "username": "testuser",
            "full_name": "Test User",
            "hashed_password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/Le6LsmG/8xW4A3YcO",  # password: test123
            "is_active": True,
            "is_verified": True,
            "is_superuser": False,
            "login_count": 10,
            "timezone": "UTC",
            "language": "en"
        },
        {
            "email": "demo@example.com",
            "username": "demouser",
            "full_name": "Demo User",
            "hashed_password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/Le6LsmG/8xW4A3YcO",  # password: demo123
            "is_active": True,
            "is_verified": False,
            "is_superuser": False,
            "login_count": 2,
            "timezone": "America/New_York",
            "language": "en"
        }
    ]
    
    created_users = []
    for user_data in users_data:
        # Check if user already exists
        existing = session.query(UserORM).filter(
            (UserORM.email == user_data["email"]) | 
            (UserORM.username == user_data["username"])
        ).first()
        
        if not existing:
            user = UserORM(**user_data)
            session.add(user)
            created_users.append(user)
    
    session.flush()
    return created_users


def create_test_sessions(session, users):
    """Create test sessions for users."""
    session_templates = [
        {"title": "Customer Support Chat", "session_type": "support"},
        {"title": "Product Demo", "session_type": "demo"},
        {"title": "Troubleshooting Session", "session_type": "troubleshooting"},
        {"title": "General Inquiry", "session_type": "general"},
        {"title": "Feature Discussion", "session_type": "feature"},
    ]
    
    created_sessions = []
    
    for user in users:
        # Create 2-4 sessions per user
        num_sessions = random.randint(2, 4)
        
        for i in range(num_sessions):
            template = random.choice(session_templates)
            
            session_data = {
                "user_id": user.id,
                "title": f"{template['title']} #{i+1}",
                "session_type": template["session_type"],
                "status": random.choice(["active", "closed", "archived"]),
                "model_name": random.choice(["gpt-3.5-turbo", "gpt-4", "claude-3"]),
                "provider": random.choice(["openai", "anthropic"]),
                "model_config": {
                    "temperature": random.uniform(0.1, 1.0),
                    "max_tokens": random.randint(500, 2000)
                },
                "message_count": random.randint(1, 50),
                "token_count": random.randint(100, 10000),
                "last_activity": datetime.utcnow() - timedelta(hours=random.randint(1, 72))
            }
            
            chat_session = SessionORM(**session_data)
            session.add(chat_session)
            created_sessions.append(chat_session)
    
    session.flush()
    return created_sessions


def create_test_messages(session, sessions):
    """Create test messages for sessions."""
    message_templates = {
        "user": [
            "Hello, I need help with my account.",
            "Can you explain how to use the new feature?",
            "I'm having trouble logging in.",
            "What are your business hours?",
            "I'd like to schedule a demo.",
            "How can I reset my password?",
            "Can you help me with billing?",
            "I need technical support.",
            "What are your pricing plans?",
            "How do I contact sales?"
        ],
        "assistant": [
            "Hello! I'd be happy to help you with that. Let me assist you with your inquiry.",
            "Of course! I can explain that feature in detail. What specific aspect would you like to know about?",
            "I understand your frustration. Let me help you resolve this login issue. Can you provide more details?",
            "Our business hours are Monday through Friday, 9 AM to 6 PM EST. How can I help you today?",
            "I'd be happy to schedule a demo for you. What time works best for you?",
            "I can help you reset your password. Please provide your email address for verification.",
            "For billing questions, I can connect you with our billing team. Can you tell me more about your concern?",
            "I'd be glad to provide technical support. What specific issue are you experiencing?",
            "Our pricing plans are available on our website. Would you like me to send you the link?",
            "You can reach our sales team at sales@company.com or call 1-800-SALES. How can I assist you further?"
        ]
    }
    
    created_messages = []
    
    for session_obj in sessions:
        # Create 2-20 messages per session
        num_messages = random.randint(2, 20)
        
        for i in range(num_messages):
            role = "user" if i % 2 == 0 else "assistant"
            
            message_data = {
                "session_id": session_obj.id,
                "role": role,
                "content": random.choice(message_templates[role]),
                "content_type": "text",
                "model_name": session_obj.model_name if role == "assistant" else None,
                "provider": session_obj.provider if role == "assistant" else None,
                "prompt_tokens": random.randint(10, 100) if role == "assistant" else 0,
                "completion_tokens": random.randint(50, 500) if role == "assistant" else 0,
                "total_tokens": 0,  # Will be calculated
                "cost_usd": random.uniform(0.001, 0.1) if role == "assistant" else 0.0,
                "is_error": random.choice([True, False]) if role == "assistant" else False,
                "is_system_prompt": False,
                "is_final_response": role == "assistant",
                "temperature": random.uniform(0.1, 1.0) if role == "assistant" else None,
                "max_tokens": random.randint(500, 2000) if role == "assistant" else None,
                "sequence_number": i,
                "created_at": session_obj.created_at + timedelta(minutes=i*2)
            }
            
            message = MessageORM(**message_data)
            message.total_tokens = message.prompt_tokens + message.completion_tokens
            session.add(message)
            created_messages.append(message)
    
    session.flush()
    return created_messages


def create_test_memories(session, sessions, messages):
    """Create test memories for sessions."""
    memory_templates = [
        {"key": "user_preference", "value": "Prefers email communication", "type": "preference"},
        {"key": "last_purchase", "value": "Purchased Premium plan in October 2024", "type": "knowledge"},
        {"key": "timezone", "value": "UTC-5 (Eastern Time)", "type": "user_info"},
        {"key": "product_interest", "value": "Interested in AI features", "type": "conversation"},
        {"key": "support_category", "value": "Technical issues", "type": "context"},
        {"key": "language", "value": "English", "type": "user_info"},
        {"key": "previous_issues", "value": "Had login problems last week", "type": "knowledge"},
        {"key": "preferred_model", "value": "gpt-4", "type": "preference"},
    ]
    
    created_memories = []
    
    for session_obj in sessions[:5]:  # Only create memories for first 5 sessions
        # Create 2-4 memories per session
        num_memories = random.randint(2, 4)
        
        for i in range(num_memories):
            template = random.choice(memory_templates)
            
            memory_data = {
                "session_id": session_obj.id,
                "key": f"{template['key']}_{i}",
                "value": template["value"],
                "memory_type": template["type"],
                "importance_score": random.uniform(0.3, 1.0),
                "confidence_score": random.uniform(0.7, 1.0),
                "access_count": random.randint(0, 5),
                "expires_at": None,
                "last_accessed": datetime.utcnow() - timedelta(hours=random.randint(1, 24))
            }
            
            memory = MemoryORM(**memory_data)
            session.add(memory)
            created_memories.append(memory)
    
    session.flush()
    return created_memories


def seed_database(num_users=3, force=False):
    """Seed the database with test data."""
    print(f"🌱 Seeding database with test data...")
    print("=" * 50)
    
    # Create database connection
    database_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
    engine = create_engine(database_url)
    
    with sessionmaker(bind=engine)() as session:
        try:
            # Check if data already exists
            existing_users = session.query(UserORM).count()
            if existing_users > 0 and not force:
                print(f"❌ Database already contains {existing_users} users.")
                print("Use --force to override existing data.")
                return False
            
            if existing_users > 0:
                print(f"⚠️  Database contains {existing_users} existing users. Proceeding with --force...")
            
            print("Creating test users...")
            users = create_test_users(session)
            if users:
                print(f"✅ Created {len(users)} new users")
            else:
                print("ℹ️  No new users created (already exist)")
            
            print("Creating test sessions...")
            sessions = create_test_sessions(session, users or [])
            print(f"✅ Created {len(sessions)} sessions")
            
            print("Creating test messages...")
            messages = create_test_messages(session, sessions)
            print(f"✅ Created {len(messages)} messages")
            
            print("Creating test memories...")
            memories = create_test_memories(session, sessions, messages)
            print(f"✅ Created {len(memories)} memories")
            
            # Commit all changes
            session.commit()
            
            print("\n🎉 Database seeded successfully!")
            print("\n📋 Test Account Credentials:")
            print("  - admin@example.com / admin123 (Admin)")
            print("  - test@example.com / test123 (User)")
            print("  - demo@example.com / demo123 (User)")
            
            return True
            
        except Exception as e:
            session.rollback()
            print(f"\n❌ Seeding failed: {e}")
            return False


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Seed database with test data")
    parser.add_argument("--users", type=int, default=3, 
                       help="Number of test users to create")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Override existing data")
    
    args = parser.parse_args()
    
    success = seed_database(args.users, args.force)
    
    if success:
        print("\n✅ Database seeding completed successfully!")
        return True
    else:
        print("\n💥 Database seeding failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)