# Backup and Restore Utilities Documentation

## Overview

This comprehensive backup and restore system provides enterprise-grade data protection and recovery capabilities for your application. It supports multiple backup types, automated scheduling, encryption, compression, and disaster recovery procedures.

## Features

### Backup Capabilities
- **Database Backup**: Full and incremental backups for SQLite and PostgreSQL
- **Configuration Backup**: Application settings, environment files, and Docker configurations
- **File System Backup**: Customizable file and directory backup with pattern filtering
- **Full System Backup**: Complete system backup including database, configuration, and file system
- **Point-in-Time Backup**: Backup at specific timestamps for temporal data recovery

### Restore Capabilities
- **Selective Restore**: Restore specific components or files
- **Full System Restore**: Complete system restoration from full backups
- **Disaster Recovery**: Multi-backup restoration for comprehensive recovery
- **Point-in-Time Recovery**: Restore data to specific timestamps

### Advanced Features
- **Automated Scheduling**: Cron-based backup scheduling
- **Compression & Encryption**: Built-in data compression and encryption support
- **Backup Verification**: Integrity checks and validation
- **Retention Policies**: Automated cleanup of old backups
- **Monitoring & Reporting**: Health reports and statistics

## Architecture

```
backup_restore_service.py
├── Database Backup (SQLite/PostgreSQL)
├── Configuration Backup
├── File System Backup
├── Full System Backup
├── Point-in-Time Backup
├── Restore Operations
├── Scheduling System
├── Verification System
├── Cleanup System
└── Health Monitoring
```

## API Endpoints

### Backup Operations

#### Create Database Backup
```http
POST /api/v1/backup-restore/backup/database
Content-Type: application/json

{
    "backup_type": "full",
    "compress": true,
    "encrypt": false,
    "backup_name": "daily_backup_20241104"
}
```

**Response:**
```json
{
    "success": true,
    "backup_id": "db_backup_20241104_143022",
    "message": "Database backup created successfully",
    "metadata": {
        "backup_type": "full",
        "timestamp": "2024-11-04T14:30:22",
        "database_type": "sqlite",
        "total_size": 1048576,
        "file_count": 1,
        "status": "completed"
    }
}
```

#### Create Configuration Backup
```http
POST /api/v1/backup-restore/backup/configuration
Content-Type: application/json

{
    "compress": true,
    "encrypt": true,
    "backup_name": "config_backup_20241104"
}
```

#### Create File System Backup
```http
POST /api/v1/backup-restore/backup/filesystem
Content-Type: application/json

{
    "compress": true,
    "encrypt": false,
    "backup_name": "fs_backup_20241104",
    "include_patterns": ["*.db", "*.json"],
    "exclude_patterns": ["*.tmp", "*.log"]
}
```

#### Create Full System Backup
```http
POST /api/v1/backup-restore/backup/full-system
Content-Type: application/json

{
    "compress": true,
    "encrypt": true,
    "backup_name": "full_backup_20241104",
    "include_configs": true,
    "include_files": true
}
```

### Restore Operations

#### Restore Database
```http
POST /api/v1/backup-restore/restore/database/{backup_id}
Content-Type: application/json

{
    "target_location": "path/to/new/database.db",
    "verify_checksum": true
}
```

#### Restore Configuration
```http
POST /api/v1/backup-restore/restore/configuration/{backup_id}
Content-Type: application/json

{
    "verify_checksum": true
}
```

#### Restore File System
```http
POST /api/v1/backup-restore/restore/filesystem/{backup_id}
Content-Type: application/json

{
    "target_location": "/path/to/restore",
    "verify_checksum": true,
    "selective_restore": ["data/", "uploads/"]
}
```

#### Disaster Recovery
```http
POST /api/v1/backup-restore/restore/disaster-recovery
Content-Type: application/json

{
    "backup_ids": ["config_backup_123", "db_backup_124", "fs_backup_125"],
    "validate_before_restore": true,
    "create_recovery_snapshot": true
}
```

### Management Operations

#### List Backups
```http
GET /api/v1/backup-restore/backups?backup_type=database&limit=10&offset=0
```

#### Get Backup Info
```http
GET /api/v1/backup-restore/backups/{backup_id}
```

#### Verify Backup
```http
POST /api/v1/backup-restore/backups/{backup_id}/verify
```

#### Schedule Backup
```http
POST /api/v1/backup-restore/schedule
Content-Type: application/json

{
    "name": "daily_database_backup",
    "backup_type": "database",
    "schedule_expression": "daily",
    "retention_days": 30,
    "enabled": true,
    "compression": true,
    "encryption": false,
    "notification_email": "admin@example.com"
}
```

#### Health Report
```http
GET /api/v1/backup-restore/health
```

#### Statistics
```http
GET /api/v1/backup-restore/statistics
```

#### Export Report
```http
GET /api/v1/backup-restore/report/export
```

## CLI Usage

The backup system includes a comprehensive CLI tool for command-line operations.

### Basic Commands

#### Create Database Backup
```bash
python scripts/backup_cli.py backup database --type full --compress --name "backup_$(date +%Y%m%d)"
```

#### Create Full System Backup
```bash
python scripts/backup_cli.py backup full-system --compress --encrypt --name "full_backup_20241104"
```

#### Restore Database
```bash
python scripts/backup_cli.py restore database --backup-id backup_123 --target /path/to/new/database.db
```

#### List Backups
```bash
python scripts/backup_cli.py list backups --type database --limit 10
```

#### Verify Backup
```bash
python scripts/backup_cli.py verify backup --backup-id backup_123
```

#### Export Report
```bash
python scripts/backup_cli.py export report --output backup_report.csv
```

#### Health Check
```bash
python scripts/backup_cli.py health
```

### Advanced Commands

#### Disaster Recovery
```bash
python scripts/backup_cli.py disaster-recovery --backup-ids backup1 backup2 backup3
```

#### Selective File System Backup
```bash
python scripts/backup_cli.py backup filesystem --include "*.db" "*.json" --exclude "*.tmp" "*.log"
```

#### Point-in-Time Backup
```bash
# Use API endpoint
curl -X POST /api/v1/backup-restore/backup/point-in-time \
  -H "Content-Type: application/json" \
  -d '{
    "target_timestamp": "2024-11-04T10:00:00",
    "backup_name": "pitr_backup_20241104"
  }'
```

### CLI Help
```bash
python scripts/backup_cli.py --help
python scripts/backup_cli.py backup --help
python scripts/backup_cli.py restore database --help
```

## Configuration

### Environment Variables

```bash
# Backup Directory Configuration
BACKUP_DIR=/path/to/backups

# Database Backup Settings
DB_BACKUP_COMPRESSION=true
DB_BACKUP_ENCRYPTION=false
DB_BACKUP_RETENTION_DAYS=30

# Schedule Configuration
BACKUP_SCHEDULE_ENABLED=true
BACKUP_SCHEDULE_TIME="02:00"

# Notification Settings
BACKUP_NOTIFICATION_EMAIL=admin@example.com
SMTP_SERVER=smtp.example.com
SMTP_PORT=587
SMTP_USERNAME=backup_bot
SMTP_PASSWORD=your_password
```

### Backup Directory Structure

```
backups/
├── backup_metadata.json          # Backup metadata storage
├── database_backups/             # Database backup files
│   ├── db_backup_20241104.db.gz
│   └── db_backup_20241105.sql.gz
├── configuration_backups/        # Configuration backup files
│   ├── config_backup_20241104.tar.gz
│   └── config_backup_20241105.tar.gz
├── data_backups/                 # File system backup files
│   ├── fs_backup_20241104.tar.gz
│   └── fs_backup_20241105.tar.gz
└── logs/                         # Backup operation logs
```

## Best Practices

### Backup Strategy

1. **Daily Incremental Backups**: Create daily incremental database backups
2. **Weekly Full Backups**: Perform weekly full system backups
3. **Monthly Configuration Backups**: Backup configurations monthly
4. **Retention Policy**: Keep daily backups for 30 days, weekly for 90 days, monthly for 1 year

### Security

1. **Encryption**: Enable encryption for sensitive data backups
2. **Access Control**: Restrict backup directory permissions
3. **Remote Storage**: Store backups in secure remote locations
4. **Backup Verification**: Always verify backup integrity before restoration

### Monitoring

1. **Health Checks**: Monitor backup service health regularly
2. **Alerting**: Set up alerts for failed backups
3. **Reporting**: Generate and review backup reports
4. **Testing**: Test restore procedures regularly

### Disaster Recovery

1. **Recovery Documentation**: Document all recovery procedures
2. **Recovery Testing**: Practice disaster recovery scenarios
3. **RTO/RPO**: Define Recovery Time Objective and Recovery Point Objective
4. **Multiple Backups**: Maintain multiple backup sources for critical data

## Troubleshooting

### Common Issues

#### Backup Fails with Database Lock Error
```bash
# SQLite: Ensure no active connections
lsof | grep sqlite

# PostgreSQL: Check for active connections
ps aux | grep postgres
```

#### Permission Denied Errors
```bash
# Check backup directory permissions
ls -la backups/
chmod 755 backups/
chown backup_user:backup_group backups/
```

#### Compression/Decompression Issues
```bash
# Check available disk space
df -h

# Verify gzip availability
which gzip
gzip --version
```

### Log Analysis

Backup operations generate detailed logs. Check logs for troubleshooting:

```bash
# View recent backup logs
tail -f logs/backup.log

# Search for errors
grep "ERROR" logs/backup.log

# Check specific backup operation
grep "backup_id_123" logs/backup.log
```

### Performance Optimization

1. **Database Optimization**: Optimize database before backup
   ```sql
   -- SQLite
   VACUUM;
   ANALYZE;
   
   -- PostgreSQL
   VACUUM ANALYZE;
   ```

2. **Parallel Backup**: Use parallel processes for large datasets
3. **Compression**: Enable compression for storage efficiency
4. **Network Optimization**: Use efficient protocols for remote backups

## Advanced Features

### Point-in-Time Recovery

For databases that support temporal queries, use point-in-time backups:

```python
from datetime import datetime

# Create PITR backup
target_time = datetime(2024, 11, 4, 10, 0, 0)
backup_id = await backup_service.create_point_in_time_backup(
    target_timestamp=target_time
)
```

### Custom Backup Scripts

Create custom backup scripts for specific scenarios:

```python
#!/usr/bin/env python3
"""
Custom backup script for specific requirements.
"""

import asyncio
from app.utils.backup_restore_service import backup_service

async def custom_backup():
    # Create configuration backup with custom name
    config_backup = await backup_service.create_configuration_backup(
        backup_name="pre_deployment_config",
        compress=True
    )
    
    # Create incremental database backup
    db_backup = await backup_service.create_database_backup(
        backup_type="incremental",
        compress=True
    )
    
    # Verify both backups
    config_valid = await backup_service.verify_backup(config_backup)
    db_valid = await backup_service.verify_backup(db_backup)
    
    print(f"Configuration backup: {'Valid' if config_valid else 'Invalid'}")
    print(f"Database backup: {'Valid' if db_valid else 'Invalid'}")

if __name__ == "__main__":
    asyncio.run(custom_backup())
```

### Integration with External Systems

The backup service can integrate with external monitoring and notification systems:

```python
# Custom notification handler
async def send_backup_notification(backup_id: str, status: str):
    # Send notification to Slack
    import aiohttp
    
    webhook_url = "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
    message = {
        "text": f"Backup {backup_id} completed with status: {status}"
    }
    
    async with aiohttp.ClientSession() as session:
        await session.post(webhook_url, json=message)

# Register notification handler
backup_service.notification_handler = send_backup_notification
```

## API Reference

### Data Models

#### BackupMetadata
```python
@dataclass
class BackupMetadata:
    backup_id: str
    backup_type: str  # full, incremental, configuration, filesystem
    timestamp: datetime
    database_type: str
    compression: bool
    encrypted: bool
    source_paths: List[str]
    total_size: int
    file_count: int
    checksum: str
    status: str  # completed, failed, in_progress
    error_message: Optional[str] = None
```

#### BackupSchedule
```python
@dataclass
class BackupSchedule:
    name: str
    backup_type: str
    schedule_expression: str  # daily, weekly, cron
    retention_days: int
    enabled: bool
    compression: bool = True
    encryption: bool = False
    notification_email: Optional[str] = None
```

#### RestoreResult
```python
@dataclass
class RestoreResult:
    restore_id: str
    timestamp: datetime
    source_backup: str
    target_location: str
    status: str  # completed, failed, partial
    restored_files: int
    restored_size: int
    warnings: List[str]
    errors: List[str]
```

### Service Methods

#### Backup Methods
- `create_database_backup()` - Create database backup
- `create_configuration_backup()` - Create configuration backup  
- `create_file_system_backup()` - Create file system backup
- `create_full_system_backup()` - Create complete system backup
- `create_point_in_time_backup()` - Create point-in-time backup
- `schedule_backup()` - Schedule automated backup

#### Restore Methods
- `restore_database()` - Restore database from backup
- `restore_configuration()` - Restore configuration
- `restore_file_system()` - Restore file system
- `disaster_recovery_restore()` - Full disaster recovery

#### Management Methods
- `verify_backup()` - Verify backup integrity
- `get_backup_list()` - List all backups
- `get_backup_info()` - Get backup details
- `cleanup_old_backups()` - Clean old backups
- `get_system_health_report()` - Generate health report
- `export_backup_report()` - Export backup report

## Examples

### Complete Backup and Restore Workflow

```python
#!/usr/bin/env python3
"""
Complete backup and restore workflow example.
"""

import asyncio
from app.utils.backup_restore_service import backup_service

async def full_backup_workflow():
    """Complete backup workflow with verification."""
    
    print("Starting full system backup workflow...")
    
    # 1. Create full system backup
    backup_id = await backup_service.create_full_system_backup(
        backup_name=f"full_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        compress=True,
        encrypt=True,
        include_configs=True,
        include_files=True
    )
    
    print(f"Backup created: {backup_id}")
    
    # 2. Verify backup integrity
    is_valid = await backup_service.verify_backup(backup_id)
    if is_valid:
        print("✅ Backup verification passed")
    else:
        print("❌ Backup verification failed")
        return False
    
    # 3. Test restore in isolated environment
    # (In production, test on separate environment)
    try:
        restore_result = await backup_service.restore_database(
            backup_id=backup_id,
            verify_checksum=True
        )
        print(f"Restore test completed: {restore_result.status}")
    except Exception as e:
        print(f"Restore test failed: {e}")
        return False
    
    # 4. Generate health report
    health_report = backup_service.get_system_health_report()
    print(f"System health: {health_report['backup_service_status']}")
    
    return True

async def disaster_recovery_workflow():
    """Disaster recovery workflow."""
    
    print("Starting disaster recovery workflow...")
    
    # 1. Identify backup IDs for recovery
    backups = backup_service.get_backup_list()
    recovery_backups = [
        b.backup_id for b in backups 
        if b.status == "completed" and b.backup_type in ["configuration", "database"]
    ][:3]  # Take most recent 3 completed backups
    
    print(f"Selected backups for recovery: {recovery_backups}")
    
    # 2. Perform disaster recovery
    results = await backup_service.disaster_recovery_restore(
        backup_ids=recovery_backups,
        validate_before_restore=True,
        create_recovery_snapshot=True
    )
    
    # 3. Check results
    successful = sum(1 for r in results.values() if r.status == "completed")
    total = len(results)
    
    print(f"Recovery completed: {successful}/{total} successful")
    
    # 4. Verify system health after recovery
    health_report = backup_service.get_system_health_report()
    print(f"Post-recovery health: {health_report['backup_service_status']}")
    
    return successful == total

# Run workflows
if __name__ == "__main__":
    asyncio.run(full_backup_workflow())
    asyncio.run(disaster_recovery_workflow())
```

## Conclusion

The backup and restore utilities provide comprehensive data protection and recovery capabilities for your application. With support for multiple backup types, automated scheduling, verification, and disaster recovery, you can ensure your data is protected and recoverable in any scenario.

For additional support or custom requirements, refer to the API documentation or contact the development team.
