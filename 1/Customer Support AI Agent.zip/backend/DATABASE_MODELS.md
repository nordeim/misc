# SQLAlchemy Database Models Documentation

## Overview

This document provides comprehensive documentation for the SQLAlchemy database models used in the application. The models provide a complete ORM layer for user management, chat sessions, messages, and conversation memory.

## Database Structure

### Core Models

1. **UserORM** - User authentication and management
2. **SessionORM** - Chat conversation sessions
3. **MessageORM** - Individual messages within sessions
4. **MemoryORM** - Long-term conversation memory and context

### Relationships

```
User (1) -----> (N) Session (1) -----> (N) Message
                |                     |
                |                     |
                +-------> (N) Memory <-+
```

- **User -> Sessions**: One-to-many relationship
- **Session -> Messages**: One-to-many relationship with cascade delete
- **Session -> Memories**: One-to-many relationship with cascade delete
- **All relationships include proper foreign key constraints**

## Model Details

### UserORM

**Purpose**: Handles user authentication and profile management.

**Key Features**:
- Email and username uniqueness constraints
- Password hashing (to be implemented with proper hashing)
- User status management (active, verified, superuser)
- Profile information (avatar, bio, timezone, language)
- Login tracking and statistics

**Key Fields**:
- `id` (String, Primary Key): Unique user identifier
- `email` (String, Unique): User email address
- `username` (String, Unique): Unique username
- `hashed_password` (String): Hashed password
- `is_active` (Boolean): Account active status
- `is_verified` (Boolean): Email verification status
- `login_count` (Integer): Total login count
- `last_login` (DateTime): Last login timestamp

**Important Methods**:
- `verify_login()`: Updates login statistics
- `get_by_email()`, `get_by_username()`: Query methods
- `create_user()`: User creation with validation

### SessionORM

**Purpose**: Manages chat conversation sessions.

**Key Features**:
- Session title and type classification
- LLM model configuration storage
- Message and token usage tracking
- Session status management (active, closed, archived)
- User feedback and rating system

**Key Fields**:
- `id` (String, Primary Key): Unique session identifier
- `user_id` (String, Foreign Key): References UserORM.id
- `title` (String): Session title
- `status` (String): Session status ('active', 'closed', 'archived')
- `model_name` (String): LLM model used
- `provider` (String): AI provider (openai, anthropic, etc.)
- `message_count` (Integer): Total messages in session
- `token_count` (Integer): Total tokens used

**Important Methods**:
- `add_message()`, `add_memory()`: Relationship management
- `close_session()`, `archive_session()`: Status management
- `get_context_messages()`: Get conversation context
- `set_feedback()`: Store user feedback

### MessageORM

**Purpose**: Stores individual messages within sessions.

**Key Features**:
- Role-based message classification (user, assistant, system)
- Rich content support (text, attachments)
- LLM usage tracking (tokens, costs, response time)
- Message editing and soft deletion
- User feedback and processing status

**Key Fields**:
- `id` (String, Primary Key): Unique message identifier
- `session_id` (String, Foreign Key): References SessionORM.id
- `role` (String): Message role ('user', 'assistant', 'system')
- `content` (Text): Message content
- `token_count` (Integer): Total tokens used
- `total_cost` (Float): Total cost for this message
- `processing_status` (String): Message processing status
- `is_edited` (Boolean): Whether message was edited
- `user_feedback` (String): User feedback ('like', 'dislike', etc.)

**Important Methods**:
- `set_usage_stats()`: Store token usage information
- `set_costs()`: Store cost information
- `edit_content()`: Update message content
- `soft_delete()`: Mark message as deleted without removing
- `to_conversation_format()`: Convert for LLM processing

### MemoryORM

**Purpose**: Provides long-term conversation memory and context.

**Key Features**:
- Importance and confidence scoring
- Memory categorization and tagging
- Automatic expiration and decay
- Search functionality
- Persistent vs temporary memory

**Key Fields**:
- `id` (String, Primary Key): Unique memory identifier
- `session_id` (String, Foreign Key): References SessionORM.id
- `key` (String): Memory identifier key
- `value` (Text): Memory content
- `memory_type` (String): Type ('conversation', 'preference', etc.)
- `importance_score` (Float): Importance rating (0.0-1.0)
- `confidence_score` (Float): Confidence rating (0.0-1.0)
- `is_persistent` (Boolean): Whether memory should be retained
- `expires_at` (DateTime): Memory expiration time

**Important Methods**:
- `access()`: Record memory access
- `set_importance()`: Update importance score
- `get_decay_factor()`: Calculate memory decay over time
- `search_memories()`: Search memory content
- `get_important_memories()`: Retrieve high-importance memories

## Database Configuration

### Engine Configuration

The database uses both async and sync engines:

- **Async Engine**: For FastAPI endpoints and async operations
- **Sync Engine**: For Alembic migrations and sync operations

**Configuration Features**:
- Connection pooling with health checks
- SQLite optimizations (WAL mode, foreign keys, etc.)
- Connection recycling
- Error handling and reconnection

### Connection Management

**Async Session Management**:
```python
async with get_db() as db:
    # Use session
    user = await create_user(db, user_data)
    await db.commit()
```

**Sync Session Management**:
```python
with get_sync_db() as db:
    # Use session for migrations
    db.execute("ALTER TABLE ...")
    db.commit()
```

## Usage Patterns

### Creating Users

```python
from app.models.schemas import UserCreate

user_data = UserCreate(
    email="user@example.com",
    username="testuser",
    full_name="Test User"
)

user = UserORM.create_user(db, **user_data.dict())
```

### Managing Sessions

```python
# Create session
session = SessionORM.create_session(
    db,
    user_id=user_id,
    title="My Chat Session",
    model_name="gpt-3.5-turbo"
)

# Add messages
message = MessageORM.create_message(
    db,
    session_id=session.id,
    role="user",
    content="Hello!"
)

session.add_message(message)
```

### Storing Memory

```python
# Store important information
memory = MemoryORM.create_memory(
    db,
    session_id=session.id,
    key="user_preference",
    value="Prefers concise responses",
    memory_type="user_preference",
    importance_score=0.8
)
```

### Querying Data

```python
# Get user's sessions
sessions = SessionORM.get_active_sessions(db, user_id)

# Get conversation context
messages = MessageORM.get_recent_messages(db, session_id, limit=10)

# Search memories
memories = MemoryORM.search_memories(db, session_id, "preference")
```

## Validation and Constraints

### Database Constraints

- **Primary Keys**: All models use UUID strings as primary keys
- **Foreign Keys**: Cascade delete for dependent records
- **Unique Constraints**: Email and username uniqueness
- **Check Constraints**: Importance scores (0.0-1.0), ratings (1-5)

### Data Validation

- **Pydantic Schemas**: Provide request/response validation
- **Field Validation**: Length limits, regex patterns, value ranges
- **Required Fields**: Proper nullability constraints

## Performance Considerations

### Indexing Strategy

- **User**: email, username indexes
- **Session**: user_id, status, last_activity indexes
- **Message**: session_id, role, created_at indexes
- **Memory**: session_id, key, memory_type, importance_score indexes

### Query Optimization

- **Eager Loading**: Use `joinedload()` for relationships
- **Pagination**: Implement limit/offset for large result sets
- **Selective Columns**: Use `load_only()` for specific fields
- **Connection Pooling**: Reuse database connections

### Memory Management

- **Memory Decay**: Automatic decay based on access patterns
- **Expiration**: Time-based memory expiration
- **Importance Filtering**: Query by importance scores
- **Batch Operations**: Bulk insert/update operations

## Migration Support

### Alembic Integration

The models are designed to work seamlessly with Alembic for database migrations:

```bash
# Generate migration
alembic revision --autogenerate -m "Add user sessions"

# Apply migrations
alembic upgrade head
```

### Schema Evolution

- **Backward Compatibility**: Old fields remain functional
- **New Field Additions**: Use default values
- **Field Deprecation**: Mark fields as deprecated but keep functional

## Testing

### Unit Testing

Each model includes comprehensive test methods:

```python
def test_user_creation():
    user = UserORM.create_user(db, email="test@example.com")
    assert user.email == "test@example.com"
    assert user.is_active == True
```

### Integration Testing

Example integration test:

```python
async def test_complete_flow():
    async with get_db() as db:
        # Create user
        user = await create_user_example(db, user_data)
        
        # Create session
        session = await create_chat_session_example(db, user.id, "Test")
        
        # Add messages
        message = await add_user_message_example(db, session.id, "Hello")
        
        # Verify relationships
        assert message.session_id == session.id
        assert session.user_id == user.id
```

## Best Practices

### 1. Error Handling

- Always use try/catch blocks for database operations
- Rollback transactions on errors
- Log database errors with proper context

### 2. Session Management

- Use context managers for automatic cleanup
- Avoid long-running transactions
- Commit changes explicitly

### 3. Data Validation

- Validate data before database operations
- Use Pydantic schemas for API validation
- Check constraints in application code

### 4. Performance

- Use appropriate indexes for frequent queries
- Implement pagination for large result sets
- Monitor query performance and optimize

### 5. Security

- Always hash passwords before storage
- Use parameterized queries to prevent SQL injection
- Implement proper access control

## Extension Guidelines

### Adding New Models

1. Inherit from `Base` and `ORMBase`
2. Define relationships with proper foreign keys
3. Add appropriate indexes
4. Create corresponding Pydantic schemas
5. Update database initialization

### Modifying Existing Models

1. Use Alembic for schema changes
2. Maintain backward compatibility
3. Update schemas and validation
4. Add migration scripts

This documentation provides a comprehensive guide to using the SQLAlchemy models effectively in the application.