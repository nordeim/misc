# Escalation Tool Documentation

## Overview

The Enhanced Escalation Tool is a comprehensive system for intelligent human handoff in customer support conversations. It provides sophisticated escalation decision-making, queue management, analytics, and human handoff procedures.

## Features

### 1. Enhanced Escalation Decision Logic

- **Multi-factor Analysis**: Considers sentiment, keywords, confidence, complexity, conversation length, and urgency
- **Intelligent Scoring**: Weighted scoring system with configurable thresholds
- **Context-aware Decisions**: Takes into account conversation history, previous escalations, and customer tier

### 2. Escalation Triggers and Criteria

- **Sentiment Analysis**: Detects frustration, anger, and negative emotions
- **Keyword Detection**: Categorized escalation keywords with different weights
- **Confidence-based Triggers**: Escalates when AI confidence is low
- **Complexity Assessment**: Identifies technical, business, and compliance complexity
- **Conversation Length**: Triggers escalation for lengthy conversations
- **Urgency Indicators**: Detects time-sensitive and critical issues

### 3. Human Handoff Routing and Queue Management

- **Queue Management**: Create and manage escalation queues by department
- **Smart Routing**: Routes escalations to appropriate queues based on issue type
- **Load Balancing**: Automatically distributes escalations based on queue capacity
- **Priority Assignment**: Assigns priority levels (Low, Medium, High, Critical, Urgent)
- **Business Hours**: Configurable business hours and availability

### 4. Escalation Analytics and Reporting

- **Performance Metrics**: Track response times, resolution times, satisfaction scores
- **Trend Analysis**: Monitor escalation patterns and trends over time
- **Queue Performance**: Compare performance across different queues
- **SLA Tracking**: Monitor service level agreement compliance
- **Customer Satisfaction**: Track and analyze customer satisfaction metrics

### 5. Escalation Algorithms

#### Confidence-based Escalation
```python
# Escalates when AI confidence is below threshold
if rag_confidence < 0.6:
    escalation_score += (0.6 - rag_confidence) * 0.5
```

#### Keyword-based Escalation
```python
# Categorized keywords with different weights
escalation_keywords = {
    'frustration': ['angry', 'frustrated', 'hate'],
    'urgency': ['urgent', 'emergency', 'asap'],
    'escalation_request': ['human', 'manager', 'supervisor'],
    'financial_legal': ['refund', 'fraud', 'legal'],
    'technical_complex': ['api', 'integration', 'debug'],
    'compliance': ['gdpr', 'privacy', 'audit']
}
```

#### Complexity Assessment
- Technical complexity (APIs, integrations, development)
- Business impact (revenue, enterprise, contracts)
- Compliance risk (legal, regulatory, data protection)

#### User Sentiment Analysis
- Pattern-based sentiment detection
- Emotional indicators (exclamation marks, ALL CAPS)
- Negative sentiment scoring

### 6. Escalation Management

#### Queue Creation and Management
```python
queue = EscalationQueueORM(
    name="Technical Support",
    department="IT Support",
    capacity=15,
    max_wait_time_minutes=15,
    is_active=True
)
```

#### Priority Assignment
```python
priority_levels = {
    'critical': EscalationPriority.CRITICAL,  # Compliance/legal issues
    'urgent': EscalationPriority.URGENT,      # High urgency
    'high': EscalationPriority.HIGH,          # Complex issues
    'medium': EscalationPriority.MEDIUM,      # Standard escalation
    'low': EscalationPriority.LOW            # Minor issues
}
```

#### Status Tracking
- PENDING: Escalation created, waiting for assignment
- ROUTED: Assigned to agent
- IN_PROGRESS: Agent actively working
- RESOLVED: Issue resolved
- CANCELLED: Escalation cancelled
- ESCALATED_AGAIN: Further escalation needed

### 7. Escalation Policies

#### Policy Configuration
```python
policy = EscalationPolicyORM(
    name="Frustrated Customer Policy",
    policy_type="sentiment",
    rules={
        'sentiment_threshold': 0.7,
        'frustration_keywords': True
    },
    thresholds={'score': 0.6},
    target_department="Customer Service",
    priority_score=5
)
```

#### Policy Types
- **Sentiment**: Based on customer emotion analysis
- **Keywords**: Based on trigger word detection
- **Complexity**: Based on technical/business complexity
- **Financial**: Based on billing and payment issues
- **Compliance**: Based on legal and regulatory risks

### 8. Escalation Analytics

#### Key Metrics
- Total escalations
- Average response time
- Average resolution time
- Customer satisfaction score
- First contact resolution rate
- Abandonment rate
- Queue utilization

#### Performance Tracking
```python
metrics = await escalation_tool.get_escalation_metrics(
    start_date=datetime.utcnow() - timedelta(days=30),
    end_date=datetime.utcnow(),
    queue_id=optional_queue_id
)
```

### 9. Human Handoff Procedures

#### Automated Handoff Process
1. **Decision Making**: Tool analyzes conversation and determines escalation need
2. **Queue Selection**: Smart routing to appropriate department/queue
3. **Priority Assignment**: Assigns appropriate priority level
4. **Agent Assignment**: Routes to available agent or creates ticket
5. **Context Transfer**: Preserves conversation history and context
6. **Notification**: Alerts relevant personnel

#### Context Preservation
- Conversation history
- Customer information
- Previous escalations
- Issue details
- Sentiment analysis results
- Technical complexity assessment

#### Resolution Feedback
```python
await escalation_tool.resolve_escalation(
    escalation_id=escalation_id,
    resolution_notes="Issue resolved by updating customer preferences",
    satisfaction_score=5,
    customer_feedback="Excellent service, very helpful!"
)
```

## Usage Examples

### Basic Escalation Check
```python
from app.tools.escalation_tool import EscalationTool
from app.agents.chat_agent import AgentContext

# Initialize escalation tool
escalation_tool = EscalationTool(db_session=db_session)

# Check if escalation is needed
should_escalate = await escalation_tool.check_escalation(
    message="I'm really frustrated with this service!",
    context=AgentContext(
        session_id="session_123",
        user_id="user_456",
        message_history=[],
        current_file_attachments=[]
    ),
    rag_results={"confidence": 0.8}
)

print(f"Should escalate: {should_escalate}")
```

### Comprehensive Escalation Decision
```python
# Get detailed escalation decision
decision = await escalation_tool.get_escalation_decision(
    message="This is urgent - our production system is down!",
    context=context,
    rag_results=rag_results
)

print(f"Should escalate: {decision.should_escalate}")
print(f"Priority: {decision.priority_level}")
print(f"Recommended queue: {decision.recommended_queue_id}")
print(f"Reasons: {decision.reasons}")
print(f"Alternative actions: {decision.alternative_actions}")
```

### Create Escalation Case
```python
# Create escalation case in database
escalation_case = await escalation_tool.create_escalation_case(
    escalation_decision=decision,
    escalation_context=escalation_context,
    session_id="session_123",
    user_id="user_456"
)

if escalation_case:
    print(f"Escalation created: {escalation_case.id}")
```

### Assign to Human Agent
```python
# Assign escalation to human agent
success = await escalation_tool.assign_escalation_to_agent(
    escalation_id=escalation_case.id,
    agent_id="agent_789",
    agent_name="John Smith"
)

if success:
    print("Escalation assigned successfully")
```

### Resolve Escalation
```python
# Mark escalation as resolved
success = await escalation_tool.resolve_escalation(
    escalation_id=escalation_case.id,
    resolution_notes="Customer issue resolved by resetting password",
    satisfaction_score=4,
    customer_feedback="Good service, but took a while"
)

if success:
    print("Escalation resolved")
```

### Get Analytics
```python
# Get escalation metrics
metrics = await escalation_tool.get_escalation_metrics(
    start_date=datetime.utcnow() - timedelta(days=30),
    end_date=datetime.utcnow()
)

print(f"Total escalations: {metrics.total_escalations}")
print(f"Avg resolution time: {metrics.avg_resolution_time_minutes}")
print(f"Customer satisfaction: {metrics.customer_satisfaction_avg}")

# Get queue performance
queue_performance = await escalation_tool.get_queue_performance()
for queue in queue_performance:
    print(f"{queue.queue_name}: {queue.customer_satisfaction_score:.2f} satisfaction")

# Get trends
trends = await escalation_tool.get_escalation_trends(days=30)
print(f"Daily trends: {trends['daily_trends']}")
```

## Database Schema

### Tables Created

1. **escalation_queues**: Queue configuration and management
2. **escalation_policies**: Escalation rules and criteria
3. **escalations**: Individual escalation cases
4. **escalation_analytics**: Performance metrics and analytics

### Key Relationships

- Escalations belong to Queues and Policies
- Analytics records link to Escalations
- Policies reference target Queues

## Configuration

### Thresholds
```python
self.confidence_thresholds = {
    'high': 0.8,      # High confidence threshold
    'medium': 0.6,    # Medium confidence threshold
    'low': 0.4,       # Low confidence threshold
    'critical': 0.9   # Critical confidence threshold
}
```

### Weights
```python
self.escalation_weights = {
    'sentiment': 0.25,         # Sentiment analysis weight
    'keywords': 0.20,          # Keyword analysis weight
    'confidence': 0.20,        # AI confidence weight
    'complexity': 0.15,        # Issue complexity weight
    'conversation_length': 0.10, # Conversation length weight
    'urgency': 0.10           # Urgency detection weight
}
```

### Conversation Thresholds
```python
self.max_conversation_turns = 15       # Standard escalation threshold
self.critical_conversation_turns = 25  # Critical escalation threshold
```

## Integration with Chat Agent

### Enhanced Integration
```python
# In CustomerSupportAgent
def initialize_escalation_tool(self, db_session: Session):
    self.escalation_tool = EscalationTool(db_session=db_session)
    # Initialize default policies and queues
    await self.escalation_tool.initialize_default_policies_and_queues()
```

### Tool Execution
```python
# Enhanced escalation tool call
elif tool_name == "escalation":
    decision = await escalation_tool.get_escalation_decision(
        message=message,
        context=context,
        rag_results=rag_results
    )
    
    return {
        "should_escalate": decision.should_escalate,
        "priority": decision.priority_level.value,
        "immediate_escalation": decision.priority_level.value in ['URGENT', 'CRITICAL']
    }
```

## Best Practices

### 1. Queue Management
- Set appropriate capacity limits
- Configure business hours
- Use skill requirements for routing
- Monitor queue utilization

### 2. Policy Configuration
- Start with conservative thresholds
- Monitor and adjust based on metrics
- Use different policies for different departments
- Regular policy review and optimization

### 3. Agent Assignment
- Match agent skills to queue requirements
- Monitor agent workload
- Use load balancing for efficiency
- Track agent performance

### 4. Analytics and Optimization
- Regular review of escalation metrics
- A/B test different policies
- Monitor customer satisfaction
- Optimize based on performance data

### 5. Context Preservation
- Always transfer conversation context
- Include customer history
- Preserve escalation reasoning
- Maintain communication continuity

## Error Handling

### Database Errors
```python
try:
    escalation = await escalation_tool.create_escalation_case(...)
except SQLAlchemyError as e:
    logger.error(f"Database error creating escalation: {e}")
    # Fallback to alternative escalation method
```

### Queue Unavailability
```python
if not recommended_queue:
    # Fallback to default queue
    fallback_queue = await escalation_tool._get_best_available_queue(
        EscalationPriority.MEDIUM
    )
```

### Tool Integration
```python
try:
    escalation_decision = await escalation_tool.get_escalation_decision(...)
except Exception as e:
    logger.error(f"Escalation tool error: {e}")
    # Use simplified escalation logic
    return {"should_escalate": False, "error": str(e)}
```

## Monitoring and Alerts

### Key Alerts
- High escalation rate
- Long response times
- Low customer satisfaction
- Queue overload
- System errors

### Metrics Dashboard
- Real-time escalation metrics
- Queue performance comparison
- Trend analysis
- Agent performance tracking

## Future Enhancements

### Planned Features
- Machine learning-based escalation prediction
- Multi-language support
- Integration with external CRM systems
- Advanced sentiment analysis
- Predictive analytics
- Automated agent scheduling

### API Extensions
- REST API for external integration
- Webhook support for notifications
- Batch operations for bulk management
- Advanced filtering and search

This enhanced escalation tool provides a comprehensive solution for intelligent human handoff in customer support, with sophisticated decision-making, queue management, analytics, and continuous optimization capabilities.