"""
Comprehensive Embedding Service Integration Example.

This script demonstrates the complete usage of the advanced embedding service
with all its features:
- Model management and loading
- Single and batch embedding generation
- Similarity calculations and clustering
- Performance monitoring and analytics
- Model optimization and memory management
- Integration with RAG workflows

Features demonstrated:
- Basic embedding generation
- Advanced batch processing
- Model performance monitoring
- Memory optimization
- Analytics and insights
- Error handling and recovery
- Utility functions for validation and analysis

Author: AI Agent System
Version: 2.0.0
"""

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import List, Dict, Any
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import embedding service components
from app.services.embedding_service import (
    EmbeddingService, EmbeddingResult, BatchProcessingResult
)
from app.services.embedding_utils import (
    TextPreprocessingUtils, SimilarityUtils, ValidationUtils,
    AnalyticsUtils, VisualizationUtils, ExportImportUtils
)
from app.services.batch_processing import (
    BatchProcessor, Priority, ProcessingMode, create_batch_processor
)
from app.services.model_management import (
    ModelManager as AdvancedModelManager, ModelRegistry
)

# ==============================================================================
# DEMONSTRATION FUNCTIONS
# ==============================================================================

async def demonstrate_basic_embedding_generation():
    """Demonstrate basic embedding generation."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Basic Embedding Generation")
    logger.info("=" * 60)
    
    async with EmbeddingService() as service:
        # Test texts
        texts = [
            "The quick brown fox jumps over the lazy dog.",
            "Machine learning is a subset of artificial intelligence.",
            "Natural language processing enables computers to understand text.",
            "Vector embeddings represent semantic meaning in numerical form."
        ]
        
        logger.info(f"Generating embeddings for {len(texts)} texts...")
        
        # Generate single embedding
        single_result = await service.generate_embedding(texts[0])
        logger.info(f"Single embedding generated:")
        logger.info(f"  - Dimension: {single_result.dimension}")
        logger.info(f"  - Processing time: {single_result.processing_time:.3f}s")
        logger.info(f"  - Cache hit: {single_result.cache_hit}")
        
        # Generate batch embeddings
        batch_result = await service.generate_embeddings_batch(texts)
        logger.info(f"Batch embeddings generated:")
        logger.info(f"  - Total texts: {batch_result.total_texts}")
        logger.info(f"  - Successful: {batch_result.successful}")
        logger.info(f"  - Failed: {batch_result.failed}")
        logger.info(f"  - Processing time: {batch_result.processing_time:.3f}s")
        logger.info(f"  - Memory usage: {batch_result.memory_usage_mb:.2f}MB")
        
        # Test embedding validation
        embeddings = [result.embedding for result in batch_result.results]
        validation_report = await service.validate_embeddings(embeddings)
        logger.info(f"Embedding validation:")
        logger.info(f"  - Valid: {validation_report['valid']}")
        logger.info(f"  - Quality score: {validation_report.get('quality_score', 0):.3f}")
        if validation_report.get('issues'):
            logger.info(f"  - Issues: {validation_report['issues']}")
        
        return batch_result

async def demonstrate_similarity_analysis(service: EmbeddingService):
    """Demonstrate similarity analysis capabilities."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Similarity Analysis")
    logger.info("=" * 60)
    
    # Generate embeddings for similarity analysis
    texts = [
        "Dogs are loyal animals that make great pets.",
        "Cats are independent pets that like to nap.",
        "Dogs and cats are both popular household pets.",
        "Machine learning uses algorithms to learn from data.",
        "Deep learning is a subset of machine learning using neural networks.",
        "Natural language processing helps computers understand human language.",
        "Vector databases store embeddings for fast similarity search.",
        "Embedding models convert text into numerical representations."
    ]
    
    logger.info(f"Analyzing similarities among {len(texts)} texts...")
    
    # Generate embeddings
    results = await service.generate_embeddings_batch(texts)
    embeddings_data = [(text, result.embedding) for text, result in zip(texts, results.results)]
    
    # Calculate pairwise similarities
    logger.info("Calculating pairwise similarities...")
    similarity_matrix = SimilarityUtils.calculate_pairwise_similarity(
        [emb for _, emb in embeddings_data],
        metric="cosine"
    )
    
    logger.info(f"Similarity matrix shape: {similarity_matrix.shape}")
    
    # Find most similar pairs
    logger.info("Finding most similar text pairs...")
    for i, (text1, _) in enumerate(embeddings_data):
        query_embedding = embeddings_data[i][1]
        candidates = embeddings_data[:i] + embeddings_data[i+1:]  # Exclude self
        
        similar_texts = SimilarityUtils.find_most_similar(
            query_embedding, 
            [(text, emb) for text, emb in candidates],
            top_k=2,
            metric="cosine"
        )
        
        if similar_texts:
            logger.info(f"Most similar to '{text1[:50]}...':")
            for similar in similar_texts[:2]:
                logger.info(f"  - '{similar.id2[:50]}...' (similarity: {similar.similarity_score:.3f})")
    
    # Clustering analysis
    logger.info("Performing clustering analysis...")
    clustering_result = SimilarityUtils.calculate_clustering_similarity(
        embeddings_data,
        n_clusters=3,
        algorithm="kmeans"
    )
    
    logger.info(f"Clustering results:")
    logger.info(f"  - Number of clusters: {clustering_result['n_clusters']}")
    logger.info(f"  - Average cluster similarity: {clustering_result['average_cluster_similarity']:.3f}")
    if clustering_result.get('silhouette_score'):
        logger.info(f"  - Silhouette score: {clustering_result['silhouette_score']:.3f}")
    
    return embeddings_data, similarity_matrix

async def demonstrate_batch_processing():
    """Demonstrate advanced batch processing capabilities."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Advanced Batch Processing")
    logger.info("=" * 60)
    
    async with EmbeddingService() as embedding_service:
        processor = await create_batch_processor(
            embedding_service, 
            max_workers=4,
            processing_mode=ProcessingMode.PARALLEL
        )
        
        await processor.initialize()
        
        try:
            # Create large dataset
            logger.info("Creating large dataset for batch processing...")
            large_dataset = [
                f"Document {i}: This is a sample document containing various content about topic {i % 10}."
                for i in range(200)
            ]
            
            # Progress tracking
            progress_updates = []
            
            def progress_callback(progress):
                progress_updates.append(progress)
                if len(progress_updates) % 10 == 0:
                    logger.info(f"Progress: {progress.progress_percentage:.1f}% "
                              f"({progress.processed_items}/{progress.total_items})")
            
            # Submit batch job
            logger.info("Submitting batch job...")
            job_id = await processor.submit_batch(
                texts=large_dataset,
                priority=Priority.HIGH,
                metadata={"description": "Large batch processing demo"}
            )
            
            logger.info(f"Batch job submitted: {job_id}")
            processor.add_progress_callback(job_id, progress_callback)
            
            # Monitor progress
            start_time = time.time()
            while True:
                job = await processor.get_job_status(job_id)
                
                if job and job.status in [BatchStatus.COMPLETED, BatchStatus.FAILED]:
                    break
                
                await asyncio.sleep(1)
            
            processing_time = time.time() - start_time
            
            # Get final results
            job = await processor.get_job_status(job_id)
            logger.info(f"Batch processing completed:")
            logger.info(f"  - Status: {job.status}")
            logger.info(f"  - Total items: {job.total_items}")
            logger.info(f"  - Successful: {job.successful_items}")
            logger.info(f"  - Failed: {job.failed_items}")
            logger.info(f"  - Processing time: {processing_time:.2f}s")
            logger.info(f"  - Throughput: {job.successful_items/processing_time:.2f} items/second")
            logger.info(f"  - Progress updates: {len(progress_updates)}")
            
            # Performance report
            perf_report = await processor.get_performance_report()
            logger.info("Performance report:")
            logger.info(f"  - Uptime: {perf_report['uptime_hours']:.2f} hours")
            logger.info(f"  - Total jobs: {perf_report['total_jobs']}")
            logger.info(f"  - Active workers: {perf_report['worker_performance']['active_workers']}")
            logger.info(f"  - Average throughput: {perf_report['statistics']['average_throughput']:.2f} items/second")
            
            return job
            
        finally:
            await processor.shutdown()

async def demonstrate_model_management():
    """Demonstrate model management capabilities."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Model Management")
    logger.info("=" * 60)
    
    manager = AdvancedModelManager()
    await manager.initialize()
    
    try:
        # Get system status
        logger.info("Getting system status...")
        system_status = await manager.get_system_status()
        logger.info("System status:")
        logger.info(f"  - Loaded models: {system_status['loaded_models']['count']}")
        logger.info(f"  - Registry models: {system_status['registry']['total_models']}")
        logger.info(f"  - System status: {system_status['system']['status']}")
        
        # Search for models
        logger.info("Searching for models...")
        models = await manager.search_models(
            query="sentence-transformers",
            min_downloads=1000
        )
        
        logger.info(f"Found {len(models)} models:")
        for model in models[:3]:  # Show top 3
            logger.info(f"  - {model.model_id}: {model.metadata.description}")
            logger.info(f"    Priority: {model.priority}, Downloads: {model.metadata.downloads}")
        
        # Load and test a model
        logger.info("Loading model for testing...")
        start_time = time.time()
        model = await manager.load_model("sentence-transformers/all-MiniLM-L6-v2")
        load_time = time.time() - start_time
        
        logger.info(f"Model loaded in {load_time:.2f} seconds")
        
        # Test model performance
        logger.info("Testing model performance...")
        test_texts = [
            "This is a test sentence.",
            "Another test document for embedding.",
            "Machine learning is fascinating."
        ]
        
        # Generate embeddings to create performance data
        from app.services.embedding_service import EmbeddingService
        async with EmbeddingService() as embedding_service:
            # Force use of specific model
            for text in test_texts:
                await embedding_service.generate_embedding(text, model_name="sentence-transformers/all-MiniLM-L6-v2")
        
        # Get performance metrics
        performance = await manager.get_model_performance("sentence-transformers/all-MiniLM-L6-v2")
        if performance:
            logger.info("Performance metrics:")
            logger.info(f"  - Load time: {performance.load_time_seconds:.3f}s")
            logger.info(f"  - Inference time: {performance.inference_time_ms:.1f}ms")
            logger.info(f"  - Memory usage: {performance.memory_usage_mb:.1f}MB")
            logger.info(f"  - Error rate: {performance.error_rate:.3f}")
        
        # Compare models if multiple are available
        if len(models) > 1:
            logger.info("Comparing model performance...")
            model_ids = [m.model_id for m in models[:2]]
            comparison = await manager.compare_models(model_ids)
            
            logger.info("Model comparison:")
            for model_id, metrics in comparison["models"].items():
                logger.info(f"  - {model_id}:")
                logger.info(f"    Inference time: {metrics['inference_time_ms']:.1f}ms")
                logger.info(f"    Memory usage: {metrics['memory_usage_mb']:.1f}MB")
                if metrics.get('issues'):
                    logger.info(f"    Issues: {metrics['issues']}")
        
        return manager
        
    finally:
        await manager.shutdown()

async def demonstrate_analytics_and_insights(service: EmbeddingService):
    """Demonstrate analytics and insights generation."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Analytics and Insights")
    logger.info("=" * 60)
    
    # Generate a variety of embeddings for analysis
    logger.info("Generating embeddings for analytics...")
    diverse_texts = [
        "Apple is a fruit that grows on trees.",
        "The stock market went up today.",
        "Machine learning algorithms require data.",
        "Natural language processing is fascinating.",
        "Climate change affects global weather patterns.",
        "Python is a popular programming language.",
        "Deep learning uses neural networks.",
        "Data science involves statistics and programming.",
        "Artificial intelligence is transforming industries.",
        "Vector embeddings represent text numerically."
    ]
    
    # Generate embeddings
    batch_result = await service.generate_embeddings_batch(diverse_texts)
    embeddings_data = [(text, result.embedding) for text, result in zip(diverse_texts, batch_result.results)]
    
    # Comprehensive analysis
    logger.info("Performing comprehensive analytics...")
    analytics_report = AnalyticsUtils.analyze_embedding_space(embeddings_data)
    
    logger.info("Analytics Summary:")
    summary = analytics_report.summary
    logger.info(f"  - Total embeddings: {summary['total_embeddings']}")
    logger.info(f"  - Dimension: {summary['dimension']}")
    logger.info(f"  - Memory usage: {summary['memory_usage_mb']:.2f}MB")
    
    logger.info("Quality Metrics:")
    quality = analytics_report.quality_metrics
    logger.info(f"  - Valid: {quality['valid']}")
    logger.info(f"  - Quality score: {quality['quality_score']:.3f}")
    if quality.get('issues'):
        logger.info(f"  - Issues: {quality['issues']}")
    
    logger.info("Distribution Analysis:")
    distribution = analytics_report.distribution_analysis
    global_stats = distribution['global_stats']
    logger.info(f"  - Mean value: {global_stats['mean']:.3f}")
    logger.info(f"  - Standard deviation: {global_stats['std']:.3f}")
    logger.info(f"  - Skewness: {global_stats['skewness']:.3f}")
    
    logger.info("Outlier Detection:")
    outliers = analytics_report.outlier_detection
    outlier_counts = outliers['outlier_counts']
    logger.info(f"  - Z-score outliers: {outlier_counts['z_score_method']}")
    logger.info(f"  - IQR outliers: {outlier_counts['iqr_method']}")
    
    if analytics_report.clustering_analysis:
        logger.info("Clustering Analysis:")
        clustering = analytics_report.clustering_analysis
        logger.info(f"  - Clusters found: {clustering['n_clusters']}")
        logger.info(f"  - Average cluster similarity: {clustering['average_cluster_similarity']:.3f}")
        if clustering.get('silhouette_score'):
            logger.info(f"  - Silhouette score: {clustering['silhouette_score']:.3f}")
    
    # Generate insights
    logger.info("Generating insights...")
    insights = AnalyticsUtils.generate_insights(analytics_report)
    
    logger.info("Insights:")
    for insight in insights['insights']:
        logger.info(f"  - {insight}")
    
    logger.info("Recommendations:")
    for recommendation in insights['recommendations']:
        logger.info(f"  - {recommendation}")
    
    return analytics_report

async def demonstrate_utilities():
    """Demonstrate utility functions."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Utility Functions")
    logger.info("=" * 60)
    
    # Text preprocessing utilities
    logger.info("Testing text preprocessing...")
    preprocessor = TextPreprocessingUtils()
    
    test_text = "  Hello   World!  \n\nThis is a TEST with   multiple spaces...  "
    cleaned, stats = preprocessor.clean_advanced(test_text)
    
    logger.info(f"Original text: '{test_text}'")
    logger.info(f"Cleaned text: '{cleaned}'")
    logger.info(f"Character reduction: {stats.character_reduction:.2%}")
    logger.info(f"Preprocessing steps: {stats.preprocessing_steps}")
    
    # Export/Import utilities
    logger.info("Testing export/import utilities...")
    sample_embeddings = [
        ("doc1", [0.1, 0.2, 0.3, 0.4] + [0.0] * 380),
        ("doc2", [0.2, 0.3, 0.4, 0.5] + [0.0] * 380),
        ("doc3", [0.3, 0.4, 0.5, 0.6] + [0.0] * 380)
    ]
    
    # Export to JSON
    json_path = ExportImportUtils.export_to_json(
        sample_embeddings,
        metadata={"test": "export", "timestamp": time.time()}
    )
    logger.info(f"Exported to JSON: {json_path}")
    
    # Export to CSV
    csv_path = ExportImportUtils.export_to_csv(sample_embeddings)
    logger.info(f"Exported to CSV: {csv_path}")
    
    # Import from JSON
    imported_embeddings, imported_metadata = ExportImportUtils.import_from_json(json_path)
    logger.info(f"Imported {len(imported_embeddings)} embeddings")
    logger.info(f"Imported metadata: {imported_metadata}")
    
    # Validation utilities
    logger.info("Testing validation utilities...")
    embeddings = [emb for _, emb in sample_embeddings]
    validation_report = ValidationUtils.validate_embedding_quality(embeddings)
    
    logger.info(f"Validation result: {validation_report.valid}")
    logger.info(f"Quality score: {validation_report.quality_score:.3f}")
    
    # Benchmark utilities
    logger.info("Running benchmarking...")
    benchmark_result = ValidationUtils.benchmark_embeddings(embeddings)
    logger.info(f"Benchmark results:")
    logger.info(f"  - Metrics calculated: {list(benchmark_result['metrics'].keys())}")
    
    return {
        "preprocessing_stats": stats,
        "export_paths": [json_path, csv_path],
        "validation_report": validation_report,
        "benchmark_result": benchmark_result
    }

async def demonstrate_error_handling():
    """Demonstrate error handling and recovery."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: Error Handling")
    logger.info("=" * 60)
    
    async with EmbeddingService() as service:
        # Test various error conditions
        test_cases = [
            ("", "Empty text"),
            (None, "None text"),
            ("   ", "Whitespace only"),
            ("x" * 10000, "Very long text")
        ]
        
        logger.info("Testing error handling for invalid inputs...")
        
        for test_input, description in test_cases:
            logger.info(f"Testing: {description}")
            try:
                if test_input is None:
                    continue  # Skip None test as it will fail at argument level
                
                result = await service.generate_embedding(str(test_input)[:100])  # Limit length
                logger.info(f"  ✓ Success: {result.dimension} dimensions")
            except Exception as e:
                logger.info(f"  ✓ Handled error: {type(e).__name__}")
        
        # Test batch processing with invalid data
        logger.info("Testing batch processing with mixed valid/invalid data...")
        mixed_batch = [
            "Valid text 1",
            "",
            "Valid text 2",
            None,  # This should be filtered out by preprocessing
            "Valid text 3",
            "   ",  # Should be filtered out
            "Valid text 4"
        ]
        
        try:
            # Filter out None and very short texts
            valid_batch = [t for t in mixed_batch if t and len(str(t).strip()) >= 3]
            
            if valid_batch:
                result = await service.generate_embeddings_batch(valid_batch)
                logger.info(f"Batch processing result:")
                logger.info(f"  - Total: {result.total_texts}")
                logger.info(f"  - Successful: {result.successful}")
                logger.info(f"  - Failed: {result.failed}")
                logger.info(f"  - Errors: {len(result.errors)}")
                
                if result.errors:
                    for error in result.errors[:3]:  # Show first 3 errors
                        logger.info(f"    - {error}")
        except Exception as e:
            logger.info(f"Batch processing error: {type(e).__name__}: {e}")

# ==============================================================================
# MAIN DEMONSTRATION
# ==============================================================================

async def run_comprehensive_demonstration():
    """Run the complete embedding service demonstration."""
    logger.info("Starting Comprehensive Embedding Service Demonstration")
    logger.info("This will showcase all major features and capabilities")
    logger.info("=" * 80)
    
    demonstration_results = {}
    
    try:
        # 1. Basic Embedding Generation
        logger.info("\n🎯 STEP 1: Basic Embedding Generation")
        demonstration_results['basic_embedding'] = await demonstrate_basic_embedding_generation()
        
        # 2. Similarity Analysis
        logger.info("\n🎯 STEP 2: Similarity Analysis")
        async with EmbeddingService() as service:
            demonstration_results['similarity_analysis'] = await demonstrate_similarity_analysis(service)
        
        # 3. Advanced Batch Processing
        logger.info("\n🎯 STEP 3: Advanced Batch Processing")
        demonstration_results['batch_processing'] = await demonstrate_batch_processing()
        
        # 4. Model Management
        logger.info("\n🎯 STEP 4: Model Management")
        demonstration_results['model_management'] = await demonstrate_model_management()
        
        # 5. Analytics and Insights
        logger.info("\n🎯 STEP 5: Analytics and Insights")
        async with EmbeddingService() as service:
            demonstration_results['analytics'] = await demonstrate_analytics_and_insights(service)
        
        # 6. Utility Functions
        logger.info("\n🎯 STEP 6: Utility Functions")
        demonstration_results['utilities'] = await demonstrate_utilities()
        
        # 7. Error Handling
        logger.info("\n🎯 STEP 7: Error Handling")
        await demonstrate_error_handling()
        
        # Summary
        logger.info("\n" + "=" * 80)
        logger.info("DEMONSTRATION COMPLETE - SUMMARY")
        logger.info("=" * 80)
        logger.info("✅ All demonstration steps completed successfully!")
        logger.info(f"📊 Basic embedding: {demonstration_results['basic_embedding'].successful} embeddings generated")
        logger.info(f"🔍 Similarity analysis: {len(demonstration_results['similarity_analysis'][0])} texts analyzed")
        logger.info(f"⚡ Batch processing: {demonstration_results['batch_processing'].successful_items} items processed")
        logger.info(f"🤖 Model management: System optimized and monitored")
        logger.info(f"📈 Analytics: Comprehensive insights generated")
        logger.info(f"🛠️  Utilities: Text processing, validation, and export tested")
        logger.info("🛡️  Error handling: Robust error recovery demonstrated")
        logger.info("=" * 80)
        
        return demonstration_results
        
    except Exception as e:
        logger.error(f"Demonstration failed with error: {e}")
        logger.error(f"Error details: {type(e).__name__}: {str(e)}")
        raise

# ==============================================================================
# INTEGRATION WITH RAG
# ==============================================================================

async def demonstrate_rag_integration():
    """Demonstrate integration with RAG system."""
    logger.info("=" * 60)
    logger.info("DEMONSTRATION: RAG System Integration")
    logger.info("=" * 60)
    
    # Simulate RAG document processing workflow
    rag_documents = [
        {
            "id": "doc_001",
            "content": "Machine learning is a subset of artificial intelligence that focuses on algorithms that can learn from data.",
            "metadata": {"category": "technical", "source": "manual"}
        },
        {
            "id": "doc_002", 
            "content": "Deep learning uses neural networks with multiple layers to model and understand complex patterns.",
            "metadata": {"category": "technical", "source": "manual"}
        },
        {
            "id": "doc_003",
            "content": "Natural language processing enables computers to understand, interpret, and generate human language.",
            "metadata": {"category": "technical", "source": "manual"}
        },
        {
            "id": "doc_004",
            "content": "Vector databases store embeddings in a format optimized for similarity search and retrieval.",
            "metadata": {"category": "technical", "source": "manual"}
        }
    ]
    
    async with EmbeddingService() as embedding_service:
        logger.info("Processing documents for RAG system...")
        
        # Extract content for embedding
        documents_content = [doc["content"] for doc in rag_documents]
        
        # Generate embeddings in batch (as RAG would)
        batch_result = await embedding_service.generate_embeddings_batch(
            documents_content,
            batch_size=4,
            use_cache=True
        )
        
        logger.info(f"RAG document processing completed:")
        logger.info(f"  - Documents processed: {batch_result.total_texts}")
        logger.info(f"  - Embeddings generated: {batch_result.successful}")
        logger.info(f"  - Average embedding dimension: {batch_result.results[0].dimension}")
        
        # Simulate vector storage (would be ChromaDB in real RAG)
        vector_storage = {}
        for doc, result in zip(rag_documents, batch_result.results):
            vector_storage[doc["id"]] = {
                "content": doc["content"],
                "embedding": result.embedding,
                "metadata": doc["metadata"]
            }
        
        logger.info(f"Vector storage updated with {len(vector_storage)} documents")
        
        # Simulate similarity search (as RAG would)
        query = "What is machine learning?"
        logger.info(f"Processing RAG query: '{query}'")
        
        # Generate query embedding
        query_result = await embedding_service.generate_embedding(query)
        
        # Find similar documents
        candidates = [
            (doc_id, data["embedding"]) 
            for doc_id, data in vector_storage.items()
        ]
        
        similar_docs = embedding_service.find_similar_embeddings(
            query_result.embedding,
            candidates,
            top_k=3,
            metric="cosine"
        )
        
        logger.info(f"RAG search results for '{query}':")
        for rank, (doc_id, similarity) in enumerate(similar_docs, 1):
            doc_data = vector_storage[doc_id]
            logger.info(f"  {rank}. {doc_id} (similarity: {similarity:.3f})")
            logger.info(f"     Content: {doc_data['content'][:100]}...")
            logger.info(f"     Metadata: {doc_data['metadata']}")
        
        # Demonstrate batch similarity search for RAG
        logger.info("Demonstrating batch similarity search...")
        queries = [
            "What are neural networks?",
            "How does NLP work?", 
            "What are vector databases?"
        ]
        
        for query in queries:
            query_emb = await embedding_service.generate_embedding(query)
            similar_docs = embedding_service.find_similar_embeddings(
                query_emb.embedding,
                [(doc_id, data["embedding"]) for doc_id, data in vector_storage.items()],
                top_k=2
            )
            
            logger.info(f"Query: '{query}'")
            for doc_id, similarity in similar_docs:
                doc_content = vector_storage[doc_id]["content"][:50] + "..."
                logger.info(f"  → {doc_id} ({similarity:.3f}): {doc_content}")
        
        return vector_storage

# ==============================================================================
# PERFORMANCE BENCHMARK
# ==============================================================================

async def run_performance_benchmark():
    """Run performance benchmark for embedding service."""
    logger.info("=" * 60)
    logger.info("PERFORMANCE BENCHMARK")
    logger.info("=" * 60)
    
    benchmark_results = {}
    
    async with EmbeddingService() as service:
        # Test 1: Single embedding latency
        logger.info("Test 1: Single embedding latency")
        test_text = "This is a test sentence for performance measurement."
        
        latencies = []
        for i in range(10):
            start_time = time.time()
            result = await service.generate_embedding(test_text)
            latency = time.time() - start_time
            latencies.append(latency)
        
        avg_latency = np.mean(latencies)
        min_latency = np.min(latencies)
        max_latency = np.max(latencies)
        
        logger.info(f"  Average latency: {avg_latency*1000:.2f}ms")
        logger.info(f"  Min latency: {min_latency*1000:.2f}ms")
        logger.info(f"  Max latency: {max_latency*1000:.2f}ms")
        
        benchmark_results['single_embedding'] = {
            'avg_latency_ms': avg_latency * 1000,
            'min_latency_ms': min_latency * 1000,
            'max_latency_ms': max_latency * 1000
        }
        
        # Test 2: Batch throughput
        logger.info("Test 2: Batch throughput")
        batch_sizes = [10, 50, 100]
        
        for batch_size in batch_sizes:
            texts = [f"Test document {i} for throughput measurement." for i in range(batch_size)]
            
            start_time = time.time()
            result = await service.generate_embeddings_batch(texts, batch_size=batch_size//4)
            end_time = time.time()
            
            throughput = result.successful / (end_time - start_time)
            
            logger.info(f"  Batch size {batch_size}: {throughput:.2f} docs/second")
            
            benchmark_results[f'batch_{batch_size}'] = {
                'throughput_docs_per_second': throughput,
                'processing_time': end_time - start_time,
                'success_rate': result.successful / batch_size
            }
        
        # Test 3: Memory usage
        logger.info("Test 3: Memory usage analysis")
        import psutil
        process = psutil.Process()
        
        # Baseline memory
        baseline_memory = process.memory_info().rss / 1024 / 1024
        
        # Generate many embeddings
        large_texts = [f"Document {i} for memory testing with longer content." for i in range(500)]
        result = await service.generate_embeddings_batch(large_texts, batch_size=50)
        
        peak_memory = process.memory_info().rss / 1024 / 1024
        memory_increase = peak_memory - baseline_memory
        
        logger.info(f"  Baseline memory: {baseline_memory:.2f}MB")
        logger.info(f"  Peak memory: {peak_memory:.2f}MB")
        logger.info(f"  Memory increase: {memory_increase:.2f}MB")
        logger.info(f"  Memory per embedding: {memory_increase/len(large_texts)*1024:.2f}KB")
        
        benchmark_results['memory'] = {
            'baseline_mb': baseline_memory,
            'peak_mb': peak_memory,
            'increase_mb': memory_increase,
            'per_embedding_kb': memory_increase/len(large_texts)*1024
        }
        
        # Test 4: Caching effectiveness
        logger.info("Test 4: Caching effectiveness")
        cache_test_text = "This text will be cached for performance testing."
        
        # First generation (no cache)
        start_time = time.time()
        result1 = await service.generate_embedding(cache_test_text, use_cache=False)
        first_time = time.time() - start_time
        
        # Second generation (with cache)
        start_time = time.time()
        result2 = await service.generate_embedding(cache_test_text, use_cache=True)
        cached_time = time.time() - start_time
        
        speedup = first_time / cached_time if cached_time > 0 else float('inf')
        
        logger.info(f"  First generation: {first_time*1000:.2f}ms")
        logger.info(f"  Cached generation: {cached_time*1000:.2f}ms")
        logger.info(f"  Speedup: {speedup:.2f}x")
        
        benchmark_results['caching'] = {
            'first_time_ms': first_time * 1000,
            'cached_time_ms': cached_time * 1000,
            'speedup_factor': speedup
        }
    
    return benchmark_results

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

async def main():
    """Main execution function."""
    import sys
    
    # Check for command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "rag":
            await demonstrate_rag_integration()
        elif command == "benchmark":
            results = await run_performance_benchmark()
            print("\n" + "="*60)
            print("BENCHMARK RESULTS SUMMARY")
            print("="*60)
            for test_name, metrics in results.items():
                print(f"\n{test_name.upper()}:")
                for metric, value in metrics.items():
                    if isinstance(value, float):
                        print(f"  {metric}: {value:.3f}")
                    else:
                        print(f"  {metric}: {value}")
        else:
            print(f"Unknown command: {command}")
            print("Available commands: rag, benchmark")
            print("Run without arguments for full demonstration")
    else:
        # Run full demonstration
        try:
            results = await run_comprehensive_demonstration()
            print("\n🎉 Embedding service demonstration completed successfully!")
            
        except KeyboardInterrupt:
            print("\n⚠️  Demonstration interrupted by user")
        except Exception as e:
            print(f"\n❌ Demonstration failed: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())