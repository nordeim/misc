#!/usr/bin/env python3
"""
Test script to verify configuration system initialization after Pydantic fix
"""

import sys
import os
sys.path.insert(0, '/workspace/backend')

def test_configuration_initialization():
    """Test that ConfigurationManager loads properly with all imports resolved"""
    
    try:
        print("🔧 Testing configuration system initialization...")
        
        # Test 1: Import ConfigurationManager
        print("📦 Testing imports...")
        from config import ConfigurationManager, MonitoringConfig, ConfigValidator, ConfigLoader, ConfigMigrationManager
        print("✅ All configuration imports successful")
        
        # Test 2: Import main Settings class
        print("⚙️ Testing main Settings import...")
        from app.config import Settings
        print("✅ Main Settings import successful")
        
        # Test 3: Initialize ConfigurationManager
        print("🏗️ Testing ConfigurationManager initialization...")
        config_manager = ConfigurationManager()
        print("✅ ConfigurationManager initialized successfully")
        
        # Test 4: Initialize individual components
        print("🔧 Testing individual component initialization...")
        monitoring_config = MonitoringConfig()
        config_validator = ConfigValidator()
        config_loader = ConfigLoader()
        config_migration = ConfigMigrationManager()
        print("✅ All components initialized successfully")
        
        # Test 5: Test Settings validation (the fix location)
        print("🔍 Testing Settings validation...")
        try:
            # Try to create Settings instance (this should work with the Pydantic fix)
            settings = Settings()
            print("✅ Settings instance created successfully")
        except Exception as e:
            print(f"❌ Settings validation failed: {e}")
            return False
        
        # Test 6: Test configuration manager methods
        print("📊 Testing ConfigurationManager methods...")
        try:
            # Test if methods exist and are callable
            assert hasattr(config_manager, 'load_config'), "load_config method missing"
            assert hasattr(config_manager, 'validate_config'), "validate_config method missing"
            assert hasattr(config_manager, 'migrate_config'), "migrate_config method missing"
            print("✅ All ConfigurationManager methods available")
        except Exception as e:
            print(f"❌ ConfigurationManager methods test failed: {e}")
            return False
        
        print("\n🎉 All tests passed! Configuration system initialization successful!")
        print("✅ Pydantic validator fix is working correctly")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error during initialization: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 Configuration System Initialization Test")
    print("=" * 60)
    
    success = test_configuration_initialization()
    
    print("\n" + "=" * 60)
    if success:
        print("🎯 RESULT: Configuration system is working correctly!")
        sys.exit(0)
    else:
        print("💥 RESULT: Configuration system has issues!")
        sys.exit(1)