#!/usr/bin/env python3
"""
Comprehensive tests for backup and restore service.

Tests cover:
- Database backup and restore
- Configuration backup and restore  
- File system backup and restore
- Full system backup operations
- Backup verification and validation
- Error handling and edge cases
- CLI functionality
"""

import asyncio
import pytest
import tempfile
import shutil
import json
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock
import sys
import os

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

# Import test dependencies
from app.utils.backup_restore_service import (
    BackupRestoreService,
    BackupMetadata,
    BackupSchedule,
    RestoreResult,
    backup_service
)
from app.config import settings


class TestBackupRestoreService:
    """Test class for backup and restore service."""
    
    @pytest.fixture
    def temp_backup_dir(self):
        """Create temporary backup directory for testing."""
        temp_dir = tempfile.mkdtemp(prefix="backup_test_")
        yield temp_dir
        shutil.rmtree(temp_dir, ignore_errors=True)
    
    @pytest.fixture
    def mock_service(self):
        """Create mock backup service for isolated testing."""
        service = BackupRestoreService()
        service.BACKUP_DIR = Path(tempfile.mkdtemp(prefix="backup_test_"))
        service.CONFIG_BACKUP_DIR = service.BACKUP_DIR / "configs"
        service.DATA_BACKUP_DIR = service.BACKUP_DIR / "data"
        service.DB_BACKUP_DIR = service.BACKUP_DIR / "databases"
        
        # Create directories
        for directory in [service.BACKUP_DIR, service.CONFIG_BACKUP_DIR, service.DATA_BACKUP_DIR, service.DB_BACKUP_DIR]:
            directory.mkdir(parents=True, exist_ok=True)
        
        return service
    
    @pytest.mark.asyncio
    async def test_backup_metadata_creation(self, mock_service):
        """Test backup metadata creation and storage."""
        metadata = BackupMetadata(
            backup_id="test_backup_123",
            backup_type="database",
            timestamp=datetime.now(),
            database_type="sqlite",
            compression=True,
            encrypted=False,
            source_paths=["/path/to/db"],
            total_size=1024000,
            file_count=1,
            checksum="abc123",
            status="completed"
        )
        
        mock_service.backup_metadata["test_backup_123"] = metadata
        mock_service._save_backup_metadata()
        
        # Test metadata retrieval
        retrieved = mock_service.get_backup_info("test_backup_123")
        assert retrieved is not None
        assert retrieved.backup_id == "test_backup_123"
        assert retrieved.backup_type == "database"
        assert retrieved.status == "completed"
    
    @pytest.mark.asyncio
    async def test_checksum_calculation(self, mock_service):
        """Test checksum calculation for files."""
        # Create test file
        test_file = mock_service.BACKUP_DIR / "test_file.txt"
        test_content = b"Hello, World! This is test content."
        
        with open(test_file, "wb") as f:
            f.write(test_content)
        
        # Calculate checksum
        checksum = mock_service._calculate_checksum(test_file)
        
        # Verify checksum
        assert len(checksum) == 64  # SHA256 checksum length
        assert isinstance(checksum, str)
        
        # Verify same content produces same checksum
        checksum2 = mock_service._calculate_checksum(test_file)
        assert checksum == checksum2
    
    @pytest.mark.asyncio
    async def test_compression_and_decompression(self, mock_service):
        """Test data compression and decompression."""
        test_data = b"This is test data for compression testing."
        
        # Test compression
        compressed = mock_service._compress_data(test_data, compress=True)
        assert len(compressed) < len(test_data)
        
        # Test decompression
        decompressed = mock_service._decompress_data(compressed, compress=True)
        assert decompressed == test_data
        
        # Test no compression
        not_compressed = mock_service._compress_data(test_data, compress=False)
        assert not_compressed == test_data
    
    @pytest.mark.asyncio
    async def test_database_backup_creation(self, mock_service):
        """Test database backup creation."""
        with patch('app.utils.backup_restore_service.sync_engine') as mock_engine:
            # Mock database engine for testing
            mock_engine.url = "sqlite:///test.db"
            
            with patch('sqlite3.connect') as mock_connect:
                mock_source_conn = Mock()
                mock_backup_conn = Mock()
                
                # Mock connection contexts
                mock_connect.side_effect = [
                    mock_source_conn,
                    mock_backup_conn
                ]
                
                with patch('pathlib.Path.exists', return_value=True):
                    with patch('pathlib.Path.stat') as mock_stat:
                        mock_stat.return_value.st_size = 1024000
                        
                        # Test backup creation
                        backup_id = await mock_service.create_database_backup(
                            backup_type="full",
                            compress=True,
                            encrypt=False
                        )
                        
                        # Verify backup metadata
                        metadata = mock_service.get_backup_info(backup_id)
                        assert metadata is not None
                        assert metadata.backup_type == "full"
                        assert metadata.status == "completed"
                        assert metadata.database_type == "sqlite"
    
    @pytest.mark.asyncio
    async def test_configuration_backup_creation(self, mock_service):
        """Test configuration backup creation."""
        # Create test configuration files
        config_dir = backend_dir / "app" / "config"
        if config_dir.exists():
            backup_id = await mock_service.create_configuration_backup(
                backup_name="test_config_backup",
                compress=True,
                encrypt=False
            )
            
            # Verify backup creation
            metadata = mock_service.get_backup_info(backup_id)
            assert metadata is not None
            assert metadata.backup_type == "configuration"
            assert metadata.status == "completed"
    
    @pytest.mark.asyncio
    async def test_filesystem_backup_creation(self, mock_service):
        """Test file system backup creation."""
        # Create test data directory
        test_data_dir = mock_service.BACKUP_DIR / "test_data"
        test_data_dir.mkdir(exist_ok=True)
        
        # Create test files
        test_file = test_data_dir / "test.txt"
        with open(test_file, "w") as f:
            f.write("This is test data for backup testing.")
        
        with patch('app.utils.backup_restore_service.Path') as mock_path_class:
            # Mock Path.exists to return True for our test directory
            mock_path_class.side_effect = lambda path: Path(str(path)) in [
                mock_service.BACKUP_DIR / "test_data"
            ]
            
            backup_id = await mock_service.create_file_system_backup(
                backup_name="test_fs_backup",
                compress=True,
                encrypt=False
            )
            
            # Verify backup creation
            metadata = mock_service.get_backup_info(backup_id)
            assert metadata is not None
            assert metadata.backup_type == "filesystem"
            assert metadata.status == "completed"
    
    @pytest.mark.asyncio
    async def test_full_system_backup_creation(self, mock_service):
        """Test full system backup creation."""
        # Mock individual backup methods
        with patch.object(mock_service, 'create_database_backup') as mock_db_backup:
            with patch.object(mock_service, 'create_configuration_backup') as mock_config_backup:
                with patch.object(mock_service, 'create_file_system_backup') as mock_fs_backup:
                    
                    mock_db_backup.return_value = "db_backup_123"
                    mock_config_backup.return_value = "config_backup_123"
                    mock_fs_backup.return_value = "fs_backup_123"
                    
                    # Test full backup creation
                    backup_id = await mock_service.create_full_system_backup(
                        backup_name="test_full_backup",
                        compress=True,
                        encrypt=False,
                        include_configs=True,
                        include_files=True
                    )
                    
                    # Verify individual backups were called
                    mock_db_backup.assert_called_once()
                    mock_config_backup.assert_called_once()
                    mock_fs_backup.assert_called_once()
                    
                    # Verify full backup metadata
                    metadata = mock_service.get_backup_info(backup_id)
                    assert metadata is not None
                    assert metadata.backup_type == "full"
                    assert metadata.status == "completed"
    
    @pytest.mark.asyncio
    async def test_backup_verification(self, mock_service):
        """Test backup verification functionality."""
        # Create test backup metadata
        metadata = BackupMetadata(
            backup_id="test_verify_123",
            backup_type="database",
            timestamp=datetime.now(),
            database_type="sqlite",
            compression=True,
            encrypted=False,
            source_paths=["/path/to/db"],
            total_size=1024000,
            file_count=1,
            checksum="test_checksum_123",
            status="completed"
        )
        
        mock_service.backup_metadata["test_verify_123"] = metadata
        
        # Create test backup file
        backup_file = mock_service.DB_BACKUP_DIR / "test_verify_123.db"
        with open(backup_file, "w") as f:
            f.write("test backup content")
        
        with patch.object(mock_service, '_calculate_checksum', return_value="test_checksum_123"):
            # Test backup verification
            is_valid = await mock_service.verify_backup("test_verify_123")
            assert is_valid is True
    
    @pytest.mark.asyncio
    async def test_backup_verification_failed(self, mock_service):
        """Test backup verification failure cases."""
        # Test non-existent backup
        is_valid = await mock_service.verify_backup("non_existent_backup")
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_backup_listing(self, mock_service):
        """Test backup listing functionality."""
        # Create multiple backup metadata
        backups = [
            BackupMetadata(
                backup_id=f"test_backup_{i}",
                backup_type="database" if i % 2 == 0 else "configuration",
                timestamp=datetime.now() - timedelta(days=i),
                database_type="sqlite",
                compression=True,
                encrypted=False,
                source_paths=["/path/to/db"],
                total_size=1024000,
                file_count=1,
                checksum=f"checksum_{i}",
                status="completed"
            )
            for i in range(5)
        ]
        
        for backup in backups:
            mock_service.backup_metadata[backup.backup_id] = backup
        
        # Test listing all backups
        all_backups = mock_service.get_backup_list()
        assert len(all_backups) == 5
        
        # Test filtering by type
        db_backups = mock_service.get_backup_list(backup_type="database")
        assert len(db_backups) == 3  # backups 0, 2, 4
        
        config_backups = mock_service.get_backup_list(backup_type="configuration")
        assert len(config_backups) == 2  # backups 1, 3
    
    @pytest.mark.asyncio
    async def test_cleanup_old_backups(self, mock_service):
        """Test cleanup of old backups."""
        # Create old and new backup metadata
        old_time = datetime.now() - timedelta(days=35)
        recent_time = datetime.now() - timedelta(days=5)
        
        backups = [
            BackupMetadata(
                backup_id="old_backup_1",
                backup_type="database",
                timestamp=old_time,
                database_type="sqlite",
                compression=True,
                encrypted=False,
                source_paths=["/path/to/db"],
                total_size=1024000,
                file_count=1,
                checksum="old_checksum_1",
                status="completed"
            ),
            BackupMetadata(
                backup_id="recent_backup_1",
                backup_type="database",
                timestamp=recent_time,
                database_type="sqlite",
                compression=True,
                encrypted=False,
                source_paths=["/path/to/db"],
                total_size=1024000,
                file_count=1,
                checksum="recent_checksum_1",
                status="completed"
            )
        ]
        
        for backup in backups:
            mock_service.backup_metadata[backup.backup_id] = backup
        
        # Test cleanup with 30-day retention
        cleaned_up = mock_service.cleanup_old_backups(retention_days=30)
        
        # Should have cleaned up 1 backup
        assert cleaned_up == 1
        assert "old_backup_1" not in mock_service.backup_metadata
        assert "recent_backup_1" in mock_service.backup_metadata
    
    @pytest.mark.asyncio
    async def test_health_report_generation(self, mock_service):
        """Test system health report generation."""
        # Create sample backup metadata
        metadata = BackupMetadata(
            backup_id="health_test_123",
            backup_type="database",
            timestamp=datetime.now(),
            database_type="sqlite",
            compression=True,
            encrypted=False,
            source_paths=["/path/to/db"],
            total_size=1024000,
            file_count=1,
            checksum="health_checksum_123",
            status="completed"
        )
        
        mock_service.backup_metadata["health_test_123"] = metadata
        
        # Generate health report
        report = mock_service.get_system_health_report()
        
        # Verify report structure
        assert "timestamp" in report
        assert "backup_service_status" in report
        assert "backup_counts" in report
        assert "disk_usage" in report
        assert "recommendations" in report
        
        # Verify statistics
        backup_counts = report["backup_counts"]
        assert backup_counts["total"] == 1
        assert backup_counts["completed"] == 1
        assert backup_counts["failed"] == 0
    
    @pytest.mark.asyncio
    async def test_point_in_time_backup(self, mock_service):
        """Test point-in-time backup creation."""
        target_timestamp = datetime(2024, 11, 4, 10, 0, 0)
        
        with patch.object(mock_service, 'create_database_backup') as mock_db_backup:
            mock_db_backup.return_value = "pitr_backup_123"
            
            # Test PITR backup creation
            backup_id = await mock_service.create_point_in_time_backup(
                target_timestamp=target_timestamp
            )
            
            # Verify backup creation
            assert backup_id == "pitr_backup_123"
            mock_db_backup.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_disaster_recovery_restore(self, mock_service):
        """Test disaster recovery restore functionality."""
        # Create mock backup metadata
        backup_metadata = [
            BackupMetadata(
                backup_id=f"dr_backup_{i}",
                backup_type="database",
                timestamp=datetime.now(),
                database_type="sqlite",
                compression=True,
                encrypted=False,
                source_paths=["/path/to/db"],
                total_size=1024000,
                file_count=1,
                checksum=f"dr_checksum_{i}",
                status="completed"
            )
            for i in range(3)
        ]
        
        for metadata in backup_metadata:
            mock_service.backup_metadata[metadata.backup_id] = metadata
        
        # Mock individual restore methods
        with patch.object(mock_service, 'verify_backup', return_value=True):
            with patch.object(mock_service, 'restore_database') as mock_restore:
                mock_restore.return_value = RestoreResult(
                    restore_id="restore_123",
                    timestamp=datetime.now(),
                    source_backup="dr_backup_1",
                    target_location="/path/to/db",
                    status="completed",
                    restored_files=1,
                    restored_size=1024000,
                    warnings=[],
                    errors=[]
                )
                
                # Test disaster recovery
                backup_ids = [f"dr_backup_{i}" for i in range(3)]
                results = await mock_service.disaster_recovery_restore(
                    backup_ids=backup_ids,
                    validate_before_restore=True,
                    create_recovery_snapshot=False
                )
                
                # Verify results
                assert len(results) == 3
                for backup_id in backup_ids:
                    assert backup_id in results
                    assert results[backup_id].status == "completed"
    
    @pytest.mark.asyncio
    async def test_error_handling(self, mock_service):
        """Test error handling in backup operations."""
        # Test invalid backup ID
        with pytest.raises(Exception, match="Backup not found"):
            await mock_service.verify_backup("non_existent_backup")
        
        # Test failed backup creation
        with patch('app.utils.backup_restore_service.sync_engine') as mock_engine:
            mock_engine.url = "sqlite:///invalid_path.db"
            
            with pytest.raises(Exception):
                await mock_service.create_database_backup()


class TestBackupCLI:
    """Test CLI functionality for backup operations."""
    
    @pytest.fixture
    def cli_script(self):
        """Get path to CLI script."""
        return backend_dir / "scripts" / "backup_cli.py"
    
    def test_cli_script_exists(self, cli_script):
        """Test that CLI script exists."""
        assert cli_script.exists()
    
    @pytest.mark.asyncio
    async def test_cli_backup_database_command(self, cli_script):
        """Test CLI database backup command."""
        # This would require actually running the CLI script
        # For now, we'll test that the CLI script can be imported
        import subprocess
        import sys
        
        try:
            result = subprocess.run([
                sys.executable, 
                str(cli_script), 
                "--help"
            ], capture_output=True, text=True, timeout=10)
            
            assert result.returncode == 0
            assert "backup" in result.stdout.lower()
        except subprocess.TimeoutExpired:
            pytest.skip("CLI help command timed out")


class TestBackupIntegration:
    """Integration tests for backup service."""
    
    @pytest.mark.asyncio
    async def test_service_initialization(self):
        """Test that backup service initializes correctly."""
        service = BackupRestoreService()
        
        # Verify service components
        assert service.backup_metadata is not None
        assert service.restore_metadata is not None
        assert service.scheduler_running is False
        assert service.scheduler_thread is None
    
    @pytest.mark.asyncio
    async def test_backup_directory_creation(self):
        """Test that backup directories are created correctly."""
        service = BackupRestoreService()
        
        # Check that backup directories exist
        assert service.BACKUP_DIR.exists()
        assert service.CONFIG_BACKUP_DIR.exists()
        assert service.DATA_BACKUP_DIR.exists()
        assert service.DB_BACKUP_DIR.exists()
        assert service.LOG_BACKUP_DIR.exists()


# Utility functions for testing
def create_test_backup_metadata(service: BackupRestoreService, backup_id: str, backup_type: str = "database"):
    """Helper function to create test backup metadata."""
    metadata = BackupMetadata(
        backup_id=backup_id,
        backup_type=backup_type,
        timestamp=datetime.now(),
        database_type="sqlite",
        compression=True,
        encrypted=False,
        source_paths=["/path/to/test"],
        total_size=1024000,
        file_count=1,
        checksum=f"test_checksum_{backup_id}",
        status="completed"
    )
    
    service.backup_metadata[backup_id] = metadata
    return metadata


def assert_backup_metadata_equal(metadata1: BackupMetadata, metadata2: BackupMetadata):
    """Helper function to compare backup metadata."""
    assert metadata1.backup_id == metadata2.backup_id
    assert metadata1.backup_type == metadata2.backup_type
    assert metadata1.status == metadata2.status
    assert metadata1.total_size == metadata2.total_size
    assert metadata1.file_count == metadata2.file_count


# Performance tests
class TestBackupPerformance:
    """Performance tests for backup operations."""
    
    @pytest.mark.asyncio
    async def test_large_backup_performance(self):
        """Test backup performance with large datasets."""
        service = BackupRestoreService()
        
        # This would test backup performance with large datasets
        # For now, we'll skip this test as it requires actual large data
        pytest.skip("Performance test requires large test data")
    
    @pytest.mark.asyncio
    async def test_concurrent_backups(self):
        """Test concurrent backup operations."""
        service = BackupRestoreService()
        
        # This would test multiple concurrent backups
        # For now, we'll skip this test
        pytest.skip("Concurrent backup test not implemented")


# Main test execution
if __name__ == "__main__":
    print("Running backup and restore service tests...")
    
    # Run tests
    pytest.main([
        __file__,
        "-v",
        "--tb=short",
        "--asyncio-mode=auto"
    ])
