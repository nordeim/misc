"""
Basic tests for SQLAlchemy models to verify they work correctly.
"""

import pytest
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Import all models
from app.models import Base, UserORM, SessionORM, MessageORM, MemoryORM
from app.models.schemas import (
    UserCreate, UserRead,
    SessionCreate, SessionRead,
    MessageCreate, MessageRead,
    MemoryCreate, MemoryRead
)


# Test database setup
@pytest.fixture
def test_db():
    """Create test database."""
    engine = create_engine("sqlite:///:memory:", echo=False)
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()


class TestUserORM:
    """Test UserORM model."""
    
    def test_create_user(self, test_db):
        """Test user creation."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            full_name="Test User",
            hashed_password="hashed_password",
            is_active=True,
            is_verified=False,
            is_superuser=False
        )
        
        test_db.add(user)
        test_db.flush()
        
        assert user.id is not None
        assert user.email == "test@example.com"
        assert user.username == "testuser"
        assert user.is_active is True
        assert user.created_at is not None
        assert user.login_count == 0
    
    def test_user_login_tracking(self, test_db):
        """Test user login tracking."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        # First login
        initial_count = user.login_count
        user.verify_login()
        assert user.login_count == initial_count + 1
        assert user.last_login is not None
    
    def test_user_status_management(self, test_db):
        """Test user status management."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        # Deactivate
        user.deactivate()
        assert user.is_active is False
        
        # Activate
        user.activate()
        assert user.is_active is True
    
    def test_user_query_methods(self, test_db):
        """Test user query methods."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        # Test get_by_email
        found_user = UserORM.get_by_email(test_db, "test@example.com")
        assert found_user is not None
        assert found_user.id == user.id
        
        # Test get_by_username
        found_user = UserORM.get_by_username(test_db, "testuser")
        assert found_user is not None
        assert found_user.id == user.id


class TestSessionORM:
    """Test SessionORM model."""
    
    def test_create_session(self, test_db):
        """Test session creation."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session",
            session_type="chat",
            model_name="gpt-3.5-turbo",
            provider="openai"
        )
        test_db.add(session)
        test_db.flush()
        
        assert session.id is not None
        assert session.title == "Test Session"
        assert session.status == "active"
        assert session.message_count == 0
        assert session.created_at is not None
    
    def test_session_relationships(self, test_db):
        """Test session relationships."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        # Add a message
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello"
        )
        test_db.add(message)
        test_db.flush()
        
        # Add a memory
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        # Test relationships
        assert len(session.messages) == 1
        assert session.messages[0].id == message.id
        assert len(session.memories) == 1
        assert session.memories[0].id == memory.id
        assert session.user.id == user.id
    
    def test_session_activity_tracking(self, test_db):
        """Test session activity tracking."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        # Add message should update activity
        initial_activity = session.last_activity
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello"
        )
        session.add_message(message)
        
        assert session.message_count == 1
        assert session.last_activity > initial_activity
    
    def test_session_status_management(self, test_db):
        """Test session status management."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        # Close session
        session.close_session()
        assert session.status == "closed"
        assert session.ended_at is not None
        
        # Archive session
        session.archive_session()
        assert session.status == "archived"
    
    def test_session_feedback(self, test_db):
        """Test session feedback functionality."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        # Set feedback
        session.set_feedback("positive", 5)
        assert session.user_feedback == "positive"
        assert session.rating == 5
        
        # Test rating clamping
        session.set_feedback("neutral", 10)  # Should clamp to 5
        assert session.rating == 5
        
        session.set_feedback("negative", 0)  # Should clamp to 1
        assert session.rating == 1


class TestMessageORM:
    """Test MessageORM model."""
    
    def test_create_message(self, test_db):
        """Test message creation."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello, world!",
            model_name="gpt-3.5-turbo",
            provider="openai"
        )
        test_db.add(message)
        test_db.flush()
        
        assert message.id is not None
        assert message.role == "user"
        assert message.content == "Hello, world!"
        assert message.processing_status == "pending"
        assert message.token_count == 0
    
    def test_message_usage_tracking(self, test_db):
        """Test message usage tracking."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello"
        )
        test_db.add(message)
        test_db.flush()
        
        # Set usage statistics
        message.set_usage_stats(
            prompt_tokens=10,
            completion_tokens=15,
            total_tokens=25
        )
        
        assert message.prompt_tokens == 10
        assert message.completion_tokens == 15
        assert message.total_tokens == 25
        assert message.token_count == 25
        
        # Set costs
        message.set_costs(0.001, 0.002)
        assert message.input_cost == 0.001
        assert message.output_cost == 0.002
        assert message.total_cost == 0.003
    
    def test_message_editing(self, test_db):
        """Test message editing functionality."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Original content"
        )
        test_db.add(message)
        test_db.flush()
        
        # Edit message
        message.edit_content("Updated content")
        assert message.content == "Updated content"
        assert message.is_edited is True
        assert message.edited_at is not None
    
    def test_message_feedback(self, test_db):
        """Test message feedback functionality."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="assistant",
            content="Helpful response"
        )
        test_db.add(message)
        test_db.flush()
        
        # Set feedback
        message.set_feedback("helpful", "This was very helpful!")
        assert message.user_feedback == "helpful"
        assert message.feedback_text == "This was very helpful!"
    
    def test_message_processing_status(self, test_db):
        """Test message processing status management."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="assistant",
            content="Response"
        )
        test_db.add(message)
        test_db.flush()
        
        # Mark as processed
        message.mark_as_processed()
        assert message.processing_status == "completed"
        assert message.error_message is None
        
        # Mark as failed
        message.mark_as_failed("API error")
        assert message.processing_status == "failed"
        assert message.error_message == "API error"
    
    def test_message_conversation_format(self, test_db):
        """Test message conversion to conversation format."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello",
            metadata={"test": "value"}
        )
        test_db.add(message)
        test_db.flush()
        
        conv_format = message.to_conversation_format()
        assert conv_format["role"] == "user"
        assert conv_format["content"] == "Hello"
        assert "timestamp" in conv_format
        assert conv_format["metadata"]["test"] == "value"


class TestMemoryORM:
    """Test MemoryORM model."""
    
    def test_create_memory(self, test_db):
        """Test memory creation."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="user_preference",
            value="Prefers short responses",
            memory_type="preference",
            category="user_settings",
            importance_score=0.8,
            confidence_score=0.9,
            source="user"
        )
        test_db.add(memory)
        test_db.flush()
        
        assert memory.id is not None
        assert memory.key == "user_preference"
        assert memory.value == "Prefers short responses"
        assert memory.memory_type == "preference"
        assert memory.importance_score == 0.8
        assert memory.confidence_score == 0.9
        assert memory.is_active is True
        assert memory.is_persistent is False
    
    def test_memory_access_tracking(self, test_db):
        """Test memory access tracking."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        initial_access = memory.access_count
        memory.access()
        assert memory.access_count == initial_access + 1
        assert memory.last_accessed is not None
    
    def test_memory_importance_management(self, test_db):
        """Test memory importance management."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        # Set importance
        memory.set_importance(0.9)
        assert memory.importance_score == 0.9
        
        # Test clamping
        memory.set_importance(1.5)
        assert memory.importance_score == 1.0
        
        memory.set_importance(-0.1)
        assert memory.importance_score == 0.0
    
    def test_memory_tagging(self, test_db):
        """Test memory tagging functionality."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        # Add tags
        memory.add_tag("important")
        memory.add_tag("preference")
        assert "important" in memory.tags
        assert "preference" in memory.tags
        
        # Remove tag
        memory.remove_tag("important")
        assert "important" not in memory.tags
        assert "preference" in memory.tags
    
    def test_memory_expiration(self, test_db):
        """Test memory expiration functionality."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        # Memory without expiration
        memory1 = MemoryORM(
            session_id=session.id,
            key="no_expiry",
            value="test_value"
        )
        test_db.add(memory1)
        test_db.flush()
        
        assert memory1.is_expired() is False
        
        # Memory with expiration
        future_date = datetime.utcnow()
        memory2 = MemoryORM(
            session_id=session.id,
            key="with_expiry",
            value="test_value",
            expires_at=future_date
        )
        test_db.add(memory2)
        test_db.flush()
        
        assert memory2.is_expired() is True  # Since we set it to current time
    
    def test_memory_decay_factor(self, test_db):
        """Test memory decay factor calculation."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value",
            access_count=5
        )
        test_db.add(memory)
        test_db.flush()
        
        # Test decay factor calculation
        decay = memory.get_decay_factor()
        assert isinstance(decay, float)
        assert 0.0 <= decay <= 1.0
    
    def test_memory_state_management(self, test_db):
        """Test memory state management."""
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test_key",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        # Test activation/deactivation
        memory.deactivate()
        assert memory.is_active is False
        
        memory.activate()
        assert memory.is_active is True
        
        # Test persistence
        memory.make_persistent()
        assert memory.is_persistent is True


class TestModelRelationships:
    """Test model relationships."""
    
    def test_complete_relationship_chain(self, test_db):
        """Test complete relationship chain: User -> Session -> Message/Memory."""
        # Create user
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        # Create session
        session = SessionORM(
            user_id=user.id,
            title="Test Session",
            model_name="gpt-3.5-turbo"
        )
        test_db.add(session)
        test_db.flush()
        
        # Create messages
        user_message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello"
        )
        assistant_message = MessageORM(
            session_id=session.id,
            role="assistant",
            content="Hi there!"
        )
        test_db.add(user_message)
        test_db.add(assistant_message)
        test_db.flush()
        
        # Create memories
        memory1 = MemoryORM(
            session_id=session.id,
            key="greeting",
            value="User said hello",
            memory_type="conversation"
        )
        memory2 = MemoryORM(
            session_id=session.id,
            key="preference",
            value="Prefers casual tone",
            memory_type="preference"
        )
        test_db.add(memory1)
        test_db.add(memory2)
        test_db.flush()
        
        # Test relationships
        assert user.id == session.user_id
        assert session.id == user_message.session_id
        assert session.id == assistant_message.session_id
        assert session.id == memory1.session_id
        assert session.id == memory2.session_id
        
        # Test relationship traversal
        assert len(user.sessions) == 1
        assert user.sessions[0].id == session.id
        
        assert len(session.messages) == 2
        assert session.messages[0].id == user_message.id
        assert session.messages[1].id == assistant_message.id
        
        assert len(session.memories) == 2
        assert session.memories[0].id == memory1.id
        assert session.memories[1].id == memory2.id
    
    def test_cascade_delete(self, test_db):
        """Test cascade delete functionality."""
        # Create user with session, messages, and memories
        user = UserORM(
            email="test@example.com",
            username="testuser",
            hashed_password="hashed_password"
        )
        test_db.add(user)
        test_db.flush()
        
        session = SessionORM(
            user_id=user.id,
            title="Test Session"
        )
        test_db.add(session)
        test_db.flush()
        
        message = MessageORM(
            session_id=session.id,
            role="user",
            content="Hello"
        )
        test_db.add(message)
        test_db.flush()
        
        memory = MemoryORM(
            session_id=session.id,
            key="test",
            value="test_value"
        )
        test_db.add(memory)
        test_db.flush()
        
        session_id = session.id
        message_id = message.id
        memory_id = memory.id
        
        # Delete session should cascade to messages and memories
        test_db.delete(session)
        test_db.flush()
        
        # Verify cascade delete
        assert test_db.get(SessionORM, session_id) is None
        assert test_db.get(MessageORM, message_id) is None
        assert test_db.get(MemoryORM, memory_id) is None


if __name__ == "__main__":
    pytest.main([__file__])