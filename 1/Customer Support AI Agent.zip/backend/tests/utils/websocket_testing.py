"""
WebSocket testing utilities for testing real-time communication.

This module provides utilities for testing WebSocket connections, message passing,
and real-time features.
"""

import asyncio
import json
import websockets
import time
from typing import Dict, Any, List, Optional, Callable, Set
from datetime import datetime, timedelta
from uuid import uuid4
from dataclasses import dataclass
from enum import Enum
import pytest


class WebSocketMessageType(Enum):
    """Types of WebSocket messages."""
    TEXT = "text"
    JSON = "json"
    BINARY = "binary"
    PING = "ping"
    PONG = "pong"
    CONTROL = "control"


@dataclass
class WebSocketMessage:
    """WebSocket message container."""
    message_type: WebSocketMessageType
    content: Any
    timestamp: datetime
    client_id: str
    server_received: bool = False
    server_processed: bool = False
    server_response: Optional[Any] = None
    metadata: Dict[str, Any] = None


class WebSocketTestingUtils:
    """
    Comprehensive WebSocket testing utilities.
    """
    
    def __init__(self, base_url: str = "ws://testserver/ws"):
        """
        Initialize WebSocket testing utilities.
        
        Args:
            base_url: Base WebSocket URL
        """
        self.base_url = base_url
        self.active_connections = {}
        self.message_history = []
        self.test_scenarios = []
        self.performance_metrics = {}
    
    # ==============================================================================
    # CONNECTION MANAGEMENT
    # ==============================================================================
    
    async def create_connection(self, client_id: str = None, 
                              headers: Dict[str, str] = None,
                              url_params: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Create a WebSocket connection for testing.
        
        Args:
            client_id: Unique client identifier
            headers: Connection headers
            url_params: URL parameters
            
        Returns:
            Connection information
        """
        client_id = client_id or str(uuid4())
        
        # Build connection URL
        connection_url = self._build_connection_url(url_params)
        
        connection_info = {
            "client_id": client_id,
            "url": connection_url,
            "headers": headers or {},
            "connected_at": datetime.utcnow(),
            "status": "connecting",
            "messages_sent": 0,
            "messages_received": 0,
            "errors": [],
            "websocket": None
        }
        
        try:
            # Create WebSocket connection
            if headers:
                websocket = await websockets.connect(
                    connection_url,
                    extra_headers=headers,
                    timeout=30
                )
            else:
                websocket = await websockets.connect(
                    connection_url,
                    timeout=30
                )
            
            connection_info["websocket"] = websocket
            connection_info["status"] = "connected"
            self.active_connections[client_id] = connection_info
            
            # Start message handler for this connection
            asyncio.create_task(self._handle_connection_messages(client_id, websocket))
            
        except Exception as e:
            connection_info["status"] = "failed"
            connection_info["errors"].append(str(e))
            raise
        
        return connection_info
    
    async def close_connection(self, client_id: str) -> bool:
        """
        Close a WebSocket connection.
        
        Args:
            client_id: Client identifier
            
        Returns:
            True if connection was closed successfully
        """
        if client_id not in self.active_connections:
            return False
        
        connection_info = self.active_connections[client_id]
        
        try:
            if connection_info["websocket"]:
                await connection_info["websocket"].close()
            
            connection_info["status"] = "closed"
            del self.active_connections[client_id]
            return True
            
        except Exception as e:
            connection_info["errors"].append(str(e))
            return False
    
    async def close_all_connections(self):
        """Close all active connections."""
        client_ids = list(self.active_connections.keys())
        
        for client_id in client_ids:
            await self.close_connection(client_id)
    
    # ==============================================================================
    # MESSAGE SENDING AND RECEIVING
    # ==============================================================================
    
    async def send_message(self, client_id: str, message: Any, 
                         message_type: WebSocketMessageType = WebSocketMessageType.TEXT) -> bool:
        """
        Send a message through WebSocket connection.
        
        Args:
            client_id: Client identifier
            message: Message content
            message_type: Type of message
            
        Returns:
            True if message was sent successfully
        """
        if client_id not in self.active_connections:
            return False
        
        connection_info = self.active_connections[client_id]
        
        if connection_info["status"] != "connected":
            return False
        
        try:
            websocket = connection_info["websocket"]
            
            # Send message based on type
            if message_type == WebSocketMessageType.TEXT:
                await websocket.send(str(message))
            elif message_type == WebSocketMessageType.JSON:
                await websocket.send(json.dumps(message))
            elif message_type == WebSocketMessageType.PING:
                await websocket.ping()
            else:
                # For binary and other types, send as text for testing
                await websocket.send(str(message))
            
            connection_info["messages_sent"] += 1
            
            # Log message
            message_record = WebSocketMessage(
                message_type=message_type,
                content=message,
                timestamp=datetime.utcnow(),
                client_id=client_id
            )
            self.message_history.append(message_record)
            
            return True
            
        except Exception as e:
            connection_info["errors"].append(str(e))
            return False
    
    async def receive_message(self, client_id: str, timeout: float = 30.0) -> Optional[WebSocketMessage]:
        """
        Receive a message from WebSocket connection.
        
        Args:
            client_id: Client identifier
            timeout: Timeout in seconds
            
        Returns:
            Received message or None if timeout
        """
        if client_id not in self.active_connections:
            return None
        
        connection_info = self.active_connections[client_id]
        
        if connection_info["status"] != "connected":
            return None
        
        try:
            websocket = connection_info["websocket"]
            
            # Set timeout for receiving
            message = await asyncio.wait_for(websocket.recv(), timeout=timeout)
            
            # Determine message type
            message_type = WebSocketMessageType.TEXT
            try:
                # Try to parse as JSON
                json.loads(message)
                message_type = WebSocketMessageType.JSON
            except (json.JSONDecodeError, TypeError):
                pass
            
            connection_info["messages_received"] += 1
            
            # Create message record
            message_record = WebSocketMessage(
                message_type=message_type,
                content=message,
                timestamp=datetime.utcnow(),
                client_id=client_id,
                server_received=True
            )
            self.message_history.append(message_record)
            
            return message_record
            
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            connection_info["errors"].append(str(e))
            return None
    
    async def send_and_receive(self, client_id: str, message: Any, 
                             timeout: float = 30.0) -> Optional[WebSocketMessage]:
        """
        Send a message and wait for response.
        
        Args:
            client_id: Client identifier
            message: Message to send
            timeout: Timeout in seconds
            
        Returns:
            Response message or None if timeout/error
        """
        # Send message
        sent = await self.send_message(client_id, message)
        if not sent:
            return None
        
        # Receive response
        return await self.receive_message(client_id, timeout)
    
    # ==============================================================================
    # BATCH OPERATIONS
    # ==============================================================================
    
    async def create_multiple_connections(self, num_connections: int, 
                                        base_client_id: str = None) -> List[str]:
        """
        Create multiple WebSocket connections.
        
        Args:
            num_connections: Number of connections to create
            base_client_id: Base ID for generating client IDs
            
        Returns:
            List of client identifiers
        """
        client_ids = []
        base = base_client_id or str(uuid4())[:8]
        
        for i in range(num_connections):
            client_id = f"{base}_client_{i}"
            try:
                await self.create_connection(client_id)
                client_ids.append(client_id)
            except Exception as e:
                print(f"Failed to create connection {client_id}: {e}")
        
        return client_ids
    
    async def broadcast_message(self, client_ids: List[str], message: Any) -> Dict[str, bool]:
        """
        Broadcast a message to multiple clients.
        
        Args:
            client_ids: List of client identifiers
            message: Message to broadcast
            
        Returns:
            Dictionary of client_id -> success status
        """
        results = {}
        
        # Send messages concurrently
        tasks = []
        for client_id in client_ids:
            task = asyncio.create_task(self.send_message(client_id, message))
            tasks.append((client_id, task))
        
        # Wait for all sends to complete
        for client_id, task in tasks:
            try:
                results[client_id] = await task
            except Exception as e:
                results[client_id] = False
        
        return results
    
    async def receive_from_all(self, client_ids: List[str], timeout: float = 30.0) -> Dict[str, Optional[WebSocketMessage]]:
        """
        Receive messages from multiple clients.
        
        Args:
            client_ids: List of client identifiers
            timeout: Timeout in seconds
            
        Returns:
            Dictionary of client_id -> received message
        """
        results = {}
        
        # Receive messages concurrently
        tasks = []
        for client_id in client_ids:
            task = asyncio.create_task(self.receive_message(client_id, timeout))
            tasks.append((client_id, task))
        
        # Wait for all receives to complete
        for client_id, task in tasks:
            try:
                results[client_id] = await task
            except Exception as e:
                results[client_id] = None
        
        return results
    
    # ==============================================================================
    # TEST SCENARIOS
    # ==============================================================================
    
    def create_connection_test_scenario(self, name: str, num_connections: int) -> Dict[str, Any]:
        """
        Create a connection test scenario.
        
        Args:
            name: Scenario name
            num_connections: Number of connections to test
            
        Returns:
            Scenario configuration
        """
        return {
            "name": name,
            "type": "connection_test",
            "description": f"Test creation and management of {num_connections} connections",
            "num_connections": num_connections,
            "steps": [
                {"action": "create_connections", "count": num_connections},
                {"action": "verify_connections", "expected_count": num_connections},
                {"action": "send_test_messages", "message": "Connection test message"},
                {"action": "receive_responses"},
                {"action": "close_connections"}
            ]
        }
    
    def create_message_test_scenario(self, name: str, num_messages: int) -> Dict[str, Any]:
        """
        Create a message test scenario.
        
        Args:
            name: Scenario name
            num_messages: Number of messages to test
            
        Returns:
            Scenario configuration
        """
        return {
            "name": name,
            "type": "message_test",
            "description": f"Test sending and receiving {num_messages} messages",
            "num_messages": num_messages,
            "steps": [
                {"action": "create_connection"},
                {"action": "send_messages", "count": num_messages, "message": "Test message {i}"},
                {"action": "receive_messages", "expected_count": num_messages},
                {"action": "verify_message_order"},
                {"action": "close_connection"}
            ]
        }
    
    def create_concurrent_test_scenario(self, name: str, num_clients: int, messages_per_client: int) -> Dict[str, Any]:
        """
        Create a concurrent testing scenario.
        
        Args:
            name: Scenario name
            num_clients: Number of concurrent clients
            messages_per_client: Messages to send per client
            
        Returns:
            Scenario configuration
        """
        return {
            "name": name,
            "type": "concurrent_test",
            "description": f"Test {num_clients} concurrent clients sending {messages_per_client} messages each",
            "num_clients": num_clients,
            "messages_per_client": messages_per_client,
            "steps": [
                {"action": "create_multiple_connections", "count": num_clients},
                {"action": "concurrent_messaging", "messages_per_client": messages_per_client},
                {"action": "measure_performance"},
                {"action": "verify_all_messages"},
                {"action": "cleanup_connections"}
            ]
        }
    
    def create_load_test_scenario(self, name: str, duration_seconds: int, 
                                connection_rate: float) -> Dict[str, Any]:
        """
        Create a load test scenario.
        
        Args:
            name: Scenario name
            duration_seconds: Test duration in seconds
            connection_rate: Connections per second
            
        Returns:
            Scenario configuration
        """
        return {
            "name": name,
            "type": "load_test",
            "description": f"Load test for {duration_seconds} seconds with {connection_rate} connections/second",
            "duration_seconds": duration_seconds,
            "connection_rate": connection_rate,
            "steps": [
                {"action": "gradual_connection_ramp_up", "rate": connection_rate},
                {"action": "sustained_load", "duration": duration_seconds},
                {"action": "measure_system_performance"},
                {"action": "gradual_connection_ramp_down"},
                {"action": "cleanup_and_report"}
            ]
        }
    
    async def run_test_scenario(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run a test scenario.
        
        Args:
            scenario: Scenario configuration
            
        Returns:
            Scenario execution results
        """
        results = {
            "scenario_name": scenario["name"],
            "start_time": datetime.utcnow(),
            "steps_completed": [],
            "errors": [],
            "metrics": {}
        }
        
        try:
            for step in scenario["steps"]:
                step_name = step["action"]
                
                if step_name == "create_connections":
                    count = step["count"]
                    client_ids = await self.create_multiple_connections(count)
                    results["steps_completed"].append({
                        "step": step_name,
                        "client_ids": client_ids,
                        "success": True
                    })
                
                elif step_name == "verify_connections":
                    expected_count = step["expected_count"]
                    actual_count = len(self.active_connections)
                    results["steps_completed"].append({
                        "step": step_name,
                        "expected": expected_count,
                        "actual": actual_count,
                        "success": actual_count == expected_count
                    })
                
                elif step_name == "send_test_messages":
                    message = step["message"]
                    client_ids = list(self.active_connections.keys())
                    results["broadcast_result"] = await self.broadcast_message(client_ids, message)
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": True
                    })
                
                elif step_name == "receive_responses":
                    client_ids = list(self.active_connections.keys())
                    results["receive_result"] = await self.receive_from_all(client_ids)
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": True
                    })
                
                elif step_name == "send_messages":
                    count = step["count"]
                    message_template = step["message"]
                    client_ids = list(self.active_connections.keys())
                    
                    for i in range(count):
                        message = message_template.format(i=i)
                        await self.broadcast_message(client_ids, message)
                    
                    results["steps_completed"].append({
                        "step": step_name,
                        "messages_sent": count,
                        "success": True
                    })
                
                elif step_name == "close_connections":
                    await self.close_all_connections()
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": True
                    })
                
                elif step_name == "create_connection":
                    connection_info = await self.create_connection()
                    results["client_id"] = connection_info["client_id"]
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": True
                    })
                
                elif step_name == "close_connection":
                    client_id = results.get("client_id")
                    if client_id:
                        await self.close_connection(client_id)
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": True
                    })
                
                elif step_name == "concurrent_messaging":
                    messages_per_client = step["messages_per_client"]
                    client_ids = list(self.active_connections.keys())
                    
                    for i in range(messages_per_client):
                        message = f"Concurrent message {i}"
                        await self.broadcast_message(client_ids, message)
                    
                    results["steps_completed"].append({
                        "step": step_name,
                        "total_messages": len(client_ids) * messages_per_client,
                        "success": True
                    })
                
                else:
                    results["steps_completed"].append({
                        "step": step_name,
                        "success": False,
                        "error": "Unknown step action"
                    })
        
        except Exception as e:
            results["errors"].append(str(e))
        
        finally:
            # Cleanup
            await self.close_all_connections()
            results["end_time"] = datetime.utcnow()
            results["duration_seconds"] = (results["end_time"] - results["start_time"]).total_seconds()
        
        return results
    
    async def run_scenario_batch(self, scenarios: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Run multiple scenarios in batch.
        
        Args:
            scenarios: List of scenarios to run
            
        Returns:
            Batch execution results
        """
        results = {
            "total_scenarios": len(scenarios),
            "completed_scenarios": 0,
            "failed_scenarios": 0,
            "scenario_results": [],
            "overall_metrics": {}
        }
        
        for scenario in scenarios:
            try:
                result = await self.run_test_scenario(scenario)
                results["scenario_results"].append(result)
                
                if not result["errors"]:
                    results["completed_scenarios"] += 1
                else:
                    results["failed_scenarios"] += 1
                    
            except Exception as e:
                results["scenario_results"].append({
                    "scenario_name": scenario["name"],
                    "errors": [str(e)]
                })
                results["failed_scenarios"] += 1
        
        # Calculate overall metrics
        total_messages = sum(
            len([msg for msg in self.message_history if msg.timestamp >= result["start_time"]])
            for result in results["scenario_results"]
        )
        
        results["overall_metrics"] = {
            "total_messages_sent": total_messages,
            "success_rate": (results["completed_scenarios"] / results["total_scenarios"]) * 100,
            "average_scenario_duration": sum(
                result.get("duration_seconds", 0) 
                for result in results["scenario_results"]
            ) / results["total_scenarios"]
        }
        
        return results
    
    # ==============================================================================
    # PERFORMANCE TESTING
    # ==============================================================================
    
    async def measure_connection_performance(self, num_connections: int = 100) -> Dict[str, Any]:
        """
        Measure WebSocket connection performance.
        
        Args:
            num_connections: Number of connections to test
            
        Returns:
            Performance metrics
        """
        results = {
            "num_connections": num_connections,
            "connection_times": [],
            "success_rate": 0.0,
            "average_connection_time": 0.0,
            "errors": []
        }
        
        start_time = datetime.utcnow()
        
        # Create connections and measure time
        for i in range(num_connections):
            try:
                conn_start = time.time()
                
                await self.create_connection(f"perf_test_client_{i}")
                
                conn_end = time.time()
                connection_time = conn_end - conn_start
                results["connection_times"].append(connection_time)
                
            except Exception as e:
                results["errors"].append(f"Connection {i} failed: {str(e)}")
        
        end_time = datetime.utcnow()
        total_time = (end_time - start_time).total_seconds()
        
        # Calculate metrics
        successful_connections = len(results["connection_times"])
        results["success_rate"] = (successful_connections / num_connections) * 100
        results["average_connection_time"] = sum(results["connection_times"]) / successful_connections if successful_connections > 0 else 0
        results["connections_per_second"] = successful_connections / total_time if total_time > 0 else 0
        results["total_time_seconds"] = total_time
        
        # Cleanup
        await self.close_all_connections()
        
        return results
    
    async def measure_message_performance(self, num_messages: int = 1000) -> Dict[str, Any]:
        """
        Measure message sending performance.
        
        Args:
            num_messages: Number of messages to send
            
        Returns:
            Performance metrics
        """
        results = {
            "num_messages": num_messages,
            "send_times": [],
            "receive_times": [],
            "round_trip_times": [],
            "success_rate": 0.0,
            "errors": []
        }
        
        try:
            # Create single connection for testing
            client_id = "perf_test_client"
            await self.create_connection(client_id)
            
            # Send and measure messages
            for i in range(num_messages):
                try:
                    # Send message
                    send_start = time.time()
                    await self.send_message(client_id, f"Performance test message {i}")
                    send_end = time.time()
                    
                    # Receive response
                    receive_start = time.time()
                    response = await self.receive_message(client_id, timeout=5.0)
                    receive_end = time.time()
                    
                    send_time = send_end - send_start
                    receive_time = receive_end - receive_start if response else 0
                    round_trip_time = receive_end - send_start if response else 0
                    
                    results["send_times"].append(send_time)
                    results["receive_times"].append(receive_time)
                    results["round_trip_times"].append(round_trip_time)
                    
                except Exception as e:
                    results["errors"].append(f"Message {i} failed: {str(e)}")
        
        finally:
            await self.close_connection(client_id)
        
        # Calculate metrics
        successful_messages = len(results["round_trip_times"])
        results["success_rate"] = (successful_messages / num_messages) * 100
        results["average_send_time"] = sum(results["send_times"]) / successful_messages if successful_messages > 0 else 0
        results["average_receive_time"] = sum(results["receive_times"]) / successful_messages if successful_messages > 0 else 0
        results["average_round_trip_time"] = sum(results["round_trip_times"]) / successful_messages if successful_messages > 0 else 0
        results["messages_per_second"] = successful_messages / sum(results["round_trip_times"]) if results["round_trip_times"] else 0
        
        return results
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    def _build_connection_url(self, url_params: Dict[str, str] = None) -> str:
        """Build WebSocket connection URL with parameters."""
        url = self.base_url
        
        if url_params:
            params = "&".join([f"{k}={v}" for k, v in url_params.items()])
            if "?" in url:
                url += f"&{params}"
            else:
                url += f"?{params}"
        
        return url
    
    async def _handle_connection_messages(self, client_id: str, websocket):
        """
        Handle incoming messages for a connection.
        
        Args:
            client_id: Client identifier
            websocket: WebSocket connection
        """
        try:
            async for message in websocket:
                # Process message (could be extended for different message types)
                message_record = WebSocketMessage(
                    message_type=WebSocketMessageType.TEXT,
                    content=message,
                    timestamp=datetime.utcnow(),
                    client_id=client_id,
                    server_received=True
                )
                self.message_history.append(message_record)
                
                # Update connection info
                if client_id in self.active_connections:
                    self.active_connections[client_id]["messages_received"] += 1
        
        except websockets.exceptions.ConnectionClosed:
            if client_id in self.active_connections:
                self.active_connections[client_id]["status"] = "closed"
        except Exception as e:
            if client_id in self.active_connections:
                self.active_connections[client_id]["errors"].append(str(e))
    
    def get_connection_status(self, client_id: str = None) -> Dict[str, Any]:
        """
        Get connection status information.
        
        Args:
            client_id: Specific client ID or None for all
            
        Returns:
            Connection status information
        """
        if client_id:
            if client_id in self.active_connections:
                return self.active_connections[client_id]
            else:
                return {"status": "not_found"}
        
        return {
            "total_connections": len(self.active_connections),
            "connections": self.active_connections,
            "message_history_count": len(self.message_history)
        }
    
    def get_message_history(self, client_id: str = None, 
                          message_type: WebSocketMessageType = None) -> List[WebSocketMessage]:
        """
        Get message history with optional filtering.
        
        Args:
            client_id: Filter by client ID
            message_type: Filter by message type
            
        Returns:
            Filtered message history
        """
        messages = self.message_history
        
        if client_id:
            messages = [msg for msg in messages if msg.client_id == client_id]
        
        if message_type:
            messages = [msg for msg in messages if msg.message_type == message_type]
        
        return messages
    
    def clear_history(self):
        """Clear message history."""
        self.message_history.clear()
    
    def generate_test_messages(self, count: int, template: str = "Test message {i}") -> List[str]:
        """Generate test messages using template."""
        return [template.format(i=i) for i in range(count)]