"""
Test data generator for creating consistent, realistic test data.

This module provides utilities to generate various types of test data including
users, sessions, messages, agents, and file uploads with realistic attributes.
"""

import random
import uuid
import string
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from faker import Faker
import json
import base64

fake = Faker()


class TestDataGenerator:
    """
    Generate realistic test data for various application components.
    """
    
    def __init__(self, seed: Optional[int] = None):
        """
        Initialize the test data generator.
        
        Args:
            seed: Optional random seed for reproducible test data
        """
        if seed:
            random.seed(seed)
            fake.seed_instance(seed)
    
    # ==============================================================================
    # USER DATA GENERATION
    # ==============================================================================
    
    def generate_user(self, **overrides) -> Dict[str, Any]:
        """
        Generate a realistic user object.
        
        Args:
            **overrides: Any field to override in the generated user
            
        Returns:
            Dictionary representing a user
        """
        user_id = str(uuid.uuid4())
        username = fake.user_name()[:20]  # Limit length
        email = fake.email()
        first_name = fake.first_name()
        last_name = fake.last_name()
        
        user = {
            "id": user_id,
            "username": username,
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "password": "TempPass123!",
            "is_active": True,
            "is_verified": random.choice([True, False]),
            "is_admin": random.choice([True, False]),
            "created_at": fake.date_time_between(start_date='-1y', end_date='now'),
            "updated_at": fake.date_time_between(start_date='-30d', end_date='now'),
            "last_login": fake.date_time_between(start_date='-30d', end_date='now') if random.random() > 0.3 else None,
            "profile": {
                "avatar_url": f"https://example.com/avatars/{user_id}.png",
                "bio": fake.text(max_nb_chars=200) if random.random() > 0.5 else None,
                "location": fake.city() if random.random() > 0.7 else None,
                "timezone": random.choice(['UTC', 'US/Eastern', 'US/Pacific', 'Europe/London']),
                "preferences": {
                    "language": random.choice(['en', 'es', 'fr', 'de']),
                    "notifications": {
                        "email": random.choice([True, False]),
                        "sms": random.choice([True, False]),
                        "push": random.choice([True, False])
                    }
                }
            }
        }
        
        # Apply any overrides
        user.update(overrides)
        return user
    
    def generate_users(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple users."""
        return [self.generate_user(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # SESSION DATA GENERATION  
    # ==============================================================================
    
    def generate_session(self, user_id: Optional[str] = None, **overrides) -> Dict[str, Any]:
        """
        Generate a realistic session object.
        
        Args:
            user_id: Optional user ID to associate with the session
            **overrides: Any field to override
            
        Returns:
            Dictionary representing a session
        """
        session_id = str(uuid.uuid4())
        created_at = fake.date_time_between(start_date='-30d', end_date='now')
        
        session = {
            "id": session_id,
            "user_id": user_id or str(uuid.uuid4()),
            "title": fake.sentence(nb_words=4)[:-1],  # Remove period
            "status": random.choice(['active', 'completed', 'archived', 'escalated']),
            "priority": random.choice(['low', 'medium', 'high', 'urgent']),
            "category": random.choice(['billing', 'technical', 'general', 'feature_request']),
            "created_at": created_at,
            "updated_at": fake.date_time_between(start_date=created_at, end_date='now'),
            "closed_at": fake.date_time_between(start_date=created_at, end_date='now') 
                         if random.random() > 0.6 else None,
            "metadata": {
                "user_agent": fake.user_agent(),
                "ip_address": fake.ipv4(),
                "referrer": fake.url() if random.random() > 0.7 else None,
                "tags": random.sample(['new_customer', 'vip', 'urgent', 'follow_up'], 
                                    k=random.randint(0, 2))
            }
        }
        
        session.update(overrides)
        return session
    
    def generate_sessions(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple sessions."""
        return [self.generate_session(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # MESSAGE DATA GENERATION
    # ==============================================================================
    
    def generate_message(self, session_id: Optional[str] = None, 
                        user_id: Optional[str] = None,
                        agent_id: Optional[str] = None, 
                        **overrides) -> Dict[str, Any]:
        """
        Generate a realistic message object.
        
        Args:
            session_id: Optional session ID to associate with the message
            user_id: Optional user ID (for user messages)
            agent_id: Optional agent ID (for agent messages)
            **overrides: Any field to override
            
        Returns:
            Dictionary representing a message
        """
        message_id = str(uuid.uuid4())
        message_type = random.choice(['user', 'agent', 'system'])
        created_at = fake.date_time_between(start_date='-30d', end_date='now')
        
        # Generate message content based on type
        if message_type == 'user':
            content = random.choice([
                "Hello, I need help with my account",
                "I'm having trouble logging in",
                "Can you help me understand my billing?",
                "I want to update my payment method",
                "I'm getting an error message",
                "How do I reset my password?",
                "I need to speak with a human agent",
                "Thank you for your help!"
            ])
        elif message_type == 'agent':
            content = random.choice([
                "I'd be happy to help you with that.",
                "Let me look into that for you.",
                "I understand your concern.",
                "Here's what I can do to assist you.",
                "Is there anything else I can help you with?",
                "I'm checking that information now.",
                "You should receive a confirmation email shortly.",
                "Let me escalate this to our specialist team."
            ])
        else:  # system
            content = "System notification"
        
        message = {
            "id": message_id,
            "session_id": session_id or str(uuid.uuid4()),
            "message_type": message_type,
            "content": content,
            "sender_id": user_id or agent_id or str(uuid.uuid4()),
            "sender_type": "user" if user_id else ("agent" if agent_id else "system"),
            "created_at": created_at,
            "updated_at": fake.date_time_between(start_date=created_at, end_date='now'),
            "metadata": {
                "message_length": len(content),
                "word_count": len(content.split()),
                "read": random.choice([True, False]),
                "edited": random.choice([True, False]) if random.random() > 0.8 else False,
                "attachments": random.choice([[], [{"filename": "document.pdf", "size": 1024}]]) 
                              if random.random() > 0.7 else []
            },
            "sentiment": random.choice(['positive', 'neutral', 'negative', 'mixed']) 
                        if random.random() > 0.3 else None
        }
        
        message.update(overrides)
        return message
    
    def generate_messages(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple messages."""
        return [self.generate_message(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # AGENT DATA GENERATION
    # ==============================================================================
    
    def generate_agent(self, **overrides) -> Dict[str, Any]:
        """
        Generate a realistic agent object.
        
        Args:
            **overrides: Any field to override
            
        Returns:
            Dictionary representing an agent
        """
        agent_id = str(uuid.uuid4())
        created_at = fake.date_time_between(start_date='-1y', end_date='now')
        
        agent = {
            "id": agent_id,
            "name": fake.name(),
            "description": fake.text(max_nb_chars=200),
            "type": random.choice(['chatbot', 'human', 'hybrid']),
            "status": random.choice(['active', 'inactive', 'maintenance', 'training']),
            "capabilities": random.sample([
                'billing_support', 'technical_support', 'account_management',
                'product_info', 'order_troubleshooting', 'general_inquiry',
                'escalation_handler', 'billing_specialist', 'technical_expert'
            ], k=random.randint(2, 5)),
            "languages": random.sample(['en', 'es', 'fr', 'de', 'it', 'pt'], k=random.randint(1, 3)),
            "created_at": created_at,
            "updated_at": fake.date_time_between(start_date=created_at, end_date='now'),
            "last_active": fake.date_time_between(start_date='-7d', end_date='now') 
                          if random.random() > 0.2 else None,
            "configuration": {
                "response_style": random.choice(['professional', 'friendly', 'casual', 'formal']),
                "max_concurrent_sessions": random.randint(3, 15),
                "escalation_threshold": random.randint(1, 10),
                "response_delay_range": [0, random.randint(1, 30)],  # seconds
            },
            "metrics": {
                "total_sessions_handled": random.randint(50, 5000),
                "average_satisfaction_rating": round(random.uniform(3.0, 5.0), 1),
                "average_response_time": random.randint(10, 300),  # seconds
                "escalation_rate": round(random.uniform(0.05, 0.25), 2),
            },
            "metadata": {
                "version": f"1.{random.randint(0, 5)}.{random.randint(0, 10)}",
                "model": random.choice(['gpt-4', 'claude-3', 'custom_llm']) 
                        if random.choice(['chatbot', 'hybrid']) else None,
                "training_data_version": f"2024.{random.randint(1, 12)}"
            }
        }
        
        agent.update(overrides)
        return agent
    
    def generate_agents(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple agents."""
        return [self.generate_agent(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # FILE DATA GENERATION
    # ==============================================================================
    
    def generate_file(self, user_id: Optional[str] = None, **overrides) -> Dict[str, Any]:
        """
        Generate a realistic file object.
        
        Args:
            user_id: Optional user ID who uploaded the file
            **overrides: Any field to override
            
        Returns:
            Dictionary representing a file
        """
        file_id = str(uuid.uuid4())
        
        # File types and extensions
        file_types = {
            'image': ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'],
            'document': ['pdf', 'doc', 'docx', 'txt', 'rtf'],
            'spreadsheet': ['xls', 'xlsx', 'csv'],
            'presentation': ['ppt', 'pptx'],
            'archive': ['zip', 'rar', '7z']
        }
        
        file_type = random.choice(list(file_types.keys()))
        extension = random.choice(file_types[file_type])
        filename = f"{fake.word()}_{fake.random_int(1000, 9999)}.{extension}"
        
        file = {
            "id": file_id,
            "filename": filename,
            "original_filename": filename,
            "file_path": f"/uploads/{file_id}/{filename}",
            "file_size": random.randint(1024, 10 * 1024 * 1024),  # 1KB to 10MB
            "mime_type": self._get_mime_type(extension),
            "file_type": file_type,
            "uploaded_by": user_id or str(uuid.uuid4()),
            "created_at": fake.date_time_between(start_date='-30d', end_date='now'),
            "updated_at": fake.date_time_between(start_date='-30d', end_date='now'),
            "metadata": {
                "checksum": fake.sha256()[:32],
                "encoding": random.choice(['utf-8', 'ascii', 'binary']),
                "compression": random.choice(['none', 'gzip', 'bz2']) if file_type == 'archive' else 'none',
                "encryption": random.choice([True, False]) if random.random() > 0.8 else False,
            },
            "processing_status": random.choice(['pending', 'processing', 'completed', 'failed']),
            "virus_scanned": random.choice([True, False]),
            "accessible": random.choice([True, False]),
            "tags": random.sample(['customer_upload', 'receipt', 'screenshot', 'document', 'backup'], 
                                k=random.randint(0, 3))
        }
        
        file.update(overrides)
        return file
    
    def generate_files(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple files."""
        return [self.generate_file(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # CONVERSATION DATA GENERATION
    # ==============================================================================
    
    def generate_conversation(self, user_id: Optional[str] = None, 
                             agent_id: Optional[str] = None, 
                             num_messages: int = 5, **overrides) -> Dict[str, Any]:
        """
        Generate a complete conversation with multiple messages.
        
        Args:
            user_id: Optional user ID
            agent_id: Optional agent ID  
            num_messages: Number of messages to generate
            **overrides: Any field to override
            
        Returns:
            Dictionary representing a conversation
        """
        session = self.generate_session(user_id=user_id)
        session.update(overrides)
        
        messages = []
        message_types = ['user', 'agent']
        
        for i in range(num_messages):
            message_type = message_types[i % 2]  # Alternate between user and agent
            
            if message_type == 'user':
                message = self.generate_message(
                    session_id=session['id'],
                    user_id=user_id,
                    message_type='user'
                )
            else:
                message = self.generate_message(
                    session_id=session['id'],
                    agent_id=agent_id,
                    message_type='agent'
                )
            
            messages.append(message)
        
        conversation = {
            "session": session,
            "messages": messages,
            "summary": fake.sentence(nb_words=10),
            "participant_count": 2,
            "message_count": len(messages),
            "duration_minutes": random.randint(5, 60),
            "status": session['status'],
            "satisfaction_rating": round(random.uniform(3.0, 5.0), 1) 
                                 if session['status'] == 'completed' else None,
        }
        
        return conversation
    
    def generate_conversations(self, count: int, **overrides) -> List[Dict[str, Any]]:
        """Generate multiple conversations."""
        return [self.generate_conversation(**overrides) for _ in range(count)]
    
    # ==============================================================================
    # SYSTEM DATA GENERATION
    # ==============================================================================
    
    def generate_system_metrics(self, **overrides) -> Dict[str, Any]:
        """Generate system metrics data."""
        base_time = datetime.utcnow()
        
        metrics = {
            "timestamp": base_time.isoformat(),
            "uptime_seconds": random.randint(3600, 86400 * 7),  # 1 hour to 7 days
            "cpu_usage": round(random.uniform(10, 90), 1),
            "memory_usage": round(random.uniform(30, 85), 1),
            "disk_usage": round(random.uniform(20, 75), 1),
            "active_connections": random.randint(5, 100),
            "requests_per_minute": random.randint(50, 500),
            "response_time_avg": round(random.uniform(100, 2000), 1),  # milliseconds
            "error_rate": round(random.uniform(0, 0.05), 3),  # 0-5%
            "active_users": random.randint(10, 200),
            "database_connections": random.randint(5, 25),
            "cache_hit_rate": round(random.uniform(0.8, 0.98), 3),
        }
        
        metrics.update(overrides)
        return metrics
    
    def generate_performance_data(self, **overrides) -> Dict[str, Any]:
        """Generate performance test data."""
        return {
            "test_name": fake.sentence(nb_words=3)[:-1],
            "start_time": fake.date_time_between(start_date='-1d', end_date='now').isoformat(),
            "end_time": fake.date_time_between(start_date='-1h', end_date='now').isoformat(),
            "duration_seconds": random.randint(60, 3600),
            "concurrent_users": random.randint(10, 100),
            "total_requests": random.randint(1000, 50000),
            "successful_requests": random.randint(900, 49500),
            "failed_requests": random.randint(0, 500),
            "avg_response_time": round(random.uniform(100, 1000), 2),
            "min_response_time": random.randint(50, 200),
            "max_response_time": random.randint(2000, 10000),
            "requests_per_second": round(random.uniform(10, 100), 2),
            "throughput_mb_s": round(random.uniform(1, 50), 2),
        }
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    def _get_mime_type(self, extension: str) -> str:
        """Get MIME type for file extension."""
        mime_types = {
            'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
            'gif': 'image/gif', 'bmp': 'image/bmp', 'webp': 'image/webp',
            'pdf': 'application/pdf', 'doc': 'application/msword',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'txt': 'text/plain', 'rtf': 'application/rtf',
            'xls': 'application/vnd.ms-excel',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv': 'text/csv',
            'ppt': 'application/vnd.ms-powerpoint',
            'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'zip': 'application/zip', 'rar': 'application/x-rar-compressed',
            '7z': 'application/x-7z-compressed'
        }
        return mime_types.get(extension.lower(), 'application/octet-stream')
    
    def generate_email_verification_token(self, user_id: str) -> str:
        """Generate email verification token."""
        payload = {
            "user_id": user_id,
            "type": "email_verification",
            "exp": datetime.utcnow() + timedelta(hours=24),
            "iat": datetime.utcnow()
        }
        # In real implementation, this would be JWT encoded
        return base64.b64encode(json.dumps(payload).encode()).decode()
    
    def generate_reset_password_token(self, user_id: str) -> str:
        """Generate password reset token."""
        payload = {
            "user_id": user_id,
            "type": "password_reset",
            "exp": datetime.utcnow() + timedelta(hours=1),
            "iat": datetime.utcnow()
        }
        # In real implementation, this would be JWT encoded
        return base64.b64encode(json.dumps(payload).encode()).decode()
    
    def generate_random_string(self, length: int = 10) -> str:
        """Generate a random string."""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    
    def generate_phone_number(self) -> str:
        """Generate a realistic phone number."""
        return fake.phone_number()
    
    def generate_address(self) -> Dict[str, str]:
        """Generate a realistic address."""
        return {
            "street": fake.street_address(),
            "city": fake.city(),
            "state": fake.state_abbr(),
            "postal_code": fake.postcode(),
            "country": "United States"
        }