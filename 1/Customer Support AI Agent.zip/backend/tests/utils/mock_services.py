"""
Mock services for external dependencies during testing.

This module provides mock implementations for services like OpenAI, Redis, 
database, and other external dependencies to enable isolated testing.
"""

import json
import asyncio
from typing import Dict, Any, List, Optional, Callable, Awaitable
from unittest.mock import MagicMock, AsyncMock
from datetime import datetime
import aioredis
from sqlalchemy.ext.asyncio import AsyncSession
import httpx
from uuid import uuid4


class MockOpenAIService:
    """
    Mock OpenAI service for testing AI functionality.
    """
    
    def __init__(self):
        self.chat = MockChatCompletion()
        self.embeddings = MockEmbeddingService()
        self.models = MockModelService()
    
    def configure_response(self, response_type: str, response_data: Dict[str, Any]):
        """Configure mock response for different types."""
        if response_type == 'chat_completion':
            self.chat.configure_response(response_data)
        elif response_type == 'embedding':
            self.embeddings.configure_response(response_data)
    
    async def test_connection(self) -> Dict[str, Any]:
        """Test connection to OpenAI service."""
        return {
            "status": "healthy",
            "available_models": ["gpt-3.5-turbo", "gpt-4", "text-embedding-ada-002"],
            "rate_limit_remaining": 1000,
            "timestamp": datetime.utcnow().isoformat()
        }


class MockChatCompletion:
    """
    Mock chat completion service.
    """
    
    def __init__(self):
        self._default_response = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "This is a test response from the mock OpenAI service."
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": 50,
                "completion_tokens": 20,
                "total_tokens": 70
            }
        }
        self._responses = []
    
    def configure_response(self, response_data: Dict[str, Any]):
        """Configure the response for the next completion."""
        self._responses.append(response_data)
    
    async def create(self, **kwargs) -> Dict[str, Any]:
        """Mock create method."""
        # Return configured response if available
        if self._responses:
            return self._responses.pop(0)
        
        # Return default response
        response = self._default_response.copy()
        
        # Modify response based on input parameters
        if "messages" in kwargs:
            user_message = kwargs["messages"][-1]["content"] if kwargs["messages"] else ""
            if "error" in user_message.lower():
                raise Exception("Mock API Error")
        
        # Simulate different model responses
        model = kwargs.get("model", "gpt-3.5-turbo")
        if model == "gpt-4":
            response["choices"][0]["message"]["content"] = f"Advanced response from {model}: " + response["choices"][0]["message"]["content"]
        
        return response


class MockEmbeddingService:
    """
    Mock embedding service.
    """
    
    def __init__(self):
        self._default_embedding = [0.1] * 1536  # Standard OpenAI embedding size
        self._call_count = 0
    
    def configure_response(self, response_data: Dict[str, Any]):
        """Configure mock embedding response."""
        if "embedding" in response_data:
            self._default_embedding = response_data["embedding"]
    
    async def create(self, **kwargs) -> Dict[str, Any]:
        """Mock embedding creation."""
        self._call_count += 1
        
        return {
            "data": [{
                "object": "embedding",
                "embedding": self._default_embedding,
                "index": 0
            }],
            "usage": {
                "prompt_tokens": 10,
                "total_tokens": 10
            }
        }
    
    async def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Mock document embedding."""
        self._call_count += 1
        return [self._default_embedding for _ in texts]
    
    async def embed_query(self, text: str) -> List[float]:
        """Mock query embedding."""
        self._call_count += 1
        return self._default_embedding


class MockModelService:
    """
    Mock model service.
    """
    
    async def list(self) -> Dict[str, Any]:
        """Mock model listing."""
        return {
            "object": "list",
            "data": [
                {"id": "gpt-3.5-turbo", "object": "model", "created": 1677610602, "owned_by": "openai"},
                {"id": "gpt-4", "object": "model", "created": 1677610602, "owned_by": "openai"},
                {"id": "text-embedding-ada-002", "object": "model", "created": 1677610602, "owned_by": "openai"}
            ]
        }


class MockRedisClient:
    """
    Mock Redis client for testing.
    """
    
    def __init__(self):
        self._data = {}
        self._keys = set()
        self._call_count = 0
    
    async def ping(self) -> bool:
        """Mock ping."""
        return True
    
    async def get(self, key: str) -> Optional[str]:
        """Mock get operation."""
        self._call_count += 1
        return self._data.get(key)
    
    async def set(self, key: str, value: str, **kwargs) -> bool:
        """Mock set operation."""
        self._call_count += 1
        self._data[key] = value
        self._keys.add(key)
        return True
    
    async def setex(self, key: str, seconds: int, value: str) -> bool:
        """Mock setex operation."""
        return await self.set(key, value)
    
    async def delete(self, *keys: str) -> int:
        """Mock delete operation."""
        self._call_count += 1
        deleted = 0
        for key in keys:
            if key in self._data:
                del self._data[key]
                self._keys.discard(key)
                deleted += 1
        return deleted
    
    async def exists(self, key: str) -> int:
        """Mock exists operation."""
        return 1 if key in self._data else 0
    
    async def keys(self, pattern: str = "*") -> List[str]:
        """Mock keys operation."""
        if pattern == "*":
            return list(self._keys)
        
        # Simple pattern matching
        matching_keys = []
        for key in self._keys:
            if pattern.replace("*", "") in key:
                matching_keys.append(key)
        return matching_keys
    
    async def flushdb(self) -> bool:
        """Mock flushdb operation."""
        self._data.clear()
        self._keys.clear()
        return True
    
    async def close(self):
        """Mock close operation."""
        pass
    
    async def hget(self, name: str, key: str) -> Optional[str]:
        """Mock hash get operation."""
        return self._data.get(f"{name}:{key}")
    
    async def hset(self, name: str, key: str, value: str) -> int:
        """Mock hash set operation."""
        hash_key = f"{name}:{key}"
        self._data[hash_key] = value
        self._keys.add(hash_key)
        return 1
    
    async def hgetall(self, name: str) -> Dict[str, str]:
        """Mock hash get all operation."""
        result = {}
        prefix = f"{name}:"
        for key, value in self._data.items():
            if key.startswith(prefix):
                result[key[len(prefix):]] = value
        return result
    
    async def expire(self, name: str, seconds: int) -> int:
        """Mock expire operation."""
        # In real Redis, this would set expiry on keys
        return 1
    
    def get_call_count(self) -> int:
        """Get number of operations performed."""
        return self._call_count


class MockDatabaseClient:
    """
    Mock database client for testing.
    """
    
    def __init__(self):
        self._connections = {}
        self._call_count = 0
    
    async def connect(self) -> bool:
        """Mock connection."""
        self._call_count += 1
        return True
    
    async def disconnect(self):
        """Mock disconnection."""
        self._call_count += 1
    
    async def execute(self, query: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Mock query execution."""
        self._call_count += 1
        
        # Mock different types of queries
        if "SELECT" in query.upper():
            return {
                "rows": [
                    {"id": 1, "name": "Test User", "email": "test@example.com"},
                    {"id": 2, "name": "Another User", "email": "another@example.com"}
                ],
                "rowcount": 2
            }
        elif "INSERT" in query.upper():
            return {"last_row_id": 123, "rowcount": 1}
        elif "UPDATE" in query.upper():
            return {"rowcount": 1}
        elif "DELETE" in query.upper():
            return {"rowcount": 1}
        else:
            return {"status": "success"}
    
    async def fetch_one(self, query: str, params: Optional[Dict] = None) -> Optional[Dict]:
        """Mock single row fetch."""
        await self.execute(query, params)
        return {"id": 1, "name": "Test User"}
    
    async def fetch_many(self, query: str, size: int, params: Optional[Dict] = None) -> List[Dict]:
        """Mock multiple row fetch."""
        await self.execute(query, params)
        return [
            {"id": i, "name": f"User {i}", "email": f"user{i}@example.com"}
            for i in range(1, size + 1)
        ]
    
    async def transaction(self):
        """Mock transaction context manager."""
        class TransactionContext:
            async def __aenter__(self):
                return self
            
            async def __aexit__(self, exc_type, exc_val, exc_tb):
                pass
        
        return TransactionContext()
    
    def get_call_count(self) -> int:
        """Get number of operations performed."""
        return self._call_count


class MockWebSocketManager:
    """
    Mock WebSocket manager for testing.
    """
    
    def __init__(self):
        self._connections = {}
        self._messages = []
        self._is_running = False
    
    async def connect(self, websocket_id: str, user_id: str) -> bool:
        """Mock WebSocket connection."""
        self._connections[websocket_id] = {
            "user_id": user_id,
            "connected_at": datetime.utcnow(),
            "status": "connected"
        }
        return True
    
    async def disconnect(self, websocket_id: str):
        """Mock WebSocket disconnection."""
        if websocket_id in self._connections:
            del self._connections[websocket_id]
    
    async def send_message(self, websocket_id: str, message: Dict[str, Any]) -> bool:
        """Mock message sending."""
        self._messages.append({
            "websocket_id": websocket_id,
            "message": message,
            "timestamp": datetime.utcnow()
        })
        return True
    
    async def broadcast(self, message: Dict[str, Any]) -> int:
        """Mock broadcast to all connections."""
        for websocket_id in self._connections:
            await self.send_message(websocket_id, message)
        return len(self._connections)
    
    async def initialize(self):
        """Mock WebSocket manager initialization."""
        self._is_running = True
    
    async def shutdown(self):
        """Mock WebSocket manager shutdown."""
        self._is_running = False
        self._connections.clear()
    
    def get_connection_count(self) -> int:
        """Get number of active connections."""
        return len(self._connections)
    
    def get_message_count(self) -> int:
        """Get number of messages sent."""
        return len(self._messages)


class MockChromadbClient:
    """
    Mock ChromaDB client for testing.
    """
    
    def __init__(self):
        self._collections = {}
        self._documents = {}
        self._call_count = 0
    
    async def create_collection(self, name: str) -> Dict[str, Any]:
        """Mock collection creation."""
        self._call_count += 1
        self._collections[name] = {
            "name": name,
            "count": 0,
            "created_at": datetime.utcnow()
        }
        return {"id": str(uuid4()), "name": name}
    
    async def add(self, collection_name: str, documents: List[str], 
                  ids: List[str], metadatas: Optional[List[Dict]] = None) -> bool:
        """Mock document addition."""
        self._call_count += 1
        
        if collection_name not in self._collections:
            await self.create_collection(collection_name)
        
        self._documents[collection_name] = self._documents.get(collection_name, [])
        for i, doc_id in enumerate(ids):
            self._documents[collection_name].append({
                "id": doc_id,
                "document": documents[i],
                "metadata": metadatas[i] if metadatas and i < len(metadatas) else {}
            })
        
        self._collections[collection_name]["count"] = len(self._documents[collection_name])
        return True
    
    async def query(self, collection_name: str, query_texts: List[str], 
                   n_results: int = 3) -> Dict[str, Any]:
        """Mock similarity search."""
        self._call_count += 1
        
        return {
            "ids": [["doc1", "doc2", "doc3"]],
            "documents": [["Result 1", "Result 2", "Result 3"]],
            "metadatas": [[{"source": "test"}, {"source": "test"}, {"source": "test"}]],
            "distances": [[0.1, 0.2, 0.3]]
        }
    
    async def delete_collection(self, name: str) -> bool:
        """Mock collection deletion."""
        self._call_count += 1
        if name in self._collections:
            del self._collections[name]
        if name in self._documents:
            del self._documents[name]
        return True
    
    def get_call_count(self) -> int:
        """Get number of operations performed."""
        return self._call_count


class MockExternalServices:
    """
    Container for all mock external services.
    """
    
    def __init__(self):
        self.openai = MockOpenAIService()
        self.redis = MockRedisClient()
        self.database = MockDatabaseClient()
        self.websocket = MockWebSocketManager()
        self.chromadb = MockChromadbClient()
        self.http = MockHTTPClient()
    
    async def reset_all(self):
        """Reset all mock services."""
        self.redis._data.clear()
        self.redis._keys.clear()
        self.redis._call_count = 0
        
        self.database._connections.clear()
        self.database._call_count = 0
        
        self.websocket._connections.clear()
        self.websocket._messages.clear()
        
        self._reset_http_client()
    
    def _reset_http_client(self):
        """Reset HTTP client mock."""
        self.http._responses.clear()
        self.http._call_count = 0
    
    def configure_openai_response(self, response_type: str, response_data: Dict[str, Any]):
        """Configure OpenAI mock responses."""
        self.openai.configure_response(response_type, response_data)
    
    def configure_redis_data(self, key: str, value: str):
        """Configure Redis mock data."""
        self.redis._data[key] = value
        self.redis._keys.add(key)
    
    def configure_database_response(self, query: str, response: Dict[str, Any]):
        """Configure database mock responses."""
        self.http._responses[query] = response
    
    def get_service_status(self) -> Dict[str, Any]:
        """Get status of all mock services."""
        return {
            "openai": {
                "status": "mocked",
                "call_count": self.openai.chat._call_count
            },
            "redis": {
                "status": "mocked",
                "data_size": len(self.redis._data),
                "call_count": self.redis.get_call_count()
            },
            "database": {
                "status": "mocked", 
                "connection_count": len(self.database._connections),
                "call_count": self.database.get_call_count()
            },
            "websocket": {
                "status": "mocked" if self.websocket._is_running else "stopped",
                "connection_count": self.websocket.get_connection_count(),
                "message_count": self.websocket.get_message_count()
            },
            "chromadb": {
                "status": "mocked",
                "collection_count": len(self.chromadb._collections),
                "call_count": self.chromadb.get_call_count()
            },
            "http": {
                "status": "mocked",
                "call_count": self.http._call_count
            }
        }


class MockHTTPClient:
    """
    Mock HTTP client for testing external API calls.
    """
    
    def __init__(self):
        self._responses = {}
        self._call_count = 0
        self._request_history = []
    
    def configure_response(self, url: str, response_data: Dict[str, Any], status_code: int = 200):
        """Configure mock HTTP response."""
        self._responses[url] = {
            "status_code": status_code,
            "json": lambda: response_data,
            "text": json.dumps(response_data)
        }
    
    async def get(self, url: str, **kwargs) -> Dict[str, Any]:
        """Mock HTTP GET request."""
        self._call_count += 1
        self._request_history.append({"method": "GET", "url": url, "params": kwargs})
        
        if url in self._responses:
            return self._responses[url]
        
        # Default response
        return {
            "status_code": 200,
            "json": lambda: {"message": "Mock GET response"},
            "text": '{"message": "Mock GET response"}'
        }
    
    async def post(self, url: str, **kwargs) -> Dict[str, Any]:
        """Mock HTTP POST request."""
        self._call_count += 1
        self._request_history.append({"method": "POST", "url": url, "params": kwargs})
        
        if url in self._responses:
            return self._responses[url]
        
        # Default response
        return {
            "status_code": 200,
            "json": lambda: {"message": "Mock POST response"},
            "text": '{"message": "Mock POST response"}'
        }
    
    def get_call_count(self) -> int:
        """Get number of HTTP requests made."""
        return self._call_count
    
    def get_request_history(self) -> List[Dict[str, Any]]:
        """Get history of HTTP requests."""
        return self._request_history.copy()