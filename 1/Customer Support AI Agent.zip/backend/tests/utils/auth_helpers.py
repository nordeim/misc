"""
Authentication test helpers for generating tokens, users, and testing auth flows.

This module provides utilities for creating test users, generating JWT tokens,
and testing authentication and authorization functionality.
"""

import json
import base64
import hashlib
import hmac
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from uuid import uuid4
import jwt
import bcrypt


class AuthHelpers:
    """
    Helper class for authentication testing.
    """
    
    def __init__(self, secret_key: str = "test_secret_key_for_auth_testing_only"):
        """
        Initialize auth helpers.
        
        Args:
            secret_key: Secret key for JWT token generation
        """
        self.secret_key = secret_key
        self.algorithm = "HS256"
    
    # ==============================================================================
    # TOKEN GENERATION
    # ==============================================================================
    
    def generate_jwt_token(self, user_id: str, 
                          token_type: str = "access",
                          expires_in: int = 3600,
                          additional_claims: Optional[Dict] = None) -> str:
        """
        Generate a JWT token for testing.
        
        Args:
            user_id: User ID to include in token
            token_type: Type of token (access, refresh)
            expires_in: Token expiry in seconds
            additional_claims: Additional claims to include
            
        Returns:
            Encoded JWT token
        """
        now = datetime.utcnow()
        expiry = now + timedelta(seconds=expires_in)
        
        payload = {
            "sub": user_id,
            "type": token_type,
            "exp": expiry,
            "iat": now,
            "iss": "test_auth_server"
        }
        
        if additional_claims:
            payload.update(additional_claims)
        
        # For testing, we'll encode this manually since we may not have access to JWT library
        header = {
            "alg": "HS256",
            "typ": "JWT"
        }
        
        # Encode header and payload
        header_b64 = self._base64_encode(json.dumps(header))
        payload_b64 = self._base64_encode(json.dumps(payload))
        
        # Create signature
        message = f"{header_b64}.{payload_b64}"
        signature = self._create_hmac_signature(message)
        
        return f"{message}.{signature}"
    
    def generate_access_token(self, user_id: str, **claims) -> str:
        """Generate access token."""
        return self.generate_jwt_token(user_id, token_type="access", **claims)
    
    def generate_refresh_token(self, user_id: str, **claims) -> str:
        """Generate refresh token."""
        return self.generate_jwt_token(user_id, token_type="refresh", expires_in=86400, **claims)
    
    def generate_verification_token(self, user_id: str) -> str:
        """Generate email verification token."""
        payload = {
            "sub": user_id,
            "type": "email_verification",
            "exp": datetime.utcnow() + timedelta(hours=24),
            "iat": datetime.utcnow()
        }
        return self._encode_payload(payload)
    
    def generate_password_reset_token(self, user_id: str) -> str:
        """Generate password reset token."""
        payload = {
            "sub": user_id,
            "type": "password_reset", 
            "exp": datetime.utcnow() + timedelta(hours=1),
            "iat": datetime.utcnow()
        }
        return self._encode_payload(payload)
    
    # ==============================================================================
    # TOKEN DECODING AND VALIDATION
    # ==============================================================================
    
    def decode_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Decode and validate a JWT token.
        
        Args:
            token: JWT token to decode
            
        Returns:
            Decoded payload or None if invalid
        """
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None
            
            header_b64, payload_b64, signature = parts
            
            # Verify signature
            message = f"{header_b64}.{payload_b64}"
            expected_signature = self._create_hmac_signature(message)
            
            if not hmac.compare_digest(signature, expected_signature):
                return None
            
            # Decode payload
            payload_json = self._base64_decode(payload_b64)
            payload = json.loads(payload_json)
            
            # Check expiry
            if "exp" in payload:
                exp_timestamp = payload["exp"]
                if isinstance(exp_timestamp, (int, float)):
                    if datetime.utcnow().timestamp() > exp_timestamp:
                        return None
            
            return payload
            
        except (json.JSONDecodeError, Exception):
            return None
    
    def is_token_valid(self, token: str) -> bool:
        """Check if token is valid."""
        payload = self.decode_jwt_token(token)
        return payload is not None
    
    def get_token_payload(self, token: str) -> Optional[Dict[str, Any]]:
        """Get token payload without validation."""
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None
            
            payload_b64 = parts[1]
            payload_json = self._base64_decode(payload_b64)
            return json.loads(payload_json)
        except (json.JSONDecodeError, Exception):
            return None
    
    # ==============================================================================
    # USER CREATION AND AUTHENTICATION
    # ==============================================================================
    
    def create_test_user(self, 
                        username: Optional[str] = None,
                        email: Optional[str] = None,
                        password: Optional[str] = None,
                        is_active: bool = True,
                        is_verified: bool = True,
                        is_admin: bool = False,
                        user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a test user.
        
        Args:
            username: Username (auto-generated if None)
            email: Email (auto-generated if None)
            password: Password (auto-generated if None)
            is_active: Whether user is active
            is_verified: Whether user is email verified
            is_admin: Whether user has admin privileges
            user_id: User ID (auto-generated if None)
            
        Returns:
            User dictionary
        """
        user_id = user_id or str(uuid4())
        
        return {
            "id": user_id,
            "username": username or f"testuser_{user_id[:8]}",
            "email": email or f"test_{user_id[:8]}@example.com",
            "password": password or "TestPass123!",
            "password_hash": self.hash_password(password or "TestPass123!"),
            "is_active": is_active,
            "is_verified": is_verified,
            "is_admin": is_admin,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "last_login": datetime.utcnow() if is_active else None,
            "profile": {
                "first_name": "Test",
                "last_name": "User",
                "avatar_url": f"https://example.com/avatars/{user_id}.png"
            }
        }
    
    def create_admin_user(self, **kwargs) -> Dict[str, Any]:
        """Create a test admin user."""
        kwargs["is_admin"] = True
        return self.create_test_user(**kwargs)
    
    def create_inactive_user(self, **kwargs) -> Dict[str, Any]:
        """Create a test inactive user."""
        kwargs["is_active"] = False
        return self.create_test_user(**kwargs)
    
    def create_unverified_user(self, **kwargs) -> Dict[str, Any]:
        """Create a test unverified user."""
        kwargs["is_verified"] = False
        return self.create_test_user(**kwargs)
    
    # ==============================================================================
    # PASSWORD HANDLING
    # ==============================================================================
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password for testing.
        
        Args:
            password: Plain text password
            
        Returns:
            Hashed password
        """
        # Simple hash for testing (use bcrypt in real implementation)
        salt = "test_salt"
        return hashlib.sha256((password + salt).encode()).hexdigest()
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        """
        Verify a password against its hash.
        
        Args:
            password: Plain text password
            password_hash: Hashed password
            
        Returns:
            True if password matches hash
        """
        computed_hash = self.hash_password(password)
        return hmac.compare_digest(computed_hash, password_hash)
    
    # ==============================================================================
    # PERMISSION AND ROLE TESTING
    # ==============================================================================
    
    def create_permission(self, name: str, description: str = "") -> Dict[str, Any]:
        """Create a test permission."""
        return {
            "id": str(uuid4()),
            "name": name,
            "description": description,
            "created_at": datetime.utcnow()
        }
    
    def create_role(self, name: str, permissions: List[str] = None) -> Dict[str, Any]:
        """Create a test role with permissions."""
        return {
            "id": str(uuid4()),
            "name": name,
            "permissions": permissions or [],
            "created_at": datetime.utcnow()
        }
    
    def assign_role_to_user(self, user: Dict[str, Any], role_name: str) -> Dict[str, Any]:
        """Assign a role to a user."""
        user_copy = user.copy()
        user_copy["roles"] = user_copy.get("roles", [])
        user_copy["roles"].append(role_name)
        return user_copy
    
    def create_user_with_roles(self, username: str, roles: List[str]) -> Dict[str, Any]:
        """Create a user with specific roles."""
        user = self.create_test_user(username=username)
        for role in roles:
            user = self.assign_role_to_user(user, role)
        return user
    
    # ==============================================================================
    # AUTH HEADERS AND REQUESTS
    # ==============================================================================
    
    def create_auth_headers(self, token: str) -> Dict[str, str]:
        """Create authentication headers for HTTP requests."""
        return {"Authorization": f"Bearer {token}"}
    
    def create_api_key_headers(self, api_key: str) -> Dict[str, str]:
        """Create API key headers for HTTP requests."""
        return {"X-API-Key": api_key}
    
    def create_authenticated_request(self, method: str, url: str, 
                                   user: Dict[str, Any],
                                   additional_headers: Optional[Dict] = None) -> Dict[str, Any]:
        """Create an authenticated HTTP request."""
        token = self.generate_access_token(user["id"])
        headers = self.create_auth_headers(token)
        
        if additional_headers:
            headers.update(additional_headers)
        
        return {
            "method": method,
            "url": url,
            "headers": headers,
            "user_id": user["id"],
            "username": user["username"]
        }
    
    # ==============================================================================
    # SECURITY TEST DATA
    # ==============================================================================
    
    def generate_malicious_tokens(self) -> List[Dict[str, Any]]:
        """Generate various malicious tokens for security testing."""
        return [
            {
                "name": "expired_token",
                "description": "Token with expired timestamp",
                "token": self.generate_jwt_token(str(uuid4()), expires_in=-3600)
            },
            {
                "name": "invalid_signature",
                "description": "Token with invalid signature",
                "token": f"{self.generate_jwt_token(str(uuid4()))}.invalid_signature"
            },
            {
                "name": "malformed_token",
                "description": "Malformed token",
                "token": "invalid.token.format"
            },
            {
                "name": "empty_payload",
                "description": "Token with empty payload",
                "token": self._create_token_with_payload({})
            },
            {
                "name": "type_confusion",
                "description": "Token with wrong type",
                "token": self.generate_jwt_token(str(uuid4()), token_type="invalid_type")
            }
        ]
    
    def generate_weak_passwords(self) -> List[str]:
        """Generate weak passwords for security testing."""
        return [
            "123456",
            "password", 
            "admin",
            "test",
            "qwerty",
            "abc123",
            "letmein",
            "welcome",
            "123456789",
            "password123"
        ]
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    def _base64_encode(self, data: str) -> str:
        """Base64 encode data."""
        return base64.b64encode(data.encode()).decode()
    
    def _base64_decode(self, data: str) -> str:
        """Base64 decode data."""
        return base64.b64decode(data.encode()).decode()
    
    def _create_hmac_signature(self, message: str) -> str:
        """Create HMAC signature for JWT."""
        signature = hmac.new(
            self.secret_key.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def _encode_payload(self, payload: Dict[str, Any]) -> str:
        """Encode a payload as a token."""
        header = {"alg": "HS256", "typ": "JWT"}
        
        header_b64 = self._base64_encode(json.dumps(header))
        payload_b64 = self._base64_encode(json.dumps(payload))
        
        message = f"{header_b64}.{payload_b64}"
        signature = self._create_hmac_signature(message)
        
        return f"{message}.{signature}"
    
    def _create_token_with_payload(self, payload: Dict[str, Any]) -> str:
        """Create a token with specific payload."""
        now = datetime.utcnow()
        default_payload = {
            "exp": now + timedelta(hours=1),
            "iat": now,
            "iss": "test_auth_server"
        }
        default_payload.update(payload)
        
        return self._encode_payload(default_payload)
    
    # ==============================================================================
    # TEST SCENARIO HELPERS
    # ==============================================================================
    
    def create_authentication_scenarios(self) -> List[Dict[str, Any]]:
        """Create various authentication test scenarios."""
        return [
            {
                "name": "valid_login",
                "description": "Successful login with valid credentials",
                "user": self.create_test_user(username="validuser"),
                "credentials": {"username": "validuser", "password": "TestPass123!"},
                "expected_result": "success"
            },
            {
                "name": "invalid_password",
                "description": "Login with wrong password",
                "user": self.create_test_user(username="badpassuser"),
                "credentials": {"username": "badpassuser", "password": "WrongPassword!"},
                "expected_result": "failure"
            },
            {
                "name": "nonexistent_user",
                "description": "Login with non-existent user",
                "credentials": {"username": "nonexistent", "password": "AnyPassword123!"},
                "expected_result": "failure"
            },
            {
                "name": "inactive_user",
                "description": "Login with inactive user",
                "user": self.create_inactive_user(username="inactiveuser"),
                "credentials": {"username": "inactiveuser", "password": "TestPass123!"},
                "expected_result": "failure"
            },
            {
                "name": "unverified_user",
                "description": "Login with unverified user",
                "user": self.create_unverified_user(username="unverifieduser"),
                "credentials": {"username": "unverifieduser", "password": "TestPass123!"},
                "expected_result": "failure"
            },
            {
                "name": "expired_token",
                "description": "Request with expired token",
                "user": self.create_test_user(username="expireduser"),
                "token": self.generate_jwt_token(str(uuid4()), expires_in=-3600),
                "expected_result": "failure"
            },
            {
                "name": "admin_access",
                "description": "Admin accessing admin-only endpoint",
                "user": self.create_admin_user(username="adminuser"),
                "token": self.generate_access_token(str(uuid4())),
                "expected_result": "success"
            },
            {
                "name": "user_admin_endpoint",
                "description": "Regular user accessing admin endpoint",
                "user": self.create_test_user(username="regularuser"),
                "token": self.generate_access_token(str(uuid4())),
                "expected_result": "failure"
            }
        ]
    
    def create_authorization_matrix(self) -> Dict[str, Dict[str, List[str]]]:
        """Create authorization matrix for testing role-based access."""
        return {
            "user": {
                "can_access": ["/api/v1/profile", "/api/v1/sessions", "/api/v1/messages"],
                "cannot_access": ["/api/v1/admin/users", "/api/v1/admin/settings", "/api/v1/analytics"]
            },
            "moderator": {
                "can_access": ["/api/v1/profile", "/api/v1/sessions", "/api/v1/messages", "/api/v1/moderate"],
                "cannot_access": ["/api/v1/admin/settings", "/api/v1/analytics"]
            },
            "admin": {
                "can_access": ["/api/v1/profile", "/api/v1/sessions", "/api/v1/messages", "/api/v1/admin/*", "/api/v1/analytics"],
                "cannot_access": []
            }
        }