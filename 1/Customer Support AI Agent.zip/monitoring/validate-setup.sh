#!/bin/bash

# Monitoring Setup Validation Script
# This script checks if all monitoring components are running correctly

set -e

echo "=== Customer Support Agent Monitoring Validation ==="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to check service health
check_service() {
    local service_name=$1
    local url=$2
    local expected_status=${3:-200}
    
    echo -n "Checking $service_name... "
    
    if curl -s -o /dev/null -w "%{http_code}" "$url" | grep -q "$expected_status"; then
        echo -e "${GREEN}✓ OK${NC}"
        return 0
    else
        echo -e "${RED}✗ FAILED${NC}"
        return 1
    fi
}

# Function to check if container is running
check_container() {
    local container_name=$1
    echo -n "Checking container $container_name... "
    
    if docker ps --filter "name=$container_name" --filter "status=running" | grep -q "$container_name"; then
        echo -e "${GREEN}✓ RUNNING${NC}"
        return 0
    else
        echo -e "${RED}✗ NOT RUNNING${NC}"
        return 1
    fi
}

echo "=== Container Status ==="
check_container "prometheus"
check_container "grafana"
check_container "alertmanager"
check_container "node-exporter"
check_container "redis-exporter"
check_container "postgres-exporter"
echo ""

echo "=== Service Health Checks ==="
check_service "Prometheus" "http://localhost:9090/-/healthy" "200"
check_service "Grafana" "http://localhost:3000/api/health" "200"
check_service "AlertManager" "http://localhost:9093/-/healthy" "200"
check_service "Node Exporter" "http://localhost:9100/metrics" "200"
echo ""

echo "=== Backend Metrics Check ==="
echo -n "Checking backend metrics endpoint... "
if curl -s "http://localhost:8000/metrics" > /dev/null; then
    echo -e "${GREEN}✓ OK${NC}"
    # Count metrics
    metrics_count=$(curl -s "http://localhost:8000/metrics" | wc -l)
    echo "  Found $metrics_count metrics"
else
    echo -e "${RED}✗ FAILED${NC}"
fi

echo -n "Checking health endpoints... "
health_status=$(curl -s "http://localhost:8000/health" | grep -o '"status":"[^"]*"' || echo "")
if [[ $health_status == '"status":"healthy"' ]]; then
    echo -e "${GREEN}✓ OK${NC}"
else
    echo -e "${YELLOW}⚠ Backend not accessible${NC}"
fi
echo ""

echo "=== Prometheus Targets Status ==="
echo "Checking Prometheus targets (this may take a moment)..."
if curl -s "http://localhost:9090/api/v1/targets" | grep -q "success"; then
    echo -e "${GREEN}✓ Prometheus targets accessible${NC}"
    # Show target count
    target_count=$(curl -s "http://localhost:9090/api/v1/targets" | grep -o '"labels"' | wc -l)
    echo "  Found $target_count active targets"
else
    echo -e "${RED}✗ Prometheus targets not accessible${NC}"
fi
echo ""

echo "=== Alert Rules Status ==="
if curl -s "http://localhost:9090/api/v1/rules" | grep -q "customer-support-agent"; then
    echo -e "${GREEN}✓ Alert rules loaded${NC}"
else
    echo -e "${YELLOW}⚠ Alert rules may not be loaded${NC}"
fi
echo ""

echo "=== Metrics Validation ==="
# Check for key metrics
metrics_to_check=(
    "http_requests_total"
    "active_conversations_total"
    "conversations_escalated_total"
    "cpu_usage_percent"
    "memory_usage_percent"
)

for metric in "${metrics_to_check[@]}"; do
    echo -n "Checking for metric '$metric'... "
    if curl -s "http://localhost:9090/api/v1/query?query=$metric" | grep -q "$metric"; then
        echo -e "${GREEN}✓ Found${NC}"
    else
        echo -e "${YELLOW}⚠ Not found${NC}"
    fi
done
echo ""

echo "=== Grafana Dashboards ==="
echo "Grafana is accessible at: http://localhost:3000"
echo "Default credentials: admin/admin"
echo ""
echo "Pre-configured dashboards:"
echo "  - System Metrics Dashboard"
echo "  - Application Metrics Dashboard" 
echo "  - Business Metrics Dashboard"
echo ""

echo "=== AlertManager Configuration ==="
echo "AlertManager is accessible at: http://localhost:9093"
echo ""
echo "Configured alert routes:"
echo "  - Critical alerts → oncall@example.com"
echo "  - Infrastructure alerts → infrastructure@example.com"
echo "  - Backend alerts → backend@example.com"
echo "  - Customer Success alerts → customer-success@example.com"
echo "  - AI alerts → ai@example.com"
echo ""

echo "=== Quick Commands ==="
echo "# View Prometheus targets"
echo "curl http://localhost:9090/api/v1/targets"
echo ""
echo "# Query a specific metric"
echo "curl 'http://localhost:9090/api/v1/query?query=http_requests_total'"
echo ""
echo "# Check alert status"
echo "curl http://localhost:9090/api/v1/alerts"
echo ""
echo "# Test alerting rule evaluation"
echo "curl 'http://localhost:9090/api/v1/rules' | jq '.data.groups[] | .name'"
echo ""

echo "=== Summary ==="
echo -e "${GREEN}✓${NC} Monitoring infrastructure validation complete"
echo ""
echo "Next steps:"
echo "1. Access Grafana at http://localhost:3000 and verify dashboards"
echo "2. Update AlertManager config with your actual notification channels"
echo "3. Trigger some test traffic to see metrics in action"
echo "4. Configure your production alerting channels (email, Slack, PagerDuty)"
echo ""
echo "For detailed setup instructions, see monitoring/README.md"
echo ""