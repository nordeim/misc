#!/usr/bin/env python3
"""
Redis Cache Service Usage Examples

This script demonstrates how to use the Redis Cache Service
in various scenarios and use cases.
"""

import asyncio
import json
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from app.services.cache_service import get_cache_service
from app.utils.cache_decorators import cache_result, cache_method
from app.utils.cache_testing import CacheValidator


async def example_basic_usage():
    """Demonstrate basic cache usage."""
    print("\n" + "="*50)
    print("1. BASIC CACHE USAGE")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Basic set and get
        print("Setting cache value...")
        await cache.set("user:123", {"name": "John Doe", "email": "john@example.com"}, ttl=300)
        
        print("Getting cache value...")
        user_data = await cache.get("user:123")
        print(f"Retrieved: {json.dumps(user_data, indent=2)}")
        
        # Check if key exists
        exists = await cache.exists("user:123")
        print(f"Key exists: {exists}")
        
        # Get TTL
        ttl = await cache.get_ttl("user:123")
        print(f"TTL remaining: {ttl} seconds")
        
    finally:
        await cache.close()


async def example_batch_operations():
    """Demonstrate batch cache operations."""
    print("\n" + "="*50)
    print("2. BATCH OPERATIONS")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Batch set
        print("Setting batch data...")
        users = {
            "user:1": {"name": "Alice Johnson", "role": "admin", "active": True},
            "user:2": {"name": "Bob Smith", "role": "user", "active": True},
            "user:3": {"name": "Charlie Brown", "role": "moderator", "active": False},
            "user:4": {"name": "Diana Prince", "role": "user", "active": True},
            "user:5": {"name": "Eve Wilson", "role": "admin", "active": True}
        }
        
        success = await cache.batch_set(users, ttl=600)
        print(f"Batch set success: {success}")
        
        # Batch get
        print("Getting batch data...")
        user_keys = list(users.keys())
        retrieved_users = await cache.batch_get(user_keys)
        print(f"Retrieved {len(retrieved_users)} users:")
        
        for user_id, user_data in retrieved_users.items():
            print(f"  {user_id}: {user_data['name']} ({user_data['role']})")
        
    finally:
        await cache.close()


async def example_tag_system():
    """Demonstrate tag-based cache invalidation."""
    print("\n" + "="*50)
    print("3. TAG SYSTEM")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Create session data with tags
        print("Creating session cache entries...")
        sessions = [
            ("session:abc123", {"user": "alice", "ip": "192.168.1.1"}, ["session", "active"]),
            ("session:def456", {"user": "bob", "ip": "192.168.1.2"}, ["session", "active"]),
            ("session:ghi789", {"user": "charlie", "ip": "192.168.1.3"}, ["session", "inactive"]),
        ]
        
        for session_id, session_data, tags in sessions:
            await cache.set(session_id, session_data, tags=tags)
        
        print("Session entries created with tags")
        
        # Get all active sessions (would require additional logic in real app)
        active_keys = ["session:abc123", "session:def456"]
        for key in active_keys:
            session = await cache.get(key)
            print(f"  {key}: {session}")
        
        # Invalidate all active sessions
        print("\nInvalidating active sessions...")
        invalidated = await cache.invalidate_by_tag("active")
        print(f"Invalidated {invalidated} entries")
        
        # Verify invalidation
        print("Checking if sessions still exist...")
        for session_id, _, _ in sessions:
            session = await cache.get(session_id)
            if session:
                print(f"  {session_id}: Still exists")
            else:
                print(f"  {session_id}: Invalidated")
        
    finally:
        await cache.close()


async def example_cache_decorators():
    """Demonstrate cache decorators."""
    print("\n" + "="*50)
    print("4. CACHE DECORATORS")
    print("="*50)
    
    # Create cache decorator
    get_user_profile = cache_result(
        ttl=300,
        key_prefix="profile",
        tags=['user_profile', 'expensive_operation']
    )
    
    # Simulate expensive function
    call_count = 0
    
    @get_user_profile
    async def expensive_user_calculation(user_id: int):
        nonlocal call_count
        call_count += 1
        print(f"  [Expensive calculation called for user {user_id}]")
        
        # Simulate expensive database query
        await asyncio.sleep(0.1)
        
        return {
            "user_id": user_id,
            "profile_score": user_id * 42 + 100,
            "calculations_performed": call_count
        }
    
    # Use the decorated function
    print("First call to expensive function:")
    result1 = await expensive_user_calculation(123)
    print(f"Result: {result1}")
    
    print("\nSecond call (should use cache):")
    result2 = await expensive_user_calculation(123)
    print(f"Result: {result2}")
    
    print(f"\nFunction called {call_count} time(s) - should be 1 if cache working")


async def example_cache_warming():
    """Demonstrate cache warming."""
    print("\n" + "="*50)
    print("5. CACHE WARMING")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Prepare data for cache warming
        print("Preparing cache warming data...")
        warming_data = [
            ("config:app_name", "My Application", 3600, ["config"]),
            ("config:version", "1.0.0", 3600, ["config"]),
            ("config:api_endpoint", "https://api.example.com", 1800, ["config"]),
            ("feature_flags:new_ui", True, 600, ["feature_flags"]),
            ("feature_flags:dark_mode", False, 600, ["feature_flags"]),
        ]
        
        # Warm the cache
        print("Warming cache...")
        await cache.warm_cache(warming_data, batch_size=5)
        
        # Verify warmed data
        print("Verifying warmed cache entries:")
        for key, expected_value, _, _ in warming_data:
            value = await cache.get(key)
            print(f"  {key}: {value} (match: {value == expected_value})")
        
    finally:
        await cache.close()


async def example_performance_monitoring():
    """Demonstrate performance monitoring."""
    print("\n" + "="*50)
    print("6. PERFORMANCE MONITORING")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Generate cache activity
        print("Generating cache activity...")
        
        # Set some values
        for i in range(10):
            await cache.set(f"monitor:test:{i}", f"test_value_{i}", ttl=300)
        
        # Get some values (mix of hits and misses)
        for i in range(15):
            await cache.get(f"monitor:test:{i}")  # These should hit
            
        for i in range(10):
            await cache.get(f"monitor:miss:{i}")  # These should miss
        
        # Get statistics
        stats = await cache.get_stats()
        print(f"\nCache Statistics:")
        print(f"  Hits: {stats.hits}")
        print(f"  Misses: {stats.misses}")
        print(f"  Hit Rate: {stats.hit_rate:.2%}")
        print(f"  Cache Size: {stats.size}")
        
        # Health check
        health = await cache.health_check()
        print(f"\nHealth Status:")
        print(f"  Overall: {health['status']}")
        for component, status in health['components'].items():
            if isinstance(status, dict):
                print(f"  {component}: {status.get('status', 'unknown')}")
            else:
                print(f"  {component}: {status}")
        
    finally:
        await cache.close()


async def example_error_handling():
    """Demonstrate error handling and graceful degradation."""
    print("\n" + "="*50)
    print("7. ERROR HANDLING")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Test with valid data
        print("Testing with valid data:")
        await cache.set("valid:test", "valid_value", ttl=60)
        result = await cache.get("valid:test")
        print(f"  Success: {result}")
        
        # Test with complex data types
        print("\nTesting with complex data types:")
        complex_data = {
            "string": "test string",
            "number": 42,
            "float": 3.14159,
            "boolean": True,
            "list": [1, 2, 3, "four"],
            "nested": {
                "key": "value",
                "array": [1, 2, 3],
                "boolean": False
            },
            "null_value": None
        }
        
        await cache.set("complex:test", complex_data, ttl=60)
        retrieved = await cache.get("complex:test")
        print(f"  Retrieved: {type(retrieved)} with {len(retrieved)} keys")
        
        # Test TTL expiration (short wait)
        print("\nTesting TTL expiration:")
        await cache.set("ttl:test", "will_expire", ttl=1)
        print("  Value set, waiting for expiration...")
        await asyncio.sleep(2)
        expired_value = await cache.get("ttl:test")
        print(f"  After expiration: {expired_value} (should be None)")
        
    finally:
        await cache.close()


async def example_pattern_operations():
    """Demonstrate pattern-based operations."""
    print("\n" + "="*50)
    print("8. PATTERN OPERATIONS")
    print("="*50)
    
    cache = await get_cache_service()
    
    try:
        # Create data with patterns
        print("Creating data with patterns...")
        
        # User data
        for user_id in range(1, 6):
            await cache.set(f"user:{user_id:03d}", {
                "name": f"User {user_id}",
                "email": f"user{user_id}@example.com"
            }, tags=["user"])
        
        # Product data
        for product_id in range(1, 4):
            await cache.set(f"product:{product_id:03d}", {
                "name": f"Product {product_id}",
                "price": product_id * 10.99
            }, tags=["product"])
        
        # Get keys by pattern
        user_keys = await cache.get_keys_by_pattern("user:*")
        product_keys = await cache.get_keys_by_pattern("product:*")
        
        print(f"User keys found: {len(user_keys)}")
        print(f"Product keys found: {len(product_keys)}")
        
        # Clear by pattern
        print("\nClearing user data by pattern...")
        cleared_count = await cache.clear_by_pattern("user:*")
        print(f"Cleared {cleared_count} user entries")
        
        # Verify
        remaining_users = await cache.get_keys_by_pattern("user:*")
        remaining_products = await cache.get_keys_by_pattern("product:*")
        print(f"Remaining user keys: {len(remaining_users)}")
        print(f"Remaining product keys: {len(remaining_products)}")
        
    finally:
        await cache.close()


async def main():
    """Run all examples."""
    print("Redis Cache Service - Usage Examples")
    print("=" * 60)
    
    examples = [
        example_basic_usage,
        example_batch_operations,
        example_tag_system,
        example_cache_decorators,
        example_cache_warming,
        example_performance_monitoring,
        example_error_handling,
        example_pattern_operations
    ]
    
    for example_func in examples:
        try:
            await example_func()
            print(f"\n✓ {example_func.__name__} completed successfully")
        except Exception as e:
            print(f"\n✗ {example_func.__name__} failed: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
