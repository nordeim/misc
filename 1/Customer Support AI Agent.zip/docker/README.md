# Docker Compose Configuration Guide
## Customer Support AI Agent

This guide provides comprehensive instructions for setting up and running the Customer Support AI Agent using Docker Compose.

## 🏗️ Architecture Overview

The application consists of the following services:

- **Frontend**: React + TypeScript SPA with WebSocket support
- **Backend**: FastAPI Python application with AI agent orchestration
- **PostgreSQL**: Primary database for application data
- **Redis**: Caching and session management
- **ChromaDB**: Vector database for RAG functionality
- **Nginx**: Reverse proxy and load balancer
- **Monitoring**: Prometheus and Grafana (optional)

## 🚀 Quick Start

### Prerequisites

1. **Docker** (>= 20.10)
2. **Docker Compose** (>= 2.0)
3. **Git**

### Development Setup

1. **Clone and navigate to project:**
   ```bash
   git clone <your-repo>
   cd customer-support-ai-agent
   ```

2. **Setup environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start services:**
   ```bash
   docker-compose up -d
   ```

4. **Access application:**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Production Setup

1. **Setup environment:**
   ```bash
   cp .env.example .env.prod
   # Edit .env.prod with production values
   ```

2. **Start services:**
   ```bash
   docker-compose -f docker-compose.prod.yml --env-file .env.prod up -d
   ```

3. **With monitoring:**
   ```bash
   docker-compose -f docker-compose.prod.yml --env-file .env.prod --profile monitoring up -d
   ```

## 📋 Configuration

### Environment Variables

Key environment variables to configure:

| Variable | Description | Development Default | Production Required |
|----------|-------------|-------------------|-------------------|
| `DB_PASSWORD` | PostgreSQL password | `postgres123` | ✅ |
| `REDIS_PASSWORD` | Redis password | `redis123` | ✅ |
| `SECRET_KEY` | Application secret key | `your-secret-key-here` | ✅ |
| `FRONTEND_URL` | Frontend URL for CORS | `http://localhost:3000` | ✅ |
| `BACKEND_REPLICAS` | Backend container replicas | - | 2+ |
| `FRONTEND_REPLICAS` | Frontend container replicas | - | 2+ |

### Database Configuration

#### Development (SQLite)
```bash
# Uses SQLite by default for development
DATABASE_URL=sqlite:///./customer_support.db
```

#### Production (PostgreSQL)
```bash
# Configure PostgreSQL in .env
DATABASE_URL=postgresql://username:password@postgres:5432/customer_support
DB_USER=your_db_user
DB_PASSWORD=your_secure_password
```

### Security Considerations

#### Development
- Basic passwords for local development
- No SSL/TLS encryption
- Full CORS access

#### Production
- Strong, unique passwords for all services
- SSL/TLS certificates
- Restricted CORS origins
- Rate limiting
- Security headers enabled

## 🔧 Service Details

### Backend Service

**Technology Stack:**
- Python 3.11
- FastAPI
- SQLAlchemy
- ChromaDB
- Redis
- Gunicorn (production)

**Ports:**
- 8000 (HTTP)

**Health Check:**
- Endpoint: `/health`
- Interval: 30s
- Timeout: 10s
- Retries: 3

**Environment Variables:**
```bash
ENVIRONMENT=development|production
DATABASE_URL=postgresql://user:pass@postgres:5432/db
REDIS_URL=redis://:password@redis:6379/0
CHROMA_DB_URL=http://chromadb:8000
```

### Frontend Service

**Technology Stack:**
- Node.js 18
- React 18
- TypeScript
- Vite
- Nginx (production)

**Ports:**
- 3000 (Development)
- 80 (Production)

**Environment Variables:**
```bash
NODE_ENV=development|production
VITE_API_BASE_URL=http://localhost:8000
VITE_WS_URL=ws://localhost:8000
```

### Database Services

#### PostgreSQL
**Image:** `postgres:15-alpine`
**Ports:** 5432
**Health Check:** `pg_isready`
**Volumes:**
- `postgres_data`: Database files

#### Redis
**Image:** `redis:7-alpine`
**Ports:** 6379
**Health Check:** `redis-cli ping`
**Configuration:**
- Password authentication
- AOF persistence enabled
- LRU eviction policy

#### ChromaDB
**Image:** `chromadb/chroma:latest`
**Ports:** 8000
**Health Check:** HTTP heartbeat
**Purpose:** Vector similarity search for RAG

## 📊 Monitoring (Production)

### Prometheus
**Port:** 9090
**Configuration:** `/docker/prometheus.yml`
**Metrics:**
- Backend application metrics
- System metrics
- Service-specific metrics

### Grafana
**Port:** 3001
**Default Credentials:**
- Username: `admin`
- Password: Set via `GRAFANA_PASSWORD` env var

**Dashboards:**
- Application overview
- System resources
- Database performance

## 🛠️ Management Commands

### Development

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Stop services
docker-compose down

# Rebuild specific service
docker-compose up -d --build backend

# Scale services (development)
docker-compose up -d --scale backend=2
```

### Production

```bash
# Start with monitoring
docker-compose -f docker-compose.prod.yml --profile monitoring up -d

# Scale services
docker-compose -f docker-compose.prod.yml up -d --scale backend=3

# View resource usage
docker stats

# Backup database
docker-compose -f docker-compose.prod.yml exec postgres pg_dump -U postgres customer_support > backup.sql

# Update services
docker-compose -f docker-compose.prod.yml pull
docker-compose -f docker-compose.prod.yml up -d
```

### Monitoring

```bash
# View Prometheus targets
curl http://localhost:9090/api/v1/targets

# Access Grafana
open http://localhost:3001

# View application metrics
curl http://localhost:8000/metrics
```

## 🔍 Troubleshooting

### Common Issues

1. **Port conflicts:**
   ```bash
   # Check port usage
   netstat -tulpn | grep :8000
   
   # Change ports in docker-compose.yml if needed
   ports:
     - "8001:8000"  # Backend
     - "3001:3000"  # Frontend
   ```

2. **Database connection issues:**
   ```bash
   # Check database health
   docker-compose exec postgres pg_isready
   
   # View database logs
   docker-compose logs postgres
   ```

3. **Redis connection issues:**
   ```bash
   # Check Redis health
   docker-compose exec redis redis-cli ping
   
   # Clear Redis cache
   docker-compose exec redis redis-cli FLUSHALL
   ```

4. **Frontend build issues:**
   ```bash
   # Rebuild frontend
   docker-compose up -d --build frontend
   
   # Clear node_modules
   docker-compose exec frontend rm -rf node_modules
   docker-compose up -d --build frontend
   ```

5. **Backend import errors:**
   ```bash
   # Check Python path
   docker-compose exec backend python -c "import sys; print(sys.path)"
   
   # Install dependencies
   docker-compose exec backend pip install -r requirements.txt
   ```

### Health Checks

All services include health checks. Monitor status:

```bash
# Check service health
docker-compose ps

# View health check logs
docker inspect customer_support_backend | grep -A 10 Health
```

### Log Analysis

```bash
# Backend logs
docker-compose logs -f --tail=100 backend

# All service logs
docker-compose logs -f

# Search logs
docker-compose logs backend | grep ERROR

# Export logs
docker-compose logs backend > backend.log
```

## 🔒 Security

### Production Security Checklist

- [ ] Change all default passwords
- [ ] Use strong SECRET_KEY (32+ characters)
- [ ] Configure SSL/TLS certificates
- [ ] Set up proper CORS origins
- [ ] Enable rate limiting
- [ ] Configure firewall rules
- [ ] Set up log monitoring
- [ ] Regular security updates
- [ ] Backup encryption
- [ ] Access control

### SSL/TLS Setup

1. **Obtain certificates:**
   ```bash
   # Using Let's Encrypt
   certbot certonly --standalone -d your-domain.com
   ```

2. **Configure nginx:**
   ```bash
   # Update nginx.prod.conf with SSL configuration
   server {
       listen 443 ssl;
       ssl_certificate /etc/nginx/ssl/cert.pem;
       ssl_certificate_key /etc/nginx/ssl/key.pem;
   }
   ```

## 📈 Scaling

### Horizontal Scaling

```bash
# Scale backend instances
docker-compose -f docker-compose.prod.yml up -d --scale backend=4

# Scale frontend instances  
docker-compose -f docker-compose.prod.yml up -d --scale frontend=3

# Verify scaling
docker-compose -f docker-compose.prod.yml ps
```

### Resource Limits

All services configured with resource limits:

- **Backend:** 2 CPU, 4GB RAM per instance
- **Frontend:** 1 CPU, 1GB RAM per instance
- **Database:** 2 CPU, 4GB RAM
- **Cache:** 1 CPU, 1GB RAM

### Load Balancing

Nginx automatically handles load balancing between scaled instances using least_conn algorithm.

## 🚢 Deployment

### Production Deployment

1. **Prepare server:**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Docker
   curl -fsSL https://get.docker.com -o get-docker.sh
   sh get-docker.sh
   
   # Install Docker Compose
   sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
   sudo chmod +x /usr/local/bin/docker-compose
   ```

2. **Deploy application:**
   ```bash
   # Clone repository
   git clone <your-repo>
   cd customer-support-ai-agent
   
   # Configure environment
   cp .env.example .env.prod
   # Edit .env.prod with production values
   
   # Start services
   docker-compose -f docker-compose.prod.yml --env-file .env.prod up -d
   ```

3. **Setup SSL:**
   ```bash
   # Install certbot
   sudo apt install certbot
   
   # Obtain certificates
   sudo certbot certonly --standalone -d your-domain.com
   
   # Copy certificates
   sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ./docker/ssl/cert.pem
   sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem ./docker/ssl/key.pem
   ```

4. **Setup monitoring:**
   ```bash
   # Start with monitoring
   docker-compose -f docker-compose.prod.yml --env-file .env.prod --profile monitoring up -d
   
   # Configure Grafana dashboards
   # Access at http://your-server:3001
   ```

## 🆘 Support

For issues and questions:

1. Check logs: `docker-compose logs -f`
2. Review health checks: `docker-compose ps`
3. Consult troubleshooting section
4. Review application logs at `/app/logs`