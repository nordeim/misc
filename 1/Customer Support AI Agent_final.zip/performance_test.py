#!/usr/bin/env python3
"""
Performance Test Suite for Customer Support AI Agent

This comprehensive performance test suite validates system performance under various
load conditions including stress testing, endurance testing, spike testing, and
volume testing with detailed metrics collection and analysis.

Features:
- Load testing with configurable user patterns
- Stress testing to identify breaking points
- Endurance testing for long-term stability
- Spike testing for sudden load changes
- Volume testing with large data sets
- Real-time performance monitoring
- Memory and resource usage analysis
- Database performance validation
- WebSocket performance testing
- Response time percentile analysis
- Throughput and concurrency measurement
- Performance regression detection

Usage:
    python performance_test.py [--host HOST] [--port PORT] [--test-type TYPE] [--duration DURATION] [--users USERS]
"""

import asyncio
import time
import logging
import sys
import json
import argparse
import statistics
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from collections import defaultdict, deque
from contextlib import asynccontextmanager
import psutil
import requests
import websockets
import numpy as np

@dataclass
class PerformanceConfig:
    """Performance test configuration."""
    base_url: str = "http://localhost:8000"
    ws_url: str = "ws://localhost:8000/ws"
    test_type: str = "load"  # load, stress, endurance, spike, volume
    duration: int = 300  # Test duration in seconds
    users: int = 50  # Concurrent users
    ramp_up_time: int = 60  # Ramp up time in seconds
    ramp_down_time: int = 60  # Ramp down time in seconds
    steady_state_time: int = 180  # Steady state duration in seconds
    think_time: float = 2.0  # Think time between requests in seconds
    request_timeout: int = 30  # Request timeout in seconds
    max_retries: int = 3
    output_file: Optional[str] = None
    verbose: bool = False
    collect_system_metrics: bool = True
    monitor_interval: float = 5.0  # System metrics collection interval
    
@dataclass
class PerformanceMetrics:
    """Performance metrics container."""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    response_times: List[float] = field(default_factory=list)
    response_times_by_endpoint: Dict[str, List[float]] = field(default_factory=dict)
    throughput_samples: List[float] = field(default_factory=list)
    concurrent_users: List[int] = field(default_factory=list)
    system_metrics: List[Dict[str, Any]] = field(default_factory=list)
    error_details: List[Dict[str, Any]] = field(default_factory=list)
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    
    @property
    def total_time(self) -> float:
        """Get total test time."""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0
    
    @property
    def average_response_time(self) -> float:
        """Get average response time."""
        if self.response_times:
            return statistics.mean(self.response_times)
        return 0
    
    @property
    def median_response_time(self) -> float:
        """Get median response time."""
        if self.response_times:
            return statistics.median(self.response_times)
        return 0
    
    @property
    def p95_response_time(self) -> float:
        """Get 95th percentile response time."""
        if len(self.response_times) >= 20:
            return np.percentile(self.response_times, 95)
        return 0
    
    @property
    def p99_response_time(self) -> float:
        """Get 99th percentile response time."""
        if len(self.response_times) >= 100:
            return np.percentile(self.response_times, 99)
        return 0
    
    @property
    def throughput(self) -> float:
        """Get requests per second."""
        if self.total_time > 0:
            return self.total_requests / self.total_time
        return 0
    
    @property
    def success_rate(self) -> float:
        """Get success rate percentage."""
        if self.total_requests > 0:
            return (self.successful_requests / self.total_requests) * 100
        return 0

class SystemMonitor:
    """System resource monitor."""
    
    def __init__(self, interval: float = 5.0):
        self.interval = interval
        self.metrics = deque(maxlen=1000)
        self.monitoring = False
        self.monitor_thread = None
        
    def start(self):
        """Start monitoring system resources."""
        if not self.monitoring:
            self.monitoring = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.monitor_thread.start()
    
    def stop(self):
        """Stop monitoring system resources."""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
    
    def _monitor_loop(self):
        """Monitor loop for system resources."""
        while self.monitoring:
            try:
                # CPU usage
                cpu_percent = psutil.cpu_percent(interval=1)
                
                # Memory usage
                memory = psutil.virtual_memory()
                
                # Disk usage
                disk = psutil.disk_usage('/')
                
                # Network I/O
                network = psutil.net_io_counters()
                
                # Process info if available
                process = psutil.Process()
                process_memory = process.memory_info()
                process_cpu = process.cpu_percent()
                
                metric = {
                    'timestamp': time.time(),
                    'cpu_percent': cpu_percent,
                    'memory_percent': memory.percent,
                    'memory_used_gb': memory.used / (1024**3),
                    'memory_available_gb': memory.available / (1024**3),
                    'disk_percent': (disk.used / disk.total) * 100,
                    'disk_free_gb': disk.free / (1024**3),
                    'network_bytes_sent': network.bytes_sent,
                    'network_bytes_recv': network.bytes_recv,
                    'process_memory_mb': process_memory.rss / (1024**2),
                    'process_cpu_percent': process_cpu
                }
                
                self.metrics.append(metric)
                time.sleep(self.interval)
                
            except Exception as e:
                logging.warning(f"Error collecting system metrics: {e}")
                time.sleep(self.interval)
    
    def get_current_metrics(self) -> Optional[Dict[str, Any]]:
        """Get latest system metrics."""
        if self.metrics:
            return self.metrics[-1]
        return None
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        if not self.metrics:
            return {}
        
        cpu_values = [m['cpu_percent'] for m in self.metrics]
        memory_values = [m['memory_percent'] for m in self.metrics]
        
        return {
            'cpu_avg': statistics.mean(cpu_values) if cpu_values else 0,
            'cpu_max': max(cpu_values) if cpu_values else 0,
            'memory_avg': statistics.mean(memory_values) if memory_values else 0,
            'memory_max': max(memory_values) if memory_values else 0,
            'total_samples': len(self.metrics)
        }

class PerformanceTestSuite:
    """Comprehensive performance test suite."""
    
    def __init__(self, config: PerformanceConfig):
        self.config = config
        self.logger = self._setup_logging()
        self.metrics = PerformanceMetrics()
        self.system_monitor = SystemMonitor(config.monitor_interval)
        self.session = requests.Session()
        self.session.timeout = config.request_timeout
        self.test_endpoints = [
            {'name': 'health', 'method': 'GET', 'path': '/health', 'weight': 10},
            {'name': 'chat', 'method': 'POST', 'path': '/chat', 'weight': 30, 'data': {'message': 'Performance test message'}},
            {'name': 'sessions', 'method': 'GET', 'path': '/sessions', 'weight': 20},
            {'name': 'rag_query', 'method': 'POST', 'path': '/rag/query', 'weight': 25, 'data': {'query': 'test query'}},
            {'name': 'upload', 'method': 'GET', 'path': '/upload', 'weight': 15},
        ]
        
    def _setup_logging(self) -> logging.Logger:
        """Setup performance test logging."""
        logger = logging.getLogger('performance_tests')
        logger.setLevel(logging.DEBUG if self.config.verbose else logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
        return logger
    
    def _make_request(self, endpoint: Dict[str, Any]) -> Tuple[bool, float, str]:
        """Make HTTP request and return success, response time, and error message."""
        url = f"{self.config.base_url}{endpoint['path']}"
        
        try:
            start_time = time.time()
            
            if endpoint['method'] == 'GET':
                response = self.session.get(url)
            elif endpoint['method'] == 'POST':
                json_data = endpoint.get('data', {})
                response = self.session.post(url, json=json_data)
            elif endpoint['method'] == 'PUT':
                json_data = endpoint.get('data', {})
                response = self.session.put(url, json=json_data)
            elif endpoint['method'] == 'DELETE':
                response = self.session.delete(url)
            else:
                return False, 0, f"Unsupported method: {endpoint['method']}"
            
            end_time = time.time()
            response_time = end_time - start_time
            
            success = response.status_code < 400
            error_msg = f"HTTP {response.status_code}" if not success else ""
            
            return success, response_time, error_msg
            
        except requests.RequestException as e:
            return False, 0, str(e)
        except Exception as e:
            return False, 0, str(e)
    
    async def _make_websocket_request(self, data: Dict[str, Any]) -> Tuple[bool, float, str]:
        """Make WebSocket request and return success, response time, and error message."""
        try:
            start_time = time.time()
            
            async with websockets.connect(self.config.ws_url) as websocket:
                await websocket.send(json.dumps(data))
                response = await asyncio.wait_for(websocket.recv(), timeout=self.config.request_timeout)
                end_time = time.time()
                
                response_time = end_time - start_time
                return True, response_time, ""
                
        except asyncio.TimeoutError:
            return False, self.config.request_timeout, "WebSocket timeout"
        except Exception as e:
            return False, 0, str(e)
    
    async def simulate_user_session(self, user_id: int) -> Dict[str, Any]:
        """Simulate a user session with realistic behavior patterns."""
        session_start = time.time()
        user_metrics = {
            'user_id': user_id,
            'requests_made': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_time': 0,
            'errors': []
        }
        
        try:
            # Simulate user thinking time
            await asyncio.sleep(random.uniform(0.5, 2.0))
            
            while time.time() - session_start < self.config.duration:
                # Select endpoint based on weights
                endpoint = self._select_endpoint()
                
                # Make request
                success, response_time, error_msg = self._make_request(endpoint)
                
                # Update metrics
                user_metrics['requests_made'] += 1
                if success:
                    user_metrics['successful_requests'] += 1
                    
                    # Record response time
                    self.metrics.response_times.append(response_time)
                    
                    if endpoint['path'] not in self.metrics.response_times_by_endpoint:
                        self.metrics.response_times_by_endpoint[endpoint['path']] = []
                    self.metrics.response_times_by_endpoint[endpoint['path']].append(response_time)
                    
                else:
                    user_metrics['failed_requests'] += 1
                    user_metrics['errors'].append(error_msg)
                    
                    self.metrics.error_details.append({
                        'user_id': user_id,
                        'endpoint': endpoint['path'],
                        'error': error_msg,
                        'timestamp': time.time()
                    })
                
                # Update global metrics
                self.metrics.total_requests += 1
                if success:
                    self.metrics.successful_requests += 1
                else:
                    self.metrics.failed_requests += 1
                
                # Simulate thinking time
                await asyncio.sleep(random.uniform(0.5, self.config.think_time * 2))
                
                # Check if we've reached the target duration
                if time.time() - session_start >= self.config.duration:
                    break
            
            user_metrics['total_time'] = time.time() - session_start
            return user_metrics
            
        except Exception as e:
            user_metrics['errors'].append(f"Session error: {str(e)}")
            return user_metrics
    
    def _select_endpoint(self) -> Dict[str, Any]:
        """Select endpoint based on weights."""
        total_weight = sum(ep['weight'] for ep in self.test_endpoints)
        random_weight = random.uniform(0, total_weight)
        
        current_weight = 0
        for endpoint in self.test_endpoints:
            current_weight += endpoint['weight']
            if random_weight <= current_weight:
                return endpoint
        
        return self.test_endpoints[0]  # Fallback
    
    async def run_load_test(self) -> Dict[str, Any]:
        """Run load test with steady user count."""
        self.logger.info(f"Running load test: {self.config.users} users for {self.config.duration} seconds")
        
        self.metrics.start_time = time.time()
        
        # Start system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.start()
        
        # Create user tasks
        tasks = []
        for i in range(self.config.users):
            task = asyncio.create_task(self.simulate_user_session(i))
            tasks.append(task)
        
        # Monitor throughput
        throughput_monitor = asyncio.create_task(self._monitor_throughput())
        
        # Wait for all tasks to complete
        await asyncio.gather(*tasks)
        throughput_monitor.cancel()
        
        self.metrics.end_time = time.time()
        
        # Stop system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.stop()
            self.metrics.system_metrics = list(self.system_monitor.metrics)
        
        return self._generate_performance_report()
    
    async def run_stress_test(self) -> Dict[str, Any]:
        """Run stress test with gradually increasing load."""
        self.logger.info(f"Running stress test: up to {self.config.users} users over {self.config.duration} seconds")
        
        self.metrics.start_time = time.time()
        
        # Start system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.start()
        
        # Gradually increase user load
        user_increment = self.config.users // 10  # 10 increments
        increment_duration = self.config.duration / 10
        
        tasks = []
        current_users = 0
        
        for i in range(10):
            # Add users
            new_users = min(user_increment, self.config.users - current_users)
            for j in range(new_users):
                task = asyncio.create_task(self.simulate_user_session(current_users + j))
                tasks.append(task)
            current_users += new_users
            
            self.logger.info(f"Stress test: {current_users} users active")
            self.metrics.concurrent_users.append(current_users)
            
            # Monitor for this period
            await asyncio.sleep(increment_duration)
            
            # Check for system breakdown
            if current_users > 10:  # Only check after initial users
                error_rate = self.metrics.failed_requests / max(self.metrics.total_requests, 1)
                if error_rate > 0.5:  # 50% error rate threshold
                    self.logger.warning(f"High error rate detected: {error_rate:.2%}")
                    break
        
        # Let remaining users complete
        await asyncio.sleep(30)  # Give time for remaining tasks
        
        # Cancel all tasks
        for task in tasks:
            task.cancel()
        
        self.metrics.end_time = time.time()
        
        # Stop system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.stop()
            self.metrics.system_metrics = list(self.system_monitor.metrics)
        
        return self._generate_performance_report()
    
    async def run_endurance_test(self) -> Dict[str, Any]:
        """Run endurance test for extended duration."""
        self.logger.info(f"Running endurance test: {self.config.users} users for {self.config.duration} seconds")
        
        self.metrics.start_time = time.time()
        
        # Start system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.start()
        
        # Create user tasks for the full duration
        tasks = []
        for i in range(self.config.users):
            task = asyncio.create_task(self.simulate_user_session(i))
            tasks.append(task)
        
        # Monitor for memory leaks and performance degradation
        monitor_task = asyncio.create_task(self._monitor_endurance())
        
        # Wait for all tasks to complete
        await asyncio.gather(*tasks)
        monitor_task.cancel()
        
        self.metrics.end_time = time.time()
        
        # Stop system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.stop()
            self.metrics.system_metrics = list(self.system_monitor.metrics)
        
        return self._generate_performance_report()
    
    async def run_spike_test(self) -> Dict[str, Any]:
        """Run spike test with sudden load changes."""
        self.logger.info(f"Running spike test with sudden load changes")
        
        self.metrics.start_time = time.time()
        
        # Start system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.start()
        
        # Spike pattern: low -> high -> low -> very high -> normal
        spike_phases = [
            {'users': self.config.users // 4, 'duration': self.config.duration // 6},
            {'users': self.config.users, 'duration': self.config.duration // 6},
            {'users': self.config.users // 4, 'duration': self.config.duration // 6},
            {'users': self.config.users * 2, 'duration': self.config.duration // 3},
            {'users': self.config.users, 'duration': self.config.duration // 6},
        ]
        
        all_tasks = []
        
        for phase in spike_phases:
            self.logger.info(f"Spike phase: {phase['users']} users for {phase['duration']} seconds")
            self.metrics.concurrent_users.append(phase['users'])
            
            # Create tasks for this phase
            tasks = []
            for i in range(phase['users']):
                task = asyncio.create_task(self.simulate_user_session(i))
                tasks.append(task)
            all_tasks.extend(tasks)
            
            # Monitor this phase
            await asyncio.sleep(phase['duration'])
            
            # Cancel tasks for this phase
            for task in tasks:
                task.cancel()
            
            # Brief pause between phases
            await asyncio.sleep(5)
        
        self.metrics.end_time = time.time()
        
        # Stop system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.stop()
            self.metrics.system_metrics = list(self.system_monitor.metrics)
        
        return self._generate_performance_report()
    
    async def run_volume_test(self) -> Dict[str, Any]:
        """Run volume test with large data payloads."""
        self.logger.info(f"Running volume test with large data payloads")
        
        self.metrics.start_time = time.time()
        
        # Create large test data
        large_data = {
            'large_text': 'x' * 10000,  # 10KB text
            'large_list': list(range(1000)),
            'large_dict': {f'key_{i}': f'value_{i}' for i in range(100)},
            'metadata': {'test_type': 'volume', 'timestamp': time.time()}
        }
        
        # Start system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.start()
        
        # Test large payload endpoints
        volume_endpoints = [
            {'name': 'large_chat', 'method': 'POST', 'path': '/chat', 'data': large_data},
            {'name': 'large_rag', 'method': 'POST', 'path': '/rag/query', 'data': large_data},
        ]
        
        for endpoint in volume_endpoints:
            self.logger.info(f"Testing {endpoint['name']} with large payload")
            
            # Make multiple requests with large payload
            for i in range(20):
                success, response_time, error_msg = self._make_request(endpoint)
                
                self.metrics.total_requests += 1
                if success:
                    self.metrics.successful_requests += 1
                    self.metrics.response_times.append(response_time)
                else:
                    self.metrics.failed_requests += 1
                    self.metrics.error_details.append({
                        'endpoint': endpoint['path'],
                        'error': error_msg,
                        'timestamp': time.time()
                    })
                
                await asyncio.sleep(1)  # Small delay between requests
        
        self.metrics.end_time = time.time()
        
        # Stop system monitoring
        if self.config.collect_system_metrics:
            self.system_monitor.stop()
            self.metrics.system_metrics = list(self.system_monitor.metrics)
        
        return self._generate_performance_report()
    
    async def _monitor_throughput(self):
        """Monitor throughput during load test."""
        while True:
            try:
                await asyncio.sleep(10)  # Monitor every 10 seconds
                
                current_time = time.time()
                if self.metrics.start_time:
                    elapsed = current_time - self.metrics.start_time
                    if elapsed > 0:
                        throughput = self.metrics.total_requests / elapsed
                        self.metrics.throughput_samples.append(throughput)
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.warning(f"Error monitoring throughput: {e}")
    
    async def _monitor_endurance(self):
        """Monitor for memory leaks and performance degradation during endurance test."""
        baseline_response_time = None
        
        while True:
            try:
                await asyncio.sleep(30)  # Monitor every 30 seconds
                
                current_time = time.time()
                if self.metrics.start_time and len(self.metrics.response_times) > 50:
                    recent_times = self.metrics.response_times[-50:]  # Last 50 requests
                    avg_response_time = statistics.mean(recent_times)
                    
                    if baseline_response_time is None:
                        baseline_response_time = avg_response_time
                    else:
                        # Check for performance degradation (>50% increase)
                        if avg_response_time > baseline_response_time * 1.5:
                            self.logger.warning(f"Performance degradation detected: {avg_response_time:.3f}s vs baseline {baseline_response_time:.3f}s")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.warning(f"Error monitoring endurance: {e}")
    
    def _generate_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report."""
        report = {
            'test_configuration': {
                'test_type': self.config.test_type,
                'duration': self.config.duration,
                'users': self.config.users,
                'base_url': self.config.base_url,
                'request_timeout': self.config.request_timeout,
                'collect_system_metrics': self.config.collect_system_metrics
            },
            'test_results': {
                'total_requests': self.metrics.total_requests,
                'successful_requests': self.metrics.successful_requests,
                'failed_requests': self.metrics.failed_requests,
                'success_rate': self.metrics.success_rate,
                'total_time': self.metrics.total_time,
                'throughput': self.metrics.throughput
            },
            'response_time_analysis': {
                'average': self.metrics.average_response_time,
                'median': self.metrics.median_response_time,
                'p95': self.metrics.p95_response_time,
                'p99': self.metrics.p99_response_time,
                'min': min(self.metrics.response_times) if self.metrics.response_times else 0,
                'max': max(self.metrics.response_times) if self.metrics.response_times else 0,
                'standard_deviation': statistics.stdev(self.metrics.response_times) if len(self.metrics.response_times) > 1 else 0
            },
            'endpoint_performance': {},
            'error_analysis': {
                'total_errors': len(self.metrics.error_details),
                'error_rate': (self.metrics.failed_requests / max(self.metrics.total_requests, 1)) * 100,
                'common_errors': self._analyze_common_errors()
            },
            'system_performance': {},
            'test_timestamp': datetime.now().isoformat()
        }
        
        # Endpoint performance analysis
        for endpoint, times in self.metrics.response_times_by_endpoint.items():
            if times:
                report['endpoint_performance'][endpoint] = {
                    'requests': len(times),
                    'average': statistics.mean(times),
                    'median': statistics.median(times),
                    'p95': np.percentile(times, 95) if len(times) >= 20 else max(times),
                    'max': max(times)
                }
        
        # System performance analysis
        if self.metrics.system_metrics and self.config.collect_system_metrics:
            system_summary = self.system_monitor.get_metrics_summary()
            report['system_performance'] = {
                'monitoring_samples': len(self.metrics.system_metrics),
                'cpu_utilization': {
                    'average': system_summary.get('cpu_avg', 0),
                    'peak': system_summary.get('cpu_max', 0)
                },
                'memory_utilization': {
                    'average': system_summary.get('memory_avg', 0),
                    'peak': system_summary.get('memory_max', 0)
                }
            }
        
        # Performance assessment
        report['performance_assessment'] = self._assess_performance(report)
        
        return report
    
    def _analyze_common_errors(self) -> Dict[str, int]:
        """Analyze common error patterns."""
        error_counts = defaultdict(int)
        for error in self.metrics.error_details:
            error_key = error['error'][:50]  # Truncate long error messages
            error_counts[error_key] += 1
        
        return dict(sorted(error_counts.items(), key=lambda x: x[1], reverse=True)[:10])
    
    def _assess_performance(self, report: Dict[str, Any]) -> Dict[str, Any]:
        """Assess overall performance based on results."""
        assessment = {
            'status': 'UNKNOWN',
            'issues': [],
            'recommendations': []
        }
        
        test_results = report['test_results']
        response_analysis = report['response_time_analysis']
        
        # Success rate check
        success_rate = test_results['success_rate']
        if success_rate >= 99:
            assessment['success_rating'] = 'EXCELLENT'
        elif success_rate >= 95:
            assessment['success_rating'] = 'GOOD'
        elif success_rate >= 90:
            assessment['success_rating'] = 'ACCEPTABLE'
        else:
            assessment['success_rating'] = 'POOR'
            assessment['issues'].append(f"Low success rate: {success_rate:.1f}%")
        
        # Response time checks
        avg_response_time = response_analysis['average']
        p95_response_time = response_analysis['p95']
        
        if avg_response_time <= 1.0:
            assessment['response_time_rating'] = 'EXCELLENT'
        elif avg_response_time <= 2.0:
            assessment['response_time_rating'] = 'GOOD'
        elif avg_response_time <= 5.0:
            assessment['response_time_rating'] = 'ACCEPTABLE'
        else:
            assessment['response_time_rating'] = 'POOR'
            assessment['issues'].append(f"High average response time: {avg_response_time:.3f}s")
        
        if p95_response_time <= 2.0:
            assessment['p95_rating'] = 'EXCELLENT'
        elif p95_response_time <= 5.0:
            assessment['p95_rating'] = 'GOOD'
        elif p95_response_time <= 10.0:
            assessment['p95_rating'] = 'ACCEPTABLE'
        else:
            assessment['p95_rating'] = 'POOR'
            assessment['issues'].append(f"High P95 response time: {p95_response_time:.3f}s")
        
        # Throughput check
        throughput = test_results['throughput']
        if throughput >= 100:
            assessment['throughput_rating'] = 'EXCELLENT'
        elif throughput >= 50:
            assessment['throughput_rating'] = 'GOOD'
        elif throughput >= 20:
            assessment['throughput_rating'] = 'ACCEPTABLE'
        else:
            assessment['throughput_rating'] = 'POOR'
            assessment['issues'].append(f"Low throughput: {throughput:.1f} requests/second")
        
        # Overall status
        ratings = [
            assessment.get('success_rating', 'POOR'),
            assessment.get('response_time_rating', 'POOR'),
            assessment.get('p95_rating', 'POOR'),
            assessment.get('throughput_rating', 'POOR')
        ]
        
        excellent_count = ratings.count('EXCELLENT')
        good_count = ratings.count('GOOD')
        
        if excellent_count >= 3:
            assessment['status'] = 'PASS'
        elif good_count >= 3:
            assessment['status'] = 'PASS_WITH_WARNINGS'
        else:
            assessment['status'] = 'FAIL'
        
        # Generate recommendations
        if assessment['status'] == 'FAIL':
            assessment['recommendations'].append("Consider optimizing database queries and implementing caching")
            assessment['recommendations'].append("Monitor system resources and scale horizontally if needed")
        elif assessment['status'] == 'PASS_WITH_WARNINGS':
            assessment['recommendations'].append("Monitor performance trends and consider optimization opportunities")
        
        return assessment
    
    def save_report(self, report: Dict[str, Any]):
        """Save performance report to file."""
        if self.config.output_file:
            with open(self.config.output_file, 'w') as f:
                json.dump(report, f, indent=2)
            self.logger.info(f"Performance report saved to: {self.config.output_file}")
    
    def print_summary(self, report: Dict[str, Any]):
        """Print performance test summary."""
        test_config = report['test_configuration']
        test_results = report['test_results']
        response_analysis = report['response_time_analysis']
        assessment = report['performance_assessment']
        
        print(f"\n{'='*80}")
        print(f"PERFORMANCE TEST SUMMARY - {test_config['test_type'].upper()}")
        print(f"{'='*80}")
        print(f"Test Configuration:")
        print(f"  - Test Type: {test_config['test_type']}")
        print(f"  - Duration: {test_config['duration']} seconds")
        print(f"  - Concurrent Users: {test_config['users']}")
        print(f"  - Target URL: {test_config['base_url']}")
        
        print(f"\nTest Results:")
        print(f"  - Total Requests: {test_results['total_requests']:,}")
        print(f"  - Successful Requests: {test_results['successful_requests']:,}")
        print(f"  - Failed Requests: {test_results['failed_requests']:,}")
        print(f"  - Success Rate: {test_results['success_rate']:.2f}%")
        print(f"  - Total Time: {test_results['total_time']:.2f} seconds")
        print(f"  - Throughput: {test_results['throughput']:.2f} requests/second")
        
        print(f"\nResponse Time Analysis:")
        print(f"  - Average: {response_analysis['average']:.3f} seconds")
        print(f"  - Median: {response_analysis['median']:.3f} seconds")
        print(f"  - P95: {response_analysis['p95']:.3f} seconds")
        print(f"  - P99: {response_analysis['p99']:.3f} seconds")
        print(f"  - Min: {response_analysis['min']:.3f} seconds")
        print(f"  - Max: {response_analysis['max']:.3f} seconds")
        
        print(f"\nPerformance Assessment:")
        print(f"  - Overall Status: {assessment['status']}")
        print(f"  - Success Rate: {assessment.get('success_rating', 'N/A')}")
        print(f"  - Response Time: {assessment.get('response_time_rating', 'N/A')}")
        print(f"  - P95 Performance: {assessment.get('p95_rating', 'N/A')}")
        print(f"  - Throughput: {assessment.get('throughput_rating', 'N/A')}")
        
        if assessment['issues']:
            print(f"\nIssues Detected:")
            for issue in assessment['issues']:
                print(f"  - {issue}")
        
        if assessment['recommendations']:
            print(f"\nRecommendations:")
            for rec in assessment['recommendations']:
                print(f"  - {rec}")
        
        if 'system_performance' in report and report['system_performance']:
            sys_perf = report['system_performance']
            print(f"\nSystem Performance:")
            if 'cpu_utilization' in sys_perf:
                print(f"  - CPU Average: {sys_perf['cpu_utilization']['average']:.1f}%")
                print(f"  - CPU Peak: {sys_perf['cpu_utilization']['peak']:.1f}%")
            if 'memory_utilization' in sys_perf:
                print(f"  - Memory Average: {sys_perf['memory_utilization']['average']:.1f}%")
                print(f"  - Memory Peak: {sys_perf['memory_utilization']['peak']:.1f}%")

def main():
    """Main function to run performance tests."""
    parser = argparse.ArgumentParser(description='Customer Support AI Agent Performance Tests')
    parser.add_argument('--host', default='localhost', help='API host (default: localhost)')
    parser.add_argument('--port', type=int, default=8000, help='API port (default: 8000)')
    parser.add_argument('--test-type', choices=['load', 'stress', 'endurance', 'spike', 'volume'], 
                       default='load', help='Type of performance test')
    parser.add_argument('--duration', type=int, default=300, help='Test duration in seconds')
    parser.add_argument('--users', type=int, default=50, help='Concurrent users')
    parser.add_argument('--think-time', type=float, default=2.0, help='Think time between requests')
    parser.add_argument('--timeout', type=int, default=30, help='Request timeout in seconds')
    parser.add_argument('--output', help='Output file for test results (JSON format)')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--no-system-metrics', action='store_true', help='Disable system metrics collection')
    
    args = parser.parse_args()
    
    # Configure test
    config = PerformanceConfig(
        base_url=f"http://{args.host}:{args.port}",
        ws_url=f"ws://{args.host}:{args.port}/ws",
        test_type=args.test_type,
        duration=args.duration,
        users=args.users,
        think_time=args.think_time,
        request_timeout=args.timeout,
        output_file=args.output,
        verbose=args.verbose,
        collect_system_metrics=not args.no_system_metrics
    )
    
    # Initialize test suite
    test_suite = PerformanceTestSuite(config)
    
    # Configure logging
    if args.verbose:
        test_suite.logger.setLevel(logging.DEBUG)
    
    # Run performance test
    try:
        print(f"Starting {args.test_type} performance test...")
        print(f"Configuration: {config.users} users, {config.duration}s duration")
        print(f"Target: {config.base_url}")
        
        if args.test_type == 'load':
            report = asyncio.run(test_suite.run_load_test())
        elif args.test_type == 'stress':
            report = asyncio.run(test_suite.run_stress_test())
        elif args.test_type == 'endurance':
            report = asyncio.run(test_suite.run_endurance_test())
        elif args.test_type == 'spike':
            report = asyncio.run(test_suite.run_spike_test())
        elif args.test_type == 'volume':
            report = asyncio.run(test_suite.run_volume_test())
        else:
            raise ValueError(f"Unknown test type: {args.test_type}")
        
        # Print summary
        test_suite.print_summary(report)
        
        # Save report
        test_suite.save_report(report)
        
        # Exit with appropriate code
        exit_code = 0 if report['performance_assessment']['status'] in ['PASS'] else 1
        sys.exit(exit_code)
        
    except KeyboardInterrupt:
        print("\nPerformance test interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\nPerformance test failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()