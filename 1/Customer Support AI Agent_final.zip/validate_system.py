#!/usr/bin/env python3
"""
Customer Support AI Agent - System Health Validator

This script performs comprehensive health checks on all system components
and provides detailed reporting on system status and performance.
"""

import asyncio
import json
import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/system_validation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

try:
    import aiohttp
    import asyncpg
    import redis.asyncio as redis
    import chromadb
    import docker
    import psutil
    import subprocess
    from prometheus_client import CollectorRegistry, generate_latest
    from sqlalchemy import create_engine, text
    from sqlalchemy.orm import sessionmaker
except ImportError as e:
    print(f"Error importing required packages: {e}")
    print("Please install required packages:")
    print("pip install aiohttp asyncpg redis chromadb docker prometheus_client psutil sqlalchemy")
    sys.exit(1)


class HealthChecker:
    """Comprehensive system health checker"""
    
    def __init__(self, config_path: str = ".env"):
        self.config = self._load_config(config_path)
        self.session = None
        self.results = {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": "unknown",
            "components": {},
            "performance": {},
            "recommendations": []
        }
        
    def _load_config(self, config_path: str) -> Dict[str, str]:
        """Load environment configuration"""
        config = {}
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        config[key.strip()] = value.strip().strip('"\'')
        return config
    
    async def check_all(self) -> Dict[str, Any]:
        """Run all health checks"""
        logger.info("Starting comprehensive system health check...")
        
        checks = [
            ("System Resources", self._check_system_resources),
            ("Docker Services", self._check_docker_services),
            ("Database", self._check_database),
            ("Redis Cache", self._check_redis),
            ("ChromaDB", self._check_chromadb),
            ("Backend API", self._check_backend_api),
            ("Frontend", self._check_frontend),
            ("File System", self._check_filesystem),
            ("Network", self._check_network),
            ("Security", self._check_security),
            ("Performance", self._check_performance)
        ]
        
        for check_name, check_func in checks:
            logger.info(f"Running {check_name} check...")
            try:
                result = await check_func()
                self.results["components"][check_name] = result
                
                if result["status"] == "critical":
                    self.results["overall_status"] = "critical"
                elif result["status"] == "warning" and self.results["overall_status"] != "critical":
                    self.results["overall_status"] = "warning"
                elif result["status"] == "healthy" and self.results["overall_status"] == "unknown":
                    self.results["overall_status"] = "healthy"
                    
            except Exception as e:
                logger.error(f"Error in {check_name} check: {e}")
                self.results["components"][check_name] = {
                    "status": "error",
                    "error": str(e),
                    "details": traceback.format_exc()
                }
        
        self._generate_recommendations()
        return self.results
    
    async def _check_system_resources(self) -> Dict[str, Any]:
        """Check system resources (CPU, memory, disk)"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_available = memory.available / (1024**3)  # GB
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            disk_free = disk.free / (1024**3)  # GB
            
            # Load average (Unix-like systems)
            load_avg = None
            if hasattr(os, 'getloadavg'):
                load_avg = os.getloadavg()
            
            # Determine status
            status = "healthy"
            issues = []
            
            if cpu_percent > 90:
                status = "critical"
                issues.append(f"High CPU usage: {cpu_percent:.1f}%")
            elif cpu_percent > 75:
                status = "warning"
                issues.append(f"Elevated CPU usage: {cpu_percent:.1f}%")
            
            if memory_percent > 90:
                status = "critical"
                issues.append(f"High memory usage: {memory_percent:.1f}%")
            elif memory_percent > 80:
                status = "warning"
                issues.append(f"Elevated memory usage: {memory_percent:.1f}%")
            
            if disk_percent > 90:
                status = "critical"
                issues.append(f"Low disk space: {disk_percent:.1f}% used")
            elif disk_percent > 85:
                status = "warning"
                issues.append(f"Disk space warning: {disk_percent:.1f}% used")
            
            if load_avg and load_avg[0] > psutil.cpu_count():
                status = "warning"
                issues.append(f"High load average: {load_avg[0]:.2f}")
            
            return {
                "status": status,
                "details": {
                    "cpu": {
                        "usage_percent": cpu_percent,
                        "load_average": load_avg,
                        "cores": psutil.cpu_count()
                    },
                    "memory": {
                        "usage_percent": memory_percent,
                        "available_gb": memory_available,
                        "total_gb": memory.total / (1024**3)
                    },
                    "disk": {
                        "usage_percent": disk_percent,
                        "free_gb": disk_free,
                        "total_gb": disk.total / (1024**3)
                    }
                },
                "issues": issues
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_docker_services(self) -> Dict[str, Any]:
        """Check Docker services status"""
        try:
            docker_client = docker.from_env()
            
            # Get container stats
            containers = docker_client.containers.list(all=True)
            
            service_status = {}
            healthy_count = 0
            total_count = 0
            
            for container in containers:
                if 'customer-support' in container.name:
                    total_count += 1
                    
                    # Get container stats
                    stats = container.stats(stream=False)
                    cpu_percent = self._calculate_cpu_percent(stats)
                    memory_usage = stats['memory_stats'].get('usage', 0) / (1024**3)
                    memory_limit = stats['memory_stats'].get('limit', 0) / (1024**3)
                    
                    container_health = "unknown"
                    if container.status == "running":
                        # Check if container has health check
                        if container.attrs.get('State', {}).get('Health'):
                            container_health = container.attrs['State']['Health']['Status']
                        else:
                            container_health = "healthy"
                        healthy_count += 1
                    elif container.status == "exited":
                        container_health = "unhealthy"
                    
                    service_status[container.name] = {
                        "status": container_health,
                        "docker_status": container.status,
                        "cpu_percent": cpu_percent,
                        "memory_gb": memory_usage,
                        "memory_limit_gb": memory_limit if memory_limit > 0 else "unlimited"
                    }
            
            # Determine overall status
            if total_count == 0:
                status = "warning"
                issues = ["No Docker services found"]
            elif healthy_count == total_count:
                status = "healthy"
                issues = []
            elif healthy_count > total_count / 2:
                status = "warning"
                issues = [f"Only {healthy_count}/{total_count} services are healthy"]
            else:
                status = "critical"
                issues = [f"Only {healthy_count}/{total_count} services are healthy"]
            
            return {
                "status": status,
                "details": {
                    "services": service_status,
                    "summary": {
                        "total": total_count,
                        "healthy": healthy_count,
                        "unhealthy": total_count - healthy_count
                    }
                },
                "issues": issues
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    def _calculate_cpu_percent(self, stats: Dict) -> float:
        """Calculate CPU percentage from container stats"""
        try:
            cpu_delta = stats['cpu_stats']['cpu_usage']['total_usage'] - \
                       stats['precpu_stats']['cpu_usage']['total_usage']
            system_delta = stats['cpu_stats']['system_cpu_usage'] - \
                          stats['precpu_stats']['system_cpu_usage']
            
            if system_delta > 0:
                cpu_percent = (cpu_delta / system_delta) * len(stats['cpu_stats']['cpu_usage']['percpu_usage']) * 100.0
                return cpu_percent
            return 0.0
        except:
            return 0.0
    
    async def _check_database(self) -> Dict[str, Any]:
        """Check database connectivity and performance"""
        try:
            database_url = self.config.get('DATABASE_URL', 'sqlite:///./customer_support.db')
            
            if 'postgresql' in database_url:
                # PostgreSQL connection
                conn = await asyncpg.connect(database_url)
                
                # Basic connectivity test
                result = await conn.fetchval('SELECT 1')
                assert result == 1
                
                # Check database stats
                stats = await conn.fetchrow("""
                    SELECT 
                        count(*) as connection_count,
                        (SELECT count(*) FROM pg_stat_activity WHERE state = 'active') as active_connections,
                        (SELECT count(*) FROM pg_stat_activity WHERE state = 'idle') as idle_connections
                    FROM pg_stat_activity
                """)
                
                # Check table sizes
                table_sizes = await conn.fetch("""
                    SELECT 
                        schemaname,
                        tablename,
                        pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
                        pg_total_relation_size(schemaname||'.'||tablename) as size_bytes
                    FROM pg_tables 
                    WHERE schemaname = 'public'
                    ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
                    LIMIT 10
                """)
                
                await conn.close()
                
                status = "healthy"
                issues = []
                
                if stats['active_connections'] > 50:
                    status = "warning"
                    issues.append(f"High number of active connections: {stats['active_connections']}")
                
                return {
                    "status": status,
                    "details": {
                        "type": "PostgreSQL",
                        "connections": {
                            "total": stats['connection_count'],
                            "active": stats['active_connections'],
                            "idle": stats['idle_connections']
                        },
                        "tables": [dict(row) for row in table_sizes]
                    },
                    "issues": issues
                }
                
            else:
                # SQLite connection (development)
                engine = create_engine(database_url)
                
                with engine.connect() as conn:
                    result = conn.execute(text("SELECT 1"))
                    assert result.fetchone()[0] == 1
                
                # Check SQLite file size
                db_path = database_url.replace('sqlite:///', '')
                if os.path.exists(db_path):
                    db_size = os.path.getsize(db_path) / (1024**2)  # MB
                    
                    return {
                        "status": "healthy",
                        "details": {
                            "type": "SQLite",
                            "size_mb": db_size,
                            "path": db_path
                        },
                        "issues": []
                    }
                else:
                    return {
                        "status": "error",
                        "error": "Database file not found",
                        "details": {"type": "SQLite"}
                    }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_redis(self) -> Dict[str, Any]:
        """Check Redis connectivity and performance"""
        try:
            redis_url = self.config.get('REDIS_URL', 'redis://localhost:6379')
            
            if redis_url:
                r = redis.from_url(redis_url)
                
                # Test connection
                await r.ping()
                
                # Get Redis info
                info = await r.info()
                
                # Check memory usage
                memory_usage = info.get('used_memory', 0) / (1024**2)  # MB
                memory_limit = info.get('maxmemory', 0) / (1024**2)  # MB
                
                # Get key count
                key_count = await r.dbsize()
                
                # Test performance
                start_time = time.time()
                await r.set('health_check', 'test', ex=1)
                value = await r.get('health_check')
                await r.delete('health_check')
                perf_time = time.time() - start_time
                
                await r.close()
                
                status = "healthy"
                issues = []
                
                if memory_limit > 0 and memory_usage > 0:
                    memory_percent = (memory_usage / memory_limit) * 100
                    if memory_percent > 90:
                        status = "critical"
                        issues.append(f"High Redis memory usage: {memory_percent:.1f}%")
                    elif memory_percent > 80:
                        status = "warning"
                        issues.append(f"Elevated Redis memory usage: {memory_percent:.1f}%")
                
                if perf_time > 0.1:  # 100ms
                    status = "warning"
                    issues.append(f"Slow Redis performance: {perf_time:.3f}s")
                
                return {
                    "status": status,
                    "details": {
                        "version": info.get('redis_version'),
                        "memory": {
                            "usage_mb": memory_usage,
                            "limit_mb": memory_limit if memory_limit > 0 else None,
                            "keys": key_count
                        },
                        "performance": {
                            "ping_time_ms": perf_time * 1000,
                            "connected_clients": info.get('connected_clients'),
                            "total_commands_processed": info.get('total_commands_processed')
                        },
                        "uptime_seconds": info.get('uptime_in_seconds')
                    },
                    "issues": issues
                }
            else:
                return {
                    "status": "warning",
                    "error": "Redis URL not configured",
                    "details": {"redis_url": redis_url},
                    "issues": ["Redis is not configured"]
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_chromadb(self) -> Dict[str, Any]:
        """Check ChromaDB connectivity and performance"""
        try:
            # Test ChromaDB client
            client = chromadb.Client()
            
            # List collections
            collections = client.list_collections()
            
            # Test collection creation
            test_collection = client.get_or_create_collection("health_check_test")
            
            # Add a test document
            test_collection.add(
                documents=["Test document for health check"],
                ids=["test_health_check"],
                metadatas={"test": True}
            )
            
            # Query the collection
            results = test_collection.query(
                query_texts=["test"],
                n_results=1
            )
            
            # Clean up test collection
            test_collection.delete(ids=["test_health_check"])
            
            # Check each collection
            collection_stats = []
            for collection in collections[:10]:  # Check first 10 collections
                count = collection.count()
                collection_stats.append({
                    "name": collection.name,
                    "documents": count
                })
            
            return {
                "status": "healthy",
                "details": {
                    "collections": len(collections),
                    "collection_stats": collection_stats,
                    "query_test": {
                        "documents_found": len(results.get('documents', [[]])[0]) if results.get('documents') else 0,
                        "query_successful": len(results.get('documents', [[]])[0]) > 0 if results.get('documents') else False
                    }
                },
                "issues": []
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_backend_api(self) -> Dict[str, Any]:
        """Check Backend API health"""
        try:
            base_url = "http://localhost:8000"
            
            async with aiohttp.ClientSession() as session:
                # Test health endpoint
                async with session.get(f"{base_url}/health") as response:
                    health_data = await response.json()
                
                # Test detailed health
                async with session.get(f"{base_url}/health/detailed") as response:
                    detailed_health = await response.json()
                
                # Test API documentation
                async with session.get(f"{base_url}/docs") as response:
                    docs_status = response.status
                
                # Test metrics endpoint
                async with session.get(f"{base_url}/metrics") as response:
                    metrics_content = await response.text()
                    has_metrics = len(metrics_content) > 0
                
                # Check service health
                services = detailed_health.get('services', {})
                service_issues = []
                unhealthy_services = []
                
                for service, status in services.items():
                    if isinstance(status, dict):
                        if status.get('status') != 'healthy':
                            unhealthy_services.append(service)
                            service_issues.append(f"{service}: {status.get('status')}")
                
                # Determine status
                status = "healthy"
                issues = []
                
                if unhealthy_services:
                    if len(unhealthy_services) > len(services) / 2:
                        status = "critical"
                    else:
                        status = "warning"
                    issues.extend(service_issues)
                
                return {
                    "status": status,
                    "details": {
                        "base_url": base_url,
                        "health": health_data,
                        "services": services,
                        "api_docs": {
                            "status": docs_status,
                            "accessible": docs_status == 200
                        },
                        "metrics": {
                            "available": has_metrics,
                            "size_bytes": len(metrics_content)
                        },
                        "unhealthy_services": unhealthy_services
                    },
                    "issues": issues
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_frontend(self) -> Dict[str, Any]:
        """Check Frontend accessibility"""
        try:
            base_url = "http://localhost:3000"
            
            async with aiohttp.ClientSession() as session:
                # Test frontend accessibility
                async with session.get(base_url) as response:
                    content = await response.text()
                    status_code = response.status
                
                # Check for React app indicators
                has_react = 'react' in content.lower() or 'root' in content.lower()
                
                # Test development server info endpoint (if available)
                dev_server_healthy = False
                try:
                    async with session.get(f"{base_url}/__vite") as response:
                        dev_server_healthy = response.status == 200
                except:
                    pass
                
                status = "healthy"
                issues = []
                
                if status_code != 200:
                    status = "error"
                    issues.append(f"Frontend returned status {status_code}")
                elif not has_react:
                    status = "warning"
                    issues.append("Frontend may not be a React application")
                
                return {
                    "status": status,
                    "details": {
                        "base_url": base_url,
                        "status_code": status_code,
                        "content_length": len(content),
                        "react_app": has_react,
                        "dev_server": dev_server_healthy,
                        "accessible": status_code == 200
                    },
                    "issues": issues
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_filesystem(self) -> Dict[str, Any]:
        """Check filesystem health and permissions"""
        try:
            paths_to_check = [
                "data/chromadb",
                "data/uploads",
                "logs",
                "backups"
            ]
            
            path_status = {}
            writable_paths = 0
            
            for path in paths_to_check:
                path_obj = Path(path)
                
                if path_obj.exists():
                    # Check if path is directory
                    is_dir = path_obj.is_dir()
                    
                    # Check write permissions
                    is_writable = os.access(path, os.W_OK) if path_obj.exists() else False
                    if is_writable:
                        writable_paths += 1
                    
                    # Get size (if directory)
                    size_mb = 0
                    if is_dir:
                        size_mb = sum(f.stat().st_size for f in path_obj.rglob('*') if f.is_file()) / (1024**2)
                    
                    path_status[path] = {
                        "exists": True,
                        "is_directory": is_dir,
                        "writable": is_writable,
                        "size_mb": size_mb
                    }
                else:
                    path_status[path] = {
                        "exists": False,
                        "is_directory": False,
                        "writable": False,
                        "size_mb": 0
                    }
            
            # Check disk space
            disk_usage = psutil.disk_usage('/')
            disk_free_gb = disk_usage.free / (1024**3)
            disk_total_gb = disk_usage.total / (1024**3)
            
            # Determine status
            status = "healthy"
            issues = []
            
            if not all(status_info["exists"] for status_info in path_status.values()):
                status = "warning"
                missing_paths = [path for path, info in path_status.items() if not info["exists"]]
                issues.append(f"Missing directories: {', '.join(missing_paths)}")
            
            if disk_free_gb < 1:  # Less than 1GB free
                status = "critical"
                issues.append(f"Very low disk space: {disk_free_gb:.1f}GB free")
            elif disk_free_gb < 5:  # Less than 5GB free
                status = "warning"
                issues.append(f"Low disk space: {disk_free_gb:.1f}GB free")
            
            return {
                "status": status,
                "details": {
                    "paths": path_status,
                    "disk": {
                        "free_gb": disk_free_gb,
                        "total_gb": disk_total_gb,
                        "usage_percent": (disk_usage.used / disk_usage.total) * 100
                    },
                    "writable_paths": f"{writable_paths}/{len(paths_to_check)}"
                },
                "issues": issues
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_network(self) -> Dict[str, Any]:
        """Check network connectivity"""
        try:
            import socket
            
            # Test DNS resolution
            dns_tests = {
                "localhost": "127.0.0.1",
                "openai.com": None,
                "github.com": None
            }
            
            dns_results = {}
            for hostname, expected in dns_tests.items():
                try:
                    ip = socket.gethostbyname(hostname)
                    dns_results[hostname] = {
                        "status": "success",
                        "ip": ip,
                        "expected": expected,
                        "match": ip == expected if expected else True
                    }
                except socket.gaierror as e:
                    dns_results[hostname] = {
                        "status": "failed",
                        "error": str(e)
                    }
            
            # Test HTTP connectivity
            http_tests = [
                "http://localhost:8000/health",
                "http://localhost:3000",
                "https://api.openai.com"
            ]
            
            http_results = {}
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                for url in http_tests:
                    try:
                        async with session.get(url) as response:
                            http_results[url] = {
                                "status": "success",
                                "status_code": response.status,
                                "response_time_ms": response.headers.get('X-Response-Time', 'N/A')
                            }
                    except Exception as e:
                        http_results[url] = {
                            "status": "failed",
                            "error": str(e)
                        }
            
            # Test port availability
            ports_to_check = [8000, 3000, 5432, 6379, 9090]
            port_status = {}
            
            for port in ports_to_check:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex(('localhost', port))
                sock.close()
                
                port_status[port] = {
                    "open": result == 0,
                    "service": self._get_port_service(port)
                }
            
            # Determine status
            status = "healthy"
            issues = []
            
            failed_dns = [host for host, result in dns_results.items() if result["status"] == "failed"]
            if failed_dns:
                status = "warning"
                issues.append(f"DNS resolution failed for: {', '.join(failed_dns)}")
            
            failed_http = [url for url, result in http_results.items() if result["status"] == "failed"]
            if failed_http:
                status = "warning"
                issues.append(f"HTTP connectivity failed for: {', '.join(failed_http)}")
            
            return {
                "status": status,
                "details": {
                    "dns": dns_results,
                    "http": http_results,
                    "ports": port_status
                },
                "issues": issues
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    def _get_port_service(self, port: int) -> str:
        """Get service name for common ports"""
        services = {
            8000: "Backend API",
            3000: "Frontend",
            5432: "PostgreSQL",
            6379: "Redis",
            9090: "Prometheus",
            3001: "Grafana"
        }
        return services.get(port, "Unknown")
    
    async def _check_security(self) -> Dict[str, Any]:
        """Check security configuration"""
        try:
            # Test for common security headers
            async with aiohttp.ClientSession() as session:
                async with session.get("http://localhost:8000/health") as response:
                    headers = response.headers
                
                security_headers = {
                    "X-Content-Type-Options": headers.get("X-Content-Type-Options"),
                    "X-Frame-Options": headers.get("X-Frame-Options"),
                    "X-XSS-Protection": headers.get("X-XSS-Protection"),
                    "Strict-Transport-Security": headers.get("Strict-Transport-Security")
                }
                
                # Check for exposed sensitive files
                sensitive_paths = [
                    "/.env",
                    "/config.py",
                    "/settings.py",
                    "/secrets.json"
                ]
                
                exposed_files = []
                for path in sensitive_paths:
                    try:
                        async with session.get(f"http://localhost:8000{path}") as response:
                            if response.status == 200:
                                exposed_files.append(path)
                    except:
                        pass
                
                # Test rate limiting (basic test)
                rate_limited = False
                try:
                    # Send multiple requests quickly
                    for i in range(10):
                        async with session.get("http://localhost:8000/health") as response:
                            if response.status == 429:
                                rate_limited = True
                                break
                except:
                    pass
                
                # Check environment variables for security issues
                security_issues = []
                
                if self.config.get('SECRET_KEY', '').lower() in ['secret', 'dev-secret-key', 'change-me']:
                    security_issues.append("Weak SECRET_KEY detected")
                
                if self.config.get('JWT_SECRET_KEY', '').lower() in ['jwt-secret', 'change-me', '']:
                    security_issues.append("Weak JWT_SECRET_KEY detected")
                
                if self.config.get('DEBUG', 'false').lower() == 'true':
                    security_issues.append("Debug mode is enabled")
                
                status = "healthy"
                issues = []
                
                if exposed_files:
                    status = "critical"
                    issues.append(f"Sensitive files exposed: {', '.join(exposed_files)}")
                
                if security_issues:
                    status = "warning"
                    issues.extend(security_issues)
                
                return {
                    "status": status,
                    "details": {
                        "security_headers": security_headers,
                        "exposed_files": exposed_files,
                        "rate_limiting": {
                            "enabled": rate_limited,
                            "tested": True
                        },
                        "security_issues": security_issues
                    },
                    "issues": issues
                }
                
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    async def _check_performance(self) -> Dict[str, Any]:
        """Check system performance metrics"""
        try:
            performance_metrics = {}
            
            # Test API response time
            async with aiohttp.ClientSession() as session:
                start_time = time.time()
                async with session.get("http://localhost:8000/health") as response:
                    response_time = time.time() - start_time
                
                performance_metrics["api_response_time"] = {
                    "time_seconds": response_time,
                    "time_ms": response_time * 1000,
                    "status": "good" if response_time < 1.0 else "slow" if response_time < 3.0 else "critical"
                }
                
                # Test concurrent API requests
                start_time = time.time()
                tasks = []
                for i in range(10):
                    task = session.get("http://localhost:8000/health")
                    tasks.append(task)
                
                responses = await asyncio.gather(*tasks, return_exceptions=True)
                concurrent_time = time.time() - start_time
                
                successful_requests = sum(1 for r in responses if not isinstance(r, Exception))
                
                performance_metrics["concurrent_requests"] = {
                    "total_requests": 10,
                    "successful_requests": successful_requests,
                    "failed_requests": 10 - successful_requests,
                    "total_time_seconds": concurrent_time,
                    "average_time_per_request_ms": (concurrent_time / 10) * 1000,
                    "requests_per_second": 10 / concurrent_time if concurrent_time > 0 else 0
                }
            
            # Test database performance
            try:
                database_url = self.config.get('DATABASE_URL', 'sqlite:///./customer_support.db')
                
                if 'postgresql' in database_url:
                    conn = await asyncpg.connect(database_url)
                    
                    # Simple query performance test
                    start_time = time.time()
                    for i in range(10):
                        await conn.fetchval('SELECT 1')
                    db_perf_time = time.time() - start_time
                    
                    await conn.close()
                    
                    performance_metrics["database_performance"] = {
                        "10_queries_time_seconds": db_perf_time,
                        "average_query_time_ms": (db_perf_time / 10) * 1000,
                        "status": "good" if db_perf_time < 1.0 else "slow"
                    }
                
            except Exception as e:
                performance_metrics["database_performance"] = {
                    "error": str(e),
                    "status": "error"
                }
            
            # Test memory usage over time
            memory_usage = psutil.virtual_memory()
            performance_metrics["memory_performance"] = {
                "usage_percent": memory_usage.percent,
                "available_gb": memory_usage.available / (1024**3),
                "status": "good" if memory_usage.percent < 70 else "slow" if memory_usage.percent < 85 else "critical"
            }
            
            # Test CPU performance
            cpu_percent = psutil.cpu_percent(interval=1)
            load_avg = os.getloadavg() if hasattr(os, 'getloadavg') else None
            
            performance_metrics["cpu_performance"] = {
                "usage_percent": cpu_percent,
                "load_average": load_avg,
                "status": "good" if cpu_percent < 70 else "slow" if cpu_percent < 85 else "critical"
            }
            
            # Overall performance assessment
            perf_issues = []
            slow_components = []
            
            if performance_metrics.get("api_response_time", {}).get("status") in ["slow", "critical"]:
                slow_components.append("API Response")
            
            if performance_metrics.get("database_performance", {}).get("status") in ["slow", "critical"]:
                slow_components.append("Database")
            
            if performance_metrics.get("memory_performance", {}).get("status") in ["slow", "critical"]:
                slow_components.append("Memory")
            
            if performance_metrics.get("cpu_performance", {}).get("status") in ["slow", "critical"]:
                slow_components.append("CPU")
            
            if slow_components:
                if len(slow_components) > 2:
                    status = "critical"
                else:
                    status = "warning"
                perf_issues.extend([f"Performance issues in {comp}" for comp in slow_components])
            else:
                status = "healthy"
            
            return {
                "status": status,
                "details": performance_metrics,
                "issues": perf_issues
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "details": traceback.format_exc()
            }
    
    def _generate_recommendations(self):
        """Generate recommendations based on health check results"""
        recommendations = []
        
        for component_name, result in self.results["components"].items():
            if result["status"] == "critical":
                recommendations.append(f"🚨 {component_name}: Immediate attention required")
            elif result["status"] == "warning":
                recommendations.append(f"⚠️ {component_name}: Monitor and address issues")
            elif result["status"] == "error":
                recommendations.append(f"❌ {component_name}: Check configuration and dependencies")
        
        # General recommendations
        if self.results["overall_status"] == "critical":
            recommendations.extend([
                "System is in critical state - immediate action required",
                "Consider rolling back recent changes",
                "Check system resources and restart failed services"
            ])
        elif self.results["overall_status"] == "warning":
            recommendations.extend([
                "System has warnings - review and address issues",
                "Monitor performance metrics closely",
                "Consider scaling resources if needed"
            ])
        
        self.results["recommendations"] = recommendations
    
    def print_summary(self):
        """Print a summary of health check results"""
        print("\n" + "="*80)
        print("CUSTOMER SUPPORT AI AGENT - SYSTEM HEALTH REPORT")
        print("="*80)
        print(f"Timestamp: {self.results['timestamp']}")
        print(f"Overall Status: {self.results['overall_status'].upper()}")
        print("\nComponent Status:")
        
        for component, result in self.results["components"].items():
            status_icon = {
                "healthy": "✅",
                "warning": "⚠️",
                "error": "❌",
                "critical": "🚨"
            }.get(result["status"], "❓")
            
            print(f"  {status_icon} {component}: {result['status'].upper()}")
        
        if self.results["recommendations"]:
            print("\nRecommendations:")
            for rec in self.results["recommendations"]:
                print(f"  • {rec}")
        
        print("\n" + "="*80)
    
    def save_report(self, filename: str = None):
        """Save detailed report to file"""
        if filename is None:
            filename = f"system_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)
        
        logger.info(f"Health report saved to {filename}")


async def main():
    """Main function"""
    # Create necessary directories
    os.makedirs('logs', exist_ok=True)
    
    # Initialize health checker
    checker = HealthChecker()
    
    # Run health checks
    results = await checker.check_all()
    
    # Print summary
    checker.print_summary()
    
    # Save detailed report
    checker.save_report()
    
    # Exit with appropriate code
    if results["overall_status"] in ["critical", "error"]:
        sys.exit(1)
    elif results["overall_status"] == "warning":
        sys.exit(2)
    else:
        sys.exit(0)


if __name__ == "__main__":
    asyncio.run(main())
