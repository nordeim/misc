#!/usr/bin/env python3
"""
WebSocket Implementation Validation Script

Quick validation to ensure all WebSocket components are properly implemented.
"""

import sys
import os

def validate_websocket_implementation():
    """Validate the WebSocket implementation."""
    
    print("="*60)
    print("WebSocket Implementation Validation")
    print("="*60)
    
    checks = []
    
    # Check 1: WebSocket file exists
    websocket_file = "/workspace/backend/app/api/websocket.py"
    if os.path.exists(websocket_file):
        checks.append(("✅ WebSocket file exists", True))
        
        # Check file size (should be substantial)
        size = os.path.getsize(websocket_file)
        if size > 50000:  # 50KB
            checks.append(("✅ WebSocket file is substantial", True))
        else:
            checks.append(("⚠️  WebSocket file seems small", False))
    else:
        checks.append(("❌ WebSocket file missing", False))
    
    # Check 2: Documentation exists
    doc_file = "/workspace/docs/websocket_implementation.md"
    if os.path.exists(doc_file):
        checks.append(("✅ Documentation exists", True))
    else:
        checks.append(("❌ Documentation missing", False))
    
    # Check 3: Test file exists
    test_file = "/workspace/backend/test_websocket_comprehensive.py"
    if os.path.exists(test_file):
        checks.append(("✅ Test suite exists", True))
    else:
        checks.append(("❌ Test suite missing", False))
    
    # Check 4: Client example exists
    client_file = "/workspace/backend/websocket_client_example.py"
    if os.path.exists(client_file):
        checks.append(("✅ Client example exists", True))
    else:
        checks.append(("❌ Client example missing", False))
    
    # Check 5: Summary file exists
    summary_file = "/workspace/WEBSOCKET_IMPLEMENTATION_COMPLETE.md"
    if os.path.exists(summary_file):
        checks.append(("✅ Implementation summary exists", True))
    else:
        checks.append(("❌ Implementation summary missing", False))
    
    # Check 6: Main integration
    main_file = "/workspace/backend/app/main.py"
    if os.path.exists(main_file):
        with open(main_file, 'r') as f:
            content = f.read()
            if "websocket_manager" in content:
                checks.append(("✅ WebSocket integration in main.py", True))
            else:
                checks.append(("⚠️  WebSocket integration not found", False))
    else:
        checks.append(("❌ main.py missing", False))
    
    # Print results
    print("\nValidation Results:")
    print("-" * 60)
    
    passed = 0
    total = len(checks)
    
    for check_msg, result in checks:
        print(f"{check_msg}")
        if result:
            passed += 1
    
    print("-" * 60)
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("\n🎉 All checks passed! WebSocket implementation is complete.")
        return 0
    else:
        print(f"\n⚠️  {total - passed} check(s) failed. Please review the implementation.")
        return 1

if __name__ == "__main__":
    sys.exit(validate_websocket_implementation())
