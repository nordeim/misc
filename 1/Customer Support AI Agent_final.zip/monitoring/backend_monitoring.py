"""
Monitoring and observability configuration for FastAPI backend.

This module provides:
- Health check endpoints
- Metrics export endpoints
- Structured logging configuration
- Custom metrics tracking
"""

import time
import logging
from contextlib import asynccontextmanager
from typing import Dict, Any
from functools import wraps
import psutil
import redis
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi import FastAPI, Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.cors import CORSMiddleware
import structlog

# Prometheus metrics
http_requests_total = Counter(
    'http_requests_total',
    'Total number of HTTP requests',
    ['method', 'endpoint', 'status_code', 'service']
)

http_request_duration_seconds = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint', 'service']
)

active_connections = Gauge(
    'websocket_active_connections',
    'Number of active WebSocket connections'
)

active_conversations_total = Gauge(
    'active_conversations_total',
    'Total number of active conversations'
)

conversations_total = Counter(
    'conversations_total',
    'Total number of conversations',
    ['status']
)

conversations_escalated_total = Counter(
    'conversations_escalated_total',
    'Total number of escalated conversations'
)

conversations_resolved_total = Counter(
    'conversations_resolved_total',
    'Total number of resolved conversations'
)

messages_total = Counter(
    'messages_total',
    'Total number of messages processed',
    ['direction']  # 'inbound' or 'outbound'
)

messages_failed_total = Counter(
    'messages_failed_total',
    'Total number of failed messages'
)

ai_agent_processing_time_seconds = Histogram(
    'ai_agent_processing_time_seconds',
    'AI agent processing time in seconds',
    ['operation']
)

rag_query_duration_seconds = Histogram(
    'rag_query_duration_seconds',
    'RAG query duration in seconds'
)

rag_queries_total = Counter(
    'rag_queries_total',
    'Total number of RAG queries'
)

rag_hits_total = Counter(
    'rag_hits_total',
    'Total number of successful RAG matches'
)

customer_satisfaction_score = Gauge(
    'customer_satisfaction_score',
    'Average customer satisfaction score',
    ['scale']  # e.g., '1-5'
)

user_feedback_score_1 = Counter(
    'user_feedback_score_1_total',
    'Total number of 1-star feedback ratings'
)

user_feedback_score_2 = Counter(
    'user_feedback_score_2_total',
    'Total number of 2-star feedback ratings'
)

user_feedback_score_3 = Counter(
    'user_feedback_score_3_total',
    'Total number of 3-star feedback ratings'
)

user_feedback_score_4 = Counter(
    'user_feedback_score_4_total',
    'Total number of 4-star feedback ratings'
)

user_feedback_score_5 = Counter(
    'user_feedback_score_5_total',
    'Total number of 5-star feedback ratings'
)

authentication_attempts_total = Counter(
    'authentication_attempts_total',
    'Total number of authentication attempts',
    ['result']  # 'success' or 'failure'
)

authentication_failures_total = Counter(
    'authentication_failures_total',
    'Total number of failed authentication attempts'
)

websocket_connections_dropped_total = Counter(
    'websocket_connections_dropped_total',
    'Total number of dropped WebSocket connections'
)

# System metrics
cpu_usage_percent = Gauge(
    'cpu_usage_percent',
    'CPU usage percentage'
)

memory_usage_percent = Gauge(
    'memory_usage_percent',
    'Memory usage percentage'
)

disk_usage_percent = Gauge(
    'disk_usage_percent',
    'Disk usage percentage'
)


class MetricsMiddleware(BaseHTTPMiddleware):
    """Middleware for collecting HTTP request metrics."""
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        response = await call_next(request)
        
        # Calculate duration
        duration = time.time() - start_time
        
        # Record metrics
        http_requests_total.labels(
            method=request.method,
            endpoint=request.url.path,
            status_code=response.status_code,
            service="fastapi-backend"
        ).inc()
        
        http_request_duration_seconds.labels(
            method=request.method,
            endpoint=request.url.path,
            service="fastapi-backend"
        ).observe(duration)
        
        return response


def setup_structured_logging():
    """Configure structured logging."""
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def track_agent_operation(operation: str):
    """Decorator to track AI agent operations."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = await func(*args, **kwargs)
                return result
            finally:
                duration = time.time() - start_time
                ai_agent_processing_time_seconds.labels(operation=operation).observe(duration)
        return wrapper
    return decorator


def track_rag_query(func):
    """Decorator to track RAG queries."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        rag_queries_total.inc()
        try:
            result = await func(*args, **kwargs)
            rag_hits_total.inc()  # Assume success for now
            return result
        except Exception:
            # RAG miss - don't increment hits counter
            raise
        finally:
            duration = time.time() - start_time
            rag_query_duration_seconds.observe(duration)
    return wrapper


def update_active_conversations(count: int):
    """Update the active conversations gauge."""
    active_conversations_total.set(count)


def record_conversation_escalation():
    """Record a conversation escalation."""
    conversations_escalated_total.inc()


def record_conversation_resolution():
    """Record a conversation resolution."""
    conversations_resolved_total.inc()


def record_conversation_status(status: str):
    """Record conversation by status."""
    conversations_total.labels(status=status).inc()


def record_user_feedback(score: int):
    """Record user feedback score."""
    if score == 1:
        user_feedback_score_1.inc()
    elif score == 2:
        user_feedback_score_2.inc()
    elif score == 3:
        user_feedback_score_3.inc()
    elif score == 4:
        user_feedback_score_4.inc()
    elif score == 5:
        user_feedback_score_5.inc()
    
    # Update average CSAT score
    # This would need to be implemented with proper averaging logic
    customer_satisfaction_score.labels(scale='1-5').set(score)


def update_system_metrics():
    """Update system metrics (call this periodically)."""
    cpu_usage_percent.set(psutil.cpu_percent())
    memory_usage_percent.set(psutil.virtual_memory().percent)
    disk_usage_percent.set(psutil.disk_usage('/').percent)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    setup_structured_logging()
    logger = structlog.get_logger()
    logger.info("Monitoring module initialized")
    
    # Start background task for system metrics
    import asyncio
    async def update_metrics():
        while True:
            update_system_metrics()
            await asyncio.sleep(60)  # Update every minute
    
    asyncio.create_task(update_metrics())
    
    yield
    
    # Shutdown
    logger.info("Monitoring module shutting down")


def create_monitoring_app() -> FastAPI:
    """Create a FastAPI app with monitoring endpoints."""
    app = FastAPI(
        title="Customer Support Agent Monitoring",
        description="Monitoring and observability for the Customer Support AI Agent",
        version="1.0.0",
        lifespan=lifespan
    )
    
    # Add middleware
    app.add_middleware(MetricsMiddleware)
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {
            "status": "healthy",
            "timestamp": time.time(),
            "uptime": time.time(),  # Should track actual uptime
            "version": "1.0.0"
        }
    
    @app.get("/health/ready")
    async def readiness_check():
        """Readiness check endpoint."""
        checks = {
            "database": "ok",  # Add actual DB check
            "redis": "ok",     # Add actual Redis check
            "chromadb": "ok"   # Add actual ChromaDB check
        }
        
        all_ready = all(status == "ok" for status in checks.values())
        
        return {
            "ready": all_ready,
            "checks": checks,
            "timestamp": time.time()
        }
    
    @app.get("/health/live")
    async def liveness_check():
        """Liveness check endpoint."""
        return {
            "alive": True,
            "timestamp": time.time()
        }
    
    @app.get("/metrics")
    async def metrics_endpoint():
        """Prometheus metrics endpoint."""
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
    
    @app.get("/metrics/app")
    async def app_metrics():
        """Application-specific metrics endpoint."""
        return {
            "active_conversations": active_conversations_total._value._value,
            "total_conversations": {
                "total": sum(counter._value._value for counter in conversations_total._metrics.values()),
                "escalated": conversations_escalated_total._value._value,
                "resolved": conversations_resolved_total._value._value
            },
            "messages": {
                "total": sum(counter._value._value for counter in messages_total._metrics.values()),
                "failed": messages_failed_total._value._value
            },
            "rag_queries": {
                "total": rag_queries_total._value._value,
                "hits": rag_hits_total._value._value
            },
            "customer_satisfaction": customer_satisfaction_score._value._value,
            "timestamp": time.time()
        }
    
    @app.get("/metrics/chromadb")
    async def chromadb_metrics():
        """ChromaDB-specific metrics endpoint."""
        # Placeholder for ChromaDB metrics
        return {
            "status": "ok",
            "collections": 0,  # Add actual collection count
            "documents": 0,    # Add actual document count
            "timestamp": time.time()
        }
    
    @app.get("/metrics/system")
    async def system_metrics():
        """System metrics endpoint."""
        return {
            "cpu_usage_percent": cpu_usage_percent._value._value,
            "memory_usage_percent": memory_usage_percent._value._value,
            "disk_usage_percent": disk_usage_percent._value._value,
            "timestamp": time.time()
        }
    
    return app


if __name__ == "__main__":
    # Run the monitoring app standalone
    import uvicorn
    app = create_monitoring_app()
    uvicorn.run(app, host="0.0.0.0", port=8000)