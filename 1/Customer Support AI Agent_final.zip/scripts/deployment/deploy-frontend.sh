#!/bin/bash

set -e

# Frontend deployment script
# Usage: ./deploy-frontend.sh [environment] [version]
# Example: ./deploy-frontend.sh production v1.0.0

ENVIRONMENT=${1:-staging}
VERSION=${2:-latest}
PROJECT_NAME="customer-support-ai-frontend"

echo "🚀 Deploying frontend to ${ENVIRONMENT} environment..."

# Configuration
REGISTRY="ghcr.io"
IMAGE_NAME="${REGISTRY}/${GITHUB_REPOSITORY}/${PROJECT_NAME}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Pre-deployment checks
check_requirements() {
    log_info "Checking requirements..."
    
    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    # Check if kubectl is installed (for Kubernetes deployments)
    if command -v kubectl &> /dev/null; then
        KUBECTL_AVAILABLE=true
        log_info "kubectl found"
    else
        KUBECTL_AVAILABLE=false
        log_warn "kubectl not found, using Docker deployment"
    fi
    
    # Check if required environment variables are set
    if [ -z "$REGISTRY_PASSWORD" ] && [ -z "$GITHUB_TOKEN" ]; then
        log_error "REGISTRY_PASSWORD or GITHUB_TOKEN must be set"
        exit 1
    fi
}

# Build Docker image
build_image() {
    log_info "Building Docker image..."
    
    docker build -t ${IMAGE_NAME}:${VERSION} \
                 -t ${IMAGE_NAME}:${ENVIRONMENT} \
                 -f Dockerfile \
                 .
    
    log_info "Docker image built successfully"
}

# Push image to registry
push_image() {
    log_info "Pushing image to registry..."
    
    # Login to registry
    if [ -n "$GITHUB_TOKEN" ]; then
        echo "$GITHUB_TOKEN" | docker login $REGISTRY -u $GITHUB_USERNAME --password-stdin
    else
        echo "$REGISTRY_PASSWORD" | docker login $REGISTRY -u $REGISTRY_USERNAME --password-stdin
    fi
    
    # Push images
    docker push ${IMAGE_NAME}:${VERSION}
    docker push ${IMAGE_NAME}:${ENVIRONMENT}
    
    log_info "Image pushed to registry"
}

# Deploy to Kubernetes
deploy_kubernetes() {
    log_info "Deploying to Kubernetes..."
    
    # Create namespace if it doesn't exist
    kubectl create namespace ${ENVIRONMENT} --dry-run=client -o yaml | kubectl apply -f -
    
    # Create image pull secret
    kubectl create secret docker-registry registry-secret \
        --docker-server=$REGISTRY \
        --docker-username=$REGISTRY_USERNAME \
        --docker-password=$REGISTRY_PASSWORD \
        --namespace=${ENVIRONMENT} \
        --dry-run=client -o yaml | kubectl apply -f -
    
    # Apply Kubernetes manifests
    envsubst < k8s/deployment.yaml | kubectl apply -n ${ENVIRONMENT} -f -
    envsubst < k8s/service.yaml | kubectl apply -n ${ENVIRONMENT} -f -
    envsubst < k8s/ingress.yaml | kubectl apply -n ${ENVIRONMENT} -f -
    
    # Wait for deployment
    kubectl rollout status deployment/${PROJECT_NAME} -n ${ENVIRONMENT}
    
    log_info "Kubernetes deployment completed"
}

# Deploy to Docker Swarm
deploy_swarm() {
    log_info "Deploying to Docker Swarm..."
    
    # Initialize swarm if not already done
    if ! docker info | grep -q "Swarm: active"; then
        docker swarm init
    fi
    
    # Deploy stack
    envsubst < docker-compose.swarm.yml | docker stack deploy -c - ${PROJECT_NAME}-${ENVIRONMENT}
    
    log_info "Docker Swarm deployment completed"
}

# Deploy to traditional server
deploy_server() {
    log_info "Deploying to server..."
    
    # Pull latest image
    if [ -n "$GITHUB_TOKEN" ]; then
        echo "$GITHUB_TOKEN" | docker login $REGISTRY -u $GITHUB_USERNAME --password-stdin
    else
        echo "$REGISTRY_PASSWORD" | docker login $REGISTRY -u $REGISTRY_USERNAME --password-stdin
    fi
    
    # Stop existing container
    docker stop ${PROJECT_NAME}-${ENVIRONMENT} || true
    docker rm ${PROJECT_NAME}-${ENVIRONMENT} || true
    
    # Run new container
    docker run -d \
        --name ${PROJECT_NAME}-${ENVIRONMENT} \
        -p 80:80 \
        -p 443:443 \
        --restart unless-stopped \
        ${IMAGE_NAME}:${VERSION}
    
    log_info "Server deployment completed"
}

# Health check
health_check() {
    log_info "Performing health check..."
    
    # Wait for service to be ready
    sleep 10
    
    # Check based on environment
    case $ENVIRONMENT in
        "staging")
            URL="https://staging.frontend.example.com/health"
            ;;
        "production")
            URL="https://frontend.example.com/health"
            ;;
        *)
            URL="http://localhost:80/health"
            ;;
    esac
    
    if curl -f -s $URL > /dev/null; then
        log_info "Health check passed ✅"
    else
        log_error "Health check failed ❌"
        exit 1
    fi
}

# Rollback deployment
rollback() {
    log_warn "Rolling back deployment..."
    
    if [ "$KUBECTL_AVAILABLE" = true ]; then
        kubectl rollout undo deployment/${PROJECT_NAME} -n ${ENVIRONMENT}
        kubectl rollout status deployment/${PROJECT_NAME} -n ${ENVIRONMENT}
    else
        # Rollback to previous version
        docker stop ${PROJECT_NAME}-${ENVIRONMENT}
        docker rm ${PROJECT_NAME}-${ENVIRONMENT}
        
        # Get previous version tag
        PREVIOUS_VERSION=$(docker images ${IMAGE_NAME} --format "{{.Tag}}" | grep -E "^[0-9]" | head -2 | tail -1)
        
        if [ -n "$PREVIOUS_VERSION" ]; then
            docker run -d \
                --name ${PROJECT_NAME}-${ENVIRONMENT} \
                -p 80:80 \
                -p 443:443 \
                --restart unless-stopped \
                ${IMAGE_NAME}:${PREVIOUS_VERSION}
        else
            log_error "No previous version found for rollback"
            exit 1
        fi
    fi
    
    log_info "Rollback completed"
}

# Post-deployment cleanup
cleanup() {
    log_info "Cleaning up old images..."
    
    # Remove old images (keep last 5)
    docker images ${IMAGE_NAME} --format "{{.Tag}}" | \
        grep -E "^[0-9]" | \
        sort -r | \
        tail -n +6 | \
        xargs -r docker rmi ${IMAGE_NAME}:
    
    log_info "Cleanup completed"
}

# Main deployment flow
main() {
    log_info "Starting deployment of ${PROJECT_NAME} to ${ENVIRONMENT}"
    
    # Environment variables substitution
    export VERSION=$VERSION
    export ENVIRONMENT=$ENVIRONMENT
    export IMAGE_NAME=$IMAGE_NAME
    
    # Execute deployment steps
    check_requirements
    
    if [ "$SKIP_BUILD" != "true" ]; then
        build_image
        push_image
    fi
    
    # Deploy based on target platform
    if [ "$DEPLOY_TARGET" = "kubernetes" ] || [ "$KUBECTL_AVAILABLE" = true ]; then
        deploy_kubernetes
    elif [ "$DEPLOY_TARGET" = "swarm" ]; then
        deploy_swarm
    else
        deploy_server
    fi
    
    health_check
    cleanup
    
    log_info "🎉 Deployment completed successfully!"
    log_info "Frontend is now available at:"
    
    case $ENVIRONMENT in
        "staging")
            echo "  https://staging.frontend.example.com"
            ;;
        "production")
            echo "  https://frontend.example.com"
            ;;
        *)
            echo "  http://localhost"
            ;;
    esac
}

# Handle script arguments
case "${1:-}" in
    "rollback")
        rollback
        ;;
    "health")
        health_check
        ;;
    *)
        main
        ;;
esac