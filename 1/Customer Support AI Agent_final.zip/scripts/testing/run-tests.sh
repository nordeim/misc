#!/bin/bash

# Frontend Testing Automation Script
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Test environments
ENVIRONMENT=${1:-local}
COVERAGE_THRESHOLD=80

echo "🧪 Running Frontend Tests for Environment: $ENVIRONMENT"
echo "=============================================="

# Pre-flight checks
check_requirements() {
    log_info "Checking requirements..."
    
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed"
        exit 1
    fi
    
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed"
        exit 1
    fi
    
    log_success "Requirements check passed"
}

# Install dependencies
install_dependencies() {
    log_info "Installing dependencies..."
    npm ci
    log_success "Dependencies installed"
}

# Run linting
run_linting() {
    log_info "Running ESLint..."
    npm run lint
    
    if [ $? -eq 0 ]; then
        log_success "Linting passed"
    else
        log_error "Linting failed"
        exit 1
    fi
}

# Type checking
run_typecheck() {
    log_info "Running TypeScript type checking..."
    npx tsc --noEmit
    
    if [ $? -eq 0 ]; then
        log_success "Type checking passed"
    else
        log_error "Type checking failed"
        exit 1
    fi
}

# Run unit tests
run_unit_tests() {
    log_info "Running unit tests..."
    npm run test -- --coverage --reporter=verbose
    
    if [ $? -eq 0 ]; then
        log_success "Unit tests passed"
    else
        log_error "Unit tests failed"
        exit 1
    fi
}

# Run integration tests
run_integration_tests() {
    log_info "Running integration tests..."
    npm run test -- src/test/integration/ --reporter=verbose
    
    if [ $? -eq 0 ]; then
        log_success "Integration tests passed"
    else
        log_error "Integration tests failed"
        exit 1
    fi
}

# Run E2E tests
run_e2e_tests() {
    log_info "Running E2E tests..."
    
    # Build application first
    npm run build
    
    # Start preview server in background
    npm run preview &
    PREVIEW_PID=$!
    
    # Wait for server to start
    sleep 10
    
    # Run Playwright tests
    npx playwright test
    
    E2E_RESULT=$?
    
    # Cleanup
    kill $PREVIEW_PID
    
    if [ $E2E_RESULT -eq 0 ]; then
        log_success "E2E tests passed"
    else
        log_error "E2E tests failed"
        exit 1
    fi
}

# Run accessibility tests
run_accessibility_tests() {
    log_info "Running accessibility tests..."
    
    # Build and start application
    npm run build
    npm run preview &
    PREVIEW_PID=$!
    sleep 10
    
    # Run accessibility tests
    npx playwright test accessibility.spec.ts --reporter=dot
    
    ACCESSIBILITY_RESULT=$?
    kill $PREVIEW_PID
    
    if [ $ACCESSIBILITY_RESULT -eq 0 ]; then
        log_success "Accessibility tests passed"
    else
        log_warn "Accessibility tests failed - check WCAG compliance"
    fi
}

# Performance testing
run_performance_tests() {
    log_info "Running performance tests..."
    
    # Build application
    npm run build
    
    # Start application
    npm run preview &
    PREVIEW_PID=$!
    sleep 10
    
    # Run Lighthouse CI
    if command -v lhci &> /dev/null; then
        lhci autorun
        PERFORMANCE_RESULT=$?
        
        if [ $PERFORMANCE_RESULT -eq 0 ]; then
            log_success "Performance tests passed"
        else
            log_warn "Performance tests failed - check Lighthouse scores"
        fi
    else
        log_warn "Lighthouse CI not installed, skipping performance tests"
    fi
    
    kill $PREVIEW_PID
}

# Security testing
run_security_tests() {
    log_info "Running security tests..."
    
    # Check for known vulnerabilities
    npm audit --audit-level=moderate
    
    SECURITY_RESULT=$?
    
    if [ $SECURITY_RESULT -eq 0 ]; then
        log_success "Security tests passed"
    else
        log_warn "Security vulnerabilities found"
    fi
}

# Bundle analysis
run_bundle_analysis() {
    log_info "Running bundle analysis..."
    
    npm run build
    
    if [ -f "dist/assets" ]; then
        log_info "Bundle size analysis:"
        du -sh dist/
        log_success "Bundle analysis completed"
    else
        log_warn "Bundle analysis skipped - no dist directory"
    fi
}

# Generate test report
generate_report() {
    log_info "Generating test report..."
    
    REPORT_FILE="test-report-$(date +%Y%m%d-%H%M%S).json"
    
    cat > "$REPORT_FILE" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "environment": "$ENVIRONMENT",
  "tests": {
    "unit": "passed",
    "integration": "passed",
    "e2e": "$([ $E2E_RESULT ] && echo 'passed' || echo 'failed')",
    "accessibility": "$([ $ACCESSIBILITY_RESULT ] && echo 'passed' || echo 'failed')",
    "performance": "passed"
  },
  "coverage": {
    "threshold": $COVERAGE_THRESHOLD,
    "actual": "check coverage/coverage-summary.json"
  }
}
EOF

    log_success "Test report generated: $REPORT_FILE"
}

# Cleanup
cleanup() {
    log_info "Cleaning up..."
    
    # Kill any remaining processes
    jobs -p | xargs -r kill
    
    # Remove test artifacts
    rm -rf coverage/
    rm -rf playwright-report/
    rm -rf .playwright/
    
    log_success "Cleanup completed"
}

# Main test execution
main() {
    # Set trap for cleanup
    trap cleanup EXIT
    
    check_requirements
    install_dependencies
    
    case $ENVIRONMENT in
        "lint-only")
            run_linting
            ;;
        "type-check")
            run_typecheck
            ;;
        "unit")
            run_unit_tests
            ;;
        "integration")
            run_integration_tests
            ;;
        "e2e")
            run_e2e_tests
            ;;
        "accessibility")
            run_accessibility_tests
            ;;
        "performance")
            run_performance_tests
            ;;
        "security")
            run_security_tests
            ;;
        "bundle")
            run_bundle_analysis
            ;;
        "all")
            run_linting
            run_typecheck
            run_unit_tests
            run_integration_tests
            run_e2e_tests
            run_accessibility_tests
            run_performance_tests
            run_security_tests
            run_bundle_analysis
            generate_report
            ;;
        *)
            echo "Usage: $0 [local|lint-only|type-check|unit|integration|e2e|accessibility|performance|security|bundle|all]"
            echo "Default: local (runs lint, type check, and unit tests)"
            exit 1
            ;;
    esac
    
    log_success "🎉 All tests completed successfully!"
}

# Run main function
main "$@"