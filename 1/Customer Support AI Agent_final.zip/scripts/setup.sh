#!/bin/bash

# Customer Support AI Agent - Complete Setup Script
# This script sets up the entire development environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}=== $1 ===${NC}\n"
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    print_status "Docker: $(docker --version)"
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        print_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    print_status "Docker Compose: $(docker-compose --version)"
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed. Please install Python 3.11+ first."
        exit 1
    fi
    print_status "Python: $(python3 --version)"
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        print_warning "Node.js is not installed. Please install Node.js 18+ first."
    else
        print_status "Node.js: $(node --version)"
    fi
    
    # Check available disk space (minimum 5GB)
    available_space=$(df . | awk 'NR==2 {print $4}')
    if [ $available_space -lt 5242880 ]; then  # 5GB in KB
        print_warning "Less than 5GB disk space available. Consider freeing up space."
    fi
    
    print_status "Prerequisites check completed"
}

# Create environment file
setup_environment() {
    print_header "Setting Up Environment Variables"
    
    if [ ! -f ".env" ]; then
        print_status "Creating .env file from template"
        if [ -f ".env.example" ]; then
            cp .env.example .env
            print_status "Environment file created from example"
        else
            print_status "Creating default .env file"
            cat > .env << 'EOF'
# Environment Configuration
DEBUG=true
ENVIRONMENT=development
LOG_LEVEL=INFO

# Database Configuration
DATABASE_URL=sqlite:///./customer_support.db

# Redis Configuration (optional for development)
REDIS_URL=redis://localhost:6379

# ChromaDB Configuration
CHROMA_PERSIST_DIRECTORY=./chroma_db

# OpenAI Configuration
OPENAI_API_KEY=your-openai-api-key-here
AGENT_MODEL=gpt-4o-mini
AGENT_TEMPERATURE=0.7

# Frontend Configuration
FRONTEND_URL=http://localhost:3000

# Security (development only - change in production)
SECRET_KEY=dev-secret-key-change-in-production
JWT_SECRET_KEY=dev-jwt-secret-change-in-production

# CORS Configuration
CORS_ORIGINS=http://localhost:3000,http://localhost:5173

# File Upload Limits
MAX_FILE_SIZE=10485760
ALLOWED_FILE_TYPES=pdf,doc,docx,txt,jpg,jpeg,png,gif

# Development Settings
ENABLE_CACHING=true
CACHE_TTL=3600
ENABLE_RATE_LIMITING=false

# Monitoring
ENABLE_TELEMETRY=false
ENABLE_METRICS=true
EOF
        fi
    else
        print_status ".env file already exists"
    fi
    
    print_warning "Please update the .env file with your API keys and configuration"
}

# Create necessary directories
setup_directories() {
    print_header "Creating Directory Structure"
    
    directories=(
        "data/chromadb"
        "data/uploads"
        "data/backups"
        "logs"
        "nginx/ssl"
        "monitoring/grafana/dashboards"
        "monitoring/grafana/datasources"
        "scripts/backups"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_status "Created directory: $dir"
        else
            print_status "Directory already exists: $dir"
        fi
    done
}

# Build Docker images
build_images() {
    print_header "Building Docker Images"
    
    print_status "Building backend image..."
    docker-compose build backend
    
    print_status "Building frontend image..."
    docker-compose build frontend
    
    print_status "Building monitoring services..."
    docker-compose -f docker-compose.yml -f monitoring/docker-compose.monitoring.yml build
    
    print_status "Docker images built successfully"
}

# Initialize database
init_database() {
    print_header "Initializing Database"
    
    print_status "Starting database service..."
    docker-compose up -d postgres
    
    # Wait for database to be ready
    print_status "Waiting for database to be ready..."
    sleep 10
    
    print_status "Running database migrations..."
    docker-compose exec -T backend alembic upgrade head
    
    print_status "Database initialized successfully"
}

# Setup development tools
setup_dev_tools() {
    print_header "Setting Up Development Tools"
    
    # Backend setup
    if [ -d "backend" ]; then
        print_status "Setting up backend virtual environment..."
        cd backend
        if [ ! -d "venv" ]; then
            python3 -m venv venv
        fi
        source venv/bin/activate
        pip install --upgrade pip
        pip install -r requirements.txt
        pip install -r requirements-dev.txt 2>/dev/null || print_warning "Development requirements not found"
        cd ..
        print_status "Backend setup completed"
    fi
    
    # Frontend setup
    if [ -d "frontend" ]; then
        print_status "Setting up frontend dependencies..."
        cd frontend
        if [ -f "package.json" ]; then
            npm install
            print_status "Frontend dependencies installed"
        else
            print_warning "Frontend package.json not found"
        fi
        cd ..
    fi
    
    # Download AI models
    print_status "Setting up AI models..."
    if [ -d "backend" ]; then
        docker-compose exec backend python -c "
import sys
sys.path.append('/app')
from app.services.embedding_service import EmbeddingService
import asyncio

async def download_models():
    service = EmbeddingService()
    await service.download_models()
    print('Models downloaded successfully')

asyncio.run(download_models())
" 2>/dev/null || print_warning "Could not download models. This will happen automatically on first use."
    fi
}

# Setup monitoring
setup_monitoring() {
    print_header "Setting Up Monitoring"
    
    # Create Grafana provisioning directories
    mkdir -p monitoring/grafana/provisioning/dashboards
    mkdir -p monitoring/grafana/provisioning/datasources
    
    # Create datasource configuration
    cat > monitoring/grafana/provisioning/datasources/prometheus.yml << 'EOF'
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
EOF
    
    # Create dashboard provider
    cat > monitoring/grafana/provisioning/dashboards/dashboard-provider.yml << 'EOF'
apiVersion: 1

providers:
  - name: 'default'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    editable: true
    options:
      path: /var/lib/grafana/dashboards
EOF
    
    print_status "Monitoring configuration created"
}

# Setup git hooks (if git repository)
setup_git_hooks() {
    if [ -d ".git" ]; then
        print_header "Setting Up Git Hooks"
        
        # Pre-commit hook
        cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
# Run tests before commit

echo "Running pre-commit checks..."

# Run linting
if [ -f "backend/requirements-dev.txt" ]; then
    echo "Running Python linting..."
    cd backend
    source venv/bin/activate
    flake8 app/ || { echo "Linting failed"; exit 1; }
    black --check app/ || { echo "Code formatting check failed"; exit 1; }
    cd ..
fi

# Run tests
echo "Running tests..."
./scripts/test.sh || { echo "Tests failed"; exit 1; }

echo "Pre-commit checks passed!"
EOF
        
        chmod +x .git/hooks/pre-commit
        print_status "Git hooks setup completed"
    fi
}

# Create startup scripts
create_scripts() {
    print_header "Creating Utility Scripts"
    
    # Development startup script
    cat > scripts/start-dev.sh << 'EOF'
#!/bin/bash
# Start development environment

set -e

echo "🚀 Starting Customer Support AI Agent (Development)..."

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "❌ .env file not found. Please run ./scripts/setup.sh first."
    exit 1
fi

# Start all services
docker-compose -f docker-compose.yml up -d

# Wait for services
echo "⏳ Waiting for services to start..."
sleep 30

# Check health
echo "🔍 Checking service health..."
curl -s http://localhost:8000/health > /dev/null && echo "✅ Backend: OK" || echo "❌ Backend: FAILED"
curl -s http://localhost:3000 > /dev/null && echo "✅ Frontend: OK" || echo "❌ Frontend: FAILED"

echo ""
echo "🎉 Development environment started!"
echo ""
echo "Services:"
echo "  Frontend: http://localhost:3000"
echo "  Backend API: http://localhost:8000"
echo "  API Documentation: http://localhost:8000/docs"
echo "  Prometheus: http://localhost:9090"
echo "  Grafana: http://localhost:3001 (admin/admin)"
echo ""
echo "To view logs: docker-compose logs -f"
echo "To stop services: docker-compose down"
EOF
    
    chmod +x scripts/start-dev.sh
    
    # Database management script
    cat > scripts/db-manage.sh << 'EOF'
#!/bin/bash
# Database management script

case "$1" in
    "backup")
        echo "Creating database backup..."
        BACKUP_FILE="backup_$(date +%Y%m%d_%H%M%S).sql"
        docker-compose exec -T postgres pg_dump -U postgres customer_support > "scripts/backups/$BACKUP_FILE"
        echo "Backup created: scripts/backups/$BACKUP_FILE"
        ;;
    "restore")
        if [ -z "$2" ]; then
            echo "Usage: $0 restore <backup_file>"
            exit 1
        fi
        echo "Restoring database from $2..."
        docker-compose exec -T backend alembic downgrade base
        docker-compose exec -T postgres psql -U postgres customer_support < "$2"
        docker-compose exec -T backend alembic upgrade head
        echo "Database restored successfully"
        ;;
    "reset")
        echo "⚠️ This will delete all data! Continue? (y/N)"
        read -r response
        if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
            docker-compose down -v
            docker-compose up -d postgres
            sleep 10
            docker-compose exec -T backend alembic upgrade head
            echo "Database reset completed"
        else
            echo "Operation cancelled"
        fi
        ;;
    *)
        echo "Usage: $0 {backup|restore|reset}"
        echo ""
        echo "Commands:"
        echo "  backup    - Create database backup"
        echo "  restore   - Restore database from backup"
        echo "  reset     - Reset database (WARNING: deletes all data)"
        exit 1
        ;;
esac
EOF
    
    chmod +x scripts/db-manage.sh
    
    print_status "Utility scripts created"
}

# Main setup function
main() {
    print_header "Customer Support AI Agent - Complete Setup"
    echo "This script will set up your entire development environment."
    echo ""
    
    # Confirm before proceeding
    read -p "Do you want to continue? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Setup cancelled."
        exit 0
    fi
    
    # Run setup steps
    check_prerequisites
    setup_environment
    setup_directories
    build_images
    init_database
    setup_dev_tools
    setup_monitoring
    setup_git_hooks
    create_scripts
    
    print_header "Setup Complete! 🎉"
    echo ""
    echo "Your Customer Support AI Agent is now ready for development!"
    echo ""
    echo "Next steps:"
    echo "1. Update your .env file with API keys and configuration"
    echo "2. Run: ./scripts/start-dev.sh"
    echo "3. Open http://localhost:3000 in your browser"
    echo ""
    echo "Useful commands:"
    echo "  ./scripts/start-dev.sh    - Start development environment"
    echo "  ./scripts/db-manage.sh    - Database management"
    echo "  ./scripts/test.sh         - Run tests"
    echo "  docker-compose logs -f    - View logs"
    echo "  docker-compose down       - Stop services"
    echo ""
}

# Run main function
main "$@"
