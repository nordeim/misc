#!/bin/bash

# Customer Support AI Agent - Development Environment Startup
# This script starts all services in development mode

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}=== $1 ===${NC}\n"
}

# Check if setup was completed
check_setup() {
    print_header "Checking Setup"
    
    if [ ! -f ".env" ]; then
        print_error ".env file not found. Please run ./scripts/setup.sh first."
        exit 1
    fi
    
    if [ ! -f "docker-compose.yml" ]; then
        print_error "docker-compose.yml not found. Are you in the project root directory?"
        exit 1
    fi
    
    print_status "Setup check passed"
}

# Start services
start_services() {
    print_header "Starting Services"
    
    # Create network if it doesn't exist
    if ! docker network ls | grep -q customer-support-net; then
        print_status "Creating Docker network..."
        docker network create customer-support-net
    fi
    
    # Start services
    print_status "Starting Docker Compose services..."
    docker-compose up -d
    
    print_status "Services started successfully"
}

# Wait for services to be ready
wait_for_services() {
    print_header "Waiting for Services"
    
    print_status "Waiting for backend to be ready..."
    timeout=60
    while [ $timeout -gt 0 ]; do
        if curl -s http://localhost:8000/health > /dev/null 2>&1; then
            print_status "Backend is ready!"
            break
        fi
        echo -n "."
        sleep 2
        timeout=$((timeout - 2))
    done
    
    if [ $timeout -le 0 ]; then
        print_error "Backend failed to start within timeout"
        print_error "Check logs with: docker-compose logs backend"
        exit 1
    fi
    
    print_status "Waiting for database to be ready..."
    docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1
    print_status "Database is ready!"
    
    # Optional: Wait for Redis if it's enabled
    if docker-compose ps redis | grep -q "Up"; then
        print_status "Waiting for Redis to be ready..."
        timeout=30
        while [ $timeout -gt 0 ]; do
            if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
                print_status "Redis is ready!"
                break
            fi
            echo -n "."
            sleep 1
            timeout=$((timeout - 1))
        done
    fi
}

# Health check
health_check() {
    print_header "Health Check"
    
    # Backend health
    if curl -s http://localhost:8000/health > /dev/null; then
        print_status "✅ Backend: Healthy"
    else
        print_error "❌ Backend: Unhealthy"
        return 1
    fi
    
    # Frontend health
    if curl -s http://localhost:3000 > /dev/null; then
        print_status "✅ Frontend: Healthy"
    else
        print_warning "⚠️ Frontend: Unhealthy (this is normal during development)"
    fi
    
    # Database health
    if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
        print_status "✅ Database: Healthy"
    else
        print_error "❌ Database: Unhealthy"
        return 1
    fi
    
    # Redis health (if running)
    if docker-compose ps redis | grep -q "Up"; then
        if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
            print_status "✅ Redis: Healthy"
        else
            print_warning "⚠️ Redis: Unhealthy"
        fi
    fi
    
    # ChromaDB health
    print_status "Checking ChromaDB..."
    docker-compose exec -T backend python -c "
import sys
try:
    import chromadb
    client = chromadb.Client()
    print('✅ ChromaDB: Healthy')
except Exception as e:
    print(f'❌ ChromaDB: {e}')
    sys.exit(1)
" > /dev/null 2>&1
}

# Display service information
show_info() {
    print_header "Service Information"
    
    echo "🌐 Services running:"
    echo ""
    echo "📱 Frontend (React):"
    echo "   URL: http://localhost:3000"
    echo "   Description: Main user interface"
    echo ""
    echo "🔧 Backend (FastAPI):"
    echo "   URL: http://localhost:8000"
    echo "   Docs: http://localhost:8000/docs"
    echo "   Description: API server"
    echo ""
    echo "📊 Monitoring:"
    echo "   Prometheus: http://localhost:9090"
    echo "   Grafana: http://localhost:3001 (admin/admin)"
    echo "   Description: Metrics and monitoring"
    echo ""
    echo "🗄️ Databases:"
    echo "   PostgreSQL: localhost:5432"
    echo "   Redis: localhost:6379 (if enabled)"
    echo "   ChromaDB: http://localhost:8001 (if enabled)"
    echo ""
}

# Show usage information
show_usage() {
    print_header "Usage Information"
    
    echo "🔍 Monitoring commands:"
    echo "  docker-compose logs -f           # Follow all logs"
    echo "  docker-compose logs -f backend   # Follow backend logs"
    echo "  docker-compose ps                # Show service status"
    echo "  docker-compose stats             # Show resource usage"
    echo ""
    echo "🛠️ Management commands:"
    echo "  docker-compose restart           # Restart all services"
    echo "  docker-compose restart backend   # Restart backend only"
    echo "  docker-compose down              # Stop all services"
    echo "  ./scripts/db-manage.sh backup    # Backup database"
    echo ""
    echo "🧪 Development commands:"
    echo "  ./scripts/test.sh                # Run tests"
    echo "  docker-compose exec backend bash # Access backend container"
    echo "  docker-compose exec postgres psql -U postgres # Access database"
    echo ""
    echo "🔗 API Testing:"
    echo "  curl http://localhost:8000/health"
    echo "  curl http://localhost:8000/docs"
    echo ""
}

# Handle cleanup on exit
cleanup() {
    if [ $? -ne 0 ]; then
        print_error "Something went wrong. Check the logs:"
        echo "  docker-compose logs backend"
    fi
}

# Main function
main() {
    # Set trap for cleanup
    trap cleanup EXIT
    
    print_header "Customer Support AI Agent - Development Startup"
    
    check_setup
    start_services
    wait_for_services
    
    # Run health check
    if health_check; then
        print_header "🎉 All systems healthy!"
        show_info
        show_usage
    else
        print_error "Some services are unhealthy. Check the logs:"
        echo "  docker-compose logs backend"
        exit 1
    fi
    
    print_status "Development environment is ready!"
    print_status "You can now access the application at http://localhost:3000"
}

# Handle command line arguments
case "${1:-}" in
    "--check"|"-c")
        print_header "Service Health Check"
        check_setup
        health_check
        ;;
    "--logs"|"-l")
        print_header "Showing Logs"
        if [ -n "${2:-}" ]; then
            docker-compose logs -f "${2}"
        else
            docker-compose logs -f
        fi
        ;;
    "--status"|"-s")
        print_header "Service Status"
        docker-compose ps
        ;;
    "--stop")
        print_header "Stopping Services"
        docker-compose down
        print_status "Services stopped"
        ;;
    "--help"|"-h")
        echo "Usage: $0 [OPTIONS]"
        echo ""
        echo "Options:"
        echo "  (no args)    Start all services and show information"
        echo "  --check      Check service health"
        echo "  --logs       Show logs (optionally specify service)"
        echo "  --status     Show service status"
        echo "  --stop       Stop all services"
        echo "  --help       Show this help message"
        ;;
    *)
        main
        ;;
esac
