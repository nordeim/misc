"""
Message Bubble Component.

Displays individual chat messages with proper formatting and styling.
"""

import React from 'react';
import { format } from 'date-fns';
import { UserIcon, SparklesIcon } from '@heroicons/react/24/solid';
import { PaperClipIcon } from '@heroicons/react/24/outline';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const isAssistant = message.role === 'assistant';

  const formatTimestamp = (timestamp: string) => {
    return format(new Date(timestamp), 'MMM dd, yyyy HH:mm');
  };

  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return '';
    if (confidence >= 0.8) return 'text-green-600';
    if (confidence >= 0.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex max-w-xs lg:max-w-md ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start space-x-2`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
          isUser ? 'bg-blue-500' : 'bg-purple-500'
        }`}>
          {isUser ? (
            <UserIcon className="w-5 h-5 text-white" />
          ) : (
            <SparklesIcon className="w-5 h-5 text-white" />
          )}
        </div>

        {/* Message Content */}
        <div className={`rounded-lg px-4 py-2 ${
          isUser 
            ? 'bg-blue-500 text-white' 
            : 'bg-gray-100 text-gray-900'
        }`}>
          {/* Message Text */}
          <p className="text-sm whitespace-pre-wrap break-words">
            {message.content}
          </p>

          {/* Attachments (User) */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="mt-2 space-y-1">
              {message.attachments.map((attachment, index) => (
                <div
                  key={index}
                  className={`flex items-center space-x-2 text-xs ${
                    isUser ? 'text-blue-100' : 'text-gray-500'
                  }`}
                >
                  <PaperClipIcon className="w-3 h-3" />
                  <span>{attachment.name}</span>
                  <span>({(attachment.size / 1024).toFixed(1)} KB)</span>
                </div>
              ))}
            </div>
          )}

          {/* Attachments Processed (Assistant) */}
          {message.attachments_processed && message.attachments_processed.length > 0 && (
            <div className="mt-2 p-2 bg-gray-50 rounded border">
              <p className="text-xs text-gray-600 mb-1">Processed attachments:</p>
              {message.attachments_processed.map((attachment, index) => (
                <div key={index} className="text-xs text-gray-700">
                  • {attachment}
                </div>
              ))}
            </div>
          )}

          {/* Sources (Assistant) */}
          {message.sources && message.sources.length > 0 && (
            <div className="mt-2 p-2 bg-blue-50 rounded border">
              <p className="text-xs text-blue-700 mb-1 font-medium">Sources:</p>
              {message.sources.slice(0, 3).map((source, index) => (
                <div key={index} className="text-xs text-blue-600 mb-1">
                  <div className="font-medium">
                    {source.metadata?.title || `Source ${index + 1}`}
                  </div>
                  {source.relevance_score && (
                    <div className="text-xs">
                      Relevance: {(source.relevance_score * 100).toFixed(1)}%
                    </div>
                  )}
                </div>
              ))}
              {message.sources.length > 3 && (
                <div className="text-xs text-blue-600">
                  +{message.sources.length - 3} more sources
                </div>
              )}
            </div>
          )}

          {/* Metadata (Assistant) */}
          {isAssistant && (
            <div className="mt-2 flex items-center justify-between text-xs">
              <span className="text-gray-500">
                {formatTimestamp(message.timestamp)}
              </span>
              {message.confidence && (
                <span className={`font-medium ${getConfidenceColor(message.confidence)}`}>
                  {message.confidence > 0 ? `${(message.confidence * 100).toFixed(0)}% confidence` : 'Low confidence'}
                </span>
              )}
            </div>
          )}

          {/* User timestamp */}
          {isUser && (
            <div className="mt-1 text-xs text-blue-100 text-right">
              {formatTimestamp(message.timestamp)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;