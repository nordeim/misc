/**
 * SourcesPanel Component

Displays source references and citations for AI responses.
Shows relevance scores, metadata, and allows expanding/collapsing details.
 */

import React, { useState } from 'react';
import { ChevronDownIcon, ChevronRightIcon, DocumentTextIcon, ExternalLinkIcon, StarIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';

interface Source {
  content: string;
  metadata: Record<string, any>;
  relevance_score?: number;
}

interface SourcesPanelProps {
  sources: Source[];
  confidence?: number;
  isVisible: boolean;
  onToggle: () => void;
  className?: string;
}

const SourcesPanel: React.FC<SourcesPanelProps> = ({
  sources,
  confidence,
  isVisible,
  onToggle,
  className = '',
}) => {
  const [expandedSources, setExpandedSources] = useState<Set<number>>(new Set());

  // Toggle source expansion
  const toggleSourceExpansion = (index: number) => {
    setExpandedSources(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  // Format relevance score
  const formatRelevanceScore = (score?: number) => {
    if (score === undefined) return null;
    return Math.round(score * 100);
  };

  // Get confidence level
  const getConfidenceLevel = (confidence?: number) => {
    if (confidence === undefined) return { level: 'unknown', color: 'gray' };
    if (confidence >= 0.8) return { level: 'high', color: 'green' };
    if (confidence >= 0.6) return { level: 'medium', color: 'yellow' };
    return { level: 'low', color: 'red' };
  };

  // Render confidence indicator
  const renderConfidenceIndicator = () => {
    const { level, color } = getConfidenceLevel(confidence);
    
    if (level === 'unknown') return null;

    return (
      <div className="flex items-center space-x-2 mb-3">
        <span className="text-sm font-medium text-gray-700">Confidence:</span>
        <div className="flex items-center space-x-1">
          <div className={`w-3 h-3 rounded-full bg-${color}-500`}></div>
          <span className={`text-sm text-${color}-600 font-medium`}>
            {Math.round((confidence || 0) * 100)}%
          </span>
          <span className="text-xs text-gray-500 capitalize">({level})</span>
        </div>
      </div>
    );
  };

  // Render source metadata
  const renderSourceMetadata = (metadata: Record<string, any>, index: number) => {
    const entries = Object.entries(metadata).filter(([key]) => 
      !['content', 'relevance_score'].includes(key)
    );

    if (entries.length === 0) return null;

    return (
      <div className="mt-2 pt-2 border-t border-gray-200">
        <div className="grid grid-cols-1 gap-1 text-xs text-gray-600">
          {entries.map(([key, value]) => (
            <div key={key} className="flex justify-between">
              <span className="font-medium capitalize">{key.replace(/_/g, ' ')}:</span>
              <span className="ml-2 truncate max-w-xs" title={String(value)}>
                {String(value)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Truncate content for preview
  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  if (sources.length === 0 && confidence === undefined) {
    return null;
  }

  return (
    <div className={`border border-gray-200 rounded-lg ${className}`}>
      {/* Header */}
      <button
        onClick={onToggle}
        className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors rounded-t-lg"
      >
        <div className="flex items-center space-x-2">
          <DocumentTextIcon className="w-5 h-5 text-gray-600" />
          <span className="font-medium text-gray-900">
            Sources ({sources.length})
          </span>
        </div>
        <div className="flex items-center space-x-2">
          {confidence !== undefined && (
            <div className="flex items-center space-x-1">
              <StarIcon className="w-4 h-4 text-yellow-500" />
              <span className="text-sm text-gray-600">
                {Math.round(confidence * 100)}%
              </span>
            </div>
          )}
          {isVisible ? (
            <ChevronDownIcon className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronRightIcon className="w-5 h-5 text-gray-600" />
          )}
        </div>
      </button>

      {/* Content */}
      {isVisible && (
        <div className="p-4">
          {renderConfidenceIndicator()}

          {sources.length === 0 ? (
            <p className="text-gray-500 text-sm italic">No sources available for this response.</p>
          ) : (
            <div className="space-y-3">
              {sources.map((source, index) => {
                const isExpanded = expandedSources.has(index);
                const relevanceScore = formatRelevanceScore(source.relevance_score);
                const hasLongContent = source.content.length > 150;

                return (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg overflow-hidden"
                  >
                    {/* Source header */}
                    <div className="px-3 py-2 bg-gray-50 border-b">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-gray-900">
                            Source {index + 1}
                          </span>
                          {relevanceScore !== null && (
                            <div className="flex items-center space-x-1">
                              <StarIconSolid className="w-4 h-4 text-yellow-500" />
                              <span className="text-sm text-gray-600">
                                {relevanceScore}%
                              </span>
                            </div>
                          )}
                        </div>
                        
                        <button
                          onClick={() => toggleSourceExpansion(index)}
                          className="text-gray-500 hover:text-gray-700 transition-colors"
                        >
                          {isExpanded ? (
                            <ChevronDownIcon className="w-4 h-4" />
                          ) : (
                            <ChevronRightIcon className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Source content */}
                    <div className="p-3">
                      <div className="text-sm text-gray-700">
                        {isExpanded || !hasLongContent ? (
                          <p className="whitespace-pre-wrap">{source.content}</p>
                        ) : (
                          <p className="whitespace-pre-wrap">
                            {truncateContent(source.content)}
                            <button
                              onClick={() => toggleSourceExpansion(index)}
                              className="ml-2 text-blue-600 hover:text-blue-700 font-medium"
                            >
                              Show more
                            </button>
                          </p>
                        )}
                      </div>

                      {isExpanded && renderSourceMetadata(source.metadata, index)}
                      
                      {hasLongContent && isExpanded && (
                        <button
                          onClick={() => toggleSourceExpansion(index)}
                          className="mt-2 text-blue-600 hover:text-blue-700 text-sm font-medium"
                        >
                          Show less
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Footer */}
          <div className="mt-4 pt-3 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Sources are retrieved from the knowledge base and ranked by relevance.
              Click on any source to view more details.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SourcesPanel;