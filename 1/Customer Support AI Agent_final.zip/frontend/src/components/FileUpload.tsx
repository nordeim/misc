/**
 * Advanced File Upload Component

Handles file attachment with drag-and-drop support, progress tracking,
validation, and preview functionality.
 */

import React, { useState, useRef, useCallback } from 'react';
import { 
  XMarkIcon, 
  DocumentIcon, 
  CloudArrowUpIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon 
} from '@heroicons/react/24/outline';
import { fileUploadService } from '../services/fileUpload';
import { FileUploadProgress } from '../types';

interface FileUploadProps {
  files: File[];
  onRemove: (index: number) => void;
  onSelect: (files: FileList) => void;
  onUpload?: (files: File[]) => Promise<string[]>;
  maxFileSize?: number;
  allowedTypes?: string[];
  maxFiles?: number;
  className?: string;
}

interface FileWithProgress extends File {
  id: string;
  progress?: number;
  status?: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

const FileUpload: React.FC<FileUploadProps> = ({
  files,
  onRemove,
  onSelect,
  onUpload,
  maxFileSize = 10 * 1024 * 1024, // 10MB
  allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'application/json',
    'text/csv',
    'image/jpeg',
    'image/png',
    'image/gif'
  ],
  maxFiles = 10,
  className = '',
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [dragCounter, setDragCounter] = useState(0);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle drag and drop events
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragCounter(prev => prev + 1);
    
    if (e.dataTransfer.types.includes('Files')) {
      setIsDragOver(true);
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragCounter(prev => prev - 1);
    
    if (dragCounter === 1) {
      setIsDragOver(false);
    }
  }, [dragCounter]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setDragCounter(0);
    setIsDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files);
      handleFilesValidation(droppedFiles);
    }
  }, []);

  // Validate and add files
  const handleFilesValidation = (newFiles: File[]) => {
    const errors: string[] = [];
    
    // Check total file count
    if (files.length + newFiles.length > maxFiles) {
      errors.push(`Maximum ${maxFiles} files allowed. You have ${files.length} files selected.`);
    }

    newFiles.forEach(file => {
      // Check file size
      if (file.size > maxFileSize) {
        const maxSizeMB = Math.round(maxFileSize / (1024 * 1024));
        errors.push(`${file.name}: File size exceeds ${maxSizeMB}MB limit`);
      }

      // Check file type
      if (!fileUploadService.isFileTypeSupported(file, allowedTypes)) {
        errors.push(`${file.name}: Unsupported file type`);
      }

      // Check for duplicate files
      const isDuplicate = files.some(existingFile => 
        existingFile.name === file.name && 
        existingFile.size === file.size && 
        existingFile.lastModified === file.lastModified
      );
      
      if (isDuplicate) {
        errors.push(`${file.name}: File already selected`);
      }
    });

    setValidationErrors(errors);

    if (errors.length === 0) {
      const fileList = new DataTransfer();
      newFiles.forEach(file => fileList.items.add(file));
      onSelect(fileList.files);
    }

    // Clear errors after 5 seconds
    setTimeout(() => setValidationErrors([]), 5000);
  };

  // Format file size for display
  const formatFileSize = (bytes: number) => {
    return fileUploadService.formatFileSize(bytes);
  };

  // Get file icon
  const getFileIcon = (fileName: string) => {
    return fileUploadService.getFileIcon(fileName);
  };

  // Get allowed file types text
  const getAllowedTypesText = () => {
    const typeMap: Record<string, string> = {
      'application/pdf': 'PDF',
      'application/msword': 'DOC',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'DOCX',
      'text/plain': 'TXT',
      'application/json': 'JSON',
      'text/csv': 'CSV',
      'image/jpeg': 'JPEG',
      'image/png': 'PNG',
      'image/gif': 'GIF',
    };

    const extensions = allowedTypes.map(type => typeMap[type] || type.split('/').pop()?.toUpperCase());
    return extensions.join(', ');
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-gray-700">
          Attachments ({files.length}/{maxFiles})
        </h4>
        {files.length < maxFiles && (
          <button
            onClick={() => fileInputRef.current?.click()}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            + Add Files
          </button>
        )}
      </div>

      {/* Validation errors */}
      {validationErrors.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <ExclamationTriangleIcon className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h5 className="text-sm font-medium text-red-800">Upload Errors</h5>
              <ul className="mt-1 text-sm text-red-700 space-y-1">
                {validationErrors.map((error, index) => (
                  <li key={index}>• {error}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Selected files */}
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((file, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center space-x-3 flex-1 min-w-0">
                <span className="text-xl flex-shrink-0">
                  {getFileIcon(file.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate" title={file.name}>
                    {file.name}
                  </p>
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <span>{formatFileSize(file.size)}</span>
                    <span>•</span>
                    <span>{file.type || 'Unknown type'}</span>
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => onRemove(index)}
                className="ml-2 p-1 text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                title="Remove file"
              >
                <XMarkIcon className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Upload area */}
      {files.length < maxFiles && (
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
            isDragOver
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <CloudArrowUpIcon className={`w-10 h-10 mx-auto mb-3 ${
            isDragOver ? 'text-blue-500' : 'text-gray-400'
          }`} />
          
          <div className="space-y-2">
            <p className="text-sm text-gray-600">
              <span className="font-medium">Drag and drop files here</span> or{' '}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                browse
              </button>
            </p>
            
            <p className="text-xs text-gray-500">
              Supported formats: {getAllowedTypesText()}
            </p>
            <p className="text-xs text-gray-500">
              Maximum file size: {Math.round(maxFileSize / (1024 * 1024))}MB per file
            </p>
            <p className="text-xs text-gray-500">
              Maximum {maxFiles} files total
            </p>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => e.target.files && handleFilesValidation(Array.from(e.target.files))}
        accept={allowedTypes.join(',')}
      />

      {/* Upload button */}
      {onUpload && files.length > 0 && (
        <div className="pt-2 border-t">
          <button
            onClick={() => onUpload(files)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
          >
            <CloudArrowUpIcon className="w-5 h-5" />
            <span>Upload {files.length} file{files.length !== 1 ? 's' : ''}</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;