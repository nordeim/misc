/**
 * Chat Interface Component.
 * 
 * The primary UI component for the customer support chat system.
 * Provides real-time messaging, file upload, and session management.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  PaperAirplaneIcon, 
  DocumentTextIcon, 
  ExclamationTriangleIcon,
  PhotoIcon,
  XMarkIcon,
  ArrowPathIcon,
  ChatBubbleLeftRightIcon,
  CogIcon
} from '@heroicons/react/24/outline';
import { useChat } from '../hooks/useChat';
import { useFileUpload } from '../hooks/useFileUpload';
import { useWebSocket } from '../hooks/useWebSocket';
import { Message, Session } from '../types';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';
import LoadingSpinner from './LoadingSpinner';
import { toast } from 'react-hot-toast';

const ChatInterface: React.FC = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  
  // Local state
  const [inputMessage, setInputMessage] = useState('');
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [isAtBottom, setIsAtBottom] = useState(true);
  
  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Use our custom hooks
  const { 
    messages, 
    currentSession, 
    isLoading, 
    isTyping, 
    error,
    sendMessage: sendChatMessage, 
    canSendMessage,
    retryMessage,
    clearChat
  } = useChat({ 
    sessionId: sessionId || undefined,
    autoConnect: true 
  });

  const {
    files,
    uploadProgress,
    isUploading,
    uploadError,
    selectFiles,
    removeFile,
    clearFiles,
    uploadFiles,
    getFileIcon,
    formatFileSize,
  } = useFileUpload({ 
    sessionId: currentSession?.id,
    validation: {
      maxSize: 10 * 1024 * 1024, // 10MB
      maxFiles: 5,
      allowedTypes: [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf', 'text/plain', 'text/csv',
        'application/json', 'application/xml',
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ],
    },
    onUploadComplete: (uploadedFiles) => {
      console.log('Files uploaded:', uploadedFiles);
    },
    onUploadError: (error, fileId) => {
      toast.error(`Failed to upload file: ${error}`);
    },
  });

  const { 
    isConnected, 
    isConnecting, 
    connectionError,
    connect: reconnectWebSocket 
  } = useWebSocket({
    onMessage: () => {}, // Handled by useChat
    onTyping: () => {}, // Handled by useChat
    onError: (error) => {
      console.error('WebSocket error:', error);
      toast.error('Connection error. Some features may not work properly.');
    },
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (isAtBottom) {
      scrollToBottom();
    }
  }, [messages, isAtBottom]);

  // Update scroll position when user scrolls
  const handleScroll = useCallback(() => {
    if (messagesContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setIsAtBottom(isNearBottom);
    }
  }, []);

  useEffect(() => {
    const container = messagesContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [handleScroll]);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !canSendMessage) {
      if (!inputMessage.trim()) {
        toast.error('Please enter a message');
      }
      return;
    }

    try {
      await sendChatMessage(inputMessage, files);
      setInputMessage('');
      setShowFileUpload(false);
      clearFiles();
      
      // Scroll to bottom after sending
      setTimeout(() => scrollToBottom('auto'), 100);
      
    } catch (error: any) {
      toast.error(`Failed to send message: ${error.message}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleFileSelect = (selectedFiles: FileList | null) => {
    if (selectedFiles && selectedFiles.length > 0) {
      selectFiles(selectedFiles);
      setShowFileUpload(true);
    }
  };

  const handleFileRemove = (index: number) => {
    removeFile(index);
    if (files.length <= 1) {
      setShowFileUpload(false);
    }
  };

  const handleNewChat = () => {
    navigate('/');
    clearChat();
  };

  const handleRetryMessage = async (messageId: string) => {
    try {
      await retryMessage(messageId);
      toast.success('Message resent');
    } catch (error: any) {
      toast.error(`Failed to resend message: ${error.message}`);
    }
  };

  const handleReconnect = () => {
    reconnectWebSocket();
    toast.info('Attempting to reconnect...');
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden flex flex-col h-[600px]">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-500 rounded-lg">
              <ChatBubbleLeftRightIcon className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">
                {currentSession?.title || 'Customer Support AI'}
              </h1>
              <div className="flex items-center space-x-2 text-sm">
                {isConnecting ? (
                  <div className="flex items-center space-x-1 text-blue-200">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                    <span>Connecting...</span>
                  </div>
                ) : isConnected ? (
                  <div className="flex items-center space-x-1 text-green-200">
                    <div className="w-2 h-2 bg-green-400 rounded-full" />
                    <span>Connected</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-1 text-red-200">
                    <div className="w-2 h-2 bg-red-400 rounded-full" />
                    <span>Disconnected</span>
                  </div>
                )}
                {error && (
                  <button
                    onClick={handleReconnect}
                    className="text-yellow-200 hover:text-yellow-100 underline ml-2"
                  >
                    Reconnect
                  </button>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {messages.length > 0 && (
              <div className="flex items-center space-x-1 text-blue-100">
                <DocumentTextIcon className="h-4 w-4" />
                <span className="text-sm">{messages.length} message{messages.length !== 1 ? 's' : ''}</span>
              </div>
            )}
            <button
              onClick={() => navigate('/settings')}
              className="p-2 hover:bg-blue-500 rounded-lg transition-colors"
              title="Settings"
            >
              <CogIcon className="h-5 w-5" />
            </button>
            <button
              onClick={handleNewChat}
              className="p-2 hover:bg-blue-500 rounded-lg transition-colors"
              title="New Chat"
            >
              <ArrowPathIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Connection Error */}
      {connectionError && (
        <div className="bg-red-50 border-b border-red-200 p-3 flex-shrink-0">
          <div className="flex items-center space-x-2 text-red-700">
            <ExclamationTriangleIcon className="h-4 w-4" />
            <span className="text-sm">Connection Error: {connectionError}</span>
            <button
              onClick={handleReconnect}
              className="ml-auto text-sm underline hover:no-underline"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Messages */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50"
      >
        {isLoading && messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <LoadingSpinner size="lg" text="Loading chat..." />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <div className="max-w-sm mx-auto">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ChatBubbleLeftRightIcon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Welcome to Customer Support AI
              </h3>
              <p className="text-sm mb-4">
                How can I help you today? Ask me anything about our products, services, or if you need support.
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => setInputMessage('What products do you offer?')}
                  className="p-2 bg-white rounded border hover:bg-gray-50 transition-colors"
                >
                  Product Information
                </button>
                <button
                  onClick={() => setInputMessage('I need technical support')}
                  className="p-2 bg-white rounded border hover:bg-gray-50 transition-colors"
                >
                  Technical Support
                </button>
                <button
                  onClick={() => setInputMessage('What are your business hours?')}
                  className="p-2 bg-white rounded border hover:bg-gray-50 transition-colors"
                >
                  Business Hours
                </button>
                <button
                  onClick={() => setInputMessage('How can I contact customer service?')}
                  className="p-2 bg-white rounded border hover:bg-gray-50 transition-colors"
                >
                  Contact Support
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <MessageBubble 
                key={message.id} 
                message={message}
                onRetry={message.role === 'user' ? () => handleRetryMessage(message.id) : undefined}
              />
            ))}
            {isTyping && <TypingIndicator />}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* File Upload Progress */}
      {uploadProgress.length > 0 && (
        <div className="px-4 py-2 border-t bg-blue-50 flex-shrink-0">
          <div className="space-y-2">
            {uploadProgress.map((progress) => (
              <div key={progress.fileId} className="flex items-center space-x-2 text-sm">
                <span className="text-gray-600">{getFileIcon(progress.fileName)}</span>
                <span className="flex-1 truncate">{progress.fileName}</span>
                <span className="text-xs text-gray-500">{progress.progress}%</span>
                {progress.status === 'success' && <span className="text-green-600">✓</span>}
                {progress.status === 'error' && <span className="text-red-600">✗</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* File Preview */}
      {files.length > 0 && (
        <div className="px-4 py-2 border-t bg-gray-50 flex-shrink-0">
          <div className="flex flex-wrap gap-2">
            {files.map((file, index) => (
              <div
                key={index}
                className="flex items-center space-x-2 bg-white px-3 py-2 rounded-lg border text-sm max-w-xs"
              >
                <span>{getFileIcon(file.name)}</span>
                <span className="flex-1 truncate">{file.name}</span>
                <span className="text-xs text-gray-500">{formatFileSize(file.size)}</span>
                <button
                  onClick={() => handleFileRemove(index)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XMarkIcon className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upload Error */}
      {uploadError && (
        <div className="px-4 py-2 border-t bg-red-50 text-red-600 text-sm flex-shrink-0">
          Upload Error: {uploadError}
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t bg-white flex-shrink-0">
        <div className="flex space-x-2">
          <div className="flex-1 relative">
            <textarea
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={isConnected ? "Type your message..." : "Connecting..."}
              className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none max-h-32"
              rows={1}
              disabled={!canSendMessage}
              style={{ minHeight: '48px' }}
            />
            {/* Character count */}
            {inputMessage.length > 400 && (
              <div className="absolute bottom-1 right-1 text-xs text-gray-400">
                {inputMessage.length}/1000
              </div>
            )}
          </div>
          <div className="flex flex-col space-y-2">
            {/* File upload button */}
            <label className="cursor-pointer">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => handleFileSelect(e.target.files)}
                accept=".txt,.pdf,.doc,.docx,.json,.csv,.jpg,.jpeg,.png,.gif,.webp"
                disabled={!canSendMessage}
              />
              <div className="p-3 bg-gray-100 hover:bg-gray-200 disabled:bg-gray-50 rounded-lg transition-colors">
                <PhotoIcon className="h-5 w-5 text-gray-600" />
              </div>
            </label>
            
            {/* Send button */}
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || !canSendMessage}
              className="p-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white rounded-lg transition-colors flex items-center justify-center"
            >
              {isLoading ? (
                <LoadingSpinner size="sm" color="white" />
              ) : (
                <PaperAirplaneIcon className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;