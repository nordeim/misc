import { describe, it, expect, vi } from 'vitest'
import { screen, fireEvent } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/utils'
import Header from './Header'

// Mock React Router Link
vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual('react-router-dom')
  return {
    ...actual,
    Link: ({ children, to, ...props }: any) => (
      <a href={to} {...props}>{children}</a>
    ),
  }
})

// Mock icons
vi.mock('@heroicons/react/24/outline', () => ({
  HomeIcon: ({ className }: { className?: string }) => (
    <svg data-testid="home-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  ),
  ChatBubbleLeftRightIcon: ({ className }: { className?: string }) => (
    <svg data-testid="chat-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  ),
  DocumentTextIcon: ({ className }: { className?: string }) => (
    <svg data-testid="document-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
}))

describe('Header', () => {
  it('renders without crashing', () => {
    renderWithProviders(<Header />)
    expect(document.body).toBeInTheDocument()
  })

  it('displays navigation links', () => {
    renderWithProviders(<Header />)
    expect(screen.getByText('Home')).toBeInTheDocument()
    expect(screen.getByText('Chat')).toBeInTheDocument()
    expect(screen.getByText('Documents')).toBeInTheDocument()
  })

  it('displays application title', () => {
    renderWithProviders(<Header />)
    expect(screen.getByText('Customer Support AI')).toBeInTheDocument()
  })

  it('applies correct styling classes', () => {
    renderWithProviders(<Header />)
    const header = screen.getByRole('banner')
    expect(header).toHaveClass('bg-white', 'shadow-sm')
  })

  it('navigation links have correct hrefs', () => {
    renderWithProviders(<Header />)
    const homeLink = screen.getByText('Home').closest('a')
    const chatLink = screen.getByText('Chat').closest('a')
    const documentsLink = screen.getByText('Documents').closest('a')

    expect(homeLink).toHaveAttribute('href', '/')
    expect(chatLink).toHaveAttribute('href', '/chat')
    expect(documentsLink).toHaveAttribute('href', '/documents')
  })

  it('displays navigation icons', () => {
    renderWithProviders(<Header />)
    expect(screen.getByTestId('home-icon')).toBeInTheDocument()
    expect(screen.getByTestId('chat-icon')).toBeInTheDocument()
    expect(screen.getByTestId('document-icon')).toBeInTheDocument()
  })

  it('has proper accessibility structure', () => {
    renderWithProviders(<Header />)
    
    // Check for semantic HTML elements
    expect(screen.getByRole('banner')).toBeInTheDocument()
    
    // Check for navigation landmark
    const nav = screen.getByRole('navigation')
    expect(nav).toBeInTheDocument()
  })

  it('handles navigation clicks', async () => {
    const user = userEvent.setup()
    renderWithProviders(<Header />)
    
    const chatLink = screen.getByText('Chat')
    await user.click(chatLink)
    
    // This would typically navigate, but in test environment we just check the click handler
    expect(chatLink).toBeInTheDocument()
  })

  it('is responsive on different screen sizes', () => {
    // Test mobile view
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 640,
    })
    
    renderWithProviders(<Header />)
    const header = screen.getByRole('banner')
    expect(header).toBeInTheDocument()
    
    // Reset window size
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 1024,
    })
  })

  it('maintains hover states on interactive elements', async () => {
    const user = userEvent.setup()
    renderWithProviders(<Header />)
    
    const navLinks = screen.getAllByRole('link')
    
    for (const link of navLinks) {
      await user.hover(link)
      expect(link).toBeInTheDocument()
    }
  })
})