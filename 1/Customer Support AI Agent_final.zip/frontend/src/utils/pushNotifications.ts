/**
 * Push Notification Service

Handles push notifications, permission management, and notification actions.
Provides unified interface for notification management across the application.
 */

import { serviceWorkerManager } from './serviceWorker';

export interface NotificationOptions {
  title?: string;
  body?: string;
  icon?: string;
  badge?: string;
  image?: string;
  vibrate?: number[];
  silent?: boolean;
  requireInteraction?: boolean;
  timestamp?: number;
  tag?: string;
  renotify?: boolean;
  data?: any;
  actions?: NotificationAction[];
  badge?: string;
  dir?: 'ltr' | 'rtl';
  lang?: string;
  silent?: boolean;
}

export interface NotificationAction {
  action: string;
  title: string;
  icon?: string;
  description?: string;
}

export interface NotificationPermissionState {
  permission: NotificationPermission;
  supported: boolean;
  canRequest: boolean;
}

class PushNotificationService {
  private vapidPublicKey: string = '';
  private subscription: PushSubscription | null = null;

  constructor() {
    this.initialize();
  }

  /**
   * Initialize notification service
   */
  private async initialize(): Promise<void> {
    if (!this.isSupported()) {
      console.warn('Push notifications not supported');
      return;
    }

    // Load VAPID public key from environment or config
    this.vapidPublicKey = import.meta.env.VITE_VAPID_PUBLIC_KEY || '';

    // Setup service worker messaging
    this.setupServiceWorkerMessaging();
  }

  /**
   * Check if push notifications are supported
   */
  isSupported(): boolean {
    return 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;
  }

  /**
   * Get current notification permission status
   */
  getPermissionState(): NotificationPermissionState {
    const permission = 'Notification' in window ? Notification.permission : 'denied';
    
    return {
      permission,
      supported: this.isSupported(),
      canRequest: permission === 'default'
    };
  }

  /**
   * Request notification permission
   */
  async requestPermission(): Promise<NotificationPermission> {
    if (!this.isSupported()) {
      throw new Error('Push notifications not supported');
    }

    if (Notification.permission === 'granted') {
      return 'granted';
    }

    if (Notification.permission === 'denied') {
      throw new Error('Notification permission denied');
    }

    // Request permission
    const permission = await Notification.requestPermission();
    
    if (permission === 'granted') {
      console.log('Notification permission granted');
      await this.subscribeToPush();
    } else {
      console.log('Notification permission denied');
    }

    return permission;
  }

  /**
   * Show local notification (using Notification API)
   */
  async showLocalNotification(options: NotificationOptions): Promise<Notification | null> {
    if (!this.isSupported()) {
      console.warn('Local notifications not supported');
      return null;
    }

    const permission = this.getPermissionState().permission;
    if (permission !== 'granted') {
      console.warn('Notification permission not granted');
      return null;
    }

    try {
      const notification = new Notification(options.title || 'Notification', {
        icon: options.icon || '/favicon.ico',
        badge: options.badge || '/favicon.ico',
        image: options.image,
        vibrate: options.vibrate || [200, 100, 200],
        silent: options.silent || false,
        requireInteraction: options.requireInteraction || false,
        timestamp: options.timestamp || Date.now(),
        tag: options.tag,
        renotify: options.renotify || false,
        data: options.data,
        actions: options.actions,
        dir: options.dir || 'ltr',
        lang: options.lang || 'en',
        body: options.body,
      });

      // Auto-close after 5 seconds if not requireInteraction
      if (!options.requireInteraction) {
        setTimeout(() => {
          notification.close();
        }, 5000);
      }

      return notification;
    } catch (error) {
      console.error('Failed to show local notification:', error);
      return null;
    }
  }

  /**
   * Show notification via service worker
   */
  async showNotification(title: string, options: NotificationOptions = {}): Promise<void> {
    if (!this.isSupported()) {
      console.warn('Service worker notifications not supported');
      return;
    }

    const permission = this.getPermissionState().permission;
    if (permission !== 'granted') {
      console.warn('Notification permission not granted');
      return;
    }

    try {
      await serviceWorkerManager.showNotification(title, {
        body: options.body,
        icon: options.icon || '/favicon.ico',
        badge: options.badge || '/favicon.ico',
        image: options.image,
        vibrate: options.vibrate || [200, 100, 200],
        silent: options.silent || false,
        requireInteraction: options.requireInteraction || false,
        timestamp: options.timestamp || Date.now(),
        tag: options.tag,
        renotify: options.renotify || false,
        data: options.data,
        actions: options.actions,
        dir: options.dir || 'ltr',
        lang: options.lang || 'en',
        badge: options.badge,
      });
    } catch (error) {
      console.error('Failed to show service worker notification:', error);
    }
  }

  /**
   * Subscribe to push notifications
   */
  async subscribeToPush(): Promise<PushSubscription | null> {
    if (!this.isSupported() || !this.vapidPublicKey) {
      console.warn('Push subscription not supported or VAPID key missing');
      return null;
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      
      if (!registration) {
        throw new Error('Service worker not ready');
      }

      // Check if already subscribed
      const existingSubscription = await registration.pushManager.getSubscription();
      if (existingSubscription) {
        this.subscription = existingSubscription;
        console.log('Already subscribed to push notifications');
        return existingSubscription;
      }

      // Subscribe to push notifications
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(this.vapidPublicKey)
      });

      this.subscription = subscription;
      console.log('Subscribed to push notifications');

      // Send subscription to server
      await this.sendSubscriptionToServer(subscription);

      return subscription;
    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
      return null;
    }
  }

  /**
   * Unsubscribe from push notifications
   */
  async unsubscribeFromPush(): Promise<boolean> {
    if (!this.subscription) {
      return true;
    }

    try {
      const result = await this.subscription.unsubscribe();
      
      if (result) {
        this.subscription = null;
        console.log('Unsubscribed from push notifications');
        
        // Notify server
        await this.removeSubscriptionFromServer();
      }

      return result;
    } catch (error) {
      console.error('Failed to unsubscribe from push notifications:', error);
      return false;
    }
  }

  /**
   * Get current push subscription
   */
  getSubscription(): PushSubscription | null {
    return this.subscription;
  }

  /**
   * Check if push is subscribed
   */
  isSubscribed(): boolean {
    return this.subscription !== null;
  }

  /**
   * Send subscription to server
   */
  private async sendSubscriptionToServer(subscription: PushSubscription): Promise<void> {
    try {
      const response = await fetch('/api/v1/notifications/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subscription: subscription.toJSON(),
          timestamp: Date.now(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send subscription to server');
      }

      console.log('Push subscription sent to server');
    } catch (error) {
      console.error('Failed to send subscription to server:', error);
      throw error;
    }
  }

  /**
   * Remove subscription from server
   */
  private async removeSubscriptionFromServer(): Promise<void> {
    try {
      const response = await fetch('/api/v1/notifications/unsubscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subscription: this.subscription?.toJSON(),
          timestamp: Date.now(),
        }),
      });

      if (!response.ok) {
        console.warn('Failed to remove subscription from server');
      }

      console.log('Push subscription removed from server');
    } catch (error) {
      console.error('Failed to remove subscription from server:', error);
    }
  }

  /**
   * Setup service worker message handling
   */
  private setupServiceWorkerMessaging(): void {
    navigator.serviceWorker?.addEventListener('message', (event) => {
      const { type, payload } = event.data;

      switch (type) {
        case 'NOTIFICATION_CLICKED':
          this.handleNotificationClick(payload);
          break;
          
        case 'NOTIFICATION_ACTION':
          this.handleNotificationAction(payload);
          break;
          
        case 'NOTIFICATION_CLOSED':
          this.handleNotificationClosed(payload);
          break;
      }
    });
  }

  /**
   * Handle notification click
   */
  private handleNotificationClick(payload: any): void {
    console.log('Notification clicked:', payload);
    
    // Focus or open the app
    this.focusOrOpenApp(payload.url || '/');
    
    // Emit custom event
    window.dispatchEvent(new CustomEvent('notificationclicked', {
      detail: payload
    }));
  }

  /**
   * Handle notification action
   */
  private handleNotificationAction(payload: any): void {
    console.log('Notification action:', payload);
    
    // Emit custom event
    window.dispatchEvent(new CustomEvent('notificationaction', {
      detail: payload
    }));
  }

  /**
   * Handle notification closed
   */
  private handleNotificationClosed(payload: any): void {
    console.log('Notification closed:', payload);
    
    // Emit custom event
    window.dispatchEvent(new CustomEvent('notificationclosed', {
      detail: payload
    }));
  }

  /**
   * Focus or open the app
   */
  private async focusOrOpenApp(url: string): Promise<void> {
    try {
      const allClients = await clients.matchAll({
        type: 'window',
        includeUncontrolled: true,
      });

      // Try to focus existing window
      for (const client of allClients) {
        if (client.url === url && 'focus' in client) {
          client.focus();
          return;
        }
      }

      // Open new window
      if (clients.openWindow) {
        await clients.openWindow(url);
      }
    } catch (error) {
      console.error('Failed to focus or open app:', error);
    }
  }

  /**
   * Convert VAPID key to Uint8Array
   */
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    
    return outputArray;
  }

  /**
   * Test notification
   */
  async testNotification(): Promise<void> {
    try {
      await this.showNotification('Test Notification', {
        body: 'Push notifications are working correctly!',
        icon: '/favicon.ico',
        tag: 'test',
        actions: [
          { action: 'open', title: 'Open App' },
          { action: 'dismiss', title: 'Dismiss' }
        ]
      });
    } catch (error) {
      console.error('Test notification failed:', error);
    }
  }

  /**
   * Show chat notification
   */
  async showChatNotification(
    message: string, 
    sender: string, 
    sessionId?: string
  ): Promise<void> {
    await this.showNotification(`New message from ${sender}`, {
      body: message,
      icon: '/favicon.ico',
      tag: `chat-${sessionId || 'general'}`,
      requireInteraction: true,
      actions: [
        { action: 'reply', title: 'Reply' },
        { action: 'view', title: 'View Chat' },
        { action: 'dismiss', title: 'Dismiss' }
      ],
      data: {
        type: 'chat',
        sessionId,
        sender,
        message
      }
    });
  }

  /**
   * Show system notification
   */
  async showSystemNotification(
    title: string,
    message: string,
    type: 'info' | 'warning' | 'error' | 'success' = 'info'
  ): Promise<void> {
    const icons = {
      info: '/favicon.ico',
      warning: '/favicon.ico',
      error: '/favicon.ico',
      success: '/favicon.ico'
    };

    await this.showNotification(title, {
      body: message,
      icon: icons[type],
      tag: `system-${type}`,
      requireInteraction: type === 'error',
      actions: [
        { action: 'dismiss', title: 'Dismiss' }
      ],
      data: {
        type: 'system',
        severity: type
      }
    });
  }
}

// Create singleton instance
export const pushNotificationService = new PushNotificationService();

// Helper functions
export const requestNotificationPermission = async (): Promise<NotificationPermission> => {
  return await pushNotificationService.requestPermission();
};

export const showNotification = async (title: string, options?: NotificationOptions): Promise<void> => {
  await pushNotificationService.showNotification(title, options);
};

export const showChatNotification = async (
  message: string, 
  sender: string, 
  sessionId?: string
): Promise<void> => {
  await pushNotificationService.showChatNotification(message, sender, sessionId);
};

export const showSystemNotification = async (
  title: string,
  message: string,
  type?: 'info' | 'warning' | 'error' | 'success'
): Promise<void> => {
  await pushNotificationService.showSystemNotification(title, message, type);
};

export const testNotifications = async (): Promise<void> => {
  await pushNotificationService.testNotification();
};

export const subscribeToPush = async (): Promise<PushSubscription | null> => {
  return await pushNotificationService.subscribeToPush();
};

export const unsubscribeFromPush = async (): Promise<boolean> => {
  return await pushNotificationService.unsubscribeFromPush();
};

export const getNotificationPermissionState = (): NotificationPermissionState => {
  return pushNotificationService.getPermissionState();
};

export default pushNotificationService;