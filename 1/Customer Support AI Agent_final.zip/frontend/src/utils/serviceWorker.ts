/**
 * Service Worker Registration and Management

Handles service worker registration, updates, and messaging.
Provides functions for offline functionality and push notifications.
 */

import { CONSTANTS } from '../utils/constants';

export interface ServiceWorkerConfig {
  onUpdate?: (registration: ServiceWorkerRegistration) => void;
  onSuccess?: (registration: ServiceWorkerRegistration) => void;
  onOfflineReady?: () => void;
  onNeedRefresh?: () => void;
}

class ServiceWorkerManager {
  private registration: ServiceWorkerRegistration | null = null;
  private isOnline = navigator.onLine;
  private updateAvailable = false;
  private config: ServiceWorkerConfig;

  constructor(config: ServiceWorkerConfig = {}) {
    this.config = config;
    this.setupEventListeners();
  }

  /**
   * Register service worker
   */
  async register(): Promise<boolean> {
    if (!this.isSupported()) {
      console.warn('Service Worker not supported in this browser');
      return false;
    }

    try {
      console.log('Registering Service Worker...');
      
      this.registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/',
        updateViaCache: 'none'
      });

      console.log('Service Worker registered successfully:', this.registration);

      // Handle updates
      this.registration.addEventListener('updatefound', () => {
        this.handleUpdateFound();
      });

      // Check for updates immediately
      this.checkForUpdates();

      // Handle messages from service worker
      this.setupMessageHandling();

      // Notify success
      this.config.onSuccess?.(this.registration);

      return true;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
      return false;
    }
  }

  /**
   * Unregister service worker
   */
  async unregister(): Promise<boolean> {
    if (!this.registration) {
      return false;
    }

    try {
      const result = await this.registration.unregister();
      console.log('Service Worker unregistered:', result);
      this.registration = null;
      return result;
    } catch (error) {
      console.error('Service Worker unregistration failed:', error);
      return false;
    }
  }

  /**
   * Check for service worker updates
   */
  async checkForUpdates(): Promise<void> {
    if (!this.registration) {
      return;
    }

    try {
      await this.registration.update();
      console.log('Service Worker update check completed');
    } catch (error) {
      console.error('Service Worker update check failed:', error);
    }
  }

  /**
   * Update service worker immediately
   */
  async updateServiceWorker(): Promise<void> {
    if (!this.registration || !this.updateAvailable) {
      return;
    }

    try {
      // Tell the service worker to skip waiting
      this.registration.active?.postMessage({ type: 'SKIP_WAITING' });
      console.log('Service Worker update requested');
    } catch (error) {
      console.error('Service Worker update failed:', error);
    }
  }

  /**
   * Show update available notification
   */
  showUpdateAvailable(): void {
    this.updateAvailable = true;
    this.config.onNeedRefresh?.();
  }

  /**
   * Check if browser supports service workers
   */
  isSupported(): boolean {
    return 'serviceWorker' in navigator;
  }

  /**
   * Check if service worker is registered
   */
  isRegistered(): boolean {
    return this.registration !== null;
  }

  /**
   * Get service worker state
   */
  getState(): string | undefined {
    return this.registration?.active?.state;
  }

  /**
   * Get service worker scope
   */
  getScope(): string | undefined {
    return this.registration?.scope;
  }

  /**
   * Send message to service worker
   */
  async sendMessage(message: any): Promise<any> {
    if (!this.registration || !this.registration.active) {
      throw new Error('Service Worker not active');
    }

    return new Promise((resolve, reject) => {
      const messageChannel = new MessageChannel();
      
      messageChannel.port1.onmessage = (event) => {
        if (event.data.error) {
          reject(event.data.error);
        } else {
          resolve(event.data);
        }
      };

      this.registration.active.postMessage(message, [messageChannel.port2]);
    });
  }

  /**
   * Cache URLs for offline access
   */
  async cacheUrls(urls: string[]): Promise<void> {
    await this.sendMessage({
      type: 'CACHE_URLS',
      payload: { urls }
    });
  }

  /**
   * Clear caches
   */
  async clearCaches(cacheNames: string[]): Promise<void> {
    await this.sendMessage({
      type: 'CLEAR_CACHE',
      payload: { cacheNames }
    });
  }

  /**
   * Get cache size
   */
  async getCacheSize(): Promise<number> {
    const messageChannel = new MessageChannel();
    
    return new Promise((resolve, reject) => {
      messageChannel.port1.onmessage = (event) => {
        resolve(event.data.cacheSize);
      };

      this.sendMessage({ type: 'GET_CACHE_SIZE' })
        .then(() => {
          if (this.registration?.active) {
            this.registration.active.postMessage(
              { type: 'GET_CACHE_SIZE' },
              [messageChannel.port2]
            );
          }
        })
        .catch(reject);
    });
  }

  /**
   * Request notification permission
   */
  async requestNotificationPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return 'denied';
    }

    if (Notification.permission === 'granted') {
      return 'granted';
    }

    if (Notification.permission === 'denied') {
      return 'denied';
    }

    // Request permission
    return await Notification.requestPermission();
  }

  /**
   * Show notification
   */
  async showNotification(
    title: string, 
    options?: NotificationOptions
  ): Promise<Notification | undefined> {
    const permission = await this.requestNotificationPermission();
    
    if (permission !== 'granted') {
      console.warn('Notification permission not granted');
      return undefined;
    }

    return new Notification(title, {
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      ...options
    });
  }

  /**
   * Setup event listeners
   */
  private setupEventListeners(): void {
    // Online/offline detection
    window.addEventListener('online', () => {
      console.log('Application back online');
      this.isOnline = true;
    });

    window.addEventListener('offline', () => {
      console.log('Application went offline');
      this.isOnline = false;
    });

    // Service worker messages
    navigator.serviceWorker?.addEventListener('message', (event) => {
      this.handleServiceWorkerMessage(event.data);
    });

    // Periodic updates (optional)
    if ('serviceWorker' in navigator) {
      setInterval(() => {
        if (this.isOnline) {
          this.checkForUpdates();
        }
      }, 60000); // Check every minute
    }
  }

  /**
   * Handle service worker update found
   */
  private handleUpdateFound(): void {
    if (!this.registration) return;

    const newWorker = this.registration.installing;
    if (!newWorker) return;

    newWorker.addEventListener('statechange', () => {
      if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
        console.log('New service worker available');
        this.showUpdateAvailable();
      }
    });
  }

  /**
   * Setup message handling from service worker
   */
  private setupMessageHandling(): void {
    if (!navigator.serviceWorker.controller) {
      // No active service worker yet, wait for it
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        this.setupMessageHandling();
      });
      return;
    }

    // Setup message handling with active service worker
    this.sendMessage({ type: 'PING' })
      .catch(() => {
        // Service worker might not be ready yet
        setTimeout(() => this.setupMessageHandling(), 1000);
      });
  }

  /**
   * Handle messages from service worker
   */
  private handleServiceWorkerMessage(data: any): void {
    console.log('Service Worker message received:', data);

    switch (data.type) {
      case 'CACHE_READY':
        this.config.onOfflineReady?.();
        break;
        
      case 'UPDATE_AVAILABLE':
        this.showUpdateAvailable();
        break;
        
      case 'CACHE_UPDATED':
        console.log('Cache updated:', data.payload);
        break;
        
      default:
        console.log('Unknown service worker message:', data.type);
    }
  }

  /**
   * Setup periodic background sync (if supported)
   */
  async setupBackgroundSync(): Promise<void> {
    if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
      try {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register('periodic-background-sync');
        console.log('Background sync registered');
      } catch (error) {
        console.error('Background sync registration failed:', error);
      }
    }
  }

  /**
   * Get offline status
   */
  isOffline(): boolean {
    return !this.isOnline;
  }

  /**
   * Get update status
   */
  hasUpdate(): boolean {
    return this.updateAvailable;
  }
}

// Create singleton instance
export const serviceWorkerManager = new ServiceWorkerManager();

// Helper functions
export const registerServiceWorker = async (config?: ServiceWorkerConfig) => {
  return await serviceWorkerManager.register();
};

export const unregisterServiceWorker = async () => {
  return await serviceWorkerManager.unregister();
};

export const updateServiceWorker = async () => {
  return await serviceWorkerManager.updateServiceWorker();
};

export const showUpdateNotification = async () => {
  return await serviceWorkerManager.showNotification('Update Available', {
    body: 'A new version of the app is available. Click to update.',
    icon: '/favicon.ico',
    actions: [
      { action: 'update', title: 'Update Now' },
      { action: 'dismiss', title: 'Later' }
    ]
  });
};

// Auto-register if in production and service worker is supported
if (process.env.NODE_ENV === 'production' && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    registerServiceWorker({
      onSuccess: (registration) => {
        console.log('Service Worker registered successfully');
      },
      onUpdate: (registration) => {
        console.log('Service Worker update available');
      },
      onOfflineReady: () => {
        console.log('App ready to work offline');
      }
    });
  });
}

export default serviceWorkerManager;