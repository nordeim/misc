/**
 * Text and Message Formatting Utilities

Provides functions for formatting text, dates, file sizes, and other data
for display in the UI.
 */

/**
 * Format a date for display
 */
export const formatDate = (date: string | Date, format: 'short' | 'long' | 'relative' = 'short'): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  switch (format) {
    case 'short':
      return dateObj.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: dateObj.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined,
      });
    
    case 'long':
      return dateObj.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    
    case 'relative':
      return formatRelativeTime(dateObj);
    
    default:
      return dateObj.toLocaleDateString();
  }
};

/**
 * Format time ago (relative time)
 */
export const formatRelativeTime = (date: string | Date): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - dateObj.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return diffInSeconds <= 1 ? 'just now' : `${diffInSeconds} seconds ago`;
  }

  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return diffInMinutes === 1 ? '1 minute ago' : `${diffInMinutes} minutes ago`;
  }

  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return diffInHours === 1 ? '1 hour ago' : `${diffInHours} hours ago`;
  }

  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 7) {
    return diffInDays === 1 ? '1 day ago' : `${diffInDays} days ago`;
  }

  const diffInWeeks = Math.floor(diffInDays / 7);
  if (diffInWeeks < 4) {
    return diffInWeeks === 1 ? '1 week ago' : `${diffInWeeks} weeks ago`;
  }

  const diffInMonths = Math.floor(diffInDays / 30);
  if (diffInMonths < 12) {
    return diffInMonths === 1 ? '1 month ago' : `${diffInMonths} months ago`;
  }

  const diffInYears = Math.floor(diffInDays / 365);
  return diffInYears === 1 ? '1 year ago' : `${diffInYears} years ago`;
};

/**
 * Format file size for display
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Format duration in milliseconds to human readable string
 */
export const formatDuration = (milliseconds: number): string => {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
};

/**
 * Truncate text to a specified length with ellipsis
 */
export const truncateText = (text: string, maxLength: number, suffix: string = '...'): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - suffix.length) + suffix;
};

/**
 * Format phone number for display
 */
export const formatPhoneNumber = (phoneNumber: string): string => {
  // Remove all non-numeric characters
  const cleaned = phoneNumber.replace(/\D/g, '');
  
  // Check if it's a US phone number
  if (cleaned.length === 10) {
    return `(${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)}-${cleaned.substring(6)}`;
  } else if (cleaned.length === 11 && cleaned[0] === '1') {
    return `+1 (${cleaned.substring(1, 4)}) ${cleaned.substring(4, 7)}-${cleaned.substring(7)}`;
  }
  
  // Return original if not a standard US number
  return phoneNumber;
};

/**
 * Format currency amount
 */
export const formatCurrency = (
  amount: number,
  currency: string = 'USD',
  locale: string = 'en-US'
): string => {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

/**
 * Format percentage
 */
export const formatPercentage = (value: number, decimals: number = 1): string => {
  return `${(value * 100).toFixed(decimals)}%`;
};

/**
 * Format number with thousand separators
 */
export const formatNumber = (num: number, locale: string = 'en-US'): string => {
  return new Intl.NumberFormat(locale).format(num);
};

/**
 * Capitalize first letter of each word
 */
export const capitalizeWords = (text: string): string => {
  return text.replace(/\w\S*/g, (txt) => 
    txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
};

/**
 * Format confidence score for display
 */
export const formatConfidence = (confidence: number): {
  percentage: string;
  level: 'very-low' | 'low' | 'medium' | 'high' | 'very-high';
  color: string;
} => {
  const percentage = formatPercentage(confidence, 0);
  
  let level: typeof percentage extends string ? 'very-low' | 'low' | 'medium' | 'high' | 'very-high' : never;
  let color: string;
  
  if (confidence >= 0.9) {
    level = 'very-high';
    color = 'text-green-600';
  } else if (confidence >= 0.75) {
    level = 'high';
    color = 'text-green-500';
  } else if (confidence >= 0.5) {
    level = 'medium';
    color = 'text-yellow-500';
  } else if (confidence >= 0.25) {
    level = 'low';
    color = 'text-orange-500';
  } else {
    level = 'very-low';
    color = 'text-red-500';
  }
  
  return { percentage, level, color };
};

/**
 * Format message content with markdown-like syntax
 */
export const formatMessageContent = (content: string): {
  __html: string;
} => {
  // Basic markdown-like formatting
  let formatted = content
    // Bold text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic text
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Code blocks
    .replace(/`(.*?)`/g, '<code class="bg-gray-100 px-1 py-0.5 rounded text-sm">$1</code>')
    // Line breaks
    .replace(/\n/g, '<br>');
  
  return { __html: formatted };
};

/**
 * Sanitize HTML content
 */
export const sanitizeHtml = (html: string): string => {
  // Basic sanitization - in production, use a proper HTML sanitizer library
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
    .replace(/on\w+="[^"]*"/gi, '')
    .replace(/javascript:/gi, '');
};

/**
 * Format URL for display
 */
export const formatUrl = (url: string, maxLength: number = 50): string => {
  try {
    const urlObj = new URL(url);
    let display = urlObj.hostname;
    
    if (urlObj.pathname !== '/') {
      display += urlObj.pathname;
    }
    
    if (display.length > maxLength) {
      display = display.substring(0, maxLength - 3) + '...';
    }
    
    return display;
  } catch {
    return truncateText(url, maxLength);
  }
};

/**
 * Format chat session title
 */
export const formatChatTitle = (title: string, maxLength: number = 30): string => {
  if (title.length <= maxLength) return title;
  
  // Try to preserve meaningful content
  if (title.includes(':')) {
    const [prefix, ...rest] = title.split(':');
    const suffix = rest.join(':');
    const newTitle = `${prefix}: ${truncateText(suffix, maxLength - prefix.length - 2)}`;
    return newTitle.length <= maxLength ? newTitle : truncateText(title, maxLength);
  }
  
  return truncateText(title, maxLength);
};

/**
 * Format memory usage or data size
 */
export const formatDataSize = (bytes: number, unit: 'auto' | 'kb' | 'mb' | 'gb' = 'auto'): string => {
  if (unit === 'auto') {
    return formatFileSize(bytes);
  }
  
  const multipliers = {
    kb: 1024,
    mb: 1024 * 1024,
    gb: 1024 * 1024 * 1024,
  };
  
  const multiplier = multipliers[unit];
  const value = bytes / multiplier;
  
  return `${value.toFixed(1)} ${unit.toUpperCase()}`;
};

/**
 * Format response time
 */
export const formatResponseTime = (milliseconds: number): {
  time: string;
  rating: 'excellent' | 'good' | 'average' | 'slow';
} => {
  let rating: 'excellent' | 'good' | 'average' | 'slow';
  let time: string;
  
  if (milliseconds < 500) {
    rating = 'excellent';
    time = `${milliseconds}ms`;
  } else if (milliseconds < 2000) {
    rating = 'good';
    time = `${(milliseconds / 1000).toFixed(1)}s`;
  } else if (milliseconds < 5000) {
    rating = 'average';
    time = `${(milliseconds / 1000).toFixed(1)}s`;
  } else {
    rating = 'slow';
    time = `${(milliseconds / 1000).toFixed(1)}s`;
  }
  
  return { time, rating };
};