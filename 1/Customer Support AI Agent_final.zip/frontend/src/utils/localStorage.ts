/**
 * Local Storage Management

Provides a robust wrapper around localStorage with type safety,
error handling, encryption support, and automatic cleanup.
 */

import { CONSTANTS } from './constants';
import { encrypt, decrypt } from './crypto';

// Storage configuration
interface StorageConfig {
  prefix?: string;
  maxSize?: number;
  maxItems?: number;
  ttl?: number; // Time to live in milliseconds
  compress?: boolean;
  encrypt?: boolean;
  compressionThreshold?: number;
}

// Storage item interface
interface StorageItem<T = any> {
  value: T;
  timestamp: number;
  expiresAt?: number;
  size: number;
  compressed?: boolean;
  encrypted?: boolean;
}

// Storage statistics
interface StorageStats {
  used: number;
  available: number;
  items: number;
  oldestItem: number;
  newestItem: number;
  compressionRatio?: number;
}

class LocalStorageManager {
  private config: Required<StorageConfig>;
  private listeners: Map<string, Set<(key: string, newValue: any, oldValue: any) => void>> = new Map();
  private memoryCache: Map<string, any> = new Map();
  private stats: StorageStats = {
    used: 0,
    available: 0,
    items: 0,
    oldestItem: 0,
    newestItem: 0,
  };

  constructor(config: StorageConfig = {}) {
    this.config = {
      prefix: config.prefix || 'csai_',
      maxSize: config.maxSize || this.getAvailableSpace(),
      maxItems: config.maxItems || 1000,
      ttl: config.ttl || 30 * 24 * 60 * 60 * 1000, // 30 days
      compress: config.compress || false,
      encrypt: config.encrypt || false,
      compressionThreshold: config.compressionThreshold || 1024, // 1KB
    };

    this.initializeStorage();
    this.startCleanupTimer();
  }

  /**
   * Initialize storage and calculate stats
   */
  private initializeStorage(): void {
    this.updateStats();
    this.cleanExpiredItems();
  }

  /**
   * Get available storage space
   */
  private getAvailableSpace(): number {
    try {
      const test = 'test';
      let i = 0;
      let used = 0;
      
      // Test how much space is available
      while (i < 10000) {
        try {
          localStorage.setItem(test + i, 'x'.repeat(1024));
          used += 1024;
          i++;
        } catch {
          break;
        }
      }
      
      // Clean up test data
      for (let j = 0; j < i; j++) {
        localStorage.removeItem(test + j);
      }
      
      return Math.max(used * 0.9, 5 * 1024 * 1024); // Use 90% of available space, minimum 5MB
    } catch {
      return 5 * 1024 * 1024; // Default 5MB
    }
  }

  /**
   * Generate full key with prefix
   */
  private getFullKey(key: string): string {
    return this.config.prefix + key;
  }

  /**
   * Compress data if needed
   */
  private async compress(data: string): Promise<string> {
    if (!this.config.compress || data.length < this.config.compressionThreshold) {
      return data;
    }

    try {
      // Use built-in compression if available (requires custom implementation)
      // For now, return as-is (would need a compression library in production)
      return data;
    } catch {
      return data;
    }
  }

  /**
   * Decompress data
   */
  private async decompress(data: string): Promise<string> {
    if (!this.config.compress) {
      return data;
    }

    try {
      // Decompression logic would go here
      return data;
    } catch {
      return data;
    }
  }

  /**
   * Encrypt data if needed
   */
  private async encryptData(data: string): Promise<string> {
    if (!this.config.encrypt) {
      return data;
    }

    try {
      return await encrypt(data);
    } catch {
      console.warn('Encryption failed, storing unencrypted');
      return data;
    }
  }

  /**
   * Decrypt data
   */
  private async decryptData(data: string): Promise<string> {
    if (!this.config.encrypt) {
      return data;
    }

    try {
      return await decrypt(data);
    } catch {
      console.warn('Decryption failed, returning as-is');
      return data;
    }
  }

  /**
   * Calculate string size in bytes
   */
  private calculateSize(str: string): number {
    return new Blob([str]).size;
  }

  /**
   * Update storage statistics
   */
  private updateStats(): void {
    try {
      const keys = this.getAllKeys();
      let used = 0;
      let oldest = Date.now();
      let newest = 0;

      for (const key of keys) {
        try {
          const item = localStorage.getItem(key);
          if (item) {
            used += this.calculateSize(item);
          }
        } catch {
          // Skip corrupted items
        }
      }

      this.stats = {
        used,
        available: this.config.maxSize - used,
        items: keys.length,
        oldestItem: oldest,
        newestItem: newest,
      };
    } catch (error) {
      console.error('Failed to update storage stats:', error);
    }
  }

  /**
   * Get all storage keys
   */
  private getAllKeys(): string[] {
    const keys: string[] = [];
    
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(this.config.prefix)) {
          keys.push(key);
        }
      }
    } catch (error) {
      console.error('Failed to get storage keys:', error);
    }
    
    return keys;
  }

  /**
   * Clean up expired items
   */
  private cleanExpiredItems(): void {
    const now = Date.now();
    const expiredKeys: string[] = [];

    for (const fullKey of this.getAllKeys()) {
      try {
        const item = localStorage.getItem(fullKey);
        if (item) {
          const parsed: StorageItem = JSON.parse(item);
          if (parsed.expiresAt && parsed.expiresAt < now) {
            expiredKeys.push(fullKey);
          }
        }
      } catch {
        // Remove corrupted items
        expiredKeys.push(fullKey);
      }
    }

    // Remove expired items
    for (const key of expiredKeys) {
      this.removeItem(key.substring(this.config.prefix.length));
    }

    if (expiredKeys.length > 0) {
      console.log(`Cleaned up ${expiredKeys.length} expired storage items`);
    }
  }

  /**
   * Start automatic cleanup timer
   */
  private startCleanupTimer(): void {
    // Clean up every hour
    setInterval(() => {
      this.cleanExpiredItems();
      this.updateStats();
    }, 60 * 60 * 1000);
  }

  /**
   * Check if storage quota would be exceeded
   */
  private wouldExceedQuota(itemSize: number): boolean {
    return this.stats.used + itemSize > this.config.maxSize;
  }

  /**
   * Remove oldest items to make space
   */
  private makeSpace(requiredSpace: number): void {
    if (requiredSpace <= 0) return;

    const items: Array<{ key: string; timestamp: number; size: number }> = [];

    for (const fullKey of this.getAllKeys()) {
      try {
        const item = localStorage.getItem(fullKey);
        if (item) {
          const parsed: StorageItem = JSON.parse(item);
          items.push({
            key: fullKey.substring(this.config.prefix.length),
            timestamp: parsed.timestamp,
            size: this.calculateSize(item),
          });
        }
      } catch {
        // Remove corrupted items immediately
        this.removeItem(fullKey.substring(this.config.prefix.length));
      }
    }

    // Sort by timestamp (oldest first)
    items.sort((a, b) => a.timestamp - b.timestamp);

    // Remove oldest items until we have enough space
    let freedSpace = 0;
    for (const item of items) {
      if (freedSpace >= requiredSpace) break;
      
      this.removeItem(item.key);
      freedSpace += item.size;
    }

    if (freedSpace < requiredSpace) {
      console.warn('Could not free enough space in localStorage');
    }
  }

  /**
   * Set item with full metadata
   */
  async setItem<T>(key: string, value: T, options?: {
    ttl?: number;
    compress?: boolean;
    encrypt?: boolean;
  }): Promise<boolean> {
    try {
      const fullKey = this.getFullKey(key);
      
      // Serialize value
      let data = JSON.stringify(value);
      
      // Apply compression if enabled and size exceeds threshold
      let compressed = false;
      if (options?.compress ?? this.config.compress) {
        data = await this.compress(data);
        compressed = data.length < JSON.stringify(value).length;
      }
      
      // Apply encryption if enabled
      let encrypted = false;
      if (options?.encrypt ?? this.config.encrypt) {
        data = await this.encryptData(data);
        encrypted = true;
      }
      
      // Calculate size
      const size = this.calculateSize(data);
      
      // Check if we need to make space
      if (this.wouldExceedQuota(size)) {
        this.makeSpace(size);
      }
      
      // Create storage item
      const now = Date.now();
      const ttl = options?.ttl ?? this.config.ttl;
      
      const storageItem: StorageItem<T> = {
        value,
        timestamp: now,
        expiresAt: ttl > 0 ? now + ttl : undefined,
        size,
        compressed,
        encrypted,
      };
      
      // Store in localStorage
      const serializedItem = JSON.stringify(storageItem);
      localStorage.setItem(fullKey, serializedItem);
      
      // Update memory cache
      this.memoryCache.set(key, value);
      
      // Update stats
      this.updateStats();
      
      // Notify listeners
      this.notifyListeners(key, value, undefined);
      
      return true;
    } catch (error) {
      console.error('Failed to set item in storage:', error);
      return false;
    }
  }

  /**
   * Get item from storage
   */
  async getItem<T>(key: string): Promise<T | null> {
    try {
      const fullKey = this.getFullKey(key);
      
      // Check memory cache first
      if (this.memoryCache.has(key)) {
        return this.memoryCache.get(key);
      }
      
      // Get from localStorage
      const item = localStorage.getItem(fullKey);
      if (!item) {
        return null;
      }
      
      // Parse storage item
      const storageItem: StorageItem<T> = JSON.parse(item);
      
      // Check if expired
      if (storageItem.expiresAt && storageItem.expiresAt < Date.now()) {
        this.removeItem(key);
        return null;
      }
      
      // Decrypt if needed
      let data = JSON.stringify(storageItem.value);
      if (storageItem.encrypted) {
        data = await this.decryptData(data);
        storageItem.value = JSON.parse(data);
      }
      
      // Decompress if needed
      if (storageItem.compressed) {
        data = await this.decompress(data);
        storageItem.value = JSON.parse(data);
      }
      
      // Update memory cache
      this.memoryCache.set(key, storageItem.value);
      
      return storageItem.value;
    } catch (error) {
      console.error('Failed to get item from storage:', error);
      // Remove corrupted item
      this.removeItem(key);
      return null;
    }
  }

  /**
   * Remove item from storage
   */
  async removeItem(key: string): Promise<boolean> {
    try {
      const fullKey = this.getFullKey(key);
      
      // Get old value for notification
      const oldValue = await this.getItem(key);
      
      // Remove from localStorage
      localStorage.removeItem(fullKey);
      
      // Remove from memory cache
      this.memoryCache.delete(key);
      
      // Update stats
      this.updateStats();
      
      // Notify listeners
      this.notifyListeners(key, undefined, oldValue);
      
      return true;
    } catch (error) {
      console.error('Failed to remove item from storage:', error);
      return false;
    }
  }

  /**
   * Clear all items with current prefix
   */
  async clear(): Promise<boolean> {
    try {
      const keys = this.getAllKeys();
      
      for (const fullKey of keys) {
        localStorage.removeItem(fullKey);
      }
      
      // Clear memory cache
      this.memoryCache.clear();
      
      // Update stats
      this.updateStats();
      
      return true;
    } catch (error) {
      console.error('Failed to clear storage:', error);
      return false;
    }
  }

  /**
   * Check if key exists
   */
  async hasItem(key: string): Promise<boolean> {
    const fullKey = this.getFullKey(key);
    return localStorage.getItem(fullKey) !== null;
  }

  /**
   * Get all keys
   */
  getKeys(): string[] {
    return this.getAllKeys().map(key => key.substring(this.config.prefix.length));
  }

  /**
   * Get storage statistics
   */
  getStats(): StorageStats {
    return { ...this.stats };
  }

  /**
   * Subscribe to storage changes
   */
  subscribe(key: string, callback: (key: string, newValue: any, oldValue: any) => void): () => void {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    
    this.listeners.get(key)!.add(callback);
    
    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(key);
      if (callbacks) {
        callbacks.delete(callback);
        if (callbacks.size === 0) {
          this.listeners.delete(key);
        }
      }
    };
  }

  /**
   * Notify listeners of storage changes
   */
  private notifyListeners(key: string, newValue: any, oldValue: any): void {
    const callbacks = this.listeners.get(key);
    if (callbacks) {
      callbacks.forEach(callback => {
        try {
          callback(key, newValue, oldValue);
        } catch (error) {
          console.error('Error in storage listener:', error);
        }
      });
    }
  }

  /**
   * Get multiple items at once
   */
  async getMultiple<T = any>(keys: string[]): Promise<Record<string, T>> {
    const result: Record<string, T> = {};
    
    await Promise.all(
      keys.map(async (key) => {
        const value = await this.getItem<T>(key);
        if (value !== null) {
          result[key] = value;
        }
      })
    );
    
    return result;
  }

  /**
   * Set multiple items at once
   */
  async setMultiple(items: Record<string, any>): Promise<boolean> {
    try {
      const results = await Promise.all(
        Object.entries(items).map(([key, value]) => this.setItem(key, value))
      );
      
      return results.every(result => result);
    } catch (error) {
      console.error('Failed to set multiple items:', error);
      return false;
    }
  }

  /**
   * Remove multiple items at once
   */
  async removeMultiple(keys: string[]): Promise<boolean> {
    try {
      const results = await Promise.all(
        keys.map(key => this.removeItem(key))
      );
      
      return results.every(result => result);
    } catch (error) {
      console.error('Failed to remove multiple items:', error);
      return false;
    }
  }

  /**
   * Export storage data
   */
  async export(): Promise<string> {
    const data: Record<string, any> = {};
    
    for (const key of this.getKeys()) {
      const value = await this.getItem(key);
      if (value !== null) {
        data[key] = value;
      }
    }
    
    return JSON.stringify(data, null, 2);
  }

  /**
   * Import storage data
   */
  async import(jsonData: string, merge: boolean = false): Promise<boolean> {
    try {
      const data: Record<string, any> = JSON.parse(jsonData);
      
      if (!merge) {
        await this.clear();
      }
      
      return await this.setMultiple(data);
    } catch (error) {
      console.error('Failed to import storage data:', error);
      return false;
    }
  }

  /**
   * Get storage usage as percentage
   */
  getUsagePercentage(): number {
    return (this.stats.used / this.config.maxSize) * 100;
  }

  /**
   * Check if storage is almost full
   */
  isAlmostFull(threshold: number = 90): boolean {
    return this.getUsagePercentage() >= threshold;
  }
}

// Create singleton instance
export const storageManager = new LocalStorageManager();

// Export utility functions
export const {
  setItem,
  getItem,
  removeItem,
  clear,
  hasItem,
  getKeys,
  getStats,
  subscribe,
  getMultiple,
  setMultiple,
  removeMultiple,
  export: exportStorage,
  import: importStorage,
} = storageManager;

// Helper functions for common use cases
export const saveUserPreferences = async (preferences: any): Promise<boolean> => {
  return await storageManager.setItem('user_preferences', preferences, {
    ttl: 365 * 24 * 60 * 60 * 1000, // 1 year
  });
};

export const loadUserPreferences = async (): Promise<any | null> => {
  return await storageManager.getItem('user_preferences');
};

export const saveChatHistory = async (sessionId: string, messages: any[]): Promise<boolean> => {
  return await storageManager.setItem(`chat_history_${sessionId}`, messages, {
    ttl: 30 * 24 * 60 * 60 * 1000, // 30 days
    compress: true,
  });
};

export const loadChatHistory = async (sessionId: string): Promise<any[] | null> => {
  return await storageManager.getItem(`chat_history_${sessionId}`);
};

export const saveTheme = async (theme: string): Promise<boolean> => {
  return await storageManager.setItem('theme', theme, {
    ttl: 365 * 24 * 60 * 60 * 1000, // 1 year
  });
};

export const loadTheme = async (): Promise<string | null> => {
  return await storageManager.getItem('theme');
};

export const clearExpiredData = (): void => {
  storageManager['cleanExpiredItems']();
};

export default storageManager;