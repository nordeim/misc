/**
 * Error Handling and User Feedback Utilities

Provides centralized error handling, user notification system,
and feedback mechanisms for the application.
 */

import { toast, Toast } from 'react-hot-toast';
import { pushNotificationService } from './pushNotifications';
import { CONSTANTS } from './constants';

// Error types
export enum ErrorType {
  NETWORK = 'network',
  VALIDATION = 'validation',
  AUTHENTICATION = 'authentication',
  AUTHORIZATION = 'authorization',
  SERVER = 'server',
  CLIENT = 'client',
  UNKNOWN = 'unknown'
}

// Error severity levels
export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

// User feedback types
export enum FeedbackType {
  SUCCESS = 'success',
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info',
  LOADING = 'loading'
}

// Error interface
export interface AppError {
  type: ErrorType;
  severity: ErrorSeverity;
  message: string;
  code?: string;
  details?: any;
  timestamp: number;
  context?: string;
  stack?: string;
}

// User feedback interface
export interface UserFeedback {
  type: FeedbackType;
  title: string;
  message: string;
  duration?: number;
  persistent?: boolean;
  actions?: FeedbackAction[];
  metadata?: any;
}

export interface FeedbackAction {
  label: string;
  action: () => void;
  style?: 'primary' | 'secondary' | 'danger';
}

// Toast interface with additional metadata
interface EnhancedToast extends Toast {
  metadata?: {
    type: FeedbackType;
    timestamp: number;
    id: string;
  };
}

class ErrorHandler {
  private errorQueue: AppError[] = [];
  private maxQueueSize = 100;
  private feedbackHistory: UserFeedback[] = [];
  private isReportingEnabled = true;

  constructor() {
    this.setupGlobalErrorHandling();
    this.setupUnhandledRejectionHandling();
  }

  /**
   * Setup global error handling
   */
  private setupGlobalErrorHandling(): void {
    window.addEventListener('error', (event) => {
      this.handleError({
        type: ErrorType.CLIENT,
        severity: ErrorSeverity.HIGH,
        message: event.message || 'Unknown JavaScript error',
        code: 'JS_ERROR',
        details: {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          error: event.error
        },
        stack: event.error?.stack,
        timestamp: Date.now(),
        context: 'window.onerror'
      });
    });
  }

  /**
   * Setup unhandled promise rejection handling
   */
  private setupUnhandledRejectionHandling(): void {
    window.addEventListener('unhandledrejection', (event) => {
      this.handleError({
        type: ErrorType.CLIENT,
        severity: ErrorSeverity.HIGH,
        message: 'Unhandled promise rejection',
        code: 'UNHANDLED_PROMISE_REJECTION',
        details: {
          reason: event.reason,
          promise: event.promise
        },
        timestamp: Date.now(),
        context: 'unhandledrejection'
      });
    });
  }

  /**
   * Handle and process errors
   */
  handleError(error: Partial<AppError> | Error): void {
    const appError: AppError = this.normalizeError(error);
    
    // Add to queue
    this.errorQueue.push(appError);
    if (this.errorQueue.length > this.maxQueueSize) {
      this.errorQueue.shift();
    }

    // Log error
    console.error('Application Error:', appError);

    // Show user feedback based on error severity
    this.showUserFeedback(appError);

    // Report error if enabled
    if (this.isReportingEnabled) {
      this.reportError(appError);
    }

    // Trigger custom event
    window.dispatchEvent(new CustomEvent('app-error', {
      detail: appError
    }));
  }

  /**
   * Normalize different error formats to AppError
   */
  private normalizeError(error: Partial<AppError> | Error): AppError {
    if (error instanceof Error) {
      return {
        type: this.determineErrorType(error),
        severity: this.determineSeverity(error),
        message: error.message,
        code: this.extractErrorCode(error),
        details: { originalError: error },
        stack: error.stack,
        timestamp: Date.now(),
        context: 'unknown'
      };
    }

    return {
      type: error.type || ErrorType.UNKNOWN,
      severity: error.severity || ErrorSeverity.MEDIUM,
      message: error.message || 'An unexpected error occurred',
      code: error.code,
      details: error.details,
      stack: error.stack,
      timestamp: error.timestamp || Date.now(),
      context: error.context || 'unknown'
    };
  }

  /**
   * Determine error type from error object
   */
  private determineErrorType(error: Error): ErrorType {
    const message = error.message.toLowerCase();
    
    if (message.includes('network') || message.includes('fetch')) {
      return ErrorType.NETWORK;
    }
    if (message.includes('401') || message.includes('unauthorized')) {
      return ErrorType.AUTHENTICATION;
    }
    if (message.includes('403') || message.includes('forbidden')) {
      return ErrorType.AUTHORIZATION;
    }
    if (message.includes('validation') || message.includes('invalid')) {
      return ErrorType.VALIDATION;
    }
    if (message.includes('500') || message.includes('server')) {
      return ErrorType.SERVER;
    }
    
    return ErrorType.CLIENT;
  }

  /**
   * Determine error severity
   */
  private determineSeverity(error: Error): ErrorSeverity {
    const message = error.message.toLowerCase();
    
    if (message.includes('critical') || message.includes('fatal')) {
      return ErrorSeverity.CRITICAL;
    }
    if (message.includes('authentication') || message.includes('security')) {
      return ErrorSeverity.HIGH;
    }
    if (message.includes('network') || message.includes('timeout')) {
      return ErrorSeverity.MEDIUM;
    }
    
    return ErrorSeverity.LOW;
  }

  /**
   * Extract error code from error
   */
  private extractErrorCode(error: Error): string | undefined {
    const match = error.message.match(/\[([A-Z_]+)\]/);
    return match ? match[1] : undefined;
  }

  /**
   * Show user feedback based on error
   */
  private showUserFeedback(error: AppError): void {
    const feedback: UserFeedback = {
      type: FeedbackType.ERROR,
      title: this.getErrorTitle(error),
      message: this.getUserFriendlyMessage(error),
      duration: this.getFeedbackDuration(error.severity),
      persistent: error.severity === ErrorSeverity.CRITICAL
    };

    this.showFeedback(feedback);
  }

  /**
   * Get user-friendly error title
   */
  private getErrorTitle(error: AppError): string {
    switch (error.type) {
      case ErrorType.NETWORK:
        return 'Connection Error';
      case ErrorType.AUTHENTICATION:
        return 'Authentication Error';
      case ErrorType.AUTHORIZATION:
        return 'Access Denied';
      case ErrorType.VALIDATION:
        return 'Validation Error';
      case ErrorType.SERVER:
        return 'Server Error';
      default:
        return 'Error';
    }
  }

  /**
   * Get user-friendly error message
   */
  private getUserFriendlyMessage(error: AppError): string {
    switch (error.type) {
      case ErrorType.NETWORK:
        return 'Unable to connect to the server. Please check your internet connection and try again.';
      case ErrorType.AUTHENTICATION:
        return 'Please log in to continue.';
      case ErrorType.AUTHORIZATION:
        return 'You do not have permission to perform this action.';
      case ErrorType.VALIDATION:
        return 'Please check your input and try again.';
      case ErrorType.SERVER:
        return 'Our server is currently experiencing issues. Please try again later.';
      default:
        return error.message || 'An unexpected error occurred. Please try again.';
    }
  }

  /**
   * Get feedback duration based on severity
   */
  private getFeedbackDuration(severity: ErrorSeverity): number {
    switch (severity) {
      case ErrorSeverity.CRITICAL:
        return 0; // Don't auto-dismiss
      case ErrorSeverity.HIGH:
        return 10000; // 10 seconds
      case ErrorSeverity.MEDIUM:
        return 5000; // 5 seconds
      default:
        return 3000; // 3 seconds
    }
  }

  /**
   * Report error to monitoring service
   */
  private async reportError(error: AppError): Promise<void> {
    try {
      // In a real application, this would send to an error reporting service
      // like Sentry, LogRocket, or custom backend
      
      const errorReport = {
        ...error,
        userAgent: navigator.userAgent,
        url: window.location.href,
        timestamp: new Date().toISOString()
      };

      console.log('Error Report:', errorReport);

      // Example: Send to API endpoint
      // await fetch('/api/errors', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(errorReport)
      // });
      
    } catch (reportingError) {
      console.error('Failed to report error:', reportingError);
    }
  }

  /**
   * Show user feedback notification
   */
  showFeedback(feedback: UserFeedback): void {
    const toastId = this.createToast(feedback);
    
    // Add to history
    this.feedbackHistory.push(feedback);
    if (this.feedbackHistory.length > 50) {
      this.feedbackHistory.shift();
    }

    // Show push notification for critical errors
    if (feedback.type === FeedbackType.ERROR && feedback.persistent) {
      pushNotificationService.showSystemNotification(
        feedback.title,
        feedback.message,
        'error'
      );
    }

    // Trigger custom event
    window.dispatchEvent(new CustomEvent('user-feedback', {
      detail: feedback
    }));
  }

  /**
   * Create toast notification
   */
  private createToast(feedback: UserFeedback): string {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const toastOptions: any = {
      duration: feedback.duration,
      position: 'top-right',
      style: this.getToastStyle(feedback.type),
      className: this.getToastClass(feedback.type),
      metadata: {
        type: feedback.type,
        timestamp: Date.now(),
        id
      }
    };

    let toastInstance: Toast;
    
    switch (feedback.type) {
      case FeedbackType.SUCCESS:
        toastInstance = toast.success(feedback.message, toastOptions);
        break;
      case FeedbackType.ERROR:
        toastInstance = toast.error(feedback.message, toastOptions);
        break;
      case FeedbackType.WARNING:
        toastInstance = toast(feedback.message, {
          ...toastOptions,
          icon: '⚠️'
        });
        break;
      case FeedbackType.INFO:
        toastInstance = toast(feedback.message, {
          ...toastOptions,
          icon: 'ℹ️'
        });
        break;
      case FeedbackType.LOADING:
        toastInstance = toast.loading(feedback.message, toastOptions);
        break;
      default:
        toastInstance = toast(feedback.message, toastOptions);
    }

    // Add custom actions if provided
    if (feedback.actions && feedback.actions.length > 0) {
      this.addToastActions(toastInstance.id, feedback.actions);
    }

    return id;
  }

  /**
   * Get toast style based on type
   */
  private getToastStyle(type: FeedbackType): React.CSSProperties {
    const baseStyle: React.CSSProperties = {
      borderRadius: '8px',
      fontSize: '14px',
      maxWidth: '400px'
    };

    switch (type) {
      case FeedbackType.SUCCESS:
        return {
          ...baseStyle,
          backgroundColor: '#10b981',
          color: '#ffffff'
        };
      case FeedbackType.ERROR:
        return {
          ...baseStyle,
          backgroundColor: '#ef4444',
          color: '#ffffff'
        };
      case FeedbackType.WARNING:
        return {
          ...baseStyle,
          backgroundColor: '#f59e0b',
          color: '#ffffff'
        };
      case FeedbackType.INFO:
        return {
          ...baseStyle,
          backgroundColor: '#3b82f6',
          color: '#ffffff'
        };
      case FeedbackType.LOADING:
        return {
          ...baseStyle,
          backgroundColor: '#6b7280',
          color: '#ffffff'
        };
      default:
        return baseStyle;
    }
  }

  /**
   * Get toast CSS class based on type
   */
  private getToastClass(type: FeedbackType): string {
    return `toast-${type}`;
  }

  /**
   * Add action buttons to toast
   */
  private addToastActions(toastId: string, actions: FeedbackAction[]): void {
    // This would require custom toast implementation
    // For now, we'll use the built-in toast actions
    toast(toastId, {
      duration: 0, // Keep open when actions are present
      actions: actions.map(action => ({
        label: action.label,
        onClick: action.action,
        style: action.style || 'default'
      }))
    });
  }

  /**
   * Show success feedback
   */
  showSuccess(message: string, title?: string, duration?: number): void {
    this.showFeedback({
      type: FeedbackType.SUCCESS,
      title: title || 'Success',
      message,
      duration: duration || 3000
    });
  }

  /**
   * Show error feedback
   */
  showError(message: string, title?: string, persistent?: boolean): void {
    this.showFeedback({
      type: FeedbackType.ERROR,
      title: title || 'Error',
      message,
      duration: persistent ? 0 : 5000,
      persistent
    });
  }

  /**
   * Show warning feedback
   */
  showWarning(message: string, title?: string): void {
    this.showFeedback({
      type: FeedbackType.WARNING,
      title: title || 'Warning',
      message,
      duration: 5000
    });
  }

  /**
   * Show info feedback
   */
  showInfo(message: string, title?: string): void {
    this.showFeedback({
      type: FeedbackType.INFO,
      title: title || 'Info',
      message,
      duration: 4000
    });
  }

  /**
   * Show loading feedback
   */
  showLoading(message: string, title?: string): string {
    const feedback: UserFeedback = {
      type: FeedbackType.LOADING,
      title: title || 'Loading',
      message,
      duration: 0 // Don't auto-dismiss
    };
    
    return this.createToast(feedback);
  }

  /**
   * Dismiss toast by ID
   */
  dismissToast(toastId: string): void {
    toast.dismiss(toastId);
  }

  /**
   * Dismiss all toasts
   */
  dismissAllToasts(): void {
    toast.dismiss();
  }

  /**
   * Get error queue
   */
  getErrorQueue(): AppError[] {
    return [...this.errorQueue];
  }

  /**
   * Get feedback history
   */
  getFeedbackHistory(): UserFeedback[] {
    return [...this.feedbackHistory];
  }

  /**
   * Clear error queue
   */
  clearErrorQueue(): void {
    this.errorQueue = [];
  }

  /**
   * Clear feedback history
   */
  clearFeedbackHistory(): void {
    this.feedbackHistory = [];
  }

  /**
   * Enable/disable error reporting
   */
  setErrorReporting(enabled: boolean): void {
    this.isReportingEnabled = enabled;
  }

  /**
   * Get error statistics
   */
  getErrorStats(): {
    total: number;
    byType: Record<ErrorType, number>;
    bySeverity: Record<ErrorSeverity, number>;
    recent: AppError[];
  } {
    const byType: Record<ErrorType, number> = {} as any;
    const bySeverity: Record<ErrorSeverity, number> = {} as any;

    this.errorQueue.forEach(error => {
      byType[error.type] = (byType[error.type] || 0) + 1;
      bySeverity[error.severity] = (bySeverity[error.severity] || 0) + 1;
    });

    return {
      total: this.errorQueue.length,
      byType,
      bySeverity,
      recent: this.errorQueue.slice(-10)
    };
  }
}

// Create singleton instance
export const errorHandler = new ErrorHandler();

// Export utility functions
export const showSuccess = (message: string, title?: string, duration?: number) => {
  errorHandler.showSuccess(message, title, duration);
};

export const showError = (message: string, title?: string, persistent?: boolean) => {
  errorHandler.showError(message, title, persistent);
};

export const showWarning = (message: string, title?: string) => {
  errorHandler.showWarning(message, title);
};

export const showInfo = (message: string, title?: string) => {
  errorHandler.showInfo(message, title);
};

export const showLoading = (message: string, title?: string) => {
  return errorHandler.showLoading(message, title);
};

export const dismissToast = (toastId: string) => {
  errorHandler.dismissToast(toastId);
};

export const dismissAllToasts = () => {
  errorHandler.dismissAllToasts();
};

export const handleError = (error: Partial<AppError> | Error) => {
  errorHandler.handleError(error);
};

export default errorHandler;