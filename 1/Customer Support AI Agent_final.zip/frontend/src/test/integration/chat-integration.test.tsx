import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { renderWithProviders, createMockUser, createMockMessage } from '@/test/utils'
import ChatInterface from '@/components/ChatInterface'
import FileUpload from '@/components/FileUpload'

// Mock services
vi.mock('@/services/api', () => ({
  sendMessage: vi.fn(),
  getMessages: vi.fn(),
  uploadFile: vi.fn(),
  createSession: vi.fn(),
  getSession: vi.fn(),
}))

vi.mock('@/hooks/useWebSocket', () => ({
  useWebSocket: () => ({
    connected: true,
    sendMessage: vi.fn(),
    lastMessage: null,
  }),
}))

describe('Chat Integration Tests', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe('Chat Flow Integration', () => {
    it('should handle complete chat workflow', async () => {
      const user = userEvent.setup()
      const { sendMessage, getMessages } = await import('@/services/api')
      
      // Mock initial messages
      vi.mocked(getMessages).mockResolvedValue({
        data: { messages: [] }
      })
      
      // Mock send message response
      vi.mocked(sendMessage).mockResolvedValue({
        data: {
          id: '1',
          content: 'Hello',
          sender: 'user',
        }
      })

      renderWithProviders(<ChatInterface />)

      // Type and send message
      const input = screen.getByPlaceholderText('Type your message...')
      const sendButton = screen.getByRole('button', { name: /send/i })

      await user.type(input, 'Hello')
      await user.click(sendButton)

      expect(sendMessage).toHaveBeenCalledWith('Hello')
      expect(input).toHaveValue('')
    })

    it('should handle file upload integration', async () => {
      const user = userEvent.setup()
      const { uploadFile } = await import('@/services/api')
      
      vi.mocked(uploadFile).mockResolvedValue({
        data: {
          success: true,
          file_id: 'file-123',
          filename: 'document.pdf',
        }
      })

      const onFileSelect = vi.fn()
      renderWithProviders(<FileUpload onFileSelect={onFileSelect} />)

      const fileInput = screen.getByTestId('file-input') as HTMLInputElement
      const testFile = new File(['test'], 'document.pdf', { type: 'application/pdf' })

      await user.upload(fileInput, testFile)

      expect(onFileSelect).toHaveBeenCalledWith(testFile)
      expect(uploadFile).toHaveBeenCalledWith(testFile, undefined)
    })

    it('should handle session creation', async () => {
      const { createSession } = await import('@/services/api')
      
      vi.mocked(createSession).mockResolvedValue({
        data: {
          session_id: 'session-123',
          status: 'active',
        }
      })

      renderWithProviders(<ChatInterface />)

      // Wait for session creation
      await waitFor(() => {
        expect(createSession).toHaveBeenCalled()
      })
    })
  })

  describe('Error Handling Integration', () => {
    it('should handle API errors gracefully', async () => {
      const user = userEvent.setup()
      const { sendMessage } = await import('@/services/api')
      const { toast } = await import('react-hot-toast')
      
      vi.mocked(sendMessage).mockRejectedValue(new Error('API Error'))

      renderWithProviders(<ChatInterface />)

      const input = screen.getByPlaceholderText('Type your message...')
      const sendButton = screen.getByRole('button', { name: /send/i })

      await user.type(input, 'Test message')
      await user.click(sendButton)

      await waitFor(() => {
        expect(toast.error).toHaveBeenCalledWith('Failed to send message')
      })
    })

    it('should handle WebSocket disconnections', async () => {
      const { useWebSocket } = await import('@/hooks/useWebSocket')
      
      // Mock disconnected state
      vi.mocked(useWebSocket).mockReturnValue({
        connected: false,
        connectionStatus: 'disconnected',
        sendMessage: vi.fn(),
        lastMessage: null,
        error: null,
        connect: vi.fn(),
        disconnect: vi.fn(),
      })

      renderWithProviders(<ChatInterface />)

      expect(screen.getByText(/disconnected/i)).toBeInTheDocument()
    })
  })

  describe('Real-time Updates Integration', () => {
    it('should handle incoming WebSocket messages', async () => {
      const { useWebSocket } = await import('@/hooks/useWebSocket')
      
      const mockMessage = createMockMessage({
        id: '2',
        content: 'Agent response',
        sender: 'agent',
      })

      vi.mocked(useWebSocket).mockReturnValue({
        connected: true,
        connectionStatus: 'connected',
        sendMessage: vi.fn(),
        lastMessage: mockMessage,
        error: null,
        connect: vi.fn(),
        disconnect: vi.fn(),
      })

      renderWithProviders(<ChatInterface />)

      await waitFor(() => {
        expect(screen.getByText('Agent response')).toBeInTheDocument()
      })
    })
  })

  describe('File Upload Integration', () => {
    it('should handle file upload with message', async () => {
      const user = userEvent.setup()
      const { uploadFile, sendMessage } = await import('@/services/api')
      
      vi.mocked(uploadFile).mockResolvedValue({
        data: {
          success: true,
          file_id: 'file-123',
          filename: 'document.pdf',
        }
      })

      vi.mocked(sendMessage).mockResolvedValue({
        data: {
          id: '2',
          content: 'Uploaded document.pdf',
          sender: 'user',
          file_attachments: [{ file_id: 'file-123' }],
        }
      })

      renderWithProviders(<ChatInterface />)

      // Upload file
      const fileUpload = screen.getByTestId('file-upload')
      const fileInput = screen.getByTestId('file-input') as HTMLInputElement
      const testFile = new File(['test'], 'document.pdf', { type: 'application/pdf' })

      await user.upload(fileInput, testFile)

      // Send message with file
      const sendButton = screen.getByRole('button', { name: /send/i })
      await user.click(sendButton)

      expect(uploadFile).toHaveBeenCalled()
      expect(sendMessage).toHaveBeenCalled()
    })

    it('should handle file upload errors', async () => {
      const user = userEvent.setup()
      const { uploadFile } = await import('@/services/api')
      const { toast } = await import('react-hot-toast')
      
      vi.mocked(uploadFile).mockRejectedValue(new Error('Upload failed'))

      renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)

      const fileInput = screen.getByTestId('file-input') as HTMLInputElement
      const testFile = new File(['test'], 'document.pdf', { type: 'application/pdf' })

      await user.upload(fileInput, testFile)

      await waitFor(() => {
        expect(toast.error).toHaveBeenCalledWith('Upload failed')
      })
    })
  })

  describe('Session Management Integration', () => {
    it('should restore session on page reload', async () => {
      const { getSession, getMessages } = await import('@/services/api')
      
      vi.mocked(getSession).mockResolvedValue({
        data: {
          session_id: 'session-123',
          status: 'active',
        }
      })

      vi.mocked(getMessages).mockResolvedValue({
        data: {
          messages: [
            createMockMessage({ id: '1', content: 'Previous message', sender: 'user' }),
          ]
        }
      })

      renderWithProviders(<ChatInterface />)

      await waitFor(() => {
        expect(getSession).toHaveBeenCalled()
        expect(getMessages).toHaveBeenCalled()
      })
    })

    it('should handle session expiration', async () => {
      const { getSession } = await import('@/services/api')
      const { toast } = await import('react-hot-toast')
      
      vi.mocked(getSession).mockRejectedValue(new Error('Session expired'))

      renderWithProviders(<ChatInterface />)

      await waitFor(() => {
        expect(toast.error).toHaveBeenCalledWith('Session expired. Please refresh the page.')
      })
    })
  })

  describe('Accessibility Integration', () => {
    it('should maintain focus during chat interactions', async () => {
      const user = userEvent.setup()
      
      renderWithProviders(<ChatInterface />)

      const input = screen.getByPlaceholderText('Type your message...')
      
      // Focus should remain on input after sending message
      await user.click(input)
      await user.type(input, 'Test{enter}')

      // In a real scenario, focus would be managed by component
      expect(input).toBeInTheDocument()
    })

    it('should announce new messages to screen readers', async () => {
      const mockMessage = createMockMessage({
        id: '2',
        content: 'New message',
        sender: 'agent',
      })

      renderWithProviders(<ChatInterface />)

      // This would typically be tested with actual ARIA live regions
      const chatContainer = screen.getByLabelText('Chat messages')
      expect(chatContainer).toHaveAttribute('aria-live', 'polite')
    })
  })
})