import { setupServer } from 'msw/node'
import { http, HttpResponse } from 'msw'

export const handlers = [
  // Health check endpoint
  http.get('/api/health', () => {
    return HttpResponse.json({ status: 'healthy', timestamp: new Date().toISOString() })
  }),

  // Authentication endpoints
  http.post('/api/auth/login', () => {
    return HttpResponse.json({
      access_token: 'mock-token',
      token_type: 'bearer',
      user: { id: '1', username: 'testuser', email: 'test@example.com' },
    })
  }),

  http.post('/api/auth/logout', () => {
    return HttpResponse.json({ message: 'Logged out successfully' })
  }),

  // Chat message endpoints
  http.get('/api/chat/messages', () => {
    return HttpResponse.json({
      messages: [
        {
          id: '1',
          content: 'Hello, how can I help you?',
          sender: 'agent',
          timestamp: new Date().toISOString(),
          session_id: 'session-1',
        },
      ],
    })
  }),

  http.post('/api/chat/messages', () => {
    return HttpResponse.json({
      id: '2',
      content: 'Thank you for your message',
      sender: 'user',
      timestamp: new Date().toISOString(),
      session_id: 'session-1',
    })
  }),

  // File upload endpoint
  http.post('/api/upload', () => {
    return HttpResponse.json({
      success: true,
      file_id: 'file-123',
      filename: 'test-file.pdf',
      size: 1024,
      mime_type: 'application/pdf',
    })
  }),

  // Session management
  http.post('/api/sessions', () => {
    return HttpResponse.json({
      session_id: 'session-123',
      created_at: new Date().toISOString(),
      status: 'active',
    })
  }),

  // Error responses for testing
  http.get('/api/error', () => {
    return HttpResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }),

  // WebSocket mock
  http.get('/ws/test', () => {
    return new Response('Mock WebSocket connection')
  }),
]

export const server = setupServer(...handlers)