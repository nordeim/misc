import { describe, it, expect, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/utils'
import App from '../App'

// Mock child components to isolate App testing
vi.mock('../components/Header', () => ({
  default: () => <div data-testid="header">Header</div>,
}))

vi.mock('../components/ChatInterface', () => ({
  default: () => <div data-testid="chat-interface">Chat Interface</div>,
}))

vi.mock('../components/FileUpload', () => ({
  default: () => <div data-testid="file-upload">File Upload</div>,
}))

describe('App', () => {
  it('renders without crashing', () => {
    renderWithProviders(<App />)
    expect(document.body).toBeInTheDocument()
  })

  it('displays header component', () => {
    renderWithProviders(<App />)
    expect(screen.getByTestId('header')).toBeInTheDocument()
  })

  it('displays chat interface component', () => {
    renderWithProviders(<App />)
    expect(screen.getByTestId('chat-interface')).toBeInTheDocument()
  })

  it('displays file upload component', () => {
    renderWithProviders(<App />)
    expect(screen.getByTestId('file-upload')).toBeInTheDocument()
  })

  it('applies correct CSS classes', () => {
    renderWithProviders(<App />)
    const appElement = document.querySelector('[data-testid="app"]')
    expect(appElement).toHaveClass('min-h-screen', 'bg-gray-50')
  })

  it('has proper accessibility attributes', () => {
    renderWithProviders(<App />)
    const main = screen.getByRole('main')
    expect(main).toBeInTheDocument()
  })

  it('handles error boundaries gracefully', () => {
    // Mock console.error to suppress error boundary logging
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
    
    // This test ensures error boundaries don't crash the app
    renderWithProviders(<App />)
    
    expect(consoleSpy).not.toHaveBeenCalled()
    consoleSpy.mockRestore()
  })
})