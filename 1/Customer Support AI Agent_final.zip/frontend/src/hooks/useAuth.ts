/**
 * Custom React hook for managing authentication state.
 * 
 * Provides user authentication, authorization, token management,
 * and login/logout functionality.
 */

import { useState, useEffect, useCallback, useContext, createContext } from 'react';
import { User } from '../types';
import { apiService } from '../services/api';
import { toast } from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  refreshToken: () => Promise<void>;
  updateUser: (userData: Partial<User>) => Promise<void>;
  clearError: () => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

interface AuthProviderProps {
  children: React.ReactNode;
  autoRefresh?: boolean;
  refreshInterval?: number; // in milliseconds
}

export const AuthProvider: React.FC<AuthProviderProps> = ({
  children,
  autoRefresh = true,
  refreshInterval = 15 * 60 * 1000, // 15 minutes
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const isAuthenticated = Boolean(user && user.id);

  // Load user from localStorage on mount
  useEffect(() => {
    loadUserFromStorage();
  }, []);

  // Auto-refresh token if enabled
  useEffect(() => {
    if (autoRefresh && isAuthenticated) {
      const interval = setInterval(() => {
        refreshToken().catch(console.error);
      }, refreshInterval);

      return () => clearInterval(interval);
    }
  }, [autoRefresh, isAuthenticated, refreshInterval]);

  const loadUserFromStorage = useCallback(async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const userData = localStorage.getItem('user_data');

      if (token && userData) {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
        
        // Verify token is still valid
        await refreshToken();
      }
    } catch (error) {
      console.error('Failed to load user from storage:', error);
      clearAuthData();
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearAuthData = useCallback(() => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user_data');
    setUser(null);
    setError(null);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // In a real implementation, you'd call the auth API
      // const response = await fetch('/api/v1/auth/login', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ email, password }),
      // });

      // Mock authentication for now
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call

      const mockUser: User = {
        id: 'user_' + Date.now(),
        email,
        name: email.split('@')[0],
        role: 'user',
        created_at: new Date().toISOString(),
      };

      const mockToken = 'mock_jwt_token_' + Date.now();

      // Store auth data
      localStorage.setItem('auth_token', mockToken);
      localStorage.setItem('user_data', JSON.stringify(mockUser));

      setUser(mockUser);
      toast.success('Login successful');

    } catch (error: any) {
      const errorMessage = error.message || 'Login failed';
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const register = useCallback(async (email: string, password: string, name: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Mock registration
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call

      const newUser: User = {
        id: 'user_' + Date.now(),
        email,
        name,
        role: 'user',
        created_at: new Date().toISOString(),
      };

      const mockToken = 'mock_jwt_token_' + Date.now();

      localStorage.setItem('auth_token', mockToken);
      localStorage.setItem('user_data', JSON.stringify(newUser));

      setUser(newUser);
      toast.success('Registration successful');

    } catch (error: any) {
      const errorMessage = error.message || 'Registration failed';
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setIsLoading(true);

    try {
      // In a real implementation, you'd call the logout API
      // await apiService.post('/api/v1/auth/logout');
      
      // Mock logout delay
      await new Promise(resolve => setTimeout(resolve, 500));

      clearAuthData();
      toast.success('Logged out successfully');

    } catch (error: any) {
      console.error('Logout error:', error);
      // Still clear local data even if API call fails
      clearAuthData();
    } finally {
      setIsLoading(false);
    }
  }, [clearAuthData]);

  const refreshToken = useCallback(async () => {
    try {
      const refreshTokenValue = localStorage.getItem('refresh_token');
      
      if (!refreshTokenValue) {
        throw new Error('No refresh token available');
      }

      // Mock token refresh
      await new Promise(resolve => setTimeout(resolve, 500));

      // In a real implementation:
      // const response = await fetch('/api/v1/auth/refresh', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ refresh_token: refreshTokenValue }),
      // });

      const mockNewToken = 'mock_jwt_token_' + Date.now();
      localStorage.setItem('auth_token', mockNewToken);

      // Optionally refresh user data
      // const userData = await apiService.getCurrentUser();
      // setUser(userData);

    } catch (error: any) {
      console.error('Token refresh failed:', error);
      clearAuthData();
      throw error;
    }
  }, [clearAuthData]);

  const updateUser = useCallback(async (userData: Partial<User>) => {
    if (!user) {
      throw new Error('No user logged in');
    }

    try {
      setIsLoading(true);

      // Mock update
      await new Promise(resolve => setTimeout(resolve, 500));

      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      
      localStorage.setItem('user_data', JSON.stringify(updatedUser));
      toast.success('Profile updated successfully');

    } catch (error: any) {
      const errorMessage = error.message || 'Failed to update profile';
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const value: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    register,
    refreshToken,
    updateUser,
    clearError,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook for using auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Additional utility hooks
export const useRequireAuth = () => {
  const { user, isAuthenticated, isLoading } = useAuth();
  
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      // Redirect to login or handle unauthenticated state
      window.location.href = '/login';
    }
  }, [isAuthenticated, isLoading]);

  return { user, isAuthenticated, isLoading };
};

export const useIsAdmin = () => {
  const { user } = useAuth();
  return user?.role === 'admin';
};

export const useIsAgent = () => {
  const { user } = useAuth();
  return user?.role === 'agent' || user?.role === 'admin';
};