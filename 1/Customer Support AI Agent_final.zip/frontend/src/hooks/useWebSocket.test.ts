import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useWebSocket } from './useWebSocket'

// Mock socket.io-client
vi.mock('socket.io-client', () => ({
  io: vi.fn(() => ({
    on: vi.fn(),
    off: vi.fn(),
    emit: vi.fn(),
    connect: vi.fn(),
    disconnect: vi.fn(),
    connected: false,
    id: 'mock-socket-id',
  })),
}))

describe('useWebSocket', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  afterEach(() => {
    vi.clearAllTimers()
  })

  it('initializes with correct default state', () => {
    const { result } = renderHook(() => useWebSocket())
    
    expect(result.current.connected).toBe(false)
    expect(result.current.connectionStatus).toBe('disconnected')
    expect(result.current.error).toBeNull()
    expect(result.current.lastMessage).toBeNull()
  })

  it('establishes connection on mount', () => {
    const { result } = renderHook(() => useWebSocket())
    
    const io = require('socket.io-client').io
    expect(io).toHaveBeenCalled()
  })

  it('connects to WebSocket when not connected', async () => {
    const mockSocket = {
      connected: false,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    act(() => {
      result.current.connect()
    })
    
    expect(mockSocket.connect).toHaveBeenCalled()
  })

  it('disconnects from WebSocket', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    act(() => {
      result.current.disconnect()
    })
    
    expect(mockSocket.disconnect).toHaveBeenCalled()
  })

  it('sends messages through WebSocket', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    act(() => {
      result.current.sendMessage('test message')
    })
    
    expect(mockSocket.emit).toHaveBeenCalledWith('message', 'test message')
  })

  it('updates connection status on connect event', () => {
    const mockSocket = {
      connected: false,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    // Simulate connection event
    const connectHandler = mockSocket.on.mock.calls.find(
      call => call[0] === 'connect'
    )?.[1]
    
    act(() => {
      connectHandler()
    })
    
    expect(result.current.connected).toBe(true)
    expect(result.current.connectionStatus).toBe('connected')
  })

  it('updates connection status on disconnect event', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    // Simulate connection first
    const connectHandler = mockSocket.on.mock.calls.find(
      call => call[0] === 'connect'
    )?.[1]
    
    act(() => {
      connectHandler()
    })
    
    // Simulate disconnect
    const disconnectHandler = mockSocket.on.mock.calls.find(
      call => call[0] === 'disconnect'
    )?.[1]
    
    act(() => {
      disconnectHandler()
    })
    
    expect(result.current.connected).toBe(false)
    expect(result.current.connectionStatus).toBe('disconnected')
  })

  it('handles incoming messages', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    // Simulate message event
    const messageHandler = mockSocket.on.mock.calls.find(
      call => call[0] === 'message'
    )?.[1]
    
    const testMessage = { content: 'Hello', timestamp: Date.now() }
    
    act(() => {
      messageHandler(testMessage)
    })
    
    expect(result.current.lastMessage).toEqual(testMessage)
  })

  it('handles connection errors', () => {
    const mockSocket = {
      connected: false,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    // Simulate error event
    const errorHandler = mockSocket.on.mock.calls.find(
      call => call[0] === 'connect_error'
    )?.[1]
    
    const error = new Error('Connection failed')
    
    act(() => {
      errorHandler(error)
    })
    
    expect(result.current.error).toEqual(error)
    expect(result.current.connectionStatus).toBe('error')
  })

  it('cleans up event listeners on unmount', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { unmount } = renderHook(() => useWebSocket())
    
    unmount()
    
    expect(mockSocket.off).toHaveBeenCalled()
  })

  it('supports custom URL configuration', () => {
    const customUrl = 'ws://custom-server:8080'
    
    renderHook(() => useWebSocket({ url: customUrl }))
    
    const io = require('socket.io-client').io
    expect(io).toHaveBeenCalledWith(customUrl, expect.any(Object))
  })

  it('supports custom options', () => {
    const options = {
      timeout: 5000,
      reconnection: true,
      reconnectionAttempts: 5,
    }
    
    renderHook(() => useWebSocket({ options }))
    
    const io = require('socket.io-client').io
    expect(io).toHaveBeenCalledWith(expect.any(String), options)
  })

  it('handles reconnection logic', () => {
    const mockSocket = {
      connected: false,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    renderHook(() => useWebSocket({ autoReconnect: true }))
    
    // Check for reconnection event listeners
    expect(mockSocket.on).toHaveBeenCalledWith('reconnect', expect.any(Function))
    expect(mockSocket.on).toHaveBeenCalledWith('reconnect_attempt', expect.any(Function))
  })

  it('tracks connection metrics', () => {
    const mockSocket = {
      connected: false,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
      id: 'socket-123',
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    // Connection metrics should be tracked
    expect(result.current.socketId).toBe('socket-123')
    expect(result.current.connectionAttempts).toBe(0)
  })

  it('handles message acknowledgments', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    const { result } = renderHook(() => useWebSocket())
    
    const ackCallback = vi.fn()
    
    act(() => {
      result.current.sendMessage('test', ackCallback)
    })
    
    expect(mockSocket.emit).toHaveBeenCalledWith('message', 'test', ackCallback)
  })

  it('supports heartbeat/ping functionality', () => {
    const mockSocket = {
      connected: true,
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    
    vi.mocked(require('socket.io-client').io).mockReturnValue(mockSocket)
    
    renderHook(() => useWebSocket({ heartbeat: true }))
    
    // Should set up ping/pong handlers
    expect(mockSocket.on).toHaveBeenCalledWith('ping', expect.any(Function))
    expect(mockSocket.on).toHaveBeenCalledWith('pong', expect.any(Function))
  })
})