# Enhanced Attachment Tool with MarkItDown Integration

## Overview

The Enhanced Attachment Tool is a comprehensive file processing system that provides advanced capabilities for handling file uploads, content extraction, and analysis. It integrates with MarkItDown for document parsing and includes robust security scanning, analytics, and storage management.

## Features

### 🚀 Core Capabilities
- **Multi-format Support**: PDF, Office documents (Word, Excel, PowerPoint), images, text files, CSV, JSON, XML, and more
- **MarkItDown Integration**: Advanced document parsing and content extraction
- **OCR Support**: Extract text from images and scanned documents
- **Security Scanning**: Comprehensive file validation and threat detection
- **Content Analysis**: Advanced text analysis, entity extraction, and quality scoring
- **Analytics & Monitoring**: Real-time processing analytics and performance monitoring
- **Storage Management**: Sophisticated file storage with quotas and cleanup policies

### 🛡️ Security Features
- File type validation and extension checking
- MIME type verification
- Content scanning for malicious code
- SQL injection pattern detection
- XSS prevention
- File size limits and quotas
- Quarantine for suspicious files

### 📊 Analytics & Monitoring
- Processing time tracking
- Success/failure rate monitoring
- Error categorization and analysis
- Content complexity metrics
- Performance optimization insights
- Usage pattern analysis

## Installation

### Prerequisites

1. **Python Dependencies**
```bash
pip install -r requirements.txt
```

2. **System Dependencies**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install tesseract-ocr libtesseract-dev
sudo apt-get install libmagic1

# macOS (with Homebrew)
brew install tesseract
brew install libmagic

# Windows
# Download and install Tesseract from: https://github.com/UB-Mannheim/tesseract/wiki
```

### Configuration

Add the following environment variables:

```bash
# File upload settings
UPLOAD_MAX_FILE_SIZE_MB=50
UPLOAD_ALLOWED_EXTENSIONS=pdf,docx,txt,md,jpg,jpeg,png,gif,csv,json

# Processing settings
FILE_PROCESSING_ENABLED=true
FILE_PROCESSING_TIMEOUT=300
FILE_MAX_CONCURRENT=5

# Storage settings
UPLOAD_PERMANENT_PATH=./data/uploads
UPLOAD_TEMP_PATH=./data/temp_uploads
```

## Usage Examples

### Basic File Processing

```python
from app.tools import AttachmentTool, initialize_attachment_system

# Initialize the attachment tool
await initialize_attachment_system()

attachment_tool = AttachmentTool()

# Process uploaded files
file_paths = ["/path/to/file1.pdf", "/path/to/file2.docx"]
results = await attachment_tool.process_attachments(
    file_paths=file_paths,
    session_id="user_session_123"
)

for result in results:
    print(f"File: {result['original_name']}")
    print(f"Status: {result['status']}")
    if result['processed_content']:
        print(f"Content: {result['processed_content'][:200]}...")
```

### File Validation

```python
from app.tools import FileValidator

validator = FileValidator()

# Comprehensive file validation
validation_result = validator.comprehensive_validate("/path/to/file.pdf")

if validation_result['valid']:
    print("File is valid")
else:
    print("Validation failed:")
    for error in validation_result['errors']:
        print(f"- {error}")
```

### Content Extraction

```python
# Extract text from a specific file
extraction_result = await attachment_tool.extract_text_from_file(
    file_path="/path/to/document.pdf",
    max_length=5000  # Limit to 5000 characters
)

if extraction_result['success']:
    content = extraction_result['content']
    metadata = extraction_result['metadata']
    
    print(f"Extracted {len(content)} characters")
    print(f"Document type: {metadata['file_type']}")
    print(f"Language: {metadata.get('language', 'unknown')}")
```

### Security Scanning

```python
from app.tools.attachment_tool import SecurityScanner

scanner = SecurityScanner()

# Scan file for security threats
scan_result = await scanner.scan_file("/path/to/file.pdf")

if scan_result['safe']:
    print("File is safe")
else:
    print("Security threats detected:")
    for threat in scan_result['threats']:
        print(f"- {threat}")
```

### Content Analysis

```python
from app.tools import FileAnalyzer, start_analytics_session

# Start analytics session
await start_analytics_session("analysis_session_123")

analyzer = FileAnalyzer()

# Analyze text content
analysis_result = await analyzer.analyze_text_content("Your text content here")

print(f"Word count: {analysis_result['basic_stats']['word_count']}")
print(f"Readability score: {analysis_result['complexity_metrics']['readability_score']}")

# Extract entities
for entity in analysis_result['entities']:
    print(f"Found {entity['type']}: {entity['value']}")
```

### File Storage Management

```python
from app.tools import get_storage_manager, StorageType

# Get storage manager
storage_manager = await get_storage_manager()

# Store file with metadata
record_id, file_hash = await storage_manager.store_file(
    content=file_content,
    session_id="user_session_123",
    filename="document.pdf",
    file_type="pdf",
    mime_type="application/pdf",
    storage_type=StorageType.PROCESSED,
    metadata={"source": "upload", "confidence": 0.95},
    tags=["important", "financial"]
)

# Retrieve file
file_data = await storage_manager.get_file(record_id)
if file_data:
    content = file_data['content']
    record = file_data['record']
    print(f"Retrieved: {record.original_name}")
```

### Analytics and Monitoring

```python
from app.tools import (
    record_file_processing, 
    get_comprehensive_analytics,
    get_attachment_health_status
)

# Record processing event
await record_file_processing(
    session_id="user_session_123",
    file_type="pdf",
    processing_time=2.5,
    success=True,
    file_size=1024000
)

# Get comprehensive analytics
analytics = await get_comprehensive_analytics(time_window_hours=24)

print(f"Files processed: {analytics['summary']['total_files_processed']}")
print(f"Success rate: {analytics['summary']['overall_success_rate']}%")
print(f"Active sessions: {analytics['summary']['active_sessions']}")

# Check system health
health_status = await get_attachment_health_status()
print(f"System status: {health_status['attachment_tool']}")
```

## API Reference

### AttachmentTool

#### Methods

- `process_attachments(file_paths, session_id, extract_metadata)` - Process multiple files
- `extract_text_from_file(file_path, max_length)` - Extract text from a single file
- `validate_file(file_path, max_size)` - Validate a file
- `save_uploaded_file(uploaded_file, session_id, filename)` - Save uploaded file
- `get_processing_analytics()` - Get processing statistics
- `cleanup_old_files(days)` - Clean up old files
- `health_check()` - Perform health check

### FileValidator

#### Methods

- `comprehensive_validate(file_path)` - Complete file validation
- `validate_file_extension(filename)` - Validate file extension
- `validate_file_size(file_path, extension)` - Validate file size
- `validate_mime_type(file_path)` - Validate MIME type

### ContentCleaner

#### Methods

- `clean_text_content(content, remove_excess_whitespace)` - Clean text content
- `clean_html_content(html_content)` - Clean HTML content
- `extract_structured_data(content, content_type)` - Extract structured data

### FileAnalyzer

#### Methods

- `analyze_text_content(content)` - Analyze text content and extract insights

### StorageManager

#### Methods

- `store_file(content, session_id, filename, file_type, mime_type, storage_type)` - Store file
- `get_file(record_id)` - Retrieve file
- `update_file_status(record_id, status, error_message, metadata)` - Update file status
- `get_files_by_session(session_id)` - Get files for session
- `delete_file(record_id)` - Delete file
- `archive_file(record_id)` - Archive file
- `get_comprehensive_stats()` - Get storage statistics

## File Formats Supported

### Document Formats
- **PDF**: Text extraction, metadata, tables
- **Word (DOC/DOCX)**: Text, tables, formatting, metadata
- **PowerPoint (PPT/PPTX)**: Text, slides, tables
- **Rich Text (RTF)**: Text content

### Spreadsheet Formats
- **Excel (XLS/XLSX)**: Data, formulas, multiple sheets
- **CSV/TSV**: Tabular data with delimiter detection

### Text Formats
- **Plain Text (TXT)**: UTF-8, UTF-16, various encodings
- **Markdown (MD)**: Converted to plain text
- **HTML**: Cleaned and converted to text
- **JSON**: Parsed and structured
- **XML**: Parsed and structured
- **YAML**: Parsed and structured

### Image Formats
- **JPEG/JPG**: OCR text extraction
- **PNG**: OCR text extraction
- **GIF**: OCR text extraction
- **TIFF**: OCR text extraction
- **WebP**: OCR text extraction
- **BMP**: OCR text extraction
- **SVG**: Text extraction

### Archive Formats
- **ZIP**: Content listing (limited)

## Configuration Options

### File Size Limits
```python
# In settings or environment
UPLOAD_MAX_FILE_SIZE_MB = 50  # Default: 50MB
MAX_TEXT_LENGTH = 100000      # Max characters to extract
MAX_PAGES = 50                # Max pages from large documents
CHUNK_SIZE = 8000             # Chunk size for large content
```

### Security Settings
```python
# Blocked file extensions
BLOCKED_EXTENSIONS = {
    'exe', 'dll', 'bat', 'cmd', 'com', 'scr', 'vbs', 'js', 'jar', 
    'ps1', 'sh', 'bash', 'py', 'pl', 'rb', 'php', 'asp', 'aspx'
}

# Allowed MIME types
ALLOWED_MIME_TYPES = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'image/jpeg',
    'image/png',
    # ... more types
]
```

### Storage Quotas
```python
# Storage type quotas
QUOTAS = {
    StorageType.UPLOAD: StorageQuota(
        max_files=1000,
        max_size_mb=5000,
        max_age_days=30,
        cleanup_enabled=True
    ),
    StorageType.PROCESSED: StorageQuota(
        max_files=5000,
        max_size_mb=10000,
        max_age_days=90,
        cleanup_enabled=True
    )
}
```

## Error Handling

### Common Error Types

1. **FileNotFoundError**: File doesn't exist
2. **InvalidFormatError**: Unsupported file format
3. **SizeLimitExceeded**: File too large
4. **SecurityViolation**: Security scan failed
5. **ProcessingError**: Content extraction failed
6. **StorageError**: Storage operation failed

### Error Response Format

```python
{
    "success": false,
    "error": "Processing failed",
    "error_code": "PROCESSING_ERROR",
    "details": {
        "file_type": "pdf",
        "file_size": 1024000,
        "processing_stage": "text_extraction"
    },
    "timestamp": "2024-01-01T12:00:00Z"
}
```

## Best Practices

### File Upload Security
1. Always validate file types before processing
2. Scan files for security threats
3. Implement file size limits
4. Use quarantine for suspicious files
5. Regular cleanup of temporary files

### Performance Optimization
1. Process files asynchronously
2. Use streaming for large files
3. Implement caching for repeated operations
4. Monitor processing times
5. Scale processing resources based on load

### Content Analysis
1. Clean content before analysis
2. Handle multiple encodings properly
3. Implement fallback methods for OCR
4. Cache analysis results when possible
5. Monitor analysis accuracy

### Storage Management
1. Implement proper quotas
2. Regular cleanup of old files
3. Use appropriate storage tiers
4. Monitor storage usage
5. Implement backup strategies

## Monitoring and Maintenance

### Health Checks
```python
# Check system health
health_status = await get_attachment_health_status()

if health_status['attachment_tool'] != 'healthy':
    # Handle degraded performance
    pass
```

### Cleanup Operations
```python
# Manual cleanup
await attachment_tool.cleanup_old_files(days=7)
await temp_file_manager.cleanup_temp_files(max_age_hours=24)

# Check cleanup statistics
cleanup_stats = await storage_manager.cleanup_expired_files()
```

### Analytics Monitoring
```python
# Monitor processing metrics
analytics = await get_comprehensive_analytics(time_window_hours=24)

# Check for performance issues
if analytics['performance']['status'] == 'degraded':
    # Investigate performance issues
    for issue in analytics['performance']['issues']:
        print(f"Issue: {issue['type']} - {issue['severity']}")
```

## Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   pip install -r requirements.txt
   # Install system dependencies
   sudo apt-get install tesseract-ocr libmagic1
   ```

2. **OCR Not Working**
   ```bash
   # Check Tesseract installation
   tesseract --version
   
   # Install language data
   sudo apt-get install tesseract-ocr-eng
   ```

3. **File Type Detection Issues**
   ```bash
   # Install libmagic for better MIME type detection
   sudo apt-get install libmagic1
   ```

4. **Permission Errors**
   ```bash
   # Ensure proper file permissions
   chmod 755 data/uploads
   chmod 755 data/temp_uploads
   ```

### Debug Mode

Enable debug logging:
```python
import logging
logging.getLogger('app.tools').setLevel(logging.DEBUG)
```

### Test Suite

Run the comprehensive test suite:
```bash
cd backend
python test_enhanced_attachment_tool.py
```

## Performance Tuning

### Processing Optimization
1. Adjust concurrent processing limits
2. Optimize chunk sizes for large files
3. Implement progressive processing
4. Use appropriate libraries for each format

### Storage Optimization
1. Configure appropriate storage quotas
2. Implement tiered storage
3. Regular cleanup and archival
4. Monitor disk usage

### Resource Management
1. Monitor memory usage
2. Implement resource pooling
3. Handle concurrent requests efficiently
4. Scale based on load patterns

## Security Considerations

### Input Validation
- Strict file type validation
- MIME type verification
- Content scanning
- Size limit enforcement

### Threat Prevention
- SQL injection detection
- XSS prevention
- Malicious code scanning
- Suspicious pattern detection

### Access Control
- Session-based file access
- Permission-based operations
- Audit logging
- Secure file storage

## Integration Examples

### FastAPI Integration
```python
from fastapi import FastAPI, UploadFile, File
from app.tools import AttachmentTool, initialize_attachment_system

app = FastAPI()

@app.on_event("startup")
async def startup_event():
    await initialize_attachment_system()

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    attachment_tool = AttachmentTool()
    
    # Save and process file
    file_path = await attachment_tool.save_uploaded_file(
        file, "session123", file.filename
    )
    
    results = await attachment_tool.process_attachments([file_path])
    
    return {
        "filename": file.filename,
        "status": results[0]["status"],
        "content": results[0].get("processed_content", "")
    }
```

### Background Task Integration
```python
from celery import Celery
from app.tools import AttachmentTool

celery_app = Celery('file_processing')

@celery_app.task
def process_file_async(file_path: str, session_id: str):
    attachment_tool = AttachmentTool()
    return attachment_tool.process_attachments([file_path], session_id)
```

## Support and Contributing

For issues, questions, or contributions:

1. Check the test suite for examples
2. Review the API documentation
3. Submit issues with detailed information
4. Include logs and error messages when reporting problems

---

**Version**: 3.0.0  
**Last Updated**: 2024-11-04  
**Compatibility**: Python 3.8+
