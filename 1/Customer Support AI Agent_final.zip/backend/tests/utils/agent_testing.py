"""
Agent testing framework for comprehensive agent system testing.

This module provides utilities for testing agent functionality, interactions,
and integration with other system components.
"""

import asyncio
import json
from typing import Dict, Any, List, Optional, Callable, AsyncGenerator
from datetime import datetime, timedelta
from uuid import uuid4
from unittest.mock import AsyncMock, MagicMock
import pytest


class AgentTestingFramework:
    """
    Comprehensive framework for testing AI agents and their interactions.
    """
    
    def __init__(self):
        """Initialize the agent testing framework."""
        self.mock_agents = {}
        self.agent_conversations = {}
        self.performance_metrics = {}
        self.scenarios = []
    
    # ==============================================================================
    # AGENT CREATION AND CONFIGURATION
    # ==============================================================================
    
    def create_mock_agent(self, agent_id: str = None, **config) -> Dict[str, Any]:
        """
        Create a mock agent for testing.
        
        Args:
            agent_id: Unique agent identifier
            **config: Agent configuration parameters
            
        Returns:
            Mock agent configuration
        """
        agent_id = agent_id or str(uuid4())
        
        agent = {
            "id": agent_id,
            "name": config.get("name", f"Test Agent {agent_id[:8]}"),
            "type": config.get("type", "chatbot"),  # chatbot, human, hybrid
            "status": config.get("status", "active"),
            "capabilities": config.get("capabilities", ["general_inquiry"]),
            "configuration": {
                "response_style": config.get("response_style", "professional"),
                "max_concurrent_sessions": config.get("max_concurrent_sessions", 5),
                "escalation_threshold": config.get("escalation_threshold", 3),
                "response_delay_range": config.get("response_delay_range", [0, 2]),  # seconds
                "temperature": config.get("temperature", 0.7),
                "max_tokens": config.get("max_tokens", 1000),
                "model": config.get("model", "gpt-3.5-turbo")
            },
            "performance": {
                "total_sessions_handled": 0,
                "average_response_time": 0.0,
                "satisfaction_rating": 0.0,
                "escalation_rate": 0.0,
                "accuracy_score": 0.0
            },
            "training_data": {
                "knowledge_base": config.get("knowledge_base", []),
                "conversation_history": [],
                "last_trained": datetime.utcnow()
            },
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        self.mock_agents[agent_id] = agent
        return agent
    
    def configure_agent_response(self, agent_id: str, response_patterns: List[Dict[str, Any]]):
        """
        Configure response patterns for a mock agent.
        
        Args:
            agent_id: Agent identifier
            response_patterns: List of response patterns to match
        """
        if agent_id not in self.mock_agents:
            raise ValueError(f"Agent {agent_id} not found")
        
        self.mock_agents[agent_id]["response_patterns"] = response_patterns
    
    def create_agent_pool(self, pool_name: str, num_agents: int, **config) -> Dict[str, Any]:
        """
        Create a pool of agents.
        
        Args:
            pool_name: Name of the agent pool
            num_agents: Number of agents to create
            **config: Configuration for all agents
            
        Returns:
            Agent pool configuration
        """
        pool = {
            "id": str(uuid4()),
            "name": pool_name,
            "agent_ids": [],
            "configuration": {
                "min_size": config.get("min_size", 1),
                "max_size": config.get("max_size", num_agents),
                "load_balancing": config.get("load_balancing", "round_robin"),
                "health_check_interval": config.get("health_check_interval", 30),
                "auto_scaling": config.get("auto_scaling", True)
            },
            "metrics": {
                "total_requests": 0,
                "successful_responses": 0,
                "average_response_time": 0.0,
                "current_load": 0
            },
            "created_at": datetime.utcnow()
        }
        
        for i in range(num_agents):
            agent_config = {
                "name": f"{pool_name}_Agent_{i+1}",
                "capabilities": config.get("capabilities", ["general_inquiry"]),
                **config
            }
            agent = self.create_mock_agent(**agent_config)
            pool["agent_ids"].append(agent["id"])
        
        return pool
    
    # ==============================================================================
    # CONVERSATION TESTING
    # ==============================================================================
    
    async def create_test_conversation(self, agent_id: str, user_id: str, 
                                     messages: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Create a test conversation.
        
        Args:
            agent_id: Agent identifier
            user_id: User identifier
            messages: Optional initial messages
            
        Returns:
            Conversation configuration
        """
        conversation_id = str(uuid4())
        
        conversation = {
            "id": conversation_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "status": "active",
            "messages": messages or [],
            "started_at": datetime.utcnow(),
            "last_activity": datetime.utcnow(),
            "metadata": {
                "session_id": str(uuid4()),
                "channel": "web",
                "user_agent": "test_client",
                "ip_address": "127.0.0.1"
            },
            "metrics": {
                "message_count": 0,
                "response_time_avg": 0.0,
                "user_satisfaction": None,
                "escalated": False
            }
        }
        
        self.agent_conversations[conversation_id] = conversation
        return conversation
    
    async def simulate_user_message(self, conversation_id: str, message: str, 
                                  timestamp: datetime = None) -> Dict[str, Any]:
        """
        Simulate a user message in a conversation.
        
        Args:
            conversation_id: Conversation identifier
            message: User message content
            timestamp: Message timestamp
            
        Returns:
            Message record
        """
        if conversation_id not in self.agent_conversations:
            raise ValueError(f"Conversation {conversation_id} not found")
        
        timestamp = timestamp or datetime.utcnow()
        
        message_record = {
            "id": str(uuid4()),
            "conversation_id": conversation_id,
            "sender_type": "user",
            "content": message,
            "timestamp": timestamp,
            "metadata": {
                "message_length": len(message),
                "word_count": len(message.split()),
                "sentiment": self._analyze_sentiment(message)
            }
        }
        
        self.agent_conversations[conversation_id]["messages"].append(message_record)
        self.agent_conversations[conversation_id]["metrics"]["message_count"] += 1
        self.agent_conversations[conversation_id]["last_activity"] = timestamp
        
        return message_record
    
    async def simulate_agent_response(self, conversation_id: str, response: str = None,
                                    agent_id: str = None, timestamp: datetime = None) -> Dict[str, Any]:
        """
        Simulate an agent response in a conversation.
        
        Args:
            conversation_id: Conversation identifier
            response: Agent response content
            agent_id: Agent identifier
            timestamp: Response timestamp
            
        Returns:
            Response record
        """
        if conversation_id not in self.agent_conversations:
            raise ValueError(f"Conversation {conversation_id} not found")
        
        conversation = self.agent_conversations[conversation_id]
        agent_id = agent_id or conversation["agent_id"]
        timestamp = timestamp or datetime.utcnow()
        
        # Generate response if not provided
        if response is None:
            response = await self._generate_agent_response(agent_id, conversation)
        
        response_record = {
            "id": str(uuid4()),
            "conversation_id": conversation_id,
            "sender_type": "agent",
            "sender_id": agent_id,
            "content": response,
            "timestamp": timestamp,
            "metadata": {
                "response_time_ms": self._calculate_response_time(conversation, timestamp),
                "confidence_score": self._calculate_confidence_score(response),
                "model_used": self.mock_agents.get(agent_id, {}).get("configuration", {}).get("model")
            }
        }
        
        conversation["messages"].append(response_record)
        conversation["last_activity"] = timestamp
        
        # Update agent metrics
        if agent_id in self.mock_agents:
            self._update_agent_metrics(agent_id, response_record)
        
        return response_record
    
    async def run_conversation_scenario(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run a complete conversation scenario.
        
        Args:
            scenario: Scenario configuration
            
        Returns:
            Conversation results and metrics
        """
        results = {
            "scenario_name": scenario.get("name", "Unnamed Scenario"),
            "conversation_id": None,
            "messages": [],
            "metrics": {},
            "errors": []
        }
        
        try:
            # Create conversation
            conversation = await self.create_test_conversation(
                agent_id=scenario["agent_id"],
                user_id=scenario.get("user_id", str(uuid4()))
            )
            results["conversation_id"] = conversation["id"]
            
            # Execute conversation steps
            for step in scenario.get("steps", []):
                if step["type"] == "user_message":
                    message = await self.simulate_user_message(
                        conversation_id=conversation["id"],
                        message=step["content"],
                        timestamp=datetime.utcnow()
                    )
                    results["messages"].append(message)
                
                elif step["type"] == "agent_response":
                    response = await self.simulate_agent_response(
                        conversation_id=conversation["id"],
                        response=step.get("response"),
                        agent_id=step.get("agent_id"),
                        timestamp=datetime.utcnow()
                    )
                    results["messages"].append(response)
                
                elif step["type"] == "wait":
                    await asyncio.sleep(step.get("duration", 1.0))
            
            # Calculate final metrics
            results["metrics"] = self._calculate_conversation_metrics(conversation)
            
        except Exception as e:
            results["errors"].append(str(e))
        
        return results
    
    # ==============================================================================
    # PERFORMANCE TESTING
    # ==============================================================================
    
    async def test_agent_performance(self, agent_id: str, num_requests: int = 100,
                                   concurrent_users: int = 10) -> Dict[str, Any]:
        """
        Test agent performance under load.
        
        Args:
            agent_id: Agent identifier
            num_requests: Total number of requests
            concurrent_users: Number of concurrent users
            
        Returns:
            Performance test results
        """
        results = {
            "agent_id": agent_id,
            "total_requests": num_requests,
            "concurrent_users": concurrent_users,
            "response_times": [],
            "success_rate": 0.0,
            "throughput": 0.0,
            "errors": []
        }
        
        requests_per_user = num_requests // concurrent_users
        
        async def simulate_user():
            for _ in range(requests_per_user):
                try:
                    start_time = datetime.utcnow()
                    
                    # Simulate conversation
                    conversation = await self.create_test_conversation(
                        agent_id=agent_id,
                        user_id=str(uuid4())
                    )
                    
                    await self.simulate_user_message(
                        conversation_id=conversation["id"],
                        message="Test message for performance testing"
                    )
                    
                    response = await self.simulate_agent_response(
                        conversation_id=conversation["id"]
                    )
                    
                    end_time = datetime.utcnow()
                    response_time = (end_time - start_time).total_seconds()
                    results["response_times"].append(response_time)
                    
                except Exception as e:
                    results["errors"].append(str(e))
        
        # Run concurrent users
        start_time = datetime.utcnow()
        tasks = [simulate_user() for _ in range(concurrent_users)]
        await asyncio.gather(*tasks)
        end_time = datetime.utcnow()
        
        # Calculate metrics
        total_time = (end_time - start_time).total_seconds()
        successful_requests = num_requests - len(results["errors"])
        
        results["success_rate"] = (successful_requests / num_requests) * 100
        results["throughput"] = successful_requests / total_time if total_time > 0 else 0
        
        if results["response_times"]:
            results["average_response_time"] = sum(results["response_times"]) / len(results["response_times"])
            results["min_response_time"] = min(results["response_times"])
            results["max_response_time"] = max(results["response_times"])
        
        return results
    
    async def test_agent_scalability(self, pool_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Test agent pool scalability.
        
        Args:
            pool_config: Agent pool configuration
            
        Returns:
            Scalability test results
        """
        results = {
            "pool_name": pool_config["name"],
            "load_levels": [],
            "response_times": [],
            "errors": []
        }
        
        # Test different load levels
        load_levels = [1, 5, 10, 20, 50]
        
        for load_level in load_levels:
            try:
                start_time = datetime.utcnow()
                
                # Simulate concurrent conversations
                tasks = []
                for _ in range(load_level):
                    task = asyncio.create_task(self._simulate_conversation_load(pool_config))
                    tasks.append(task)
                
                responses = await asyncio.gather(*tasks, return_exceptions=True)
                
                end_time = datetime.utcnow()
                total_time = (end_time - start_time).total_seconds()
                
                load_result = {
                    "concurrent_conversations": load_level,
                    "total_time": total_time,
                    "successful_conversations": sum(1 for r in responses if not isinstance(r, Exception)),
                    "average_time_per_conversation": total_time / load_level if load_level > 0 else 0
                }
                
                results["load_levels"].append(load_result)
                
            except Exception as e:
                results["errors"].append(f"Load level {load_level} error: {str(e)}")
        
        return results
    
    async def _simulate_conversation_load(self, pool_config: Dict[str, Any]) -> Dict[str, Any]:
        """Simulate a single conversation under load."""
        # Select random agent from pool
        agent_id = pool_config["agent_ids"][0]  # Simplified selection
        
        conversation = await self.create_test_conversation(
            agent_id=agent_id,
            user_id=str(uuid4())
        )
        
        # Simulate short conversation
        await self.simulate_user_message(conversation["id"], "Quick question")
        response = await self.simulate_agent_response(conversation["id"])
        
        return {
            "conversation_id": conversation["id"],
            "agent_id": agent_id,
            "success": True
        }
    
    # ==============================================================================
    # SCENARIO TESTING
    # ==============================================================================
    
    def create_test_scenarios(self) -> List[Dict[str, Any]]:
        """Create predefined test scenarios."""
        return [
            {
                "name": "Basic Inquiry",
                "description": "Customer asks a basic question",
                "agent_id": "basic_agent",
                "steps": [
                    {"type": "user_message", "content": "Hello, I need help with my account"},
                    {"type": "agent_response", "response": "I'd be happy to help you with your account. What specific issue are you experiencing?"},
                    {"type": "user_message", "content": "I can't login to my account"},
                    {"type": "agent_response", "response": "I understand that login issues can be frustrating. Let me help you troubleshoot this. First, can you confirm you're using the correct email address?"}
                ]
            },
            {
                "name": "Billing Issue",
                "description": "Customer has a billing problem",
                "agent_id": "billing_agent", 
                "steps": [
                    {"type": "user_message", "content": "I was charged twice for my subscription"},
                    {"type": "agent_response", "response": "I apologize for the duplicate charge. Let me look into that for you immediately."},
                    {"type": "user_message", "content": "I need this resolved quickly"},
                    {"type": "agent_response", "response": "I understand your concern. I'm initiating a refund for the duplicate charge now. You should see it within 3-5 business days."}
                ]
            },
            {
                "name": "Escalation Required",
                "description": "Issue requires human escalation",
                "agent_id": "support_agent",
                "steps": [
                    {"type": "user_message", "content": "My computer is completely broken and nothing works"},
                    {"type": "agent_response", "response": "I see this is a technical issue that requires specialized assistance. Let me connect you with our technical support team."},
                    {"type": "user_message", "content": "This is very urgent!"},
                    {"type": "agent_response", "response": "I understand the urgency. I'm escalating this to priority support right away. You'll receive a call within 15 minutes."}
                ]
            },
            {
                "name": "Multi-turn Conversation",
                "description": "Extended conversation with multiple turns",
                "agent_id": "general_agent",
                "steps": [
                    {"type": "user_message", "content": "Hi"},
                    {"type": "agent_response", "response": "Hello! How can I assist you today?"},
                    {"type": "user_message", "content": "I want to change my password"},
                    {"type": "agent_response", "response": "I can help you change your password. Are you currently logged in?"},
                    {"type": "user_message", "content": "Yes"},
                    {"type": "agent_response", "response": "Great! You can change your password by going to Account Settings > Security > Change Password. You'll need your current password and can set a new one."},
                    {"type": "user_message", "content": "Perfect, thanks!"},
                    {"type": "agent_response", "response": "You're welcome! Is there anything else I can help you with today?"}
                ]
            }
        ]
    
    async def run_scenario_batch(self, scenarios: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Run multiple scenarios in batch.
        
        Args:
            scenarios: List of scenarios to run
            
        Returns:
            Batch test results
        """
        results = {
            "total_scenarios": len(scenarios),
            "completed_scenarios": 0,
            "failed_scenarios": 0,
            "scenario_results": [],
            "overall_metrics": {}
        }
        
        for scenario in scenarios:
            try:
                result = await self.run_conversation_scenario(scenario)
                results["scenario_results"].append(result)
                
                if not result["errors"]:
                    results["completed_scenarios"] += 1
                else:
                    results["failed_scenarios"] += 1
                    
            except Exception as e:
                results["scenario_results"].append({
                    "scenario_name": scenario.get("name", "Unknown"),
                    "errors": [str(e)]
                })
                results["failed_scenarios"] += 1
        
        # Calculate overall metrics
        total_messages = sum(len(r.get("messages", [])) for r in results["scenario_results"])
        total_errors = sum(len(r.get("errors", [])) for r in results["scenario_results"])
        
        results["overall_metrics"] = {
            "total_messages": total_messages,
            "total_errors": total_errors,
            "success_rate": (results["completed_scenarios"] / results["total_scenarios"]) * 100,
            "error_rate": (total_errors / total_messages) * 100 if total_messages > 0 else 0
        }
        
        return results
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    def _analyze_sentiment(self, text: str) -> str:
        """Simple sentiment analysis for testing."""
        positive_words = ["good", "great", "excellent", "thanks", "perfect", "happy"]
        negative_words = ["bad", "terrible", "awful", "angry", "frustrated", "problem"]
        
        text_lower = text.lower()
        
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"
    
    def _calculate_response_time(self, conversation: Dict[str, Any], response_timestamp: datetime) -> float:
        """Calculate response time in milliseconds."""
        messages = conversation["messages"]
        user_messages = [m for m in messages if m["sender_type"] == "user"]
        
        if not user_messages:
            return 0.0
        
        last_user_message = max(user_messages, key=lambda x: x["timestamp"])
        time_diff = (response_timestamp - last_user_message["timestamp"]).total_seconds()
        
        return time_diff * 1000  # Convert to milliseconds
    
    def _calculate_confidence_score(self, response: str) -> float:
        """Calculate confidence score for agent response."""
        # Simple confidence calculation based on response characteristics
        base_confidence = 0.7
        
        # Adjust based on response length
        if len(response) > 10:
            base_confidence += 0.1
        
        # Adjust based on response quality indicators
        response_lower = response.lower()
        quality_indicators = ["i understand", "i can help", "let me", "i'll"]
        
        for indicator in quality_indicators:
            if indicator in response_lower:
                base_confidence += 0.05
        
        return min(base_confidence, 1.0)
    
    def _update_agent_metrics(self, agent_id: str, response_record: Dict[str, Any]):
        """Update agent performance metrics."""
        if agent_id not in self.mock_agents:
            return
        
        agent = self.mock_agents[agent_id]
        metrics = agent["performance"]
        
        # Update response count
        metrics["total_sessions_handled"] += 1
        
        # Update average response time
        response_time = response_record["metadata"]["response_time_ms"]
        current_avg = metrics["average_response_time"]
        new_avg = ((current_avg * (metrics["total_sessions_handled"] - 1)) + response_time) / metrics["total_sessions_handled"]
        metrics["average_response_time"] = new_avg
    
    async def _generate_agent_response(self, agent_id: str, conversation: Dict[str, Any]) -> str:
        """Generate agent response based on agent configuration."""
        if agent_id not in self.mock_agents:
            return "I apologize, but I'm having technical difficulties right now."
        
        agent = self.mock_agents[agent_id]
        agent_type = agent["type"]
        
        # Generate response based on agent type and last message
        last_message = None
        for msg in reversed(conversation["messages"]):
            if msg["sender_type"] == "user":
                last_message = msg
                break
        
        if not last_message:
            return "Hello! How can I assist you today?"
        
        user_message = last_message["content"].lower()
        
        # Simple rule-based responses for testing
        if "hello" in user_message or "hi" in user_message:
            return "Hello! How can I help you today?"
        elif "help" in user_message:
            return "I'd be happy to help you with that. Could you please provide more details about what you need assistance with?"
        elif "problem" in user_message or "issue" in user_message:
            return "I understand you're experiencing a problem. Let me help you resolve this issue. What specifically is not working as expected?"
        elif "thank" in user_message:
            return "You're very welcome! Is there anything else I can help you with?"
        else:
            # Default responses based on agent capabilities
            capabilities = agent["capabilities"]
            if "billing" in capabilities:
                return "I can help you with billing-related questions. Could you please provide more details about your billing concern?"
            elif "technical" in capabilities:
                return "I can assist with technical issues. Can you describe the technical problem you're experiencing?"
            else:
                return "I understand. Let me think about how best to help you with this situation."
    
    def _calculate_conversation_metrics(self, conversation: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate metrics for a completed conversation."""
        messages = conversation["messages"]
        
        if not messages:
            return {}
        
        # Basic metrics
        user_messages = [m for m in messages if m["sender_type"] == "user"]
        agent_messages = [m for m in messages if m["sender_type"] == "agent"]
        
        # Response times
        response_times = []
        for agent_msg in agent_messages:
            if "metadata" in agent_msg and "response_time_ms" in agent_msg["metadata"]:
                response_times.append(agent_msg["metadata"]["response_time_ms"])
        
        # Conversation duration
        start_time = messages[0]["timestamp"]
        end_time = messages[-1]["timestamp"]
        duration = (end_time - start_time).total_seconds()
        
        metrics = {
            "total_messages": len(messages),
            "user_messages": len(user_messages),
            "agent_messages": len(agent_messages),
            "conversation_duration_seconds": duration,
            "average_response_time_ms": sum(response_times) / len(response_times) if response_times else 0,
            "response_time_range": {
                "min_ms": min(response_times) if response_times else 0,
                "max_ms": max(response_times) if response_times else 0
            },
            "message_frequency": len(messages) / duration if duration > 0 else 0
        }
        
        return metrics