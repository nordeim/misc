"""
Comprehensive Test Suite for Embedding Service.

This test suite validates all aspects of the embedding service:
- Basic embedding generation
- Batch processing capabilities
- Model management and caching
- Performance monitoring
- Error handling and recovery
- Integration with RAG tool

Tests include:
- Unit tests for individual components
- Integration tests for the full service
- Performance tests for throughput
- Error handling tests
- Memory management tests

Author: AI Agent System
Version: 2.0.0
"""

import asyncio
import json
import logging
import pytest
import time
import tempfile
from pathlib import Path
from typing import List, Dict, Any
from unittest.mock import Mock, patch, AsyncMock

# Import embedding service components
from app.services.embedding_service import (
    EmbeddingService, ModelManager, EmbeddingCache, TextPreprocessor,
    EmbeddingResult, BatchProcessingResult, PerformanceMetrics
)
from app.services.embedding_utils import (
    TextPreprocessingUtils, SimilarityUtils, ValidationUtils,
    AnalyticsUtils, VisualizationUtils, ExportImportUtils
)
from app.services.batch_processing import (
    BatchProcessor, BatchJob, BatchStatus, Priority, create_batch_processor
)
from app.services.model_management import (
    ModelManager as AdvancedModelManager, ModelRegistry, ModelDownloadManager,
    ModelPerformanceMonitor, MemoryOptimizer
)

# Configure logging for tests
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==============================================================================
# TEST FIXTURES AND HELPERS
# ==============================================================================

@pytest.fixture
async def embedding_service():
    """Create and initialize embedding service for testing."""
    service = EmbeddingService()
    await service.initialize()
    yield service
    await service.shutdown()

@pytest.fixture
async def model_manager():
    """Create and initialize model manager for testing."""
    manager = AdvancedModelManager()
    await manager.initialize()
    yield manager
    await manager.shutdown()

@pytest.fixture
async def batch_processor(embedding_service):
    """Create and initialize batch processor for testing."""
    processor = await create_batch_processor(embedding_service, max_workers=2)
    await processor.initialize()
    yield processor
    await processor.shutdown()

@pytest.fixture
def sample_texts():
    """Sample texts for testing."""
    return [
        "The quick brown fox jumps over the lazy dog.",
        "Machine learning is a subset of artificial intelligence.",
        "Natural language processing enables computers to understand human language.",
        "Deep learning uses neural networks with multiple layers.",
        "Vector embeddings represent text as numerical vectors.",
        "Sentence transformers are models that encode sentences into vectors.",
        "Embedding similarity measures how alike two text embeddings are.",
        "Batch processing improves efficiency when processing multiple texts."
    ]

@pytest.fixture
def sample_embeddings():
    """Sample embeddings for testing."""
    import numpy as np
    return [
        ([0.1, 0.2, 0.3, 0.4] + [0.0] * 380, "embedding_1"),
        ([0.2, 0.3, 0.4, 0.5] + [0.0] * 380, "embedding_2"),
        ([0.3, 0.4, 0.5, 0.6] + [0.0] * 380, "embedding_3"),
        ([0.4, 0.5, 0.6, 0.7] + [0.0] * 380, "embedding_4"),
        ([0.5, 0.6, 0.7, 0.8] + [0.0] * 380, "embedding_5")
    ]

# ==============================================================================
# UNIT TESTS
# ==============================================================================

class TestTextPreprocessor:
    """Test text preprocessing utilities."""
    
    def test_basic_cleaning(self):
        """Test basic text cleaning."""
        preprocessor = TextPreprocessor()
        
        # Test basic cleaning
        text = "  Hello   World!  \n\nThis is a test.  "
        cleaned, stats = preprocessor.clean_basic(text)
        
        assert "Hello World!" in cleaned
        assert "This is a test." in cleaned
        assert stats.original_length > stats.processed_length
        assert len(stats.preprocessing_steps) > 0
    
    def test_advanced_cleaning(self):
        """Test advanced text cleaning."""
        preprocessor = TextPreprocessor()
        
        text = "Hello!!! This is a test... with multiple spaces   and special chars @#$%"
        cleaned, stats = preprocessor.clean_advanced(text)
        
        assert "!!!" not in cleaned  # Multiple punctuation normalized
        assert stats.character_reduction > 0
        assert "normalized_punctuation" in stats.preprocessing_steps
    
    def test_optimization_for_embedding(self):
        """Test text optimization for embeddings."""
        preprocessor = TextPreprocessor()
        
        # Test length optimization
        long_text = " ".join(["word"] * 1000)
        optimized, info = preprocessor.optimize_for_embedding(long_text, max_length=100)
        
        assert len(optimized) <= 400  # Allow for words + spaces
        assert info["truncated"] is True
        assert "length_optimization" in info["cleaning_stats"]["preprocessing_steps"]

class TestSimilarityUtils:
    """Test similarity calculation utilities."""
    
    def test_pairwise_similarity(self):
        """Test pairwise similarity calculation."""
        utils = SimilarityUtils
        
        # Create sample embeddings
        embedding1 = [0.1, 0.2, 0.3, 0.4] + [0.0] * 380
        embedding2 = [0.2, 0.3, 0.4, 0.5] + [0.0] * 380
        
        # Test cosine similarity
        sim_matrix = utils.calculate_pairwise_similarity([embedding1, embedding2], metric='cosine')
        
        assert sim_matrix.shape == (1, 2)
        assert sim_matrix[0, 0] == 1.0  # Self-similarity
        assert sim_matrix[0, 1] < 1.0  # Different embeddings
    
    def test_find_most_similar(self, sample_embeddings):
        """Test finding most similar embeddings."""
        utils = SimilarityUtils
        
        query_embedding = [0.15, 0.25, 0.35, 0.45] + [0.0] * 380
        candidates = [(f"emb_{i}", emb) for i, (emb, _) in enumerate(sample_embeddings)]
        
        results = utils.find_most_similar(query_embedding, candidates, top_k=3)
        
        assert len(results) == 3
        assert all(result.similarity_score >= 0 for result in results)
        # Results should be sorted by similarity (descending)
        for i in range(len(results) - 1):
            assert results[i].similarity_score >= results[i + 1].similarity_score

class TestValidationUtils:
    """Test embedding validation utilities."""
    
    def test_embedding_quality_validation(self, sample_embeddings):
        """Test embedding quality validation."""
        utils = ValidationUtils
        
        # Extract embedding vectors
        embeddings = [emb for emb, _ in sample_embeddings]
        
        # Test validation
        report = utils.validate_embedding_quality(embeddings)
        
        assert report.valid is True
        assert len(report.issues) == 0
        assert "n_embeddings" in report.statistics
        assert "dimension" in report.statistics
        assert report.quality_score > 0
    
    def test_invalid_embedding_detection(self):
        """Test detection of invalid embeddings."""
        utils = ValidationUtils
        
        # Create invalid embeddings
        invalid_embeddings = [
            [0.1, 0.2, 0.3, float('nan')],  # NaN values
            [0.1, 0.2, 0.3, float('inf')],  # Infinite values
            [0.0, 0.0, 0.0, 0.0],  # Zero vector
        ]
        
        report = utils.validate_embedding_quality(invalid_embeddings)
        
        assert report.valid is False
        assert len(report.issues) > 0
        assert any("NaN" in issue or "infinite" in issue or "zero" in issue 
                  for issue in report.issues)
    
    def test_benchmark_embeddings(self, sample_embeddings):
        """Test embedding benchmarking."""
        utils = ValidationUtils
        
        # Extract embedding vectors
        embeddings = [emb for emb, _ in sample_embeddings]
        
        # Run benchmark
        benchmark = utils.benchmark_embeddings(embeddings, metrics=['cosine', 'euclidean'])
        
        assert "n_embeddings" in benchmark
        assert "metrics" in benchmark
        assert "cosine" in benchmark["metrics"]
        assert "euclidean" in benchmark["metrics"]
        assert benchmark["n_embeddings"] == len(embeddings)

# ==============================================================================
# INTEGRATION TESTS
# ==============================================================================

class TestEmbeddingService:
    """Test the main embedding service."""
    
    @pytest.mark.asyncio
    async def test_service_initialization(self, embedding_service):
        """Test service initialization."""
        assert embedding_service is not None
        assert embedding_service.model_manager is not None
        assert embedding_service.cache is not None
        assert embedding_service.preprocessor is not None
    
    @pytest.mark.asyncio
    async def test_single_embedding_generation(self, embedding_service, sample_texts):
        """Test single embedding generation."""
        text = sample_texts[0]
        
        result = await embedding_service.generate_embedding(text)
        
        assert isinstance(result, EmbeddingResult)
        assert len(result.embedding) > 0
        assert result.text == text
        assert result.processing_time > 0
        assert result.dimension > 0
    
    @pytest.mark.asyncio
    async def test_batch_embedding_generation(self, embedding_service, sample_texts):
        """Test batch embedding generation."""
        # Use small batch for faster testing
        batch_texts = sample_texts[:3]
        
        result = await embedding_service.generate_embeddings_batch(batch_texts)
        
        assert isinstance(result, BatchProcessingResult)
        assert result.total_texts == len(batch_texts)
        assert len(result.results) == result.successful
        assert result.successful > 0
        assert result.processing_time > 0
        
        # Check that all results are valid
        for embedding_result in result.results:
            assert len(embedding_result.embedding) > 0
            assert isinstance(embedding_result.embedding, list)
            assert all(isinstance(x, (int, float)) for x in embedding_result.embedding)
    
    @pytest.mark.asyncio
    async def test_embedding_caching(self, embedding_service, sample_texts):
        """Test embedding caching functionality."""
        text = sample_texts[0]
        
        # First generation (cache miss)
        result1 = await embedding_service.generate_embedding(text, use_cache=True)
        assert result1.cache_hit is False
        
        # Second generation (cache hit)
        result2 = await embedding_service.generate_embedding(text, use_cache=True)
        assert result2.cache_hit is True
        
        # Embeddings should be identical
        assert result1.embedding == result2.embedding
        assert result1.processing_time >= result2.processing_time  # Cache hit should be faster
    
    @pytest.mark.asyncio
    async def test_similarity_calculation(self, embedding_service, sample_texts):
        """Test similarity calculation between embeddings."""
        # Generate embeddings for two similar texts
        text1 = "The quick brown fox jumps over the lazy dog"
        text2 = "A fast brown fox leaps over a sleeping dog"
        
        result1 = await embedding_service.generate_embedding(text1)
        result2 = await embedding_service.generate_embedding(text2)
        
        # Calculate similarity
        similarity = embedding_service.calculate_similarity(
            result1.embedding, result2.embedding, metric="cosine"
        )
        
        assert isinstance(similarity, float)
        assert 0.0 <= similarity <= 1.0
        # Similar texts should have relatively high similarity
        assert similarity > 0.3
    
    @pytest.mark.asyncio
    async def test_error_handling(self, embedding_service):
        """Test error handling for invalid inputs."""
        # Test empty text
        with pytest.raises(Exception):
            await embedding_service.generate_embedding("")
        
        # Test None text
        with pytest.raises(Exception):
            await embedding_service.generate_embedding(None)
        
        # Test invalid model name (should fallback)
        try:
            result = await embedding_service.generate_embedding(
                "Test text", model_name="invalid-model-name"
            )
            # Should either fail or fallback to a working model
            assert result is not None
        except Exception:
            # Expected if no fallback is available
            pass

class TestBatchProcessor:
    """Test batch processing capabilities."""
    
    @pytest.mark.asyncio
    async def test_batch_submission(self, batch_processor, sample_texts):
        """Test batch job submission."""
        # Submit a batch job
        job_id = await batch_processor.submit_batch(
            texts=sample_texts[:3],
            priority=Priority.NORMAL
        )
        
        assert job_id is not None
        assert len(job_id) > 0
        
        # Check job status
        job = await batch_processor.get_job_status(job_id)
        assert job is not None
        assert job.job_id == job_id
        assert job.status in [BatchStatus.PENDING, BatchStatus.RUNNING]
    
    @pytest.mark.asyncio
    async def test_batch_processing_completion(self, batch_processor, sample_texts):
        """Test complete batch processing workflow."""
        # Submit batch
        job_id = await batch_processor.submit_batch(
            texts=sample_texts[:2],  # Small batch for faster testing
            priority=Priority.HIGH
        )
        
        # Wait for completion
        max_wait_time = 60  # 1 minute timeout
        start_time = time.time()
        
        while time.time() - start_time < max_wait_time:
            job = await batch_processor.get_job_status(job_id)
            
            if job and job.status in [BatchStatus.COMPLETED, BatchStatus.FAILED]:
                break
            
            await asyncio.sleep(1)
        
        # Check final status
        job = await batch_processor.get_job_status(job_id)
        assert job is not None
        assert job.status == BatchStatus.COMPLETED
        assert job.successful_items > 0
        assert len(job.results) > 0
    
    @pytest.mark.asyncio
    async def test_job_cancellation(self, batch_processor, sample_texts):
        """Test job cancellation."""
        # Submit a batch job
        job_id = await batch_processor.submit_batch(
            texts=sample_texts[:5],
            priority=Priority.LOW
        )
        
        # Cancel the job
        cancelled = await batch_processor.cancel_job(job_id)
        assert cancelled is True
        
        # Check status
        job = await batch_processor.get_job_status(job_id)
        assert job.status == BatchStatus.CANCELLED
    
    @pytest.mark.asyncio
    async def test_progress_tracking(self, batch_processor, sample_texts):
        """Test progress tracking functionality."""
        progress_updates = []
        
        def progress_callback(progress):
            progress_updates.append(progress)
        
        # Submit batch with progress callback
        job_id = await batch_processor.submit_batch(
            texts=sample_texts[:2],
            priority=Priority.NORMAL
        )
        
        batch_processor.add_progress_callback(job_id, progress_callback)
        
        # Wait for completion
        max_wait_time = 30
        start_time = time.time()
        
        while time.time() - start_time < max_wait_time:
            job = await batch_processor.get_job_status(job_id)
            if job and job.status in [BatchStatus.COMPLETED, BatchStatus.FAILED]:
                break
            await asyncio.sleep(0.5)
        
        # Check progress updates
        assert len(progress_updates) > 0
        assert any(update.progress_percentage >= 0 for update in progress_updates)

class TestModelManagement:
    """Test model management functionality."""
    
    @pytest.mark.asyncio
    async def test_model_loading(self, model_manager):
        """Test model loading and caching."""
        # Test loading primary model
        model = await model_manager.get_model()
        assert model is not None
        
        # Test loading specific model
        model2 = await model_manager.load_model("sentence-transformers/all-MiniLM-L6-v2")
        assert model2 is not None
        
        # Test model caching (second load should be faster)
        start_time = time.time()
        await model_manager.load_model("sentence-transformers/all-MiniLM-L6-v2")
        load_time = time.time() - start_time
        
        assert load_time < 1.0  # Should be fast due to caching
    
    @pytest.mark.asyncio
    async def test_model_search(self, model_manager):
        """Test model search functionality."""
        # Search for models
        models = await model_manager.search_models(
            query="sentence-transformers",
            min_downloads=0
        )
        
        assert isinstance(models, list)
        assert len(models) > 0
        
        # Check model attributes
        for model_entry in models:
            assert hasattr(model_entry, 'model_id')
            assert hasattr(model_entry, 'metadata')
            assert hasattr(model_entry, 'performance_metrics')
    
    @pytest.mark.asyncio
    async def test_performance_monitoring(self, model_manager):
        """Test performance monitoring."""
        # Load a model to generate performance data
        model = await model_manager.get_model()
        
        # Get performance metrics
        performance = await model_manager.get_model_performance("sentence-transformers/all-MiniLM-L6-v2")
        
        # Performance data should be available after model usage
        assert performance is not None
        assert hasattr(performance, 'inference_time_ms')
        assert hasattr(performance, 'memory_usage_mb')
    
    @pytest.mark.asyncio
    async def test_system_status(self, model_manager):
        """Test system status reporting."""
        status = await model_manager.get_system_status()
        
        assert isinstance(status, dict)
        assert "loaded_models" in status
        assert "registry" in status
        assert "performance" in status
        assert "system" in status
        
        assert "count" in status["loaded_models"]
        assert "model_ids" in status["loaded_models"]
        assert status["loaded_models"]["count"] >= 0

# ==============================================================================
# PERFORMANCE TESTS
# ==============================================================================

class TestPerformance:
    """Test performance characteristics."""
    
    @pytest.mark.asyncio
    async def test_throughput_benchmark(self, embedding_service):
        """Test embedding generation throughput."""
        # Create test dataset
        texts = [f"Test document number {i} contains various content for embedding." 
                for i in range(100)]
        
        start_time = time.time()
        result = await embedding_service.generate_embeddings_batch(texts, batch_size=10)
        end_time = time.time()
        
        total_time = end_time - start_time
        throughput = len(texts) / total_time
        
        # Performance assertions (adjust based on your environment)
        assert throughput > 1.0  # At least 1 embedding per second
        assert result.successful >= len(texts) * 0.9  # 90% success rate
    
    @pytest.mark.asyncio
    async def test_memory_usage(self, embedding_service):
        """Test memory usage during processing."""
        # Generate many embeddings
        large_dataset = [f"Document {i}" for i in range(1000)]
        
        # Record initial memory
        import psutil
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024
        
        # Process dataset
        result = await embedding_service.generate_embeddings_batch(
            large_dataset, batch_size=100
        )
        
        # Check final memory
        final_memory = process.memory_info().rss / 1024 / 1024
        memory_increase = final_memory - initial_memory
        
        # Memory increase should be reasonable (less than 500MB)
        assert memory_increase < 500
        assert result.successful > 0
    
    @pytest.mark.asyncio
    async def test_caching_performance(self, embedding_service, sample_texts):
        """Test caching performance improvement."""
        text = sample_texts[0]
        
        # First generation (no cache)
        start_time = time.time()
        result1 = await embedding_service.generate_embedding(text, use_cache=False)
        first_time = time.time() - start_time
        
        # Second generation (with cache)
        start_time = time.time()
        result2 = await embedding_service.generate_embedding(text, use_cache=True)
        cached_time = time.time() - start_time
        
        # Cached version should be significantly faster
        assert cached_time < first_time * 0.5  # At least 50% faster
        assert result1.embedding == result2.embedding

# ==============================================================================
# ERROR HANDLING TESTS
# ==============================================================================

class TestErrorHandling:
    """Test error handling and recovery."""
    
    @pytest.mark.asyncio
    async def test_invalid_model_handling(self, embedding_service):
        """Test handling of invalid model names."""
        # Test with invalid model name
        try:
            result = await embedding_service.generate_embedding(
                "Test text", 
                model_name="non-existent-model-12345"
            )
            # If it doesn't fail, that's also acceptable (fallback mechanism)
            assert result is not None
        except Exception as e:
            # Expected to fail with meaningful error
            assert "fail" in str(e).lower() or "not found" in str(e).lower()
    
    @pytest.mark.asyncio
    async def test_empty_input_handling(self, embedding_service):
        """Test handling of empty or invalid inputs."""
        # Test empty text
        with pytest.raises(Exception):
            await embedding_service.generate_embedding("")
        
        # Test None input
        with pytest.raises(Exception):
            await embedding_service.generate_embedding(None)
        
        # Test empty batch
        result = await embedding_service.generate_embeddings_batch([])
        assert result.total_texts == 0
        assert result.successful == 0
    
    @pytest.mark.asyncio
    async def test_large_batch_error_handling(self, embedding_service):
        """Test handling of very large batches."""
        # Create a very large batch
        large_batch = ["Test text"] * 10000
        
        # This should either succeed or fail gracefully
        try:
            result = await embedding_service.generate_embeddings_batch(
                large_batch, batch_size=1000
            )
            assert result.total_texts == len(large_batch)
        except Exception as e:
            # Should fail with meaningful error message
            assert "memory" in str(e).lower() or "size" in str(e).lower() or "large" in str(e).lower()

# ==============================================================================
# INTEGRATION TESTS WITH RAG
# ==============================================================================

class TestRAGIntegration:
    """Test integration with RAG system."""
    
    @pytest.mark.asyncio
    async def test_rag_tool_compatibility(self, embedding_service):
        """Test compatibility with RAG tool."""
        # Test that embedding service can be used by RAG tool
        # (This would typically test integration points)
        
        # Generate embeddings in RAG-compatible format
        text = "This is a test document for RAG processing."
        result = await embedding_service.generate_embedding(text)
        
        # RAG tool expects certain format
        assert hasattr(result, 'embedding')
        assert hasattr(result, 'text')
        assert isinstance(result.embedding, list)
        assert len(result.embedding) > 0
    
    @pytest.mark.asyncio
    async def test_batch_rag_processing(self, embedding_service):
        """Test batch processing for RAG workflows."""
        # Simulate RAG document processing
        documents = [
            "Document 1: Machine learning introduction",
            "Document 2: Deep learning fundamentals",
            "Document 3: Neural networks basics"
        ]
        
        # Process as RAG would
        result = await embedding_service.generate_embeddings_batch(documents)
        
        assert result.total_texts == len(documents)
        assert result.successful == len(documents)
        
        # Check that all results are suitable for vector storage
        for embedding_result in result.results:
            assert len(embedding_result.embedding) == result.results[0].dimension
            assert all(isinstance(x, float) for x in embedding_result.embedding)

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

async def run_comprehensive_test_suite():
    """Run a comprehensive test suite for the embedding service."""
    logger.info("Starting comprehensive embedding service test suite...")
    
    test_results = {
        "passed": 0,
        "failed": 0,
        "errors": []
    }
    
    try:
        # Initialize services
        logger.info("Initializing services...")
        async with EmbeddingService() as service:
            logger.info("Testing basic functionality...")
            
            # Test basic embedding generation
            test_text = "This is a test sentence for embedding generation."
            result = await service.generate_embedding(test_text)
            
            if result and len(result.embedding) > 0:
                test_results["passed"] += 1
                logger.info("✓ Basic embedding generation passed")
            else:
                test_results["failed"] += 1
                logger.error("✗ Basic embedding generation failed")
            
            # Test batch processing
            texts = ["Test 1", "Test 2", "Test 3"]
            batch_result = await service.generate_embeddings_batch(texts)
            
            if batch_result and batch_result.successful == len(texts):
                test_results["passed"] += 1
                logger.info("✓ Batch processing passed")
            else:
                test_results["failed"] += 1
                logger.error("✗ Batch processing failed")
            
            # Test similarity calculation
            result1 = await service.generate_embedding("Similar text 1")
            result2 = await service.generate_embedding("Similar text 2")
            
            similarity = service.calculate_similarity(result1.embedding, result2.embedding)
            
            if isinstance(similarity, float) and 0.0 <= similarity <= 1.0:
                test_results["passed"] += 1
                logger.info("✓ Similarity calculation passed")
            else:
                test_results["failed"] += 1
                logger.error("✗ Similarity calculation failed")
            
            # Test analytics
            analytics = await service.get_analytics()
            
            if analytics and "global_metrics" in analytics:
                test_results["passed"] += 1
                logger.info("✓ Analytics generation passed")
            else:
                test_results["failed"] += 1
                logger.error("✗ Analytics generation failed")
        
        logger.info(f"Test suite completed: {test_results['passed']} passed, {test_results['failed']} failed")
        
    except Exception as e:
        test_results["errors"].append(str(e))
        logger.error(f"Test suite failed with error: {e}")
    
    return test_results

if __name__ == "__main__":
    # Run the comprehensive test suite
    results = asyncio.run(run_comprehensive_test_suite())
    
    # Print results
    print("\n" + "="*50)
    print("EMBEDDING SERVICE TEST RESULTS")
    print("="*50)
    print(f"Tests Passed: {results['passed']}")
    print(f"Tests Failed: {results['failed']}")
    
    if results['errors']:
        print(f"Errors: {len(results['errors'])}")
        for error in results['errors']:
            print(f"  - {error}")
    
    success_rate = results['passed'] / (results['passed'] + results['failed']) * 100
    print(f"Success Rate: {success_rate:.1f}%")
    print("="*50)