"""
Comprehensive unit tests for all agents in the backend.

This test module covers:
- Agent Factory (agent creation, management, lifecycle)
- Agent Utils (utility functions, helpers, validators)
- Chat Agent (conversation handling, context management, tool orchestration)
- Monitoring Integration (metrics collection, health monitoring, observability)

Uses pytest fixtures from conftest.py and test utilities from utils package.
"""

import pytest
import asyncio
import json
import time
import uuid
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch, MagicMock, call
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, field

# Import all agents to test
from app.agents.agent_factory import (
    AgentFactory,
    AgentInstance,
    AgentConfig,
    AgentTemplate,
    AgentLifecycleManager,
    AgentSpawner,
    AgentRegistry
)
from app.agents.agent_utils import (
    AgentUtils,
    ContextManager,
    IntentClassifier,
    ResponseGenerator,
    ToolSelector,
    ConversationManager,
    MetricsCollector,
    ValidationHelper
)
from app.agents.chat_agent import (
    ChatAgent,
    AgentContext,
    AgentState,
    EscalationType,
    ToolExecutionStatus,
    MessageProcessor,
    ConversationFlow,
    ToolOrchestrator,
    ResponseBuilder
)
from app.agents.monitoring_integration import (
    MonitoringIntegration,
    AgentMetrics,
    HealthMonitor,
    PerformanceTracker,
    ErrorTracker,
    MetricsAggregator,
    AlertManager,
    DashboardProvider
)

# Import dependencies from tools and services
from app.tools.rag_tool import RAGTool
from app.tools.memory_tool import MemoryTool
from app.tools.attachment_tool import AttachmentTool
from app.tools.escalation_tool import EscalationTool

# Import test utilities
from tests.utils.test_data_generator import TestDataGenerator
from tests.utils.auth_helpers import AuthTestHelper
from tests.utils.performance_testing import PerformanceProfiler
from tests.utils.agent_testing import AgentTestHelper


# =============================================================================
# AGENT FACTORY TESTS
# =============================================================================

class TestAgentFactory:
    """Test agent factory functionality."""
    
    @pytest.fixture
    def agent_factory(self):
        """Create agent factory instance."""
        return AgentFactory()
    
    @pytest.fixture
    def agent_config(self):
        """Create agent configuration."""
        return AgentConfig(
            name="test_agent",
            version="1.0.0",
            agent_type="chat",
            max_instances=5,
            resource_limits={
                "memory": "512MB",
                "cpu": "0.5",
                "timeout": 30
            },
            capabilities=["text_generation", "tool_usage", "memory_access"]
        )
    
    @pytest.mark.asyncio
    async def test_agent_creation(self, agent_factory, agent_config):
        """Test agent creation functionality."""
        # Create agent instance
        agent_instance = await agent_factory.create_agent(agent_config)
        
        assert isinstance(agent_instance, AgentInstance)
        assert agent_instance.config.name == "test_agent"
        assert agent_instance.config.agent_type == "chat"
        assert agent_instance.state == "created"
        assert agent_instance.id is not None
    
    @pytest.mark.asyncio
    async def test_agent_lifecycle_management(self, agent_factory, agent_config):
        """Test agent lifecycle management."""
        # Create agent
        agent_instance = await agent_factory.create_agent(agent_config)
        
        # Test lifecycle transitions
        await agent_factory.initialize_agent(agent_instance.id)
        assert agent_instance.state == "initialized"
        
        await agent_factory.start_agent(agent_instance.id)
        assert agent_instance.state == "running"
        
        await agent_factory.stop_agent(agent_instance.id)
        assert agent_instance.state == "stopped"
        
        await agent_factory.dispose_agent(agent_instance.id)
        assert agent_instance.state == "disposed"
    
    @pytest.mark.asyncio
    async def test_agent_spawning(self, agent_factory, agent_config):
        """Test agent spawning functionality."""
        spawner = AgentSpawner(agent_factory)
        
        # Test single agent spawn
        agent = await spawner.spawn_agent(agent_config)
        assert agent is not None
        assert agent.state == "initialized"
        
        # Test multiple agent spawn
        agents = await spawner.spawn_multiple(agent_config, count=3)
        assert len(agents) == 3
        assert all(agent.state == "initialized" for agent in agents)
        
        # Test spawn with limits
        max_config = AgentConfig(
            name="limited_agent",
            agent_type="chat",
            max_instances=2
        )
        
        agents = await spawner.spawn_multiple(max_config, count=5)
        assert len(agents) <= 2  # Respects max_instances limit
    
    @pytest.mark.asyncio
    async def test_agent_registry(self, agent_factory, agent_config):
        """Test agent registry functionality."""
        registry = AgentRegistry(agent_factory)
        
        # Register agent template
        template = AgentTemplate(
            name="template_agent",
            config=agent_config,
            description="Test agent template",
            version="1.0.0"
        )
        
        await registry.register_template(template)
        assert "template_agent" in registry.templates
        
        # Create agent from template
        created_agent = await registry.create_from_template("template_agent")
        assert created_agent.config.name == "test_agent"
        
        # List registered templates
        templates = await registry.list_templates()
        assert len(templates) > 0
        assert any(t.name == "template_agent" for t in templates)
    
    @pytest.mark.asyncio
    async def test_agent_load_balancing(self, agent_factory):
        """Test agent load balancing functionality."""
        # Create multiple agent instances
        configs = []
        for i in range(5):
            config = AgentConfig(
                name=f"load_balancer_test_{i}",
                agent_type="chat",
                capabilities=["text_generation"]
            )
            configs.append(config)
            await agent_factory.create_agent(config)
        
        # Test load balancing selection
        selected_agent = await agent_factory.select_agent(
            agent_type="chat",
            capabilities=["text_generation"]
        )
        
        assert selected_agent is not None
        assert selected_agent.config.agent_type == "chat"
    
    def test_agent_config_validation(self, agent_factory):
        """Test agent configuration validation."""
        # Valid configuration
        valid_config = AgentConfig(
            name="valid_agent",
            agent_type="chat",
            max_instances=3,
            resource_limits={"memory": "256MB", "cpu": "0.5"}
        )
        
        is_valid, errors = agent_factory.validate_config(valid_config)
        assert is_valid is True
        assert len(errors) == 0
        
        # Invalid configuration
        invalid_config = AgentConfig(
            name="",  # Empty name
            agent_type="unknown_type",  # Invalid type
            max_instances=-1  # Negative max instances
        )
        
        is_valid, errors = agent_factory.validate_config(invalid_config)
        assert is_valid is False
        assert len(errors) > 0


# =============================================================================
# AGENT UTILS TESTS
# =============================================================================

class TestAgentUtils:
    """Test agent utility functions."""
    
    @pytest.fixture
    def agent_utils(self):
        """Create agent utils instance."""
        return AgentUtils()
    
    @pytest.mark.asyncio
    async def test_context_manager(self, agent_utils):
        """Test context management functionality."""
        context_manager = ContextManager()
        
        # Create context
        context = AgentContext(
            session_id="test_session_123",
            user_id="user_456"
        )
        
        await context_manager.store_context(context)
        
        # Retrieve context
        retrieved_context = await context_manager.get_context("test_session_123")
        assert retrieved_context is not None
        assert retrieved_context.session_id == "test_session_123"
        assert retrieved_context.user_id == "user_456"
        
        # Update context
        retrieved_context.add_message({
            "role": "user",
            "content": "Hello",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        await context_manager.update_context(retrieved_context)
        
        # Verify update
        updated_context = await context_manager.get_context("test_session_123")
        assert len(updated_context.message_history) == 1
        
        # Cleanup
        await context_manager.cleanup_context("test_session_123")
        cleaned_context = await context_manager.get_context("test_session_123")
        assert cleaned_context is None
    
    @pytest.mark.asyncio
    async def test_intent_classification(self, agent_utils):
        """Test intent classification functionality."""
        intent_classifier = IntentClassifier()
        
        # Test customer support intents
        test_messages = [
            {
                "message": "I need help with my account",
                "expected_intent": "account_help"
            },
            {
                "message": "My payment failed, what should I do?",
                "expected_intent": "payment_support"
            },
            {
                "message": "How do I reset my password?",
                "expected_intent": "password_help"
            },
            {
                "message": "I want to cancel my subscription",
                "expected_intent": "subscription_cancellation"
            }
        ]
        
        for test_case in test_messages:
            intent = await intent_classifier.classify_intent(test_case["message"])
            assert isinstance(intent, str)
            assert len(intent) > 0
            
            # Note: The actual classification accuracy depends on the implementation
            # and training data
    
    @pytest.mark.asyncio
    async def test_response_generation(self, agent_utils):
        """Test response generation functionality."""
        response_generator = ResponseGenerator()
        
        # Generate response based on intent
        response = await response_generator.generate_response(
            intent="account_help",
            context={"user_id": "user_123", "session_id": "session_456"},
            conversation_history=[
                {"role": "user", "content": "I need help with my account"}
            ]
        )
        
        assert isinstance(response, dict)
        assert "content" in response
        assert "intent" in response
        assert "confidence" in response
        assert "suggested_actions" in response
        
        # Test escalation response
        escalation_response = await response_generator.generate_response(
            intent="complex_technical_issue",
            context={"escalation_level": 2},
            require_escalation=True
        )
        
        assert escalation_response.get("requires_escalation") is True
    
    @pytest.mark.asyncio
    async def test_tool_selection(self, agent_utils):
        """Test tool selection functionality."""
        tool_selector = ToolSelector()
        
        # Available tools for testing
        available_tools = [
            {"name": "memory_tool", "capabilities": ["memory_access", "data_retrieval"]},
            {"name": "rag_tool", "capabilities": ["document_search", "knowledge_retrieval"]},
            {"name": "attachment_tool", "capabilities": ["file_upload", "file_processing"]}
        ]
        
        # Select tools based on intent
        selected_tools = await tool_selector.select_tools(
            intent="document_search",
            available_tools=available_tools,
            context={"query": "How to reset password"}
        )
        
        assert isinstance(selected_tools, list)
        assert len(selected_tools) > 0
        assert any("rag_tool" in tool.get("name", "") for tool in selected_tools)
        
        # Test tool selection with multiple intents
        multi_intent_tools = await tool_selector.select_tools(
            intent="file_processing_with_memory",
            available_tools=available_tools,
            context={}
        )
        
        assert len(multi_intent_tools) >= 2  # Should select multiple tools
    
    @pytest.mark.asyncio
    async def test_conversation_management(self, agent_utils):
        """Test conversation management functionality."""
        conversation_manager = ConversationManager()
        
        # Start conversation
        conversation_id = await conversation_manager.start_conversation(
            user_id="user_123",
            channel="web"
        )
        
        assert isinstance(conversation_id, str)
        
        # Add messages to conversation
        await conversation_manager.add_message(
            conversation_id=conversation_id,
            message={
                "role": "user",
                "content": "Hello, I need help",
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        await conversation_manager.add_message(
            conversation_id=conversation_id,
            message={
                "role": "assistant",
                "content": "How can I assist you today?",
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        # Get conversation history
        history = await conversation_manager.get_conversation_history(conversation_id)
        assert len(history) == 2
        
        # Update conversation state
        await conversation_manager.update_conversation_state(
            conversation_id=conversation_id,
            state="active"
        )
        
        # End conversation
        await conversation_manager.end_conversation(conversation_id)
    
    @pytest.mark.asyncio
    async def test_metrics_collection(self, agent_utils):
        """Test metrics collection functionality."""
        metrics_collector = MetricsCollector()
        
        # Record agent metrics
        await metrics_collector.record_agent_metric(
            agent_id="agent_123",
            metric_name="response_time",
            value=1.5,
            timestamp=datetime.utcnow()
        )
        
        await metrics_collector.record_agent_metric(
            agent_id="agent_123",
            metric_name="messages_processed",
            value=10,
            timestamp=datetime.utcnow()
        )
        
        # Get metrics summary
        summary = await metrics_collector.get_agent_summary("agent_123")
        
        assert isinstance(summary, dict)
        assert "response_time" in summary
        assert "messages_processed" in summary
    
    def test_validation_helper(self, agent_utils):
        """Test validation helper functionality."""
        validator = ValidationHelper()
        
        # Test agent configuration validation
        config = {
            "name": "test_agent",
            "version": "1.0.0",
            "capabilities": ["text_generation"]
        }
        
        is_valid, errors = validator.validate_agent_config(config)
        assert is_valid is True
        
        # Test invalid configuration
        invalid_config = {
            "name": "",  # Empty name
            "version": "invalid_version",
            "capabilities": []  # Empty capabilities
        }
        
        is_valid, errors = validator.validate_agent_config(invalid_config)
        assert is_valid is False
        assert len(errors) > 0


# =============================================================================
# CHAT AGENT TESTS
# =============================================================================

class TestChatAgent:
    """Test chat agent functionality."""
    
    @pytest.fixture
    def chat_agent(self):
        """Create chat agent instance."""
        # Mock dependencies
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            return ChatAgent()
    
    @pytest.fixture
    def agent_context(self):
        """Create agent context."""
        return AgentContext(
            session_id="test_session_123",
            user_id="user_456"
        )
    
    @pytest.mark.asyncio
    async def test_agent_initialization(self, chat_agent):
        """Test chat agent initialization."""
        assert chat_agent.state == AgentState.IDLE
        assert chat_agent.tools is not None
        assert isinstance(chat_agent.config, dict)
    
    @pytest.mark.asyncio
    async def test_message_processing(self, chat_agent, agent_context):
        """Test message processing functionality."""
        # Mock the message processing pipeline
        with patch.object(chat_agent, '_process_message') as mock_process:
            mock_process.return_value = AsyncMock(return_value={
                "response": "Hello! How can I help you?",
                "intent": "greeting",
                "confidence": 0.9,
                "tools_used": []
            })
            
            # Process user message
            response = await chat_agent.process_message(
                message="Hello, I need help",
                context=agent_context
            )
            
            assert isinstance(response, dict)
            assert "response" in response
            assert "intent" in response
            assert "confidence" in response
            mock_process.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_conversation_flow_management(self, chat_agent, agent_context):
        """Test conversation flow management."""
        # Test conversation start
        await chat_agent.start_conversation(agent_context)
        assert agent_context.agent_state == AgentState.PROCESSING
        
        # Test step-by-step conversation flow
        steps = [
            "greeting",
            "intent_detection",
            "tool_selection",
            "response_generation"
        ]
        
        for step in steps:
            agent_context.current_step = step
            # Simulate step processing
            await asyncio.sleep(0.01)  # Simulate processing time
        
        assert agent_context.current_step == steps[-1]
        
        # Test conversation end
        await chat_agent.end_conversation(agent_context)
        assert agent_context.agent_state == AgentState.TERMINATED
    
    @pytest.mark.asyncio
    async def test_tool_orchestration(self, chat_agent, agent_context):
        """Test tool orchestration functionality."""
        # Configure agent with mock tools
        chat_agent.tools = {
            "memory": Mock(),
            "rag": Mock(),
            "attachment": Mock(),
            "escalation": Mock()
        }
        
        # Mock tool execution
        chat_agent.tools["memory"].store.return_value = AsyncMock(return_value={"success": True})
        chat_agent.tools["rag"].search.return_value = AsyncMock(return_value=[{"content": "Relevant info"}])
        
        # Test tool selection and execution
        tools_to_execute = ["memory", "rag"]
        results = await chat_agent.orchestrate_tools(
            tools=tools_to_execute,
            context=agent_context,
            task="search_and_store"
        )
        
        assert isinstance(results, dict)
        assert "memory" in results
        assert "rag" in results
        assert agent_context.tools_used == tools_to_execute
    
    @pytest.mark.asyncio
    async def test_escalation_handling(self, chat_agent, agent_context):
        """Test escalation handling functionality."""
        # Test soft escalation
        agent_context.escalation_type = EscalationType.SOFT
        escalation_result = await chat_agent.handle_escalation(
            context=agent_context,
            reason="complex_technical_issue"
        )
        
        assert escalation_result["escalation_triggered"] is True
        assert escalation_result["escalation_type"] == EscalationType.SOFT.value
        
        # Test hard escalation
        agent_context.escalation_level = 3
        agent_context.escalation_type = EscalationType.HARD
        
        hard_escalation = await chat_agent.handle_escalation(
            context=agent_context,
            reason="customer_frustration"
        )
        
        assert hard_escalation["escalation_triggered"] is True
        assert hard_escalation["escalation_type"] == EscalationType.HARD.value
        assert hard_escalation["priority"] == "high"
    
    @pytest.mark.asyncio
    async def test_context_management(self, chat_agent, agent_context):
        """Test context management functionality."""
        # Add message to context
        message = {
            "role": "user",
            "content": "I need help with my account",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        agent_context.add_message(message)
        assert len(agent_context.message_history) == 1
        
        # Update user intent
        agent_context.user_intent = "account_help"
        assert agent_context.user_intent == "account_help"
        
        # Test context serialization
        context_dict = agent_context.to_dict()
        assert isinstance(context_dict, dict)
        assert context_dict["session_id"] == "test_session_123"
        assert context_dict["user_id"] == "user_456"
        assert context_dict["user_intent"] == "account_help"
    
    @pytest.mark.asyncio
    async def test_state_management(self, chat_agent, agent_context):
        """Test agent state management."""
        # Test state transitions
        initial_state = chat_agent.state
        assert initial_state == AgentState.IDLE
        
        # Transition to processing
        chat_agent.state = AgentState.PROCESSING
        assert chat_agent.state == AgentState.PROCESSING
        
        # Transition to waiting
        chat_agent.state = AgentState.WAITING
        assert chat_agent.state == AgentState.WAITING
        
        # Transition to error
        chat_agent.state = AgentState.ERROR
        assert chat_agent.state == AgentState.ERROR
        
        # Reset to idle
        chat_agent.state = AgentState.IDLE
        assert chat_agent.state == AgentState.IDLE
    
    def test_agent_enums(self):
        """Test agent enum values."""
        # Test AgentState enum
        assert AgentState.IDLE.value == "idle"
        assert AgentState.PROCESSING.value == "processing"
        assert AgentState.WAITING.value == "waiting"
        assert AgentState.ERROR.value == "error"
        assert AgentState.TERMINATED.value == "terminated"
        
        # Test EscalationType enum
        assert EscalationType.NONE.value == "none"
        assert EscalationType.SOFT.value == "soft"
        assert EscalationType.HARD.value == "hard"
        assert EscalationType.IMMEDIATE.value == "immediate"
        
        # Test ToolExecutionStatus enum
        assert ToolExecutionStatus.PENDING.value == "pending"
        assert ToolExecutionStatus.RUNNING.value == "running"
        assert ToolExecutionStatus.COMPLETED.value == "completed"
        assert ToolExecutionStatus.FAILED.value == "failed"
        assert ToolExecutionStatus.SKIPPED.value == "skipped"
    
    @pytest.mark.asyncio
    async def test_response_builder(self, chat_agent, agent_context):
        """Test response builder functionality."""
        # Build response from context
        response_data = {
            "content": "Here's how I can help you with your account:",
            "intent": "account_help",
            "confidence": 0.85,
            "tools_used": ["memory", "rag"],
            "metadata": {
                "processing_time": 1.2,
                "escalation_level": 0
            }
        }
        
        # Mock response building
        with patch.object(chat_agent, '_build_response') as mock_build:
            mock_build.return_value = AsyncMock(return_value=response_data)
            
            response = await chat_agent._build_response(agent_context, response_data)
            
            assert isinstance(response, dict)
            assert response["content"] == "Here's how I can help you with your account:"
            assert response["intent"] == "account_help"
            assert response["confidence"] == 0.85
            assert "tools_used" in response
            assert "metadata" in response


# =============================================================================
# MONITORING INTEGRATION TESTS
# =============================================================================

class TestMonitoringIntegration:
    """Test monitoring integration functionality."""
    
    @pytest.fixture
    def monitoring_integration(self):
        """Create monitoring integration instance."""
        return MonitoringIntegration()
    
    @pytest.fixture
    def sample_metrics(self):
        """Create sample metrics for testing."""
        return AgentMetrics(
            agent_id="test_agent_123",
            session_id="session_456",
            response_time=1.5,
            messages_processed=10,
            tools_used=5,
            errors_count=0,
            escalation_count=1,
            user_satisfaction=4.2,
            timestamp=datetime.utcnow()
        )
    
    @pytest.mark.asyncio
    async def test_metrics_collection(self, monitoring_integration, sample_metrics):
        """Test metrics collection functionality."""
        # Record metrics
        await monitoring_integration.record_metrics(sample_metrics)
        
        # Retrieve metrics
        metrics = await monitoring_integration.get_agent_metrics("test_agent_123")
        
        assert isinstance(metrics, list)
        assert len(metrics) > 0
        assert metrics[0].agent_id == "test_agent_123"
    
    @pytest.mark.asyncio
    async def test_health_monitoring(self, monitoring_integration):
        """Test health monitoring functionality."""
        # Test health check
        health_status = await monitoring_integration.check_agent_health("test_agent_123")
        
        assert isinstance(health_status, dict)
        assert "status" in health_status
        assert "last_check" in health_status
        assert "metrics" in health_status
        
        # Test health status values
        valid_statuses = ["healthy", "warning", "critical", "unknown"]
        assert health_status["status"] in valid_statuses
    
    @pytest.mark.asyncio
    async def test_performance_tracking(self, monitoring_integration, sample_metrics):
        """Test performance tracking functionality."""
        # Track performance metrics
        performance_data = {
            "response_time": 1.2,
            "throughput": 5.0,
            "resource_usage": {
                "cpu": 25.5,
                "memory": 512.0
            }
        }
        
        await monitoring_integration.track_performance("test_agent_123", performance_data)
        
        # Retrieve performance data
        performance = await monitoring_integration.get_performance_data("test_agent_123")
        
        assert isinstance(performance, dict)
        assert "response_time" in performance
        assert "throughput" in performance
        assert "resource_usage" in performance
    
    @pytest.mark.asyncio
    async def test_error_tracking(self, monitoring_integration):
        """Test error tracking functionality."""
        # Record error
        error_data = {
            "error_type": "tool_execution_failed",
            "error_message": "Failed to execute RAG tool",
            "severity": "high",
            "context": {
                "agent_id": "test_agent_123",
                "session_id": "session_456"
            }
        }
        
        await monitoring_integration.track_error("test_agent_123", error_data)
        
        # Get error summary
        error_summary = await monitoring_integration.get_error_summary("test_agent_123")
        
        assert isinstance(error_summary, dict)
        assert "total_errors" in error_summary
        assert "error_types" in error_summary
        assert error_summary["total_errors"] > 0
    
    @pytest.mark.asyncio
    async def test_metrics_aggregation(self, monitoring_integration):
        """Test metrics aggregation functionality."""
        # Create multiple metric entries
        metrics_list = []
        for i in range(5):
            metrics = AgentMetrics(
                agent_id="agg_test_agent",
                session_id=f"session_{i}",
                response_time=1.0 + i * 0.2,
                messages_processed=i + 1,
                tools_used=i,
                errors_count=max(0, i - 2),
                escalation_count=1 if i >= 3 else 0,
                user_satisfaction=3.5 + i * 0.1,
                timestamp=datetime.utcnow()
            )
            metrics_list.append(metrics)
            await monitoring_integration.record_metrics(metrics)
        
        # Aggregate metrics
        aggregated = await monitoring_integration.aggregate_metrics("agg_test_agent")
        
        assert isinstance(aggregated, dict)
        assert "avg_response_time" in aggregated
        assert "total_messages" in aggregated
        assert "total_errors" in aggregated
        assert "avg_satisfaction" in aggregated
        
        # Verify aggregation calculations
        assert aggregated["total_messages"] == sum(i + 1 for i in range(5))
        assert aggregated["total_errors"] == sum(max(0, i - 2) for i in range(5))
    
    @pytest.mark.asyncio
    async def test_alert_management(self, monitoring_integration):
        """Test alert management functionality."""
        # Create alert rule
        alert_rule = {
            "name": "high_error_rate",
            "condition": "errors_count > 5",
            "threshold": 5,
            "severity": "critical",
            "enabled": True
        }
        
        await monitoring_integration.create_alert_rule(alert_rule)
        
        # Trigger alert (simulate condition met)
        trigger_data = {
            "agent_id": "test_agent_123",
            "metrics": {
                "errors_count": 6,
                "response_time": 5.0
            }
        }
        
        alert_triggered = await monitoring_integration.check_alert_conditions(trigger_data)
        assert isinstance(alert_triggered, list)
        
        # Test alert history
        alert_history = await monitoring_integration.get_alert_history("test_agent_123")
        assert isinstance(alert_history, list)
    
    @pytest.mark.asyncio
    async def test_dashboard_provider(self, monitoring_integration):
        """Test dashboard provider functionality."""
        # Generate dashboard data
        dashboard_data = await monitoring_integration.generate_dashboard_data(
            time_range="24h",
            agent_ids=["agent1", "agent2", "agent3"]
        )
        
        assert isinstance(dashboard_data, dict)
        assert "summary" in dashboard_data
        assert "agents" in dashboard_data
        assert "time_range" in dashboard_data
        
        # Verify summary structure
        summary = dashboard_data["summary"]
        assert "total_agents" in summary
        assert "avg_response_time" in summary
        assert "total_messages" in summary
        assert "error_rate" in summary
        
        # Verify agent data structure
        agents = dashboard_data["agents"]
        for agent_data in agents:
            assert "agent_id" in agent_data
            assert "metrics" in agent_data
            assert "status" in agent_data
    
    def test_metrics_data_structure(self, monitoring_integration, sample_metrics):
        """Test metrics data structure validation."""
        # Test metrics object creation
        assert sample_metrics.agent_id == "test_agent_123"
        assert sample_metrics.response_time == 1.5
        assert sample_metrics.messages_processed == 10
        assert sample_metrics.tools_used == 5
        assert sample_metrics.errors_count == 0
        assert sample_metrics.escalation_count == 1
        assert sample_metrics.user_satisfaction == 4.2
        assert isinstance(sample_metrics.timestamp, datetime)
    
    @pytest.mark.asyncio
    async def test_real_time_monitoring(self, monitoring_integration):
        """Test real-time monitoring functionality."""
        # Test real-time metrics stream
        real_time_stream = monitoring_integration.get_real_time_stream("test_agent_123")
        
        # Simulate real-time metric updates
        for i in range(3):
            metrics = AgentMetrics(
                agent_id="realtime_agent",
                session_id=f"session_{i}",
                response_time=1.0 + i * 0.1,
                messages_processed=i + 1,
                tools_used=i,
                errors_count=0,
                escalation_count=0,
                user_satisfaction=4.0,
                timestamp=datetime.utcnow()
            )
            
            await monitoring_integration.record_metrics(metrics)
        
        # Verify real-time data availability
        recent_metrics = await monitoring_integration.get_recent_metrics("realtime_agent", minutes=1)
        assert len(recent_metrics) == 3


# =============================================================================
# AGENT INTEGRATION TESTS
# =============================================================================

class TestAgentIntegration:
    """Test integration between different agent components."""
    
    @pytest.mark.asyncio
    async def test_factory_utils_integration(self):
        """Test integration between factory and utils."""
        factory = AgentFactory()
        utils = AgentUtils()
        
        # Create agent via factory
        config = AgentConfig(
            name="integration_agent",
            agent_type="chat",
            capabilities=["text_generation", "tool_usage"]
        )
        
        agent = await factory.create_agent(config)
        
        # Use utils to manage agent context
        context = AgentContext(
            session_id="integration_session",
            user_id="integration_user"
        )
        
        context_manager = ContextManager()
        await context_manager.store_context(context)
        
        # Verify integration
        stored_context = await context_manager.get_context("integration_session")
        assert stored_context is not None
        assert stored_context.session_id == "integration_session"
    
    @pytest.mark.asyncio
    async def test_chat_agent_factory_integration(self):
        """Test integration between chat agent and factory."""
        # This would test the complete pipeline of:
        # 1. Agent creation via factory
        # 2. Chat agent functionality
        # 3. Monitoring integration
        
        factory = AgentFactory()
        
        # Create chat agent via factory
        config = AgentConfig(
            name="integration_chat_agent",
            agent_type="chat",
            max_instances=2
        )
        
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            chat_agent = await factory.create_agent(config)
            
            # The actual chat agent would have different interface than factory returns
            # This is a simplified test of the integration concept
    
    @pytest.mark.asyncio
    async def test_full_agent_pipeline(self):
        """Test complete agent processing pipeline."""
        # Mock dependencies
        mock_rag = Mock()
        mock_memory = Mock()
        mock_attachment = Mock()
        mock_escalation = Mock()
        
        mock_rag.search.return_value = AsyncMock(return_value=[{"content": "Found information"}])
        mock_memory.store.return_value = AsyncMock(return_value={"success": True})
        
        with patch('app.agents.chat_agent.RAGTool', return_value=mock_rag), \
             patch('app.agents.chat_agent.MemoryTool', return_value=mock_memory), \
             patch('app.agents.chat_agent.AttachmentTool', return_value=mock_attachment), \
             patch('app.agents.chat_agent.EscalationTool', return_value=mock_escalation):
            
            # Create and initialize chat agent
            chat_agent = ChatAgent()
            
            # Create context
            context = AgentContext(
                session_id="pipeline_session",
                user_id="pipeline_user"
            )
            
            # Process user message
            user_message = "I need help finding information about my account"
            
            with patch.object(chat_agent, '_process_message') as mock_process:
                mock_process.return_value = AsyncMock(return_value={
                    "response": "I found information about your account.",
                    "intent": "account_information",
                    "confidence": 0.9,
                    "tools_used": ["rag", "memory"]
                })
                
                response = await chat_agent.process_message(user_message, context)
                
                # Verify pipeline execution
                assert isinstance(response, dict)
                assert "response" in response
                assert response["intent"] == "account_information"
                
                # Verify tools were used
                assert "tools_used" in response
                assert len(response["tools_used"]) > 0


# =============================================================================
# PERFORMANCE AND STRESS TESTS
# =============================================================================

class TestAgentPerformance:
    """Performance tests for agent components."""
    
    @pytest.mark.asyncio
    async def test_agent_factory_performance(self):
        """Test agent factory performance under load."""
        factory = AgentFactory()
        
        # Performance test parameters
        num_agents = 100
        start_time = time.time()
        
        # Create multiple agents
        agents = []
        for i in range(num_agents):
            config = AgentConfig(
                name=f"perf_agent_{i}",
                agent_type="chat",
                capabilities=["text_generation"]
            )
            agent = await factory.create_agent(config)
            agents.append(agent)
        
        creation_time = time.time() - start_time
        
        # Performance assertions
        agents_per_second = num_agents / creation_time if creation_time > 0 else float('inf')
        assert agents_per_second > 1  # At least 1 agent/second
        
        # Test lifecycle operations
        start_time = time.time()
        
        for agent in agents[:10]:  # Test subset for speed
            await factory.initialize_agent(agent.id)
            await factory.start_agent(agent.id)
            await factory.stop_agent(agent.id)
        
        lifecycle_time = time.time() - start_time
        lifecycle_ops_per_second = (10 * 3) / lifecycle_time if lifecycle_time > 0 else float('inf')
        assert lifecycle_ops_per_second > 10  # At least 10 ops/second
    
    @pytest.mark.asyncio
    async def test_chat_agent_response_performance(self):
        """Test chat agent response performance."""
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            chat_agent = ChatAgent()
            
            # Performance test parameters
            num_messages = 50
            start_time = time.time()
            
            # Mock response generation for performance testing
            with patch.object(chat_agent, '_process_message') as mock_process:
                mock_process.return_value = AsyncMock(return_value={
                    "response": "Test response",
                    "intent": "test",
                    "confidence": 0.9,
                    "tools_used": []
                })
                
                for i in range(num_messages):
                    context = AgentContext(
                        session_id=f"perf_session_{i}",
                        user_id=f"perf_user_{i}"
                    )
                    
                    await chat_agent.process_message(f"Message {i}", context)
            
            processing_time = time.time() - start_time
            
            # Performance assertions
            messages_per_second = num_messages / processing_time if processing_time > 0 else float('inf')
            assert messages_per_second > 5  # At least 5 messages/second
    
    @pytest.mark.asyncio
    async def test_monitoring_performance(self):
        """Test monitoring integration performance."""
        monitoring = MonitoringIntegration()
        
        # Performance test parameters
        num_metrics = 1000
        start_time = time.time()
        
        # Record many metrics
        for i in range(num_metrics):
            metrics = AgentMetrics(
                agent_id=f"perf_agent_{i % 10}",
                session_id=f"session_{i}",
                response_time=1.0 + (i % 100) * 0.01,
                messages_processed=i % 50,
                tools_used=i % 20,
                errors_count=i % 5,
                escalation_count=i % 3,
                user_satisfaction=4.0 + (i % 10) * 0.05,
                timestamp=datetime.utcnow()
            )
            
            await monitoring.record_metrics(metrics)
        
        recording_time = time.time() - start_time
        
        # Performance assertions
        metrics_per_second = num_metrics / recording_time if recording_time > 0 else float('inf')
        assert metrics_per_second > 100  # At least 100 metrics/second
        
        # Test aggregation performance
        start_time = time.time()
        
        aggregated = await monitoring.aggregate_metrics("perf_agent_1")
        
        aggregation_time = time.time() - start_time
        
        assert aggregation_time < 1.0  # Aggregation should complete in < 1 second
        assert isinstance(aggregated, dict)


# =============================================================================
# ERROR HANDLING AND RESILIENCE TESTS
# =============================================================================

class TestAgentResilience:
    """Test error handling and resilience of agent components."""
    
    @pytest.mark.asyncio
    async def test_agent_factory_error_recovery(self):
        """Test agent factory error recovery."""
        factory = AgentFactory()
        
        # Test invalid configuration handling
        invalid_config = AgentConfig(
            name="",  # Invalid name
            agent_type="invalid_type",
            max_instances=-1  # Invalid max instances
        )
        
        # Should handle invalid config gracefully
        with pytest.raises((ValueError, TypeError)):
            await factory.create_agent(invalid_config)
    
    @pytest.mark.asyncio
    async def test_chat_agent_error_handling(self):
        """Test chat agent error handling."""
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            chat_agent = ChatAgent()
            context = AgentContext(
                session_id="error_test_session",
                user_id="error_test_user"
            )
            
            # Test with tool execution failure
            with patch.object(chat_agent, '_process_message') as mock_process:
                mock_process.side_effect = Exception("Simulated tool failure")
                
                # Should handle error gracefully
                try:
                    response = await chat_agent.process_message("test message", context)
                    # If no exception, error was handled
                    assert isinstance(response, dict)
                    assert "error" in response or "response" in response
                except Exception as e:
                    # Exception might be expected depending on error handling strategy
                    assert isinstance(e, Exception)
    
    @pytest.mark.asyncio
    async def test_context_manager_error_handling(self):
        """Test context manager error handling."""
        context_manager = ContextManager()
        
        # Test with invalid context data
        with pytest.raises((ValueError, TypeError)):
            await context_manager.store_context("invalid_context")
        
        # Test with non-existent context retrieval
        non_existent_context = await context_manager.get_context("non_existent_session")
        assert non_existent_context is None
        
        # Test with corrupted context data
        corrupted_context = AgentContext(
            session_id="corrupted_session",
            user_id="corrupted_user"
        )
        corrupted_context.message_history = "corrupted_data"  # Should be list
        
        # Should handle corrupted data gracefully
        await context_manager.store_context(corrupted_context)
        retrieved_context = await context_manager.get_context("corrupted_session")
        assert retrieved_context is not None
    
    @pytest.mark.asyncio
    async def test_monitoring_error_handling(self):
        """Test monitoring error handling."""
        monitoring = MonitoringIntegration()
        
        # Test with invalid metrics data
        with pytest.raises((ValueError, TypeError)):
            await monitoring.record_metrics("invalid_metrics")
        
        # Test health check with non-existent agent
        health_status = await monitoring.check_agent_health("non_existent_agent")
        assert health_status["status"] == "unknown"
        
        # Test error tracking with incomplete data
        await monitoring.track_error("test_agent", {
            "error_type": "test_error"
            # Missing other required fields
        })
        
        # Should handle incomplete data gracefully
        error_summary = await monitoring.get_error_summary("test_agent")
        assert isinstance(error_summary, dict)
    
    @pytest.mark.asyncio
    async def test_agent_state_resilience(self):
        """Test agent state management resilience."""
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            chat_agent = ChatAgent()
            context = AgentContext(
                session_id="state_test_session",
                user_id="state_test_user"
            )
            
            # Test state recovery after error
            original_state = chat_agent.state
            
            # Simulate error state
            chat_agent.state = AgentState.ERROR
            
            # Test recovery
            await chat_agent.recover_from_error()
            
            # Agent should either recover or be in safe state
            assert chat_agent.state in [AgentState.IDLE, AgentState.ERROR]
            
            # Test graceful shutdown even in error state
            await chat_agent.shutdown()
            assert chat_agent.state == AgentState.TERMINATED
    
    @pytest.mark.asyncio
    async def test_tool_orchestration_fault_tolerance(self):
        """Test tool orchestration fault tolerance."""
        with patch('app.agents.chat_agent.RAGTool'), \
             patch('app.agents.chat_agent.MemoryTool'), \
             patch('app.agents.chat_agent.AttachmentTool'), \
             patch('app.agents.chat_agent.EscalationTool'):
            
            chat_agent = ChatAgent()
            context = AgentContext(
                session_id="tolerance_test_session",
                user_id="tolerance_test_user"
            )
            
            # Configure some tools to fail
            chat_agent.tools = {
                "memory": Mock(),
                "rag": Mock(),
                "attachment": Mock(),
                "escalation": Mock()
            }
            
            # Make some tools fail
            chat_agent.tools["memory"].store.side_effect = Exception("Memory tool failed")
            chat_agent.tools["rag"].search.side_effect = Exception("RAG tool failed")
            chat_agent.tools["attachment"].upload.return_value = AsyncMock(return_value={"success": True})
            
            # Test orchestration with failing tools
            tools_to_execute = ["memory", "rag", "attachment"]
            results = await chat_agent.orchestrate_tools(
                tools=tools_to_execute,
                context=context,
                task="test_with_failures"
            )
            
            # Should still return results even with failures
            assert isinstance(results, dict)
            assert "errors" in results or "partial_results" in results


# =============================================================================
# TEST DATA AND UTILITIES
# =============================================================================

@pytest.fixture
def sample_agent_configs():
    """Provide sample agent configurations for testing."""
    return [
        {
            "name": "basic_chat_agent",
            "agent_type": "chat",
            "version": "1.0.0",
            "capabilities": ["text_generation", "basic_tool_usage"],
            "max_instances": 3,
            "resource_limits": {"memory": "256MB", "cpu": "0.3"}
        },
        {
            "name": "advanced_agent",
            "agent_type": "chat",
            "version": "2.0.0",
            "capabilities": ["text_generation", "tool_usage", "memory_access", "escalation"],
            "max_instances": 5,
            "resource_limits": {"memory": "512MB", "cpu": "0.7", "timeout": 60}
        }
    ]


@pytest.fixture
def sample_conversations():
    """Provide sample conversations for testing."""
    return [
        {
            "session_id": "session_1",
            "user_id": "user_1",
            "messages": [
                {"role": "user", "content": "Hello, I need help", "timestamp": "2023-01-01T10:00:00Z"},
                {"role": "assistant", "content": "Hello! How can I assist you?", "timestamp": "2023-01-01T10:00:01Z"},
                {"role": "user", "content": "I have a problem with my account", "timestamp": "2023-01-01T10:00:05Z"}
            ],
            "intent": "account_help",
            "escalation_level": 0
        },
        {
            "session_id": "session_2",
            "user_id": "user_2",
            "messages": [
                {"role": "user", "content": "My payment failed", "timestamp": "2023-01-01T11:00:00Z"},
                {"role": "assistant", "content": "I can help you with that. Let me check your payment status.", "timestamp": "2023-01-01T11:00:01Z"}
            ],
            "intent": "payment_support",
            "escalation_level": 1
        }
    ]


@pytest.fixture
def agent_test_scenarios():
    """Provide test scenarios for agent testing."""
    return {
        "simple_conversation": {
            "description": "Simple greeting and basic question",
            "input": "Hello, how are you?",
            "expected_intent": "greeting",
            "complexity": "low",
            "tools_needed": []
        },
        "account_inquiry": {
            "description": "User asking about account status",
            "input": "What's the status of my account?",
            "expected_intent": "account_status",
            "complexity": "medium",
            "tools_needed": ["memory", "rag"]
        },
        "complex_technical_issue": {
            "description": "Complex technical problem requiring escalation",
            "input": "I'm having issues with the API integration and it's affecting my business",
            "expected_intent": "technical_support",
            "complexity": "high",
            "tools_needed": ["memory", "rag", "escalation"],
            "should_escalate": True
        },
        "file_processing": {
            "description": "User uploading file for processing",
            "input": "Please analyze this document for me",
            "expected_intent": "file_processing",
            "complexity": "medium",
            "tools_needed": ["attachment", "rag"]
        }
    }


@pytest.fixture
def monitoring_test_data():
    """Provide test data for monitoring tests."""
    return {
        "sample_metrics": [
            {
                "agent_id": "agent_1",
                "response_time": 1.2,
                "messages_processed": 5,
                "tools_used": 3,
                "errors_count": 0,
                "escalation_count": 0,
                "user_satisfaction": 4.5
            },
            {
                "agent_id": "agent_2",
                "response_time": 2.1,
                "messages_processed": 8,
                "tools_used": 6,
                "errors_count": 1,
                "escalation_count": 1,
                "user_satisfaction": 3.8
            }
        ],
        "alert_rules": [
            {
                "name": "high_response_time",
                "condition": "response_time > 3.0",
                "threshold": 3.0,
                "severity": "warning"
            },
            {
                "name": "high_error_rate",
                "condition": "errors_count > 5",
                "threshold": 5,
                "severity": "critical"
            }
        ]
    }


# =============================================================================
# MARKERS CONFIGURATION
# =============================================================================

pytest.mark.unit = pytest.mark.unit
pytest.mark.integration = pytest.mark.integration
pytest.mark.slow = pytest.mark.slow
pytest.mark.performance = pytest.mark.performance
pytest.mark.resilience = pytest.mark.resilience
pytest.mark.agent = pytest.mark.agent


# =============================================================================
# TEST SUITE CONFIGURATION
# =============================================================================

def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line("markers", "unit: Unit tests for individual agent components")
    config.addinivalue_line("markers", "integration: Integration tests for agent interactions")
    config.addinivalue_line("markers", "slow: Slow running agent tests")
    config.addinivalue_line("markers", "performance: Performance tests for agents")
    config.addinivalue_line("markers", "resilience: Error handling and resilience tests")
    config.addinivalue_line("markers", "agent: Agent-specific tests")


def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on test names."""
    for item in items:
        # Add performance marker to performance tests
        if "performance" in item.name.lower():
            item.add_marker(pytest.mark.performance)
        
        # Add resilience marker to resilience tests
        if "resilience" in item.name.lower() or "error" in item.name.lower():
            item.add_marker(pytest.mark.resilience)
        
        # Add slow marker to stress tests
        if any(keyword in item.name.lower() for keyword in ["stress", "load", "batch"]):
            item.add_marker(pytest.mark.slow)
        
        # Add agent marker to all agent tests
        if any(keyword in item.name.lower() for keyword in ["agent", "chat", "factory"]):
            item.add_marker(pytest.mark.agent)