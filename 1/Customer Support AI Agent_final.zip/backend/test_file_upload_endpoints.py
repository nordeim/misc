#!/usr/bin/env python3
"""
Comprehensive Test Suite for File Upload Endpoints

This test suite validates the complete file upload and processing pipeline including:
- File upload initiation and progress tracking
- Multipart file uploads with chunks
- File validation and security scanning
- Background processing queue
- File management operations
- Search and discovery
- Security and audit features

Usage:
    python test_file_upload_endpoints.py

Environment:
    Set PYTHONPATH to include the backend directory
    Ensure database and storage are configured
"""

import asyncio
import aiohttp
import json
import os
import tempfile
import hashlib
from pathlib import Path
from typing import Dict, Any
import logging
import sys

# Add backend to path
sys.path.insert(0, '/workspace/backend')

from app.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FileUploadTester:
    """Comprehensive file upload endpoint tester."""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = None
        self.test_files = {}
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def create_test_file(self, size: int, filename: str) -> str:
        """Create a test file with specified size."""
        test_content = b"x" * size
        
        with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix=Path(filename).suffix) as f:
            f.write(test_content)
            file_path = f.name
        
        self.test_files[filename] = {
            "path": file_path,
            "size": size,
            "content": test_content,
            "hash": hashlib.sha256(test_content).hexdigest()
        }
        
        return file_path
    
    async def test_upload_initiation(self) -> Dict[str, Any]:
        """Test file upload initiation."""
        logger.info("Testing file upload initiation...")
        
        # Create a test file
        test_file = await self.create_test_file(1024, "test_document.txt")
        
        try:
            # Test upload initiation
            async with self.session.post(
                f"{self.base_url}/api/v1/files/upload/initiate",
                data={
                    "filename": "test_document.txt",
                    "total_size": 1024,
                    "metadata": json.dumps({"description": "Test file"})
                }
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Upload initiation successful")
                    return result
                else:
                    logger.error(f"❌ Upload initiation failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Upload initiation error: {str(e)}")
            return None
    
    async def test_file_chunk_upload(self, upload_id: str) -> bool:
        """Test file chunk upload."""
        logger.info(f"Testing file chunk upload for {upload_id}...")
        
        try:
            # Read test file content
            test_content = self.test_files["test_document.txt"]["content"]
            
            # Simulate chunk upload
            chunk_data = test_content[:512]  # First half
            
            async with self.session.post(
                f"{self.base_url}/api/v1/files/upload/chunk",
                data={
                    "upload_id": upload_id,
                    "chunk_data": chunk_data,
                    "chunk_index": 0,
                    "total_chunks": 2
                }
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Chunk upload successful")
                    return True
                else:
                    logger.error(f"❌ Chunk upload failed: {result}")
                    return False
                    
        except Exception as e:
            logger.error(f"❌ Chunk upload error: {str(e)}")
            return False
    
    async def test_upload_completion(self, upload_id: str) -> Dict[str, Any]:
        """Test upload completion."""
        logger.info(f"Testing upload completion for {upload_id}...")
        
        try:
            async with self.session.post(
                f"{self.base_url}/api/v1/files/upload/complete",
                data={
                    "upload_id": upload_id
                }
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Upload completion successful")
                    return result
                else:
                    logger.error(f"❌ Upload completion failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Upload completion error: {str(e)}")
            return None
    
    async def test_upload_progress_tracking(self, upload_id: str) -> Dict[str, Any]:
        """Test upload progress tracking."""
        logger.info(f"Testing upload progress tracking for {upload_id}...")
        
        try:
            async with self.session.get(
                f"{self.base_url}/api/v1/files/upload/progress/{upload_id}"
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Upload progress tracking successful")
                    logger.info(f"Progress: {result.get('progress', 0)}%")
                    return result
                else:
                    logger.error(f"❌ Upload progress tracking failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Upload progress tracking error: {str(e)}")
            return None
    
    async def test_processing_status(self, upload_id: str) -> Dict[str, Any]:
        """Test file processing status."""
        logger.info(f"Testing processing status for {upload_id}...")
        
        try:
            async with self.session.get(
                f"{self.base_url}/api/v1/files/processing/status/{upload_id}"
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Processing status check successful")
                    logger.info(f"Status: {result.get('status', 'unknown')}")
                    return result
                else:
                    logger.error(f"❌ Processing status check failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Processing status check error: {str(e)}")
            return None
    
    async def test_batch_upload(self) -> Dict[str, Any]:
        """Test batch file upload."""
        logger.info("Testing batch file upload...")
        
        try:
            # Create multiple test files
            files_data = []
            for i, size in enumerate([512, 1024, 2048]):
                filename = f"batch_test_{i}.txt"
                file_path = await self.create_test_file(size, filename)
                
                with open(file_path, 'rb') as f:
                    files_data.append(('files', (filename, f.read(), 'text/plain')))
            
            async with self.session.post(
                f"{self.base_url}/api/v1/files/batch/upload",
                data=files_data
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Batch upload successful")
                    logger.info(f"Processed: {result.get('successful_uploads', 0)}/{result.get('total_files', 0)}")
                    return result
                else:
                    logger.error(f"❌ Batch upload failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Batch upload error: {str(e)}")
            return None
    
    async def test_file_listing(self) -> Dict[str, Any]:
        """Test file listing."""
        logger.info("Testing file listing...")
        
        try:
            async with self.session.get(
                f"{self.base_url}/api/v1/files/files/list"
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ File listing successful")
                    logger.info(f"Total files: {result.get('total_count', 0)}")
                    return result
                else:
                    logger.error(f"❌ File listing failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ File listing error: {str(e)}")
            return None
    
    async def test_file_search(self) -> Dict[str, Any]:
        """Test file search functionality."""
        logger.info("Testing file search...")
        
        try:
            search_data = {
                "query": "test",
                "limit": 10,
                "offset": 0
            }
            
            async with self.session.post(
                f"{self.base_url}/api/v1/files/files/search",
                json=search_data
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ File search successful")
                    logger.info(f"Search results: {result.get('total_count', 0)}")
                    return result
                else:
                    logger.error(f"❌ File search failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ File search error: {str(e)}")
            return None
    
    async def test_file_format_detection(self) -> Dict[str, Any]:
        """Test file format detection."""
        logger.info("Testing file format detection...")
        
        try:
            test_file = self.test_files["test_document.txt"]
            
            with open(test_file["path"], 'rb') as f:
                files_data = {'file': ('test_document.txt', f.read(), 'text/plain')}
                
                async with self.session.post(
                    f"{self.base_url}/api/v1/files/utils/detect-format",
                    data=files_data
                ) as response:
                    result = await response.json()
                    
                    if response.status == 200:
                        logger.info("✅ File format detection successful")
                        logger.info(f"Detected format: {result.get('detected_format', {})}")
                        return result
                    else:
                        logger.error(f"❌ File format detection failed: {result}")
                        return None
                        
        except Exception as e:
            logger.error(f"❌ File format detection error: {str(e)}")
            return None
    
    async def test_file_analytics(self) -> Dict[str, Any]:
        """Test file analytics."""
        logger.info("Testing file analytics...")
        
        try:
            async with self.session.get(
                f"{self.base_url}/api/v1/files/analytics/files"
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ File analytics successful")
                    logger.info(f"Analytics generated for window: {result.get('time_window_hours', 0)} hours")
                    return result
                else:
                    logger.error(f"❌ File analytics failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ File analytics error: {str(e)}")
            return None
    
    async def test_maintenance_cleanup(self) -> Dict[str, Any]:
        """Test maintenance cleanup."""
        logger.info("Testing maintenance cleanup...")
        
        try:
            async with self.session.post(
                f"{self.base_url}/api/v1/files/maintenance/cleanup"
            ) as response:
                result = await response.json()
                
                if response.status == 200:
                    logger.info("✅ Maintenance cleanup successful")
                    logger.info(f"Cleanup results: {result.get('cleanup_results', {})}")
                    return result
                else:
                    logger.error(f"❌ Maintenance cleanup failed: {result}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Maintenance cleanup error: {str(e)}")
            return None
    
    async def run_comprehensive_test(self):
        """Run comprehensive test suite."""
        logger.info("🚀 Starting comprehensive file upload endpoint tests...")
        
        results = {
            "upload_initiation": False,
            "chunk_upload": False,
            "upload_completion": False,
            "progress_tracking": False,
            "processing_status": False,
            "batch_upload": False,
            "file_listing": False,
            "file_search": False,
            "format_detection": False,
            "file_analytics": False,
            "maintenance_cleanup": False
        }
        
        try:
            # Test 1: Upload Initiation
            upload_result = await self.test_upload_initiation()
            if upload_result:
                results["upload_initiation"] = True
                upload_id = upload_result.get("upload_id")
                
                # Test 2: Progress Tracking
                progress_result = await self.test_upload_progress_tracking(upload_id)
                if progress_result:
                    results["progress_tracking"] = True
                
                # Test 3: Processing Status
                status_result = await self.test_processing_status(upload_id)
                if status_result:
                    results["processing_status"] = True
                
                # Test 4: Upload Completion (if not auto-completed)
                if progress_result and progress_result.get("status") == "uploading":
                    completion_result = await self.test_upload_completion(upload_id)
                    if completion_result:
                        results["upload_completion"] = True
            else:
                logger.warning("Skipping subsequent tests due to upload initiation failure")
            
            # Test 5: Batch Upload
            batch_result = await self.test_batch_upload()
            if batch_result:
                results["batch_upload"] = True
            
            # Test 6: File Listing
            list_result = await self.test_file_listing()
            if list_result:
                results["file_listing"] = True
            
            # Test 7: File Search
            search_result = await self.test_file_search()
            if search_result:
                results["file_search"] = True
            
            # Test 8: File Format Detection
            format_result = await self.test_file_format_detection()
            if format_result:
                results["format_detection"] = True
            
            # Test 9: File Analytics
            analytics_result = await self.test_file_analytics()
            if analytics_result:
                results["file_analytics"] = True
            
            # Test 10: Maintenance Cleanup
            cleanup_result = await self.test_maintenance_cleanup()
            if cleanup_result:
                results["maintenance_cleanup"] = True
            
            # Generate summary
            passed_tests = sum(results.values())
            total_tests = len(results)
            
            logger.info("\n" + "="*50)
            logger.info("📊 TEST SUMMARY")
            logger.info("="*50)
            
            for test_name, passed in results.items():
                status = "✅ PASS" if passed else "❌ FAIL"
                logger.info(f"{test_name.replace('_', ' ').title()}: {status}")
            
            logger.info(f"\nTotal: {passed_tests}/{total_tests} tests passed ({passed_tests/total_tests*100:.1f}%)")
            
            if passed_tests == total_tests:
                logger.info("🎉 All tests passed!")
            else:
                logger.warning(f"⚠️  {total_tests - passed_tests} tests failed")
            
            return results
            
        except Exception as e:
            logger.error(f"❌ Test suite error: {str(e)}")
            return results
        finally:
            # Cleanup test files
            for file_info in self.test_files.values():
                try:
                    os.unlink(file_info["path"])
                except:
                    pass

async def check_server_health(base_url: str) -> bool:
    """Check if the server is running and healthy."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{base_url}/health") as response:
                if response.status == 200:
                    logger.info("✅ Server is healthy")
                    return True
                else:
                    logger.error(f"❌ Server health check failed: {response.status}")
                    return False
    except Exception as e:
        logger.error(f"❌ Cannot connect to server: {str(e)}")
        return False

async def main():
    """Main test execution."""
    base_url = os.getenv("TEST_BASE_URL", "http://localhost:8000")
    
    logger.info("🔍 Checking server availability...")
    
    # Check if server is running
    if not await check_server_health(base_url):
        logger.error(f"Server is not available at {base_url}")
        logger.error("Please ensure the server is running before testing.")
        return 1
    
    # Run tests
    async with FileUploadTester(base_url) as tester:
        results = await tester.run_comprehensive_test()
        
        # Return exit code based on results
        passed_tests = sum(results.values())
        total_tests = len(results)
        
        return 0 if passed_tests == total_tests else 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
