#!/usr/bin/env python3
"""
Comprehensive WebSocket Testing Script

This script demonstrates and tests all the WebSocket features including:
- Connection management and authentication
- Message queuing and delivery
- Room management
- Rate limiting and security
- Admin functionality
- Health monitoring
- Testing utilities

Usage:
    python test_websocket_comprehensive.py
"""

import asyncio
import json
import websockets
import logging
import sys
from datetime import datetime
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class WebSocketTestClient:
    """Enhanced WebSocket test client."""
    
    def __init__(self, base_url: str = "ws://localhost:8000"):
        self.base_url = base_url
        self.connections: Dict[str, websockets.WebSocketServerProtocol] = {}
        self.client_id: Optional[str] = None
        self.auth_token: Optional[str] = None
        self.session_id: Optional[str] = None
        
    async def connect(
        self, 
        client_id: str, 
        auth_token: Optional[str] = None,
        session_id: Optional[str] = None,
        rooms: Optional[list] = None
    ) -> bool:
        """Connect to WebSocket endpoint."""
        try:
            self.client_id = client_id
            self.auth_token = auth_token
            self.session_id = session_id or client_id
            rooms = rooms or []
            
            # Prepare connection data
            connection_data = {
                "client_id": client_id,
                "session_id": self.session_id,
                "rooms": rooms
            }
            
            # Set up headers for authentication
            extra_headers = {}
            if auth_token:
                extra_headers["Authorization"] = f"Bearer {auth_token}"
            
            # Connect
            uri = f"{self.base_url}/ws"
            websocket = await websockets.connect(uri, extra_headers=extra_headers)
            
            # Send connection data
            await websocket.send(json.dumps(connection_data))
            
            # Wait for connection confirmation
            response = await websocket.recv()
            response_data = json.loads(response)
            
            if response_data.get("type") == "connection" and response_data.get("status") == "connected":
                self.connections[client_id] = websocket
                logger.info(f"Connected as {client_id}")
                return True
            else:
                logger.error(f"Connection failed: {response_data}")
                await websocket.close()
                return False
                
        except Exception as e:
            logger.error(f"Connection error: {str(e)}")
            return False
    
    async def disconnect(self, client_id: Optional[str] = None):
        """Disconnect WebSocket."""
        client_id = client_id or self.client_id
        if client_id and client_id in self.connections:
            websocket = self.connections.pop(client_id)
            await websocket.close()
            logger.info(f"Disconnected {client_id}")
    
    async def send_message(self, message_type: str, data: Dict[str, Any], client_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Send a message and get response."""
        client_id = client_id or self.client_id
        if client_id not in self.connections:
            logger.error(f"No connection for client {client_id}")
            return None
        
        websocket = self.connections[client_id]
        message = {"type": message_type, **data}
        
        try:
            # Send message
            await websocket.send(json.dumps(message))
            
            # Wait for response with timeout
            response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
            response_data = json.loads(response)
            
            logger.info(f"Sent {message_type}, received: {response_data.get('type', 'unknown')}")
            return response_data
            
        except asyncio.TimeoutError:
            logger.warning(f"Timeout waiting for response to {message_type}")
            return None
        except Exception as e:
            logger.error(f"Error sending {message_type}: {str(e)}")
            return None
    
    async def chat_message(self, content: str, room: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Send a chat message."""
        data = {
            "content": content,
            "session_id": self.session_id
        }
        if room:
            data["room"] = room
        
        return await self.send_message("chat_message", data)
    
    async def join_room(self, room: str) -> Optional[Dict[str, Any]]:
        """Join a room."""
        return await self.send_message("join_room", {"room": room})
    
    async def leave_room(self, room: str) -> Optional[Dict[str, Any]]:
        """Leave a room."""
        return await self.send_message("leave_room", {"room": room})
    
    async def send_ping(self) -> Optional[Dict[str, Any]]:
        """Send ping."""
        return await self.send_message("ping", {})
    
    async def get_stats(self) -> Optional[Dict[str, Any]]:
        """Get connection stats (admin only)."""
        return await self.send_message("get_stats", {})
    
    async def broadcast(self, message: str, room: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Send broadcast message (admin only)."""
        data = {"message": message}
        if room:
            data["room"] = room
        return await self.send_message("broadcast", data)
    
    async def admin_action(self, action: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Send admin action."""
        data = {"action": action, **kwargs}
        return await self.send_message("admin_action", data)

class WebSocketTester:
    """WebSocket testing orchestrator."""
    
    def __init__(self):
        self.client = WebSocketTestClient()
        
    async def test_basic_connection(self):
        """Test basic WebSocket connection."""
        logger.info("Testing basic connection...")
        
        success = await self.client.connect("test_client_1")
        if not success:
            logger.error("Basic connection test failed")
            return False
        
        # Test ping
        response = await self.client.send_ping()
        if not response or response.get("type") != "pong":
            logger.error("Ping test failed")
            return False
        
        await self.client.disconnect()
        logger.info("Basic connection test passed")
        return True
    
    async def test_chat_functionality(self):
        """Test chat functionality."""
        logger.info("Testing chat functionality...")
        
        # Connect
        success = await self.client.connect("chat_test_client")
        if not success:
            return False
        
        # Send chat message
        response = await self.client.chat_message("Hello, WebSocket!")
        if not response or response.get("type") != "chat_response":
            logger.error("Chat message test failed")
            return False
        
        # Test typing indicator
        typing_response = await self.client.send_message("typing_indicator", {"is_typing": True})
        if not typing_response:
            logger.warning("Typing indicator test failed (non-critical)")
        
        await self.client.disconnect()
        logger.info("Chat functionality test passed")
        return True
    
    async def test_room_management(self):
        """Test room management."""
        logger.info("Testing room management...")
        
        # Connect
        success = await self.client.connect("room_test_client")
        if not success:
            return False
        
        # Join room
        join_response = await self.client.join_room("test_room")
        if not join_response or join_response.get("type") != "room_joined":
            logger.error("Room join test failed")
            return False
        
        # Leave room
        leave_response = await self.client.leave_room("test_room")
        if not leave_response or leave_response.get("type") != "room_left":
            logger.error("Room leave test failed")
            return False
        
        await self.client.disconnect()
        logger.info("Room management test passed")
        return True
    
    async def test_rate_limiting(self):
        """Test rate limiting."""
        logger.info("Testing rate limiting...")
        
        # Connect
        success = await self.client.connect("rate_limit_test_client")
        if not success:
            return False
        
        # Send many messages quickly to trigger rate limiting
        responses = []
        for i in range(10):
            response = await self.client.send_ping()
            responses.append(response)
            await asyncio.sleep(0.1)  # Small delay between messages
        
        # Check if rate limiting was triggered
        rate_limited = any(
            response and response.get("type") == "error" and 
            "rate limit" in response.get("message", "").lower()
            for response in responses
        )
        
        if not rate_limited:
            logger.warning("Rate limiting test: no rate limiting detected (may be expected)")
        else:
            logger.info("Rate limiting test passed")
        
        await self.client.disconnect()
        return True
    
    async def test_multiple_connections(self):
        """Test multiple connections."""
        logger.info("Testing multiple connections...")
        
        # Create multiple clients
        clients = []
        for i in range(3):
            client = WebSocketTestClient()
            success = await client.connect(f"multi_client_{i}")
            if success:
                clients.append(client)
        
        if len(clients) < 2:
            logger.error("Multiple connection test failed - not enough clients connected")
            # Cleanup
            for client in clients:
                await client.disconnect()
            return False
        
        # Test broadcasting between clients
        # Note: This would require a test server setup for full end-to-end testing
        
        # Cleanup
        for client in clients:
            await client.disconnect()
        
        logger.info("Multiple connections test passed")
        return True
    
    async def test_error_handling(self):
        """Test error handling."""
        logger.info("Testing error handling...")
        
        # Connect
        success = await self.client.connect("error_test_client")
        if not success:
            return False
        
        # Test invalid message type
        response = await self.client.send_message("invalid_message_type", {})
        # Should get an error response or ignore invalid message
        
        # Test empty chat message
        empty_response = await self.client.chat_message("")
        if empty_response and empty_response.get("type") == "error":
            logger.info("Empty message error handling works correctly")
        
        await self.client.disconnect()
        logger.info("Error handling test passed")
        return True
    
    async def test_health_monitoring(self):
        """Test health monitoring endpoints."""
        logger.info("Testing health monitoring...")
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                # Test WebSocket health endpoint
                async with session.get("http://localhost:8000/health/websocket") as resp:
                    if resp.status == 200:
                        health_data = await resp.json()
                        logger.info(f"WebSocket health: {health_data.get('status', 'unknown')}")
                    else:
                        logger.warning(f"WebSocket health endpoint returned status {resp.status}")
                
                # Test WebSocket stats endpoint
                async with session.get("http://localhost:8000/stats/websocket") as resp:
                    if resp.status == 200:
                        stats_data = await resp.json()
                        logger.info("WebSocket stats endpoint accessible")
                    else:
                        logger.warning(f"WebSocket stats endpoint returned status {resp.status}")
                        
        except ImportError:
            logger.warning("aiohttp not available for health monitoring test")
        except Exception as e:
            logger.warning(f"Health monitoring test failed: {str(e)}")
        
        return True
    
    async def run_all_tests(self):
        """Run all WebSocket tests."""
        logger.info("Starting comprehensive WebSocket tests...")
        
        tests = [
            ("Basic Connection", self.test_basic_connection),
            ("Chat Functionality", self.test_chat_functionality),
            ("Room Management", self.test_room_management),
            ("Rate Limiting", self.test_rate_limiting),
            ("Multiple Connections", self.test_multiple_connections),
            ("Error Handling", self.test_error_handling),
            ("Health Monitoring", self.test_health_monitoring)
        ]
        
        results = {}
        for test_name, test_func in tests:
            try:
                logger.info(f"Running {test_name} test...")
                result = await test_func()
                results[test_name] = result
                status = "PASSED" if result else "FAILED"
                logger.info(f"{test_name} test: {status}")
            except Exception as e:
                logger.error(f"{test_name} test failed with exception: {str(e)}")
                results[test_name] = False
        
        # Summary
        logger.info("\n" + "="*50)
        logger.info("WEBSOCKET TEST RESULTS")
        logger.info("="*50)
        
        passed = sum(1 for result in results.values() if result)
        total = len(results)
        
        for test_name, result in results.items():
            status = "✅ PASSED" if result else "❌ FAILED"
            logger.info(f"{test_name}: {status}")
        
        logger.info(f"\nTotal: {passed}/{total} tests passed")
        
        if passed == total:
            logger.info("🎉 All WebSocket tests passed!")
        else:
            logger.warning(f"⚠️  {total - passed} tests failed")
        
        return results

async def main():
    """Main test runner."""
    logger.info("WebSocket Comprehensive Test Suite")
    logger.info("Make sure the backend server is running on http://localhost:8000")
    
    # Wait a moment for server to be ready
    await asyncio.sleep(1)
    
    tester = WebSocketTester()
    results = await tester.run_all_tests()
    
    # Return exit code based on results
    all_passed = all(results.values())
    return 0 if all_passed else 1

if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        logger.info("Tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Test suite failed: {str(e)}")
        sys.exit(1)
