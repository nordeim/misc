#!/usr/bin/env python3
"""
Simple test for the Enhanced Escalation Tool core functionality.

This script tests the escalation decision logic without database dependencies.
"""

import asyncio
import re
from datetime import datetime
from typing import Dict, Any, List, Optional
from enum import Enum


class EscalationPriority(str, Enum):
    """Priority levels for escalations."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    URGENT = "urgent"


class EscalationReason(str, Enum):
    """Reasons for escalation."""
    SENTIMENT = "sentiment"
    KEYWORDS = "keywords"
    CONVERSATION_LENGTH = "conversation_length"
    CONFIDENCE = "confidence"
    COMPLEXITY = "complexity"
    MANUAL_REQUEST = "manual_request"


class EscalationContext:
    """Simple escalation context for testing."""
    
    def __init__(
        self,
        message: str,
        conversation_length: int,
        user_sentiment: float,
        rag_confidence: float,
        technical_complexity: float = 0.0,
        business_impact: float = 0.0,
        compliance_risk: float = 0.0,
        previous_escalations: int = 0,
        time_since_last_response: float = 0.0,
        customer_tier: Optional[str] = None
    ):
        self.message = message
        self.conversation_length = conversation_length
        self.user_sentiment = user_sentiment
        self.rag_confidence = rag_confidence
        self.technical_complexity = technical_complexity
        self.business_impact = business_impact
        self.compliance_risk = compliance_risk
        self.previous_escalations = previous_escalations
        self.time_since_last_response = time_since_last_response
        self.customer_tier = customer_tier


class SimpleEscalationTool:
    """Simplified escalation tool for testing core functionality."""
    
    def __init__(self):
        """Initialize the escalation tool with patterns and thresholds."""
        
        # Enhanced escalation keywords with categories
        self.escalation_keywords = {
            'frustration': [
                "frustrated", "angry", "upset", "annoyed", "dissatisfied",
                "terrible", "awful", "horrible", "worst", "hate", "rage",
                "furious", "livid", "disgusted", "fed up"
            ],
            'urgency': [
                "urgent", "emergency", "asap", "immediately", "critical",
                "outage", "down", "can't access", "lost", "stolen", "crisis"
            ],
            'escalation_request': [
                "speak to manager", "talk to supervisor", "human agent",
                "escalate", "supervisor", "manager", "representative",
                "customer service", "real person", "human", "escalate to human"
            ],
            'financial_legal': [
                "refund", "chargeback", "lawsuit", "legal", "attorney",
                "fraud", "unauthorized", "dispute", "billing error",
                "credit card", "charge", "scam", "theft"
            ],
            'technical_complex': [
                "bug", "error", "crash", "system error", "technical issue",
                "debug", "programming", "code", "development", "api",
                "database", "server", "infrastructure"
            ],
            'compliance': [
                "policy", "terms of service", "violation", "complaint",
                "report", "terms", "compliance", "regulatory", "gdpr",
                "privacy", "data protection", "audit"
            ],
            'service_quality': [
                "poor service", "bad experience", "disappointed",
                "unacceptable", "refuse to use", "cancel", "terminate",
                "poor support", "inadequate", "unsatisfactory"
            ]
        }
        
        # Enhanced thresholds and weights
        self.escalation_weights = {
            'sentiment': 0.25,
            'keywords': 0.20,
            'confidence': 0.20,
            'complexity': 0.15,
            'conversation_length': 0.10,
            'urgency': 0.10
        }
        
        self.confidence_thresholds = {
            'high': 0.8,
            'medium': 0.6,
            'low': 0.4,
            'critical': 0.9
        }
        
        # Conversation thresholds
        self.max_conversation_turns = 15
        self.critical_conversation_turns = 25
        
    async def get_escalation_decision(
        self,
        message: str,
        context: EscalationContext
    ) -> Dict[str, Any]:
        """Get comprehensive escalation decision with full analysis."""
        
        # Calculate scores
        scores = await self._calculate_escalation_scores(context)
        
        # Determine if escalation is needed
        should_escalate = scores['total_score'] >= self.confidence_thresholds['medium']
        
        # Determine priority
        priority_level = self._determine_priority(context, scores)
        
        # Generate alternative actions
        alternative_actions = self._generate_alternative_actions(context, scores)
        
        # Calculate complexity assessment
        complexity_assessment = await self._assess_complexity(context)
        
        return {
            'should_escalate': should_escalate,
            'confidence_score': scores['confidence'],
            'escalation_score': scores['total_score'],
            'reasons': self._get_escalation_reasons(context, scores),
            'priority_level': priority_level,
            'urgency_score': scores.get('urgency', 0.0),
            'complexity_assessment': complexity_assessment,
            'alternative_actions': alternative_actions
        }
    
    async def _calculate_escalation_scores(
        self,
        context: EscalationContext
    ) -> Dict[str, float]:
        """Calculate comprehensive escalation scores."""
        
        scores = {}
        
        # Sentiment score
        scores['sentiment'] = context.user_sentiment
        
        # Keyword score
        scores['keywords'] = await self._analyze_enhanced_keywords(context.message)
        
        # Confidence score (inverted - lower confidence = higher escalation)
        scores['confidence'] = 1.0 - context.rag_confidence
        
        # Complexity score
        scores['complexity'] = max(
            context.technical_complexity,
            context.business_impact,
            context.compliance_risk
        )
        
        # Conversation length score
        scores['conversation_length'] = self._analyze_conversation_length_score(context.conversation_length)
        
        # Urgency score
        scores['urgency'] = await self._analyze_urgency(context)
        
        # Calculate weighted total score
        total_score = sum(
            scores[key] * weight
            for key, weight in self.escalation_weights.items()
            if key in scores
        )
        
        scores['total_score'] = total_score
        scores['confidence'] = max(scores.values()) if scores else 0.0
        
        return scores
    
    def _determine_priority(
        self,
        context: EscalationContext,
        scores: Dict[str, float]
    ) -> EscalationPriority:
        """Determine escalation priority level."""
        
        # Check for critical indicators
        if (context.compliance_risk > 0.8 or
            context.business_impact > 0.8 or
            context.previous_escalations > 2):
            return EscalationPriority.CRITICAL
        
        # Check for urgent indicators
        if (context.user_sentiment > 0.9 or
            scores.get('urgency', 0) > 0.8 or
            context.conversation_length > self.critical_conversation_turns):
            return EscalationPriority.URGENT
        
        # Check for high priority
        if (context.user_sentiment > 0.7 or
            context.technical_complexity > 0.7 or
            scores.get('total_score', 0) > 0.7):
            return EscalationPriority.HIGH
        
        # Check for medium priority
        if (context.user_sentiment > 0.5 or
            context.technical_complexity > 0.5 or
            scores.get('total_score', 0) > 0.5):
            return EscalationPriority.MEDIUM
        
        return EscalationPriority.LOW
    
    async def _analyze_enhanced_keywords(self, message: str) -> float:
        """Enhanced keyword analysis with categories and weights."""
        
        message_lower = message.lower()
        category_scores = {}
        
        for category, keywords in self.escalation_keywords.items():
            category_matches = sum(1 for keyword in keywords if keyword in message_lower)
            if category_matches > 0:
                # Weight different categories differently
                category_weights = {
                    'frustration': 1.0,
                    'urgency': 1.2,
                    'escalation_request': 1.5,
                    'financial_legal': 1.3,
                    'technical_complex': 1.1,
                    'compliance': 1.4,
                    'service_quality': 1.0
                }
                category_scores[category] = (category_matches / len(keywords)) * category_weights.get(category, 1.0)
        
        if not category_scores:
            return 0.0
        
        # Return weighted average of category scores
        total_weighted_score = sum(category_scores.values())
        total_weight = sum(1.0 for _ in category_scores)
        
        return min(1.0, total_weighted_score / total_weight)
    
    def _analyze_conversation_length_score(self, conversation_length: int) -> float:
        """Analyze conversation length for escalation indicators."""
        
        if conversation_length > self.critical_conversation_turns:
            return 1.0
        elif conversation_length > self.max_conversation_turns:
            excess = conversation_length - self.max_conversation_turns
            return min(1.0, excess / (self.critical_conversation_turns - self.max_conversation_turns))
        else:
            return 0.0
    
    async def _analyze_urgency(self, context: EscalationContext) -> float:
        """Analyze urgency indicators."""
        
        urgency_score = 0.0
        
        # Time-based urgency
        if context.time_since_last_response > 60:  # 1 hour
            urgency_score += 0.3
        elif context.time_since_last_response > 30:  # 30 minutes
            urgency_score += 0.1
        
        # Previous escalation urgency
        if context.previous_escalations > 0:
            urgency_score += context.previous_escalations * 0.2
        
        # Message-based urgency
        urgent_keywords = ['urgent', 'emergency', 'asap', 'immediately', 'critical']
        if any(keyword in context.message.lower() for keyword in urgent_keywords):
            urgency_score += 0.5
        
        return min(1.0, urgency_score)
    
    def _get_escalation_reasons(
        self,
        context: EscalationContext,
        scores: Dict[str, float]
    ) -> List[str]:
        """Get detailed reasons for escalation decision."""
        
        reasons = []
        
        if context.user_sentiment > 0.6:
            reasons.append(EscalationReason.SENTIMENT.value)
        
        if scores.get('keywords', 0) > 0.5:
            reasons.append(EscalationReason.KEYWORDS.value)
        
        if context.conversation_length > self.max_conversation_turns:
            reasons.append(EscalationReason.CONVERSATION_LENGTH.value)
        
        if context.rag_confidence < self.confidence_thresholds['high']:
            reasons.append(EscalationReason.CONFIDENCE.value)
        
        if context.technical_complexity > 0.6:
            reasons.append(EscalationReason.COMPLEXITY.value)
        
        # Check for explicit escalation requests
        message_lower = context.message.lower()
        if any(phrase in message_lower for phrase in ['escalate', 'human', 'manager', 'supervisor']):
            reasons.append(EscalationReason.MANUAL_REQUEST.value)
        
        return reasons
    
    def _generate_alternative_actions(
        self,
        context: EscalationContext,
        scores: Dict[str, float]
    ) -> List[str]:
        """Generate alternative actions to escalation."""
        
        actions = []
        
        # Sentiment-based actions
        if context.user_sentiment > 0.6:
            actions.append("Send empathetic response acknowledging frustration")
            actions.append("Offer to schedule callback at customer's convenience")
        
        # Confidence-based actions
        if context.rag_confidence < 0.6:
            actions.append("Provide more detailed information or FAQ links")
            actions.append("Suggest alternative support channels")
        
        # Technical complexity actions
        if context.technical_complexity > 0.6:
            actions.append("Create technical support ticket")
            actions.append("Schedule technical consultation")
        
        # Conversation length actions
        if context.conversation_length > self.max_conversation_turns:
            actions.append("Offer to continue conversation via phone")
            actions.append("Provide summary of previous interactions")
        
        return actions[:5]  # Limit to top 5 actions
    
    async def _assess_complexity(self, context: EscalationContext) -> Dict[str, Any]:
        """Assess the complexity of the issue."""
        
        complexity_factors = {
            'technical_depth': context.technical_complexity,
            'business_impact': context.business_impact,
            'compliance_risk': context.compliance_risk,
            'resolution_difficulty': max(
                context.technical_complexity,
                context.business_impact,
                context.compliance_risk
            )
        }
        
        overall_complexity = max(complexity_factors.values())
        
        complexity_level = "Low"
        if overall_complexity > 0.8:
            complexity_level = "Very High"
        elif overall_complexity > 0.6:
            complexity_level = "High"
        elif overall_complexity > 0.4:
            complexity_level = "Medium"
        
        return {
            'complexity_score': overall_complexity,
            'complexity_level': complexity_level,
            'factors': complexity_factors,
            'estimated_resolution_time': self._estimate_resolution_time(overall_complexity)
        }
    
    def _estimate_resolution_time(self, complexity_score: float) -> str:
        """Estimate resolution time based on complexity."""
        
        if complexity_score > 0.8:
            return "2-4 hours"
        elif complexity_score > 0.6:
            return "1-2 hours"
        elif complexity_score > 0.4:
            return "30-60 minutes"
        else:
            return "15-30 minutes"


async def test_basic_scenarios():
    """Test basic escalation scenarios."""
    print("=" * 60)
    print("Testing Basic Escalation Scenarios")
    print("=" * 60)
    
    escalation_tool = SimpleEscalationTool()
    
    # Test scenarios
    test_scenarios = [
        {
            "name": "Frustrated Customer",
            "context": EscalationContext(
                message="I'm so frustrated with this terrible service! I've been waiting for hours and nothing works!",
                conversation_length=8,
                user_sentiment=0.9,
                rag_confidence=0.7
            )
        },
        {
            "name": "Technical Crisis",
            "context": EscalationContext(
                message="URGENT: Our production system is down! The API is failing and customers can't access their accounts!",
                conversation_length=5,
                user_sentiment=0.8,
                rag_confidence=0.4,
                technical_complexity=0.9,
                business_impact=0.8
            )
        },
        {
            "name": "Billing Dispute",
            "context": EscalationContext(
                message="I want a refund for this unauthorized charge on my credit card. This is fraudulent!",
                conversation_length=6,
                user_sentiment=0.7,
                rag_confidence=0.6
            )
        },
        {
            "name": "Manager Request",
            "context": EscalationContext(
                message="I need to speak to a manager or supervisor immediately about this issue.",
                conversation_length=4,
                user_sentiment=0.6,
                rag_confidence=0.8
            )
        },
        {
            "name": "Long Conversation",
            "context": EscalationContext(
                message="We've been talking for a while and I'm still not satisfied with the solution.",
                conversation_length=20,
                user_sentiment=0.6,
                rag_confidence=0.7
            )
        },
        {
            "name": "Normal Conversation",
            "context": EscalationContext(
                message="Thank you for the information. That answers my question.",
                conversation_length=3,
                user_sentiment=0.2,
                rag_confidence=0.9
            )
        }
    ]
    
    for scenario in test_scenarios:
        print(f"\n{scenario['name']}:")
        print(f"  Message: '{scenario['context'].message}'")
        
        decision = await escalation_tool.get_escalation_decision(
            message=scenario['context'].message,
            context=scenario['context']
        )
        
        print(f"  Should escalate: {decision['should_escalate']}")
        print(f"  Priority: {decision['priority_level']}")
        print(f"  Escalation score: {decision['escalation_score']:.2f}")
        print(f"  Confidence: {decision['confidence_score']:.2f}")
        print(f"  Reasons: {decision['reasons']}")
        print(f"  Complexity: {decision['complexity_assessment']['complexity_level']}")
        print(f"  Estimated resolution: {decision['complexity_assessment']['estimated_resolution_time']}")
        
        if decision['alternative_actions']:
            print(f"  Alternative actions: {decision['alternative_actions'][:2]}")


async def test_keyword_analysis():
    """Test keyword analysis by categories."""
    print("\n" + "=" * 60)
    print("Testing Keyword Analysis")
    print("=" * 60)
    
    escalation_tool = SimpleEscalationTool()
    
    test_cases = [
        {
            "name": "Frustration",
            "message": "I'm so frustrated with this broken system. This is terrible!",
            "expected_high": True
        },
        {
            "name": "Urgency",
            "message": "This is urgent and critical! I need help immediately!",
            "expected_high": True
        },
        {
            "name": "Escalation Request",
            "message": "I want to speak to a manager or supervisor right now.",
            "expected_high": True
        },
        {
            "name": "Technical",
            "message": "There's a bug in the API integration and the database is down.",
            "expected_high": True
        },
        {
            "name": "Financial",
            "message": "I want a refund for this unauthorized charge on my credit card.",
            "expected_high": True
        },
        {
            "name": "Normal",
            "message": "What are your business hours?",
            "expected_high": False
        }
    ]
    
    for test_case in test_cases:
        keyword_score = await escalation_tool._analyze_enhanced_keywords(test_case["message"])
        
        print(f"{test_case['name']}: '{test_case['message']}'")
        print(f"  Keyword score: {keyword_score:.2f}")
        print(f"  Expected high: {test_case['expected_high']}")
        print(f"  Result: {'✓' if (keyword_score > 0.5) == test_case['expected_high'] else '✗'}")
        print()


async def test_sentiment_analysis():
    """Test sentiment analysis functionality."""
    print("\n" + "=" * 60)
    print("Testing Sentiment Analysis")
    print("=" * 60)
    
    def analyze_sentiment(message: str) -> float:
        """Simple sentiment analysis."""
        negative_patterns = [
            r'\b(frustrated|angry|upset|annoyed|dissatisfied|furious|livid)\b',
            r'\b(terrible|awful|horrible|worst|hate|disgusting)\b',
            r'\b(not working|broken|useless|incompetent|failure)\b',
            r'\b(refuse|reject|unacceptable|disappointing)\b'
        ]
        
        urgency_patterns = [
            r'!{2,}',
            r'\?{2,}',
            r'\b(urgent|emergency|critical|immediately|asap)\b',
            r'[A-Z]{4,}',
            r'\.{3,}',
        ]
        
        sentiment_score = 0.0
        
        for pattern in negative_patterns:
            matches = re.findall(pattern, message, re.IGNORECASE)
            sentiment_score += len(matches) * 0.2
        
        for pattern in urgency_patterns:
            matches = re.findall(pattern, message, re.IGNORECASE)
            sentiment_score += len(matches) * 0.15
        
        return min(1.0, sentiment_score)
    
    test_messages = [
        ("Hello, I need some help please.", "Low"),
        ("This is really frustrating!", "Medium"),
        ("I'm angry about this terrible service!", "High"),
        ("URGENT!!! I need help RIGHT NOW!!!", "Very High"),
        ("Thank you for your help, this solved my problem.", "Very Low")
    ]
    
    for message, expected_level in test_messages:
        sentiment_score = analyze_sentiment(message)
        print(f"Message: '{message}'")
        print(f"  Sentiment score: {sentiment_score:.2f}")
        print(f"  Expected level: {expected_level}")
        print()


async def main():
    """Run all tests."""
    print("Enhanced Escalation Tool - Core Functionality Test")
    print("=" * 60)
    
    try:
        await test_basic_scenarios()
        await test_keyword_analysis()
        await test_sentiment_analysis()
        
        print("\n" + "=" * 60)
        print("All tests completed successfully!")
        print("The escalation tool demonstrates intelligent decision-making")
        print("for human handoff scenarios.")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nError during testing: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())