"""
Stream Handlers for different streaming scenarios.
"""

import asyncio
import time
from typing import Dict, Any, Optional, List, AsyncIterator
from datetime import datetime, timedelta

from .models import (
    StreamEvent, StreamEventType, StreamError,
    TokenChunk, ProgressUpdate, StreamContext,
    StreamState
)
from .managers import StreamManager, StreamConnection, StreamSession
import structlog

logger = structlog.get_logger(__name__)


class StreamCancellable:
    """Base class for cancellable streams."""
    
    def __init__(self):
        self._cancelled = asyncio.Event()
        self._cancellation_reason: Optional[str] = None
    
    def cancel(self, reason: str = "Cancelled by user"):
        """Cancel the stream."""
        self._cancellation_reason = reason
        self._cancelled.set()
    
    def is_cancelled(self) -> bool:
        """Check if stream is cancelled."""
        return self._cancelled.is_set()
    
    async def wait_for_cancellation(self) -> Optional[str]:
        """Wait for cancellation signal."""
        if self._cancelled.is_set():
            return self._cancellation_reason
        
        try:
            await asyncio.wait_for(self._cancelled.wait(), timeout=None)
            return self._cancellation_reason
        except asyncio.CancelledError:
            return self._cancellation_reason
    
    def check_cancellation(self):
        """Check for cancellation and raise exception if cancelled."""
        if self.is_cancelled():
            raise asyncio.CancelledError(f"Stream cancelled: {self._cancellation_reason}")


class ProgressTracker:
    """Track and report progress for long-running operations."""
    
    def __init__(self, session_id: str, operation_id: str, total_steps: int):
        self.session_id = session_id
        self.operation_id = operation_id
        self.total_steps = total_steps
        self.current_step = 0
        self.current_step_name = ""
        self.start_time = datetime.utcnow()
        self.step_history: List[Dict[str, Any]] = []
        self.percentage = 0.0
        self.estimated_completion: Optional[datetime] = None
    
    async def update_step(self, step_name: str, step_increment: int = 1):
        """Update the current step."""
        self.current_step += step_increment
        self.current_step_name = step_name
        
        # Calculate percentage
        self.percentage = min(100.0, (self.current_step / self.total_steps) * 100)
        
        # Estimate completion time
        if self.percentage > 0:
            elapsed = (datetime.utcnow() - self.start_time).total_seconds()
            estimated_total = elapsed / (self.percentage / 100)
            remaining = estimated_total - elapsed
            self.estimated_completion = datetime.utcnow() + timedelta(seconds=remaining)
        
        # Log step
        logger.debug("Progress step updated",
                    session_id=self.session_id,
                    operation_id=self.operation_id,
                    step_name=step_name,
                    current_step=self.current_step,
                    total_steps=self.total_steps,
                    percentage=self.percentage)
    
    async def get_progress_update(self, metadata: Optional[Dict[str, Any]] = None) -> ProgressUpdate:
        """Get current progress update."""
        return ProgressUpdate(
            session_id=self.session_id,
            operation_id=self.operation_id,
            progress_percentage=self.percentage,
            current_step=self.current_step_name,
            total_steps=self.total_steps,
            estimated_completion=self.estimated_completion,
            metadata=metadata or {}
        )
    
    def is_complete(self) -> bool:
        """Check if progress is complete."""
        return self.current_step >= self.total_steps


class ChatStreamHandler(StreamCancellable):
    """Handler for chat message streaming."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.active_streams: Dict[str, "ChatStreamingContext"] = {}
    
    async def start_stream(
        self,
        context: StreamContext,
        message: str,
        connection_id: Optional[str] = None
    ) -> StreamConnection:
        """Start a streaming chat response."""
        
        # Create session and connection
        session = await self.stream_manager.create_session(context)
        connection = await self.stream_manager.create_connection(session.session_id, connection_id)
        
        if not connection:
            raise RuntimeError("Failed to create streaming connection")
        
        # Store streaming context
        streaming_ctx = ChatStreamingContext(session, connection, message)
        self.active_streams[session.session_id] = streaming_ctx
        
        # Send initial event
        await connection.send_event(StreamEvent(
            type=StreamEventType.CONNECT,
            session_id=session.session_id,
            data={"message": "Chat stream started", "content": message}
        ))
        
        return connection
    
    async def stream_response(
        self,
        session_id: str,
        response_generator: AsyncIterator[str],
        token_callback: Optional[callable] = None
    ):
        """Stream response tokens to the connection."""
        
        if session_id not in self.active_streams:
            raise ValueError(f"Session {session_id} not found")
        
        streaming_ctx = self.active_streams[session_id]
        connection = streaming_ctx.connection
        session = streaming_ctx.session
        
        try:
            # Mark as active
            connection.state = StreamState.ACTIVE
            
            token_count = 0
            chunk_index = 0
            
            async for token_text in response_generator:
                self.check_cancellation()
                
                token_count += 1
                chunk_index += 1
                
                # Create token chunk
                token_chunk = TokenChunk(
                    content=token_text,
                    token_count=len(token_text.split()),
                    chunk_index=chunk_index,
                    is_final=False
                )
                
                # Send token
                await connection.send_token(token_chunk)
                
                # Call optional token callback
                if token_callback:
                    await token_callback(token_text, token_count)
                
                # Small delay to prevent overwhelming the connection
                await asyncio.sleep(0.01)
            
            # Send final token
            final_token = TokenChunk(
                content="",
                token_count=0,
                chunk_index=chunk_index + 1,
                is_final=True
            )
            
            await connection.send_token(final_token)
            
            # Complete stream
            await connection.complete()
            
        except asyncio.CancelledError:
            logger.info("Chat stream cancelled", session_id=session_id)
            await connection.cancel("Stream cancelled by client")
        except Exception as e:
            logger.error("Chat stream error", session_id=session_id, error=str(e))
            await connection.error(StreamError(
                error_code="stream_error",
                error_message=str(e),
                error_type="server_error",
                recoverable=False
            ))
        finally:
            # Clean up
            if session_id in self.active_streams:
                del self.active_streams[session_id]
    
    async def cancel_stream(self, session_id: str, reason: str = "Cancelled by user"):
        """Cancel a streaming session."""
        if session_id in self.active_streams:
            streaming_ctx = self.active_streams[session_id]
            streaming_ctx.cancel(reason)
            await streaming_ctx.connection.cancel(reason)
    
    async def send_progress(
        self,
        session_id: str,
        progress: ProgressUpdate
    ):
        """Send progress update to session."""
        if session_id in self.active_streams:
            streaming_ctx = self.active_streams[session_id]
            await streaming_ctx.connection.send_progress(progress)


class AgentStreamHandler(StreamCancellable):
    """Handler for agent response streaming."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.active_streams: Dict[str, "AgentStreamingContext"] = {}
    
    async def start_agent_stream(
        self,
        context: StreamContext,
        agent_response_generator: AsyncIterator[str],
        connection_id: Optional[str] = None
    ) -> StreamConnection:
        """Start streaming agent response."""
        
        session = await self.stream_manager.create_session(context)
        connection = await self.stream_manager.create_connection(session.session_id, connection_id)
        
        if not connection:
            raise RuntimeError("Failed to create agent stream connection")
        
        streaming_ctx = AgentStreamingContext(session, connection, agent_response_generator)
        self.active_streams[session.session_id] = streaming_ctx
        
        # Send initial event
        await connection.send_event(StreamEvent(
            type=StreamEventType.CONNECT,
            session_id=session.session_id,
            data={"type": "agent_stream", "agent_id": context.user_id}
        ))
        
        return connection
    
    async def stream_agent_response(
        self,
        session_id: str,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Stream agent response to connection."""
        
        if session_id not in self.active_streams:
            raise ValueError(f"Agent stream session {session_id} not found")
        
        streaming_ctx = self.active_streams[session_id]
        connection = streaming_ctx.connection
        generator = streaming_ctx.generator
        
        try:
            connection.state = StreamState.ACTIVE
            
            # Send metadata event
            if metadata:
                await connection.send_event(StreamEvent(
                    type=StreamEventType.META,
                    session_id=session_id,
                    data=metadata
                ))
            
            # Stream response
            async for chunk in generator:
                self.check_cancellation()
                
                token_chunk = TokenChunk(
                    content=chunk,
                    token_count=len(chunk.split()),
                    chunk_index=0
                )
                
                await connection.send_token(token_chunk)
                await asyncio.sleep(0.01)  # Prevent overwhelming
            
            # Complete stream
            await connection.complete()
            
        except asyncio.CancelledError:
            logger.info("Agent stream cancelled", session_id=session_id)
            await connection.cancel("Agent stream cancelled")
        except Exception as e:
            logger.error("Agent stream error", session_id=session_id, error=str(e))
            await connection.error(StreamError(
                error_code="agent_stream_error",
                error_message=str(e),
                error_type="server_error",
                recoverable=False
            ))
        finally:
            if session_id in self.active_streams:
                del self.active_streams[session_id]
    
    async def cancel_agent_stream(self, session_id: str, reason: str = "Agent stream cancelled"):
        """Cancel agent stream."""
        if session_id in self.active_streams:
            streaming_ctx = self.active_streams[session_id]
            streaming_ctx.cancel(reason)
            await streaming_ctx.connection.cancel(reason)


class ChatStreamingContext:
    """Context for streaming chat sessions."""
    
    def __init__(self, session: StreamSession, connection: StreamConnection, message: str):
        self.session = session
        self.connection = connection
        self.original_message = message
        self.start_time = datetime.utcnow()


class AgentStreamingContext:
    """Context for streaming agent sessions."""
    
    def __init__(self, session: StreamSession, connection: StreamConnection, generator: AsyncIterator[str]):
        self.session = session
        self.connection = connection
        self.generator = generator
        self.start_time = datetime.utcnow()


class StreamingChatSimulator:
    """Simulator for testing streaming chat responses."""
    
    def __init__(self):
        self.responses = [
            "I'm analyzing your request...",
            "Let me help you with that.",
            "Based on your question, I can provide the following information:",
            "Here are the key points:",
            "1. First, we need to consider the main factors.",
            "2. The solution involves several steps.",
            "3. Here's what I recommend.",
            "4. Let me know if you need more details."
        ]
    
    async def generate_streaming_response(
        self,
        message: str,
        delay: float = 0.2
    ) -> AsyncIterator[str]:
        """Generate a streaming response for testing."""
        
        # Simulate processing time
        await asyncio.sleep(0.5)
        
        # Stream response tokens
        for i, response in enumerate(self.responses):
            await asyncio.sleep(delay)
            yield response
        
        # Complete
        yield ""


class StreamingAgentSimulator:
    """Simulator for testing streaming agent responses."""
    
    async def generate_agent_response(
        self,
        query: str,
        context: Dict[str, Any]
    ) -> AsyncIterator[str]:
        """Generate a streaming agent response."""
        
        # Simulate agent processing
        await asyncio.sleep(0.3)
        
        # Stream agent reasoning
        agent_steps = [
            "Processing request...",
            f"Analyzing query: {query[:50]}...",
            "Consulting knowledge base...",
            "Formulating response...",
            "Generating final answer..."
        ]
        
        for step in agent_steps:
            await asyncio.sleep(0.4)
            yield f"🤖 {step}\n\n"
        
        # Stream actual response
        response_parts = [
            "Based on my analysis, I can help you with that.",
            "The best approach would be to consider the following factors.",
            "Here's my recommendation:",
            "Please let me know if you need clarification."
        ]
        
        for part in response_parts:
            await asyncio.sleep(0.3)
            yield f"{part}\n\n"