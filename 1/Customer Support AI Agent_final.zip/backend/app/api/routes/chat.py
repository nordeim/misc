"""
Chat API routes for comprehensive message handling.
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from fastapi.security import HTTPBearer
from typing import List, Optional, Dict, Any, Union
import logging
import uuid
import json
import re
import hashlib
from datetime import datetime, timedelta
from io import StringIO
import csv
from pathlib import Path
import asyncio

from sqlalchemy import select, func, desc, and_, or_, text, exists
from sqlalchemy.orm import selectinload, Session
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db, AsyncSession
from app.agents.chat_agent import CustomerSupportAgent, AgentContext
from app.models.session import SessionORM, SessionCreate, SessionUpdate, SessionRead, SessionSummary, SessionClose
from app.models.message import MessageORM, MessageCreate, MessageUpdate, MessageRead
from app.models.user import UserORM
from app.services.message_service import MessageService
from app.services.message_analytics_service import MessageAnalyticsService
from app.services.message_security_service import MessageSecurityService
from app.services.message_utilities_service import MessageUtilitiesService

# Import additional models
from app.models.memory import MemoryORM
from app.models.escalation import EscalationORM, EscalationLogORM

# Enhanced validation imports
from app.validation import validate_chat_message, ValidateRequest, ValidationRule, ValidationType

logger = logging.getLogger(__name__)
router = APIRouter()
security = HTTPBearer()

# Initialize services
message_service = MessageService()
analytics_service = MessageAnalyticsService()
security_service = MessageSecurityService()
utilities_service = MessageUtilitiesService()

# Initialize the agent
agent = CustomerSupportAgent()

# ============================================================================
# CORE MESSAGE PROCESSING ENDPOINTS
# ============================================================================

@router.post("/chat", response_model=Dict[str, Any])
@validate_chat_message()
async def send_message(
    message: str,
    session_id: Optional[str] = None,
    file_attachments: Optional[List[UploadFile]] = None,
    parent_message_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Send a message to the chat agent with enhanced processing capabilities.
    
    Args:
        message: The user's message content
        session_id: Optional session ID for continuing conversations
        file_attachments: Optional list of uploaded files
        parent_message_id: Optional ID for message threading
        metadata: Optional metadata for the message
        
    Returns:
        Enhanced chat response with comprehensive data
    """
    start_time = datetime.utcnow()
    
    try:
        # Security validation and content sanitization
        sanitized_message = await security_service.sanitize_content(message)
        pii_detected = await security_service.detect_pii(sanitized_message)
        security_level = await security_service.get_security_level(sanitized_message, pii_detected)
        
        # Create or get session
        session_obj = None
        if not session_id:
            session_id = str(uuid.uuid4())
            session_obj = SessionORM(
                id=session_id,
                user_id="anonymous",  # Would be from auth in real implementation
                title=f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                status="active"
            )
            db.add(session_obj)
        else:
            result = await db.execute(
                select(SessionORM).where(SessionORM.id == session_id)
            )
            session_obj = result.scalar_one_or_none()
            if not session_obj:
                raise HTTPException(status_code=404, detail="Session not found")
        
        # Process file attachments with security scanning
        processed_attachments = []
        if file_attachments:
            for file in file_attachments:
                # Security check for file
                file_scan_result = await security_service.scan_file(file)
                if not file_scan_result.safe:
                    raise HTTPException(status_code=400, detail=f"File {file.filename} failed security scan")
                
                # Process attachment
                attachment_data = await message_service.process_attachment(file, session_id)
                processed_attachments.append(attachment_data)
        
        # Load message history for context
        history_messages = await message_service.get_session_messages(
            session_id, limit=20, db=db
        )
        
        # Create agent context with enhanced data
        context = AgentContext(
            session_id=session_id,
            user_id="anonymous",  # Would be from auth in real implementation
            message_history=[msg.dict() for msg in history_messages],
            current_file_attachments=[att['path'] for att in processed_attachments],
            parent_message_id=parent_message_id,
            metadata=metadata or {}
        )
        
        # Process message with agent
        response = await agent.process_message(sanitized_message, context)
        
        # Store user message with comprehensive data
        user_message_data = {
            "session_id": session_id,
            "role": "user",
            "content": sanitized_message,
            "content_type": "text",
            "sequence_number": await message_service.get_next_sequence_number(session_id, db),
            "parent_message_id": parent_message_id,
            "attachments": processed_attachments,
            "metadata": {
                **(metadata or {}),
                "pii_detected": pii_detected,
                "security_level": security_level,
                "original_message": message,  # Store original before sanitization
                "processing_start": start_time.isoformat()
            }
        }
        
        user_message = MessageORM(**user_message_data)
        db.add(user_message)
        
        # Store assistant response
        assistant_message_data = {
            "session_id": session_id,
            "role": "assistant",
            "content": response.content,
            "content_type": "text",
            "sequence_number": await message_service.get_next_sequence_number(session_id, db),
            "parent_message_id": user_message.id,
            "model_name": response.model_name or "default",
            "provider": response.provider or "default",
            "prompt_tokens": response.prompt_tokens or 0,
            "completion_tokens": response.completion_tokens or 0,
            "total_tokens": response.total_tokens or 0,
            "cost_usd": response.cost_usd or 0.0,
            "confidence_score": response.confidence_score or 0.0,
            "tool_calls": response.tool_calls,
            "metadata": {
                "attachments_processed": response.attachments_processed,
                "escalation_triggered": response.escalation_triggered,
                "sources": response.sources,
                "processing_time": response.processing_time,
                "security_level": security_level
            }
        }
        
        assistant_message = MessageORM(**assistant_message_data)
        db.add(assistant_message)
        
        # Update session activity
        if session_obj:
            session_obj.message_count += 2  # User + Assistant message
            session_obj.token_count += assistant_message_data["total_tokens"]
            session_obj.last_activity = datetime.utcnow()
        
        await db.commit()
        
        # Generate analytics
        analytics_data = await analytics_service.track_message_interaction(
            user_message, assistant_message, db=db
        )
        
        # Response with comprehensive data
        response_data = {
            "session_id": session_id,
            "message_id": user_message.id,
            "response": {
                "content": response.content,
                "message_id": assistant_message.id,
                "attachments_processed": response.attachments_processed,
                "escalation_triggered": response.escalation_triggered,
                "sources": response.sources,
                "confidence_score": response.confidence_score,
                "processing_time": response.processing_time,
                "model_name": response.model_name,
                "provider": response.provider,
                "token_usage": {
                    "prompt_tokens": response.prompt_tokens,
                    "completion_tokens": response.completion_tokens,
                    "total_tokens": response.total_tokens,
                    "cost_usd": response.cost_usd
                },
                "security_info": {
                    "pii_detected": pii_detected,
                    "security_level": security_level,
                    "content_sanitized": sanitized_message != message
                },
                "analytics": analytics_data
            }
        }
        
        return JSONResponse(content=response_data)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error")

# ============================================================================
# MESSAGE BATCH OPERATIONS AND BULK PROCESSING
# ============================================================================

@router.post("/messages/batch")
async def batch_process_messages(
    messages: List[Dict[str, Any]],
    session_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Process multiple messages in batch with optimized operations.
    
    Args:
        messages: List of message objects to process
        session_id: Optional session ID for all messages
        
    Returns:
        Batch processing results
    """
    try:
        results = []
        errors = []
        
        # Create session if needed
        current_session_id = session_id or str(uuid.uuid4())
        if not session_id:
            session_obj = SessionORM(
                id=current_session_id,
                user_id="anonymous",
                title=f"Batch Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                status="active"
            )
            db.add(session_obj)
        
        for i, msg_data in enumerate(messages):
            try:
                # Validate and sanitize message
                sanitized_content = await security_service.sanitize_content(
                    msg_data.get("content", "")
                )
                
                # Create message
                message = MessageORM(
                    session_id=current_session_id,
                    role=msg_data.get("role", "user"),
                    content=sanitized_content,
                    sequence_number=await message_service.get_next_sequence_number(current_session_id, db),
                    parent_message_id=msg_data.get("parent_message_id"),
                    metadata=msg_data.get("metadata", {})
                )
                db.add(message)
                
                results.append({
                    "index": i,
                    "message_id": message.id,
                    "status": "success",
                    "content": sanitized_content
                })
                
            except Exception as e:
                errors.append({
                    "index": i,
                    "error": str(e),
                    "status": "failed"
                })
        
        await db.commit()
        
        return JSONResponse(content={
            "session_id": current_session_id,
            "processed_count": len(results),
            "error_count": len(errors),
            "results": results,
            "errors": errors
        })
        
    except Exception as e:
        logger.error(f"Batch processing error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Batch processing failed")

@router.post("/messages/bulk-import")
async def bulk_import_messages(
    file: UploadFile = File(...),
    session_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Bulk import messages from CSV/JSON file.
    
    Args:
        file: CSV or JSON file with messages
        session_id: Target session ID
        
    Returns:
        Import results
    """
    try:
        current_session_id = session_id or str(uuid.uuid4())
        
        # Create session if needed
        if not session_id:
            session_obj = SessionORM(
                id=current_session_id,
                user_id="anonymous",
                title=f"Import Session {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                status="active"
            )
            db.add(session_obj)
        
        # Process file based on type
        if file.filename.endswith('.csv'):
            content = await file.read()
            import_result = await utilities_service.import_csv_messages(
                content.decode('utf-8'), current_session_id, db
            )
        elif file.filename.endswith('.json'):
            content = await file.read()
            import_result = await utilities_service.import_json_messages(
                json.loads(content.decode('utf-8')), current_session_id, db
            )
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format")
        
        await db.commit()
        
        return JSONResponse(content={
            "session_id": current_session_id,
            "import_summary": import_result
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk import error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Import failed")

# ============================================================================
# MESSAGE SEARCH AND FILTERING CAPABILITIES
# ============================================================================

@router.get("/messages/search")
async def search_messages(
    query: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    role: Optional[str] = None,
    content_type: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    has_attachments: Optional[bool] = None,
    has_pii: Optional[bool] = None,
    security_level: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db)
):
    """
    Advanced message search with comprehensive filtering.
    
    Args:
        query: Text search query
        session_id: Filter by session
        user_id: Filter by user
        role: Filter by message role (user/assistant/system)
        content_type: Filter by content type
        date_from: Start date filter
        date_to: End date filter
        has_attachments: Filter by attachment presence
        has_pii: Filter by PII detection
        security_level: Filter by security level
        limit: Results limit
        offset: Results offset
        
    Returns:
        Paginated search results with metadata
    """
    try:
        search_params = {
            "query": query,
            "session_id": session_id,
            "user_id": user_id,
            "role": role,
            "content_type": content_type,
            "date_from": date_from,
            "date_to": date_to,
            "has_attachments": has_attachments,
            "has_pii": has_pii,
            "security_level": security_level,
            "limit": limit,
            "offset": offset
        }
        
        results = await message_service.search_messages(search_params, db)
        
        return JSONResponse(content={
            "results": [msg.dict() for msg in results["messages"]],
            "total_count": results["total_count"],
            "page_info": {
                "limit": limit,
                "offset": offset,
                "has_more": results["total_count"] > offset + len(results["messages"])
            },
            "search_params": search_params
        })
        
    except Exception as e:
        logger.error(f"Message search error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Search failed")

@router.get("/messages/filter")
async def filter_messages(
    filters: Dict[str, Any],
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db)
):
    """
    Advanced message filtering using complex query parameters.
    
    Args:
        filters: Dictionary of filter parameters
        limit: Results limit
        offset: Results offset
        
    Returns:
        Filtered message results
    """
    try:
        results = await message_service.advanced_filter_messages(filters, limit, offset, db)
        
        return JSONResponse(content={
            "messages": [msg.dict() for msg in results["messages"]],
            "total_count": results["total_count"],
            "facets": results.get("facets", {}),
            "page_info": {
                "limit": limit,
                "offset": offset,
                "has_more": results["total_count"] > offset + len(results["messages"])
            }
        })
        
    except Exception as e:
        logger.error(f"Message filtering error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Filtering failed")

# ============================================================================
# MESSAGE HISTORY AND PAGINATION
# ============================================================================

@router.get("/sessions/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    limit: int = 50,
    offset: int = 0,
    include_metadata: bool = True,
    sort_order: str = "desc",  # "asc" or "desc"
    db: AsyncSession = Depends(get_db)
):
    """
    Get paginated message history for a session.
    
    Args:
        session_id: Session ID
        limit: Number of messages to return
        offset: Number of messages to skip
        include_metadata: Whether to include message metadata
        sort_order: Sort order (asc/desc)
        
    Returns:
        Paginated message history
    """
    try:
        messages = await message_service.get_session_messages_paginated(
            session_id=session_id,
            limit=limit,
            offset=offset,
            include_metadata=include_metadata,
            sort_order=sort_order,
            db=db
        )
        
        # Get session info
        result = await db.execute(
            select(SessionORM).where(SessionORM.id == session_id)
        )
        session_obj = result.scalar_one_or_none()
        
        if not session_obj:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return JSONResponse(content={
            "session": session_obj.to_summary_dict(),
            "messages": [msg.dict(include_metadata=include_metadata) for msg in messages["messages"]],
            "pagination": {
                "limit": limit,
                "offset": offset,
                "total_count": messages["total_count"],
                "has_more": messages["total_count"] > offset + len(messages["messages"]),
                "sort_order": sort_order
            }
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get session messages error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get messages")

@router.get("/users/{user_id}/message-history")
async def get_user_message_history(
    user_id: str,
    limit: int = 50,
    offset: int = 0,
    session_filter: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Get comprehensive message history for a user.
    
    Args:
        user_id: User ID
        limit: Number of messages to return
        offset: Number of messages to skip
        session_filter: Optional session ID filter
        date_from: Start date filter
        date_to: End date filter
        
    Returns:
        Paginated user message history
    """
    try:
        history = await message_service.get_user_message_history(
            user_id=user_id,
            limit=limit,
            offset=offset,
            session_filter=session_filter,
            date_from=date_from,
            date_to=date_to,
            db=db
        )
        
        return JSONResponse(content={
            "user_id": user_id,
            "messages": [msg.dict() for msg in history["messages"]],
            "sessions": history["sessions"],
            "pagination": {
                "limit": limit,
                "offset": offset,
                "total_count": history["total_count"],
                "has_more": history["total_count"] > offset + len(history["messages"])
            }
        })
        
    except Exception as e:
        logger.error(f"Get user message history error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get user history")

# ============================================================================
# MESSAGE ANALYTICS
# ============================================================================

@router.get("/analytics/messages")
async def get_message_analytics(
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    granularities: Optional[List[str]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Get comprehensive message analytics and metrics.
    
    Args:
        session_id: Optional session filter
        user_id: Optional user filter
        date_from: Start date for analysis
        date_to: End date for analysis
        granularities: List of time granularities (hour, day, week, month)
        
    Returns:
        Comprehensive analytics data
    """
    try:
        analytics_params = {
            "session_id": session_id,
            "user_id": user_id,
            "date_from": date_from,
            "date_to": date_to,
            "granularities": granularities or ["day"]
        }
        
        analytics = await analytics_service.get_comprehensive_analytics(analytics_params, db)
        
        return JSONResponse(content=analytics)
        
    except Exception as e:
        logger.error(f"Message analytics error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Analytics computation failed")

@router.get("/analytics/response-times")
async def get_response_time_analytics(
    session_id: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Get response time analytics for message processing.
    
    Args:
        session_id: Optional session filter
        date_from: Start date for analysis
        date_to: End date for analysis
        
    Returns:
        Response time analytics data
    """
    try:
        analytics = await analytics_service.get_response_time_analytics(
            session_id=session_id,
            date_from=date_from,
            date_to=date_to,
            db=db
        )
        
        return JSONResponse(content=analytics)
        
    except Exception as e:
        logger.error(f"Response time analytics error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Response time analytics failed")

@router.get("/analytics/user-interactions")
async def get_user_interaction_analytics(
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Get user interaction analytics and patterns.
    
    Args:
        user_id: Optional user filter
        session_id: Optional session filter
        date_from: Start date for analysis
        date_to: End date for analysis
        
    Returns:
        User interaction analytics data
    """
    try:
        analytics = await analytics_service.get_user_interaction_analytics(
            user_id=user_id,
            session_id=session_id,
            date_from=date_from,
            date_to=date_to,
            db=db
        )
        
        return JSONResponse(content=analytics)
        
    except Exception as e:
        logger.error(f"User interaction analytics error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="User interaction analytics failed")

@router.get("/analytics/effectiveness")
async def get_message_effectiveness_analytics(
    session_id: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Get message effectiveness tracking and analysis.
    
    Args:
        session_id: Optional session filter
        date_from: Start date for analysis
        date_to: End date for analysis
        
    Returns:
        Message effectiveness analytics
    """
    try:
        analytics = await analytics_service.get_effectiveness_analytics(
            session_id=session_id,
            date_from=date_from,
            date_to=date_to,
            db=db
        )
        
        return JSONResponse(content=analytics)
        
    except Exception as e:
        logger.error(f"Message effectiveness analytics error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Effectiveness analytics failed")

# ============================================================================
# MESSAGE MANAGEMENT
# ============================================================================

@router.put("/messages/{message_id}")
async def update_message(
    message_id: str,
    update_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Update an existing message with audit trail.
    
    Args:
        message_id: Message ID to update
        update_data: Data to update
        
    Returns:
        Updated message data
    """
    try:
        # Security check for message updates
        message = await message_service.get_message_by_id(message_id, db)
        if not message:
            raise HTTPException(status_code=404, detail="Message not found")
        
        # Create audit trail
        audit_data = {
            "original_content": message.content,
            "updated_by": "anonymous",  # Would be from auth
            "update_reason": update_data.get("update_reason", "Manual edit")
        }
        
        # Sanitize updated content if provided
        if "content" in update_data:
            update_data["content"] = await security_service.sanitize_content(
                update_data["content"]
            )
        
        # Update message
        updated_message = await message_service.update_message(message_id, update_data, db)
        
        # Store audit trail
        await message_service.create_audit_trail(message_id, audit_data, db)
        
        await db.commit()
        
        return JSONResponse(content={
            "message": updated_message.dict(),
            "audit_trail": audit_data
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update message error: {str(e)}", exc_info=True)
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to update message")

@router.delete("/messages/{message_id}")
async def delete_message(
    message_id: str,
    force: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """
    Delete a message with safety checks.
    
    Args:
        message_id: Message ID to delete
        force: Force deletion even if it breaks conversation flow
        
    Returns:
        Deletion confirmation
    """
    try:
        message = await message_service.get_message_by_id(message_id, db)
        if not message:
            raise HTTPException(status_code=404, detail="Message not found")
        
        # Check if deletion would break conversation flow
        if not force:
            has_replies = await message_service.check_message_replies(message_id, db)
            if has_replies:
                raise HTTPException(
                    status_code=400, 
                    detail="Cannot delete message with replies. Use force=true to override."
                )
        
        # Create deletion audit trail
        audit_data = {
            "deleted_message": message.dict(),
            "deleted_by": "anonymous",  # Would be from auth
            "deletion_reason": "Manual deletion"
        }
        
        # Soft delete or hard delete based on policy
        if force:
            await message_service.hard_delete_message(message_id, db)
        else:
            await message_service.soft_delete_message(message_id, db)
        
        # Store audit trail
        await message_service.create_deletion_audit_trail(message_id, audit_data, db)
        
        await db.commit()
        
        return JSONResponse(content={
            "message": "Message deleted successfully",
            "audit_trail": audit_data
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete message error: {str(e)}", exc_info=True)
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to delete message")

@router.post("/messages/{message_id}/thread")
async def create_message_thread(
    message_id: str,
    thread_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Create or manage message threading for conversations.
    
    Args:
        message_id: Base message ID
        thread_data: Thread configuration data
        
    Returns:
        Thread creation result
    """
    try:
        thread = await message_service.create_message_thread(
            message_id=message_id,
            thread_data=thread_data,
            db=db
        )
        
        await db.commit()
        
        return JSONResponse(content={
            "thread": thread,
            "message": "Thread created successfully"
        })
        
    except Exception as e:
        logger.error(f"Create message thread error: {str(e)}", exc_info=True)
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to create thread")

@router.get("/messages/{message_id}/thread")
async def get_message_thread(
    message_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get the full thread for a message.
    
    Args:
        message_id: Message ID
        
    Returns:
        Complete thread with all related messages
    """
    try:
        thread = await message_service.get_message_thread(message_id, db)
        
        return JSONResponse(content=thread)
        
    except Exception as e:
        logger.error(f"Get message thread error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get thread")

@router.post("/messages/{message_id}/reactions")
async def add_message_reaction(
    message_id: str,
    reaction_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Add reaction/feedback to a message.
    
    Args:
        message_id: Message ID
        reaction_data: Reaction data (emoji, feedback type, etc.)
        
    Returns:
        Reaction addition result
    """
    try:
        reaction = await message_service.add_message_reaction(
            message_id=message_id,
            reaction_data=reaction_data,
            db=db
        )
        
        await db.commit()
        
        return JSONResponse(content={
            "reaction": reaction,
            "message": "Reaction added successfully"
        })
        
    except Exception as e:
        logger.error(f"Add message reaction error: {str(e)}", exc_info=True)
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to add reaction")

@router.get("/messages/{message_id}/reactions")
async def get_message_reactions(
    message_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get all reactions for a message.
    
    Args:
        message_id: Message ID
        
    Returns:
        List of reactions for the message
    """
    try:
        reactions = await message_service.get_message_reactions(message_id, db)
        
        return JSONResponse(content={
            "message_id": message_id,
            "reactions": reactions,
            "reaction_summary": await message_service.get_reaction_summary(message_id, db)
        })
        
    except Exception as e:
        logger.error(f"Get message reactions error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get reactions")

@router.post("/messages/export")
async def export_messages(
    export_config: Dict[str, Any],
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Export messages with various formats and options.
    
    Args:
        export_config: Export configuration
        background_tasks: Background task handler
        
    Returns:
        Export job information
    """
    try:
        export_job = await utilities_service.create_export_job(export_config, db)
        
        # Start background export
        background_tasks.add_task(
            utilities_service.process_export_job,
            export_job["job_id"],
            export_config,
            db
        )
        
        return JSONResponse(content={
            "export_job_id": export_job["job_id"],
            "status": "processing",
            "estimated_completion": export_job["estimated_completion"],
            "message": "Export job started"
        })
        
    except Exception as e:
        logger.error(f"Export messages error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Export failed")

@router.get("/exports/{export_job_id}/status")
async def get_export_status(
    export_job_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get export job status.
    
    Args:
        export_job_id: Export job ID
        
    Returns:
        Export status information
    """
    try:
        status = await utilities_service.get_export_status(export_job_id, db)
        
        return JSONResponse(content=status)
        
    except Exception as e:
        logger.error(f"Get export status error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get export status")

@router.get("/exports/{export_job_id}/download")
async def download_export(
    export_job_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Download completed export file.
    
    Args:
        export_job_id: Export job ID
        
    Returns:
        Export file for download
    """
    try:
        file_path, filename = await utilities_service.get_export_file(export_job_id, db)
        
        if not file_path:
            raise HTTPException(status_code=404, detail="Export file not found")
        
        return FileResponse(
            path=file_path,
            filename=filename,
            media_type="application/octet-stream"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Download export error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to download export")

# ============================================================================
# MESSAGE SECURITY
# ============================================================================

@router.post("/messages/validate")
async def validate_message_content(
    message_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Validate and analyze message content for security issues.
    
    Args:
        message_data: Message data to validate
        
    Returns:
        Validation results with security analysis
    """
    try:
        validation_result = await security_service.comprehensive_content_validation(
            message_data.get("content", ""),
            metadata=message_data.get("metadata", {})
        )
        
        return JSONResponse(content=validation_result)
        
    except Exception as e:
        logger.error(f"Message validation error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Validation failed")

@router.post("/messages/sanitize")
async def sanitize_message_content(
    message_data: Dict[str, Any],
    custom_rules: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Sanitize message content with customizable rules.
    
    Args:
        message_data: Message data to sanitize
        custom_rules: Optional custom sanitization rules
        
    Returns:
        Sanitized content with analysis
    """
    try:
        sanitization_result = await security_service.sanitize_with_custom_rules(
            content=message_data.get("content", ""),
            custom_rules=custom_rules or {},
            preserve_formatting=message_data.get("preserve_formatting", False)
        )
        
        return JSONResponse(content=sanitization_result)
        
    except Exception as e:
        logger.error(f"Message sanitization error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Sanitization failed")

@router.post("/messages/detect-pii")
async def detect_pii_in_content(
    message_data: Dict[str, Any],
    detection_config: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Detect personally identifiable information in message content.
    
    Args:
        message_data: Message data to analyze
        detection_config: Optional PII detection configuration
        
    Returns:
        PII detection results
    """
    try:
        pii_result = await security_service.detect_pii_with_config(
            content=message_data.get("content", ""),
            detection_config=detection_config or {},
            return_masked=message_data.get("return_masked", True)
        )
        
        return JSONResponse(content=pii_result)
        
    except Exception as e:
        logger.error(f"PII detection error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="PII detection failed")

@router.post("/messages/encrypt")
async def encrypt_message_content(
    message_data: Dict[str, Any],
    encryption_config: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Encrypt sensitive message content.
    
    Args:
        message_data: Message data to encrypt
        encryption_config: Optional encryption configuration
        
    Returns:
        Encrypted content with metadata
    """
    try:
        encryption_result = await security_service.encrypt_content(
            content=message_data.get("content", ""),
            encryption_config=encryption_config or {},
            user_id=message_data.get("user_id", "anonymous")
        )
        
        return JSONResponse(content=encryption_result)
        
    except Exception as e:
        logger.error(f"Message encryption error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Encryption failed")

@router.post("/messages/decrypt")
async def decrypt_message_content(
    encryption_data: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Decrypt encrypted message content.
    
    Args:
        encryption_data: Encrypted content data
        
    Returns:
        Decrypted content
    """
    try:
        decryption_result = await security_service.decrypt_content(
            encrypted_data=encryption_data,
            user_id=encryption_data.get("user_id", "anonymous")
        )
        
        return JSONResponse(content=decryption_result)
        
    except Exception as e:
        logger.error(f"Message decryption error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Decryption failed")

@router.post("/messages/moderate")
async def moderate_message_content(
    message_data: Dict[str, Any],
    moderation_config: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Moderate message content for policy compliance.
    
    Args:
        message_data: Message data to moderate
        moderation_config: Optional moderation configuration
        
    Returns:
        Moderation results and recommendations
    """
    try:
        moderation_result = await security_service.moderate_content(
            content=message_data.get("content", ""),
            moderation_config=moderation_config or {},
            user_id=message_data.get("user_id", "anonymous")
        )
        
        return JSONResponse(content=moderation_result)
        
    except Exception as e:
        logger.error(f"Content moderation error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Moderation failed")

# ============================================================================
# MESSAGE UTILITIES
# ============================================================================

@router.post("/messages/preprocess")
async def preprocess_messages(
    preprocess_config: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Preprocess and clean messages using various techniques.
    
    Args:
        preprocess_config: Preprocessing configuration
        
    Returns:
        Preprocessing results
    """
    try:
        result = await utilities_service.preprocess_messages(
            preprocess_config=preprocess_config,
            db=db
        )
        
        return JSONResponse(content=result)
        
    except Exception as e:
        logger.error(f"Message preprocessing error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Preprocessing failed")

@router.post("/messages/validate-structure")
async def validate_message_structure(
    message_data: Dict[str, Any],
    schema_config: Optional[Dict[str, Any]] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Validate message structure against schema.
    
    Args:
        message_data: Message data to validate
        schema_config: Optional schema configuration
        
    Returns:
        Structure validation results
    """
    try:
        validation_result = await utilities_service.validate_message_structure(
            message_data=message_data,
            schema_config=schema_config or {},
            db=db
        )
        
        return JSONResponse(content=validation_result)
        
    except Exception as e:
        logger.error(f"Message structure validation error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Structure validation failed")

@router.post("/messages/backup")
async def backup_messages(
    backup_config: Dict[str, Any],
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Create backup of messages with various options.
    
    Args:
        backup_config: Backup configuration
        background_tasks: Background task handler
        
    Returns:
        Backup job information
    """
    try:
        backup_job = await utilities_service.create_backup_job(backup_config, db)
        
        # Start background backup
        background_tasks.add_task(
            utilities_service.process_backup_job,
            backup_job["job_id"],
            backup_config,
            db
        )
        
        return JSONResponse(content={
            "backup_job_id": backup_job["job_id"],
            "status": "processing",
            "estimated_completion": backup_job["estimated_completion"],
            "message": "Backup job started"
        })
        
    except Exception as e:
        logger.error(f"Backup messages error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Backup failed")

@router.get("/backups/{backup_job_id}/status")
async def get_backup_status(
    backup_job_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get backup job status.
    
    Args:
        backup_job_id: Backup job ID
        
    Returns:
        Backup status information
    """
    try:
        status = await utilities_service.get_backup_status(backup_job_id, db)
        
        return JSONResponse(content=status)
        
    except Exception as e:
        logger.error(f"Get backup status error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get backup status")

@router.post("/messages/archive")
async def archive_messages(
    archive_config: Dict[str, Any],
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Archive old messages according to retention policies.
    
    Args:
        archive_config: Archive configuration
        background_tasks: Background task handler
        
    Returns:
        Archive job information
    """
    try:
        archive_job = await utilities_service.create_archive_job(archive_config, db)
        
        # Start background archive
        background_tasks.add_task(
            utilities_service.process_archive_job,
            archive_job["job_id"],
            archive_config,
            db
        )
        
        return JSONResponse(content={
            "archive_job_id": archive_job["job_id"],
            "status": "processing",
            "estimated_completion": archive_job["estimated_completion"],
            "message": "Archive job started"
        })
        
    except Exception as e:
        logger.error(f"Archive messages error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Archive failed")

@router.get("/analytics/insights")
async def get_message_insights(
    insight_config: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """
    Generate comprehensive message insights and patterns.
    
    Args:
        insight_config: Insight generation configuration
        
    Returns:
        Comprehensive insights and patterns
    """
    try:
        insights = await analytics_service.generate_comprehensive_insights(
            insight_config=insight_config,
            db=db
        )
        
        return JSONResponse(content=insights)
        
    except Exception as e:
        logger.error(f"Generate insights error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Insights generation failed")

@router.get("/health/chat-system")
async def chat_system_health_check(db: AsyncSession = Depends(get_db)):
    """
    Comprehensive health check for the chat system.
    
    Returns:
        System health status
    """
    try:
        health_status = {
            "timestamp": datetime.utcnow().isoformat(),
            "services": {
                "database": await check_database_health(db),
                "message_service": await check_message_service_health(),
                "security_service": await check_security_service_health(),
                "analytics_service": await check_analytics_service_health(),
                "utilities_service": await check_utilities_service_health()
            },
            "overall_status": "healthy"
        }
        
        # Determine overall status
        if not all(service["status"] == "healthy" for service in health_status["services"].values()):
            health_status["overall_status"] = "degraded"
        
        return JSONResponse(content=health_status)
        
    except Exception as e:
        logger.error(f"Health check error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Health check failed")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

async def check_database_health(db: AsyncSession) -> Dict[str, Any]:
    """Check database connectivity and performance."""
    try:
        start_time = datetime.utcnow()
        await db.execute(text("SELECT 1"))
        response_time = (datetime.utcnow() - start_time).total_seconds()
        
        return {
            "status": "healthy",
            "response_time_ms": response_time * 1000,
            "message": "Database connection successful"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "message": "Database connection failed"
        }

async def check_message_service_health() -> Dict[str, Any]:
    """Check message service health."""
    try:
        # Simple health check for message service
        return {
            "status": "healthy",
            "message": "Message service is operational"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "message": "Message service is not operational"
        }

async def check_security_service_health() -> Dict[str, Any]:
    """Check security service health."""
    try:
        # Simple health check for security service
        return {
            "status": "healthy",
            "message": "Security service is operational"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "message": "Security service is not operational"
        }

async def check_analytics_service_health() -> Dict[str, Any]:
    """Check analytics service health."""
    try:
        # Simple health check for analytics service
        return {
            "status": "healthy",
            "message": "Analytics service is operational"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "message": "Analytics service is not operational"
        }

async def check_utilities_service_health() -> Dict[str, Any]:
    """Check utilities service health."""
    try:
        # Simple health check for utilities service
        return {
            "status": "healthy",
            "message": "Utilities service is operational"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "message": "Utilities service is not operational"
        }