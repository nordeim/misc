"""
API routes package.

This package contains all API route handlers for the application.
"""

from fastapi import APIRouter

# Import routers
from . import health
from . import chat
from . import agents
from . import files
from . import sessions

# Create main API router
api_router = APIRouter()

# Include route routers
api_router.include_router(health.router, prefix="/health", tags=["health"])
api_router.include_router(chat.router, prefix="/chat", tags=["chat"])
api_router.include_router(agents.router, prefix="/agents", tags=["agent-system"])
api_router.include_router(files.router, prefix="/files", tags=["file-management"])
api_router.include_router(sessions.router, prefix="/sessions", tags=["sessions"])

__all__ = ["api_router"]