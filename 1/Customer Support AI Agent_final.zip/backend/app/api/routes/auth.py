"""
Authentication API endpoints.

This module provides comprehensive authentication functionality including:
- User login and registration
- JWT token generation and validation
- Token refresh and logout
- Password reset and email verification
- Account management and security
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from fastapi import (
    APIRouter, 
    HTTPException, 
    status, 
    Depends,
    BackgroundTasks
)
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr, validator
import logging

from app.config import settings
from app.security.auth import (
    authenticate_user, 
    create_user,
    get_current_user,
    get_current_active_user,
    user_db,
    User
)
from app.security.token_utils import (
    create_token_pair,
    refresh_access_token,
    revoke_token,
    create_password_reset_token,
    verify_password_reset_token,
    create_email_verification_token,
    verify_email_verification_token,
    token_blacklist
)
from app.security.password_utils import (
    validate_password_strength,
    get_password_strength,
    generate_secure_password
)
from app.middleware.security import SecurityAuditLogger, get_security_context
from app.security.permissions import UserPermissions, Role

# Enhanced validation imports
from app.validation import (
    validate_user_registration,
    validate_user_login,
    ValidateRequest,
    ValidationMode,
    ValidationRule,
    ValidationType
)
from app.validation.schema_validator import USER_REGISTRATION_SCHEMA, USER_LOGIN_SCHEMA

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/auth", tags=["authentication"])

# Security scheme
security = HTTPBearer()

# Pydantic models for request/response

class LoginRequest(BaseModel):
    """User login request model."""
    username: str
    password: str
    
    @validator('username')
    def username_not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('Username cannot be empty')
        return v.strip()
    
    @validator('password')
    def password_not_empty(cls, v):
        if not v:
            raise ValueError('Password cannot be empty')
        return v


class RegisterRequest(BaseModel):
    """User registration request model."""
    username: str
    email: EmailStr
    password: str
    confirm_password: str
    
    @validator('username')
    def username_validation(cls, v):
        if not v or not v.strip():
            raise ValueError('Username cannot be empty')
        if len(v.strip()) < 3:
            raise ValueError('Username must be at least 3 characters long')
        if len(v.strip()) > 50:
            raise ValueError('Username cannot exceed 50 characters')
        return v.strip()
    
    @validator('password')
    def password_validation(cls, v):
        if not v:
            raise ValueError('Password cannot be empty')
        return v
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match')
        return v


class TokenRefreshRequest(BaseModel):
    """Token refresh request model."""
    refresh_token: str


class PasswordResetRequest(BaseModel):
    """Password reset request model."""
    email: EmailStr


class PasswordResetConfirmRequest(BaseModel):
    """Password reset confirmation request model."""
    token: str
    new_password: str
    confirm_password: str
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


class ChangePasswordRequest(BaseModel):
    """Change password request model."""
    current_password: str
    new_password: str
    confirm_password: str
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


class UserResponse(BaseModel):
    """User information response model."""
    id: str
    username: str
    email: str
    role: str
    is_active: bool
    is_verified: bool
    last_login: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    
    @classmethod
    def from_user(cls, user: User) -> "UserResponse":
        """Create UserResponse from User object."""
        return cls(
            id=user.id,
            username=user.username,
            email=user.email,
            role=str(user.role),
            is_active=user.is_active,
            is_verified=user.is_verified,
            last_login=user.last_login,
            created_at=user.created_at,
            updated_at=user.updated_at
        )


class TokenResponse(BaseModel):
    """Token response model."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse


class SimpleTokenResponse(BaseModel):
    """Simple token response model."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshTokenResponse(BaseModel):
    """Refresh token response model."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class MessageResponse(BaseModel):
    """Simple message response model."""
    message: str


class PasswordValidationResponse(BaseModel):
    """Password validation response model."""
    is_valid: bool
    strength: str
    score: int
    errors: List[str]
    suggestions: List[str]


# Endpoints

@router.post("/login", response_model=TokenResponse, status_code=status.HTTP_200_OK)
@validate_user_login(LoginRequest)
async def login(
    login_data: LoginRequest,
    request: Request,
    background_tasks: BackgroundTasks
) -> TokenResponse:
    """
    Authenticate user and return JWT tokens.
    
    This endpoint:
    1. Validates user credentials
    2. Generates access and refresh tokens
    3. Updates user last login time
    4. Logs authentication attempt
    """
    try:
        # Get client information
        context = get_security_context(request)
        client_ip = context["client_ip"]
        user_agent = context["user_agent"]
        
        # Authenticate user
        user = await authenticate_user(login_data.username, login_data.password)
        
        if not user:
            # Log failed authentication
            SecurityAuditLogger.log_auth_attempt(
                user_id=None,
                ip_address=client_ip or "unknown",
                user_agent=user_agent or "",
                success=False,
                reason="Invalid credentials"
            )
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password"
            )
        
        # Check if user is active
        if not user.is_active:
            SecurityAuditLogger.log_auth_attempt(
                user_id=user.id,
                ip_address=client_ip or "unknown",
                user_agent=user_agent or "",
                success=False,
                reason="Account inactive"
            )
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Account is inactive"
            )
        
        # Check if user is locked
        if user.is_locked:
            SecurityAuditLogger.log_auth_attempt(
                user_id=user.id,
                ip_address=client_ip or "unknown",
                user_agent=user_agent or "",
                success=False,
                reason="Account locked"
            )
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Account is temporarily locked due to too many failed attempts"
            )
        
        # Create token pair
        user_data = {
            "sub": user.id,
            "username": user.username,
            "permissions": user.permissions.permissions_list
        }
        
        tokens = create_token_pair(user_data)
        
        # Log successful authentication
        SecurityAuditLogger.log_auth_attempt(
            user_id=user.id,
            ip_address=client_ip or "unknown",
            user_agent=user_agent or "",
            success=True,
            reason="Login successful"
        )
        
        # Create response
        return TokenResponse(
            access_token=tokens["access_token"],
            refresh_token=tokens["refresh_token"],
            expires_in=tokens["expires_in"],
            user=UserResponse.from_user(user)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Login failed due to server error"
        )


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
@validate_user_registration(RegisterRequest)
async def register(
    register_data: RegisterRequest,
    request: Request,
    background_tasks: BackgroundTasks
) -> UserResponse:
    """
    Register a new user account.
    
    This endpoint:
    1. Validates password strength
    2. Checks for existing username/email
    3. Creates new user account
    4. Sends verification email (in production)
    """
    try:
        # Validate password strength
        is_valid, errors = validate_password_strength(
            register_data.password,
            register_data.username,
            register_data.email
        )
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "Password does not meet requirements",
                    "errors": errors
                }
            )
        
        # Create user
        user = create_user(
            username=register_data.username,
            email=register_data.email,
            password=register_data.password,
            role="user"
        )
        
        # Log registration
        context = get_security_context(request)
        logger.info(
            f"New user registered: {user.username}",
            user_id=user.id,
            email=user.email,
            ip_address=context["client_ip"]
        )
        
        # In production, send verification email here
        # background_tasks.add_task(send_verification_email, user)
        
        return UserResponse.from_user(user)
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Registration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Registration failed due to server error"
        )


@router.post("/refresh", response_model=RefreshTokenResponse)
async def refresh_token(
    refresh_data: TokenRefreshRequest,
    request: Request
) -> RefreshTokenResponse:
    """
    Refresh access token using refresh token.
    
    This endpoint:
    1. Validates the refresh token
    2. Generates new access token
    3. Revokes old refresh token for security
    """
    try:
        # Verify refresh token
        current_user = get_current_user(
            HTTPAuthorizationCredentials(
                scheme="Bearer",
                credentials=refresh_data.refresh_token
            )
        )
        
        if not current_user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )
        
        # Create new access token
        new_access_token = await refresh_access_token(
            refresh_data.refresh_token,
            current_user
        )
        
        return RefreshTokenResponse(
            access_token=new_access_token,
            expires_in=int(settings.jwt_expire_delta.total_seconds())
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Token refresh error: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token refresh failed"
        )


@router.post("/logout", response_model=MessageResponse)
async def logout(
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user)
) -> MessageResponse:
    """
    Logout user and revoke tokens.
    
    This endpoint:
    1. Revokes the current access token
    2. Optionally revokes the refresh token
    3. Logs the logout event
    """
    try:
        # Get authorization header
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
            revoke_token(token, reason="logout")
        
        # Log logout
        context = get_security_context(request)
        logger.info(
            f"User logged out: {current_user.username}",
            user_id=current_user.id,
            ip_address=context["client_ip"]
        )
        
        return MessageResponse(message="Successfully logged out")
        
    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Logout failed"
        )


@router.post("/logout-all", response_model=MessageResponse)
async def logout_all(
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user)
) -> MessageResponse:
    """
    Logout user from all devices/sessions.
    
    This endpoint revokes all tokens for the current user.
    """
    try:
        # Revoke all user tokens
        token_blacklist.revoke_all_user_tokens(current_user.id)
        
        # Log logout all
        context = get_security_context(request)
        logger.info(
            f"User logged out from all devices: {current_user.username}",
            user_id=current_user.id,
            ip_address=context["client_ip"]
        )
        
        return MessageResponse(message="Successfully logged out from all devices")
        
    except Exception as e:
        logger.error(f"Logout all error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Logout from all devices failed"
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
) -> UserResponse:
    """
    Get current user information.
    
    This endpoint returns the current authenticated user's details.
    """
    return UserResponse.from_user(current_user)


@router.post("/change-password", response_model=MessageResponse)
async def change_password(
    password_data: ChangePasswordRequest,
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user)
) -> MessageResponse:
    """
    Change user password.
    
    This endpoint:
    1. Verifies current password
    2. Validates new password strength
    3. Updates user password
    4. Optionally sends security notification
    """
    try:
        # Verify current password
        if not current_user.check_password(password_data.current_password):
            SecurityAuditLogger.log_security_violation(
                violation_type="password_change_failed",
                ip_address=get_security_context(request)["client_ip"] or "unknown",
                user_agent=get_security_context(request)["user_agent"] or "",
                details=f"Invalid current password for user {current_user.username}"
            )
            
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Current password is incorrect"
            )
        
        # Validate new password strength
        is_valid, errors = validate_password_strength(
            password_data.new_password,
            current_user.username,
            current_user.email
        )
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "New password does not meet requirements",
                    "errors": errors
                }
            )
        
        # Update password
        from app.security.password_utils import get_password_hash
        current_user.hashed_password = get_password_hash(password_data.new_password)
        current_user.updated_at = datetime.utcnow()
        user_db.update_user(current_user)
        
        # Log password change
        logger.info(
            f"Password changed for user: {current_user.username}",
            user_id=current_user.id,
            ip_address=get_security_context(request)["client_ip"]
        )
        
        # Send security notification email (in production)
        # background_tasks.add_task(send_password_change_notification, current_user)
        
        return MessageResponse(message="Password changed successfully")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Password change error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Password change failed"
        )


@router.post("/reset-password", response_model=MessageResponse)
async def request_password_reset(
    reset_data: PasswordResetRequest,
    request: Request,
    background_tasks: BackgroundTasks
) -> MessageResponse:
    """
    Request password reset token.
    
    This endpoint:
    1. Validates email exists
    2. Generates password reset token
    3. Sends reset email
    """
    try:
        # Check if user exists
        user = user_db.get_user_by_email(reset_data.email)
        
        # Always return success for security (don't reveal if email exists)
        if not user:
            return MessageResponse(
                message="If the email exists, a password reset link has been sent"
            )
        
        # Generate reset token
        reset_token = create_password_reset_token(user.id, user.email)
        
        # Log password reset request
        logger.info(
            f"Password reset requested for: {user.username}",
            user_id=user.id,
            email=user.email,
            ip_address=get_security_context(request)["client_ip"]
        )
        
        # Send reset email (in production)
        # background_tasks.add_task(send_password_reset_email, user, reset_token)
        
        # For development, return the token (remove in production!)
        if settings.is_development:
            logger.warning(f"Development password reset token: {reset_token}")
        
        return MessageResponse(
            message="If the email exists, a password reset link has been sent"
        )
        
    except Exception as e:
        logger.error(f"Password reset request error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Password reset request failed"
        )


@router.post("/reset-password/confirm", response_model=MessageResponse)
async def confirm_password_reset(
    reset_data: PasswordResetConfirmRequest,
    request: Request
) -> MessageResponse:
    """
    Confirm password reset with token.
    
    This endpoint:
    1. Validates reset token
    2. Updates user password
    3. Invalidates old tokens
    """
    try:
        # Verify reset token
        token_data = verify_password_reset_token(reset_data.token)
        if not token_data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired reset token"
            )
        
        # Get user
        user = user_db.get_user_by_id(token_data["user_id"])
        if not user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid reset token"
            )
        
        # Validate new password strength
        is_valid, errors = validate_password_strength(
            reset_data.new_password,
            user.username,
            user.email
        )
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "New password does not meet requirements",
                    "errors": errors
                }
            )
        
        # Update password
        from app.security.password_utils import get_password_hash
        user.hashed_password = get_password_hash(reset_data.new_password)
        user.updated_at = datetime.utcnow()
        user_db.update_user(user)
        
        # Revoke all user tokens for security
        token_blacklist.revoke_all_user_tokens(user.id)
        
        # Log password reset
        logger.info(
            f"Password reset completed for: {user.username}",
            user_id=user.id,
            ip_address=get_security_context(request)["client_ip"]
        )
        
        return MessageResponse(message="Password reset successfully")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Password reset confirmation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Password reset failed"
        )


@router.get("/validate-password", response_model=PasswordValidationResponse)
async def validate_password(
    password: str,
    username: str = "",
    email: str = ""
) -> PasswordValidationResponse:
    """
    Validate password strength.
    
    This endpoint provides real-time password validation feedback.
    """
    is_valid, errors = validate_password_strength(password, username, email)
    strength, score = get_password_strength(password)
    
    # Generate suggestions based on errors
    suggestions = []
    if "length" in " ".join(errors).lower():
        suggestions.append("Use at least 12 characters for better security")
    if "uppercase" in " ".join(errors).lower():
        suggestions.append("Include uppercase letters (A-Z)")
    if "lowercase" in " ".join(errors).lower():
        suggestions.append("Include lowercase letters (a-z)")
    if "digit" in " ".join(errors).lower():
        suggestions.append("Include numbers (0-9)")
    if "special" in " ".join(errors).lower():
        suggestions.append("Include special characters (!@#$%^&*)")
    if "common" in " ".join(errors).lower():
        suggestions.append("Avoid common passwords or patterns")
    
    return PasswordValidationResponse(
        is_valid=is_valid,
        strength=strength,
        score=score,
        errors=errors,
        suggestions=suggestions
    )


@router.post("/generate-password", response_model=Dict[str, str])
async def generate_password() -> Dict[str, str]:
    """
    Generate a secure random password.
    
    This endpoint creates a strong password for users.
    """
    password = generate_secure_password(
        length=16,
        include_symbols=True,
        exclude_ambiguous=True,
        exclude_similar=True
    )
    
    return {"password": password}


# Health check for authentication service
@router.get("/health")
async def auth_health_check() -> Dict[str, Any]:
    """Health check endpoint for authentication service."""
    return {
        "status": "healthy",
        "service": "authentication",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0"
    }
