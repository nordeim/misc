"""
Session Management API Routes

This module provides comprehensive REST API endpoints for session management,
including CRUD operations, analytics, security, utilities, and monitoring.

Endpoints:
- CRUD operations: Create, read, update, delete sessions
- Search and filtering: Advanced session search capabilities
- Analytics and reporting: Session statistics and usage metrics
- Management utilities: Session cleanup, migration, and transfer
- Security features: Authentication, authorization, and audit logging
- Monitoring and alerts: Session lifecycle tracking and performance monitoring
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text, func, select, and_, or_, desc, asc, text as sql_text
from typing import List, Optional, Dict, Any, Union
import logging
import uuid
import json
from datetime import datetime, timedelta
from enum import Enum
import re
import asyncio
from concurrent.futures import ThreadPoolExecutor

from app.database import get_db
from app.models.session import (
    SessionORM, SessionCreate, SessionUpdate, SessionRead, 
    SessionSummary, SessionClose, SessionBase
)
from app.models.user import UserORM
from app.models.message import MessageORM
from app.models.memory import MemoryORM
from app.dependencies import (
    get_db_session_dependency, get_current_active_user, 
    get_current_user_optional, check_rate_limit, get_cache,
    get_background_tasks, get_request_info, require_permissions
)

logger = logging.getLogger(__name__)
router = APIRouter()

# Constants for session management
SESSION_EXPIRY_HOURS = 24
MAX_SESSIONS_PER_USER = 100
CLEANUP_BATCH_SIZE = 1000
ANALYTICS_CACHE_TTL = 3600  # 1 hour

# ==============================================================================
# CRUD OPERATIONS
# ==============================================================================

@router.post("/", response_model=Dict[str, Any])
async def create_session(
    session_data: SessionCreate,
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Create a new session.
    
    Args:
        session_data: Session creation data
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Created session information
    """
    try:
        # Check session limits
        active_sessions = await count_user_sessions(db, current_user["id"], "active")
        if active_sessions >= MAX_SESSIONS_PER_USER:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Maximum number of sessions ({MAX_SESSIONS_PER_USER}) exceeded"
            )
        
        # Create session
        session_obj = SessionORM.create_session(
            db, 
            user_id=current_user["id"],
            **session_data.dict()
        )
        
        await db.commit()
        
        logger.info(
            "Session created",
            session_id=session_obj.id,
            user_id=current_user["id"],
            session_type=session_obj.session_type
        )
        
        return {
            "success": True,
            "message": "Session created successfully",
            "session": SessionRead.from_orm(session_obj).dict()
        }
        
    except Exception as e:
        await db.rollback()
        logger.error("Session creation failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create session"
        )

@router.get("/", response_model=Dict[str, Any])
async def list_sessions(
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    status: Optional[str] = Query(None, description="Filter by status"),
    session_type: Optional[str] = Query(None, description="Filter by session type"),
    model_name: Optional[str] = Query(None, description="Filter by model"),
    provider: Optional[str] = Query(None, description="Filter by provider"),
    search: Optional[str] = Query(None, description="Search in title and metadata"),
    tags: Optional[List[str]] = Query(None, description="Filter by tags"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    sort_by: str = Query("last_activity", description="Sort field"),
    sort_order: str = Query("desc", regex="^(asc|desc)$", description="Sort order"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    List sessions with filtering, searching, and pagination.
    
    Args:
        user_id: Filter by user ID
        status: Filter by session status
        session_type: Filter by session type
        model_name: Filter by model name
        provider: Filter by provider
        search: Search query
        tags: Filter by tags
        page: Page number
        limit: Items per page
        sort_by: Sort field
        sort_order: Sort order
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        List of sessions with pagination info
    """
    try:
        # Build query
        query = db.query(SessionORM)
        
        # Access control: users can only see their own sessions unless admin
        if current_user.get("role") != "admin":
            user_id = current_user["id"]
        
        if user_id:
            query = query.filter(SessionORM.user_id == user_id)
        
        if status:
            query = query.filter(SessionORM.status == status)
        
        if session_type:
            query = query.filter(SessionORM.session_type == session_type)
        
        if model_name:
            query = query.filter(SessionORM.model_name == model_name)
        
        if provider:
            query = query.filter(SessionORM.provider == provider)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    SessionORM.title.ilike(search_term),
                    SessionORM.meta_data.cast(sql_text).contains(search_term)
                )
            )
        
        if tags:
            # Filter sessions that have any of the specified tags
            for tag in tags:
                query = query.filter(SessionORM.tags.cast(sql_text).contains(tag))
        
        # Apply sorting
        sort_field = getattr(SessionORM, sort_by, SessionORM.last_activity)
        if sort_order == "asc":
            query = query.order_by(asc(sort_field))
        else:
            query = query.order_by(desc(sort_field))
        
        # Get total count
        total_count = await query.count()
        
        # Apply pagination
        offset = (page - 1) * limit
        sessions = await query.offset(offset).limit(limit).all()
        
        # Convert to response format
        session_list = [SessionSummary.from_orm(s).dict() for s in sessions]
        
        return {
            "success": True,
            "sessions": session_list,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total_count,
                "pages": (total_count + limit - 1) // limit
            }
        }
        
    except Exception as e:
        logger.error("Failed to list sessions", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve sessions"
        )

@router.get("/{session_id}", response_model=Dict[str, Any])
async def get_session(
    session_id: str,
    include_messages: bool = Query(False, description="Include messages"),
    include_memories: bool = Query(False, description="Include memories"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get a specific session by ID.
    
    Args:
        session_id: Session ID
        include_messages: Whether to include messages
        include_memories: Whether to include memories
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Session details
    """
    try:
        # Get session
        query = db.query(SessionORM).filter(SessionORM.id == session_id)
        session = await query.first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Check access permissions
        if current_user.get("role") != "admin" and session.user_id != current_user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        # Convert to response
        session_data = SessionRead.from_orm(session).dict()
        
        # Include optional data
        if include_messages:
            messages = await db.query(MessageORM).filter(
                MessageORM.session_id == session_id
            ).order_by(MessageORM.created_at).all()
            session_data["messages"] = [
                {
                    "id": m.id,
                    "role": m.role,
                    "content": m.content,
                    "token_count": m.token_count,
                    "created_at": m.created_at,
                    "user_feedback": m.user_feedback
                }
                for m in messages
            ]
        
        if include_memories:
            memories = await db.query(MemoryORM).filter(
                MemoryORM.session_id == session_id
            ).order_by(MemoryORM.importance_score.desc()).all()
            session_data["memories"] = [
                {
                    "id": mem.id,
                    "key": mem.key,
                    "value": mem.value,
                    "memory_type": mem.memory_type,
                    "importance_score": mem.importance_score,
                    "is_persistent": mem.is_persistent
                }
                for mem in memories
            ]
        
        return {
            "success": True,
            "session": session_data
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get session", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve session"
        )

@router.put("/{session_id}", response_model=Dict[str, Any])
async def update_session(
    session_id: str,
    session_data: SessionUpdate,
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Update a session.
    
    Args:
        session_id: Session ID
        session_data: Session update data
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Updated session information
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Check access permissions
        if current_user.get("role") != "admin" and session.user_id != current_user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        # Update session
        update_data = session_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(session, field, value)
        
        session.update_activity()
        await db.commit()
        
        logger.info(
            "Session updated",
            session_id=session_id,
            user_id=current_user["id"],
            updates=list(update_data.keys())
        )
        
        return {
            "success": True,
            "message": "Session updated successfully",
            "session": SessionRead.from_orm(session).dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Failed to update session", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update session"
        )

@router.delete("/{session_id}", response_model=Dict[str, Any])
async def delete_session(
    session_id: str,
    hard_delete: bool = Query(False, description="Perform hard delete"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Delete a session.
    
    Args:
        session_id: Session ID
        hard_delete: Whether to perform hard delete (cascade delete)
        current_user: Current authenticated user
        db: Database session
        background_tasks: Background tasks for cleanup
        
    Returns:
        Deletion result
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Check access permissions
        if current_user.get("role") != "admin" and session.user_id != current_user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        if hard_delete:
            # Hard delete (cascade delete messages and memories)
            await db.delete(session)
            logger.info("Session hard deleted", session_id=session_id)
        else:
            # Soft delete (archive)
            session.status = "archived"
            session.update_activity()
            logger.info("Session archived", session_id=session_id)
        
        await db.commit()
        
        return {
            "success": True,
            "message": f"Session {'deleted' if hard_delete else 'archived'} successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Failed to delete session", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete session"
        )

@router.post("/{session_id}/close", response_model=Dict[str, Any])
async def close_session(
    session_id: str,
    close_data: SessionClose,
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Close a session with feedback.
    
    Args:
        session_id: Session ID
        close_data: Session close data with feedback
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Close result
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Check access permissions
        if current_user.get("role") != "admin" and session.user_id != current_user["id"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        # Close session
        session.close_session()
        
        # Set feedback
        if close_data.user_feedback or close_data.rating:
            session.set_feedback(
                close_data.user_feedback, 
                close_data.rating
            )
        
        await db.commit()
        
        logger.info(
            "Session closed",
            session_id=session_id,
            user_id=current_user["id"],
            feedback=close_data.user_feedback,
            rating=close_data.rating
        )
        
        return {
            "success": True,
            "message": "Session closed successfully",
            "session": SessionRead.from_orm(session).dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Failed to close session", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to close session"
        )

# ==============================================================================
# SEARCH AND FILTERING
# ==============================================================================

@router.get("/search/advanced", response_model=Dict[str, Any])
async def advanced_search(
    q: Optional[str] = Query(None, description="General search query"),
    content_search: Optional[str] = Query(None, description="Search in message content"),
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    min_messages: Optional[int] = Query(None, ge=0, description="Minimum message count"),
    max_messages: Optional[int] = Query(None, ge=0, description="Maximum message count"),
    min_tokens: Optional[int] = Query(None, ge=0, description="Minimum token count"),
    max_tokens: Optional[int] = Query(None, ge=0, description="Maximum token count"),
    rating: Optional[int] = Query(None, ge=1, le=5, description="Filter by rating"),
    feedback: Optional[str] = Query(None, description="Filter by feedback type"),
    has_attachments: Optional[bool] = Query(None, description="Filter sessions with attachments"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Advanced search and filtering for sessions.
    
    Args:
        q: General search query
        content_search: Search in message content
        date_from: Date range start
        date_to: Date range end
        min_messages: Minimum message count
        max_messages: Maximum message count
        min_tokens: Minimum token count
        max_tokens: Maximum token count
        rating: Filter by rating
        feedback: Filter by feedback type
        has_attachments: Filter sessions with attachments
        page: Page number
        limit: Items per page
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Search results with pagination
    """
    try:
        # Build base query
        query = db.query(SessionORM)
        
        # Access control
        if current_user.get("role") != "admin":
            query = query.filter(SessionORM.user_id == current_user["id"])
        
        # Apply filters
        if q:
            search_term = f"%{q}%"
            query = query.filter(
                or_(
                    SessionORM.title.ilike(search_term),
                    SessionORM.meta_data.cast(sql_text).contains(q)
                )
            )
        
        if date_from:
            query = query.filter(SessionORM.created_at >= date_from)
        
        if date_to:
            query = query.filter(SessionORM.created_at <= date_to)
        
        if min_messages is not None:
            query = query.filter(SessionORM.message_count >= min_messages)
        
        if max_messages is not None:
            query = query.filter(SessionORM.message_count <= max_messages)
        
        if min_tokens is not None:
            query = query.filter(SessionORM.token_count >= min_tokens)
        
        if max_tokens is not None:
            query = query.filter(SessionORM.token_count <= max_tokens)
        
        if rating is not None:
            query = query.filter(SessionORM.rating == rating)
        
        if feedback:
            query = query.filter(SessionORM.user_feedback == feedback)
        
        if has_attachments is not None:
            # Check if sessions have messages with attachments
            if has_attachments:
                query = query.filter(SessionORM.messages.any())
            else:
                # This would need a more complex query to check for no attachments
                pass
        
        # Search in message content if specified
        if content_search:
            message_query = db.query(MessageORM.session_id).filter(
                MessageORM.content.ilike(f"%{content_search}%")
            ).subquery()
            query = query.filter(SessionORM.id.in_(select(message_query)))
        
        # Order by relevance/recent activity
        query = query.order_by(desc(SessionORM.last_activity))
        
        # Get total count
        total_count = await query.count()
        
        # Apply pagination
        offset = (page - 1) * limit
        sessions = await query.offset(offset).limit(limit).all()
        
        # Convert to response
        session_list = [SessionSummary.from_orm(s).dict() for s in sessions]
        
        return {
            "success": True,
            "sessions": session_list,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total_count,
                "pages": (total_count + limit - 1) // limit
            },
            "filters_applied": {
                "q": q,
                "content_search": content_search,
                "date_from": date_from,
                "date_to": date_to,
                "min_messages": min_messages,
                "max_messages": max_messages,
                "min_tokens": min_tokens,
                "max_tokens": max_tokens,
                "rating": rating,
                "feedback": feedback,
                "has_attachments": has_attachments
            }
        }
        
    except Exception as e:
        logger.error("Advanced search failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Search failed"
        )

@router.get("/search/suggestions", response_model=Dict[str, Any])
async def search_suggestions(
    q: str = Query(..., min_length=2, description="Search query prefix"),
    limit: int = Query(10, ge=1, le=50, description="Number of suggestions"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get search suggestions for session titles and tags.
    
    Args:
        q: Search query prefix
        limit: Number of suggestions
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Search suggestions
    """
    try:
        suggestions = []
        
        # Search in session titles
        title_query = db.query(SessionORM.title).filter(
            SessionORM.title.ilike(f"%{q}%")
        )
        
        # Access control
        if current_user.get("role") != "admin":
            title_query = title_query.filter(SessionORM.user_id == current_user["id"])
        
        titles = await title_query.limit(limit).all()
        suggestions.extend([{"type": "title", "value": title[0]} for title in titles])
        
        # Search in tags
        # This is a simplified tag search - in practice, you'd want to extract and deduplicate tags
        tag_query = db.query(SessionORM.tags).filter(
            SessionORM.tags.isnot(None)
        )
        
        if current_user.get("role") != "admin":
            tag_query = tag_query.filter(SessionORM.user_id == current_user["id"])
        
        sessions_with_tags = await tag_query.limit(limit).all()
        for session in sessions_with_tags:
            if session.tags:
                for tag in session.tags:
                    if q.lower() in tag.lower():
                        suggestions.append({"type": "tag", "value": tag})
        
        # Remove duplicates and limit
        seen = set()
        unique_suggestions = []
        for suggestion in suggestions:
            if suggestion["value"] not in seen:
                seen.add(suggestion["value"])
                unique_suggestions.append(suggestion)
                if len(unique_suggestions) >= limit:
                    break
        
        return {
            "success": True,
            "suggestions": unique_suggestions
        }
        
    except Exception as e:
        logger.error("Search suggestions failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get suggestions"
        )

# ==============================================================================
# ANALYTICS AND REPORTING
# ==============================================================================

@router.get("/analytics/overview", response_model=Dict[str, Any])
async def get_analytics_overview(
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    cache: Dict[str, Any] = Depends(get_cache),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get comprehensive analytics overview for sessions.
    
    Args:
        date_from: Date range start
        date_to: Date range end
        user_id: Filter by user ID
        cache: Cache instance
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Analytics overview data
    """
    try:
        # Generate cache key
        cache_key = f"session_analytics_overview:{user_id or current_user['id']}:{date_from or 'start'}:{date_to or 'end'}"
        
        # Check cache
        if cache["exists"](cache_key):
            cached_data = await cache["get"](cache_key)
            if cached_data:
                return json.loads(cached_data)
        
        # Set default date range if not provided
        if not date_from:
            date_from = datetime.utcnow() - timedelta(days=30)
        if not date_to:
            date_to = datetime.utcnow()
        
        # Access control
        query = db.query(SessionORM).filter(
            SessionORM.created_at >= date_from,
            SessionORM.created_at <= date_to
        )
        
        if current_user.get("role") != "admin" or user_id:
            target_user_id = user_id or current_user["id"]
            query = query.filter(SessionORM.user_id == target_user_id)
        
        # Basic statistics
        total_sessions = await query.count()
        
        active_sessions = await query.filter(SessionORM.status == "active").count()
        closed_sessions = await query.filter(SessionORM.status == "closed").count()
        archived_sessions = await query.filter(SessionORM.status == "archived").count()
        
        # Usage statistics
        total_messages = await query.with_entities(
            func.sum(SessionORM.message_count)
        ).scalar() or 0
        
        total_tokens = await query.with_entities(
            func.sum(SessionORM.token_count)
        ).scalar() or 0
        
        avg_messages_per_session = total_messages / total_sessions if total_sessions > 0 else 0
        avg_tokens_per_session = total_tokens / total_sessions if total_sessions > 0 else 0
        
        # Session type distribution
        session_types = await query.with_entities(
            SessionORM.session_type,
            func.count(SessionORM.id)
        ).group_by(SessionORM.session_type).all()
        
        # Model usage distribution
        model_usage = await query.with_entities(
            SessionORM.model_name,
            func.count(SessionORM.id),
            func.sum(SessionORM.token_count)
        ).group_by(SessionORM.model_name).all()
        
        # Provider usage distribution
        provider_usage = await query.with_entities(
            SessionORM.provider,
            func.count(SessionORM.id),
            func.sum(SessionORM.token_count)
        ).group_by(SessionORM.provider).all()
        
        # Daily activity (last 30 days)
        daily_activity = []
        current_date = date_from.date()
        while current_date <= date_to.date():
            day_start = datetime.combine(current_date, datetime.min.time())
            day_end = datetime.combine(current_date, datetime.max.time())
            
            day_sessions = await query.filter(
                SessionORM.created_at >= day_start,
                SessionORM.created_at <= day_end
            ).count()
            
            daily_activity.append({
                "date": current_date.isoformat(),
                "sessions": day_sessions
            })
            
            current_date += timedelta(days=1)
        
        # Feedback statistics
        feedback_stats = await query.with_entities(
            SessionORM.user_feedback,
            func.count(SessionORM.id),
            func.avg(SessionORM.rating)
        ).filter(SessionORM.user_feedback.isnot(None)).group_by(SessionORM.user_feedback).all()
        
        analytics_data = {
            "success": True,
            "period": {
                "from": date_from.isoformat(),
                "to": date_to.isoformat(),
                "days": (date_to - date_from).days
            },
            "overview": {
                "total_sessions": total_sessions,
                "active_sessions": active_sessions,
                "closed_sessions": closed_sessions,
                "archived_sessions": archived_sessions,
                "total_messages": int(total_messages),
                "total_tokens": int(total_tokens),
                "avg_messages_per_session": round(avg_messages_per_session, 2),
                "avg_tokens_per_session": round(avg_tokens_per_session, 2)
            },
            "distributions": {
                "session_types": [{"type": st[0], "count": st[1]} for st in session_types],
                "models": [
                    {
                        "model": m[0] or "unknown",
                        "sessions": m[1],
                        "total_tokens": int(m[2] or 0)
                    } for m in model_usage
                ],
                "providers": [
                    {
                        "provider": p[0] or "unknown",
                        "sessions": p[1],
                        "total_tokens": int(p[2] or 0)
                    } for p in provider_usage
                ]
            },
            "activity": daily_activity,
            "feedback": [
                {
                    "type": f[0],
                    "count": f[1],
                    "avg_rating": round(f[2], 2) if f[2] else None
                } for f in feedback_stats
            ]
        }
        
        # Cache the result
        await cache["set"](cache_key, json.dumps(analytics_data), ANALYTICS_CACHE_TTL)
        
        return analytics_data
        
    except Exception as e:
        logger.error("Analytics overview failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get analytics"
        )

@router.get("/analytics/performance", response_model=Dict[str, Any])
async def get_performance_metrics(
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get session performance metrics and trends.
    
    Args:
        date_from: Date range start
        date_to: Date range end
        user_id: Filter by user ID
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Performance metrics
    """
    try:
        # Set default date range
        if not date_from:
            date_from = datetime.utcnow() - timedelta(days=7)
        if not date_to:
            date_to = datetime.utcnow()
        
        # Access control
        query = db.query(SessionORM).filter(
            SessionORM.created_at >= date_from,
            SessionORM.created_at <= date_to
        )
        
        if current_user.get("role") != "admin" or user_id:
            target_user_id = user_id or current_user["id"]
            query = query.filter(SessionORM.user_id == target_user_id)
        
        # Calculate performance metrics
        sessions = await query.all()
        
        if not sessions:
            return {
                "success": True,
                "message": "No sessions found for the specified period",
                "metrics": {}
            }
        
        # Session duration analysis
        durations = []
        for session in sessions:
            if session.ended_at and session.started_at:
                duration = (session.ended_at - session.started_at).total_seconds() / 60  # minutes
                durations.append(duration)
        
        avg_session_duration = sum(durations) / len(durations) if durations else 0
        
        # Message count distribution
        message_counts = [s.message_count for s in sessions]
        avg_messages = sum(message_counts) / len(message_counts)
        
        # Token usage analysis
        token_counts = [s.token_count for s in sessions]
        avg_tokens = sum(token_counts) / len(token_counts)
        
        # Session completion rate
        completed_sessions = [s for s in sessions if s.status == "closed"]
        completion_rate = len(completed_sessions) / len(sessions) * 100 if sessions else 0
        
        # User satisfaction (based on ratings)
        rated_sessions = [s for s in sessions if s.rating is not None]
        avg_rating = sum(s.rating for s in rated_sessions) / len(rated_sessions) if rated_sessions else 0
        
        # Peak activity times (simplified analysis)
        hourly_activity = {}
        for session in sessions:
            hour = session.started_at.hour
            hourly_activity[hour] = hourly_activity.get(hour, 0) + 1
        
        peak_hour = max(hourly_activity.items(), key=lambda x: x[1])[0] if hourly_activity else 12
        
        metrics = {
            "success": True,
            "period": {
                "from": date_from.isoformat(),
                "to": date_to.isoformat()
            },
            "metrics": {
                "avg_session_duration_minutes": round(avg_session_duration, 2),
                "avg_messages_per_session": round(avg_messages, 2),
                "avg_tokens_per_session": round(avg_tokens, 2),
                "completion_rate_percent": round(completion_rate, 2),
                "avg_user_rating": round(avg_rating, 2),
                "peak_activity_hour": peak_hour,
                "session_distribution": {
                    "duration_brackets": {
                        "short_0_5min": len([d for d in durations if d <= 5]),
                        "medium_5_30min": len([d for d in durations if 5 < d <= 30]),
                        "long_30min_plus": len([d for d in durations if d > 30])
                    },
                    "message_count_brackets": {
                        "few_0_5": len([m for m in message_counts if m <= 5]),
                        "moderate_6_20": len([m for m in message_counts if 6 <= m <= 20]),
                        "many_21_plus": len([m for m in message_counts if m > 20])
                    },
                    "token_usage_brackets": {
                        "low_0_1k": len([t for t in token_counts if t <= 1000]),
                        "medium_1k_10k": len([t for t in token_counts if 1000 < t <= 10000]),
                        "high_10k_plus": len([t for t in token_counts if t > 10000])
                    }
                },
                "hourly_activity": hourly_activity
            }
        }
        
        return metrics
        
    except Exception as e:
        logger.error("Performance metrics failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get performance metrics"
        )

@router.get("/analytics/usage", response_model=Dict[str, Any])
async def get_usage_analytics(
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    group_by: str = Query("day", regex="^(hour|day|week|month)$", description="Grouping period"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get detailed usage analytics with time-based grouping.
    
    Args:
        date_from: Date range start
        date_to: Date range end
        group_by: Time grouping period
        current_user: Current authenticated user
        db: Database session
        
    Returns:
        Usage analytics with time-based grouping
    """
    try:
        # Set default date range
        if not date_from:
            date_from = datetime.utcnow() - timedelta(days=30)
        if not date_to:
            date_to = datetime.utcnow()
        
        # Access control
        query = db.query(SessionORM).filter(
            SessionORM.created_at >= date_from,
            SessionORM.created_at <= date_to
        )
        
        if current_user.get("role") != "admin":
            query = query.filter(SessionORM.user_id == current_user["id"])
        
        # Get raw data
        sessions = await query.all()
        
        # Group data based on specified period
        grouped_data = {}
        
        for session in sessions:
            # Determine grouping key
            if group_by == "hour":
                key = session.started_at.strftime("%Y-%m-%d %H:00")
            elif group_by == "day":
                key = session.started_at.strftime("%Y-%m-%d")
            elif group_by == "week":
                year, week, _ = session.started_at.isocalendar()
                key = f"{year}-W{week:02d}"
            elif group_by == "month":
                key = session.started_at.strftime("%Y-%m")
            
            if key not in grouped_data:
                grouped_data[key] = {
                    "period": key,
                    "sessions": 0,
                    "messages": 0,
                    "tokens": 0,
                    "unique_users": set()
                }
            
            grouped_data[key]["sessions"] += 1
            grouped_data[key]["messages"] += session.message_count
            grouped_data[key]["tokens"] += session.token_count
            grouped_data[key]["unique_users"].add(session.user_id)
        
        # Convert to list and calculate derived metrics
        usage_data = []
        for period, data in sorted(grouped_data.items()):
            usage_data.append({
                "period": period,
                "sessions": data["sessions"],
                "messages": data["messages"],
                "tokens": data["tokens"],
                "unique_users": len(data["unique_users"]),
                "avg_messages_per_session": round(data["messages"] / data["sessions"], 2) if data["sessions"] > 0 else 0,
                "avg_tokens_per_session": round(data["tokens"] / data["sessions"], 2) if data["sessions"] > 0 else 0
            })
        
        return {
            "success": True,
            "period": {
                "from": date_from.isoformat(),
                "to": date_to.isoformat(),
                "group_by": group_by
            },
            "usage": usage_data,
            "summary": {
                "total_sessions": sum(u["sessions"] for u in usage_data),
                "total_messages": sum(u["messages"] for u in usage_data),
                "total_tokens": sum(u["tokens"] for u in usage_data),
                "avg_sessions_per_period": round(sum(u["sessions"] for u in usage_data) / len(usage_data), 2) if usage_data else 0
            }
        }
        
    except Exception as e:
        logger.error("Usage analytics failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get usage analytics"
        )

# ==============================================================================
# SESSION MANAGEMENT UTILITIES
# ==============================================================================

@router.post("/cleanup/expired", response_model=Dict[str, Any])
async def cleanup_expired_sessions(
    dry_run: bool = Query(True, description="Perform dry run without actual deletion"),
    max_age_hours: int = Query(SESSION_EXPIRY_HOURS, description="Maximum session age in hours"),
    background_tasks: BackgroundTasks = Depends(get_background_tasks),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Clean up expired sessions.
    
    Args:
        dry_run: Whether to perform a dry run
        max_age_hours: Maximum session age in hours
        background_tasks: Background tasks
        current_user: Current authenticated user (must be admin)
        db: Database session
        
    Returns:
        Cleanup results
    """
    try:
        # Calculate cutoff time
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
        
        # Find expired sessions
        expired_query = db.query(SessionORM).filter(
            SessionORM.status == "active",
            SessionORM.last_activity < cutoff_time
        )
        
        expired_sessions = await expired_query.all()
        expired_count = len(expired_sessions)
        
        if dry_run:
            return {
                "success": True,
                "message": f"Dry run completed. Found {expired_count} expired sessions.",
                "dry_run": True,
                "expired_sessions_found": expired_count,
                "cutoff_time": cutoff_time.isoformat()
            }
        
        # Perform actual cleanup
        cleaned_sessions = 0
        
        for session in expired_sessions:
            try:
                # Archive expired sessions
                session.status = "archived"
                session.update_activity()
                cleaned_sessions += 1
                
                logger.info(
                    "Session expired and archived",
                    session_id=session.id,
                    last_activity=session.last_activity
                )
                
            except Exception as e:
                logger.error(
                    "Failed to archive expired session",
                    session_id=session.id,
                    error=str(e)
                )
        
        await db.commit()
        
        logger.info(
            "Expired sessions cleanup completed",
            expired_sessions=expired_count,
            cleaned_sessions=cleaned_sessions
        )
        
        return {
            "success": True,
            "message": f"Cleaned up {cleaned_sessions} expired sessions.",
            "dry_run": False,
            "expired_sessions_found": expired_count,
            "cleaned_sessions": cleaned_sessions,
            "cutoff_time": cutoff_time.isoformat()
        }
        
    except Exception as e:
        await db.rollback()
        logger.error("Session cleanup failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Session cleanup failed"
        )

@router.post("/batch/operations", response_model=Dict[str, Any])
async def batch_operations(
    operation: str = Query(..., regex="^(archive|close|delete|transfer)$", description="Operation to perform"),
    session_ids: List[str] = Query(..., description="List of session IDs"),
    target_user_id: Optional[str] = Query(None, description="Target user ID for transfer operation"),
    reason: Optional[str] = Query(None, description="Reason for the operation"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Perform batch operations on multiple sessions.
    
    Args:
        operation: Operation to perform
        session_ids: List of session IDs
        target_user_id: Target user ID for transfer operation
        reason: Reason for the operation
        current_user: Current authenticated user
        db: Database session
        background_tasks: Background tasks
        
    Returns:
        Batch operation results
    """
    try:
        if not session_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Session IDs list cannot be empty"
            )
        
        # Get sessions
        sessions_query = db.query(SessionORM).filter(SessionORM.id.in_(session_ids))
        sessions = await sessions_query.all()
        
        if len(sessions) != len(session_ids):
            missing_ids = set(session_ids) - {s.id for s in sessions}
            logger.warning("Some session IDs not found", missing_ids=list(missing_ids))
        
        # Check permissions
        accessible_sessions = []
        for session in sessions:
            if current_user.get("role") == "admin" or session.user_id == current_user["id"]:
                accessible_sessions.append(session)
        
        if not accessible_sessions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No accessible sessions found"
            )
        
        # Perform operation
        results = {
            "operation": operation,
            "total_requested": len(session_ids),
            "accessible_sessions": len(accessible_sessions),
            "processed": 0,
            "failed": 0,
            "errors": []
        }
        
        for session in accessible_sessions:
            try:
                if operation == "archive":
                    session.status = "archived"
                    session.update_activity()
                    
                elif operation == "close":
                    session.close_session()
                    
                elif operation == "delete":
                    await db.delete(session)
                    
                elif operation == "transfer":
                    if not target_user_id:
                        raise ValueError("Target user ID required for transfer operation")
                    
                    # Verify target user exists
                    target_user = await db.query(UserORM).filter(UserORM.id == target_user_id).first()
                    if not target_user:
                        raise ValueError("Target user not found")
                    
                    session.user_id = target_user_id
                    session.update_activity()
                
                results["processed"] += 1
                
                logger.info(
                    "Batch operation applied",
                    operation=operation,
                    session_id=session.id,
                    user_id=current_user["id"],
                    reason=reason
                )
                
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({
                    "session_id": session.id,
                    "error": str(e)
                })
        
        await db.commit()
        
        return {
            "success": True,
            "message": f"Batch {operation} completed on {results['processed']} sessions",
            "results": results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Batch operation failed", operation=operation, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch operation failed: {str(e)}"
        )

@router.post("/migrate/{session_id}", response_model=Dict[str, Any])
async def migrate_session(
    session_id: str,
    target_user_id: str = Query(..., description="Target user ID"),
    preserve_history: bool = Query(True, description="Preserve session history"),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Migrate a session to another user.
    
    Args:
        session_id: Session ID to migrate
        target_user_id: Target user ID
        preserve_history: Whether to preserve session history
        current_user: Current authenticated user (must be admin)
        db: Database session
        background_tasks: Background tasks
        
    Returns:
        Migration results
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Verify target user exists
        target_user = await db.query(UserORM).filter(UserORM.id == target_user_id).first()
        if not target_user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Target user not found"
            )
        
        # Store original user for logging
        original_user_id = session.user_id
        
        # Perform migration
        session.user_id = target_user_id
        session.update_activity()
        
        # Add migration metadata
        if not session.meta_data:
            session.meta_data = {}
        session.meta_data["migration"] = {
            "migrated_at": datetime.utcnow().isoformat(),
            "migrated_by": current_user["id"],
            "from_user": original_user_id,
            "to_user": target_user_id,
            "preserve_history": preserve_history
        }
        
        await db.commit()
        
        logger.info(
            "Session migrated",
            session_id=session_id,
            from_user=original_user_id,
            to_user=target_user_id,
            migrated_by=current_user["id"]
        )
        
        return {
            "success": True,
            "message": "Session migrated successfully",
            "migration": {
                "session_id": session_id,
                "from_user": original_user_id,
                "to_user": target_user_id,
                "migrated_at": datetime.utcnow().isoformat(),
                "migrated_by": current_user["id"]
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Session migration failed", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Session migration failed"
        )

@router.get("/export/{user_id}", response_model=Dict[str, Any])
async def export_user_sessions(
    user_id: str,
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    include_messages: bool = Query(False, description="Include messages in export"),
    include_memories: bool = Query(False, description="Include memories in export"),
    format: str = Query("json", regex="^(json|csv)$", description="Export format"),
    current_user: Dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Export user sessions data.
    
    Args:
        user_id: User ID to export sessions for
        date_from: Date range start
        date_to: Date range end
        include_messages: Include messages in export
        include_memories: Include memories in export
        format: Export format
        current_user: Current authenticated user
        db: Database session
        background_tasks: Background tasks
        
    Returns:
        Export download information
    """
    try:
        # Access control
        if current_user.get("role") != "admin" and current_user["id"] != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        # Build query
        query = db.query(SessionORM).filter(SessionORM.user_id == user_id)
        
        if date_from:
            query = query.filter(SessionORM.created_at >= date_from)
        if date_to:
            query = query.filter(SessionORM.created_at <= date_to)
        
        sessions = await query.order_by(desc(SessionORM.created_at)).all()
        
        # Prepare export data
        export_data = {
            "user_id": user_id,
            "exported_at": datetime.utcnow().isoformat(),
            "total_sessions": len(sessions),
            "date_range": {
                "from": date_from.isoformat() if date_from else None,
                "to": date_to.isoformat() if date_to else None
            },
            "include_messages": include_messages,
            "include_memories": include_memories,
            "sessions": []
        }
        
        # Process each session
        for session in sessions:
            session_data = SessionRead.from_orm(session).dict()
            
            # Optionally include messages
            if include_messages:
                messages = await db.query(MessageORM).filter(
                    MessageORM.session_id == session.id
                ).order_by(MessageORM.created_at).all()
                session_data["messages"] = [
                    {
                        "id": m.id,
                        "role": m.role,
                        "content": m.content,
                        "token_count": m.token_count,
                        "created_at": m.created_at,
                        "user_feedback": m.user_feedback
                    }
                    for m in messages
                ]
            
            # Optionally include memories
            if include_memories:
                memories = await db.query(MemoryORM).filter(
                    MemoryORM.session_id == session.id
                ).order_by(MemoryORM.importance_score.desc()).all()
                session_data["memories"] = [
                    {
                        "id": mem.id,
                        "key": mem.key,
                        "value": mem.value,
                        "memory_type": mem.memory_type,
                        "importance_score": mem.importance_score,
                        "is_persistent": mem.is_persistent
                    }
                    for mem in memories
                ]
            
            export_data["sessions"].append(session_data)
        
        logger.info(
            "Sessions export completed",
            user_id=user_id,
            session_count=len(sessions),
            include_messages=include_messages,
            include_memories=include_memories
        )
        
        return {
            "success": True,
            "message": f"Exported {len(sessions)} sessions",
            "export_info": export_data,
            "download_ready": True  # In a real implementation, you'd generate a download URL
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Session export failed", user_id=user_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Session export failed"
        )

# ==============================================================================
# SESSION SECURITY
# ==============================================================================

@router.post("/{session_id}/lock", response_model=Dict[str, Any])
async def lock_session(
    session_id: str,
    reason: Optional[str] = Query(None, description="Lock reason"),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Lock a session for security purposes.
    
    Args:
        session_id: Session ID to lock
        reason: Reason for locking
        current_user: Current authenticated user (must be admin)
        db: Database session
        background_tasks: Background tasks
        
    Returns:
        Lock result
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Update session status
        session.status = "locked"
        session.update_activity()
        
        # Add security metadata
        if not session.meta_data:
            session.meta_data = {}
        session.meta_data["security"] = {
            "locked_at": datetime.utcnow().isoformat(),
            "locked_by": current_user["id"],
            "reason": reason or "Security lock"
        }
        
        await db.commit()
        
        logger.info(
            "Session locked",
            session_id=session_id,
            locked_by=current_user["id"],
            reason=reason
        )
        
        return {
            "success": True,
            "message": "Session locked successfully",
            "lock_info": {
                "session_id": session_id,
                "locked_at": datetime.utcnow().isoformat(),
                "locked_by": current_user["id"],
                "reason": reason or "Security lock"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Session lock failed", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Session lock failed"
        )

@router.post("/{session_id}/unlock", response_model=Dict[str, Any])
async def unlock_session(
    session_id: str,
    reason: Optional[str] = Query(None, description="Unlock reason"),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency),
    background_tasks: BackgroundTasks = Depends(get_background_tasks)
):
    """
    Unlock a previously locked session.
    
    Args:
        session_id: Session ID to unlock
        reason: Reason for unlocking
        current_user: Current authenticated user (must be admin)
        db: Database session
        background_tasks: Background tasks
        
    Returns:
        Unlock result
    """
    try:
        # Get session
        session = await db.query(SessionORM).filter(SessionORM.id == session_id).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        
        # Check if session is locked
        if session.status != "locked":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Session is not locked"
            )
        
        # Update session status
        session.status = "active"
        session.update_activity()
        
        # Update security metadata
        if session.meta_data and "security" in session.meta_data:
            session.meta_data["security"]["unlocked_at"] = datetime.utcnow().isoformat()
            session.meta_data["security"]["unlocked_by"] = current_user["id"]
            session.meta_data["security"]["unlock_reason"] = reason or "Manual unlock"
        
        await db.commit()
        
        logger.info(
            "Session unlocked",
            session_id=session_id,
            unlocked_by=current_user["id"],
            reason=reason
        )
        
        return {
            "success": True,
            "message": "Session unlocked successfully",
            "unlock_info": {
                "session_id": session_id,
                "unlocked_at": datetime.utcnow().isoformat(),
                "unlocked_by": current_user["id"],
                "reason": reason or "Manual unlock"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error("Session unlock failed", session_id=session_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Session unlock failed"
        )

@router.get("/audit/logs", response_model=Dict[str, Any])
async def get_audit_logs(
    session_id: Optional[str] = Query(None, description="Filter by session ID"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    action: Optional[str] = Query(None, description="Filter by action type"),
    date_from: Optional[datetime] = Query(None, description="Date range start"),
    date_to: Optional[datetime] = Query(None, description="Date range end"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(50, ge=1, le=200, description="Items per page"),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get session audit logs.
    
    Args:
        session_id: Filter by session ID
        user_id: Filter by user ID
        action: Filter by action type
        date_from: Date range start
        date_to: Date range end
        page: Page number
        limit: Items per page
        current_user: Current authenticated user (must be admin)
        db: Database session
        
    Returns:
        Audit logs
    """
    try:
        # This is a simplified audit log implementation
        # In a real system, you'd have a separate audit_logs table
        
        # Build query for sessions with security metadata
        query = db.query(SessionORM)
        
        if session_id:
            query = query.filter(SessionORM.id == session_id)
        
        if user_id:
            query = query.filter(SessionORM.user_id == user_id)
        
        if date_from:
            query = query.filter(SessionORM.created_at >= date_from)
        
        if date_to:
            query = query.filter(SessionORM.created_at <= date_to)
        
        sessions = await query.order_by(desc(SessionORM.updated_at)).all()
        
        # Extract audit information
        audit_logs = []
        for session in sessions:
            # Check for security metadata
            if session.meta_data and "security" in session.meta_data:
                security_info = session.meta_data["security"]
                if "locked_at" in security_info:
                    audit_logs.append({
                        "session_id": session.id,
                        "user_id": session.user_id,
                        "action": "LOCK_SESSION",
                        "timestamp": security_info["locked_at"],
                        "actor": security_info.get("locked_by"),
                        "details": f"Session locked: {security_info.get('reason', 'No reason')}"
                    })
                
                if "unlocked_at" in security_info:
                    audit_logs.append({
                        "session_id": session.id,
                        "user_id": session.user_id,
                        "action": "UNLOCK_SESSION",
                        "timestamp": security_info["unlocked_at"],
                        "actor": security_info.get("unlocked_by"),
                        "details": f"Session unlocked: {security_info.get('unlock_reason', 'No reason')}"
                    })
            
            # Check for migration metadata
            if session.meta_data and "migration" in session.meta_data:
                migration_info = session.meta_data["migration"]
                audit_logs.append({
                    "session_id": session.id,
                    "user_id": migration_info.get("from_user"),
                    "action": "MIGRATE_SESSION",
                    "timestamp": migration_info.get("migrated_at"),
                    "actor": migration_info.get("migrated_by"),
                    "details": f"Migrated from user {migration_info.get('from_user')} to {migration_info.get('to_user')}"
                })
            
            # Check for status changes
            if session.status == "archived":
                audit_logs.append({
                    "session_id": session.id,
                    "user_id": session.user_id,
                    "action": "ARCHIVE_SESSION",
                    "timestamp": session.updated_at.isoformat(),
                    "actor": session.user_id,
                    "details": "Session archived"
                })
        
        # Filter by action if specified
        if action:
            audit_logs = [log for log in audit_logs if log["action"] == action]
        
        # Sort by timestamp descending
        audit_logs.sort(key=lambda x: x["timestamp"], reverse=True)
        
        # Apply pagination
        total_count = len(audit_logs)
        offset = (page - 1) * limit
        paginated_logs = audit_logs[offset:offset + limit]
        
        return {
            "success": True,
            "audit_logs": paginated_logs,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total_count,
                "pages": (total_count + limit - 1) // limit
            }
        }
        
    except Exception as e:
        logger.error("Audit logs retrieval failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve audit logs"
        )

# ==============================================================================
# MONITORING AND ALERTS
# ==============================================================================

@router.get("/monitoring/health", response_model=Dict[str, Any])
async def get_session_health(
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get session system health status.
    
    Args:
        current_user: Current authenticated user (must be admin)
        db: Database session
        
    Returns:
        System health status
    """
    try:
        # Get current timestamp
        now = datetime.utcnow()
        
        # Calculate thresholds
        hour_ago = now - timedelta(hours=1)
        day_ago = now - timedelta(days=1)
        
        # Get basic metrics
        total_sessions = await db.query(SessionORM).count()
        active_sessions = await db.query(SessionORM).filter(SessionORM.status == "active").count()
        
        # Recent activity
        recent_sessions = await db.query(SessionORM).filter(
            SessionORM.created_at >= hour_ago
        ).count()
        
        # Potential issues
        expired_sessions = await db.query(SessionORM).filter(
            and_(
                SessionORM.status == "active",
                SessionORM.last_activity < day_ago
            )
        ).count()
        
        # Performance metrics
        avg_session_duration = await db.query(
            func.avg(
                func.julianday(func.ifnull(SessionORM.ended_at, now)) - 
                func.julianday(SessionORM.started_at)
            )
        ).scalar() or 0
        
        # Health status determination
        health_status = "healthy"
        alerts = []
        
        if expired_sessions > total_sessions * 0.1:  # More than 10% expired
            health_status = "warning"
            alerts.append(f"High number of expired sessions: {expired_sessions}")
        
        if recent_sessions == 0:  # No recent activity
            health_status = "warning"
            alerts.append("No recent session activity")
        
        health_data = {
            "success": True,
            "health_status": health_status,
            "timestamp": now.isoformat(),
            "metrics": {
                "total_sessions": total_sessions,
                "active_sessions": active_sessions,
                "expired_sessions": expired_sessions,
                "recent_sessions_last_hour": recent_sessions,
                "avg_session_duration_days": round(avg_session_duration, 2)
            },
            "alerts": alerts,
            "recommendations": []
        }
        
        # Add recommendations
        if expired_sessions > 0:
            health_data["recommendations"].append("Consider running session cleanup")
        
        if recent_sessions < 10:
            health_data["recommendations"].append("Monitor for potential usage issues")
        
        return health_data
        
    except Exception as e:
        logger.error("Session health check failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Health check failed"
        )

@router.get("/monitoring/alerts", response_model=Dict[str, Any])
async def get_session_alerts(
    active_only: bool = Query(True, description="Show only active alerts"),
    alert_type: Optional[str] = Query(None, description="Filter by alert type"),
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get session-related alerts and notifications.
    
    Args:
        active_only: Show only active alerts
        alert_type: Filter by alert type
        current_user: Current authenticated user (must be admin)
        db: Database session
        
    Returns:
        List of alerts
    """
    try:
        alerts = []
        now = datetime.utcnow()
        
        # Check for expired sessions
        day_ago = now - timedelta(days=1)
        expired_count = await db.query(SessionORM).filter(
            and_(
                SessionORM.status == "active",
                SessionORM.last_activity < day_ago
            )
        ).count()
        
        if expired_count > 0:
            alerts.append({
                "id": f"expired_sessions_{now.strftime('%Y%m%d_%H%M%S')}",
                "type": "EXPIRED_SESSIONS",
                "severity": "medium" if expired_count < 100 else "high",
                "message": f"{expired_count} sessions have been inactive for more than 24 hours",
                "count": expired_count,
                "created_at": now.isoformat(),
                "active": True,
                "actions": [
                    {"type": "cleanup", "label": "Run Cleanup", "endpoint": "/sessions/cleanup/expired"}
                ]
            })
        
        # Check for unusually long sessions
        week_ago = now - timedelta(days=7)
        long_sessions = await db.query(SessionORM).filter(
            and_(
                SessionORM.status == "active",
                SessionORM.started_at < week_ago
            )
        ).count()
        
        if long_sessions > 0:
            alerts.append({
                "id": f"long_sessions_{now.strftime('%Y%m%d_%H%M%S')}",
                "type": "LONG_SESSIONS",
                "severity": "low",
                "message": f"{long_sessions} sessions have been active for more than 7 days",
                "count": long_sessions,
                "created_at": now.isoformat(),
                "active": True,
                "actions": [
                    {"type": "review", "label": "Review Sessions", "endpoint": "/sessions?status=active"}
                ]
            })
        
        # Check for high session count per user
        high_usage_query = await db.query(
            SessionORM.user_id,
            func.count(SessionORM.id).label('session_count')
        ).filter(SessionORM.status == "active").group_by(SessionORM.user_id).having(
            func.count(SessionORM.id) > MAX_SESSIONS_PER_USER
        ).all()
        
        for result in high_usage_query:
            alerts.append({
                "id": f"high_usage_{result.user_id}_{now.strftime('%Y%m%d_%H%M%S')}",
                "type": "HIGH_USAGE",
                "severity": "low",
                "message": f"User {result.user_id} has {result.session_count} active sessions",
                "count": result.session_count,
                "created_at": now.isoformat(),
                "active": True,
                "actions": [
                    {"type": "investigate", "label": "Investigate User", "endpoint": f"/users/{result.user_id}"}
                ]
            })
        
        # Filter by type if specified
        if alert_type:
            alerts = [alert for alert in alerts if alert["type"] == alert_type]
        
        # Filter active only
        if active_only:
            alerts = [alert for alert in alerts if alert["active"]]
        
        return {
            "success": True,
            "alerts": alerts,
            "total_alerts": len(alerts),
            "timestamp": now.isoformat()
        }
        
    except Exception as e:
        logger.error("Session alerts failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get alerts"
        )

@router.get("/monitoring/metrics", response_model=Dict[str, Any])
async def get_realtime_metrics(
    current_user: Dict[str, Any] = Depends(require_permissions(["admin"])),
    db: AsyncSession = Depends(get_db_session_dependency)
):
    """
    Get real-time session metrics.
    
    Args:
        current_user: Current authenticated user (must be admin)
        db: Database session
        
    Returns:
        Real-time metrics
    """
    try:
        now = datetime.utcnow()
        
        # Get current metrics
        total_sessions = await db.query(SessionORM).count()
        active_sessions = await db.query(SessionORM).filter(SessionORM.status == "active").count()
        
        # Sessions created in last hour
        hour_ago = now - timedelta(hours=1)
        sessions_last_hour = await db.query(SessionORM).filter(
            SessionORM.created_at >= hour_ago
        ).count()
        
        # Sessions closed in last hour
        closed_last_hour = await db.query(SessionORM).filter(
            and_(
                SessionORM.status == "closed",
                SessionORM.ended_at >= hour_ago
            )
        ).count()
        
        # Average session metrics for active sessions
        active_sessions_data = await db.query(SessionORM).filter(
            SessionORM.status == "active"
        ).all()
        
        if active_sessions_data:
            avg_messages = sum(s.message_count for s in active_sessions_data) / len(active_sessions_data)
            avg_tokens = sum(s.token_count for s in active_sessions_data) / len(active_sessions_data)
        else:
            avg_messages = 0
            avg_tokens = 0
        
        # Session status distribution
        status_distribution = {}
        for status in ["active", "closed", "archived", "locked"]:
            count = await db.query(SessionORM).filter(SessionORM.status == status).count()
            status_distribution[status] = count
        
        # Top users by session count
        top_users = await db.query(
            SessionORM.user_id,
            func.count(SessionORM.id).label('session_count'),
            func.sum(SessionORM.message_count).label('total_messages'),
            func.sum(SessionORM.token_count).label('total_tokens')
        ).filter(SessionORM.status == "active").group_by(SessionORM.user_id).order_by(
            desc(func.count(SessionORM.id))
        ).limit(5).all()
        
        metrics = {
            "success": True,
            "timestamp": now.isoformat(),
            "real_time": {
                "total_sessions": total_sessions,
                "active_sessions": active_sessions,
                "sessions_created_last_hour": sessions_last_hour,
                "sessions_closed_last_hour": closed_last_hour,
                "net_session_change": sessions_last_hour - closed_last_hour
            },
            "performance": {
                "avg_messages_per_active_session": round(avg_messages, 2),
                "avg_tokens_per_active_session": round(avg_tokens, 2)
            },
            "distribution": status_distribution,
            "top_users": [
                {
                    "user_id": user.user_id,
                    "active_sessions": user.session_count,
                    "total_messages": int(user.total_messages or 0),
                    "total_tokens": int(user.total_tokens or 0)
                }
                for user in top_users
            ]
        }
        
        return metrics
        
    except Exception as e:
        logger.error("Real-time metrics failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get real-time metrics"
        )

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

async def count_user_sessions(db: AsyncSession, user_id: str, status: Optional[str] = None) -> int:
    """
    Count sessions for a user.
    
    Args:
        db: Database session
        user_id: User ID
        status: Optional status filter
        
    Returns:
        Session count
    """
    query = db.query(SessionORM).filter(SessionORM.user_id == user_id)
    if status:
        query = query.filter(SessionORM.status == status)
    return await query.count()

async def cleanup_inactive_sessions(db: AsyncSession, hours: int = SESSION_EXPIRY_HOURS) -> int:
    """
    Clean up inactive sessions.
    
    Args:
        db: Database session
        hours: Hours of inactivity threshold
        
    Returns:
        Number of sessions cleaned up
    """
    cutoff_time = datetime.utcnow() - timedelta(hours=hours)
    
    result = await db.query(SessionORM).filter(
        and_(
            SessionORM.status == "active",
            SessionORM.last_activity < cutoff_time
        )
    ).update({
        "status": "archived",
        "updated_at": datetime.utcnow()
    })
    
    await db.commit()
    return result

# Export router
__all__ = ["router"]