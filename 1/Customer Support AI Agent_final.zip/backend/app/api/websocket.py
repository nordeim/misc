"""
WebSocket endpoint for real-time chat communication.

Handles WebSocket connections for real-time bidirectional communication
between the frontend and backend with comprehensive security, scalability,
and reliability features.

Features:
- JWT token validation and authentication
- Connection management and heartbeat handling
- Message queuing and delivery guarantees
- Connection pooling and scaling
- Rate limiting and throttling
- DDoS protection and mitigation
- Connection audit logging
- Health monitoring and diagnostics
"""

import asyncio
import json
import logging
import time
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Set, Callable
from collections import defaultdict, deque
from dataclasses import dataclass, field
from contextlib import asynccontextmanager
import structlog

from fastapi import WebSocket, WebSocketDisconnect, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
import aioredis

from app.config import settings
from app.agents.chat_agent import CustomerSupportAgent, AgentContext
from app.dependencies import get_redis_client, get_db_session, get_rate_limit_key, check_rate_limit

logger = structlog.get_logger(__name__)
security = HTTPBearer(auto_error=False)

# ==============================================================================
# DATA MODELS
# ==============================================================================

@dataclass
class ConnectionInfo:
    """Information about a WebSocket connection."""
    websocket: WebSocket
    client_id: str
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    user_role: str = "user"
    permissions: List[str] = field(default_factory=list)
    connection_time: datetime = field(default_factory=datetime.utcnow)
    last_heartbeat: datetime = field(default_factory=datetime.utcnow)
    message_count: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    is_authenticated: bool = False
    rooms: Set[str] = field(default_factory=set)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "client_id": self.client_id,
            "user_id": self.user_id,
            "session_id": self.session_id,
            "user_role": self.user_role,
            "permissions": self.permissions,
            "connection_time": self.connection_time.isoformat(),
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "message_count": self.message_count,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "is_authenticated": self.is_authenticated,
            "rooms": list(self.rooms)
        }

@dataclass
class MessageQueueItem:
    """Item in the message queue."""
    id: str
    target_client_id: str
    message: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    retry_count: int = 0
    max_retries: int = 3
    delivery_guaranteed: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "target_client_id": self.target_client_id,
            "message": self.message,
            "timestamp": self.timestamp.isoformat(),
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "delivery_guaranteed": self.delivery_guaranteed
        }

@dataclass
class RateLimitInfo:
    """Rate limiting information for a client."""
    connection_count: int = 0
    message_count: int = 0
    last_reset: datetime = field(default_factory=datetime.utcnow)
    blocked_until: Optional[datetime] = None

@dataclass
class AuditLogEntry:
    """WebSocket audit log entry."""
    timestamp: datetime = field(default_factory=datetime.utcnow)
    event_type: str = ""
    client_id: str = ""
    user_id: Optional[str] = None
    ip_address: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "event_type": self.event_type,
            "client_id": self.client_id,
            "user_id": self.user_id,
            "ip_address": self.ip_address,
            "details": self.details
        }

class ConnectionManager:
    """Enhanced WebSocket connection manager with comprehensive features."""
    
    def __init__(self):
        self.active_connections: Dict[str, ConnectionInfo] = {}
        self.connection_to_user: Dict[str, str] = {}  # client_id -> user_id
        self.room_members: Dict[str, Set[str]] = defaultdict(set)  # room -> client_ids
        self.message_queue: List[MessageQueueItem] = []
        self.rate_limits: Dict[str, RateLimitInfo] = defaultdict(RateLimitInfo)
        self.audit_logs: deque = deque(maxlen=10000)
        self.max_connections = 1000
        self.max_connections_per_user = 5
        self.max_messages_per_minute = 60
        self.max_message_size = 1024 * 1024  # 1MB
        self.heartbeat_interval = 30  # seconds
        self.message_queue_max_size = 10000
        
        # Lock for thread-safe operations
        self._lock = asyncio.Lock()
        
        # Background tasks
        self._background_tasks: List[asyncio.Task] = []
        self._running = False
    
    async def start(self):
        """Start the connection manager and background tasks."""
        if self._running:
            return
        
        self._running = True
        
        # Start background tasks
        self._background_tasks.extend([
            asyncio.create_task(self._heartbeat_task()),
            asyncio.create_task(self._message_queue_processor()),
            asyncio.create_task(self._cleanup_disconnected()),
            asyncio.create_task(self._rate_limit_cleanup())
        ])
        
        logger.info("Connection manager started")
    
    async def stop(self):
        """Stop the connection manager and background tasks."""
        if not self._running:
            return
        
        self._running = False
        
        # Cancel background tasks
        for task in self._background_tasks:
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self._background_tasks, return_exceptions=True)
        self._background_tasks.clear()
        
        logger.info("Connection manager stopped")
    
    async def connect(self, websocket: WebSocket, client_id: str, connection_info: ConnectionInfo) -> bool:
        """Accept a new WebSocket connection with security checks."""
        async with self._lock:
            # Check connection limits
            if len(self.active_connections) >= self.max_connections:
                logger.warning("Max connections reached", client_id=client_id)
                await websocket.close(code=1013, reason="Server overloaded")
                return False
            
            # Check per-user connection limits
            if connection_info.user_id:
                user_connections = [
                    conn for conn in self.active_connections.values()
                    if conn.user_id == connection_info.user_id
                ]
                if len(user_connections) >= self.max_connections_per_user:
                    logger.warning("Max connections per user reached", 
                                 user_id=connection_info.user_id, client_id=client_id)
                    await websocket.close(code=1008, reason="Too many connections")
                    return False
            
            # Accept connection
            await websocket.accept()
            
            # Store connection info
            self.active_connections[client_id] = connection_info
            
            # Update mappings
            if connection_info.user_id:
                self.connection_to_user[client_id] = connection_info.user_id
            
            # Log connection
            self._log_audit_event("connection_established", client_id, connection_info.user_id, {
                "user_agent": connection_info.user_agent,
                "ip_address": connection_info.ip_address
            })
            
            logger.info(f"Client {client_id} connected via WebSocket", 
                       user_id=connection_info.user_id,
                       ip_address=connection_info.ip_address)
            
            return True
    
    def disconnect(self, client_id: str, reason: str = "Normal closure"):
        """Remove a WebSocket connection and clean up."""
        if client_id not in self.active_connections:
            return
        
        async def _disconnect():
            async with self._lock:
                connection_info = self.active_connections.pop(client_id, None)
                
                if not connection_info:
                    return
                
                # Remove from room memberships
                for room in connection_info.rooms:
                    self.room_members[room].discard(client_id)
                    # Clean up empty rooms
                    if not self.room_members[room]:
                        del self.room_members[room]
                
                # Remove user mapping
                self.connection_to_user.pop(client_id, None)
                
                # Clean up rate limit info
                self.rate_limits.pop(client_id, None)
                
                # Log disconnection
                self._log_audit_event("connection_disconnected", client_id, connection_info.user_id, {
                    "reason": reason,
                    "connection_duration": (datetime.utcnow() - connection_info.connection_time).total_seconds(),
                    "messages_sent": connection_info.message_count,
                    "bytes_sent": connection_info.bytes_sent,
                    "bytes_received": connection_info.bytes_received
                })
                
                logger.info(f"Client {client_id} disconnected", 
                           user_id=connection_info.user_id,
                           reason=reason,
                           duration=(datetime.utcnow() - connection_info.connection_time).total_seconds())
        
        asyncio.create_task(_disconnect())
    
    async def send_message(self, message: Dict[str, Any], client_id: str, queue_if_offline: bool = True) -> bool:
        """Send a message to a specific client with optional queuing."""
        if client_id not in self.active_connections:
            if queue_if_offline:
                await self._queue_message(MessageQueueItem(
                    id=str(uuid.uuid4()),
                    target_client_id=client_id,
                    message=message,
                    delivery_guaranteed=True
                ))
                logger.debug("Message queued for offline client", client_id=client_id)
            return False
        
        connection_info = self.active_connections[client_id]
        websocket = connection_info.websocket
        
        try:
            # Check rate limits
            if not await self._check_rate_limit(client_id):
                logger.warning("Rate limit exceeded, dropping message", client_id=client_id)
                return False
            
            # Serialize message
            message_str = json.dumps(message)
            message_bytes = message_str.encode('utf-8')
            
            # Check message size
            if len(message_bytes) > self.max_message_size:
                logger.warning("Message too large", client_id=client_id, size=len(message_bytes))
                await self.send_error(client_id, "Message too large")
                return False
            
            # Send message
            await websocket.send_text(message_str)
            
            # Update stats
            connection_info.message_count += 1
            connection_info.bytes_sent += len(message_bytes)
            
            # Log message sent
            self._log_audit_event("message_sent", client_id, connection_info.user_id, {
                "message_type": message.get("type"),
                "size": len(message_bytes),
                "queued": False
            })
            
            return True
            
        except Exception as e:
            logger.error(f"Error sending message to {client_id}: {str(e)}")
            self.disconnect(client_id, reason=f"Send error: {str(e)}")
            return False
    
    async def broadcast(self, message: Dict[str, Any], room: Optional[str] = None, exclude_client: Optional[str] = None):
        """Broadcast a message to all connected clients or room members."""
        targets = self.active_connections.keys()
        
        if room:
            targets = self.room_members.get(room, set())
        
        if exclude_client:
            targets = [cid for cid in targets if cid != exclude_client]
        
        # Send to all targets
        send_tasks = [
            self.send_message(message, target_id, queue_if_offline=False)
            for target_id in targets
        ]
        
        results = await asyncio.gather(*send_tasks, return_exceptions=True)
        successful = sum(1 for r in results if r is True)
        
        logger.debug("Broadcast completed", 
                    room=room, 
                    total_targets=len(targets), 
                    successful=successful)
        
        return successful
    
    async def join_room(self, client_id: str, room: str) -> bool:
        """Add client to a room."""
        if client_id not in self.active_connections:
            return False
        
        connection_info = self.active_connections[client_id]
        connection_info.rooms.add(room)
        self.room_members[room].add(client_id)
        
        # Log room join
        self._log_audit_event("room_joined", client_id, connection_info.user_id, {
            "room": room
        })
        
        logger.debug(f"Client {client_id} joined room {room}")
        return True
    
    async def leave_room(self, client_id: str, room: str) -> bool:
        """Remove client from a room."""
        if client_id not in self.active_connections:
            return False
        
        connection_info = self.active_connections[client_id]
        connection_info.rooms.discard(room)
        self.room_members[room].discard(client_id)
        
        # Clean up empty rooms
        if not self.room_members[room]:
            del self.room_members[room]
        
        # Log room leave
        self._log_audit_event("room_left", client_id, connection_info.user_id, {
            "room": room
        })
        
        logger.debug(f"Client {client_id} left room {room}")
        return True
    
    async def send_error(self, client_id: str, error_message: str, error_code: str = "ERROR"):
        """Send an error message to a client."""
        await self.send_message({
            "type": "error",
            "error_code": error_code,
            "message": error_message,
            "timestamp": datetime.utcnow().isoformat()
        }, client_id)
    
    async def update_heartbeat(self, client_id: str):
        """Update heartbeat timestamp for a client."""
        if client_id in self.active_connections:
            self.active_connections[client_id].last_heartbeat = datetime.utcnow()
    
    def get_connection_stats(self) -> Dict[str, Any]:
        """Get connection statistics."""
        total_connections = len(self.active_connections)
        authenticated_connections = sum(1 for conn in self.active_connections.values() if conn.is_authenticated)
        
        return {
            "total_connections": total_connections,
            "authenticated_connections": authenticated_connections,
            "anonymous_connections": total_connections - authenticated_connections,
            "active_rooms": len(self.room_members),
            "queued_messages": len(self.message_queue),
            "connection_details": [conn.to_dict() for conn in self.active_connections.values()]
        }
    
    def _log_audit_event(self, event_type: str, client_id: str, user_id: Optional[str], details: Dict[str, Any]):
        """Log an audit event."""
        if client_id in self.active_connections:
            connection_info = self.active_connections[client_id]
            details["ip_address"] = details.get("ip_address", connection_info.ip_address)
            details["user_agent"] = details.get("user_agent", connection_info.user_agent)
        
        entry = AuditLogEntry(
            event_type=event_type,
            client_id=client_id,
            user_id=user_id,
            details=details
        )
        
        if hasattr(self, '_lock'):  # Only log if lock is available (for serialization)
            self.audit_logs.append(entry)
        
        logger.info(f"WebSocket audit: {event_type}", 
                   audit_entry=entry.to_dict())
    
    async def _queue_message(self, message_item: MessageQueueItem):
        """Queue a message for delivery."""
        async with self._lock:
            if len(self.message_queue) >= self.message_queue_max_size:
                # Remove oldest messages to make room
                self.message_queue = self.message_queue[-self.message_queue_max_size//2:]
            
            self.message_queue.append(message_item)
    
    async def _check_rate_limit(self, client_id: str) -> bool:
        """Check if client is within rate limits."""
        now = datetime.utcnow()
        rate_info = self.rate_limits[client_id]
        
        # Reset counter if a minute has passed
        if (now - rate_info.last_reset).total_seconds() >= 60:
            rate_info.message_count = 0
            rate_info.last_reset = now
            rate_info.blocked_until = None
        
        # Check if blocked
        if rate_info.blocked_until and now < rate_info.blocked_until:
            return False
        
        # Check message count
        if rate_info.message_count >= self.max_messages_per_minute:
            # Block for 5 minutes
            rate_info.blocked_until = now + timedelta(minutes=5)
            logger.warning("Rate limit exceeded, blocking client", client_id=client_id)
            self._log_audit_event("rate_limit_exceeded", client_id, 
                                self.active_connections.get(client_id, {}).get("user_id"),
                                {"blocked_until": rate_info.blocked_until.isoformat()})
            return False
        
        rate_info.message_count += 1
        return True
    
    async def _heartbeat_task(self):
        """Background task to send heartbeats and detect dead connections."""
        while self._running:
            try:
                now = datetime.utcnow()
                dead_connections = []
                
                for client_id, connection_info in self.active_connections.items():
                    time_since_heartbeat = (now - connection_info.last_heartbeat).total_seconds()
                    
                    if time_since_heartbeat > self.heartbeat_interval * 3:  # 3x heartbeat interval
                        dead_connections.append(client_id)
                    elif time_since_heartbeat > self.heartbeat_interval * 2:  # 2x heartbeat interval
                        # Send heartbeat
                        try:
                            await connection_info.websocket.send_text(json.dumps({
                                "type": "heartbeat",
                                "timestamp": now.isoformat()
                            }))
                        except:
                            dead_connections.append(client_id)
                
                # Clean up dead connections
                for client_id in dead_connections:
                    self.disconnect(client_id, reason="Heartbeat timeout")
                
                await asyncio.sleep(self.heartbeat_interval // 2)  # Check every half heartbeat interval
                
            except Exception as e:
                logger.error(f"Error in heartbeat task: {str(e)}")
                await asyncio.sleep(self.heartbeat_interval)
    
    async def _message_queue_processor(self):
        """Background task to process queued messages."""
        while self._running:
            try:
                messages_to_send = []
                
                async with self._lock:
                    # Get messages for connected clients
                    for message_item in list(self.message_queue):
                        if message_item.target_client_id in self.active_connections:
                            messages_to_send.append(message_item)
                            self.message_queue.remove(message_item)
                
                # Send messages
                for message_item in messages_to_send:
                    success = await self.send_message(
                        message_item.message, 
                        message_item.target_client_id, 
                        queue_if_offline=False
                    )
                    
                    # Retry on failure if delivery guaranteed
                    if not success and message_item.delivery_guaranteed:
                        message_item.retry_count += 1
                        if message_item.retry_count < message_item.max_retries:
                            async with self._lock:
                                self.message_queue.append(message_item)
                        else:
                            logger.warning("Max retries reached for queued message", 
                                         message_id=message_item.id,
                                         target_client_id=message_item.target_client_id)
                
                await asyncio.sleep(1)  # Process queue every second
                
            except Exception as e:
                logger.error(f"Error in message queue processor: {str(e)}")
                await asyncio.sleep(5)
    
    async def _cleanup_disconnected(self):
        """Background task to clean up disconnected clients."""
        while self._running:
            try:
                await asyncio.sleep(60)  # Clean up every minute
                
                # This is mostly handled by disconnect() method, 
                # but this provides additional cleanup for edge cases
                
            except Exception as e:
                logger.error(f"Error in cleanup task: {str(e)}")
                await asyncio.sleep(60)
    
    async def _rate_limit_cleanup(self):
        """Background task to clean up old rate limit info."""
        while self._running:
            try:
                await asyncio.sleep(300)  # Clean up every 5 minutes
                
                now = datetime.utcnow()
                expired_clients = []
                
                for client_id, rate_info in list(self.rate_limits.items()):
                    # Remove rate limit info for disconnected clients
                    if client_id not in self.active_connections:
                        expired_clients.append(client_id)
                    # Remove expired block times
                    elif rate_info.blocked_until and now > rate_info.blocked_until:
                        rate_info.blocked_until = None
                        rate_info.message_count = 0
                
                for client_id in expired_clients:
                    self.rate_limits.pop(client_id, None)
                
            except Exception as e:
                logger.error(f"Error in rate limit cleanup: {str(e)}")
                await asyncio.sleep(300)

# ==============================================================================
# AUTHENTICATION AND AUTHORIZATION
# ==============================================================================

class WebSocketAuthenticationError(HTTPException):
    """Custom exception for WebSocket authentication errors."""
    
    def __init__(self, detail: str, code: str = "AUTHENTICATION_FAILED"):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail
        )
        self.code = code

class WebSocketAuthorizationError(HTTPException):
    """Custom exception for WebSocket authorization errors."""
    
    def __init__(self, detail: str, code: str = "AUTHORIZATION_FAILED"):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=detail
        )
        self.code = code

async def authenticate_websocket_token(token: Optional[str]) -> Dict[str, Any]:
    """
    Authenticate WebSocket connection using JWT token.
    
    Args:
        token: JWT token from connection request
        
    Returns:
        Dict[str, Any]: User information
        
    Raises:
        WebSocketAuthenticationError: If authentication fails
    """
    if not token:
        raise WebSocketAuthenticationError("No authentication token provided")
    
    try:
        # Decode JWT token
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        # Check token expiration
        exp = payload.get("exp")
        if exp and datetime.utcnow() > datetime.utcfromtimestamp(exp):
            raise WebSocketAuthenticationError("Token has expired", code="TOKEN_EXPIRED")
        
        # Extract user information
        user_info = {
            "id": payload.get("sub"),
            "email": payload.get("email"),
            "role": payload.get("role", "user"),
            "permissions": payload.get("permissions", []),
            "exp": exp,
            "iat": payload.get("iat"),
            "is_active": payload.get("is_active", True)
        }
        
        # Validate user status
        if not user_info.get("is_active", True):
            raise WebSocketAuthenticationError("User account is inactive", code="USER_INACTIVE")
        
        logger.debug("WebSocket authentication successful", 
                    user_id=user_info["id"],
                    role=user_info["role"])
        
        return user_info
        
    except jwt.ExpiredSignatureError:
        logger.warning("WebSocket token expired")
        raise WebSocketAuthenticationError("Token has expired", code="TOKEN_EXPIRED")
    except jwt.InvalidTokenError as e:
        logger.warning(f"Invalid WebSocket token: {str(e)}")
        raise WebSocketAuthenticationError("Invalid token", code="INVALID_TOKEN")

async def authorize_websocket_action(
    user_info: Dict[str, Any], 
    action: str, 
    resource: Optional[str] = None
) -> bool:
    """
    Authorize WebSocket action for user.
    
    Args:
        user_info: User information from authentication
        action: Action to authorize (chat, admin, broadcast, etc.)
        resource: Resource being accessed
        
    Returns:
        bool: True if authorized
        
    Raises:
        WebSocketAuthorizationError: If authorization fails
    """
    user_role = user_info.get("role", "user")
    user_permissions = user_info.get("permissions", [])
    
    # Define permission requirements for actions
    action_permissions = {
        "chat": ["chat:read", "chat:write"],
        "broadcast": ["chat:broadcast", "admin"],
        "room_manage": ["room:manage", "admin"],
        "admin": ["admin"],
        "system": ["system:admin"]
    }
    
    required_permissions = action_permissions.get(action, [])
    
    # Admin users have all permissions
    if user_role == "admin":
        return True
    
    # Check specific permissions
    if required_permissions:
        has_permission = any(perm in user_permissions for perm in required_permissions)
        if not has_permission:
            logger.warning("WebSocket authorization failed", 
                          user_id=user_info.get("id"),
                          action=action,
                          resource=resource,
                          required_permissions=required_permissions)
            raise WebSocketAuthorizationError(
                f"Insufficient permissions for action: {action}",
                code="INSUFFICIENT_PERMISSIONS"
            )
    
    # Additional role-based checks
    if action == "admin" and user_role != "admin":
        raise WebSocketAuthorizationError("Admin privileges required", code="ADMIN_REQUIRED")
    
    logger.debug("WebSocket authorization successful",
                user_id=user_info.get("id"),
                action=action,
                resource=resource)
    
    return True

def verify_token_from_headers(request_headers: Dict[str, str]) -> Optional[str]:
    """
    Extract and verify JWT token from WebSocket request headers.
    
    Args:
        request_headers: WebSocket request headers
        
    Returns:
        Optional[str]: JWT token if found and valid format
    """
    # Check Authorization header
    auth_header = request_headers.get("authorization") or request_headers.get("Authorization")
    if auth_header:
        if auth_header.startswith("Bearer "):
            return auth_header.replace("Bearer ", "", 1)
    
    # Check X-Token header (alternative)
    token_header = request_headers.get("x-token") or request_headers.get("X-Token")
    if token_header:
        return token_header
    
    return None

# ==============================================================================
# WEBSOCKET UTILITIES AND TESTING
# ==============================================================================

class WebSocketTester:
    """WebSocket testing and debugging utilities."""
    
    def __init__(self, manager: ConnectionManager):
        self.manager = manager
        self.test_connections: Dict[str, Dict[str, Any]] = {}
    
    async def create_test_connection(
        self, 
        client_id: str, 
        user_id: Optional[str] = None,
        authenticated: bool = False,
        rooms: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Create a test WebSocket connection.
        
        Args:
            client_id: Unique client identifier
            user_id: Associated user ID
            authenticated: Whether connection is authenticated
            rooms: List of rooms to join
            
        Returns:
            Dict[str, Any]: Test connection information
        """
        # Create mock WebSocket for testing
        class MockWebSocket:
            def __init__(self):
                self.sent_messages = []
                self.is_closed = False
            
            async def accept(self):
                pass
            
            async def send_text(self, message: str):
                self.sent_messages.append(message)
            
            async def close(self, code: int = 1000, reason: str = ""):
                self.is_closed = True
            
            def get_sent_messages(self) -> List[str]:
                return self.sent_messages.copy()
        
        mock_websocket = MockWebSocket()
        
        # Create connection info
        connection_info = ConnectionInfo(
            websocket=mock_websocket,
            client_id=client_id,
            user_id=user_id,
            is_authenticated=authenticated,
            rooms=set(rooms or [])
        )
        
        # Add to test connections
        self.test_connections[client_id] = {
            "connection_info": connection_info,
            "mock_websocket": mock_websocket,
            "created_at": datetime.utcnow()
        }
        
        logger.info(f"Created test connection {client_id}")
        return self.test_connections[client_id]
    
    async def simulate_message(
        self, 
        client_id: str, 
        message_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Simulate receiving a message from a test connection.
        
        Args:
            client_id: Client identifier
            message_data: Message data to simulate
            
        Returns:
            Dict[str, Any]: Response information
        """
        if client_id not in self.test_connections:
            raise ValueError(f"Test connection {client_id} not found")
        
        # Simulate message processing
        try:
            # Add to connection stats
            connection_info = self.test_connections[client_id]["connection_info"]
            message_str = json.dumps(message_data)
            message_bytes = message_str.encode('utf-8')
            connection_info.bytes_received += len(message_bytes)
            connection_info.message_count += 1
            
            # Simulate response based on message type
            response = await self._handle_test_message(client_id, message_data)
            
            return {
                "success": True,
                "response": response,
                "client_messages": self.test_connections[client_id]["mock_websocket"].get_sent_messages()
            }
            
        except Exception as e:
            logger.error(f"Error simulating message for {client_id}: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "client_messages": self.test_connections[client_id]["mock_websocket"].get_sent_messages()
            }
    
    async def _handle_test_message(self, client_id: str, message_data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle test message based on type."""
        message_type = message_data.get("type")
        
        if message_type == "ping":
            return {"type": "pong", "timestamp": datetime.utcnow().isoformat()}
        elif message_type == "chat_message":
            content = message_data.get("content", "")
            return {
                "type": "chat_response",
                "session_id": message_data.get("session_id"),
                "response": {
                    "content": f"Echo: {content}",
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
        elif message_type == "join_room":
            room = message_data.get("room")
            if room:
                return {
                    "type": "room_joined",
                    "room": room,
                    "timestamp": datetime.utcnow().isoformat()
                }
        elif message_type == "get_stats":
            return self.manager.get_connection_stats()
        
        return {"type": "unknown_message", "original_type": message_type}
    
    def get_test_connection_info(self, client_id: str) -> Optional[Dict[str, Any]]:
        """Get test connection information."""
        return self.test_connections.get(client_id)
    
    def list_test_connections(self) -> List[str]:
        """List all test connection IDs."""
        return list(self.test_connections.keys())
    
    def cleanup_test_connection(self, client_id: str):
        """Remove a test connection."""
        if client_id in self.test_connections:
            del self.test_connections[client_id]
            logger.info(f"Cleaned up test connection {client_id}")
    
    def cleanup_all_connections(self):
        """Remove all test connections."""
        self.test_connections.clear()
        logger.info("Cleaned up all test connections")

class WebSocketDiagnostics:
    """WebSocket connection diagnostics and monitoring."""
    
    def __init__(self, manager: ConnectionManager):
        self.manager = manager
    
    async def get_connection_health(self, client_id: str) -> Dict[str, Any]:
        """
        Get health status for a specific connection.
        
        Args:
            client_id: Client identifier
            
        Returns:
            Dict[str, Any]: Health status information
        """
        if client_id not in self.manager.active_connections:
            return {"status": "not_connected"}
        
        connection_info = self.manager.active_connections[client_id]
        now = datetime.utcnow()
        
        # Calculate health metrics
        time_since_heartbeat = (now - connection_info.last_heartbeat).total_seconds()
        connection_duration = (now - connection_info.connection_time).total_seconds()
        
        health_status = "healthy"
        issues = []
        
        # Check heartbeat freshness
        if time_since_heartbeat > self.manager.heartbeat_interval * 2:
            health_status = "warning"
            issues.append("Stale heartbeat")
        elif time_since_heartbeat > self.manager.heartbeat_interval * 3:
            health_status = "critical"
            issues.append("Heartbeat timeout")
        
        # Check message activity
        if connection_info.message_count == 0 and connection_duration > 300:  # 5 minutes
            issues.append("No message activity")
        
        # Check data transfer
        total_bytes = connection_info.bytes_sent + connection_info.bytes_received
        if total_bytes > 100 * 1024 * 1024:  # 100MB
            issues.append("High data transfer")
        
        return {
            "client_id": client_id,
            "status": health_status,
            "issues": issues,
            "metrics": {
                "connection_duration_seconds": round(connection_duration, 2),
                "time_since_heartbeat_seconds": round(time_since_heartbeat, 2),
                "message_count": connection_info.message_count,
                "bytes_sent": connection_info.bytes_sent,
                "bytes_received": connection_info.bytes_received,
                "total_bytes": total_bytes,
                "rooms_count": len(connection_info.rooms),
                "is_authenticated": connection_info.is_authenticated
            },
            "last_updated": now.isoformat()
        }
    
    async def get_system_health(self) -> Dict[str, Any]:
        """
        Get overall system health status.
        
        Returns:
            Dict[str, Any]: System health information
        """
        stats = self.manager.get_connection_stats()
        now = datetime.utcnow()
        
        # Calculate health metrics
        total_connections = stats["total_connections"]
        authenticated_ratio = (
            stats["authenticated_connections"] / max(total_connections, 1)
        )
        
        health_status = "healthy"
        issues = []
        
        # Check connection limits
        if total_connections >= self.manager.max_connections * 0.9:
            health_status = "warning"
            issues.append("Near connection limit")
        elif total_connections >= self.manager.max_connections:
            health_status = "critical"
            issues.append("Connection limit reached")
        
        # Check authentication ratio
        if authenticated_ratio < 0.5 and total_connections > 10:
            issues.append("Low authentication ratio")
        
        # Check message queue
        if stats["queued_messages"] > 1000:
            issues.append("Large message queue")
        
        return {
            "status": health_status,
            "issues": issues,
            "metrics": {
                "total_connections": total_connections,
                "connection_utilization": total_connections / self.manager.max_connections,
                "authenticated_ratio": round(authenticated_ratio, 3),
                "active_rooms": stats["active_rooms"],
                "queued_messages": stats["queued_messages"],
                "connection_details_count": len(stats["connection_details"])
            },
            "limits": {
                "max_connections": self.manager.max_connections,
                "max_connections_per_user": self.manager.max_connections_per_user,
                "max_messages_per_minute": self.manager.max_messages_per_minute,
                "max_message_size_bytes": self.manager.max_message_size,
                "heartbeat_interval_seconds": self.manager.heartbeat_interval
            },
            "last_updated": now.isoformat()
        }
    
    async def analyze_connection_patterns(self) -> Dict[str, Any]:
        """
        Analyze connection patterns for insights.
        
        Returns:
            Dict[str, Any]: Pattern analysis results
        """
        connections = list(self.manager.active_connections.values())
        if not connections:
            return {"message": "No active connections to analyze"}
        
        now = datetime.utcnow()
        
        # Analyze patterns
        analysis = {
            "total_connections": len(connections),
            "authenticated_vs_anonymous": {
                "authenticated": sum(1 for c in connections if c.is_authenticated),
                "anonymous": sum(1 for c in connections if not c.is_authenticated)
            },
            "roles_distribution": {},
            "rooms_analysis": {
                "total_rooms": len(self.manager.room_members),
                "room_sizes": [len(members) for members in self.manager.room_members.values()],
                "popular_rooms": sorted(
                    [(room, len(members)) for room, members in self.manager.room_members.items()],
                    key=lambda x: x[1], reverse=True
                )[:10]  # Top 10
            },
            "activity_analysis": {
                "high_activity_connections": sum(1 for c in connections if c.message_count > 100),
                "low_activity_connections": sum(1 for c in connections if c.message_count == 0),
                "average_messages_per_connection": sum(c.message_count for c in connections) / len(connections)
            },
            "connection_age_analysis": {
                "new_connections": sum(1 for c in connections if (now - c.connection_time).total_seconds() < 300),  # < 5 min
                "old_connections": sum(1 for c in connections if (now - c.connection_time).total_seconds() > 3600),  # > 1 hour
                "average_connection_duration": sum((now - c.connection_time).total_seconds() for c in connections) / len(connections)
            }
        }
        
        # Role distribution
        role_counts = {}
        for connection in connections:
            role = connection.user_role
            role_counts[role] = role_counts.get(role, 0) + 1
        analysis["roles_distribution"] = role_counts
        
        return analysis

# Global instances
manager = ConnectionManager()
tester = WebSocketTester(manager)
diagnostics = WebSocketDiagnostics(manager)

# Initialize the agent
agent = CustomerSupportAgent()

# ==============================================================================
# MAIN WEBSOCKET ENDPOINT
# ==============================================================================

async def websocket_endpoint(websocket: WebSocket):
"""
Enhanced WebSocket endpoint for real-time chat with comprehensive features.

This endpoint handles:
- JWT token authentication and authorization
- Real-time message sending and receiving
- Connection management with heartbeat
- Room and channel management
- Rate limiting and security
- Agent processing through WebSocket
- Message queuing and delivery guarantees
"""
client_id = None
connection_info = None

try:
# Get client information from headers
headers = dict(websocket.headers)
client_ip = headers.get('x-forwarded-for', '').split(',')[0].strip() or websocket.client.host
user_agent = headers.get('user-agent', '')

# Extract and authenticate token
token = verify_token_from_headers(headers)
user_info = None
is_authenticated = False

if token:
try:
user_info = await authenticate_websocket_token(token)
is_authenticated = True
except WebSocketAuthenticationError as e:
logger.warning(f\"WebSocket authentication failed: {e.detail}\")
await websocket.close(code=1008, reason=f\"Authentication failed: {e.code}\")
return

# Wait for client to send connection info
connection_data = await websocket.receive_text()
data = json.loads(connection_data)
client_id = data.get(\"client_id\", f\"anon_{uuid.uuid4().hex[:8]}\")
session_id = data.get(\"session_id\", client_id)

# Authorize connection if authenticated
if is_authenticated and user_info:
await authorize_websocket_action(user_info, \"chat\")

# Create connection info
connection_info = ConnectionInfo(
websocket=websocket,
client_id=client_id,
user_id=user_info[\"id\"] if user_info else None,
session_id=session_id,
user_role=user_info[\"role\"] if user_info else \"anonymous\",
permissions=user_info[\"permissions\"] if user_info else [],
ip_address=client_ip,
user_agent=user_agent,
is_authenticated=is_authenticated
)

# Start connection manager if not running
if not manager._running:
await manager.start()

# Connect with security checks
connected = await manager.connect(websocket, client_id, connection_info)
if not connected:
return

# Join initial rooms if specified
initial_rooms = data.get(\"rooms\", [])
for room in initial_rooms:
await manager.join_room(client_id, room)

# Send connection confirmation
await manager.send_message({
\"type\": \"connection\",
\"status\": \"connected\",
\"client_id\": client_id,
\"user_id\": connection_info.user_id,
\"is_authenticated\": is_authenticated,
\"rooms\": list(connection_info.rooms),
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)

# Main WebSocket loop
while True:
try:
# Set timeout for receiving messages
message_data = await asyncio.wait_for(
websocket.receive_text(), 
timeout=60.0  # 60 second timeout
)

data = json.loads(message_data)

# Update stats
connection_info.message_count += 1
connection_info.bytes_received += len(message_data.encode('utf-8'))

# Update heartbeat
await manager.update_heartbeat(client_id)

message_type = data.get(\"type\")

if message_type == \"chat_message\":
await handle_chat_message(websocket, client_id, data, user_info)
elif message_type == \"ping\":
await manager.send_message({
\"type\": \"pong\",
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
elif message_type == \"heartbeat\":
await manager.send_message({
\"type\": \"heartbeat_ack\",
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
elif message_type == \"typing_indicator\":
# Handle typing indicators
await manager.broadcast({
\"type\": \"typing_indicator\",
\"client_id\": client_id,
\"is_typing\": data.get(\"is_typing\", False),
\"session_id\": data.get(\"session_id\")
}, exclude_client=client_id)
elif message_type == \"join_room\":
room = data.get(\"room\")
if room:
# Authorize room access
if is_authenticated and user_info:
await authorize_websocket_action(user_info, \"room_manage\", room)

success = await manager.join_room(client_id, room)
if success:
await manager.send_message({
\"type\": \"room_joined\",
\"room\": room,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
else:
await manager.send_error(client_id, \"Failed to join room\")
elif message_type == \"leave_room\":
room = data.get(\"room\")
if room:
success = await manager.leave_room(client_id, room)
if success:
await manager.send_message({
\"type\": \"room_left\",
\"room\": room,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
else:
await manager.send_error(client_id, \"Failed to leave room\")
elif message_type == \"broadcast\":
# Handle broadcast requests
if is_authenticated and user_info:
await authorize_websocket_action(user_info, \"broadcast\")

room = data.get(\"room\")
message_content = data.get(\"message\")

if message_content:
broadcast_message = {
\"type\": \"broadcast\",
\"from_client_id\": client_id,
\"from_user_id\": connection_info.user_id,
\"message\": message_content,
\"timestamp\": datetime.utcnow().isoformat()
}

success_count = await manager.broadcast(broadcast_message, room=room)
await manager.send_message({
\"type\": \"broadcast_result\",
\"success_count\": success_count,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
else:
await manager.send_error(client_id, \"Broadcast requires authentication\")
elif message_type == \"get_stats\":
# Handle stats requests
if is_authenticated and user_info and user_info[\"role\"] == \"admin\":
stats = manager.get_connection_stats()
await manager.send_message({
\"type\": \"stats\",
\"stats\": stats,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
else:
await manager.send_error(client_id, \"Admin access required for stats\", \"ADMIN_REQUIRED\")
elif message_type == \"admin_action\":
# Handle admin actions
if is_authenticated and user_info and user_info[\"role\"] == \"admin\":
await handle_admin_action(client_id, data, user_info)
else:
await manager.send_error(client_id, \"Admin access required\", \"ADMIN_REQUIRED\")
else:
logger.warning(f\"Unknown message type: {message_type}\", client_id=client_id)
await manager.send_error(client_id, f\"Unknown message type: {message_type}\")

except asyncio.TimeoutError:
# Handle timeout - send ping to check if connection is alive
try:
await manager.send_message({
\"type\": \"ping\",
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
except:
# Connection is dead
break
except json.JSONDecodeError:
await manager.send_error(client_id, \"Invalid JSON message\", \"INVALID_JSON\")
except Exception as e:
logger.error(f\"Error processing message for client {client_id}: {str(e)}\")
await manager.send_error(client_id, \"Internal server error\", \"INTERNAL_ERROR\")

except WebSocketDisconnect:
logger.info(f\"WebSocket disconnected for client {client_id}\")
if client_id:
manager.disconnect(client_id, \"Client disconnected\")
except Exception as e:
logger.error(f\"WebSocket error for client {client_id}: {str(e)}\")
if client_id:
manager.disconnect(client_id, f\"Server error: {str(e)}\")
finally:
# Cleanup
if connection_info:
# Connection info will be cleaned up by disconnect()
pass"

async def handle_chat_message(
    websocket: WebSocket, 
    client_id: str, 
    data: Dict[str, Any],
    user_info: Optional[Dict[str, Any]] = None
):
    """
    Handle a chat message through WebSocket with enhanced features.
    
    Args:
        websocket: The WebSocket connection
        client_id: Client identifier
        data: Message data containing content and session info
        user_info: Optional user information for authorization
    """
    try:
        message_content = data.get("content", "")
        session_id = data.get("session_id", client_id)
        file_attachments = data.get("attachments", [])
        room = data.get("room")
        
        # Validate message content
        if not message_content or not message_content.strip():
            await manager.send_error(client_id, "Message content cannot be empty", "EMPTY_MESSAGE")
            return
        
        # Check message length
        if len(message_content) > 10000:  # 10KB limit
            await manager.send_error(client_id, "Message too long (max 10KB)", "MESSAGE_TOO_LONG")
            return
        
        # Authorize chat message if user info is available
        if user_info:
            await authorize_websocket_action(user_info, "chat", room)
        
        # Send typing indicator
        await manager.send_message({
            "type": "typing_indicator",
            "client_id": "agent",
            "is_typing": True,
            "session_id": session_id
        }, client_id)
        
        # Create agent context with enhanced information
        context = AgentContext(
            session_id=session_id,
            user_id=user_info["id"] if user_info else client_id,
            message_history=[],  # Would load from database
            current_file_attachments=file_attachments
        )
        
        # Add user context to agent context if available
        if user_info:
            context.user_context = {
                "role": user_info.get("role", "user"),
                "permissions": user_info.get("permissions", []),
                "email": user_info.get("email"),
                "is_authenticated": True
            }
        
        # Process message with agent
        start_time = time.time()
        response = await agent.process_message(message_content, context)
        processing_time = time.time() - start_time
        
        # Stop typing indicator
        await manager.send_message({
            "type": "typing_indicator",
            "client_id": "agent",
            "is_typing": False,
            "session_id": session_id
        }, client_id)
        
        # Prepare response with enhanced information
        chat_response = {
            "type": "chat_response",
            "session_id": session_id,
            "request_id": str(uuid.uuid4()),
            "response": {
                "content": response.content,
                "attachments_processed": response.attachments_processed,
                "escalation_triggered": response.escalation_triggered,
                "sources": response.sources,
                "confidence_score": response.confidence_score,
                "processing_time": round(processing_time, 3),
                "timestamp": datetime.utcnow().isoformat()
            },
            "user_context": {
                "is_authenticated": user_info is not None,
                "user_id": user_info.get("id") if user_info else None,
                "client_id": client_id
            }
        }
        
        # Send response back to client
        success = await manager.send_message(chat_response, client_id)
        
        if not success:
            logger.warning(f"Failed to send chat response to client {client_id}")
        
        # Log chat interaction
        manager._log_audit_event(
            "chat_message_processed",
            client_id,
            user_info.get("id") if user_info else None,
            {
                "session_id": session_id,
                "room": room,
                "message_length": len(message_content),
                "processing_time": processing_time,
                "response_length": len(response.content) if response.content else 0,
                "has_attachments": len(file_attachments) > 0,
                "escalation_triggered": response.escalation_triggered
            }
        )
        
    except WebSocketAuthorizationError as e:
        await manager.send_error(client_id, e.detail, e.code)
except Exception as e:
logger.error(f\"Error handling chat message for client {client_id}: {str(e)}\")
# Send error response
await manager.send_message({
\"type\": \"error\",
\"error_code\": \"PROCESSING_ERROR\",
\"message\": \"Failed to process message. Please try again.\",
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)

async def handle_admin_action(
client_id: str, 
data: Dict[str, Any], 
user_info: Dict[str, Any]
):
"""
Handle admin actions through WebSocket.

Args:
client_id: Client identifier
data: Action data
user_info: Admin user information
"""
try:
action = data.get(\"action\")
target_client_id = data.get(\"target_client_id\")

if action == \"disconnect_client\":
# Disconnect a specific client
if target_client_id and target_client_id in manager.active_connections:
manager.disconnect(target_client_id, \"Disconnected by admin\")
await manager.send_message({
\"type\": \"admin_action_result\",
\"action\": \"disconnect_client\",
\"target_client_id\": target_client_id,
\"success\": True,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
logger.info(f\"Admin {user_info['id']} disconnected client {target_client_id}\")
else:
await manager.send_error(client_id, \"Target client not found\", \"CLIENT_NOT_FOUND\")

elif action == \"get_connection_stats\":
# Get detailed connection statistics
stats = manager.get_connection_stats()
await manager.send_message({
\"type\": \"admin_action_result\",
\"action\": \"get_connection_stats\",
\"stats\": stats,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)

elif action == \"get_diagnostics\":
# Get system diagnostics
if target_client_id:
# Get diagnostics for specific client
health = await diagnostics.get_connection_health(target_client_id)
else:
# Get system health
health = await diagnostics.get_system_health()

await manager.send_message({
\"type\": \"admin_action_result\",
\"action\": \"get_diagnostics\",
\"health\": health,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)

elif action == \"broadcast_system_message\":
# Send system broadcast
message_content = data.get(\"message\", \"\")
if message_content:
broadcast_msg = {
\"type\": \"system_broadcast\",
\"message\": message_content,
\"from_admin\": user_info[\"id\"],
\"timestamp\": datetime.utcnow().isoformat()
}

success_count = await manager.broadcast(broadcast_msg)
await manager.send_message({
\"type\": \"admin_action_result\",
\"action\": \"broadcast_system_message\",
\"success_count\": success_count,
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)
else:
await manager.send_error(client_id, \"Message content required\", \"INVALID_MESSAGE\")

elif action == \"get_audit_logs\":
# Get recent audit logs
log_count = data.get(\"count\", 100)
logs = list(manager.audit_logs)[-log_count:] if manager.audit_logs else []

await manager.send_message({
\"type\": \"admin_action_result\",
\"action\": \"get_audit_logs\",
\"logs\": [log.to_dict() for log in logs],
\"count\": len(logs),
\"timestamp\": datetime.utcnow().isoformat()
}, client_id)

else:
await manager.send_error(client_id, f\"Unknown admin action: {action}\", \"UNKNOWN_ACTION\")

except Exception as e:
logger.error(f\"Error handling admin action for client {client_id}: {str(e)}\")
await manager.send_error(client_id, \"Failed to execute admin action\", \"ADMIN_ACTION_ERROR\")

# ==============================================================================
# WEBSOCKET MANAGEMENT AND LIFECYCLE
# ==============================================================================

class WebSocketManager:
"""WebSocket manager for application lifecycle management."""

def __init__(self):
self.connection_manager = manager
self.tester = tester
self.diagnostics = diagnostics
self._initialized = False

async def initialize(self):
"""Initialize the WebSocket system."""
if self._initialized:
return

try:
# Start the connection manager
await self.connection_manager.start()

self._initialized = True
logger.info(\"WebSocket system initialized\")

except Exception as e:
logger.error(f\"Failed to initialize WebSocket system: {str(e)}\")
raise

async def shutdown(self):
"""Shutdown the WebSocket system."""
if not self._initialized:
return

try:
# Stop the connection manager
await self.connection_manager.stop()

# Cleanup test connections
self.tester.cleanup_all_connections()

self._initialized = False
logger.info(\"WebSocket system shutdown complete\")

except Exception as e:
logger.error(f\"Error during WebSocket system shutdown: {str(e)}\")

async def health_check(self) -> Dict[str, Any]:
"""
Perform WebSocket system health check.

Returns:
Dict[str, Any]: Health check results
"""
try:
system_health = await self.diagnostics.get_system_health()
connection_stats = self.connection_manager.get_connection_stats()

# Determine overall health
overall_status = \"healthy\"
if system_health[\"status\"] in [\"warning\", \"critical\"]:
overall_status = system_health[\"status\"]

return {
\"status\": overall_status,
\"websocket_manager\": {
\"initialized\": self._initialized,
\"running\": self.connection_manager._running
},
\"system_health\": system_health,
\"connection_stats\": connection_stats,
\"last_check\": datetime.utcnow().isoformat()
}

except Exception as e:
logger.error(f\"Error during WebSocket health check: {str(e)}\")
return {
\"status\": \"unhealthy\",
\"error\": str(e),
\"last_check\": datetime.utcnow().isoformat()
}

# Global WebSocket manager instance
websocket_manager = WebSocketManager()

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

async def get_websocket_stats() -> Dict[str, Any]:
"""
Get WebSocket system statistics.

Returns:
Dict[str, Any]: System statistics
"""
return {
\"connection_stats\": manager.get_connection_stats(),
\"system_health\": await diagnostics.get_system_health(),
\"test_connections\": {
\"count\": len(tester.test_connections),
\"connection_ids\": tester.list_test_connections()
},
\"manager_status\": {
\"initialized\": websocket_manager._initialized,
\"running\": manager._running,
\"background_tasks\": len(manager._background_tasks)
}
}

async def validate_websocket_message(message: Dict[str, Any]) -> tuple[bool, str]:
"""
Validate WebSocket message format and content.

Args:
message: Message to validate

Returns:
tuple[bool, str]: (is_valid, error_message)
"""
# Check if message is a dictionary
if not isinstance(message, dict):
return False, \"Message must be a JSON object\"

# Check for required fields
if \"type\" not in message:
return False, \"Message must contain 'type' field\"

message_type = message[\"type\"]

# Validate specific message types
if message_type == \"chat_message\":
if \"content\" not in message:
return False, \"Chat message must contain 'content' field\"
if not isinstance(message[\"content\"], str):
return False, \"Chat message content must be a string\"

elif message_type == \"join_room\":
if \"room\" not in message:
return False, \"Join room message must contain 'room' field\"

elif message_type == \"broadcast\":
if \"message\" not in message:
return False, \"Broadcast message must contain 'message' field\"

elif message_type == \"admin_action\":
if \"action\" not in message:
return False, \"Admin action must contain 'action' field\"

# Check for malicious content (basic validation)
dangerous_patterns = [\"../\", \"javascript:\", \"data:\", \"vbscript:\"]
message_str = json.dumps(message)
for pattern in dangerous_patterns:
if pattern in message_str:
return False, f\"Message contains dangerous content: {pattern}\"

return True, \"\"

# Export public interface
__all__ = [
# Core classes
\"ConnectionManager\",
\"ConnectionInfo\",
\"MessageQueueItem\",
\"RateLimitInfo\",
\"AuditLogEntry\",

# Authentication
\"WebSocketAuthenticationError\",
\"WebSocketAuthorizationError\",
\"authenticate_websocket_token\",
\"authorize_websocket_action\",
\"verify_token_from_headers\",

# Utilities
\"WebSocketTester\",
\"WebSocketDiagnostics\",
\"WebSocketManager\",

# Main endpoint and utilities
\"websocket_endpoint\",
\"handle_chat_message\",
\"handle_admin_action\",

# Global instances
\"manager\",
\"tester\",
\"diagnostics\",
\"websocket_manager\",

# Utility functions
\"get_websocket_stats\",
\"validate_websocket_message\"
]"