"""
Password Security Utilities.

This module provides secure password handling including:
- Password hashing using bcrypt
- Password strength validation
- Password complexity requirements
- Secure password generation
"""

import re
import secrets
import string
from typing import Dict, List, Tuple
from passlib.context import CryptContext
from passlib.hash import bcrypt
import logging

logger = logging.getLogger(__name__)

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class PasswordStrength:
    """Password strength levels."""
    
    WEAK = "weak"
    MEDIUM = "medium" 
    STRONG = "strong"
    VERY_STRONG = "very_strong"


class PasswordRequirements:
    """Password complexity requirements."""
    
    def __init__(
        self,
        min_length: int = 8,
        max_length: int = 128,
        require_uppercase: bool = True,
        require_lowercase: bool = True,
        require_digits: bool = True,
        require_special: bool = True,
        min_uppercase: int = 1,
        min_lowercase: int = 1,
        min_digits: int = 1,
        min_special: int = 1,
        max_repeated_chars: int = 3,
        forbid_common_passwords: bool = True,
        forbid_username_in_password: bool = True,
        forbid_email_in_password: bool = True
    ):
        self.min_length = min_length
        self.max_length = max_length
        self.require_uppercase = require_uppercase
        self.require_lowercase = require_lowercase
        self.require_digits = require_digits
        self.require_special = require_special
        self.min_uppercase = min_uppercase
        self.min_lowercase = min_lowercase
        self.min_digits = min_digits
        self.min_special = min_special
        self.max_repeated_chars = max_repeated_chars
        self.forbid_common_passwords = forbid_common_passwords
        self.forbid_username_in_password = forbid_username_in_password
        self.forbid_email_in_password = forbid_email_in_password


# Default password requirements
DEFAULT_REQUIREMENTS = PasswordRequirements()


# Common weak passwords (expand as needed)
COMMON_PASSWORDS = {
    "password", "123456", "123456789", "qwerty", "abc123", "password123",
    "admin", "letmein", "welcome", "monkey", "1234567890", "dragon",
    "master", "hello", "login", "football", "princess", "solo", "starwars",
    "1q2w3e4r", "sunshine", "flower", "hottie", "loveme", "zaq12wsx",
    "ashley", "nicole", "daniel", "buster", "soccer", "hannah", "george",
    "taylor", "charlie", "michelle", "jordan", "jessica", "pepper", "andrew",
    "jennifer", "james", "matthew", "ginger", "justin", "internet",
    "shadow", "killer", "test", "pass", "god", "whatever", "freedom",
    "qazwsx", "pokemon", "secret", "baseball", "trustno1", "123qwe",
    "qwertyuiop", "asdfghjkl", "zxcvbnm", "iloveyou", "admin123", "root123",
    "password1", "111111", "123123", "000000", "1234567", "888888",
    "superman", "harley", "batman", "1234", "welcome123", "temp123",
    "changeme", "default", "12345678", "qwerty123", "passw0rd", "letmein123"
}


def get_password_hash(password: str) -> str:
    """
    Hash a password using bcrypt.
    
    Args:
        password: Plain text password
    
    Returns:
        Hashed password string
    
    Raises:
        ValueError: If password is empty or invalid
    """
    if not password:
        raise ValueError("Password cannot be empty")
    
    if len(password) > 512:  # Prevent DoS attacks
        raise ValueError("Password too long")
    
    try:
        # Use bcrypt with appropriate cost factor
        hashed = pwd_context.hash(password)
        logger.debug("Password hashed successfully")
        return hashed
    except Exception as e:
        logger.error(f"Password hashing failed: {e}")
        raise ValueError("Password hashing failed")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a password against its hash.
    
    Args:
        plain_password: Plain text password
        hashed_password: Hashed password
    
    Returns:
        True if password matches, False otherwise
    """
    if not plain_password or not hashed_password:
        return False
    
    try:
        result = pwd_context.verify(plain_password, hashed_password)
        return result
    except Exception as e:
        logger.warning(f"Password verification error: {e}")
        return False


def validate_password_strength(
    password: str,
    username: str = "",
    email: str = "",
    requirements: PasswordRequirements = DEFAULT_REQUIREMENTS
) -> Tuple[bool, List[str]]:
    """
    Validate password strength against requirements.
    
    Args:
        password: Password to validate
        username: Username to check against password
        email: Email to check against password
        requirements: Password requirements
    
    Returns:
        Tuple of (is_valid, list_of_errors)
    """
    errors = []
    
    if not password:
        errors.append("Password cannot be empty")
        return False, errors
    
    # Check length requirements
    if len(password) < requirements.min_length:
        errors.append(f"Password must be at least {requirements.min_length} characters long")
    elif len(password) > requirements.max_length:
        errors.append(f"Password must be no more than {requirements.max_length} characters long")
    
    # Check character requirements
    uppercase_count = sum(1 for c in password if c.isupper())
    lowercase_count = sum(1 for c in password if c.islower())
    digit_count = sum(1 for c in password if c.isdigit())
    special_count = sum(1 for c in password if not c.isalnum())
    
    if requirements.require_uppercase:
        if uppercase_count < requirements.min_uppercase:
            errors.append(f"Password must contain at least {requirements.min_uppercase} uppercase letter(s)")
    
    if requirements.require_lowercase:
        if lowercase_count < requirements.min_lowercase:
            errors.append(f"Password must contain at least {requirements.min_lowercase} lowercase letter(s)")
    
    if requirements.require_digits:
        if digit_count < requirements.min_digits:
            errors.append(f"Password must contain at least {requirements.min_digits} digit(s)")
    
    if requirements.require_special:
        if special_count < requirements.min_special:
            errors.append(f"Password must contain at least {requirements.min_special} special character(s)")
    
    # Check for repeated characters
    if requirements.max_repeated_chars > 0:
        max_repeated = max(len(list(g)) for k, g in __import__('itertools').groupby(password))
        if max_repeated > requirements.max_repeated_chars:
            errors.append(f"Password cannot contain more than {requirements.max_repeated_chars} repeated characters in a row")
    
    # Check against common passwords
    if requirements.forbid_common_passwords and password.lower() in COMMON_PASSWORDS:
        errors.append("Password is too common, please choose a stronger password")
    
    # Check against username
    if requirements.forbid_username_in_password and username:
        if username.lower() in password.lower():
            errors.append("Password cannot contain your username")
    
    # Check against email
    if requirements.forbid_email_in_password and email:
        email_parts = email.split('@')[0].split('.')
        for part in email_parts:
            if part and part.lower() in password.lower():
                errors.append("Password cannot contain parts of your email address")
                break
    
    # Check for sequential patterns
    if __has_sequential_pattern(password):
        errors.append("Password cannot contain sequential patterns (e.g., abc, 123)")
    
    # Check for keyboard patterns
    if __has_keyboard_pattern(password):
        errors.append("Password cannot contain keyboard patterns (e.g., qwerty)")
    
    return len(errors) == 0, errors


def assess_password_strength(password: str) -> Tuple[str, int]:
    """
    Assess password strength and return level and score.
    
    Args:
        password: Password to assess
    
    Returns:
        Tuple of (strength_level, score)
    """
    if not password:
        return PasswordStrength.WEAK, 0
    
    score = 0
    
    # Length scoring
    length = len(password)
    if length >= 12:
        score += 25
    elif length >= 8:
        score += 15
    else:
        score += 5
    
    # Character variety scoring
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(not c.isalnum() for c in password)
    
    variety_count = sum([has_upper, has_lower, has_digit, has_special])
    score += variety_count * 10
    
    # Uncommon character bonus
    unique_chars = set(password.lower())
    score += min(len(unique_chars) * 2, 20)
    
    # Penalties
    if password.lower() in COMMON_PASSWORDS:
        score = max(score - 50, 0)
    
    if __has_sequential_pattern(password):
        score = max(score - 20, 0)
    
    if __has_keyboard_pattern(password):
        score = max(score - 20, 0)
    
    # Determine strength level
    if score >= 80:
        return PasswordStrength.VERY_STRONG, score
    elif score >= 60:
        return PasswordStrength.STRONG, score
    elif score >= 40:
        return PasswordStrength.MEDIUM, score
    else:
        return PasswordStrength.WEAK, score


def generate_secure_password(
    length: int = 16,
    include_symbols: bool = True,
    exclude_ambiguous: bool = True,
    exclude_similar: bool = True
) -> str:
    """
    Generate a cryptographically secure random password.
    
    Args:
        length: Password length
        include_symbols: Include special characters
        exclude_ambiguous: Exclude ambiguous characters (0, O, 1, l, I)
        exclude_similar: Exclude similar looking characters
    
    Returns:
        Generated password string
    """
    if length < 8:
        length = 8
    elif length > 128:
        length = 128
    
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    # Remove ambiguous characters if requested
    if exclude_ambiguous:
        lowercase = lowercase.replace('l', '')
        uppercase = uppercase.replace('I', '')
        digits = digits.replace('0', '').replace('1', '')
    
    # Remove similar characters if requested
    if exclude_similar:
        lowercase = lowercase.replace('o', '')
        digits = digits.replace('o', '')
    
    # Build character set
    chars = lowercase + uppercase + digits
    if include_symbols:
        chars += symbols
    
    # Generate password ensuring at least one character from each set
    password = []
    
    # Ensure lowercase
    password.append(secrets.choice(lowercase))
    
    # Ensure uppercase
    password.append(secrets.choice(uppercase))
    
    # Ensure digit
    password.append(secrets.choice(digits))
    
    if include_symbols:
        password.append(secrets.choice(symbols))
    
    # Fill remaining length
    for _ in range(length - len(password)):
        password.append(secrets.choice(chars))
    
    # Shuffle to randomize positions
    secrets.SystemRandom().shuffle(password)
    
    return ''.join(password)


def __has_sequential_pattern(password: str) -> bool:
    """Check for sequential character patterns."""
    patterns = [
        "abcdefghijklmnopqrstuvwxyz",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "0123456789",
        "zyxwvutsrqponmlkjihgfedcba",
        "ZYXWVUTSRQPONMLKJIHGFEDCBA",
        "9876543210"
    ]
    
    password_lower = password.lower()
    for pattern in patterns:
        for i in range(len(pattern) - 2):
            seq = pattern[i:i+3]
            if seq in password_lower:
                return True
    
    return False


def __has_keyboard_pattern(password: str) -> bool:
    """Check for common keyboard patterns."""
    keyboard_patterns = [
        "qwerty", "asdf", "zxcv", "1234", "qaz", "wsx", "edc", "rfv",
        "tgb", "yhn", "ujm", "ik", "ol", "p", "12345", "123456",
        "1q2w3e", "qazwsx", "1qaz2wsx", "q1w2e3r4", "qaz1wsx2"
    ]
    
    password_lower = password.lower()
    for pattern in keyboard_patterns:
        if pattern in password_lower:
            return True
    
    return False


def check_password_history(new_password: str, old_passwords: List[str]) -> bool:
    """
    Check if password matches any in history (prevents reuse).
    
    Args:
        new_password: New password to check
        old_passwords: List of old password hashes
    
    Returns:
        True if password is not in history, False if found
    """
    for old_password_hash in old_passwords:
        if verify_password(new_password, old_password_hash):
            return False
    
    return True


def get_password_entropy(password: str) -> float:
    """
    Calculate password entropy in bits.
    
    Args:
        password: Password to analyze
    
    Returns:
        Entropy value in bits
    """
    if not password:
        return 0.0
    
    # Count character sets
    has_lowercase = bool(re.search(r'[a-z]', password))
    has_uppercase = bool(re.search(r'[A-Z]', password))
    has_digits = bool(re.search(r'[0-9]', password))
    has_special = bool(re.search(r'[^a-zA-Z0-9]', password))
    
    # Calculate character pool size
    pool_size = 0
    if has_lowercase:
        pool_size += 26
    if has_uppercase:
        pool_size += 26
    if has_digits:
        pool_size += 10
    if has_special:
        pool_size += 33  # Approximate count of special characters
    
    if pool_size == 0:
        return 0.0
    
    # Calculate entropy: length * log2(pool_size)
    entropy = len(password) * (pool_size.bit_length() - 1)
    
    return entropy


def is_password_compromised(password: str) -> bool:
    """
    Check if password appears in common breach databases (mock implementation).
    
    Args:
        password: Password to check
    
    Returns:
        True if password appears in breach databases
    """
    # This is a simplified implementation
    # In production, use services like HaveIBeenPwned API
    
    # Check against common passwords
    if password.lower() in COMMON_PASSWORDS:
        return True
    
    # Add more sophisticated breach checking here
    # For now, just return False (not compromised)
    return False
