"""
Advanced Rate Limiting and Throttling.

This module provides comprehensive rate limiting functionality including:
- Token bucket algorithm
- Sliding window rate limiting
- Distributed rate limiting with Redis
- Custom rate limiting strategies
- Rate limit bypass for trusted users
- Dynamic rate limiting based on user behavior
"""

import time
import asyncio
from typing import Dict, Any, Optional, List, Callable, Union
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dataclasses import dataclass
from enum import Enum
import logging

from app.config import settings

logger = logging.getLogger(__name__)


class RateLimitStrategy(Enum):
    """Rate limiting strategy types."""
    TOKEN_BUCKET = "token_bucket"
    SLIDING_WINDOW = "sliding_window"
    FIXED_WINDOW = "fixed_window"
    DISTRIBUTED = "distributed"


@dataclass
class RateLimitRule:
    """Rate limit rule configuration."""
    name: str
    limit: int  # Maximum requests
    window: int  # Time window in seconds
    strategy: RateLimitStrategy = RateLimitStrategy.SLIDING_WINDOW
    burst_limit: Optional[int] = None  # Burst allowance
    block_duration: Optional[int] = None  # Block duration in seconds
    exempt_users: Optional[List[str]] = None  # User IDs to exempt
    exempt_ips: Optional[List[str]] = None  # IP addresses to exempt


class TokenBucket:
    """Token bucket rate limiter."""
    
    def __init__(self, capacity: int, refill_rate: float):
        """
        Initialize token bucket.
        
        Args:
            capacity: Maximum number of tokens
            refill_rate: Tokens added per second
        """
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.tokens = capacity
        self.last_refill = time.time()
    
    def consume(self, tokens: int = 1) -> bool:
        """
        Consume tokens from bucket.
        
        Args:
            tokens: Number of tokens to consume
        
        Returns:
            True if tokens were consumed, False if bucket is empty
        """
        now = time.time()
        
        # Refill tokens based on time elapsed
        time_elapsed = now - self.last_refill
        tokens_to_add = time_elapsed * self.refill_rate
        self.tokens = min(self.capacity, self.tokens + tokens_to_add)
        self.last_refill = now
        
        # Check if we have enough tokens
        if self.tokens >= tokens:
            self.tokens -= tokens
            return True
        
        return False


class SlidingWindowRateLimiter:
    """Sliding window rate limiter."""
    
    def __init__(self, limit: int, window: int):
        """
        Initialize sliding window rate limiter.
        
        Args:
            limit: Maximum requests in window
            window: Time window in seconds
        """
        self.limit = limit
        self.window = window
        self.requests = defaultdict(deque)
    
    def is_rate_limited(self, key: str) -> bool:
        """
        Check if key is rate limited.
        
        Args:
            key: Rate limit key (IP, user ID, etc.)
        
        Returns:
            True if rate limited, False otherwise
        """
        now = time.time()
        requests = self.requests[key]
        
        # Remove old requests outside window
        while requests and now - requests[0] > self.window:
            requests.popleft()
        
        # Check if under limit
        if len(requests) < self.limit:
            requests.append(now)
            return False
        
        return True
    
    def get_remaining_requests(self, key: str) -> int:
        """
        Get remaining requests for key.
        
        Args:
            key: Rate limit key
        
        Returns:
            Number of remaining requests
        """
        now = time.time()
        requests = self.requests[key]
        
        # Remove old requests
        while requests and now - requests[0] > self.window:
            requests.popleft()
        
        return max(0, self.limit - len(requests))
    
    def get_reset_time(self, key: str) -> int:
        """
        Get time until rate limit resets.
        
        Args:
            key: Rate limit key
        
        Returns:
            Seconds until rate limit resets
        """
        now = time.time()
        requests = self.requests[key]
        
        if not requests:
            return 0
        
        # Find oldest request in window
        oldest_request = min(requests)
        reset_time = oldest_request + self.window - now
        
        return max(0, int(reset_time))


class DistributedRateLimiter:
    """Distributed rate limiter using Redis (placeholder implementation)."""
    
    def __init__(self, redis_client=None):
        """
        Initialize distributed rate limiter.
        
        Args:
            redis_client: Redis client instance
        """
        self.redis_client = redis_client
    
    async def is_rate_limited(
        self, 
        key: str, 
        limit: int, 
        window: int
    ) -> bool:
        """
        Check if key is rate limited using Redis.
        
        Args:
            key: Rate limit key
            limit: Maximum requests
            window: Time window in seconds
        
        Returns:
            True if rate limited, False otherwise
        """
        if not self.redis_client:
            # Fallback to in-memory implementation
            return False
        
        now = time.time()
        redis_key = f"rate_limit:{key}"
        
        try:
            # Use Redis pipeline for atomic operations
            pipe = self.redis_client.pipeline()
            pipe.incr(redis_key)
            pipe.expire(redis_key, window)
            results = pipe.execute()
            
            current_count = results[0]
            return current_count > limit
            
        except Exception as e:
            logger.error(f"Redis rate limiting error: {e}")
            # Fail open (don't block) on Redis errors
            return False


class AdaptiveRateLimiter:
    """Adaptive rate limiter that adjusts limits based on user behavior."""
    
    def __init__(self, base_limit: int, window: int):
        """
        Initialize adaptive rate limiter.
        
        Args:
            base_limit: Base rate limit
            window: Time window in seconds
        """
        self.base_limit = base_limit
        self.window = window
        self.user_scores = defaultdict(float)  # User behavior score
        self.request_history = defaultdict(list)
    
    def calculate_dynamic_limit(self, key: str) -> int:
        """
        Calculate dynamic rate limit based on user behavior.
        
        Args:
            key: Rate limit key
        
        Returns:
            Dynamic rate limit
        """
        score = self.user_scores[key]
        
        # Good users get higher limits, bad users get lower limits
        if score > 0.5:
            return int(self.base_limit * 1.5)  # 50% increase
        elif score < 0:
            return max(1, int(self.base_limit * 0.5))  # 50% decrease
        
        return self.base_limit
    
    def update_user_score(self, key: str, success: bool):
        """
        Update user behavior score.
        
        Args:
            key: Rate limit key
            success: Whether the request was successful
        """
        # Increase score for successful requests, decrease for failures
        adjustment = 0.1 if success else -0.1
        self.user_scores[key] += adjustment
        
        # Clamp score between -1 and 1
        self.user_scores[key] = max(-1.0, min(1.0, self.user_scores[key]))
    
    def is_rate_limited(self, key: str) -> bool:
        """
        Check if key is rate limited using adaptive logic.
        
        Args:
            key: Rate limit key
        
        Returns:
            True if rate limited, False otherwise
        """
        dynamic_limit = self.calculate_dynamic_limit(key)
        now = time.time()
        
        requests = self.request_history[key]
        
        # Remove old requests
        requests[:] = [req_time for req_time in requests 
                      if now - req_time <= self.window]
        
        # Check limit
        if len(requests) >= dynamic_limit:
            # Update score for exceeding limit
            self.update_user_score(key, success=False)
            return True
        
        requests.append(now)
        # Update score for successful request
        self.update_user_score(key, success=True)
        
        return False


class AdvancedRateLimiter:
    """Advanced rate limiter with multiple strategies and rules."""
    
    def __init__(self):
        """Initialize advanced rate limiter."""
        self.limiters: Dict[str, Union[
            SlidingWindowRateLimiter, 
            TokenBucket, 
            AdaptiveRateLimiter
        ]] = {}
        self.distributed_limiter = DistributedRateLimiter()
        self.rate_limit_rules: List[RateLimitRule] = []
        self.blocked_keys: Dict[str, float] = {}  # key -> unblock_time
        
        # Add default rate limit rules
        self._setup_default_rules()
    
    def _setup_default_rules(self):
        """Set up default rate limit rules."""
        self.rate_limit_rules = [
            RateLimitRule(
                name="default",
                limit=settings.rate_limit_requests_per_minute,
                window=60,
                strategy=RateLimitStrategy.SLIDING_WINDOW,
                burst_limit=settings.rate_limit_burst_size
            ),
            RateLimitRule(
                name="auth",
                limit=5,
                window=60,
                strategy=RateLimitStrategy.SLIDING_WINDOW,
                block_duration=300  # 5 minutes
            ),
            RateLimitRule(
                name="api",
                limit=1000,
                window=3600,
                strategy=RateLimitStrategy.SLIDING_WINDOW,
                burst_limit=100
            ),
            RateLimitRule(
                name="upload",
                limit=10,
                window=60,
                strategy=RateLimitStrategy.SLIDING_WINDOW
            )
        ]
    
    def is_rate_limited(
        self, 
        key: str, 
        rule_name: str = "default",
        user_id: Optional[str] = None,
        user_permissions: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Check if key is rate limited.
        
        Args:
            key: Rate limit key (IP, user ID, etc.)
            rule_name: Name of rate limit rule
            user_id: User ID for exemption checks
            user_permissions: User permissions for dynamic limits
        
        Returns:
            Dictionary with rate limit status and details
        """
        # Check if key is blocked
        if key in self.blocked_keys:
            unblock_time = self.blocked_keys[key]
            if time.time() < unblock_time:
                return {
                    "rate_limited": True,
                    "reason": "blocked",
                    "unblock_time": unblock_time
                }
            else:
                # Remove expired block
                del self.blocked_keys[key]
        
        # Find rate limit rule
        rule = None
        for r in self.rate_limit_rules:
            if r.name == rule_name:
                rule = r
                break
        
        if not rule:
            rule = self.rate_limit_rules[0]  # Use default
        
        # Check exemptions
        if self._is_exempt(key, user_id, user_permissions, rule):
            return {
                "rate_limited": False,
                "reason": "exempt"
            }
        
        # Apply rate limiting strategy
        if rule.strategy == RateLimitStrategy.SLIDING_WINDOW:
            return self._sliding_window_check(key, rule)
        elif rule.strategy == RateLimitStrategy.TOKEN_BUCKET:
            return self._token_bucket_check(key, rule)
        elif rule.strategy == RateLimitStrategy.ADAPTIVE:
            return self._adaptive_check(key, rule)
        elif rule.strategy == RateLimitStrategy.DISTRIBUTED:
            return self._distributed_check(key, rule)
        
        return {"rate_limited": False, "reason": "no_rule"}
    
    def _is_exempt(
        self, 
        key: str, 
        user_id: Optional[str], 
        permissions: Optional[List[str]], 
        rule: RateLimitRule
    ) -> bool:
        """Check if request should be exempted from rate limiting."""
        # Check IP exemptions
        if rule.exempt_ips and key in rule.exempt_ips:
            return True
        
        # Check user exemptions
        if rule.exempt_users and user_id in rule.exempt_users:
            return True
        
        # Check for admin users
        if permissions and "admin" in permissions:
            return True
        
        # Check for high-privilege users
        if permissions and any(perm in permissions for perm in ["moderator", "super_user"]):
            return True
        
        return False
    
    def _sliding_window_check(self, key: str, rule: RateLimitRule) -> Dict[str, Any]:
        """Check using sliding window strategy."""
        if key not in self.limiters:
            self.limiters[key] = SlidingWindowRateLimiter(
                limit=rule.limit,
                window=rule.window
            )
        
        limiter = self.limiters[key]
        rate_limited = limiter.is_rate_limited(key)
        
        return {
            "rate_limited": rate_limited,
            "remaining": limiter.get_remaining_requests(key),
            "reset_time": limiter.get_reset_time(key),
            "limit": rule.limit,
            "window": rule.window
        }
    
    def _token_bucket_check(self, key: str, rule: RateLimitRule) -> Dict[str, Any]:
        """Check using token bucket strategy."""
        if key not in self.limiters:
            refill_rate = rule.limit / rule.window
            self.limiters[key] = TokenBucket(
                capacity=rule.burst_limit or rule.limit,
                refill_rate=refill_rate
            )
        
        limiter = self.limiters[key]
        allowed = limiter.consume()
        
        # Calculate tokens remaining
        tokens_remaining = int(limiter.tokens)
        
        if not allowed and rule.block_duration:
            self.blocked_keys[key] = time.time() + rule.block_duration
        
        return {
            "rate_limited": not allowed,
            "remaining": tokens_remaining,
            "limit": rule.limit,
            "window": rule.window
        }
    
    def _adaptive_check(self, key: str, rule: RateLimitRule) -> Dict[str, Any]:
        """Check using adaptive strategy."""
        if key not in self.limiters:
            self.limiters[key] = AdaptiveRateLimiter(
                base_limit=rule.limit,
                window=rule.window
            )
        
        limiter = self.limiters[key]
        rate_limited = limiter.is_rate_limited(key)
        
        return {
            "rate_limited": rate_limited,
            "dynamic_limit": limiter.calculate_dynamic_limit(key),
            "user_score": limiter.user_scores[key],
            "limit": rule.limit,
            "window": rule.window
        }
    
    def _distributed_check(self, key: str, rule: RateLimitRule) -> Dict[str, Any]:
        """Check using distributed strategy."""
        # This would use Redis in production
        return {
            "rate_limited": False,
            "distributed": True,
            "limit": rule.limit,
            "window": rule.window
        }
    
    def add_rate_limit_rule(self, rule: RateLimitRule):
        """Add a new rate limit rule."""
        self.rate_limit_rules.append(rule)
        logger.info(f"Added rate limit rule: {rule.name}")
    
    def remove_rate_limit_rule(self, rule_name: str):
        """Remove a rate limit rule."""
        self.rate_limit_rules = [
            r for r in self.rate_limit_rules 
            if r.name != rule_name
        ]
        logger.info(f"Removed rate limit rule: {rule_name}")
    
    def get_rate_limit_stats(self, key: str) -> Dict[str, Any]:
        """Get rate limiting statistics for a key."""
        stats = {
            "key": key,
            "blocked": key in self.blocked_keys,
            "unblock_time": self.blocked_keys.get(key)
        }
        
        if key in self.limiters:
            limiter = self.limiters[key]
            if isinstance(limiter, SlidingWindowRateLimiter):
                stats.update({
                    "remaining_requests": limiter.get_remaining_requests(key),
                    "reset_time": limiter.get_reset_time(key)
                })
            elif isinstance(limiter, AdaptiveRateLimiter):
                stats.update({
                    "dynamic_limit": limiter.calculate_dynamic_limit(key),
                    "user_score": limiter.user_scores[key]
                })
        
        return stats
    
    def cleanup_expired_entries(self):
        """Clean up expired rate limiting entries."""
        current_time = time.time()
        
        # Clean up blocked keys
        expired_blocks = [
            key for key, unblock_time in self.blocked_keys.items()
            if current_time >= unblock_time
        ]
        for key in expired_blocks:
            del self.blocked_keys[key]
        
        # Clean up old limiter data
        for key, limiter in list(self.limiters.items()):
            if isinstance(limiter, AdaptiveRateLimiter):
                # Remove users with very low scores or no recent activity
                if (limiter.user_scores[key] < -0.5 and 
                    current_time - max(limiter.request_history[key] or [0]) > 3600):
                    del limiter.user_scores[key]
                    if key in limiter.request_history:
                        del limiter.request_history[key]


# Global rate limiter instance
rate_limiter = AdvancedRateLimiter()


def rate_limit(
    rule_name: str = "default",
    key_func: Optional[Callable] = None,
    exempt_func: Optional[Callable] = None
):
    """
    Rate limiting decorator.
    
    Args:
        rule_name: Name of rate limit rule
        key_func: Function to generate rate limit key
        exempt_func: Function to check if request should be exempt
    
    Example:
        @rate_limit(rule_name="api")
        async def my_endpoint():
            pass
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # This would be implemented based on your FastAPI request context
            # For now, it's a placeholder
            return await func(*args, **kwargs)
        return wrapper
    return decorator


# Utility functions

def get_client_ip_key(client_ip: str, user_id: Optional[str] = None) -> str:
    """Generate rate limit key from client IP and optional user ID."""
    if user_id:
        return f"user:{user_id}"
    return f"ip:{client_ip}"


def should_bypass_rate_limit(
    user_permissions: Optional[List[str]] = None,
    path: str = "",
    method: str = ""
) -> bool:
    """Check if request should bypass rate limiting."""
    # Admin users bypass all rate limits
    if user_permissions and "admin" in user_permissions:
        return True
    
    # Health checks and metrics bypass rate limits
    if path in ["/health", "/metrics"]:
        return True
    
    # Auth endpoints have their own rate limiting
    if path.startswith("/auth/"):
        return True
    
    return False


def get_rate_limit_headers(
    remaining: int, 
    limit: int, 
    reset_time: int
) -> Dict[str, str]:
    """Generate rate limit headers for response."""
    return {
        "X-RateLimit-Limit": str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset": str(reset_time),
        "X-RateLimit-Window": "60"  # Standard window in seconds
    }
