"""
JWT Authentication and User Management.

This module provides authentication functionality including:
- User verification and authentication
- JWT token creation and validation
- Current user retrieval and session management
- Password verification against stored hashes
"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import logging
import secrets

from app.config import settings
from app.security.password_utils import verify_password, get_password_hash
from app.security.token_utils import verify_access_token, create_access_token
from app.security.permissions import UserPermissions, Role

logger = logging.getLogger(__name__)

# Security scheme
security = HTTPBearer()

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class User:
    """User model for authentication and authorization."""
    
    def __init__(
        self,
        id: str,
        username: str,
        email: str,
        hashed_password: str,
        role: str = "user",
        is_active: bool = True,
        is_verified: bool = False,
        permissions: Optional[List[str]] = None,
        last_login: Optional[datetime] = None,
        failed_login_attempts: int = 0,
        locked_until: Optional[datetime] = None,
        **kwargs
    ):
        self.id = id
        self.username = username
        self.email = email
        self.hashed_password = hashed_password
        self.role = Role(role) if isinstance(role, str) else role
        self.is_active = is_active
        self.is_verified = is_verified
        self.permissions = UserPermissions(permissions or [])
        self.last_login = last_login
        self.failed_login_attempts = failed_login_attempts
        self.locked_until = locked_until
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    def check_password(self, password: str) -> bool:
        """Verify user password."""
        try:
            return verify_password(password, self.hashed_password)
        except Exception as e:
            logger.warning(f"Password verification failed for user {self.username}: {e}")
            return False
    
    def update_failed_attempts(self):
        """Update failed login attempts counter."""
        self.failed_login_attempts += 1
        self.updated_at = datetime.utcnow()
        
        # Lock account after 5 failed attempts
        if self.failed_login_attempts >= 5:
            self.locked_until = datetime.utcnow() + timedelta(minutes=15)  # 15-minute lock
            logger.warning(f"User account {self.username} locked due to too many failed attempts")
    
    def reset_failed_attempts(self):
        """Reset failed login attempts on successful login."""
        self.failed_login_attempts = 0
        self.locked_until = None
        self.last_login = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    @property
    def is_locked(self) -> bool:
        """Check if user account is locked."""
        if self.locked_until:
            return datetime.utcnow() < self.locked_until
        return False
    
    def to_dict(self, include_sensitive: bool = False) -> Dict[str, Any]:
        """Convert user to dictionary."""
        data = {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "role": str(self.role),
            "is_active": self.is_active,
            "is_verified": self.is_verified,
            "permissions": self.permissions.permissions,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
        
        if include_sensitive:
            data.update({
                "failed_login_attempts": self.failed_login_attempts,
                "locked_until": self.locked_until.isoformat() if self.locked_until else None,
            })
        
        return data


# Mock user database - replace with actual database integration
class MockUserDatabase:
    """Mock user database for demonstration purposes."""
    
    def __init__(self):
        self.users: Dict[str, User] = {}
        self.users_by_username: Dict[str, str] = {}
        self.users_by_email: Dict[str, str] = {}
        
        # Create default admin user
        admin_user = User(
            id="admin-001",
            username="admin",
            email="admin@example.com",
            hashed_password=get_password_hash("admin123"),
            role="admin",
            is_active=True,
            is_verified=True,
            permissions=["admin", "user", "read", "write"]
        )
        
        self.create_user(admin_user)
    
    def create_user(self, user: User):
        """Create a new user."""
        self.users[user.id] = user
        self.users_by_username[user.username] = user.id
        self.users_by_email[user.email] = user.id
        logger.info(f"Created user: {user.username}")
    
    def get_user_by_id(self, user_id: str) -> Optional[User]:
        """Get user by ID."""
        return self.users.get(user_id)
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username."""
        user_id = self.users_by_username.get(username)
        return self.users.get(user_id) if user_id else None
    
    def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email."""
        user_id = self.users_by_email.get(email)
        return self.users.get(user_id) if user_id else None
    
    def update_user(self, user: User):
        """Update user information."""
        self.users[user.id] = user
        self.users_by_username[user.username] = user.id
        self.users_by_email[user.email] = user.id
        user.updated_at = datetime.utcnow()
    
    def delete_user(self, user_id: str):
        """Delete user."""
        user = self.users.get(user_id)
        if user:
            del self.users[user_id]
            del self.users_by_username[user.username]
            del self.users_by_email[user.email]


# Global user database instance
user_db = MockUserDatabase()


async def authenticate_user(username: str, password: str) -> Optional[User]:
    """
    Authenticate user with username and password.
    
    Args:
        username: Username or email
        password: Plain text password
    
    Returns:
        User object if authentication successful, None otherwise
    """
    try:
        # Try to find user by username first
        user = user_db.get_user_by_username(username)
        
        # If not found, try by email
        if not user:
            user = user_db.get_user_by_email(username)
        
        if not user:
            logger.warning(f"Authentication failed: user {username} not found")
            return None
        
        # Check if user is active
        if not user.is_active:
            logger.warning(f"Authentication failed: user {username} is inactive")
            return None
        
        # Check if user is locked
        if user.is_locked:
            logger.warning(f"Authentication failed: user {username} account is locked")
            return None
        
        # Verify password
        if not user.check_password(password):
            user.update_failed_attempts()
            user_db.update_user(user)
            logger.warning(f"Authentication failed: invalid password for user {username}")
            return None
        
        # Successful authentication - reset failed attempts
        user.reset_failed_attempts()
        user_db.update_user(user)
        
        logger.info(f"User {username} authenticated successfully")
        return user
        
    except Exception as e:
        logger.error(f"Authentication error for user {username}: {e}")
        return None


async def create_access_token(
    data: dict,
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Create JWT access token.
    
    Args:
        data: Data to encode in token
        expires_delta: Custom expiration time
    
    Returns:
        Encoded JWT token
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)
    
    to_encode.update({"exp": expire, "type": "access"})
    
    try:
        encoded_jwt = jwt.encode(
            to_encode,
            settings.jwt_secret_key.get_secret_value(),
            algorithm=settings.jwt_algorithm
        )
        return encoded_jwt
    except Exception as e:
        logger.error(f"Token creation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Token creation failed"
        )


async def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify and decode JWT token.
    
    Args:
        token: JWT token to verify
    
    Returns:
        Decoded token payload if valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        return payload
    except JWTError as e:
        logger.warning(f"Token verification failed: {e}")
        return None


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security)
) -> User:
    """
    Get current authenticated user from JWT token.
    
    Args:
        credentials: HTTP Bearer credentials
    
    Returns:
        Current user object
    
    Raises:
        HTTPException: If token is invalid or user not found
    """
    token = credentials.credentials
    
    # Verify token
    payload = verify_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check token type
    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Extract user ID from token
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Get user from database
    user = user_db.get_user_by_id(user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user is still active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is inactive",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user is locked
    if user.is_locked:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is locked",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return user


def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    Get current active user (convenience function).
    
    Args:
        current_user: Current user from token
    
    Returns:
        Current user object (guaranteed to be active)
    """
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    
    return current_user


async def refresh_access_token(
    refresh_token: str,
    current_user: User = Depends(get_current_user)
) -> str:
    """
    Create new access token using refresh token.
    
    Args:
        refresh_token: Valid refresh token
        current_user: Current authenticated user
    
    Returns:
        New access token
    """
    # Verify refresh token
    payload = verify_token(refresh_token)
    if payload is None or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    # Check if refresh token belongs to current user
    token_user_id = payload.get("sub")
    if token_user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token-user mismatch"
        )
    
    # Create new access token
    return await create_access_token(
        data={"sub": current_user.id, "username": current_user.username}
    )


def create_user(
    username: str,
    email: str,
    password: str,
    role: str = "user",
    permissions: Optional[List[str]] = None
) -> User:
    """
    Create a new user with hashed password.
    
    Args:
        username: Username
        email: Email address
        password: Plain text password
        role: User role
        permissions: List of permissions
    
    Returns:
        Created user object
    """
    # Check if username already exists
    if user_db.get_user_by_username(username):
        raise ValueError(f"Username '{username}' already exists")
    
    # Check if email already exists
    if user_db.get_user_by_email(email):
        raise ValueError(f"Email '{email}' already exists")
    
    # Generate user ID
    user_id = f"user-{secrets.token_hex(8)}"
    
    # Hash password
    hashed_password = get_password_hash(password)
    
    # Create user
    user = User(
        id=user_id,
        username=username,
        email=email,
        hashed_password=hashed_password,
        role=role,
        permissions=permissions
    )
    
    # Save to database
    user_db.create_user(user)
    
    logger.info(f"Created new user: {username}")
    return user
