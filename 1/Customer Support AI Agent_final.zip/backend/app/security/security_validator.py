"""
Security Input Validation and Sanitization.

This module provides comprehensive input validation and sanitization including:
- SQL injection detection and prevention
- XSS (Cross-Site Scripting) protection
- Command injection prevention
- Path traversal protection
- Content validation and filtering
- Input normalization and encoding
- Security pattern matching
"""

import re
import html
import json
import urllib.parse
from typing import Any, Dict, List, Optional, Set, Union, Tuple
from dataclasses import dataclass
from enum import Enum
import logging
import unicodedata
import bleach

logger = logging.getLogger(__name__)


class ValidationLevel(Enum):
    """Validation severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ValidationResult:
    """Input validation result."""
    
    def __init__(
        self, 
        is_valid: bool, 
        level: ValidationLevel = ValidationLevel.MEDIUM,
        message: str = "",
        violations: Optional[List[str]] = None,
        sanitized_value: Optional[str] = None
    ):
        self.is_valid = is_valid
        self.level = level
        self.message = message
        self.violations = violations or []
        self.sanitized_value = sanitized_value
        self.timestamp = None  # Can be set by caller


class SecurityPatterns:
    """Collection of security patterns for validation."""
    
    # SQL Injection patterns
    SQL_INJECTION_PATTERNS = [
        # Basic SQL keywords
        r"\b(union|select|insert|update|delete|drop|create|alter|exec|execute|truncate|grant|revoke)\b",
        # SQL operators
        r"\b(or|and|not|xor|like|glob|regexp|match|against|in|between|exists)\b",
        # SQL comments
        r"('|(\\)|(%27)|(%5C))",  # Single quote and backslash
        r"(;|--|/\\*)",  # SQL statements and comments
        # Function patterns
        r"\b(concat|char|ascii|hex|unhex|substring|mid|length|upper|lower|replace)\b",
        # Database-specific
        r"\b(union|xp_cmdshell|sp_executesql|information_schema|sys\.)",
        # Time-based patterns
        r"\b(sleep|benchmark|pg_sleep|waitfor\s+delay)\b",
        # File system access
        r"\b(load_file|into\s+outfile|into\s+dumpfile)\b",
        # Advanced injection
        r"(?:'|\"|`)\s*(?:or|and)\s*(?:'|\"|`)?\d+",
        r"(?:'|\"|`)\s*=\s*(?:'|\"|`)",
    ]
    
    # XSS patterns
    XSS_PATTERNS = [
        # Script tags
        r"<script[^>]*>.*?</script>",
        r"<script[^>]*>",
        # Event handlers
        r"on\w+\s*=\s*['\"][^'\"]*['\"]",
        r"on\w+\s*=\s*[^\s>]+",
        # JavaScript protocols
        r"javascript:",
        r"vbscript:",
        r"data:",
        # HTML injection
        r"<[^>]*onload[^>]*>",
        r"<[^>]*onerror[^>]*>",
        # Iframe injection
        r"<iframe[^>]*>.*?</iframe>",
        # Object/embed tags
        r"<object[^>]*>.*?</object>",
        r"<embed[^>]*>.*?</embed>",
        # Form injection
        r"<form[^>]*>.*?</form>",
        # Meta refresh
        r"<meta[^>]*http-equiv=['\"]?refresh['\"]?[^>]*>",
    ]
    
    # Command Injection patterns
    COMMAND_INJECTION_PATTERNS = [
        # Shell metacharacters
        r"[;&|`$(){}\\[\\]<>]",
        r"\|\|",
        r"&&",
        r"\\",
        r"/",
        # Command separators
        r";",
        r"\\|",
        # Environment variables
        r"\\$\\{[^}]*\\}",
        r"\\$\\w+",
        # Command substitution
        r"\\$\\(.*?\\)",
        r"`[^`]*`",
        # File descriptors
        r"\\d>&\\d",
        # Process substitution
        r"\\$\\{.*?\\}",
    ]
    
    # Path Traversal patterns
    PATH_TRAVERSAL_PATTERNS = [
        r"\\.\\./",
        r"\\.\\.\\\\",
        r"%2e%2e%2f",
        r"%2e%2e%5c",
        r"%252e%252e%252f",
        r"....//",
        r"....\\\\",
    ]
    
    # NoSQL Injection patterns
    NOSQL_INJECTION_PATTERNS = [
        # MongoDB operators
        r"\$where",
        r"\$ne",
        r"\$gt",
        r"\$lt",
        r"\$gte",
        r"\$lte",
        r"\$in",
        r"\$nin",
        r"\$or",
        r"\$and",
        r"\$not",
        r"\$nor",
        r"\$exists",
        r"\$type",
        r"\$regex",
        r"\$options",
        # JavaScript injection
        r"\\$\\{.*?\\}",
        r"this\\.",
        r"constructor\\.",
    ]
    
    # LDAP Injection patterns
    LDAP_INJECTION_PATTERNS = [
        r"\\(\\|",
        r"\\)\\|",
        r"\\)\\(",
        r"\\*\\)",
        r"\\)\\s*\\|",
        r"\\)\\s*\\&",
        r"\\)\\s*\\(",
    ]
    
    # Template Injection patterns
    TEMPLATE_INJECTION_PATTERNS = [
        # Jinja2/Django templates
        r"\\{\\{.*?\\}\\}",
        r"\\{%.*?%\\}",
        r"\\{#.*?#\\}",
        # Mustache templates
        r"\\{\\{!.*?\\}\\}",
        r"\\{&.*?&\\}",
        # Handlebars templates
        r"\\{\\{&.*?\\}\\}",
        r"\\{~.*?~\\}",
        # General template syntax
        r"\\$collection\\[.*?\\]",
        r"\\$eval\\(",
        r"\\$where\\(",
    ]
    
    # SSRF patterns
    SSRF_PATTERNS = [
        # Internal IP ranges
        r"127\\.0\\.0\\.1",
        r"localhost",
        r"0\\.0\\.0\\.0",
        r"::1",
        r"10\\.\\d+\\.\\d+\\.\\d+",
        r"192\\.168\\.\\d+\\.\\d+",
        r"172\\.(1[6-9]|2[0-9]|3[0-1])\\.\\d+\\.\\d+",
        # Cloud metadata endpoints
        r"169\\.254\\.169\\.254",
        # File URLs
        r"file:///[^\\s]",
        # Gopher protocol
        r"gopher://[^\\s]",
    ]


class InputValidator:
    """Comprehensive input validation and sanitization."""
    
    def __init__(self):
        """Initialize validator with security patterns."""
        self.sql_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.SQL_INJECTION_PATTERNS]
        self.xss_patterns = [re.compile(p, re.IGNORECASE | re.DOTALL) for p in SecurityPatterns.XSS_PATTERNS]
        self.command_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.COMMAND_INJECTION_PATTERNS]
        self.path_traversal_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.PATH_TRAVERSAL_PATTERNS]
        self.nosql_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.NOSQL_INJECTION_PATTERNS]
        self.ldap_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.LDAP_INJECTION_PATTERNS]
        self.template_patterns = [re.compile(p, re.IGNORECASE | re.DOTALL) for p in SecurityPatterns.TEMPLATE_INJECTION_PATTERNS]
        self.ssrf_patterns = [re.compile(p, re.IGNORECASE) for p in SecurityPatterns.SSRF_PATTERNS]
    
    def validate_sql_injection(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against SQL injection attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.sql_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"SQL injection detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="SQL injection pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_xss(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against XSS attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.xss_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"XSS pattern detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="XSS pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_command_injection(self, value: str, level: ValidationLevel = ValidationLevel.CRITICAL) -> ValidationResult:
        """
        Validate input against command injection attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.command_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"Command injection detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="Command injection pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_path_traversal(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against path traversal attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.path_traversal_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"Path traversal detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="Path traversal pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_nosql_injection(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against NoSQL injection attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.nosql_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"NoSQL injection detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="NoSQL injection pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_ldap_injection(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against LDAP injection attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.ldap_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"LDAP injection detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="LDAP injection pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_template_injection(self, value: str, level: ValidationLevel = ValidationLevel.HIGH) -> ValidationResult:
        """
        Validate input against template injection attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.template_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"Template injection detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="Template injection pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def validate_ssrf(self, value: str, level: ValidationLevel = ValidationLevel.CRITICAL) -> ValidationResult:
        """
        Validate input against Server-Side Request Forgery (SSRF) attacks.
        
        Args:
            value: Input to validate
            level: Validation severity level
        
        Returns:
            ValidationResult with validation status and details
        """
        if not isinstance(value, str):
            value = str(value)
        
        violations = []
        for pattern in self.ssrf_patterns:
            matches = pattern.findall(value)
            if matches:
                violations.extend(matches)
        
        if violations:
            logger.warning(f"SSRF pattern detected: {violations}")
            return ValidationResult(
                is_valid=False,
                level=level,
                message="SSRF pattern detected",
                violations=violations
            )
        
        return ValidationResult(is_valid=True)
    
    def comprehensive_validation(
        self, 
        value: Any, 
        checks: Optional[List[str]] = None,
        level: ValidationLevel = ValidationLevel.HIGH
    ) -> ValidationResult:
        """
        Perform comprehensive security validation.
        
        Args:
            value: Input to validate
            checks: List of validation checks to perform
            level: Validation severity level
        
        Returns:
            ValidationResult with comprehensive validation status
        """
        str_value = str(value) if not isinstance(value, str) else value
        all_violations = []
        
        if checks is None:
            checks = ["sql", "xss", "command", "path_traversal", "nosql"]
        
        validation_methods = {
            "sql": self.validate_sql_injection,
            "xss": self.validate_xss,
            "command": self.validate_command_injection,
            "path_traversal": self.validate_path_traversal,
            "nosql": self.validate_nosql_injection,
            "ldap": self.validate_ldap_injection,
            "template": self.validate_template_injection,
            "ssrf": self.validate_ssrf,
        }
        
        for check in checks:
            if check in validation_methods:
                result = validation_methods[check](str_value, level)
                if not result.is_valid:
                    all_violations.extend(result.violations)
        
        if all_violations:
            return ValidationResult(
                is_valid=False,
                level=level,
                message="Security violations detected",
                violations=all_violations
            )
        
        return ValidationResult(is_valid=True)


class InputSanitizer:
    """Input sanitization utilities."""
    
    def __init__(self):
        """Initialize sanitizer."""
        self.max_length = 10000  # Default max input length
        self.allowed_tags = set(bleach.sanitizer.ALLOWED_TAGS)
        self.allowed_attributes = bleach.sanitizer.ALLOWED_ATTRIBUTES.copy()
    
    def sanitize_html(self, value: str, allowed_tags: Optional[Set[str]] = None) -> str:
        """
        Sanitize HTML content using bleach.
        
        Args:
            value: HTML content to sanitize
            allowed_tags: Custom allowed HTML tags
        
        Returns:
            Sanitized HTML string
        """
        if not isinstance(value, str):
            value = str(value)
        
        tags = allowed_tags or self.allowed_tags
        
        # Sanitize with bleach
        cleaned = bleach.clean(
            value,
            tags=tags,
            attributes=self.allowed_attributes,
            protocols=['http', 'https', 'mailto'],
            strip=True
        )
        
        return cleaned
    
    def sanitize_text(self, value: str, remove_special_chars: bool = False) -> str:
        """
        Sanitize plain text content.
        
        Args:
            value: Text content to sanitize
            remove_special_chars: Whether to remove special characters
        
        Returns:
            Sanitized text string
        """
        if not isinstance(value, str):
            value = str(value)
        
        # Remove null bytes and control characters
        cleaned = ''.join(char for char in value if ord(char) >= 32 or char in '\t\n\r')
        
        # Remove or escape special characters if requested
        if remove_special_chars:
            cleaned = re.sub(r'[^\w\s]', '', cleaned)
        
        # Normalize unicode
        cleaned = unicodedata.normalize('NFKC', cleaned)
        
        return cleaned
    
    def sanitize_filename(self, value: str) -> str:
        """
        Sanitize filename to be safe for filesystem operations.
        
        Args:
            value: Filename to sanitize
        
        Returns:
            Sanitized filename
        """
        if not isinstance(value, str):
            value = str(value)
        
        # Remove path separators and dangerous characters
        cleaned = re.sub(r'[<>:\"/\\|?*]', '_', value)
        
        # Remove leading/trailing dots and spaces
        cleaned = cleaned.strip('. ')
        
        # Limit length
        if len(cleaned) > 255:
            name, ext = cleaned.rsplit('.', 1) if '.' in cleaned else (cleaned, '')
            name = name[:255-len(ext)-1]
            cleaned = f"{name}.{ext}" if ext else name
        
        # Ensure not empty
        if not cleaned:
            cleaned = "untitled"
        
        return cleaned
    
    def sanitize_url(self, value: str) -> str:
        """
        Sanitize URL to prevent SSRF attacks.
        
        Args:
            value: URL to sanitize
        
        Returns:
            Sanitized URL or empty string if invalid
        """
        if not isinstance(value, str):
            value = str(value)
        
        try:
            parsed = urllib.parse.urlparse(value)
            
            # Block internal/private IP ranges
            if self._is_internal_ip(parsed.hostname):
                return ""
            
            # Allow only HTTP and HTTPS protocols
            if parsed.scheme not in ['http', 'https']:
                return ""
            
            # Remove dangerous URL components
            cleaned_url = urllib.parse.urlunparse((
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                '',  # Remove params
                '',  # Remove query
                ''   # Remove fragment
            ))
            
            return cleaned_url
            
        except Exception:
            return ""
    
    def sanitize_json(self, value: str) -> str:
        """
        Sanitize JSON input by removing dangerous patterns.
        
        Args:
            value: JSON string to sanitize
        
        Returns:
            Sanitized JSON string
        """
        if not isinstance(value, str):
            value = str(value)
        
        # Remove null bytes
        cleaned = value.replace('\x00', '')
        
        # Check for JavaScript injection in JSON
        dangerous_patterns = [
            r'\\beval\\b',
            r'\\bconstructor\\b',
            r'\\bprototype\\b',
            r'\\b__proto__\\b',
            r'\\b__defineGetter__\\b',
            r'\\b__defineSetter__\\b',
            r'\\b__lookupGetter__\\b',
            r'\\b__lookupSetter__\\b',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, cleaned, re.IGNORECASE):
                logger.warning(f"Dangerous pattern detected in JSON: {pattern}")
                return ""
        
        try:
            # Validate JSON structure
            json.loads(cleaned)
            return cleaned
        except json.JSONDecodeError:
            return ""
    
    def _is_internal_ip(self, hostname: str) -> bool:
        """
        Check if hostname resolves to an internal IP address.
        
        Args:
            hostname: Hostname to check
        
        Returns:
            True if internal IP, False otherwise
        """
        if not hostname:
            return False
        
        # Common internal hostnames
        if hostname.lower() in ['localhost', '127.0.0.1', '::1', '0.0.0.0']:
            return True
        
        # Check if it's an IP address
        try:
            import ipaddress
            ip = ipaddress.ip_address(hostname)
            return ip.is_private or ip.is_loopback or ip.is_link_local
        except (ValueError, ImportError):
            # If ipaddress not available or hostname is not IP, do basic checks
            return (hostname.startswith('10.') or 
                    hostname.startswith('192.168.') or
                    hostname.startswith('172.16.') or
                    hostname.startswith('172.17.') or
                    hostname.startswith('172.18.') or
                    hostname.startswith('172.19.') or
                    hostname.startswith('172.20.') or
                    hostname.startswith('172.21.') or
                    hostname.startswith('172.22.') or
                    hostname.startswith('172.23.') or
                    hostname.startswith('172.24.') or
                    hostname.startswith('172.25.') or
                    hostname.startswith('172.26.') or
                    hostname.startswith('172.27.') or
                    hostname.startswith('172.28.') or
                    hostname.startswith('172.29.') or
                    hostname.startswith('172.30.') or
                    hostname.startswith('172.31.') or
                    hostname.startswith('169.254.'))
    
    def escape_html(self, value: str) -> str:
        """
        Escape HTML characters to prevent XSS.
        
        Args:
            value: Text to escape
        
        Returns:
            HTML-escaped string
        """
        if not isinstance(value, str):
            value = str(value)
        
        return html.escape(value, quote=True)
    
    def escape_sql(self, value: str) -> str:
        """
        Escape SQL special characters (basic protection).
        
        Args:
            value: Text to escape for SQL
        
        Returns:
            SQL-escaped string (though parameterized queries are preferred)
        """
        if not isinstance(value, str):
            value = str(value)
        
        # Basic SQL escaping
        escaped = value.replace("'", "''")
        escaped = escaped.replace("\\", "\\\\")
        escaped = escaped.replace("%", "\\%")
        escaped = escaped.replace("_", "\\_")
        
        return escaped


class SecurityValidator:
    """High-level security validation interface."""
    
    def __init__(self):
        """Initialize security validator."""
        self.validator = InputValidator()
        self.sanitizer = InputSanitizer()
    
    def validate_and_sanitize_input(
        self, 
        value: Any, 
        validation_type: str = "comprehensive",
        sanitize_html: bool = False,
        max_length: Optional[int] = None
    ) -> ValidationResult:
        """
        Validate and optionally sanitize input.
        
        Args:
            value: Input to validate and sanitize
            validation_type: Type of validation to perform
            sanitize_html: Whether to sanitize HTML content
            max_length: Maximum allowed length
        
        Returns:
            ValidationResult with validation status and sanitized value
        """
        # Convert to string if not already
        str_value = str(value) if not isinstance(value, str) else value
        
        # Check length
        if max_length and len(str_value) > max_length:
            return ValidationResult(
                is_valid=False,
                level=ValidationLevel.MEDIUM,
                message=f"Input exceeds maximum length of {max_length} characters",
                violations=[f"length_{len(str_value)}"]
            )
        
        # Perform validation
        result = self.validator.comprehensive_validation(
            str_value, 
            checks=[validation_type] if validation_type != "comprehensive" else None
        )
        
        # Sanitize if requested and valid
        if result.is_valid and sanitize_html:
            sanitized = self.sanitizer.sanitize_html(str_value)
            result.sanitized_value = sanitized
        else:
            result.sanitized_value = str_value
        
        return result
    
    def validate_request_data(
        self, 
        data: Dict[str, Any],
        validation_config: Optional[Dict[str, Dict[str, Any]]] = None
    ) -> Dict[str, ValidationResult]:
        """
        Validate request data according to configuration.
        
        Args:
            data: Request data dictionary
            validation_config: Validation configuration per field
        
        Returns:
            Dictionary of field names to ValidationResults
        """
        results = {}
        
        if validation_config is None:
            # Default validation for all fields
            validation_config = {
                field: {"validation_type": "comprehensive", "max_length": 1000}
                for field in data.keys()
            }
        
        for field_name, field_value in data.items():
            config = validation_config.get(field_name, {})
            
            result = self.validate_and_sanitize_input(
                value=field_value,
                validation_type=config.get("validation_type", "comprehensive"),
                sanitize_html=config.get("sanitize_html", False),
                max_length=config.get("max_length")
            )
            
            results[field_name] = result
        
        return results


# Global validator instance
security_validator = SecurityValidator()


# Utility functions

def validate_input(value: Any, **kwargs) -> ValidationResult:
    """
    Convenience function for input validation.
    
    Args:
        value: Input to validate
        **kwargs: Additional validation parameters
    
    Returns:
        ValidationResult
    """
    return security_validator.validate_and_sanitize_input(value, **kwargs)


def sanitize_input(value: Any, **kwargs) -> str:
    """
    Convenience function for input sanitization.
    
    Args:
        value: Input to sanitize
        **kwargs: Additional sanitization parameters
    
    Returns:
        Sanitized string
    """
    result = security_validator.validate_and_sanitize_input(value, **kwargs)
    return result.sanitized_value or str(value)


def is_safe_filename(filename: str) -> bool:
    """
    Check if filename is safe for filesystem operations.
    
    Args:
        filename: Filename to check
    
    Returns:
        True if filename is safe
    """
    result = security_validator.validate_and_sanitize_input(
        filename, 
        validation_type="path_traversal"
    )
    return result.is_valid


def is_safe_url(url: str) -> bool:
    """
    Check if URL is safe (no SSRF attack).
    
    Args:
        url: URL to check
    
    Returns:
        True if URL is safe
    """
    result = security_validator.validate_and_sanitize_input(
        url, 
        validation_type="ssrf"
    )
    if not result.is_valid:
        return False
    
    # Additional URL sanitization check
    sanitized = security_validator.sanitizer.sanitize_url(url)
    return bool(sanitized and sanitized == url)


def validate_user_input(value: str, max_length: int = 1000) -> ValidationResult:
    """
    Validate general user input.
    
    Args:
        value: User input to validate
        max_length: Maximum allowed length
    
    Returns:
        ValidationResult
    """
    return security_validator.validate_and_sanitize_input(
        value,
        validation_type="comprehensive",
        max_length=max_length
    )
