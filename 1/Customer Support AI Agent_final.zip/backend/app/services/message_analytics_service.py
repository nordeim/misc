"""
Message Analytics Service for comprehensive analytics and insights.
"""

import logging
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from collections import defaultdict, Counter
import statistics
import asyncio

from sqlalchemy import select, func, desc, and_, or_, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.message import MessageORM
from app.models.session import SessionORM

logger = logging.getLogger(__name__)


class MessageAnalyticsService:
    """Comprehensive message analytics and insights service."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    # ============================================================================
    # MESSAGE INTERACTION TRACKING
    # ============================================================================
    
    async def track_message_interaction(
        self, 
        user_message: MessageORM, 
        assistant_message: MessageORM, 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Track and analyze user message interactions."""
        try:
            # Calculate response time
            response_time = (assistant_message.created_at - user_message.created_at).total_seconds()
            
            # Analyze content characteristics
            user_content_analysis = await self._analyze_content_characteristics(user_message.content)
            assistant_content_analysis = await self._analyze_content_characteristics(assistant_message.content)
            
            # Get session context
            session_result = await db.execute(
                select(SessionORM).where(SessionORM.id == user_message.session_id)
            )
            session = session_result.scalar_one_or_none()
            
            interaction_data = {
                "timestamp": datetime.utcnow().isoformat(),
                "session_id": user_message.session_id,
                "user_message_id": user_message.id,
                "assistant_message_id": assistant_message.id,
                "response_time_seconds": response_time,
                "user_content_metrics": user_content_analysis,
                "assistant_content_metrics": assistant_content_analysis,
                "token_usage": {
                    "prompt_tokens": assistant_message.prompt_tokens,
                    "completion_tokens": assistant_message.completion_tokens,
                    "total_tokens": assistant_message.total_tokens,
                    "cost_usd": assistant_message.cost_usd
                },
                "confidence_score": assistant_message.confidence_score,
                "has_attachments": bool(user_message.attachments or assistant_message.attachments),
                "session_context": {
                    "session_type": session.session_type if session else "unknown",
                    "user_feedback": session.user_feedback if session else None,
                    "session_rating": session.rating if session else None
                }
            }
            
            # Store interaction data in message metadata for later analysis
            if user_message.metadata is None:
                user_message.metadata = {}
            user_message.metadata["interaction_data"] = interaction_data
            
            await db.flush()
            
            return interaction_data
            
        except Exception as e:
            self.logger.error(f"Error tracking message interaction: {str(e)}")
            return {"error": str(e)}
    
    # ============================================================================
    # COMPREHENSIVE ANALYTICS
    # ============================================================================
    
    async def get_comprehensive_analytics(
        self, 
        analytics_params: Dict[str, Any], 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Get comprehensive message analytics with multiple dimensions."""
        try:
            # Build base query with filters
            query = select(MessageORM).join(SessionORM, MessageORM.session_id == SessionORM.id)
            conditions = []
            
            # Apply filters
            if analytics_params.get("session_id"):
                conditions.append(MessageORM.session_id == analytics_params["session_id"])
            
            if analytics_params.get("user_id"):
                conditions.append(SessionORM.user_id == analytics_params["user_id"])
            
            if analytics_params.get("date_from"):
                conditions.append(MessageORM.created_at >= analytics_params["date_from"])
            
            if analytics_params.get("date_to"):
                conditions.append(MessageORM.created_at <= analytics_params["date_to"])
            
            if conditions:
                query = query.where(and_(*conditions))
            
            # Execute query
            result = await db.execute(query)
            messages = result.scalars().all()
            
            # Perform comprehensive analysis
            analytics = {
                "overview": await self._generate_overview_analytics(messages),
                "temporal": await self._generate_temporal_analytics(messages, analytics_params.get("granularities", ["day"])),
                "content": await self._generate_content_analytics(messages),
                "performance": await self._generate_performance_analytics(messages),
                "user_behavior": await self._generate_user_behavior_analytics(messages),
                "system_metrics": await self._generate_system_metrics(messages),
                "generated_at": datetime.utcnow().isoformat(),
                "data_range": {
                    "date_from": analytics_params.get("date_from"),
                    "date_to": analytics_params.get("date_to"),
                    "session_id": analytics_params.get("session_id"),
                    "user_id": analytics_params.get("user_id")
                }
            }
            
            return analytics
            
        except Exception as e:
            self.logger.error(f"Error generating comprehensive analytics: {str(e)}")
            return {"error": str(e), "generated_at": datetime.utcnow().isoformat()}
    
    # ============================================================================
    # RESPONSE TIME ANALYTICS
    # ============================================================================
    
    async def get_response_time_analytics(
        self,
        session_id: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get response time analytics for message processing."""
        try:
            # Get assistant messages with timing data
            query = select(MessageORM).where(MessageORM.role == "assistant")
            
            if session_id:
                query = query.where(MessageORM.session_id == session_id)
            
            if date_from:
                query = query.where(MessageORM.created_at >= date_from)
            
            if date_to:
                query = query.where(MessageORM.created_at <= date_to)
            
            result = await db.execute(query)
            assistant_messages = result.scalars().all()
            
            # Calculate response times by finding corresponding user messages
            response_times = []
            for assistant_msg in assistant_messages:
                # Find the user message that prompted this response
                user_msg_result = await db.execute(
                    select(MessageORM)
                    .where(
                        and_(
                            MessageORM.session_id == assistant_msg.session_id,
                            MessageORM.role == "user",
                            MessageORM.created_at < assistant_msg.created_at
                        )
                    )
                    .order_by(desc(MessageORM.created_at))
                    .limit(1)
                )
                
                user_msg = user_msg_result.scalar_one_or_none()
                if user_msg:
                    response_time = (assistant_msg.created_at - user_msg.created_at).total_seconds()
                    response_times.append(response_time)
            
            # Calculate statistics
            if response_times:
                analytics = {
                    "response_time_stats": {
                        "mean": statistics.mean(response_times),
                        "median": statistics.median(response_times),
                        "min": min(response_times),
                        "max": max(response_times),
                        "std_dev": statistics.stdev(response_times) if len(response_times) > 1 else 0,
                        "percentiles": {
                            "p25": self._calculate_percentile(response_times, 25),
                            "p50": self._calculate_percentile(response_times, 50),
                            "p75": self._calculate_percentile(response_times, 75),
                            "p90": self._calculate_percentile(response_times, 90),
                            "p95": self._calculate_percentile(response_times, 95)
                        }
                    },
                    "response_time_distribution": await self._create_response_time_distribution(response_times),
                    "total_responses": len(response_times),
                    "time_range": {
                        "date_from": date_from.isoformat() if date_from else None,
                        "date_to": date_to.isoformat() if date_to else None,
                        "session_id": session_id
                    }
                }
            else:
                analytics = {
                    "response_time_stats": None,
                    "response_time_distribution": {},
                    "total_responses": 0,
                    "message": "No response time data found for the specified filters"
                }
            
            analytics["generated_at"] = datetime.utcnow().isoformat()
            return analytics
            
        except Exception as e:
            self.logger.error(f"Error generating response time analytics: {str(e)}")
            return {"error": str(e), "generated_at": datetime.utcnow().isoformat()}
    
    # ============================================================================
    # USER INTERACTION ANALYTICS
    # ============================================================================
    
    async def get_user_interaction_analytics(
        self,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get user interaction analytics and patterns."""
        try:
            # Build query
            query = select(MessageORM, SessionORM).join(
                SessionORM, MessageORM.session_id == SessionORM.id
            )
            
            conditions = []
            if user_id:
                conditions.append(SessionORM.user_id == user_id)
            
            if session_id:
                conditions.append(MessageORM.session_id == session_id)
            
            if date_from:
                conditions.append(MessageORM.created_at >= date_from)
            
            if date_to:
                conditions.append(MessageORM.created_at <= date_to)
            
            if conditions:
                query = query.where(and_(*conditions))
            
            result = await db.execute(query)
            message_session_pairs = result.all()
            
            if not message_session_pairs:
                return {
                    "error": "No interaction data found",
                    "generated_at": datetime.utcnow().isoformat()
                }
            
            # Analyze interactions
            analytics = {
                "user_activity": await self._analyze_user_activity(message_session_pairs, user_id),
                "session_patterns": await self._analyze_session_patterns(message_session_pairs),
                "engagement_metrics": await self._analyze_engagement_metrics(message_session_pairs),
                "content_preferences": await self._analyze_content_preferences(message_session_pairs),
                "temporal_patterns": await self._analyze_temporal_patterns(message_session_pairs),
                "interaction_quality": await self._analyze_interaction_quality(message_session_pairs),
                "generated_at": datetime.utcnow().isoformat()
            }
            
            return analytics
            
        except Exception as e:
            self.logger.error(f"Error generating user interaction analytics: {str(e)}")
            return {"error": str(e), "generated_at": datetime.utcnow().isoformat()}
    
    # ============================================================================
    # MESSAGE EFFECTIVENESS ANALYTICS
    # ============================================================================
    
    async def get_effectiveness_analytics(
        self,
        session_id: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get message effectiveness tracking and analysis."""
        try:
            # Get sessions with feedback data
            query = select(SessionORM)
            
            if session_id:
                query = query.where(SessionORM.id == session_id)
            
            if date_from:
                query = query.where(SessionORM.started_at >= date_from)
            
            if date_to:
                query = query.where(SessionORM.started_at <= date_to)
            
            result = await db.execute(query)
            sessions = result.scalars().all()
            
            # Get messages for these sessions
            session_ids = [s.id for s in sessions]
            if session_ids:
                messages_result = await db.execute(
                    select(MessageORM).where(MessageORM.session_id.in_(session_ids))
                )
                messages = messages_result.scalars().all()
            else:
                messages = []
            
            # Analyze effectiveness
            analytics = {
                "session_effectiveness": await self._analyze_session_effectiveness(sessions),
                "message_effectiveness": await self._analyze_message_effectiveness(messages),
                "feedback_analysis": await self._analyze_feedback_patterns(sessions),
                "resolution_analysis": await self._analyze_resolution_patterns(sessions, messages),
                "user_satisfaction": await self._analyze_user_satisfaction(sessions),
                "generated_at": datetime.utcnow().isoformat()
            }
            
            return analytics
            
        except Exception as e:
            self.logger.error(f"Error generating effectiveness analytics: {str(e)}")
            return {"error": str(e), "generated_at": datetime.utcnow().isoformat()}
    
    # ============================================================================
    # COMPREHENSIVE INSIGHTS GENERATION
    # ============================================================================
    
    async def generate_comprehensive_insights(
        self,
        insight_config: Dict[str, Any],
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Generate comprehensive message insights and patterns."""
        try:
            # Get comprehensive analytics
            analytics = await self.get_comprehensive_analytics(
                insight_config.get("filters", {}), db
            )
            
            # Generate insights
            insights = {
                "key_insights": await self._generate_key_insights(analytics),
                "patterns": await self._identify_patterns(analytics),
                "trends": await self._identify_trends(analytics),
                "anomalies": await self._identify_anomalies(analytics),
                "recommendations": await self._generate_recommendations(analytics),
                "summary": await self._generate_insight_summary(analytics),
                "visualization_data": await self._generate_visualization_data(analytics),
                "generated_at": datetime.utcnow().isoformat(),
                "config": insight_config
            }
            
            return insights
            
        except Exception as e:
            self.logger.error(f"Error generating comprehensive insights: {str(e)}")
            return {"error": str(e), "generated_at": datetime.utcnow().isoformat()}
    
    # ============================================================================
    # PRIVATE HELPER METHODS
    # ============================================================================
    
    async def _analyze_content_characteristics(self, content: str) -> Dict[str, Any]:
        """Analyze content characteristics."""
        try:
            import re
            
            # Basic metrics
            word_count = len(content.split())
            char_count = len(content)
            sentence_count = len(re.split(r'[.!?]+', content)) - 1 if content else 0
            
            # Readability metrics (simplified)
            avg_word_length = sum(len(word) for word in content.split()) / max(word_count, 1)
            
            # Content type detection
            has_questions = '?' in content
            has_exclamations = '!' in content
            has_urls = bool(re.search(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', content))
            has_code = bool(re.search(r'```|```[a-zA-Z]*|`[^`]+`', content))
            
            return {
                "word_count": word_count,
                "character_count": char_count,
                "sentence_count": sentence_count,
                "average_word_length": round(avg_word_length, 2),
                "has_questions": has_questions,
                "has_exclamations": has_exclamations,
                "has_urls": has_urls,
                "has_code_blocks": has_code,
                "content_complexity": self._calculate_content_complexity(content)
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing content characteristics: {str(e)}")
            return {}
    
    def _calculate_content_complexity(self, content: str) -> str:
        """Calculate content complexity level."""
        try:
            words = content.split()
            if not words:
                return "minimal"
            
            avg_word_length = sum(len(word) for word in words) / len(words)
            
            if avg_word_length < 4 and len(words) < 10:
                return "simple"
            elif avg_word_length < 6 and len(words) < 25:
                return "moderate"
            elif avg_word_length < 8 and len(words) < 50:
                return "complex"
            else:
                return "advanced"
                
        except Exception:
            return "unknown"
    
    def _calculate_percentile(self, data: List[float], percentile: int) -> float:
        """Calculate percentile from data."""
        try:
            sorted_data = sorted(data)
            index = (percentile / 100) * (len(sorted_data) - 1)
            
            if index.is_integer():
                return sorted_data[int(index)]
            else:
                lower_index = int(index)
                upper_index = lower_index + 1
                weight = index - lower_index
                return sorted_data[lower_index] * (1 - weight) + sorted_data[upper_index] * weight
                
        except Exception:
            return 0.0
    
    async def _create_response_time_distribution(self, response_times: List[float]) -> Dict[str, Any]:
        """Create response time distribution buckets."""
        try:
            buckets = {
                "very_fast": {"min": 0, "max": 1, "count": 0},
                "fast": {"min": 1, "max": 3, "count": 0},
                "normal": {"min": 3, "max": 10, "count": 0},
                "slow": {"min": 10, "max": 30, "count": 0},
                "very_slow": {"min": 30, "max": float('inf'), "count": 0}
            }
            
            for rt in response_times:
                for bucket_name, bucket_info in buckets.items():
                    if bucket_info["min"] <= rt < bucket_info["max"]:
                        bucket_info["count"] += 1
                        break
            
            total_count = len(response_times)
            for bucket in buckets.values():
                bucket["percentage"] = round((bucket["count"] / total_count * 100), 2) if total_count > 0 else 0
            
            return buckets
            
        except Exception as e:
            self.logger.error(f"Error creating response time distribution: {str(e)}")
            return {}
    
    # Placeholder methods for more complex analytics
    # These would be implemented with actual logic
    
    async def _generate_overview_analytics(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Generate overview analytics from messages."""
        return {"total_messages": len(messages)}
    
    async def _generate_temporal_analytics(self, messages: List[MessageORM], granularities: List[str]) -> Dict[str, Any]:
        """Generate temporal analytics from messages."""
        return {"temporal_data": "placeholder"}
    
    async def _generate_content_analytics(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Generate content analytics from messages."""
        return {"content_analysis": "placeholder"}
    
    async def _generate_performance_analytics(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Generate performance analytics from messages."""
        return {"performance_metrics": "placeholder"}
    
    async def _generate_user_behavior_analytics(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Generate user behavior analytics from messages."""
        return {"behavior_patterns": "placeholder"}
    
    async def _generate_system_metrics(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Generate system metrics from messages."""
        return {"system_performance": "placeholder"}
    
    async def _analyze_user_activity(self, message_session_pairs: List[tuple], user_id: Optional[str]) -> Dict[str, Any]:
        """Analyze user activity patterns."""
        return {"activity_metrics": "placeholder"}
    
    async def _analyze_session_patterns(self, message_session_pairs: List[tuple]) -> Dict[str, Any]:
        """Analyze session patterns."""
        return {"session_analysis": "placeholder"}
    
    async def _analyze_engagement_metrics(self, message_session_pairs: List[tuple]) -> Dict[str, Any]:
        """Analyze engagement metrics."""
        return {"engagement_data": "placeholder"}
    
    async def _analyze_content_preferences(self, message_session_pairs: List[tuple]) -> Dict[str, Any]:
        """Analyze content preferences."""
        return {"preferences": "placeholder"}
    
    async def _analyze_temporal_patterns(self, message_session_pairs: List[tuple]) -> Dict[str, Any]:
        """Analyze temporal patterns."""
        return {"temporal_insights": "placeholder"}
    
    async def _analyze_interaction_quality(self, message_session_pairs: List[tuple]) -> Dict[str, Any]:
        """Analyze interaction quality."""
        return {"quality_metrics": "placeholder"}
    
    async def _analyze_session_effectiveness(self, sessions: List[SessionORM]) -> Dict[str, Any]:
        """Analyze session effectiveness."""
        return {"effectiveness_scores": "placeholder"}
    
    async def _analyze_message_effectiveness(self, messages: List[MessageORM]) -> Dict[str, Any]:
        """Analyze message effectiveness."""
        return {"message_metrics": "placeholder"}
    
    async def _analyze_feedback_patterns(self, sessions: List[SessionORM]) -> Dict[str, Any]:
        """Analyze feedback patterns."""
        return {"feedback_analysis": "placeholder"}
    
    async def _analyze_resolution_patterns(self, sessions: List[SessionORM], messages: List[MessageORM]) -> Dict[str, Any]:
        """Analyze resolution patterns."""
        return {"resolution_metrics": "placeholder"}
    
    async def _analyze_user_satisfaction(self, sessions: List[SessionORM]) -> Dict[str, Any]:
        """Analyze user satisfaction."""
        return {"satisfaction_scores": "placeholder"}
    
    async def _generate_key_insights(self, analytics: Dict[str, Any]) -> List[str]:
        """Generate key insights from analytics."""
        return ["Key insights would be generated here based on analytics data"]
    
    async def _identify_patterns(self, analytics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify patterns in the data."""
        return [{"pattern": "Pattern identification would be implemented here"}]
    
    async def _identify_trends(self, analytics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify trends in the data."""
        return [{"trend": "Trend analysis would be implemented here"}]
    
    async def _identify_anomalies(self, analytics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify anomalies in the data."""
        return [{"anomaly": "Anomaly detection would be implemented here"}]
    
    async def _generate_recommendations(self, analytics: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on analytics."""
        return ["Recommendations would be generated based on insights"]
    
    async def _generate_insight_summary(self, analytics: Dict[str, Any]) -> Dict[str, Any]:
        """Generate summary of insights."""
        return {"summary": "Summary of all insights and findings"}
    
    async def _generate_visualization_data(self, analytics: Dict[str, Any]) -> Dict[str, Any]:
        """Generate data for visualizations."""
        return {"charts": "Data for charts and visualizations would be generated here"}