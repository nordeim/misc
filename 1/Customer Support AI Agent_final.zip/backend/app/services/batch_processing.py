"""
Advanced Batch Processing Module for Embeddings.

This module provides comprehensive batch processing capabilities:
- Large-scale batch embedding generation
- Parallel processing with worker management
- Progress tracking with callbacks and cancellation
- Resource management and optimization
- Memory-efficient processing for large datasets
- Queue-based processing with priority support
- Error handling and retry mechanisms

Features:
- Configurable batch sizes and parallel workers
- Real-time progress tracking and reporting
- Memory management and cleanup
- Cancellation and pause/resume support
- Error recovery and retry logic
- Performance monitoring and analytics
- Queue-based processing system

Author: AI Agent System
Version: 2.0.0
"""

import asyncio
import json
import logging
import time
import traceback
from collections import deque, defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, AsyncGenerator, Set
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import uuid

import numpy as np
import psutil
from queue import Queue, Empty
import threading
from threading import Lock, Event

from app.services.embedding_service import EmbeddingService, EmbeddingResult, BatchProcessingResult

logger = logging.getLogger(__name__)

# ==============================================================================
# ENUMS AND CONSTANTS
# ==============================================================================

class BatchStatus(Enum):
    """Batch processing status."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"

class Priority(Enum):
    """Batch processing priority levels."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

class ProcessingMode(Enum):
    """Batch processing modes."""
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    MIXED = "mixed"

# Configuration constants
DEFAULT_BATCH_SIZE = 32
MAX_BATCH_SIZE = 100
DEFAULT_MAX_WORKERS = 4
MAX_WORKERS = 16
MEMORY_THRESHOLD_PERCENT = 80
PROGRESS_UPDATE_INTERVAL = 1.0  # seconds
CLEANUP_INTERVAL = 300  # 5 minutes

# ==============================================================================
# DATA STRUCTURES
# ==============================================================================

@dataclass
class BatchJob:
    """Represents a batch processing job."""
    job_id: str
    texts: List[str]
    model_name: str
    priority: Priority
    status: BatchStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    total_items: int = 0
    processed_items: int = 0
    successful_items: int = 0
    failed_items: int = 0
    error_messages: List[str] = None
    results: List[EmbeddingResult] = None
    metadata: Dict[str, Any] = None
    retry_count: int = 0
    max_retries: int = 3
    
    def __post_init__(self):
        if self.error_messages is None:
            self.error_messages = []
        if self.results is None:
            self.results = []
        if self.metadata is None:
            self.metadata = {}
        self.total_items = len(self.texts)

@dataclass
class WorkerInfo:
    """Information about a worker process."""
    worker_id: str
    status: str  # "idle", "busy", "error", "stopped"
    current_job_id: Optional[str] = None
    items_processed: int = 0
    items_successful: int = 0
    items_failed: int = 0
    start_time: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    error_message: Optional[str] = None

@dataclass
class BatchProgress:
    """Progress information for batch processing."""
    job_id: str
    status: BatchStatus
    total_items: int
    processed_items: int
    successful_items: int
    failed_items: int
    progress_percentage: float
    estimated_time_remaining: Optional[float]
    current_throughput: float
    memory_usage_mb: float
    worker_count: int
    active_workers: int
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

@dataclass
class ProcessingStats:
    """Overall processing statistics."""
    total_jobs: int = 0
    completed_jobs: int = 0
    failed_jobs: int = 0
    total_items_processed: int = 0
    total_processing_time: float = 0.0
    average_throughput: float = 0.0
    peak_memory_usage_mb: float = 0.0
    average_latency: float = 0.0
    error_rate: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

# ==============================================================================
# PROGRESS TRACKER
# ==============================================================================

class ProgressTracker:
    """Tracks progress of batch processing jobs."""
    
    def __init__(self):
        self.job_progress: Dict[str, BatchProgress] = {}
        self.callbacks: Dict[str, List[Callable]] = defaultdict(list)
        self.lock = Lock()
        self.last_update = {}
    
    def add_callback(self, job_id: str, callback: Callable):
        """Add a progress callback for a job."""
        with self.lock:
            self.callbacks[job_id].append(callback)
    
    def remove_callback(self, job_id: str, callback: Callable):
        """Remove a progress callback."""
        with self.lock:
            if job_id in self.callbacks:
                if callback in self.callbacks[job_id]:
                    self.callbacks[job_id].remove(callback)
    
    def update_progress(
        self,
        job_id: str,
        status: BatchStatus,
        total_items: int,
        processed_items: int,
        successful_items: int,
        failed_items: int,
        throughput: float = 0.0,
        estimated_time_remaining: Optional[float] = None
    ):
        """Update progress for a job."""
        progress_percentage = (processed_items / total_items * 100) if total_items > 0 else 0
        
        # Get current memory usage
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        
        progress = BatchProgress(
            job_id=job_id,
            status=status,
            total_items=total_items,
            processed_items=processed_items,
            successful_items=successful_items,
            failed_items=failed_items,
            progress_percentage=progress_percentage,
            estimated_time_remaining=estimated_time_remaining,
            current_throughput=throughput,
            memory_usage_mb=memory_mb,
            worker_count=0,  # Will be updated by batch processor
            active_workers=0  # Will be updated by batch processor
        )
        
        with self.lock:
            self.job_progress[job_id] = progress
            self.last_update[job_id] = time.time()
            
            # Trigger callbacks
            for callback in self.callbacks[job_id]:
                try:
                    callback(progress)
                except Exception as e:
                    logger.error(f"Progress callback error: {e}")
    
    def get_progress(self, job_id: str) -> Optional[BatchProgress]:
        """Get progress for a specific job."""
        with self.lock:
            return self.job_progress.get(job_id)
    
    def get_all_progress(self) -> Dict[str, BatchProgress]:
        """Get progress for all jobs."""
        with self.lock:
            return self.job_progress.copy()
    
    def cleanup_old_progress(self, max_age_hours: int = 24):
        """Clean up old progress entries."""
        cutoff_time = time.time() - (max_age_hours * 3600)
        
        with self.lock:
            jobs_to_remove = []
            for job_id, update_time in self.last_update.items():
                if update_time < cutoff_time:
                    jobs_to_remove.append(job_id)
            
            for job_id in jobs_to_remove:
                self.job_progress.pop(job_id, None)
                self.callbacks.pop(job_id, None)
                self.last_update.pop(job_id, None)

# ==============================================================================
# WORKER MANAGER
# ==============================================================================

class WorkerManager:
    """Manages worker processes for parallel batch processing."""
    
    def __init__(
        self,
        embedding_service: EmbeddingService,
        max_workers: int = DEFAULT_MAX_WORKERS,
        processing_mode: ProcessingMode = ProcessingMode.PARALLEL
    ):
        self.embedding_service = embedding_service
        self.max_workers = max(1, min(max_workers, MAX_WORKERS))
        self.processing_mode = processing_mode
        
        self.workers: Dict[str, WorkerInfo] = {}
        self.worker_queue = asyncio.Queue()
        self.active_jobs: Set[str] = set()
        self.worker_tasks: Dict[str, asyncio.Task] = {}
        
        self.shutdown_event = asyncio.Event()
        self.worker_lock = Lock()
        
        # Performance tracking
        self.total_items_processed = 0
        self.total_successful = 0
        self.total_failed = 0
        self.throughput_history = deque(maxlen=100)
        
        logger.info(f"Worker manager initialized with {self.max_workers} workers in {processing_mode.value} mode")
    
    async def start_workers(self):
        """Start worker processes."""
        for i in range(self.max_workers):
            worker_id = f"worker_{i}"
            worker_info = WorkerInfo(
                worker_id=worker_id,
                status="idle",
                start_time=datetime.now()
            )
            
            with self.worker_lock:
                self.workers[worker_id] = worker_info
            
            # Start worker task
            task = asyncio.create_task(self._worker_loop(worker_id))
            self.worker_tasks[worker_id] = task
            
            # Add to queue
            await self.worker_queue.put(worker_id)
        
        logger.info(f"Started {self.max_workers} workers")
    
    async def stop_workers(self):
        """Stop all workers."""
        self.shutdown_event.set()
        
        # Cancel all worker tasks
        for task in self.worker_tasks.values():
            task.cancel()
        
        # Wait for tasks to complete
        if self.worker_tasks:
            await asyncio.gather(*self.worker_tasks.values(), return_exceptions=True)
        
        self.worker_tasks.clear()
        self.workers.clear()
        
        logger.info("All workers stopped")
    
    async def _worker_loop(self, worker_id: str):
        """Main worker loop."""
        while not self.shutdown_event.is_set():
            try:
                # Get job from queue with timeout
                job_id = await asyncio.wait_for(
                    self.worker_queue.get(),
                    timeout=1.0
                )
                
                # Process job
                await self._process_job(worker_id, job_id)
                
            except asyncio.TimeoutError:
                # No job available, continue
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")
                
                with self.worker_lock:
                    if worker_id in self.workers:
                        self.workers[worker_id].status = "error"
                        self.workers[worker_id].error_message = str(e)
                
                # Return worker to queue after delay
                await asyncio.sleep(5)
                await self.worker_queue.put(worker_id)
    
    async def _process_job(self, worker_id: str, job_id: str):
        """Process a single job."""
        job = self._get_job_by_id(job_id)
        if not job:
            logger.warning(f"Job {job_id} not found")
            return
        
        # Update worker status
        with self.worker_lock:
            self.workers[worker_id].status = "busy"
            self.workers[worker_id].current_job_id = job_id
            self.workers[worker_id].last_activity = datetime.now()
        
        try:
            # Process batch
            start_time = time.time()
            results = await self.embedding_service.generate_embeddings_batch(
                texts=job.texts,
                model_name=job.model_name,
                batch_size=min(DEFAULT_BATCH_SIZE, len(job.texts)),
                use_cache=True,
                preprocess=True
            )
            
            processing_time = time.time() - start_time
            
            # Update job results
            job.results.extend(results.results)
            job.processed_items = results.successful
            job.successful_items = results.successful
            job.failed_items = results.failed
            job.status = BatchStatus.COMPLETED
            job.completed_at = datetime.now()
            
            # Update statistics
            self.total_items_processed += results.successful
            self.total_successful += results.successful
            self.total_failed += results.failed
            
            # Calculate throughput
            throughput = results.successful / processing_time if processing_time > 0 else 0
            self.throughput_history.append(throughput)
            
            logger.info(f"Worker {worker_id} completed job {job_id}: {results.successful}/{len(job.texts)} successful")
            
        except Exception as e:
            logger.error(f"Worker {worker_id} failed to process job {job_id}: {e}")
            
            job.error_messages.append(f"Worker {worker_id} error: {str(e)}")
            job.failed_items += len(job.texts) - job.processed_items
            job.status = BatchStatus.FAILED
            job.completed_at = datetime.now()
            
            self.total_failed += len(job.texts) - job.processed_items
        
        finally:
            # Update worker status
            with self.worker_lock:
                self.workers[worker_id].status = "idle"
                self.workers[worker_id].current_job_id = None
                self.workers[worker_id].last_activity = datetime.now()
                
                # Update worker stats
                worker_info = self.workers[worker_id]
                worker_info.items_processed += job.processed_items
                worker_info.items_successful += job.successful_items
                worker_info.items_failed += job.failed_items
            
            # Return worker to queue
            await self.worker_queue.put(worker_id)
    
    def _get_job_by_id(self, job_id: str) -> Optional[BatchJob]:
        """Get job by ID (to be implemented by batch processor)."""
        # This should be implemented by the batch processor
        # For now, raise an error to indicate it needs to be overridden
        raise NotImplementedError("Batch processor must implement _get_job_by_id")
    
    async def submit_job(self, job: BatchJob) -> str:
        """Submit a job for processing."""
        job.status = BatchStatus.PENDING
        job.created_at = datetime.now()
        
        # This should be implemented by the batch processor
        # to add the job to the job queue
        raise NotImplementedError("Batch processor must implement submit_job")
    
    def get_worker_status(self) -> Dict[str, WorkerInfo]:
        """Get status of all workers."""
        with self.worker_lock:
            return self.workers.copy()
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics."""
        with self.worker_lock:
            active_workers = sum(1 for w in self.workers.values() if w.status == "busy")
            idle_workers = sum(1 for w in self.workers.values() if w.status == "idle")
            
            avg_throughput = np.mean(self.throughput_history) if self.throughput_history else 0
            
            return {
                "total_workers": len(self.workers),
                "active_workers": active_workers,
                "idle_workers": idle_workers,
                "total_items_processed": self.total_items_processed,
                "total_successful": self.total_successful,
                "total_failed": self.total_failed,
                "average_throughput": avg_throughput,
                "processing_mode": self.processing_mode.value
            }

# ==============================================================================
# MAIN BATCH PROCESSOR
# ==============================================================================

class BatchProcessor:
    """
    Advanced batch processor for embeddings with comprehensive features.
    
    Features:
    - Queue-based job management with priority support
    - Parallel processing with configurable workers
    - Real-time progress tracking and callbacks
    - Cancellation and pause/resume capabilities
    - Memory management and resource optimization
    - Error handling and retry mechanisms
    - Performance monitoring and analytics
    """
    
    def __init__(
        self,
        embedding_service: EmbeddingService,
        max_workers: int = DEFAULT_MAX_WORKERS,
        processing_mode: ProcessingMode = ProcessingMode.PARALLEL,
        memory_limit_mb: int = 2048
    ):
        self.embedding_service = embedding_service
        self.worker_manager = WorkerManager(
            embedding_service=embedding_service,
            max_workers=max_workers,
            processing_mode=processing_mode
        )
        self.progress_tracker = ProgressTracker()
        self.job_queue = asyncio.PriorityQueue()
        self.jobs: Dict[str, BatchJob] = {}
        self.memory_limit_mb = memory_limit_mb
        
        self.shutdown_event = asyncio.Event()
        self.processor_task = None
        self.cleanup_task = None
        
        # Statistics
        self.stats = ProcessingStats()
        self.start_time = datetime.now()
        
        # Link worker manager to processor
        self.worker_manager._get_job_by_id = self._get_job_by_id
        self.worker_manager.submit_job = self._submit_job_to_queue
        
        logger.info(f"Batch processor initialized with {processing_mode.value} mode")
    
    async def initialize(self):
        """Initialize the batch processor."""
        logger.info("Initializing batch processor...")
        
        # Start worker manager
        await self.worker_manager.start_workers()
        
        # Start processor tasks
        self.processor_task = asyncio.create_task(self._processor_loop())
        self.cleanup_task = asyncio.create_task(self._cleanup_loop())
        
        logger.info("Batch processor initialized successfully")
    
    async def shutdown(self):
        """Shutdown the batch processor gracefully."""
        logger.info("Shutting down batch processor...")
        
        # Signal shutdown
        self.shutdown_event.set()
        
        # Cancel active jobs
        for job_id in list(self.jobs.keys()):
            await self.cancel_job(job_id)
        
        # Stop worker manager
        await self.worker_manager.stop_workers()
        
        # Cancel processor tasks
        if self.processor_task:
            self.processor_task.cancel()
            try:
                await self.processor_task
            except asyncio.CancelledError:
                pass
        
        if self.cleanup_task:
            self.cleanup_task.cancel()
            try:
                await self.cleanup_task
            except asyncio.CancelledError:
                pass
        
        logger.info("Batch processor shutdown complete")
    
    async def submit_batch(
        self,
        texts: List[str],
        model_name: str = None,
        priority: Priority = Priority.NORMAL,
        metadata: Dict[str, Any] = None,
        max_retries: int = 3
    ) -> str:
        """
        Submit a batch job for processing.
        
        Args:
            texts: List of texts to process
            model_name: Model name (uses primary if None)
            priority: Job priority level
            metadata: Additional metadata
            max_retries: Maximum retry attempts
            
        Returns:
            Job ID for tracking
        """
        if not texts:
            raise ValueError("Text list cannot be empty")
        
        job_id = f"batch_{uuid.uuid4().hex[:12]}"
        
        job = BatchJob(
            job_id=job_id,
            texts=texts.copy(),
            model_name=model_name,
            priority=priority,
            status=BatchStatus.PENDING,
            created_at=datetime.now(),
            metadata=metadata or {},
            max_retries=max_retries
        )
        
        # Store job
        self.jobs[job_id] = job
        
        # Update statistics
        self.stats.total_jobs += 1
        
        # Add to queue (negative priority for max-heap behavior)
        priority_value = -priority.value  # Higher priority = lower negative value
        await self.job_queue.put((priority_value, job_id, job))
        
        logger.info(f"Submitted batch job {job_id} with {len(texts)} texts, priority {priority.name}")
        
        return job_id
    
    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job."""
        if job_id not in self.jobs:
            return False
        
        job = self.jobs[job_id]
        
        if job.status in [BatchStatus.COMPLETED, BatchStatus.CANCELLED, BatchStatus.FAILED]:
            return False
        
        job.status = BatchStatus.CANCELLED
        job.completed_at = datetime.now()
        
        logger.info(f"Cancelled job {job_id}")
        return True
    
    async def pause_job(self, job_id: str) -> bool:
        """Pause a running job."""
        if job_id not in self.jobs:
            return False
        
        job = self.jobs[job_id]
        
        if job.status != BatchStatus.RUNNING:
            return False
        
        job.status = BatchStatus.PAUSED
        logger.info(f"Paused job {job_id}")
        return True
    
    async def resume_job(self, job_id: str) -> bool:
        """Resume a paused job."""
        if job_id not in self.jobs:
            return False
        
        job = self.jobs[job_id]
        
        if job.status != BatchStatus.PAUSED:
            return False
        
        job.status = BatchStatus.PENDING
        job.retry_count += 1
        
        # Add back to queue
        priority_value = -job.priority.value
        await self.job_queue.put((priority_value, job_id, job))
        
        logger.info(f"Resumed job {job_id}")
        return True
    
    async def get_job_status(self, job_id: str) -> Optional[BatchJob]:
        """Get status of a specific job."""
        return self.jobs.get(job_id)
    
    async def get_all_jobs(self) -> List[BatchJob]:
        """Get status of all jobs."""
        return list(self.jobs.values())
    
    def add_progress_callback(self, job_id: str, callback: Callable):
        """Add a progress callback for a job."""
        self.progress_tracker.add_callback(job_id, callback)
    
    def remove_progress_callback(self, job_id: str, callback: Callable):
        """Remove a progress callback."""
        self.progress_tracker.remove_callback(job_id, callback)
    
    async def _processor_loop(self):
        """Main processing loop."""
        while not self.shutdown_event.is_set():
            try:
                # Check memory usage
                await self._check_memory_usage()
                
                # Process jobs from queue
                try:
                    priority, job_id, job = await asyncio.wait_for(
                        self.job_queue.get(),
                        timeout=1.0
                    )
                    
                    if job.status == BatchStatus.CANCELLED:
                        continue
                    
                    # Start job
                    job.status = BatchStatus.RUNNING
                    job.started_at = datetime.now()
                    
                    # Submit to worker
                    await self.worker_manager.submit_job(job)
                    
                except asyncio.TimeoutError:
                    continue
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Processor loop error: {e}")
                await asyncio.sleep(1)
    
    async def _cleanup_loop(self):
        """Cleanup loop for removing old jobs and updating statistics."""
        while not self.shutdown_event.is_set():
            try:
                await asyncio.sleep(CLEANUP_INTERVAL)
                
                # Clean up old completed jobs (older than 24 hours)
                cutoff_time = datetime.now() - timedelta(hours=24)
                jobs_to_remove = []
                
                for job_id, job in self.jobs.items():
                    if job.completed_at and job.completed_at < cutoff_time:
                        jobs_to_remove.append(job_id)
                
                for job_id in jobs_to_remove:
                    del self.jobs[job_id]
                
                # Update statistics
                self._update_statistics()
                
                # Clean up old progress
                self.progress_tracker.cleanup_old_progress()
                
                if jobs_to_remove:
                    logger.info(f"Cleaned up {len(jobs_to_remove)} old jobs")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup loop error: {e}")
    
    async def _check_memory_usage(self):
        """Check memory usage and potentially pause low-priority jobs."""
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        memory_percent = process.memory_percent()
        
        if memory_percent > MEMORY_THRESHOLD_PERCENT:
            logger.warning(f"High memory usage detected: {memory_percent:.1f}% ({memory_mb:.1f}MB)")
            
            # Pause low-priority jobs
            paused_jobs = 0
            for job_id, job in self.jobs.items():
                if (job.status == BatchStatus.RUNNING and 
                    job.priority in [Priority.LOW] and
                    job.retry_count < job.max_retries):
                    
                    job.status = BatchStatus.PAUSED
                    paused_jobs += 1
            
            if paused_jobs > 0:
                logger.info(f"Paused {paused_jobs} low-priority jobs due to memory pressure")
    
    def _update_statistics(self):
        """Update overall processing statistics."""
        completed_jobs = [j for j in self.jobs.values() if j.status == BatchStatus.COMPLETED]
        failed_jobs = [j for j in self.jobs.values() if j.status == BatchStatus.FAILED]
        
        self.stats.completed_jobs = len(completed_jobs)
        self.stats.failed_jobs = len(failed_jobs)
        self.stats.total_items_processed = sum(j.successful_items for j in completed_jobs)
        
        if completed_jobs:
            total_time = sum((j.completed_at - j.created_at).total_seconds() for j in completed_jobs if j.completed_at)
            self.stats.total_processing_time = total_time
            self.stats.average_throughput = self.stats.total_items_processed / total_time if total_time > 0 else 0
            self.stats.average_latency = total_time / len(completed_jobs) if completed_jobs else 0
        
        error_rate = self.stats.failed_jobs / self.stats.total_jobs if self.stats.total_jobs > 0 else 0
        self.stats.error_rate = error_rate
        
        # Update peak memory
        process = psutil.Process()
        current_memory_mb = process.memory_info().rss / 1024 / 1024
        self.stats.peak_memory_usage_mb = max(self.stats.peak_memory_usage_mb, current_memory_mb)
    
    def _get_job_by_id(self, job_id: str) -> Optional[BatchJob]:
        """Get job by ID (used by worker manager)."""
        return self.jobs.get(job_id)
    
    async def _submit_job_to_queue(self, job: BatchJob):
        """Submit job to worker queue (used by worker manager)."""
        # This is a simplified version - in practice, the worker manager
        # would handle job distribution directly
        pass
    
    async def get_performance_report(self) -> Dict[str, Any]:
        """Get comprehensive performance report."""
        uptime = datetime.now() - self.start_time
        
        # Get worker performance
        worker_stats = self.worker_manager.get_performance_stats()
        
        # Get job distribution
        job_distribution = {}
        for status in BatchStatus:
            count = sum(1 for j in self.jobs.values() if j.status == status)
            job_distribution[status.value] = count
        
        # Get active jobs
        active_jobs = [j for j in self.jobs.values() if j.status in [BatchStatus.RUNNING, BatchStatus.PAUSED]]
        
        return {
            "uptime_seconds": uptime.total_seconds(),
            "uptime_hours": uptime.total_seconds() / 3600,
            "statistics": self.stats.to_dict(),
            "worker_performance": worker_stats,
            "job_distribution": job_distribution,
            "active_jobs": len(active_jobs),
            "total_jobs": len(self.jobs),
            "queue_size": self.job_queue.qsize(),
            "memory_limit_mb": self.memory_limit_mb,
            "current_memory_mb": psutil.Process().memory_info().rss / 1024 / 1024
        }
    
    # Context manager support
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.shutdown()

# ==============================================================================
# FACTORY FUNCTION
# ==============================================================================

def create_batch_processor(
    embedding_service: EmbeddingService,
    max_workers: int = DEFAULT_MAX_WORKERS,
    processing_mode: ProcessingMode = ProcessingMode.PARALLEL,
    memory_limit_mb: int = 2048
) -> BatchProcessor:
    """Factory function to create and configure a batch processor."""
    return BatchProcessor(
        embedding_service=embedding_service,
        max_workers=max_workers,
        processing_mode=processing_mode,
        memory_limit_mb=memory_limit_mb
    )

# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

async def process_large_dataset(
    embedding_service: EmbeddingService,
    texts: List[str],
    batch_size: int = 1000,
    max_workers: int = 4,
    progress_callback: Callable = None
) -> List[EmbeddingResult]:
    """
    Process a large dataset efficiently using batch processing.
    
    Args:
        embedding_service: Embedding service instance
        texts: List of texts to process
        batch_size: Size of each batch
        max_workers: Number of parallel workers
        progress_callback: Optional progress callback
        
    Returns:
        List of all embedding results
    """
    if not texts:
        return []
    
    all_results = []
    
    async with create_batch_processor(embedding_service, max_workers=max_workers) as batch_processor:
        # Split texts into batches
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            job_id = await batch_processor.submit_batch(batch_texts)
            
            if progress_callback:
                batch_processor.add_progress_callback(job_id, progress_callback)
            
            # Wait for completion
            while True:
                job = await batch_processor.get_job_status(job_id)
                if job and job.status in [BatchStatus.COMPLETED, BatchStatus.FAILED]:
                    all_results.extend(job.results)
                    break
                await asyncio.sleep(0.1)
    
    return all_results

# ==============================================================================
# GLOBAL INSTANCE
# ==============================================================================

# Global batch processor instance (singleton pattern)
_batch_processor_instance = None

def get_global_batch_processor(
    embedding_service: EmbeddingService,
    max_workers: int = DEFAULT_MAX_WORKERS
) -> BatchProcessor:
    """Get or create global batch processor instance."""
    global _batch_processor_instance
    
    if _batch_processor_instance is None:
        _batch_processor_instance = create_batch_processor(
            embedding_service=embedding_service,
            max_workers=max_workers
        )
    
    return _batch_processor_instance