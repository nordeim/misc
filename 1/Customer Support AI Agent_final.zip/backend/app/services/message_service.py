"""
Message Service for comprehensive message handling operations.
"""

import logging
import json
import uuid
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple, Union
from pathlib import Path
import re
from io import BytesIO

from sqlalchemy import select, func, desc, and_, or_, text
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import UploadFile

from app.models.message import MessageORM
from app.models.session import SessionORM

logger = logging.getLogger(__name__)


class MessageService:
    """Comprehensive message handling service."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.attachment_base_path = Path("./data/uploads")
        self.attachment_base_path.mkdir(parents=True, exist_ok=True)
    
    # ============================================================================
    # CORE MESSAGE OPERATIONS
    # ============================================================================
    
    async def get_message_by_id(self, message_id: str, db: AsyncSession) -> Optional[MessageORM]:
        """Get message by ID with full loading."""
        try:
            result = await db.execute(
                select(MessageORM)
                .where(MessageORM.id == message_id)
                .options(selectinload(MessageORM.session))
            )
            return result.scalar_one_or_none()
        except Exception as e:
            self.logger.error(f"Error getting message by ID: {str(e)}")
            return None
    
    async def get_next_sequence_number(self, session_id: str, db: AsyncSession) -> int:
        """Get the next sequence number for a session."""
        try:
            result = await db.execute(
                select(func.max(MessageORM.sequence_number))
                .where(MessageORM.session_id == session_id)
            )
            max_sequence = result.scalar() or 0
            return max_sequence + 1
        except Exception as e:
            self.logger.error(f"Error getting next sequence number: {str(e)}")
            return 1
    
    async def get_session_messages(
        self, 
        session_id: str, 
        limit: int = 50, 
        offset: int = 0, 
        include_metadata: bool = True,
        sort_order: str = "desc",
        db: AsyncSession = None
    ) -> List[MessageORM]:
        """Get messages for a session with pagination."""
        try:
            query = select(MessageORM).where(MessageORM.session_id == session_id)
            
            # Apply sorting
            if sort_order == "desc":
                query = query.order_by(desc(MessageORM.created_at))
            else:
                query = query.order_by(MessageORM.created_at)
            
            # Apply pagination
            query = query.offset(offset).limit(limit)
            
            result = await db.execute(query)
            return result.scalars().all()
            
        except Exception as e:
            self.logger.error(f"Error getting session messages: {str(e)}")
            return []
    
    async def get_session_messages_paginated(
        self,
        session_id: str,
        limit: int = 50,
        offset: int = 0,
        include_metadata: bool = True,
        sort_order: str = "desc",
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get paginated session messages with metadata."""
        try:
            # Get total count
            count_result = await db.execute(
                select(func.count(MessageORM.id))
                .where(MessageORM.session_id == session_id)
            )
            total_count = count_result.scalar()
            
            # Get messages
            messages = await self.get_session_messages(
                session_id=session_id,
                limit=limit,
                offset=offset,
                include_metadata=include_metadata,
                sort_order=sort_order,
                db=db
            )
            
            return {
                "messages": messages,
                "total_count": total_count
            }
            
        except Exception as e:
            self.logger.error(f"Error getting paginated messages: {str(e)}")
            return {"messages": [], "total_count": 0}
    
    async def get_user_message_history(
        self,
        user_id: str,
        limit: int = 50,
        offset: int = 0,
        session_filter: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        db: AsyncSession = None
    ) -> Dict[str, Any]:
        """Get comprehensive user message history."""
        try:
            # Build base query with joins
            query = (
                select(MessageORM, SessionORM)
                .join(SessionORM, MessageORM.session_id == SessionORM.id)
                .where(SessionORM.user_id == user_id)
            )
            
            # Apply filters
            if session_filter:
                query = query.where(MessageORM.session_id == session_filter)
            
            if date_from:
                query = query.where(MessageORM.created_at >= date_from)
            
            if date_to:
                query = query.where(MessageORM.created_at <= date_to)
            
            # Get total count
            count_query = select(func.count(MessageORM.id)).select_from(
                select(MessageORM)
                .join(SessionORM, MessageORM.session_id == SessionORM.id)
                .where(SessionORM.user_id == user_id)
                .subquery()
            )
            
            if session_filter:
                count_query = count_query.where(MessageORM.session_id == session_filter)
            if date_from:
                count_query = count_query.where(MessageORM.created_at >= date_from)
            if date_to:
                count_query = count_query.where(MessageORM.created_at <= date_to)
            
            count_result = await db.execute(count_query)
            total_count = count_result.scalar()
            
            # Apply pagination and ordering
            query = query.order_by(desc(MessageORM.created_at))
            query = query.offset(offset).limit(limit)
            
            result = await db.execute(query)
            message_session_pairs = result.all()
            
            # Process results
            messages = [pair[0] for pair in message_session_pairs]
            sessions_info = {}
            
            for pair in message_session_pairs:
                message, session = pair
                sessions_info[session.id] = session.to_summary_dict()
            
            return {
                "messages": messages,
                "sessions": sessions_info,
                "total_count": total_count
            }
            
        except Exception as e:
            self.logger.error(f"Error getting user message history: {str(e)}")
            return {"messages": [], "sessions": {}, "total_count": 0}
    
    # ============================================================================
    # SEARCH AND FILTERING
    # ============================================================================
    
    async def search_messages(
        self, 
        search_params: Dict[str, Any], 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Advanced message search with comprehensive filtering."""
        try:
            query = select(MessageORM).join(SessionORM, MessageORM.session_id == SessionORM.id)
            filters = []
            
            # Text search
            if search_params.get("query"):
                query_text = f"%{search_params['query']}%"
                filters.append(MessageORM.content.ilike(query_text))
            
            # Session filter
            if search_params.get("session_id"):
                filters.append(MessageORM.session_id == search_params["session_id"])
            
            # User filter
            if search_params.get("user_id"):
                filters.append(SessionORM.user_id == search_params["user_id"])
            
            # Role filter
            if search_params.get("role"):
                filters.append(MessageORM.role == search_params["role"])
            
            # Content type filter
            if search_params.get("content_type"):
                filters.append(MessageORM.content_type == search_params["content_type"])
            
            # Date range filters
            if search_params.get("date_from"):
                filters.append(MessageORM.created_at >= search_params["date_from"])
            
            if search_params.get("date_to"):
                filters.append(MessageORM.created_at <= search_params["date_to"])
            
            # Attachment filter
            if search_params.get("has_attachments") is not None:
                if search_params["has_attachments"]:
                    filters.append(MessageORM.attachments.isnot(None))
                else:
                    filters.append(MessageORM.attachments.is_(None))
            
            # PII detection filter (from metadata)
            if search_params.get("has_pii") is not None:
                # This would require a more complex query to check metadata
                pass
            
            # Security level filter (from metadata)
            if search_params.get("security_level"):
                # This would require a more complex query to check metadata
                pass
            
            # Apply filters
            if filters:
                query = query.where(and_(*filters))
            
            # Get total count
            count_query = select(func.count(MessageORM.id)).select_from(
                select(MessageORM).join(SessionORM, MessageORM.session_id == SessionORM.id).subquery()
            )
            
            if filters:
                count_query = count_query.where(and_(*filters))
            
            count_result = await db.execute(count_query)
            total_count = count_result.scalar()
            
            # Apply pagination
            query = query.order_by(desc(MessageORM.created_at))
            query = query.offset(search_params["offset"]).limit(search_params["limit"])
            
            result = await db.execute(query)
            messages = result.scalars().all()
            
            return {
                "messages": messages,
                "total_count": total_count
            }
            
        except Exception as e:
            self.logger.error(f"Error searching messages: {str(e)}")
            return {"messages": [], "total_count": 0}
    
    async def advanced_filter_messages(
        self, 
        filters: Dict[str, Any], 
        limit: int, 
        offset: int, 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Advanced filtering with complex query parameters."""
        try:
            # This method would implement more complex filtering logic
            # For now, delegate to the search_messages method
            search_params = {**filters, "limit": limit, "offset": offset}
            return await self.search_messages(search_params, db)
            
        except Exception as e:
            self.logger.error(f"Error in advanced filter: {str(e)}")
            return {"messages": [], "total_count": 0}
    
    # ============================================================================
    # MESSAGE MANAGEMENT
    # ============================================================================
    
    async def update_message(
        self, 
        message_id: str, 
        update_data: Dict[str, Any], 
        db: AsyncSession
    ) -> Optional[MessageORM]:
        """Update an existing message."""
        try:
            message = await self.get_message_by_id(message_id, db)
            if not message:
                return None
            
            # Update allowed fields
            updateable_fields = ["content", "content_type", "temperature", "max_tokens", "top_p", "attachments", "metadata"]
            
            for field in updateable_fields:
                if field in update_data:
                    setattr(message, field, update_data[field])
            
            message.updated_at = datetime.utcnow()
            await db.flush()
            
            return message
            
        except Exception as e:
            self.logger.error(f"Error updating message: {str(e)}")
            return None
    
    async def soft_delete_message(self, message_id: str, db: AsyncSession) -> bool:
        """Soft delete a message."""
        try:
            message = await self.get_message_by_id(message_id, db)
            if not message:
                return False
            
            # Mark as deleted by adding metadata
            current_metadata = message.metadata or {}
            current_metadata["deleted"] = True
            current_metadata["deleted_at"] = datetime.utcnow().isoformat()
            message.metadata = current_metadata
            
            await db.flush()
            return True
            
        except Exception as e:
            self.logger.error(f"Error soft deleting message: {str(e)}")
            return False
    
    async def hard_delete_message(self, message_id: str, db: AsyncSession) -> bool:
        """Hard delete a message from database."""
        try:
            result = await db.execute(
                select(MessageORM).where(MessageORM.id == message_id)
            )
            message = result.scalar_one_or_none()
            
            if not message:
                return False
            
            await db.delete(message)
            await db.flush()
            return True
            
        except Exception as e:
            self.logger.error(f"Error hard deleting message: {str(e)}")
            return False
    
    async def check_message_replies(self, message_id: str, db: AsyncSession) -> bool:
        """Check if a message has replies."""
        try:
            result = await db.execute(
                select(func.count(MessageORM.id))
                .where(MessageORM.parent_message_id == message_id)
            )
            count = result.scalar() or 0
            return count > 0
            
        except Exception as e:
            self.logger.error(f"Error checking message replies: {str(e)}")
            return False
    
    # ============================================================================
    # AUDIT TRAIL OPERATIONS
    # ============================================================================
    
    async def create_audit_trail(
        self, 
        message_id: str, 
        audit_data: Dict[str, Any], 
        db: AsyncSession
    ) -> bool:
        """Create audit trail for message changes."""
        try:
            # Store audit data in message metadata
            message = await self.get_message_by_id(message_id, db)
            if not message:
                return False
            
            current_metadata = message.metadata or {}
            if "audit_trail" not in current_metadata:
                current_metadata["audit_trail"] = []
            
            current_metadata["audit_trail"].append({
                "timestamp": datetime.utcnow().isoformat(),
                "action": "update",
                "data": audit_data
            })
            
            message.metadata = current_metadata
            await db.flush()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating audit trail: {str(e)}")
            return False
    
    async def create_deletion_audit_trail(
        self, 
        message_id: str, 
        audit_data: Dict[str, Any], 
        db: AsyncSession
    ) -> bool:
        """Create audit trail for message deletion."""
        try:
            # This would typically be stored in a separate audit table
            # For now, we'll store it in the session metadata
            self.logger.info(f"Deletion audit trail: {message_id} - {audit_data}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating deletion audit trail: {str(e)}")
            return False
    
    # ============================================================================
    # MESSAGE THREADING
    # ============================================================================
    
    async def create_message_thread(
        self, 
        message_id: str, 
        thread_data: Dict[str, Any], 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Create or manage message threading."""
        try:
            message = await self.get_message_by_id(message_id, db)
            if not message:
                raise ValueError("Message not found")
            
            # Update message with thread information
            current_metadata = message.metadata or {}
            current_metadata["thread_id"] = thread_data.get("thread_id", str(uuid.uuid4()))
            current_metadata["thread_title"] = thread_data.get("thread_title")
            current_metadata["thread_priority"] = thread_data.get("priority", "normal")
            current_metadata["thread_tags"] = thread_data.get("tags", [])
            current_metadata["thread_created_at"] = datetime.utcnow().isoformat()
            
            message.metadata = current_metadata
            await db.flush()
            
            return {
                "thread_id": current_metadata["thread_id"],
                "message_id": message_id,
                "thread_info": thread_data
            }
            
        except Exception as e:
            self.logger.error(f"Error creating message thread: {str(e)}")
            raise
    
    async def get_message_thread(self, message_id: str, db: AsyncSession) -> Dict[str, Any]:
        """Get the full thread for a message."""
        try:
            base_message = await self.get_message_by_id(message_id, db)
            if not base_message:
                raise ValueError("Message not found")
            
            thread_id = base_message.metadata.get("thread_id") if base_message.metadata else None
            
            if not thread_id:
                # Single message thread
                return {
                    "thread_id": message_id,
                    "messages": [base_message.dict()],
                    "thread_type": "single"
                }
            
            # Find all messages in the thread
            query = select(MessageORM).where(
                or_(
                    MessageORM.metadata["thread_id"].astext() == thread_id,
                    MessageORM.id == message_id
                )
            ).order_by(MessageORM.created_at)
            
            result = await db.execute(query)
            thread_messages = result.scalars().all()
            
            return {
                "thread_id": thread_id,
                "messages": [msg.dict() for msg in thread_messages],
                "thread_type": "conversation",
                "message_count": len(thread_messages)
            }
            
        except Exception as e:
            self.logger.error(f"Error getting message thread: {str(e)}")
            raise
    
    # ============================================================================
    # MESSAGE REACTIONS
    # ============================================================================
    
    async def add_message_reaction(
        self, 
        message_id: str, 
        reaction_data: Dict[str, Any], 
        db: AsyncSession
    ) -> Dict[str, Any]:
        """Add reaction/feedback to a message."""
        try:
            message = await self.get_message_by_id(message_id, db)
            if not message:
                raise ValueError("Message not found")
            
            current_metadata = message.metadata or {}
            if "reactions" not in current_metadata:
                current_metadata["reactions"] = []
            
            reaction = {
                "id": str(uuid.uuid4()),
                "type": reaction_data.get("type", "emoji"),
                "value": reaction_data.get("value"),
                "user_id": reaction_data.get("user_id", "anonymous"),
                "created_at": datetime.utcnow().isoformat(),
                "metadata": reaction_data.get("metadata", {})
            }
            
            current_metadata["reactions"].append(reaction)
            message.metadata = current_metadata
            await db.flush()
            
            return reaction
            
        except Exception as e:
            self.logger.error(f"Error adding message reaction: {str(e)}")
            raise
    
    async def get_message_reactions(self, message_id: str, db: AsyncSession) -> List[Dict[str, Any]]:
        """Get all reactions for a message."""
        try:
            message = await self.get_message_by_id(message_id, db)
            if not message:
                return []
            
            reactions = message.metadata.get("reactions", []) if message.metadata else []
            return reactions
            
        except Exception as e:
            self.logger.error(f"Error getting message reactions: {str(e)}")
            return []
    
    async def get_reaction_summary(self, message_id: str, db: AsyncSession) -> Dict[str, Any]:
        """Get reaction summary for a message."""
        try:
            reactions = await self.get_message_reactions(message_id, db)
            
            summary = {
                "total_reactions": len(reactions),
                "reaction_types": {},
                "unique_users": len(set(r.get("user_id") for r in reactions)),
                "latest_reaction": max(reactions, key=lambda x: x.get("created_at", "")) if reactions else None
            }
            
            # Count reaction types
            for reaction in reactions:
                reaction_type = reaction.get("type", "unknown")
                if reaction_type not in summary["reaction_types"]:
                    summary["reaction_types"][reaction_type] = 0
                summary["reaction_types"][reaction_type] += 1
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting reaction summary: {str(e)}")
            return {"total_reactions": 0, "reaction_types": {}, "unique_users": 0}
    
    # ============================================================================
    # ATTACHMENT PROCESSING
    # ============================================================================
    
    async def process_attachment(self, file: UploadFile, session_id: str) -> Dict[str, Any]:
        """Process file attachment with metadata extraction."""
        try:
            # Generate unique filename
            file_hash = hashlib.md5(f"{file.filename}_{datetime.now()}".encode()).hexdigest()[:8]
            file_extension = Path(file.filename).suffix
            secure_filename = f"{file_hash}{file_extension}"
            
            # Create session directory
            session_dir = self.attachment_base_path / session_id
            session_dir.mkdir(parents=True, exist_ok=True)
            
            # Save file
            file_path = session_dir / secure_filename
            content = await file.read()
            
            with open(file_path, "wb") as f:
                f.write(content)
            
            # Extract metadata
            metadata = {
                "original_filename": file.filename,
                "secure_filename": secure_filename,
                "file_path": str(file_path),
                "file_size": len(content),
                "content_type": file.content_type,
                "uploaded_at": datetime.utcnow().isoformat(),
                "file_hash": hashlib.md5(content).hexdigest()
            }
            
            return metadata
            
        except Exception as e:
            self.logger.error(f"Error processing attachment: {str(e)}")
            raise
    
    # ============================================================================
    # UTILITY METHODS
    # ============================================================================
    
    def dict(self, include_metadata: bool = True) -> Dict[str, Any]:
        """Convert message to dictionary representation."""
        # This would be implemented in the MessageORM model itself
        pass
    
    async def get_message_statistics(self, db: AsyncSession) -> Dict[str, Any]:
        """Get overall message statistics."""
        try:
            # Get basic counts
            result = await db.execute(
                select(
                    func.count(MessageORM.id),
                    func.count(func.distinct(MessageORM.session_id)),
                    func.count(func.distinct(SessionORM.user_id))
                )
                .join(SessionORM, MessageORM.session_id == SessionORM.id)
            )
            
            total_messages, total_sessions, total_users = result.first()
            
            # Get role distribution
            role_result = await db.execute(
                select(MessageORM.role, func.count(MessageORM.id))
                .group_by(MessageORM.role)
            )
            
            role_distribution = {role: count for role, count in role_result.all()}
            
            # Get content type distribution
            content_result = await db.execute(
                select(MessageORM.content_type, func.count(MessageORM.id))
                .group_by(MessageORM.content_type)
            )
            
            content_distribution = {content_type: count for content_type, count in content_result.all()}
            
            return {
                "total_messages": total_messages or 0,
                "total_sessions": total_sessions or 0,
                "total_users": total_users or 0,
                "role_distribution": role_distribution,
                "content_distribution": content_distribution,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error getting message statistics: {str(e)}")
            return {
                "total_messages": 0,
                "total_sessions": 0,
                "total_users": 0,
                "role_distribution": {},
                "content_distribution": {},
                "error": str(e)
            }