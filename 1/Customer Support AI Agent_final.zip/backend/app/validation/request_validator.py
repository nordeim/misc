"""
Enhanced request validation middleware.

Provides comprehensive request validation including:
- Parameter validation and type checking
- Input sanitization and security filtering
- Content validation and size limits
- Business rule validation
- Custom validation decorators
"""

import json
import re
import html
from typing import Dict, Any, Optional, List, Union, Callable, Set
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum

from fastapi import Request, HTTPException, status
from fastapi.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import RequestResponseEndpoint
from pydantic import ValidationError, validator
import structlog

from app.config import settings
from app.validation.schema_validator import SchemaValidator
from app.validation.business_validator import BusinessLogicValidator
from app.validation.security_validator_enhanced import SecurityValidator
from app.middleware.error_handling import (
    create_validation_error_response,
    ErrorCategory,
    ErrorSeverity
)

logger = structlog.get_logger(__name__)

class ContentType(Enum):
    """Supported content types."""
    JSON = "application/json"
    FORM = "application/x-www-form-urlencoded"
    MULTIPART = "multipart/form-data"
    TEXT = "text/plain"
    HTML = "text/html"
    XML = "application/xml"

class ValidationRule(Enum):
    """Validation rule types."""
    REQUIRED = "required"
    TYPE = "type"
    MIN_LENGTH = "min_length"
    MAX_LENGTH = "max_length"
    MIN_VALUE = "min_value"
    MAX_VALUE = "max_value"
    PATTERN = "pattern"
    EMAIL = "email"
    URL = "url"
    REGEX = "regex"
    CUSTOM = "custom"

class ValidationConfig:
    """Configuration for validation middleware."""
    
    def __init__(self):
        self.max_request_size = settings.upload_max_file_size_mb * 1024 * 1024  # Convert to bytes
        self.allowed_content_types = {
            "application/json",
            "application/x-www-form-urlencoded",
            "multipart/form-data",
            "text/plain",
            "text/csv"
        }
        self.blocked_content_types = {
            "text/html",
            "application/x-shockwave-flash",
            "application/javascript",
            "text/javascript",
            "application/x-msdownload"
        }
        self.sanitization_enabled = True
        self.xss_protection_enabled = True
        self.sql_injection_protection_enabled = True
        self.max_depth = 10  # Max JSON object depth
        self.max_array_size = 1000  # Max array elements
        self.max_string_length = 10000  # Max string length
        self.validate_business_rules = True
        self.rate_limit_validation_requests = True
        
        # Path-specific configurations
        self.path_configs = {
            "/auth/login": {
                "max_login_attempts": 5,
                "password_min_length": 8,
                "username_pattern": r"^[a-zA-Z0-9_.-]{3,50}$"
            },
            "/auth/register": {
                "registration_rate_limit": 3,  # per hour
                "password_min_length": 8,
                "email_validation_required": True
            },
            "/chat": {
                "max_message_length": 2000,
                "max_file_attachments": 5,
                "max_file_size": 10 * 1024 * 1024,  # 10MB
                "allowed_file_types": {".txt", ".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png"}
            },
            "/upload": {
                "max_file_size": 50 * 1024 * 1024,  # 50MB
                "allowed_file_types": {".pdf", ".doc", ".docx", ".txt", ".jpg", ".jpeg", ".png", ".csv", ".xlsx"},
                "scan_for_malware": True
            }
        }

class RequestValidationMiddleware(BaseHTTPMiddleware):
    """Comprehensive request validation middleware."""
    
    def __init__(self, app):
        super().__init__(app)
        self.config = ValidationConfig()
        self.schema_validator = SchemaValidator()
        self.business_validator = BusinessLogicValidator()
        self.security_validator = SecurityValidator()
        
        # Compile common patterns for performance
        self._compile_patterns()
        
        logger.info("Request validation middleware initialized")
    
    def _compile_patterns(self):
        """Compile regex patterns for performance."""
        self.email_pattern = re.compile(
            r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
        self.url_pattern = re.compile(
            r'^https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.]*))?(?:#(?:\w)*)?)?$'
        )
        self.sql_injection_patterns = [
            re.compile(r'(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)', re.IGNORECASE),
            re.compile(r'(--|/\\*|\\*/|;|\bUNION\b|\bOR\b|\bAND\b)', re.IGNORECASE),
            re.compile(r'([\'"])\s*(OR|AND)\s*[\'"]?\s*\d+\s*=\s*\d+', re.IGNORECASE),
        ]
        self.xss_patterns = [
            re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL),
            re.compile(r'javascript:', re.IGNORECASE),
            re.compile(r'on\w+\s*=', re.IGNORECASE),
            re.compile(r'<iframe[^>]*>.*?</iframe>', re.IGNORECASE | re.DOTALL),
        ]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Union[JSONResponse, Any]:
        """Validate request before processing."""
        try:
            # Skip validation for certain paths
            if self._should_skip_validation(request):
                return await call_next(request)
            
            # Validate request size
            await self._validate_request_size(request)
            
            # Validate content type
            await self._validate_content_type(request)
            
            # Validate headers
            await self._validate_headers(request)
            
            # Validate query parameters
            await self._validate_query_parameters(request)
            
            # Validate path parameters
            await self._validate_path_parameters(request)
            
            # Validate request body
            await self._validate_request_body(request)
            
            # Security validation
            await self._validate_security(request)
            
            # Business logic validation
            if self.config.validate_business_rules:
                await self._validate_business_rules(request)
            
            # Add validated data to request state
            await self._add_validation_context(request)
            
            return await call_next(request)
            
        except HTTPException as e:
            raise e
        except ValidationError as e:
            logger.warning("Validation error", 
                         path=request.url.path,
                         errors=e.errors())
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Request validation failed"
            )
        except Exception as e:
            logger.error("Request validation error", 
                        path=request.url.path,
                        error=str(e))
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid request format"
            )
    
    def _should_skip_validation(self, request: Request) -> bool:
        """Determine if validation should be skipped."""
        skip_paths = {
            "/health",
            "/docs", 
            "/redoc",
            "/openapi.json",
            "/metrics",
            "/favicon.ico",
            "/sitemap.xml",
            "/robots.txt"
        }
        return any(request.url.path.startswith(path) for path in skip_paths)
    
    async def _validate_request_size(self, request: Request):
        """Validate request size."""
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > self.config.max_request_size:
                    logger.warning("Request size limit exceeded",
                                 size=size,
                                 max_size=self.config.max_request_size,
                                 path=request.url.path)
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"Request too large. Maximum size is {self.config.max_request_size // (1024*1024)}MB"
                    )
            except ValueError:
                pass
    
    async def _validate_content_type(self, request: Request):
        """Validate content type."""
        content_type = request.headers.get("content-type", "").lower()
        
        if content_type:
            # Remove parameters (e.g., "application/json; charset=utf-8")
            base_content_type = content_type.split(";")[0].strip()
            
            if base_content_type in self.config.blocked_content_types:
                logger.warning("Blocked content type", 
                             content_type=base_content_type,
                             path=request.url.path)
                raise HTTPException(
                    status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                    detail=f"Content type '{base_content_type}' is not allowed"
                )
            
            # Only validate content type for requests that should have a body
            if request.method in ["POST", "PUT", "PATCH"] and base_content_type:
                if base_content_type not in self.config.allowed_content_types:
                    logger.warning("Unsupported content type",
                                 content_type=base_content_type,
                                 allowed_types=self.config.allowed_content_types)
                    # Don't raise error for unknown content types, just log
    
    async def _validate_headers(self, request: Request):
        """Validate request headers."""
        # Check for suspicious headers
        suspicious_headers = [
            "x-forwarded-host", "x-original-url", "x-rewrite-url",
            "x-originating-ip", "x-remote-ip", "x-remote-addr"
        ]
        
        for header in request.headers:
            if header[0].lower() in suspicious_headers:
                logger.warning("Suspicious header detected",
                             header=header[0],
                             path=request.url.path)
        
        # Validate content type header
        if request.method in ["POST", "PUT", "PATCH"]:
            if "content-type" not in [h[0].lower() for h in request.headers]:
                # Some endpoints might not require content-type
                pass
    
    async def _validate_query_parameters(self, request: Request):
        """Validate query parameters."""
        for param, value in request.query_params.items():
            # Check parameter name
            if not self._is_valid_parameter_name(param):
                logger.warning("Invalid query parameter name",
                             parameter=param,
                             path=request.url.path)
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid parameter name: {param}"
                )
            
            # Sanitize parameter value
            if self.config.sanitization_enabled:
                sanitized_value = self._sanitize_string(value)
                if sanitized_value != value:
                    logger.info("Query parameter sanitized",
                              original=value,
                              sanitized=sanitized_value,
                              parameter=param)
    
    async def _validate_path_parameters(self, request: Request):
        """Validate path parameters."""
        # This would be called from route handlers, but we can do basic validation here
        path_parts = request.url.path.split("/")
        for part in path_parts:
            if part and not self._is_safe_path_component(part):
                logger.warning("Unsafe path component detected",
                             component=part,
                             path=request.url.path)
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid path component: {part}"
                )
    
    async def _validate_request_body(self, request: Request):
        """Validate request body content."""
        if request.method in ["POST", "PUT", "PATCH"]:
            content_type = request.headers.get("content-type", "").lower()
            
            if "application/json" in content_type:
                await self._validate_json_body(request)
            elif "application/x-www-form-urlencoded" in content_type:
                await self._validate_form_body(request)
            elif "multipart/form-data" in content_type:
                await self._validate_multipart_body(request)
    
    async def _validate_json_body(self, request: Request):
        """Validate JSON request body."""
        try:
            # Read body with size limit
            body = await request.body()
            if len(body) > self.config.max_request_size:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail="Request body too large"
                )
            
            if body:
                # Parse JSON
                data = json.loads(body.decode('utf-8'))
                
                # Validate JSON structure
                self._validate_json_structure(data, 0)
                
                # Security validation
                if self.config.xss_protection_enabled:
                    self._validate_json_for_xss(data)
                
                if self.config.sql_injection_protection_enabled:
                    self._validate_json_for_sql_injection(data)
                
                # Add to request state for later use
                request.state.validated_data = data
                
        except json.JSONDecodeError as e:
            logger.warning("Invalid JSON in request body",
                         error=str(e),
                         path=request.url.path)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid JSON format"
            )
    
    def _validate_json_structure(self, data: Any, depth: int):
        """Validate JSON structure depth and size."""
        if depth > self.config.max_depth:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="JSON structure too deep"
            )
        
        if isinstance(data, dict):
            if len(data) > self.config.max_array_size:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Too many JSON object properties"
                )
            for value in data.values():
                self._validate_json_structure(value, depth + 1)
        elif isinstance(data, list):
            if len(data) > self.config.max_array_size:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="JSON array too large"
                )
            for item in data:
                self._validate_json_structure(item, depth + 1)
        elif isinstance(data, str):
            if len(data) > self.config.max_string_length:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="String too long"
                )
    
    def _validate_json_for_xss(self, data: Any):
        """Validate JSON data for XSS patterns."""
        if isinstance(data, str):
            for pattern in self.xss_patterns:
                if pattern.search(data):
                    logger.warning("XSS pattern detected in JSON",
                                 pattern=pattern.pattern,
                                 data=data[:100])
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Potentially dangerous content detected"
                    )
        elif isinstance(data, dict):
            for value in data.values():
                self._validate_json_for_xss(value)
        elif isinstance(data, list):
            for item in data:
                self._validate_json_for_xss(item)
    
    def _validate_json_for_sql_injection(self, data: Any):
        """Validate JSON data for SQL injection patterns."""
        if isinstance(data, str):
            for pattern in self.sql_injection_patterns:
                if pattern.search(data):
                    logger.warning("SQL injection pattern detected in JSON",
                                 pattern=pattern.pattern,
                                 data=data[:100])
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Potentially dangerous content detected"
                    )
        elif isinstance(data, dict):
            for value in data.values():
                self._validate_json_for_sql_injection(value)
        elif isinstance(data, list):
            for item in data:
                self._validate_json_for_sql_injection(item)
    
    async def _validate_form_body(self, request: Request):
        """Validate form-encoded body."""
        # Basic form validation would go here
        pass
    
    async def _validate_multipart_body(self, request: Request):
        """Validate multipart form body."""
        # File upload validation would go here
        pass
    
    async def _validate_security(self, request: Request):
        """Perform security validation."""
        # User agent validation
        user_agent = request.headers.get("user-agent", "")
        if user_agent:
            # Check for suspicious user agents
            suspicious_patterns = [
                r"bot",
                r"crawler", 
                r"spider",
                r"scraper"
            ]
            for pattern in suspicious_patterns:
                if re.search(pattern, user_agent, re.IGNORECASE):
                    logger.warning("Suspicious user agent detected",
                                 user_agent=user_agent,
                                 path=request.url.path)
        
        # IP validation
        client_ip = getattr(request.state, 'client_ip', None)
        if client_ip:
            # Check for private IP ranges (basic check)
            if client_ip.startswith(('127.', '192.168.', '10.', '172.')):
                logger.debug("Private IP detected", 
                           ip=client_ip,
                           path=request.url.path)
    
    async def _validate_business_rules(self, request: Request):
        """Validate business rules."""
        path_config = self.config.path_configs.get(request.url.path)
        if not path_config:
            return
        
        # Path-specific validation rules
        if "/auth/" in request.url.path:
            await self._validate_auth_request(request, path_config)
        elif "/chat" in request.url.path:
            await self._validate_chat_request(request, path_config)
        elif "/upload" in request.url.path:
            await self._validate_upload_request(request, path_config)
    
    async def _validate_auth_request(self, request: Request, config: Dict[str, Any]):
        """Validate authentication requests."""
        if request.url.path.endswith("/login"):
            # Validate login request
            if hasattr(request.state, 'validated_data'):
                data = request.state.validated_data
                if 'username' in data:
                    if not re.match(config.get('username_pattern', r'^[a-zA-Z0-9_.-]{3,50}$'), 
                                  data['username']):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invalid username format"
                        )
    
    async def _validate_chat_request(self, request: Request, config: Dict[str, Any]):
        """Validate chat requests."""
        if hasattr(request.state, 'validated_data'):
            data = request.state.validated_data
            if 'message' in data:
                if len(data['message']) > config.get('max_message_length', 2000):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Message too long. Maximum {config['max_message_length']} characters"
                    )
    
    async def _validate_upload_request(self, request: Request, config: Dict[str, Any]):
        """Validate upload requests."""
        # File upload validation would go here
        pass
    
    async def _add_validation_context(self, request: Request):
        """Add validation context to request state."""
        request.state.validation_context = {
            "validated": True,
            "sanitized": self.config.sanitization_enabled,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _is_valid_parameter_name(self, name: str) -> bool:
        """Check if parameter name is valid."""
        # Parameter names should only contain alphanumeric characters, underscores, and hyphens
        return re.match(r'^[a-zA-Z0-9_-]+$', name) is not None
    
    def _is_safe_path_component(self, component: str) -> bool:
        """Check if path component is safe."""
        # Basic path component validation
        unsafe_chars = ['<', '>', ':', '"', '|', '?', '*', '\x00']
        return not any(char in component for char in unsafe_chars)
    
    def _sanitize_string(self, value: str) -> str:
        """Sanitize string value."""
        if not self.config.sanitization_enabled:
            return value
        
        # Remove null bytes
        sanitized = value.replace('\x00', '')
        
        # HTML escape
        if self.config.xss_protection_enabled:
            sanitized = html.escape(sanitized, quote=True)
        
        # Remove control characters
        sanitized = ''.join(char for char in sanitized if ord(char) >= 32 or char in ['\n', '\r', '\t'])
        
        return sanitized.strip()

def setup_request_validation_middleware(app):
    """Setup request validation middleware."""
    app.add_middleware(RequestValidationMiddleware)
    logger.info("Request validation middleware configured")

# Decorators for manual validation
def validate_endpoint(endpoint_type: str, config: Optional[Dict[str, Any]] = None):
    """Decorator for endpoint-specific validation."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Get request from function arguments
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            
            if not request:
                return await func(*args, **kwargs)
            
            # Apply endpoint-specific validation
            validator = RequestValidationMiddleware(None)
            await validator._validate_business_rules(request)
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator