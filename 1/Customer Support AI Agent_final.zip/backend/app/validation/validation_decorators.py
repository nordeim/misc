"""
Validation decorators for endpoint functions.

Provides convenient decorators for applying validation to API endpoints:
- Request validation decorators
- Response validation decorators
- Business rule validation decorators
- Input sanitization decorators
"""

import functools
import inspect
from typing import Any, Dict, List, Optional, Union, Callable, Type
from datetime import datetime

from fastapi import Request, HTTPException, status
from pydantic import BaseModel
import structlog

from app.validation.request_validator import RequestValidationMiddleware
from app.validation.schema_validator import SchemaValidator, ValidationResult, ValidationRule
from app.validation.business_validator import BusinessLogicValidator
from app.validation.security_validator_enhanced import SecurityValidator
from app.middleware.error_handling import (
    create_validation_error_response,
    ErrorCategory,
    ErrorSeverity
)

logger = structlog.get_logger(__name__)

class ValidationMode(Enum):
    """Validation modes."""
    STRICT = "strict"       # Fail on any validation error
    LENIENT = "lenient"     # Only fail on security issues
    PERMISSIVE = "permissive"  # Log warnings but don't fail

class ValidationScope(Enum):
    """Validation scope."""
    REQUEST = "request"
    RESPONSE = "response"
    BOTH = "both"

class ValidateRequest:
    """Decorator for validating requests."""
    
    def __init__(
        self,
        schema: Optional[Type[BaseModel]] = None,
        rules: Optional[List[ValidationRule]] = None,
        mode: ValidationMode = ValidationMode.STRICT,
        sanitize: bool = True,
        security_check: bool = True,
        business_rules: Optional[List[str]] = None
    ):
        self.schema = schema
        self.rules = rules
        self.mode = mode
        self.sanitize = sanitize
        self.security_check = security_check
        self.business_rules = business_rules
        
        # Initialize validators
        self.schema_validator = SchemaValidator()
        self.security_validator = SecurityValidator()
        self.business_validator = BusinessLogicValidator()
    
    def __call__(self, func):
        """Apply validation decorator."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract request from arguments
            request = self._extract_request(args, kwargs)
            if not request:
                # No request found, skip validation
                return await func(*args, **kwargs)
            
            try:
                # Validate request
                await self._validate_request(request, args, kwargs)
                
                # Execute original function
                return await func(*args, **kwargs)
                
            except Exception as e:
                logger.error("Request validation error", 
                           error=str(e),
                           endpoint=func.__name__)
                raise
        
        return wrapper
    
    def _extract_request(self, args: tuple, kwargs: dict) -> Optional[Request]:
        """Extract FastAPI request from function arguments."""
        # Check kwargs first
        for key, value in kwargs.items():
            if isinstance(value, Request):
                return value
        
        # Check args
        for arg in args:
            if isinstance(arg, Request):
                return arg
        
        return None
    
    async def _validate_request(self, request: Request, args: tuple, kwargs: dict):
        """Validate the request."""
        # Get request body
        try:
            body = await request.body()
            data = None
            
            if body:
                # Try to parse as JSON
                content_type = request.headers.get("content-type", "")
                if "application/json" in content_type:
                    import json
                    data = json.loads(body.decode('utf-8'))
                elif "application/x-www-form-urlencoded" in content_type:
                    from urllib.parse import parse_qs
                    data = parse_qs(body.decode('utf-8'))
            
        except Exception as e:
            if self.mode == ValidationMode.STRICT:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Failed to parse request body: {str(e)}"
                )
            return
        
        if not data:
            return
        
        issues = []
        
        # Schema validation
        if self.schema and data:
            result = self.schema_validator.validate_data(data, self.schema)
            if not result.is_valid:
                for error in result.errors:
                    issues.append(f"Schema validation: {error}")
                if self.mode == ValidationMode.STRICT:
                    raise create_validation_error_response(
                        f"Schema validation failed: {'; '.join(result.errors)}",
                        [{"field": "request", "message": error} for error in result.errors]
                    )
        
        # Custom validation rules
        if self.rules and data:
            for rule in self.rules:
                field_value = data.get(rule.field)
                result = self.schema_validator.validate_field(field_value, rule.rule_type, rule.params)
                if not result.is_valid:
                    for error in result.errors:
                        issues.append(f"Field validation ({rule.field}): {error}")
                    if self.mode == ValidationMode.STRICT:
                        raise HTTPException(
                            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=f"Field validation failed: {'; '.join(result.errors)}"
                        )
        
        # Security validation
        if self.security_check and data:
            security_result = self.security_validator.validate_input(data)
            if not security_result.is_safe:
                for issue in security_result.issues:
                    if issue.threat_level.value in ['high', 'critical']:
                        issues.append(f"Security: {issue.message}")
                
                if self.mode in [ValidationMode.STRICT, ValidationMode.LENIENT]:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Security validation failed: {'; '.join(issues)}"
                    )
            
            # Sanitize data if requested
            if self.sanitize and security_result.sanitized_data:
                request.state.sanitized_data = security_result.sanitized_data
        
        # Business rule validation
        if self.business_rules and data:
            context = self._build_context(request)
            business_issues = self.business_validator.validate_business_rules(data, context, self.business_rules)
            
            for issue in business_issues:
                if issue.severity.value == 'error':
                    issues.append(f"Business rule: {issue.message}")
            
            if self.mode == ValidationMode.STRICT:
                error_issues = [issue for issue in business_issues if issue.severity.value == 'error']
                if error_issues:
                    messages = [issue.message for issue in error_issues]
                    raise HTTPException(
                        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                        detail=f"Business rule validation failed: {'; '.join(messages)}"
                    )
        
        # Log validation results
        if issues:
            logger.info("Request validation issues",
                       endpoint=request.url.path,
                       issues=issues,
                       mode=self.mode.value)
    
    def _build_context(self, request: Request) -> Dict[str, Any]:
        """Build validation context from request."""
        context = {
            "request": {
                "path": str(request.url.path),
                "method": request.method,
                "headers": dict(request.headers),
                "client_ip": getattr(request.state, 'client_ip', 'unknown'),
                "user_agent": request.headers.get("user-agent"),
            },
            "timestamp": datetime.utcnow()
        }
        
        # Add user info if available
        if hasattr(request.state, 'user'):
            context["user"] = request.state.user
        
        # Add session info if available
        if hasattr(request.state, 'session'):
            context["session"] = request.state.session
        
        return context

class ValidateResponse:
    """Decorator for validating responses."""
    
    def __init__(
        self,
        schema: Optional[Type[BaseModel]] = None,
        mode: ValidationMode = ValidationMode.STRICT,
        sanitize: bool = True
    ):
        self.schema = schema
        self.mode = mode
        self.sanitize = sanitize
        self.schema_validator = SchemaValidator()
        self.security_validator = SecurityValidator()
    
    def __call__(self, func):
        """Apply response validation decorator."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Execute original function
            response = await func(*args, **kwargs)
            
            # Validate response
            await self._validate_response(response)
            
            return response
        
        return wrapper
    
    async def _validate_response(self, response):
        """Validate the response."""
        # Extract response data
        if hasattr(response, 'body'):
            # FastAPI Response object
            try:
                import json
                data = json.loads(response.body.decode('utf-8'))
            except:
                return  # Can't parse response, skip validation
            
            issues = []
            
            # Schema validation
            if self.schema and data:
                result = self.schema_validator.validate_data(data, self.schema)
                if not result.is_valid:
                    for error in result.errors:
                        issues.append(f"Response schema: {error}")
                    
                    if self.mode == ValidationMode.STRICT:
                        logger.error("Response schema validation failed",
                                   errors=result.errors)
                        # In production, you might want to log but not fail
            
            # Security validation
            if self.sanitize and data:
                security_result = self.security_validator.validate_input(data)
                if not security_result.is_safe:
                    for issue in security_result.issues:
                        if issue.threat_level.value in ['high', 'critical']:
                            issues.append(f"Response security: {issue.message}")
                    
                    if self.mode == ValidationMode.STRICT:
                        logger.error("Response security validation failed",
                                   issues=[issue.message for issue in security_result.issues])
            
            # Log validation results
            if issues:
                logger.warning("Response validation issues",
                             issues=issues,
                             mode=self.mode.value)

class ValidateBusinessRules:
    """Decorator for validating business rules."""
    
    def __init__(
        self,
        rule_names: List[str],
        context_builder: Optional[Callable] = None,
        mode: ValidationMode = ValidationMode.STRICT
    ):
        self.rule_names = rule_names
        self.context_builder = context_builder
        self.mode = mode
        self.business_validator = BusinessLogicValidator()
    
    def __call__(self, func):
        """Apply business rule validation decorator."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract request and data
            request = self._extract_request(args, kwargs)
            data = self._extract_data(args, kwargs)
            
            if data and request:
                # Build context
                if self.context_builder:
                    context = self.context_builder(data, request)
                else:
                    context = self._default_context_builder(request)
                
                # Validate business rules
                await self._validate_business_rules(data, context)
            
            # Execute original function
            return await func(*args, **kwargs)
        
        return wrapper
    
    def _extract_request(self, args: tuple, kwargs: dict) -> Optional[Request]:
        """Extract request from arguments."""
        for value in list(kwargs.values()) + list(args):
            if isinstance(value, Request):
                return value
        return None
    
    def _extract_data(self, args: tuple, kwargs: dict) -> Optional[Dict[str, Any]]:
        """Extract data from arguments."""
        # Look for common data parameters
        for key in ['data', 'payload', 'body', 'request_data']:
            if key in kwargs:
                return kwargs[key]
        
        # Look for Pydantic models
        for value in args:
            if hasattr(value, 'dict') and callable(getattr(value, 'dict')):
                return value.dict()
        
        return None
    
    def _default_context_builder(self, request: Request) -> Dict[str, Any]:
        """Default context builder."""
        return {
            "request": {
                "path": str(request.url.path),
                "method": request.method,
                "client_ip": getattr(request.state, 'client_ip', 'unknown')
            },
            "timestamp": datetime.utcnow()
        }
    
    async def _validate_business_rules(self, data: Dict[str, Any], context: Dict[str, Any]):
        """Validate business rules."""
        issues = self.business_validator.validate_business_rules(data, context, self.rule_names)
        
        error_issues = [issue for issue in issues if issue.severity.value == 'error']
        
        if error_issues and self.mode == ValidationMode.STRICT:
            messages = [issue.message for issue in error_issues]
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Business rule validation failed: {'; '.join(messages)}"
            )
        
        if issues:
            logger.info("Business rule validation completed",
                       issue_count=len(issues),
                       error_count=len(error_issues))

class SanitizeInput:
    """Decorator for sanitizing input."""
    
    def __init__(self, fields: Optional[List[str]] = None):
        self.fields = fields
        self.security_validator = SecurityValidator()
    
    def __call__(self, func):
        """Apply input sanitization decorator."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract request and data
            request = self._extract_request(args, kwargs)
            if request:
                await self._sanitize_request(request, args, kwargs)
            
            return await func(*args, **kwargs)
        
        return wrapper
    
    def _extract_request(self, args: tuple, kwargs: dict) -> Optional[Request]:
        """Extract request from arguments."""
        for value in list(kwargs.values()) + list(args):
            if isinstance(value, Request):
                return value
        return None
    
    async def _sanitize_request(self, request: Request, args: tuple, kwargs: dict):
        """Sanitize request data."""
        try:
            body = await request.body()
            if body and "application/json" in request.headers.get("content-type", ""):
                import json
                data = json.loads(body.decode('utf-8'))
                
                # Validate and sanitize
                result = self.security_validator.validate_input(data)
                
                if result.sanitized_data:
                    # Store sanitized data for later use
                    request.state.sanitized_data = result.sanitized_data
                
                # Log security issues
                if result.issues:
                    security_issues = [issue for issue in result.issues 
                                     if issue.threat_level.value in ['high', 'critical']]
                    if security_issues:
                        logger.warning("Security issues detected in sanitized request",
                                     issues=[issue.message for issue in security_issues])
        
        except Exception as e:
            logger.error("Input sanitization error", error=str(e))

# Convenience decorators
def validate_user_registration(schema: Type[BaseModel] = None):
    """Validate user registration requests."""
    return ValidateRequest(
        schema=schema,
        rules=[
            ValidationRule("username", "string", {"min_length": 3, "max_length": 50}),
            ValidationRule("email", "email"),
            ValidationRule("password", "password"),
        ],
        business_rules=["username_uniqueness", "password_strength", "email_format"]
    )

def validate_user_login(schema: Type[BaseModel] = None):
    """Validate user login requests."""
    return ValidateRequest(
        schema=schema,
        rules=[
            ValidationRule("username", "string", {"min_length": 1}),
            ValidationRule("password", "string", {"min_length": 1}),
        ],
        business_rules=["suspicious_activity"]
    )

def validate_chat_message(schema: Type[BaseModel] = None):
    """Validate chat messages."""
    return ValidateRequest(
        schema=schema,
        rules=[
            ValidationRule("message", "string", {"min_length": 1, "max_length": 2000}),
        ],
        security_check=True,
        business_rules=["message_length", "rate_limit_per_user"]
    )

def validate_file_upload():
    """Validate file uploads."""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            request = None
            for value in list(kwargs.values()) + list(args):
                if isinstance(value, Request):
                    request = value
                    break
            
            if request:
                # Extract file information
                files = []
                content_type = request.headers.get("content-type", "")
                
                if "multipart/form-data" in content_type:
                    # This would need proper multipart parsing
                    pass
                
                # Validate each file
                for file_info in files:
                    validator = SecurityValidator()
                    result = validator.validate_file_upload(
                        file_info['filename'],
                        file_info['content'],
                        file_info['content_type']
                    )
                    
                    if not result.is_safe:
                        high_risk_issues = [issue for issue in result.issues 
                                          if issue.threat_level.value in ['high', 'critical']]
                        if high_risk_issues:
                            raise HTTPException(
                                status_code=status.HTTP_400_BAD_REQUEST,
                                detail=f"File security validation failed: {'; '.join([issue.message for issue in high_risk_issues])}"
                            )
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator

# Helper function for applying multiple decorators
def compose_validators(*validators):
    """Compose multiple validation decorators."""
    def decorator(func):
        for validator in reversed(validators):
            func = validator(func)
        return func
    return decorator

# Usage examples
"""
# Basic request validation
@ValidateRequest(
    schema=UserCreateSchema,
    mode=ValidationMode.STRICT,
    security_check=True
)
async def create_user(user_data: UserCreateSchema):
    return await user_service.create_user(user_data)

# Business rule validation
@ValidateBusinessRules(
    rule_names=["username_uniqueness", "email_format"],
    context_builder=build_user_context
)
async def register_user(data: UserRegistrationData):
    return await auth_service.register_user(data)

# File upload validation
@validate_file_upload()
async def upload_file(file: UploadFile):
    return await file_service.save_file(file)

# Composed validation
@compose_validators(
    validate_user_registration(),
    SanitizeInput(fields=["username", "email"]),
    ValidateResponse(schema=UserResponseSchema)
)
async def register_user_endpoint(data: UserCreateSchema):
    return await auth_service.create_user(data)
"""