"""
Caching Utilities for RAG System.

This module provides comprehensive caching functionality for the RAG system including:
- Memory caching with LRU eviction
- Redis-based distributed caching
- Embedding cache management
- Search result caching
- Cache invalidation strategies

Features:
- Multi-level caching (memory + Redis)
- Cache statistics and monitoring
- Configurable TTL and eviction policies
- Cache warming and preloading
- Thread-safe operations
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union, Callable
from dataclasses import dataclass, asdict
from functools import wraps
from collections import OrderedDict
import hashlib
import pickle

try:
    import redis.asyncio as aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    aioredis = None

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class CacheStats:
    """Cache statistics."""
    hits: int = 0
    misses: int = 0
    evictions: int = 0
    size: int = 0
    max_size: int = 0
    hit_rate: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
    
    def update_hit_rate(self):
        """Update hit rate calculation."""
        total = self.hits + self.misses
        self.hit_rate = self.hits / total if total > 0 else 0.0


class CacheBackend(ABC):
    """Abstract base class for cache backends."""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache."""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        pass
    
    @abstractmethod
    async def clear(self) -> bool:
        """Clear all cache entries."""
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        pass
    
    @abstractmethod
    def get_stats(self) -> CacheStats:
        """Get cache statistics."""
        pass


class MemoryCache(CacheBackend):
    """In-memory LRU cache implementation."""
    
    def __init__(self, max_size: int = 1000, default_ttl: int = 3600):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache = OrderedDict()
        self._expiry = {}
        self._stats = CacheStats(max_size=max_size)
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from memory cache."""
        async with self._lock:
            if key not in self._cache:
                self._stats.misses += 1
                return None
            
            # Check if expired
            if key in self._expiry and time.time() > self._expiry[key]:
                del self._cache[key]
                del self._expiry[key]
                self._stats.misses += 1
                return None
            
            # Move to end (LRU)
            value = self._cache.pop(key)
            self._cache[key] = value
            self._stats.hits += 1
            return value
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in memory cache."""
        async with self._lock:
            ttl = ttl or self.default_ttl
            expiry_time = time.time() + ttl
            
            # Remove existing key if present
            if key in self._cache:
                self._cache.pop(key)
                self._expiry.pop(key, None)
            
            # Evict if at capacity
            while len(self._cache) >= self.max_size:
                oldest_key = next(iter(self._cache))
                self._cache.pop(oldest_key)
                self._expiry.pop(oldest_key, None)
                self._stats.evictions += 1
            
            self._cache[key] = value
            self._expiry[key] = expiry_time
            self._stats.size = len(self._cache)
            
            return True
    
    async def delete(self, key: str) -> bool:
        """Delete value from memory cache."""
        async with self._lock:
            if key in self._cache:
                self._cache.pop(key)
                self._expiry.pop(key, None)
                self._stats.size = len(self._cache)
                return True
            return False
    
    async def clear(self) -> bool:
        """Clear all cache entries."""
        async with self._lock:
            self._cache.clear()
            self._expiry.clear()
            self._stats = CacheStats(max_size=self.max_size)
            return True
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in memory cache."""
        async with self._lock:
            if key not in self._cache:
                return False
            
            # Check expiry
            if key in self._expiry and time.time() > self._expiry[key]:
                self._cache.pop(key, None)
                self._expiry.pop(key, None)
                self._stats.size = len(self._cache)
                return False
            
            return True
    
    def get_stats(self) -> CacheStats:
        """Get memory cache statistics."""
        self._stats.update_hit_rate()
        return self._stats


class RedisCache(CacheBackend):
    """Redis-based distributed cache."""
    
    def __init__(self, redis_url: str, default_ttl: int = 3600, key_prefix: str = "rag:"):
        self.redis_url = redis_url
        self.default_ttl = default_ttl
        self.key_prefix = key_prefix
        self._redis = None
        self._stats = CacheStats()
        self._connected = False
    
    async def _ensure_connection(self):
        """Ensure Redis connection is established."""
        if not self._connected and REDIS_AVAILABLE:
            try:
                self._redis = aioredis.from_url(self.redis_url)
                await self._redis.ping()
                self._connected = True
                logger.info("Redis cache connected successfully")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {e}")
                self._connected = False
                raise
    
    def _get_key(self, key: str) -> str:
        """Get Redis key with prefix."""
        return f"{self.key_prefix}{key}"
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from Redis cache."""
        try:
            await self._ensure_connection()
            redis_key = self._get_key(key)
            value = await self._redis.get(redis_key)
            
            if value is None:
                self._stats.misses += 1
                return None
            
            # Deserialize value
            try:
                result = json.loads(value)
            except (json.JSONDecodeError, pickle.PickleError):
                result = pickle.loads(value)
            
            self._stats.hits += 1
            return result
            
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            self._stats.misses += 1
            return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in Redis cache."""
        try:
            await self._ensure_connection()
            redis_key = self._get_key(key)
            ttl = ttl or self.default_ttl
            
            # Serialize value
            try:
                serialized_value = json.dumps(value, default=str)
            except (TypeError, ValueError):
                serialized_value = pickle.dumps(value)
            
            await self._redis.setex(redis_key, ttl, serialized_value)
            return True
            
        except Exception as e:
            logger.error(f"Redis set error: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete value from Redis cache."""
        try:
            await self._ensure_connection()
            redis_key = self._get_key(key)
            result = await self._redis.delete(redis_key)
            return bool(result)
            
        except Exception as e:
            logger.error(f"Redis delete error: {e}")
            return False
    
    async def clear(self) -> bool:
        """Clear all cache entries with prefix."""
        try:
            await self._ensure_connection()
            pattern = f"{self.key_prefix}*"
            keys = await self._redis.keys(pattern)
            if keys:
                await self._redis.delete(*keys)
            return True
            
        except Exception as e:
            logger.error(f"Redis clear error: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in Redis cache."""
        try:
            await self._ensure_connection()
            redis_key = self._get_key(key)
            result = await self._redis.exists(redis_key)
            return bool(result)
            
        except Exception as e:
            logger.error(f"Redis exists error: {e}")
            return False
    
    def get_stats(self) -> CacheStats:
        """Get Redis cache statistics."""
        self._stats.update_hit_rate()
        return self._stats
    
    async def close(self):
        """Close Redis connection."""
        if self._redis:
            await self._redis.close()


class MultiLevelCache(CacheBackend):
    """Multi-level cache with memory and Redis backends."""
    
    def __init__(
        self,
        memory_cache: MemoryCache,
        redis_cache: Optional[RedisCache] = None,
        write_through: bool = True
    ):
        self.memory_cache = memory_cache
        self.redis_cache = redis_cache
        self.write_through = write_through
        self._combined_stats = CacheStats()
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from multi-level cache."""
        # Try memory cache first
        value = await self.memory_cache.get(key)
        if value is not None:
            return value
        
        # Try Redis cache if available
        if self.redis_cache and self.redis_cache._connected:
            value = await self.redis_cache.get(key)
            if value is not None:
                # Populate memory cache
                await self.memory_cache.set(key, value)
                return value
        
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in multi-level cache."""
        success = True
        
        # Always write to memory cache
        memory_success = await self.memory_cache.set(key, value, ttl)
        success &= memory_success
        
        # Write to Redis if configured and write-through enabled
        if self.redis_cache and self.write_through and self.redis_cache._connected:
            redis_success = await self.redis_cache.set(key, value, ttl)
            success &= redis_success
        
        return success
    
    async def delete(self, key: str) -> bool:
        """Delete value from multi-level cache."""
        success = True
        
        # Delete from both backends
        await self.memory_cache.delete(key)
        if self.redis_cache:
            await self.redis_cache.delete(key)
        
        return success
    
    async def clear(self) -> bool:
        """Clear all cache entries."""
        success = True
        
        await self.memory_cache.clear()
        if self.redis_cache:
            await self.redis_cache.clear()
        
        return success
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in multi-level cache."""
        return await self.memory_cache.exists(key) or (
            self.redis_cache and await self.redis_cache.exists(key)
        )
    
    def get_stats(self) -> CacheStats:
        """Get combined cache statistics."""
        memory_stats = self.memory_cache.get_stats()
        redis_stats = self.redis_cache.get_stats() if self.redis_cache else CacheStats()
        
        combined = CacheStats(
            hits=memory_stats.hits + redis_stats.hits,
            misses=memory_stats.misses + redis_stats.misses,
            evictions=memory_stats.evictions + redis_stats.evictions,
            size=memory_stats.size,
            max_size=memory_stats.max_size
        )
        combined.update_hit_rate()
        
        return combined


class CacheManager:
    """Centralized cache management for RAG system."""
    
    def __init__(self):
        self._memory_cache = None
        self._redis_cache = None
        self._multi_cache = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize cache components."""
        if self._initialized:
            return
        
        try:
            # Initialize memory cache
            self._memory_cache = MemoryCache(
                max_size=settings.ai_cache_max_size or 1000,
                default_ttl=settings.ai_cache_ttl or 3600
            )
            
            # Initialize Redis cache if available
            if settings.redis_url and REDIS_AVAILABLE:
                try:
                    self._redis_cache = RedisCache(
                        redis_url=settings.redis_url,
                        default_ttl=settings.ai_cache_ttl or 3600,
                        key_prefix="rag:cache:"
                    )
                    await self._redis_cache._ensure_connection()
                except Exception as e:
                    logger.warning(f"Failed to initialize Redis cache: {e}")
                    self._redis_cache = None
            
            # Create multi-level cache
            self._multi_cache = MultiLevelCache(
                memory_cache=self._memory_cache,
                redis_cache=self._redis_cache,
                write_through=True
            )
            
            self._initialized = True
            logger.info("Cache manager initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize cache manager: {e}")
            raise
    
    @property
    def cache(self) -> CacheBackend:
        """Get the multi-level cache instance."""
        if not self._initialized:
            raise RuntimeError("Cache manager not initialized")
        return self._multi_cache
    
    def cache_key(self, *args, **kwargs) -> str:
        """Generate cache key from arguments."""
        # Create a deterministic key from arguments
        key_data = {
            'args': args,
            'kwargs': sorted(kwargs.items())
        }
        key_string = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def cached(
        self,
        key_prefix: str = "",
        ttl: Optional[int] = None,
        condition: Optional[Callable] = None
    ):
        """Decorator for caching function results."""
        def decorator(func):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # Check condition
                if condition and not condition(*args, **kwargs):
                    return await func(*args, **kwargs)
                
                # Generate cache key
                key = self.cache_key(*args, **kwargs)
                if key_prefix:
                    key = f"{key_prefix}:{key}"
                
                # Try to get from cache
                result = await self.cache.get(key)
                if result is not None:
                    logger.debug(f"Cache hit for {func.__name__}")
                    return result
                
                # Execute function and cache result
                logger.debug(f"Cache miss for {func.__name__}")
                result = await func(*args, **kwargs)
                
                if result is not None:
                    await self.cache.set(key, result, ttl)
                
                return result
            
            return wrapper
        return decorator
    
    async def warm_cache(self, items: List[Tuple[str, Any, Optional[int]]]):
        """
        Warm cache with predefined items.
        
        Args:
            items: List of (key, value, ttl) tuples
        """
        logger.info(f"Warming cache with {len(items)} items")
        
        for key, value, ttl in items:
            try:
                await self.cache.set(key, value, ttl)
            except Exception as e:
                logger.error(f"Failed to warm cache item {key}: {e}")
        
        logger.info("Cache warming completed")
    
    async def clear_cache(self):
        """Clear all cache entries."""
        await self.cache.clear()
        logger.info("Cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics."""
        if not self._initialized:
            return {"status": "not_initialized"}
        
        memory_stats = self._memory_cache.get_stats()
        redis_stats = self._redis_cache.get_stats() if self._redis_cache else CacheStats()
        combined_stats = self.cache.get_stats()
        
        return {
            "memory_cache": memory_stats.to_dict(),
            "redis_cache": redis_stats.to_dict() if self._redis_cache else None,
            "combined": combined_stats.to_dict(),
            "initialized": self._initialized
        }
    
    async def close(self):
        """Close cache manager and cleanup resources."""
        if self._redis_cache:
            await self._redis_cache.close()
        
        logger.info("Cache manager closed")


# Global cache manager instance
cache_manager = CacheManager()


# Specific cache implementations for RAG components

class EmbeddingCache:
    """Specialized cache for embedding results."""
    
    def __init__(self):
        self.cache_manager = cache_manager
        self._initialized = False
    
    async def initialize(self):
        """Initialize embedding cache."""
        if not self._initialized:
            await self.cache_manager.initialize()
            self._initialized = True
    
    async def get_embedding(self, text: str) -> Optional[List[float]]:
        """Get cached embedding."""
        if not self._initialized:
            await self.initialize()
        
        key = f"embedding:{hashlib.md5(text.encode()).hexdigest()}"
        return await self.cache_manager.cache.get(key)
    
    async def set_embedding(self, text: str, embedding: List[float], ttl: Optional[int] = None):
        """Cache embedding."""
        if not self._initialized:
            await self.initialize()
        
        key = f"embedding:{hashlib.md5(text.encode()).hexdigest()}"
        await self.cache_manager.cache.set(key, embedding, ttl)
    
    async def clear_embeddings(self):
        """Clear all embedding cache."""
        await self.cache_manager.cache.clear()


class SearchResultCache:
    """Specialized cache for search results."""
    
    def __init__(self):
        self.cache_manager = cache_manager
        self._initialized = False
    
    async def initialize(self):
        """Initialize search result cache."""
        if not self._initialized:
            await self.cache_manager.initialize()
            self._initialized = True
    
    async def get_search_results(
        self,
        query: str,
        search_type: str,
        top_k: int,
        filter_metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        """Get cached search results."""
        if not self._initialized:
            await self.initialize()
        
        # Create deterministic cache key
        cache_data = {
            'query': query,
            'search_type': search_type,
            'top_k': top_k,
            'filter_metadata': filter_metadata or {}
        }
        key = f"search:{hashlib.md5(json.dumps(cache_data, sort_keys=True).encode()).hexdigest()}"
        
        return await self.cache_manager.cache.get(key)
    
    async def set_search_results(
        self,
        query: str,
        search_type: str,
        top_k: int,
        results: List[Dict[str, Any]],
        filter_metadata: Optional[Dict[str, Any]] = None,
        ttl: Optional[int] = None
    ):
        """Cache search results."""
        if not self._initialized:
            await self.initialize()
        
        # Create deterministic cache key
        cache_data = {
            'query': query,
            'search_type': search_type,
            'top_k': top_k,
            'filter_metadata': filter_metadata or {}
        }
        key = f"search:{hashlib.md5(json.dumps(cache_data, sort_keys=True).encode()).hexdigest()}"
        
        await self.cache_manager.cache.set(key, results, ttl)
    
    async def clear_search_results(self):
        """Clear all search result cache."""
        await self.cache_manager.cache.clear()


# Export main classes and functions
__all__ = [
    'CacheBackend',
    'MemoryCache',
    'RedisCache',
    'MultiLevelCache',
    'CacheManager',
    'EmbeddingCache',
    'SearchResultCache',
    'cache_manager'
]