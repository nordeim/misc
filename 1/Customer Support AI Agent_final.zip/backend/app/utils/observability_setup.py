"""
Integrated Observability Configuration and Setup.

This module provides comprehensive observability setup and integration:
- Centralized observability configuration
- Service integration and setup
- Middleware configuration
- Metrics endpoint setup
- Health check integration
- Alerting configuration
- Dashboard endpoints

Features:
- Auto-configuration of observability components
- Integration with existing monitoring infrastructure
- Performance optimization
- Production-ready monitoring setup
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from fastapi import FastAPI, Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
import structlog

from app.services.observability_service import (
    get_observability_service, initialize_observability, 
    ObservabilityConfig, ObservabilityLevel
)
from app.utils.health_check_aggregator import health_aggregator, initialize_common_health_checks
from app.utils.observability_decorators import profiler
from app.monitoring.enhanced_monitoring import setup_api_monitoring
from config.monitoring import monitoring_config

logger = structlog.get_logger(__name__)

class ObservabilitySetup:
    """Comprehensive observability system setup and management."""
    
    def __init__(self, config: ObservabilityConfig = None):
        self.config = config or self._create_default_config()
        self.app = None
        self.observability_service = None
        self.middleware_registered = False
        self.endpoints_registered = False
        
        logger.info("Observability setup initialized",
                   level=self.config.level.value,
                   prometheus_enabled=self.config.prometheus_enabled,
                   tracing_enabled=self.config.tracing_enabled)
    
    def _create_default_config(self) -> ObservabilityConfig:
        """Create default observability configuration based on monitoring config."""
        return ObservabilityConfig(
            level=ObservabilityLevel(monitoring_config.monitoring_level.lower()),
            prometheus_enabled=monitoring_config.prometheus_enabled,
            tracing_enabled=monitoring_config.tracing_enabled,
            alerts_enabled=monitoring_config.alerting_enabled,
            performance_tracking=monitoring_config.performance_monitoring_enabled,
            custom_metrics=monitoring_config.custom_metrics_enabled,
            distributed_tracing=monitoring_config.tracing_enabled,
            metrics_retention_hours=monitoring_config.metrics_retention_days * 24,
            alert_cooldown_minutes=5,
            performance_sample_rate=monitoring_config.metrics_sample_rate
        )
    
    async def setup_observability(self, app: FastAPI):
        """Set up complete observability system for the FastAPI application."""
        self.app = app
        
        try:
            # Initialize observability service
            self.observability_service = await initialize_observability()
            
            # Setup health checks
            await self._setup_health_checks()
            
            # Setup middleware
            self._setup_middleware(app)
            
            # Setup endpoints
            self._setup_observability_endpoints(app)
            
            # Setup background tasks
            await self._setup_background_tasks()
            
            # Configure alerting
            await self._setup_alerting()
            
            logger.info("Observability system setup completed successfully")
            
        except Exception as e:
            logger.error("Failed to setup observability system", error=str(e))
            raise
    
    async def _setup_health_checks(self):
        """Setup comprehensive health checks."""
        try:
            # Initialize common health checks
            initialize_common_health_checks()
            
            # Add service health checks based on configuration
            if monitoring_config.database_health_check:
                health_aggregator.register_service_health_check("database", critical=True)
            
            if monitoring_config.redis_health_check:
                health_aggregator.register_service_health_check("redis", critical=True)
            
            if monitoring_config.ai_service_health_check:
                health_aggregator.register_service_health_check("ai_service", ["database"], True)
            
            if monitoring_config.vector_db_health_check:
                health_aggregator.register_service_health_check("vector_db", ["database"], True)
            
            logger.info("Health checks setup completed",
                       services_monitored=len(health_aggregator.service_health_checks))
            
        except Exception as e:
            logger.error("Failed to setup health checks", error=str(e))
            raise
    
    def _setup_middleware(self, app: FastAPI):
        """Setup observability middleware."""
        try:
            # Add API monitoring middleware if enabled
            if monitoring_config.performance_monitoring_enabled:
                setup_api_monitoring(app)
                logger.info("API monitoring middleware configured")
            
            # Add observability middleware for request tracking
            app.add_middleware(ObservabilityMiddleware)
            
            self.middleware_registered = True
            logger.info("Observability middleware configured")
            
        except Exception as e:
            logger.error("Failed to setup middleware", error=str(e))
            raise
    
    def _setup_observability_endpoints(self, app: FastAPI):
        """Setup observability API endpoints."""
        try:
            # Metrics endpoint
            if self.config.prometheus_enabled:
                @app.get(monitoring_config.prometheus_endpoint)
                async def metrics_endpoint():
                    """Prometheus metrics endpoint."""
                    return Response(
                        content=self.observability_service.get_metrics(),
                        media_type=CONTENT_TYPE_LATEST
                    )
                
                logger.info("Prometheus metrics endpoint configured",
                           endpoint=monitoring_config.prometheus_endpoint)
            
            # Health endpoints
            @app.get(monitoring_config.health_check_endpoint)
            async def health_endpoint():
                """Basic health check endpoint."""
                try:
                    health_status = await self.observability_service.get_health_status()
                    status_code = 200 if health_status.get("status") == "healthy" else 503
                    return JSONResponse(status_code=status_code, content=health_status)
                except Exception as e:
                    logger.error("Health check failed", error=str(e))
                    return JSONResponse(
                        status_code=503,
                        content={"status": "unhealthy", "error": str(e)}
                    )
            
            @app.get("/health/detailed")
            async def detailed_health_endpoint():
                """Detailed health check with full system status."""
                try:
                    health_data = health_aggregator.get_health_dashboard_data()
                    overall_status = health_data.get("overall_status", "unknown")
                    status_code = 200 if overall_status == "healthy" else 503
                    return JSONResponse(status_code=status_code, content=health_data)
                except Exception as e:
                    logger.error("Detailed health check failed", error=str(e))
                    return JSONResponse(
                        status_code=503,
                        content={"status": "unhealthy", "error": str(e)}
                    )
            
            # Observability endpoints
            @app.get("/observability/performance")
            async def performance_endpoint():
                """Performance metrics and analysis."""
                try:
                    performance_data = self.observability_service.get_performance_summary()
                    return JSONResponse(content={"status": "success", "data": performance_data})
                except Exception as e:
                    logger.error("Performance metrics failed", error=str(e))
                    return JSONResponse(
                        status_code=500,
                        content={"status": "error", "error": str(e)}
                    )
            
            @app.get("/observability/traces")
            async def traces_endpoint():
                """Distributed tracing summary."""
                try:
                    if not self.config.tracing_enabled:
                        return JSONResponse(
                            status_code=503,
                            content={"status": "disabled", "message": "Distributed tracing is disabled"}
                        )
                    
                    trace_data = self.observability_service.get_trace_summary()
                    return JSONResponse(content={"status": "success", "data": trace_data})
                except Exception as e:
                    logger.error("Trace data failed", error=str(e))
                    return JSONResponse(
                        status_code=500,
                        content={"status": "error", "error": str(e)}
                    )
            
            @app.get("/observability/alerts")
            async def alerts_endpoint():
                """Alert summary and management."""
                try:
                    alert_data = self.observability_service.get_alert_summary()
                    return JSONResponse(content={"status": "success", "data": alert_data})
                except Exception as e:
                    logger.error("Alert data failed", error=str(e))
                    return JSONResponse(
                        status_code=500,
                        content={"status": "error", "error": str(e)}
                    )
            
            # Export endpoints
            @app.get("/observability/export")
            async def export_endpoint(hours: int = 24):
                """Export observability data."""
                try:
                    export_path = f"./data/exports/observability_{int(asyncio.get_event_loop().time())}.json"
                    success = self.observability_service.export_observability_data(export_path, hours)
                    
                    if success:
                        return JSONResponse(
                            content={
                                "status": "success", 
                                "message": f"Data exported to {export_path}",
                                "export_path": export_path
                            }
                        )
                    else:
                        return JSONResponse(
                            status_code=500,
                            content={"status": "error", "message": "Export failed"}
                        )
                except Exception as e:
                    logger.error("Export failed", error=str(e))
                    return JSONResponse(
                        status_code=500,
                        content={"status": "error", "error": str(e)}
                    )
            
            self.endpoints_registered = True
            logger.info("Observability endpoints configured")
            
        except Exception as e:
            logger.error("Failed to setup endpoints", error=str(e))
            raise
    
    async def _setup_background_tasks(self):
        """Setup background monitoring tasks."""
        try:
            # Health aggregation task
            async def health_aggregation_task():
                while True:
                    try:
                        await health_aggregator.aggregate_health()
                        await asyncio.sleep(60)  # Aggregate every minute
                    except Exception as e:
                        logger.error("Health aggregation task error", error=str(e))
                        await asyncio.sleep(30)
            
            # Start background tasks
            asyncio.create_task(health_aggregation_task())
            
            logger.info("Background monitoring tasks configured")
            
        except Exception as e:
            logger.error("Failed to setup background tasks", error=str(e))
            raise
    
    async def _setup_alerting(self):
        """Setup alerting system."""
        try:
            if not self.config.alerts_enabled:
                logger.info("Alerting disabled in configuration")
                return
            
            # Configure alert channels
            alert_manager = self.observability_service.alert_manager
            
            # Console alerting (always enabled)
            # This is handled by default in the alert manager
            
            # Webhook alerting
            if monitoring_config.alert_webhook_url:
                alert_manager.add_channel(
                    channel_type="webhook",
                    config={"url": monitoring_config.alert_webhook_url}
                )
                logger.info("Webhook alerting configured")
            
            # Email alerting
            if monitoring_config.alert_email_enabled and monitoring_config.alert_email_recipients:
                alert_manager.add_channel(
                    channel_type="email",
                    config={"recipients": monitoring_config.alert_email_recipients}
                )
                logger.info("Email alerting configured")
            
            # Slack alerting
            if monitoring_config.alert_slack_enabled and monitoring_config.alert_slack_webhook:
                alert_manager.add_channel(
                    channel_type="slack",
                    config={"webhook": monitoring_config.alert_slack_webhook}
                )
                logger.info("Slack alerting configured")
            
            logger.info("Alerting system configured")
            
        except Exception as e:
            logger.error("Failed to setup alerting", error=str(e))
            raise
    
    async def shutdown(self):
        """Shutdown observability system."""
        try:
            if self.observability_service:
                await self.observability_service.stop()
            
            logger.info("Observability system shutdown completed")
            
        except Exception as e:
            logger.error("Error during observability shutdown", error=str(e))

class ObservabilityMiddleware(BaseHTTPMiddleware):
    """FastAPI middleware for comprehensive observability."""
    
    def __init__(self, app, config: ObservabilityConfig = None):
        super().__init__(app)
        self.config = config or self._create_default_config()
        self.observability_service = None
        
        logger.info("Observability middleware initialized")
    
    def _create_default_config(self) -> ObservabilityConfig:
        """Create default configuration."""
        return ObservabilityConfig(
            level=ObservabilityLevel(monitoring_config.monitoring_level.lower()),
            prometheus_enabled=monitoring_config.prometheus_enabled,
            tracing_enabled=monitoring_config.tracing_enabled,
            alerts_enabled=monitoring_config.alerting_enabled,
            performance_tracking=monitoring_config.performance_monitoring_enabled
        )
    
    async def dispatch(self, request: Request, call_next):
        """Process request with observability tracking."""
        # Get observability service
        if self.observability_service is None:
            self.observability_service = get_observability_service()
        
        # Generate request ID
        request_id = str(id(request))
        
        # Start timing
        start_time = asyncio.get_event_loop().time()
        
        try:
            # Add request context
            request.state.request_id = request_id
            request.state.start_time = start_time
            
            # Process request
            response = await call_next(request)
            
            # Calculate response time
            response_time = asyncio.get_event_loop().time() - start_time
            
            # Record request metrics
            self.observability_service.record_request(
                method=request.method,
                endpoint=request.url.path,
                status_code=response.status_code,
                response_time=response_time
            )
            
            # Add observability headers
            response.headers["X-Request-ID"] = request_id
            response.headers["X-Response-Time"] = f"{response_time:.3f}"
            
            return response
            
        except Exception as e:
            # Record error metrics
            response_time = asyncio.get_event_loop().time() - start_time
            self.observability_service.record_request(
                method=request.method,
                endpoint=request.url.path,
                status_code=500,
                response_time=response_time
            )
            
            # Log error
            logger.error("Request processing failed",
                        request_id=request_id,
                        method=request.method,
                        path=request.url.path,
                        response_time=response_time,
                        error=str(e))
            
            raise

# Utility functions for easy integration
def setup_observability_for_app(app: FastAPI, config: ObservabilityConfig = None) -> ObservabilitySetup:
    """Setup observability for a FastAPI application."""
    setup = ObservabilitySetup(config)
    
    # Add startup event
    @app.on_event("startup")
    async def startup_event():
        await setup.setup_observability(app)
    
    # Add shutdown event
    @app.on_event("shutdown")
    async def shutdown_event():
        await setup.shutdown()
    
    return setup

def configure_production_observability() -> ObservabilityConfig:
    """Configure observability for production deployment."""
    return ObservabilityConfig(
        level=ObservabilityLevel.COMPREHENSIVE,
        prometheus_enabled=True,
        tracing_enabled=True,
        alerts_enabled=True,
        performance_tracking=True,
        custom_metrics=True,
        distributed_tracing=True,
        metrics_retention_hours=168,  # 7 days
        alert_cooldown_minutes=5,
        performance_sample_rate=1.0
    )

def configure_development_observability() -> ObservabilityConfig:
    """Configure observability for development environment."""
    return ObservabilityConfig(
        level=ObservabilityLevel.STANDARD,
        prometheus_enabled=True,
        tracing_enabled=False,
        alerts_enabled=True,
        performance_tracking=True,
        custom_metrics=True,
        distributed_tracing=False,
        metrics_retention_hours=24,  # 1 day
        alert_cooldown_minutes=5,
        performance_sample_rate=0.5  # Sample 50% of operations
    )

def configure_test_observability() -> ObservabilityConfig:
    """Configure observability for testing."""
    return ObservabilityConfig(
        level=ObservabilityLevel.MINIMAL,
        prometheus_enabled=False,
        tracing_enabled=False,
        alerts_enabled=False,
        performance_tracking=False,
        custom_metrics=False,
        distributed_tracing=False,
        metrics_retention_hours=1,  # 1 hour
        alert_cooldown_minutes=1,
        performance_sample_rate=0.0  # No sampling
    )

# Global observability setup instance
_observability_setup: Optional[ObservabilitySetup] = None

def get_observability_setup() -> ObservabilitySetup:
    """Get the global observability setup instance."""
    global _observability_setup
    return _observability_setup

async def initialize_global_observability(app: FastAPI, environment: str = "development"):
    """Initialize global observability system."""
    global _observability_setup
    
    # Choose configuration based on environment
    if environment.lower() == "production":
        config = configure_production_observability()
    elif environment.lower() == "development":
        config = configure_development_observability()
    else:
        config = configure_test_observability()
    
    _observability_setup = ObservabilitySetup(config)
    await _observability_setup.setup_observability(app)
    
    return _observability_setup

# Export main components
__all__ = [
    'ObservabilitySetup',
    'ObservabilityMiddleware',
    'setup_observability_for_app',
    'configure_production_observability',
    'configure_development_observability',
    'configure_test_observability',
    'initialize_global_observability',
    'get_observability_setup',
    'health_aggregator',
    'profiler'
]