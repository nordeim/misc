"""
Cache Configuration Management.

This module provides comprehensive configuration management for the cache system,
including environment-specific settings, performance tuning, and configuration validation.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, asdict
from pydantic import BaseSettings, Field, validator

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class CachePerformanceConfig:
    """Cache performance configuration."""
    # Connection settings
    connection_pool_size: int = 20
    connection_timeout: int = 5
    socket_timeout: int = 5
    max_retries: int = 3
    retry_delay: float = 1.0
    
    # Memory settings
    max_memory_percent: int = 80
    max_memory_policy: str = "allkeys-lru"
    
    # Performance tuning
    pipeline_commands: int = 50
    compression_threshold: int = 1024
    batch_operation_size: int = 100
    
    # Timeout settings
    short_ttl: int = 300      # 5 minutes
    medium_ttl: int = 3600    # 1 hour
    long_ttl: int = 86400     # 24 hours
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CacheFeatureConfig:
    """Cache feature configuration."""
    # Enable/disable features
    enable_fallback: bool = True
    enable_compression: bool = True
    enable_encryption: bool = False
    enable_analytics: bool = True
    enable_monitoring: bool = True
    
    # Tag system
    enable_tags: bool = True
    max_tags_per_key: int = 10
    tag_validation: bool = True
    
    # Backup and migration
    enable_backups: bool = True
    backup_retention_days: int = 30
    auto_backup_interval_hours: int = 24
    
    # Health monitoring
    health_check_interval: int = 30
    health_check_timeout: int = 5
    max_health_check_failures: int = 3
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CacheConfigManager:
    """Manage cache configuration for different environments and use cases."""
    
    def __init__(self, config_file: Optional[Path] = None):
        self.config_file = config_file or Path(__file__).parent / "cache_config.json"
        self.performance_config = CachePerformanceConfig()
        self.feature_config = CacheFeatureConfig()
        self._load_config()
    
    def _load_config(self):
        """Load configuration from file."""
        try:
            if self.config_file.exists():
                with open(self.config_file, 'r') as f:
                    config_data = json.load(f)
                
                # Update performance config
                if 'performance' in config_data:
                    for key, value in config_data['performance'].items():
                        if hasattr(self.performance_config, key):
                            setattr(self.performance_config, key, value)
                
                # Update feature config
                if 'features' in config_data:
                    for key, value in config_data['features'].items():
                        if hasattr(self.feature_config, key):
                            setattr(self.feature_config, key, value)
                
                logger.info("Cache configuration loaded from file")
        except Exception as e:
            logger.warning(f"Failed to load cache config from file: {e}")
    
    def save_config(self):
        """Save current configuration to file."""
        try:
            config_data = {
                'performance': self.performance_config.to_dict(),
                'features': self.feature_config.to_dict(),
                'environment': settings.environment,
                'updated_at': __import__('time').time()
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config_data, f, indent=2)
            
            logger.info("Cache configuration saved to file")
        except Exception as e:
            logger.error(f"Failed to save cache config: {e}")
    
    def apply_environment_config(self, environment: str):
        """Apply environment-specific configuration."""
        env_configs = {
            'development': {
                'connection_pool_size': 5,
                'max_memory_percent': 50,
                'enable_monitoring': False,
                'enable_backups': False,
                'health_check_interval': 60,
                'short_ttl': 300,
                'medium_ttl': 1800,
                'long_ttl': 7200
            },
            'testing': {
                'connection_pool_size': 3,
                'max_memory_percent': 30,
                'enable_monitoring': False,
                'enable_backups': False,
                'enable_analytics': False,
                'health_check_interval': 120,
                'short_ttl': 60,
                'medium_ttl': 300,
                'long_ttl': 600
            },
            'production': {
                'connection_pool_size': 50,
                'max_memory_percent': 80,
                'enable_monitoring': True,
                'enable_backups': True,
                'enable_analytics': True,
                'health_check_interval': 30,
                'short_ttl': 300,
                'medium_ttl': 3600,
                'long_ttl': 86400
            }
        }
        
        if environment in env_configs:
            config = env_configs[environment]
            
            # Apply performance settings
            for key, value in config.items():
                if hasattr(self.performance_config, key):
                    setattr(self.performance_config, key, value)
                elif hasattr(self.feature_config, key):
                    setattr(self.feature_config, key, value)
            
            logger.info(f"Applied {environment} configuration")
        else:
            logger.warning(f"Unknown environment: {environment}")
    
    def apply_workload_config(self, workload_type: str):
        """Apply configuration based on workload type."""
        workload_configs = {
            'high_throughput': {
                'connection_pool_size': 100,
                'batch_operation_size': 500,
                'pipeline_commands': 100,
                'compression_threshold': 512,
                'max_memory_percent': 90
            },
            'low_latency': {
                'connection_pool_size': 20,
                'batch_operation_size': 50,
                'pipeline_commands': 20,
                'compression_threshold': 2048,
                'max_memory_percent': 70
            },
            'memory_optimized': {
                'connection_pool_size': 10,
                'max_memory_percent': 60,
                'enable_compression': True,
                'compression_threshold': 512,
                'short_ttl': 180,
                'medium_ttl': 1800
            },
            'durability_focused': {
                'connection_pool_size': 30,
                'enable_backups': True,
                'backup_retention_days': 90,
                'auto_backup_interval_hours': 12,
                'long_ttl': 604800  # 7 days
            }
        }
        
        if workload_type in workload_configs:
            config = workload_configs[workload_type]
            
            for key, value in config.items():
                if hasattr(self.performance_config, key):
                    setattr(self.performance_config, key, value)
                elif hasattr(self.feature_config, key):
                    setattr(self.feature_config, key, value)
            
            logger.info(f"Applied {workload_type} workload configuration")
        else:
            logger.warning(f"Unknown workload type: {workload_type}")
    
    def optimize_for_application(self, app_type: str):
        """Optimize configuration for specific application types."""
        app_configs = {
            'web_app': {
                'short_ttl': 300,      # 5 minutes
                'medium_ttl': 3600,    # 1 hour
                'long_ttl': 86400,     # 24 hours
                'enable_compression': True,
                'max_memory_percent': 75
            },
            'api_service': {
                'short_ttl': 60,       # 1 minute
                'medium_ttl': 1800,    # 30 minutes
                'long_ttl': 7200,      # 2 hours
                'enable_compression': True,
                'max_memory_percent': 80
            },
            'batch_processing': {
                'short_ttl': 3600,     # 1 hour
                'medium_ttl': 86400,   # 24 hours
                'long_ttl': 604800,    # 7 days
                'enable_backups': True,
                'max_memory_percent': 85
            },
            'real_time': {
                'short_ttl': 30,       # 30 seconds
                'medium_ttl': 300,     # 5 minutes
                'long_ttl': 1800,      # 30 minutes
                'enable_compression': False,
                'max_memory_percent': 70
            }
        }
        
        if app_type in app_configs:
            config = app_configs[app_type]
            
            for key, value in config.items():
                if hasattr(self.performance_config, key):
                    setattr(self.performance_config, key, value)
                elif hasattr(self.feature_config, key):
                    setattr(self.feature_config, key, value)
            
            logger.info(f"Optimized cache configuration for {app_type} application")
        else:
            logger.warning(f"Unknown application type: {app_type}")
    
    def validate_config(self) -> Dict[str, Any]:
        """Validate current configuration."""
        issues = []
        warnings = []
        
        # Validate performance config
        perf_config = self.performance_config
        
        if perf_config.connection_pool_size <= 0:
            issues.append("Connection pool size must be positive")
        
        if perf_config.connection_pool_size > 1000:
            warnings.append("Very large connection pool size may cause resource issues")
        
        if perf_config.max_memory_percent <= 0 or perf_config.max_memory_percent > 100:
            issues.append("Max memory percent must be between 1 and 100")
        
        if perf_config.max_memory_percent > 90:
            warnings.append("High memory usage may cause system instability")
        
        if perf_config.batch_operation_size <= 0:
            issues.append("Batch operation size must be positive")
        
        if perf_config.batch_operation_size > 10000:
            warnings.append("Very large batch size may impact performance")
        
        # Validate feature config
        feature_config = self.feature_config
        
        if feature_config.max_tags_per_key <= 0:
            issues.append("Max tags per key must be positive")
        
        if feature_config.max_tags_per_key > 100:
            warnings.append("Large number of tags per key may impact performance")
        
        if feature_config.backup_retention_days <= 0:
            issues.append("Backup retention days must be positive")
        
        if feature_config.backup_retention_days > 365:
            warnings.append("Very long backup retention may consume significant disk space")
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'performance_config': perf_config.to_dict(),
            'feature_config': feature_config.to_dict()
        }
    
    def export_config_template(self, file_path: Path):
        """Export configuration template for users."""
        template = {
            "performance": {
                "connection_pool_size": "Number of connections in pool (default: 20)",
                "connection_timeout": "Connection timeout in seconds (default: 5)",
                "socket_timeout": "Socket timeout in seconds (default: 5)",
                "max_retries": "Maximum retry attempts (default: 3)",
                "retry_delay": "Delay between retries in seconds (default: 1.0)",
                "max_memory_percent": "Maximum memory usage percentage (default: 80)",
                "max_memory_policy": "Redis memory eviction policy (default: allkeys-lru)",
                "pipeline_commands": "Commands to batch in pipeline (default: 50)",
                "compression_threshold": "Size threshold for compression in bytes (default: 1024)",
                "batch_operation_size": "Size for batch operations (default: 100)",
                "short_ttl": "Short TTL in seconds (default: 300)",
                "medium_ttl": "Medium TTL in seconds (default: 3600)",
                "long_ttl": "Long TTL in seconds (default: 86400)"
            },
            "features": {
                "enable_fallback": "Enable in-memory fallback cache (default: true)",
                "enable_compression": "Enable data compression (default: true)",
                "enable_encryption": "Enable data encryption (default: false)",
                "enable_analytics": "Enable cache analytics (default: true)",
                "enable_monitoring": "Enable health monitoring (default: true)",
                "enable_tags": "Enable tag-based invalidation (default: true)",
                "max_tags_per_key": "Maximum tags per cache key (default: 10)",
                "tag_validation": "Enable tag validation (default: true)",
                "enable_backups": "Enable automatic backups (default: true)",
                "backup_retention_days": "Backup retention period in days (default: 30)",
                "auto_backup_interval_hours": "Automatic backup interval in hours (default: 24)",
                "health_check_interval": "Health check interval in seconds (default: 30)",
                "health_check_timeout": "Health check timeout in seconds (default: 5)",
                "max_health_check_failures": "Maximum health check failures (default: 3)"
            },
            "environment": "deployment environment (development/testing/production)",
            "example_values": {
                "development": {
                    "connection_pool_size": 5,
                    "max_memory_percent": 50,
                    "enable_monitoring": false,
                    "enable_backups": false
                },
                "production": {
                    "connection_pool_size": 50,
                    "max_memory_percent": 80,
                    "enable_monitoring": true,
                    "enable_backups": true
                }
            }
        }
        
        try:
            with open(file_path, 'w') as f:
                json.dump(template, f, indent=2)
            logger.info(f"Configuration template exported to {file_path}")
        except Exception as e:
            logger.error(f"Failed to export config template: {e}")
    
    def get_ttl_for_category(self, category: str) -> int:
        """Get TTL for a specific category."""
        category_ttl_map = {
            'session': self.performance_config.short_ttl,
            'user_data': self.performance_config.medium_ttl,
            'configuration': self.performance_config.long_ttl,
            'temporary': self.performance_config.short_ttl,
            'analytics': self.performance_config.medium_ttl,
            'static_data': self.performance_config.long_ttl
        }
        
        return category_ttl_map.get(category, self.performance_config.medium_ttl)
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Get comprehensive configuration summary."""
        return {
            'performance': self.performance_config.to_dict(),
            'features': self.feature_config.to_dict(),
            'environment': settings.environment,
            'recommendations': self._get_recommendations()
        }
    
    def _get_recommendations(self) -> List[str]:
        """Get configuration recommendations."""
        recommendations = []
        
        # Check for potential issues
        if self.performance_config.connection_pool_size > 100:
            recommendations.append("Consider reducing connection pool size for better resource utilization")
        
        if self.performance_config.max_memory_percent > 85:
            recommendations.append("High memory usage may impact system performance")
        
        if not self.feature_config.enable_backups and settings.environment == 'production':
            recommendations.append("Backups should be enabled in production")
        
        if not self.feature_config.enable_monitoring:
            recommendations.append("Health monitoring is recommended for production deployments")
        
        # Add workload-specific recommendations
        if settings.environment == 'production':
            if self.performance_config.connection_pool_size < 20:
                recommendations.append("Consider increasing connection pool size for production")
            
            if self.feature_config.backup_retention_days < 7:
                recommendations.append("Consider increasing backup retention for production")
        
        return recommendations


# Global cache config manager
cache_config = CacheConfigManager()

# Initialize with environment settings
if hasattr(settings, 'environment'):
    cache_config.apply_environment_config(settings.environment)


class CacheSettings:
    """Cache-specific settings that can be overridden by environment variables."""
    
    @staticmethod
    def get_redis_url() -> str:
        """Get Redis URL with fallback logic."""
        # Priority: explicit redis_url, then constructed from components
        if hasattr(settings, 'redis_url') and settings.redis_url:
            return settings.redis_url
        
        # Construct from individual components
        host = getattr(settings, 'redis_host', 'localhost')
        port = getattr(settings, 'redis_port', 6379)
        db = getattr(settings, 'redis_db', 0)
        
        return f"redis://{host}:{port}/{db}"
    
    @staticmethod
    def get_fallback_enabled() -> bool:
        """Check if fallback cache is enabled."""
        return os.getenv('CACHE_FALLBACK_ENABLED', 'true').lower() == 'true'
    
    @staticmethod
    def get_fallback_max_size() -> int:
        """Get fallback cache maximum size."""
        return int(os.getenv('CACHE_FALLBACK_MAX_SIZE', '10000'))
    
    @staticmethod
    def get_default_ttl() -> int:
        """Get default TTL value."""
        return int(os.getenv('CACHE_DEFAULT_TTL', '3600'))
    
    @staticmethod
    def get_performance_tier() -> str:
        """Get performance tier for configuration."""
        return os.getenv('CACHE_PERFORMANCE_TIER', 'balanced')
    
    @staticmethod
    def is_development_mode() -> bool:
        """Check if running in development mode."""
        return settings.environment == 'development' if hasattr(settings, 'environment') else True


# Export configuration management classes
__all__ = [
    'CachePerformanceConfig',
    'CacheFeatureConfig',
    'CacheConfigManager',
    'CacheSettings',
    'cache_config'
]
