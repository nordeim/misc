# Utility Functions Documentation

This document provides comprehensive documentation for the utility functions package, which includes validation, preprocessing, and common utility functions for backend application development.

## Table of Contents

1. [Overview](#overview)
2. [Package Structure](#package-structure)
3. [Validation Utils](#validation-utils)
4. [Preprocessing Utils](#preprocessing-utils)
5. [Common Utils](#common-utils)
6. [Usage Examples](#usage-examples)
7. [Best Practices](#best-practices)
8. [Performance Considerations](#performance-considerations)

## Overview

The utility functions package provides a comprehensive set of tools for:

- **Input Validation**: Email, phone, URL, password, file type, and format validation
- **Data Sanitization**: XSS prevention, SQL injection protection, filename sanitization
- **Text Preprocessing**: Cleaning, normalization, tokenization, and keyword extraction
- **Common Utilities**: File operations, string manipulation, error handling, and decorators
- **Performance Monitoring**: Execution time tracking, memory profiling, and caching
- **Testing Support**: Mock data generation and validation helpers

## Package Structure

```
backend/app/utils/
├── __init__.py                     # Package initialization and exports
├── validation_utils.py             # Input validation and sanitization
├── preprocessing_utils.py          # Text preprocessing and data cleaning
├── common_utils.py                 # Common utilities and decorators
└── test_utility_functions.py       # Comprehensive test suite
```

## Validation Utils

### InputValidator

Provides comprehensive input validation for common data types.

#### Email Validation
```python
from app.utils import InputValidator

# Validate email format
is_valid = InputValidator.validate_email("user@example.com")  # True
is_valid = InputValidator.validate_email("invalid-email")     # False
```

#### Phone Number Validation
```python
# Validate phone number
is_valid = InputValidator.validate_phone_number("+1234567890", "US")  # True
```

#### URL Validation
```python
# Validate URL format
is_valid = InputValidator.validate_url("https://example.com")  # True
```

#### Password Validation
```python
# Validate password strength
feedback = InputValidator.validate_password("StrongPass123!")
# Returns: {'is_valid': True, 'errors': [], 'score': 85}
```

#### File Validation
```python
# Validate file type and size
is_type_valid = InputValidator.validate_file_type("image/jpeg", "image")
is_size_valid = InputValidator.validate_file_size(1024*1024, "image")  # 1MB
```

### DataSanitizer

Provides data sanitization to prevent security vulnerabilities.

#### HTML Sanitization
```python
from app.utils import DataSanitizer

# Sanitize HTML content
clean_html = DataSanitizer.sanitize_html("<script>alert('xss')</script>Hello")
# Returns: "Hello" (script tags removed)
```

#### Input Sanitization
```python
# Sanitize user input
clean_input = DataSanitizer.sanitize_input("'; DROP TABLE users; --")
# Returns sanitized string without SQL injection patterns
```

#### Filename Sanitization
```python
# Sanitize filename
safe_filename = DataSanitizer.sanitize_filename("../../../etc/passwd")
# Returns safe filename without path traversal
```

### FormatValidator

Validates data format compliance.

#### Date Format
```python
from app.utils import FormatValidator

# Validate date format
is_valid = FormatValidator.validate_date_format("2023-12-25", "%Y-%m-%d")
```

#### UUID Format
```python
# Validate UUID
is_valid = FormatValidator.validate_uuid_format("123e4567-e89b-12d3-a456-426614174000")
```

#### Credit Card Format
```python
# Validate credit card using Luhn algorithm
is_valid = FormatValidator.validate_credit_card_format("4532015112830366")
```

### BusinessRuleValidator

Validates data according to business rules.

#### User Registration
```python
from app.utils import BusinessRuleValidator

user_data = {
    'username': 'validuser',
    'email': 'user@example.com',
    'password': 'SecurePass123!',
    'birth_date': '1990-01-01'
}

result = BusinessRuleValidator.validate_user_registration(user_data)
# Returns: {'is_valid': True, 'errors': [], 'warnings': []}
```

## Preprocessing Utils

### TextPreprocessor

Advanced text preprocessing utilities.

#### Text Cleaning
```python
from app.utils import TextPreprocessor

# Clean text
dirty_text = "Hello <script>alert('xss')</script>! Visit https://example.com"
clean_text = TextPreprocessor.clean_text(dirty_text, remove_html=True, remove_urls=True)
```

#### Abbreviation Expansion
```python
# Expand abbreviations
text = "u r great! thx!"
expanded = TextPreprocessor.expand_abbreviations(text)
# Returns: "you are great! thanks!"
```

#### Tokenization
```python
# Tokenize text
tokens = TextPreprocessor.tokenize_text("Hello world! How are you?", method='word')
# Returns: ['Hello', 'world', '!', 'How', 'are', 'you', '?']
```

#### Keyword Extraction
```python
# Extract keywords
keywords = TextPreprocessor.extract_keywords("This is a test sentence", max_keywords=5)
# Returns: ['test', 'sentence']
```

### DataCleaner

Data cleaning utilities for various formats.

#### Dictionary Cleaning
```python
from app.utils import DataCleaner

dirty_dict = {
    'name': 'John',
    'empty': '',
    'none_value': None,
    'nested': {'value': 123, 'null': None}
}

clean_dict = DataCleaner.clean_dict(dirty_dict)
# Removes empty strings, None values, and clean nested objects
```

#### Key Standardization
```python
# Standardize dictionary keys
mixed_keys = {'CamelCase': 1, 'snake_case': 2}
standardized = DataCleaner.standardize_keys(mixed_keys, 'snake')
# Returns: {'camel_case': 1, 'snake_case': 2}
```

### FormatConverter

Format conversion utilities.

#### CSV Conversion
```python
from app.utils import FormatConverter

# CSV to dict list
csv_content = "name,age\nJohn,25\nJane,30"
data = FormatConverter.csv_to_dict_list(csv_content)
# Returns: [{'name': 'John', 'age': '25'}, {'name': 'Jane', 'age': '30'}]

# Dict list to CSV
csv_result = FormatConverter.dict_list_to_csv(data)
```

#### URL Query Conversion
```python
# Dict to query string
params = {'name': 'John', 'age': 25}
query = FormatConverter.dict_to_query_string(params)
# Returns: "name=John&age=25"
```

## Common Utils

### ErrorHandling

Error handling utilities and decorators.

#### Retry Decorator
```python
from app.utils.common_utils import ErrorHandling

@ErrorHandling.retry(max_attempts=3, delay=1.0)
def unreliable_function():
    # Function that might fail
    pass
```

#### Timeout Decorator
```python
@ErrorHandling.timeout(seconds=30)
def long_running_function():
    # Function that might hang
    pass
```

#### Safe Execute
```python
@ErrorHandling.safe_execute(fallback_return="default")
def risky_function():
    # Function that might throw exceptions
    pass
```

### PerformanceMonitor

Performance monitoring utilities.

#### Execution Time Tracking
```python
from app.utils.common_utils import PerformanceMonitor

@PerformanceMonitor.measure_time
def slow_function():
    # Function to measure
    pass

@PerformanceMonitor.profile_memory
def memory_intensive_function():
    # Function to profile
    pass
```

#### Call Counting
```python
@PerformanceMonitor.count_calls
def frequently_called_function():
    pass

# Access call count
print(f"Function called {frequently_called_function.call_count} times")
```

### FileSystemUtils

File system operations.

#### Directory Management
```python
from app.utils import FileSystemUtils

# Ensure directory exists
directory = FileSystemUtils.ensure_directory("/path/to/directory")
```

#### File Operations
```python
# Get file information
file_info = FileSystemUtils.get_file_info("/path/to/file.txt")
# Returns: {name, size, created, modified, extension, hash_md5, ...}

# Find files
files = FileSystemUtils.find_files("/path/to/search", "*.txt", recursive=True)

# Calculate file hash
file_hash = FileSystemUtils.get_file_hash("/path/to/file.txt", "md5")
```

#### Temporary Files
```python
# Context manager for temporary files
with FileSystemUtils.temporary_file(suffix='.tmp') as temp_path:
    # Use temporary file
    pass
# File automatically cleaned up
```

### StringUtils

String manipulation utilities.

#### Random String Generation
```python
from app.utils import StringUtils

# Generate random string
random_id = StringUtils.generate_random_string(10)
random_uuid = StringUtils.generate_uuid_string()
```

#### Case Conversion
```python
# Camel case to snake case
snake_case = StringUtils.camel_to_snake("CamelCaseString")
# Returns: "camel_case_string"

# Snake case to camel case
camel_case = StringUtils.snake_to_camel("snake_case_string")
# Returns: "snakeCaseString"
```

#### String Operations
```python
# Truncate string
truncated = StringUtils.truncate_string("Very long text...", 10, suffix="...")
# Returns: "Very long..."

# Mask sensitive data
masked = StringUtils.mask_sensitive_data("123456789")
# Returns: "12*****89"
```

### DataUtils

Data manipulation utilities.

#### Dictionary Operations
```python
from app.utils import DataUtils

# Deep merge
dict1 = {'a': 1, 'b': {'x': 10}}
dict2 = {'b': {'y': 20}, 'c': 3}
merged = DataUtils.deep_merge(dict1, dict2)
# Returns: {'a': 1, 'b': {'x': 10, 'y': 20}, 'c': 3}

# Flatten dictionary
flat = DataUtils.flatten_dict({'a': {'b': {'c': 1}}})
# Returns: {'a.b.c': 1}
```

#### List Operations
```python
# Chunk list
chunks = DataUtils.chunk_list([1,2,3,4,5,6], 3)
# Returns: [[1,2,3], [4,5,6]]

# Remove duplicates
unique = DataUtils.remove_duplicates([1,2,2,3,3,3])
# Returns: [1, 2, 3]

# Group by
data = [{'category': 'A', 'value': 1}, {'category': 'B', 'value': 2}]
grouped = DataUtils.group_by(data, 'category')
# Returns: {'A': [...], 'B': [...]}
```

### Advanced Utilities

#### RateLimiter
```python
from app.utils import RateLimiter

rate_limiter = RateLimiter(max_calls=100, time_window=60)

@rate_limiter
def api_function():
    # Function with rate limiting
    pass
```

#### CircuitBreaker
```python
from app.utils import CircuitBreaker

circuit_breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60)

@circuit_breaker
def unreliable_external_service():
    # External service call
    pass
```

## Usage Examples

### Complete Validation Workflow

```python
from app.utils import (
    InputValidator, DataSanitizer, BusinessRuleValidator,
    validate_email, sanitize_input
)

def validate_user_input(user_data):
    # Step 1: Sanitize input
    sanitized_data = {
        key: sanitize_input(str(value)) for key, value in user_data.items()
    }
    
    # Step 2: Validate email
    if not validate_email(sanitized_data.get('email', '')):
        return {'error': 'Invalid email format'}
    
    # Step 3: Validate password strength
    password_feedback = InputValidator.validate_password(
        sanitized_data.get('password', '')
    )
    if not password_feedback['is_valid']:
        return {'error': 'Password too weak', 'details': password_feedback['errors']}
    
    # Step 4: Business rule validation
    business_result = BusinessRuleValidator.validate_user_registration(sanitized_data)
    if not business_result['is_valid']:
        return {'error': 'Business rules failed', 'details': business_result['errors']}
    
    return {'success': True, 'data': sanitized_data}
```

### Text Processing Pipeline

```python
from app.utils import create_preprocessing_pipeline

# Create preprocessing pipeline
pipeline = create_preprocessing_pipeline([
    (TextPreprocessor.clean_text, {'remove_html': True, 'remove_urls': True}),
    (TextPreprocessor.normalize_text, {'lowercase': True, 'remove_accents': True}),
    (TextPreprocessor.remove_stopwords, {}),
    (TextPreprocessor.lemmatize_words, {})
])

# Process text
raw_text = "Hello! Visit <b>https://example.com</b> for more info!"
processed_text = pipeline.process(raw_text)
# Returns preprocessed text ready for analysis
```

### File Upload Validation

```python
from app.utils import InputValidator, DataSanitizer, get_safe_filename

def validate_uploaded_file(file_data):
    # Validate file type
    if not InputValidator.validate_file_type(file_data['content_type'], 'image'):
        return {'error': 'Invalid file type'}
    
    # Validate file size
    if not InputValidator.validate_file_size(file_data['size'], 'image'):
        return {'error': 'File too large'}
    
    # Sanitize filename
    safe_filename = get_safe_filename(file_data['filename'])
    
    return {
        'success': True,
        'safe_filename': safe_filename,
        'validated_size': file_data['size'],
        'content_type': file_data['content_type']
    }
```

### Performance Monitoring

```python
from app.utils import measure_time, safe_execute, cache_file

@measure_time
@safe_execute(fallback_return={})
@cache_file('/tmp/cache', max_age=3600)
def expensive_operation(data):
    # Expensive computation with caching
    return process_data(data)
```

### Error Handling with Retry

```python
from app.utils import retry, timeout

@retry(max_attempts=3, delay=2.0)
@timeout(seconds=30)
def external_api_call():
    # API call that might fail or timeout
    return call_external_service()
```

## Best Practices

### Input Validation
1. **Always validate on input**: Validate data as soon as it enters your system
2. **Sanitize before storage**: Sanitize data before storing in database
3. **Validate output**: Don't trust external data sources, validate everything
4. **Use specific validators**: Use appropriate validators for each data type

### Security
1. **Prevent XSS**: Always sanitize HTML content from user input
2. **Prevent SQL injection**: Sanitize input before database operations
3. **Validate file uploads**: Check file type, size, and content
4. **Sanitize filenames**: Prevent path traversal attacks

### Performance
1. **Cache expensive operations**: Use caching decorators for repeated computations
2. **Monitor function performance**: Use performance monitoring decorators
3. **Use rate limiting**: Prevent abuse with rate limiters
4. **Circuit breaker pattern**: Protect against cascading failures

### Error Handling
1. **Graceful degradation**: Use safe execute decorators for non-critical operations
2. **Retry with backoff**: Implement exponential backoff for transient failures
3. **Timeout protection**: Prevent hanging operations with timeout decorators
4. **Comprehensive logging**: Log errors with sufficient context

### Text Processing
1. **Preprocessing pipeline**: Use consistent preprocessing steps
2. **Text normalization**: Normalize encoding and formatting
3. **Remove noise**: Clean HTML, URLs, and special characters
4. **Handle edge cases**: Deal with empty, null, or malformed input

## Performance Considerations

### Memory Usage
- **Caching**: Cache directory uses disk space, monitor usage
- **Large datasets**: Process large data in chunks to avoid memory issues
- **Temporary files**: Cleanup temporary files to avoid disk space issues

### CPU Usage
- **Text processing**: NLTK operations can be CPU-intensive
- **Validation**: Complex validations (password, business rules) may be slower
- **File operations**: Large file operations should be chunked

### Database Impact
- **Validation frequency**: Avoid redundant validation queries
- **Caching strategy**: Cache validation results when appropriate
- **Batch operations**: Use batch processing for multiple validations

### File System
- **Concurrent access**: Be careful with file operations in multi-threaded environments
- **Temporary files**: Ensure cleanup of temporary files
- **File permissions**: Handle file permission errors gracefully

## Integration Guide

### Adding to FastAPI Applications

```python
from fastapi import FastAPI, Depends
from app.utils import validate_email, sanitize_input

app = FastAPI()

@app.post("/users")
async def create_user(user_data: dict):
    # Validate input using utility functions
    if not validate_email(user_data.get('email', '')):
        raise HTTPException(status_code=400, detail="Invalid email")
    
    # Sanitize input
    sanitized_data = {
        key: sanitize_input(str(value)) 
        for key, value in user_data.items()
    }
    
    # Process user creation
    return create_user_in_db(sanitized_data)
```

### Adding to Background Tasks

```python
from app.utils import measure_time, retry

@measure_time
@retry(max_attempts=3)
def background_data_processing(data_batch):
    # Process data with monitoring and retry
    for item in data_batch:
        process_item(item)
```

### Adding to API Routes

```python
from app.utils import FileSystemUtils, InputValidator

@app.post("/upload")
async def upload_file(file: UploadFile):
    # Validate file
    if not InputValidator.validate_file_type(file.content_type, 'document'):
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    # Use safe filename
    safe_filename = FileSystemUtils.safe_filename(file.filename)
    
    # Save file
    await save_uploaded_file(file, safe_filename)
    
    return {"filename": safe_filename}
```

## Testing

Run the comprehensive test suite:

```bash
cd backend/app/utils
python test_utility_functions.py
```

The test suite validates:
- All validation functions
- Text preprocessing capabilities
- Common utility functions
- Decorator functionality
- Error handling mechanisms
- Performance monitoring
- Integration scenarios

## Contributing

When adding new utility functions:

1. **Follow naming conventions**: Use descriptive names and consistent patterns
2. **Add comprehensive tests**: Include tests for all new functions
3. **Document thoroughly**: Add docstrings and usage examples
4. **Handle edge cases**: Consider null, empty, and malformed inputs
5. **Performance impact**: Consider performance implications of new functions

## Version History

- **v1.0.0**: Initial release with comprehensive validation, preprocessing, and common utilities
- **Features**: Complete validation suite, text preprocessing pipeline, common utilities, decorators, and testing framework
