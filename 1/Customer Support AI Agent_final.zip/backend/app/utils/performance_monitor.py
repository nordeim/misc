"""
Performance Monitoring Utilities for RAG System.

This module provides comprehensive performance monitoring and analytics for the RAG system:
- Request tracking and timing
- Memory usage monitoring  
- Query performance analysis
- System resource utilization
- Performance metrics aggregation
- Alert generation for performance issues

Features:
- Real-time performance metrics
- Historical performance data
- Performance benchmarking
- Resource usage tracking
- Query optimization suggestions
"""

import asyncio
import json
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Callable
from concurrent.futures import ThreadPoolExecutor
import psutil
import threading

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetric:
    """Individual performance metric."""
    name: str
    value: float
    unit: str
    timestamp: float
    tags: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class QueryMetrics:
    """Metrics for a single query."""
    query: str
    search_type: str
    execution_time: float
    top_k: int
    results_count: int
    confidence_score: float
    memory_usage_mb: float
    embedding_time: float
    search_time: float
    processing_time: float
    timestamp: float
    success: bool
    error_message: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class SystemMetrics:
    """System resource metrics."""
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    memory_available_mb: float
    disk_usage_percent: float
    disk_free_mb: float
    active_connections: int
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class PerformanceMonitor:
    """Monitor and track RAG system performance."""
    
    def __init__(self, max_history: int = 10000):
        self.max_history = max_history
        self._metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=max_history))
        self._query_metrics: deque = deque(maxlen=max_history)
        self._system_metrics_history: deque = deque(maxlen=max_history)
        self._monitoring_active = False
        self._monitor_thread = None
        self._lock = threading.Lock()
        
        # Performance thresholds
        self.thresholds = {
            'query_time_warning': 5.0,  # seconds
            'query_time_critical': 10.0,
            'memory_usage_warning': 80.0,  # percent
            'memory_usage_critical': 90.0,
            'confidence_warning': 0.5,
            'confidence_critical': 0.3
        }
        
        # Performance statistics
        self._stats = {
            'total_queries': 0,
            'successful_queries': 0,
            'failed_queries': 0,
            'average_query_time': 0.0,
            'average_confidence': 0.0,
            'total_processed_documents': 0,
            'cache_hit_rate': 0.0
        }
    
    def start_monitoring(self, interval: float = 30.0):
        """Start continuous performance monitoring."""
        if self._monitoring_active:
            logger.warning("Performance monitoring already active")
            return
        
        self._monitoring_active = True
        self._monitor_thread = threading.Thread(target=self._monitoring_loop, args=(interval,), daemon=True)
        self._monitor_thread.start()
        logger.info(f"Performance monitoring started with {interval}s interval")
    
    def stop_monitoring(self):
        """Stop performance monitoring."""
        self._monitoring_active = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)
        logger.info("Performance monitoring stopped")
    
    def _monitoring_loop(self, interval: float):
        """Background monitoring loop."""
        while self._monitoring_active:
            try:
                self._collect_system_metrics()
                time.sleep(interval)
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
    
    def _collect_system_metrics(self):
        """Collect system resource metrics."""
        try:
            # CPU and memory
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Active connections (approximate)
            connections = len(psutil.net_connections())
            
            system_metrics = SystemMetrics(
                cpu_percent=cpu_percent,
                memory_percent=memory.percent,
                memory_used_mb=memory.used / (1024 * 1024),
                memory_available_mb=memory.available / (1024 * 1024),
                disk_usage_percent=disk.percent,
                disk_free_mb=disk.free / (1024 * 1024),
                active_connections=connections,
                timestamp=time.time()
            )
            
            with self._lock:
                self._system_metrics_history.append(system_metrics)
            
            # Check for alerts
            self._check_system_alerts(system_metrics)
            
        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
    
    def _check_system_alerts(self, metrics: SystemMetrics):
        """Check for system performance alerts."""
        alerts = []
        
        # Memory alerts
        if metrics.memory_percent > self.thresholds['memory_usage_critical']:
            alerts.append(f"CRITICAL: Memory usage at {metrics.memory_percent:.1f}%")
        elif metrics.memory_percent > self.thresholds['memory_usage_warning']:
            alerts.append(f"WARNING: Memory usage at {metrics.memory_percent:.1f}%")
        
        # CPU alerts
        if metrics.cpu_percent > 90:
            alerts.append(f"WARNING: CPU usage at {metrics.cpu_percent:.1f}%")
        
        # Disk space alerts
        if metrics.disk_usage_percent > 90:
            alerts.append(f"CRITICAL: Disk usage at {metrics.disk_usage_percent:.1f}%")
        
        # Log alerts
        for alert in alerts:
            logger.warning(f"Performance Alert: {alert}")
    
    def record_query(self, metrics: QueryMetrics):
        """Record query performance metrics."""
        with self._lock:
            self._query_metrics.append(metrics)
            
            # Update statistics
            self._stats['total_queries'] += 1
            if metrics.success:
                self._stats['successful_queries'] += 1
            else:
                self._stats['failed_queries'] += 1
            
            # Update rolling averages
            total_queries = self._stats['total_queries']
            self._stats['average_query_time'] = (
                (self._stats['average_query_time'] * (total_queries - 1) + metrics.execution_time) / total_queries
            )
            self._stats['average_confidence'] = (
                (self._stats['average_confidence'] * (total_queries - 1) + metrics.confidence_score) / total_queries
            )
        
        # Check for query alerts
        self._check_query_alerts(metrics)
    
    def _check_query_alerts(self, metrics: QueryMetrics):
        """Check for query performance alerts."""
        alerts = []
        
        # Query time alerts
        if metrics.execution_time > self.thresholds['query_time_critical']:
            alerts.append(f"CRITICAL: Query took {metrics.execution_time:.2f}s (>{self.thresholds['query_time_critical']}s)")
        elif metrics.execution_time > self.thresholds['query_time_warning']:
            alerts.append(f"WARNING: Query took {metrics.execution_time:.2f}s (>{self.thresholds['query_time_warning']}s)")
        
        # Confidence alerts
        if not metrics.success:
            alerts.append(f"ERROR: Query failed - {metrics.error_message}")
        elif metrics.confidence_score < self.thresholds['confidence_critical']:
            alerts.append(f"WARNING: Low confidence score: {metrics.confidence_score:.2f}")
        
        # Log alerts
        for alert in alerts:
            logger.warning(f"Query Alert: {alert}")
    
    def record_metric(self, name: str, value: float, unit: str = "", tags: Dict[str, str] = None):
        """Record a custom performance metric."""
        metric = PerformanceMetric(
            name=name,
            value=value,
            unit=unit,
            timestamp=time.time(),
            tags=tags or {}
        )
        
        with self._lock:
            self._metrics_history[name].append(metric)
    
    def get_query_performance(self, hours: int = 24) -> Dict[str, Any]:
        """Get query performance statistics for the specified time period."""
        cutoff_time = time.time() - (hours * 3600)
        
        with self._lock:
            recent_queries = [q for q in self._query_metrics if q.timestamp > cutoff_time]
        
        if not recent_queries:
            return {"message": "No query data available for the specified period"}
        
        # Calculate statistics
        successful_queries = [q for q in recent_queries if q.success]
        failed_queries = [q for q in recent_queries if not q.success]
        
        total_time = sum(q.execution_time for q in successful_queries)
        total_confidence = sum(q.confidence_score for q in successful_queries)
        
        return {
            "time_period_hours": hours,
            "total_queries": len(recent_queries),
            "successful_queries": len(successful_queries),
            "failed_queries": len(failed_queries),
            "success_rate": len(successful_queries) / len(recent_queries) if recent_queries else 0,
            "average_execution_time": total_time / len(successful_queries) if successful_queries else 0,
            "average_confidence": total_confidence / len(successful_queries) if successful_queries else 0,
            "total_processing_time": total_time,
            "queries_per_hour": len(recent_queries) / hours,
            "search_type_distribution": self._get_search_type_distribution(successful_queries),
            "slow_queries": self._get_slow_queries(successful_queries, 5),
            "low_confidence_queries": self._get_low_confidence_queries(successful_queries, 5)
        }
    
    def _get_search_type_distribution(self, queries: List[QueryMetrics]) -> Dict[str, int]:
        """Get distribution of search types."""
        distribution = defaultdict(int)
        for query in queries:
            distribution[query.search_type] += 1
        return dict(distribution)
    
    def _get_slow_queries(self, queries: List[QueryMetrics], limit: int) -> List[Dict[str, Any]]:
        """Get slowest queries."""
        sorted_queries = sorted(queries, key=lambda x: x.execution_time, reverse=True)
        return [
            {
                "query": q.query[:100] + "..." if len(q.query) > 100 else q.query,
                "execution_time": q.execution_time,
                "search_type": q.search_type,
                "timestamp": q.timestamp
            }
            for q in sorted_queries[:limit]
        ]
    
    def _get_low_confidence_queries(self, queries: List[QueryMetrics], limit: int) -> List[Dict[str, Any]]:
        """Get queries with lowest confidence scores."""
        sorted_queries = sorted(queries, key=lambda x: x.confidence_score)
        return [
            {
                "query": q.query[:100] + "..." if len(q.query) > 100 else q.query,
                "confidence_score": q.confidence_score,
                "results_count": q.results_count,
                "timestamp": q.timestamp
            }
            for q in sorted_queries[:limit]
        ]
    
    def get_system_performance(self, hours: int = 1) -> Dict[str, Any]:
        """Get system performance metrics for the specified time period."""
        cutoff_time = time.time() - (hours * 3600)
        
        with self._lock:
            recent_metrics = [m for m in self._system_metrics_history if m.timestamp > cutoff_time]
        
        if not recent_metrics:
            return {"message": "No system metrics available for the specified period"}
        
        # Calculate statistics
        avg_cpu = sum(m.cpu_percent for m in recent_metrics) / len(recent_metrics)
        avg_memory = sum(m.memory_percent for m in recent_metrics) / len(recent_metrics)
        avg_disk = sum(m.disk_usage_percent for m in recent_metrics) / len(recent_metrics)
        
        return {
            "time_period_hours": hours,
            "samples": len(recent_metrics),
            "average_cpu_percent": avg_cpu,
            "average_memory_percent": avg_memory,
            "average_disk_usage_percent": avg_disk,
            "peak_cpu_percent": max(m.cpu_percent for m in recent_metrics),
            "peak_memory_percent": max(m.memory_percent for m in recent_metrics),
            "current_memory_used_mb": recent_metrics[-1].memory_used_mb if recent_metrics else 0,
            "current_connections": recent_metrics[-1].active_connections if recent_metrics else 0,
            "resource_utilization_trend": self._calculate_resource_trend(recent_metrics)
        }
    
    def _calculate_resource_trend(self, metrics: List[SystemMetrics]) -> Dict[str, str]:
        """Calculate resource utilization trends."""
        if len(metrics) < 2:
            return {"cpu": "stable", "memory": "stable", "disk": "stable"}
        
        # Calculate simple trends (first half vs second half)
        mid_point = len(metrics) // 2
        first_half = metrics[:mid_point]
        second_half = metrics[mid_point:]
        
        cpu_trend = self._calculate_trend([m.cpu_percent for m in first_half], [m.cpu_percent for m in second_half])
        memory_trend = self._calculate_trend([m.memory_percent for m in first_half], [m.memory_percent for m in second_half])
        disk_trend = self._calculate_trend([m.disk_usage_percent for m in first_half], [m.disk_usage_percent for m in second_half])
        
        return {
            "cpu": cpu_trend,
            "memory": memory_trend,
            "disk": disk_trend
        }
    
    def _calculate_trend(self, first_half: List[float], second_half: List[float]) -> str:
        """Calculate trend direction."""
        if not first_half or not second_half:
            return "stable"
        
        first_avg = sum(first_half) / len(first_half)
        second_avg = sum(second_half) / len(second_half)
        
        difference = second_avg - first_avg
        threshold = 5.0  # 5% change threshold
        
        if difference > threshold:
            return "increasing"
        elif difference < -threshold:
            return "decreasing"
        else:
            return "stable"
    
    def get_performance_summary(self, hours: int = 24) -> Dict[str, Any]:
        """Get comprehensive performance summary."""
        query_performance = self.get_query_performance(hours)
        system_performance = self.get_system_performance(hours)
        
        # Get overall statistics
        with self._lock:
            stats = self._stats.copy()
        
        return {
            "timestamp": time.time(),
            "monitoring_period_hours": hours,
            "overall_statistics": stats,
            "query_performance": query_performance,
            "system_performance": system_performance,
            "alerts": self._get_recent_alerts(hours),
            "recommendations": self._generate_recommendations()
        }
    
    def _get_recent_alerts(self, hours: int) -> List[str]:
        """Get recent performance alerts."""
        # This would typically check an alerts log or database
        # For now, return empty list
        return []
    
    def _generate_recommendations(self) -> List[str]:
        """Generate performance optimization recommendations."""
        recommendations = []
        
        with self._lock:
            stats = self._stats.copy()
            recent_queries = list(self._query_metrics)[-100:]  # Last 100 queries
        
        # Memory usage recommendations
        if recent_queries:
            avg_memory = sum(q.memory_usage_mb for q in recent_queries) / len(recent_queries)
            if avg_memory > 500:  # MB
                recommendations.append("Consider optimizing memory usage by reducing batch sizes or implementing better garbage collection")
        
        # Query time recommendations
        if stats.get('average_query_time', 0) > 5.0:
            recommendations.append("Query performance is slow - consider optimizing ChromaDB indexes or implementing more aggressive caching")
        
        # Success rate recommendations
        success_rate = stats.get('successful_queries', 0) / max(stats.get('total_queries', 1), 1)
        if success_rate < 0.95:
            recommendations.append("Query success rate is below 95% - investigate error patterns and improve error handling")
        
        # Cache recommendations
        cache_hit_rate = stats.get('cache_hit_rate', 0)
        if cache_hit_rate < 0.7:
            recommendations.append("Cache hit rate is low - consider adjusting cache TTL or warming cache with frequently accessed data")
        
        return recommendations
    
    def export_metrics(self, filepath: str, hours: int = 24) -> bool:
        """Export performance metrics to file."""
        try:
            cutoff_time = time.time() - (hours * 3600)
            
            export_data = {
                "export_timestamp": time.time(),
                "time_period_hours": hours,
                "query_metrics": [q.to_dict() for q in self._query_metrics if q.timestamp > cutoff_time],
                "system_metrics": [m.to_dict() for m in self._system_metrics_history if m.timestamp > cutoff_time],
                "statistics": self._stats,
                "performance_summary": self.get_performance_summary(hours)
            }
            
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            logger.info(f"Performance metrics exported to {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to export metrics: {e}")
            return False


class PerformanceContext:
    """Context manager for performance tracking."""
    
    def __init__(
        self,
        monitor: PerformanceMonitor,
        operation_name: str,
        tags: Dict[str, str] = None,
        track_memory: bool = True
    ):
        self.monitor = monitor
        self.operation_name = operation_name
        self.tags = tags or {}
        self.track_memory = track_memory
        self.start_time = None
        self.start_memory = None
        self.end_time = None
        self.end_memory = None
    
    def __enter__(self):
        self.start_time = time.time()
        if self.track_memory:
            self.start_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # MB
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end_time = time.time()
        if self.track_memory:
            self.end_memory = psutil.Process().memory_info().rss / (1024 * 1024)  # MB
        
        execution_time = self.end_time - self.start_time
        memory_delta = (self.end_memory - self.start_memory) if self.track_memory else 0
        
        # Record metrics
        self.monitor.record_metric(
            name=f"{self.operation_name}_execution_time",
            value=execution_time,
            unit="seconds",
            tags=self.tags
        )
        
        if self.track_memory:
            self.monitor.record_metric(
                name=f"{self.operation_name}_memory_usage",
                value=memory_delta,
                unit="MB",
                tags=self.tags
            )
        
        # Log slow operations
        if execution_time > 5.0:
            logger.warning(f"Slow operation: {self.operation_name} took {execution_time:.2f}s")


def track_performance(
    monitor: PerformanceMonitor,
    operation_name: str,
    tags: Dict[str, str] = None,
    track_memory: bool = True
) -> Callable:
    """Decorator for automatic performance tracking."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            with PerformanceContext(monitor, operation_name, tags, track_memory):
                return await func(*args, **kwargs)
        return wrapper
    return decorator


# Global performance monitor instance
performance_monitor = PerformanceMonitor()


# Export main classes and functions
__all__ = [
    'PerformanceMonitor',
    'PerformanceContext',
    'QueryMetrics',
    'SystemMetrics',
    'PerformanceMetric',
    'track_performance',
    'performance_monitor'
]