"""
Comprehensive Test Suite for Utility Functions

This test file demonstrates and validates all utility functions created in the
utils package including validation, preprocessing, and common utilities.
"""

import sys
import os
import json
import time
import tempfile
from pathlib import Path

# Add the backend app directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

try:
    from app.utils.validation_utils import (
        InputValidator, DataSanitizer, FormatValidator, BusinessRuleValidator,
        validate_required_fields, validate_field_types, ValidationError
    )
    from app.utils.preprocessing_utils import (
        TextPreprocessor, DataCleaner, ContentNormalizer, FormatConverter,
        preprocess_text_for_search, extract_entities_from_text
    )
    from app.utils.common_utils import (
        ErrorHandling, PerformanceMonitor, FileSystemUtils, StringUtils,
        DataUtils, ConfigurationUtils, LoggingUtils, TestingUtils,
        RateLimiter, CircuitBreaker
    )
    from app.utils.common_utils import ConfigurationUtils
    from app.utils import (
        validate_email, sanitize_input, preprocess_text, get_safe_filename,
        generate_id, retry, timeout, measure_time, setup_logging,
        create_preprocessing_pipeline, USER_VALIDATION_RULES
    )
    UTILS_AVAILABLE = True
except ImportError as e:
    print(f"Import error: {e}")
    UTILS_AVAILABLE = False


class UtilityFunctionTests:
    """Comprehensive test suite for utility functions"""
    
    def __init__(self):
        self.test_results = []
        self.temp_dir = None
    
    def log_test(self, test_name: str, success: bool, message: str = ""):
        """Log test results"""
        status = "PASS" if success else "FAIL"
        self.test_results.append((test_name, status, message))
        print(f"[{status}] {test_name}: {message}")
    
    def setup(self):
        """Setup test environment"""
        self.temp_dir = tempfile.mkdtemp(prefix="utils_test_")
        print(f"Test directory: {self.temp_dir}")
    
    def cleanup(self):
        """Cleanup test environment"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            import shutil
            shutil.rmtree(self.temp_dir)
            print(f"Cleaned up test directory: {self.temp_dir}")
    
    # Validation Utils Tests
    def test_validation_utilities(self):
        """Test validation utility functions"""
        print("\n=== Testing Validation Utilities ===")
        
        # Test InputValidator
        try:
            # Email validation
            result = InputValidator.validate_email("test@example.com")
            self.log_test("Email validation - valid", result, "Valid email should return True")
            
            result = InputValidator.validate_email("invalid-email")
            self.log_test("Email validation - invalid", not result, "Invalid email should return False")
            
            # Phone validation
            result = InputValidator.validate_phone_number("+1234567890")
            self.log_test("Phone validation", result is not None, "Phone validation should work")
            
            # URL validation
            result = InputValidator.validate_url("https://example.com")
            self.log_test("URL validation - valid", result, "Valid URL should return True")
            
            result = InputValidator.validate_url("not-a-url")
            self.log_test("URL validation - invalid", not result, "Invalid URL should return False")
            
            # Password validation
            feedback = InputValidator.validate_password("StrongPass123!")
            self.log_test("Password validation - strong", feedback['is_valid'], "Strong password should be valid")
            
            weak_feedback = InputValidator.validate_password("weak")
            self.log_test("Password validation - weak", not weak_feedback['is_valid'], "Weak password should be invalid")
            
            # File type validation
            result = InputValidator.validate_file_type("image/jpeg", "image")
            self.log_test("File type validation", result, "Valid file type should return True")
            
            # UUID validation
            result = InputValidator.validate_uuid_format("123e4567-e89b-12d3-a456-426614174000")
            self.log_test("UUID validation", result, "Valid UUID should return True")
            
        except Exception as e:
            self.log_test("InputValidator tests", False, f"Error: {e}")
    
    def test_data_sanitization(self):
        """Test data sanitization functions"""
        print("\n=== Testing Data Sanitization ===")
        
        try:
            # HTML sanitization
            html_input = "<script>alert('xss')</script>Hello <strong>World</strong>"
            sanitized = DataSanitizer.sanitize_html(html_input)
            self.log_test("HTML sanitization", "<script>" not in sanitized, "Script tags should be removed")
            
            # Input sanitization
            sql_input = "'; DROP TABLE users; --"
            sanitized = DataSanitizer.sanitize_input(sql_input)
            self.log_test("SQL injection sanitization", "DROP TABLE" not in sanitized, "SQL commands should be removed")
            
            # Filename sanitization
            unsafe_filename = "../../../etc/passwd"
            sanitized = DataSanitizer.sanitize_filename(unsafe_filename)
            self.log_test("Filename sanitization", ".." not in sanitized, "Path traversal should be removed")
            
            # Text sanitization
            text_with_control_chars = "Hello\x00World\x1f"
            sanitized = DataSanitizer.sanitize_text(text_with_control_chars)
            self.log_test("Text sanitization", "\x00" not in sanitized, "Control characters should be removed")
            
        except Exception as e:
            self.log_test("DataSanitizer tests", False, f"Error: {e}")
    
    def test_format_validation(self):
        """Test format validation functions"""
        print("\n=== Testing Format Validation ===")
        
        try:
            # Date format validation
            result = FormatValidator.validate_date_format("2023-12-25", "%Y-%m-%d")
            self.log_test("Date format validation", result, "Valid date should return True")
            
            # Credit card validation (Luhn algorithm)
            result = FormatValidator.validate_credit_card_format("4532015112830366")  # Valid test card
            self.log_test("Credit card validation", result, "Valid card should return True")
            
            # Color code validation
            result = FormatValidator.validate_color_code("#FF5733")
            self.log_test("Color code validation", result, "Valid hex color should return True")
            
            # Coordinates validation
            result = FormatValidator.validate_coordinates(40.7128, -74.0060)
            self.log_test("Coordinates validation", result, "Valid coordinates should return True")
            
        except Exception as e:
            self.log_test("FormatValidator tests", False, f"Error: {e}")
    
    def test_business_validation(self):
        """Test business rule validation"""
        print("\n=== Testing Business Rule Validation ===")
        
        try:
            # User registration validation
            user_data = {
                'username': 'validuser',
                'email': 'user@example.com',
                'password': 'SecurePass123!',
                'birth_date': '1990-01-01'
            }
            result = BusinessRuleValidator.validate_user_registration(user_data)
            self.log_test("User registration validation", result['is_valid'], "Valid user data should pass")
            
            # Invalid user data
            invalid_user = {
                'username': 'ab',  # Too short
                'email': 'invalid-email',
                'password': 'weak',
                'birth_date': '2010-01-01'  # Too young
            }
            result = BusinessRuleValidator.validate_user_registration(invalid_user)
            self.log_test("Invalid user validation", not result['is_valid'], "Invalid user data should fail")
            
        except Exception as e:
            self.log_test("BusinessRuleValidator tests", False, f"Error: {e}")
    
    # Preprocessing Utils Tests
    def test_text_preprocessing(self):
        """Test text preprocessing functions"""
        print("\n=== Testing Text Preprocessing ===")
        
        try:
            # Text cleaning
            dirty_text = "Hello <script>alert('xss')</script>! Visit https://example.com"
            cleaned = TextPreprocessor.clean_text(dirty_text)
            self.log_test("Text cleaning", "<script>" not in cleaned, "HTML should be removed")
            
            # Abbreviation expansion
            text_with_abbrev = "u r great! thx!"
            expanded = TextPreprocessor.expand_abbreviations(text_with_abbrev)
            self.log_test("Abbreviation expansion", "you are" in expanded, "Abbreviations should be expanded")
            
            # Tokenization
            tokens = TextPreprocessor.tokenize_text("Hello world! How are you?")
            self.log_test("Tokenization", len(tokens) > 0, "Tokenization should produce tokens")
            
            # Keyword extraction
            keywords = TextPreprocessor.extract_keywords("This is a test sentence with some important keywords")
            self.log_test("Keyword extraction", len(keywords) > 0, "Keywords should be extracted")
            
            # Text normalization
            accented_text = "café résumé naïve"
            normalized = TextPreprocessor.normalize_text(accented_text, remove_accents=True)
            self.log_test("Text normalization", normalized != accented_text, "Accents should be removed")
            
        except Exception as e:
            self.log_test("TextPreprocessor tests", False, f"Error: {e}")
    
    def test_data_cleaning(self):
        """Test data cleaning functions"""
        print("\n=== Testing Data Cleaning ===")
        
        try:
            # Dictionary cleaning
            dirty_dict = {
                'name': 'John',
                'age': 25,
                'email': 'john@example.com',
                'empty': '',
                'none_value': None,
                'nested': {
                    'value': 123,
                    'empty_string': '',
                    'null': None
                }
            }
            cleaned = DataCleaner.clean_dict(dirty_dict)
            self.log_test("Dictionary cleaning", 'empty' not in cleaned, "Empty values should be removed")
            
            # List cleaning
            dirty_list = [1, 2, '', None, 4, '']
            cleaned_list = DataCleaner.clean_list(dirty_list)
            self.log_test("List cleaning", None not in cleaned_list and '' not in cleaned_list, "Null/empty values should be removed")
            
            # Key standardization
            mixed_keys = {'CamelCase': 1, 'snake_case': 2, 'PascalCase': 3}
            standardized = DataCleaner.standardize_keys(mixed_keys, 'snake')
            self.log_test("Key standardization", 'camel_case' in standardized, "Keys should be standardized")
            
        except Exception as e:
            self.log_test("DataCleaner tests", False, f"Error: {e}")
    
    def test_content_normalization(self):
        """Test content normalization functions"""
        print("\n=== Testing Content Normalization ===")
        
        try:
            # Text content normalization
            messy_text = "Hello\r\nWorld\n\nThis is\ta test."
            normalized = ContentNormalizer.normalize_text_content(messy_text)
            self.log_test("Text normalization", '\r' not in normalized, "Line endings should be normalized")
            
            # JSON normalization
            json_content = '{"b":1,"a":2,"c":3}'
            normalized_json = ContentNormalizer.normalize_json_content(json_content)
            parsed = json.loads(normalized_json)
            self.log_test("JSON normalization", parsed == {"a": 2, "b": 1, "c": 3}, "JSON should be sorted and formatted")
            
            # URL normalization
            messy_url = "https://example.com/path/to/resource?param1=value1&param2=value2"
            normalized_url = ContentNormalizer.normalize_url_content(messy_url)
            self.log_test("URL normalization", 'https://' in normalized_url, "URL should be normalized")
            
        except Exception as e:
            self.log_test("ContentNormalizer tests", False, f"Error: {e}")
    
    def test_format_conversion(self):
        """Test format conversion functions"""
        print("\n=== Testing Format Conversion ===")
        
        try:
            # CSV to dict list
            csv_content = "name,age,city\nJohn,25,NYC\nJane,30,LA"
            data = FormatConverter.csv_to_dict_list(csv_content)
            self.log_test("CSV to dict conversion", len(data) == 2 and data[0]['name'] == 'John', "CSV should convert to dict list")
            
            # List to string conversion
            items = ['apple', 'banana', 'cherry']
            string_result = FormatConverter.list_to_string(items, ', ')
            self.log_test("List to string conversion", string_result == 'apple, banana, cherry', "List should convert to string")
            
            # String to list conversion
            result = FormatConverter.string_to_list("a,b,c", ',')
            self.log_test("String to list conversion", result == ['a', 'b', 'c'], "String should convert to list")
            
            # Dict to query string
            params = {'name': 'John', 'age': 25, 'city': 'NYC'}
            query = FormatConverter.dict_to_query_string(params)
            self.log_test("Dict to query string", 'name=John' in query, "Dict should convert to query string")
            
        except Exception as e:
            self.log_test("FormatConverter tests", False, f"Error: {e}")
    
    # Common Utils Tests
    def test_file_system_utils(self):
        """Test file system utilities"""
        print("\n=== Testing File System Utilities ===")
        
        try:
            # Ensure directory
            test_dir = Path(self.temp_dir) / "test_subdir"
            result_dir = FileSystemUtils.ensure_directory(test_dir)
            self.log_test("Ensure directory", result_dir.exists(), "Directory should be created")
            
            # Safe filename
            unsafe_filename = "test<>file?.txt"
            safe_name = FileSystemUtils.safe_filename(unsafe_filename)
            self.log_test("Safe filename", '<' not in safe_name and '?' not in safe_name, "Invalid chars should be removed")
            
            # File info
            test_file = Path(self.temp_dir) / "test.txt"
            test_file.write_text("Test content")
            file_info = FileSystemUtils.get_file_info(test_file)
            self.log_test("File info", file_info.get('size') == 12, "File info should be correct")
            
            # Find files
            result_files = FileSystemUtils.find_files(self.temp_dir, "*.txt")
            self.log_test("Find files", len(result_files) >= 1, "Files should be found")
            
        except Exception as e:
            self.log_test("FileSystemUtils tests", False, f"Error: {e}")
    
    def test_string_utils(self):
        """Test string utilities"""
        print("\n=== Testing String Utilities ===")
        
        try:
            # Random string generation
            random_str = StringUtils.generate_random_string(10)
            self.log_test("Random string", len(random_str) == 10, "Random string should have correct length")
            
            # String truncation
            long_text = "This is a very long text that needs to be truncated"
            truncated = StringUtils.truncate_string(long_text, 20)
            self.log_test("String truncation", len(truncated) <= 23, "String should be truncated with suffix")
            
            # Camel to snake conversion
            camel_case = "CamelCaseString"
            snake_case = StringUtils.camel_to_snake(camel_case)
            self.log_test("Camel to snake", snake_case == "camel_case_string", "Camel case should convert to snake case")
            
            # Snake to camel conversion
            result = StringUtils.snake_to_camel("snake_case_string")
            self.log_test("Snake to camel", result == "snakeCaseString", "Snake case should convert to camel case")
            
            # Mask sensitive data
            sensitive = "123456789"
            masked = StringUtils.mask_sensitive_data(sensitive)
            self.log_test("Mask sensitive data", masked != sensitive, "Sensitive data should be masked")
            
        except Exception as e:
            self.log_test("StringUtils tests", False, f"Error: {e}")
    
    def test_data_utils(self):
        """Test data utilities"""
        print("\n=== Testing Data Utilities ===")
        
        try:
            # Deep merge
            dict1 = {'a': 1, 'b': {'x': 10}}
            dict2 = {'b': {'y': 20}, 'c': 3}
            merged = DataUtils.deep_merge(dict1, dict2)
            self.log_test("Deep merge", merged == {'a': 1, 'b': {'x': 10, 'y': 20}, 'c': 3}, "Dicts should be deeply merged")
            
            # Chunk list
            data = [1, 2, 3, 4, 5, 6, 7]
            chunks = DataUtils.chunk_list(data, 3)
            self.log_test("Chunk list", len(chunks) == 3 and chunks[-1] == [7], "List should be chunked correctly")
            
            # Group by
            data = [{'category': 'A', 'value': 1}, {'category': 'B', 'value': 2}, {'category': 'A', 'value': 3}]
            grouped = DataUtils.group_by(data, 'category')
            self.log_test("Group by", len(grouped['A']) == 2, "Data should be grouped correctly")
            
            # Remove duplicates
            data_with_dups = [1, 2, 2, 3, 3, 3, 4]
            unique = DataUtils.remove_duplicates(data_with_dups)
            self.log_test("Remove duplicates", unique == [1, 2, 3, 4], "Duplicates should be removed")
            
        except Exception as e:
            self.log_test("DataUtils tests", False, f"Error: {e}")
    
    def test_decorators_and_handlers(self):
        """Test decorators and error handlers"""
        print("\n=== Testing Decorators and Error Handlers ===")
        
        try:
            # Test retry decorator
            @retry(max_attempts=2, delay=0.1)
            def failing_function():
                raise ValueError("Test error")
            
            try:
                failing_function()
                self.log_test("Retry decorator", False, "Should have failed")
            except Exception:
                self.log_test("Retry decorator", True, "Retry should work as expected")
            
            # Test safe execute decorator
            @ErrorHandling.safe_execute(fallback_return="fallback")
            def safe_function():
                raise Exception("Test error")
            
            result = safe_function()
            self.log_test("Safe execute", result == "fallback", "Should return fallback value")
            
            # Test performance monitor
            @measure_time
            def slow_function():
                time.sleep(0.1)
                return "done"
            
            result = slow_function()
            self.log_test("Performance monitor", result == "done", "Function should complete")
            
            # Test rate limiter
            rate_limiter = RateLimiter(max_calls=5, time_window=1)
            
            @rate_limiter
            def limited_function():
                return "success"
            
            # Should work for first 5 calls
            for i in range(5):
                try:
                    result = limited_function()
                except Exception:
                    break
            else:
                # If we get here, all 5 calls succeeded
                self.log_test("Rate limiter", True, "Rate limiter should allow configured calls")
            
        except Exception as e:
            self.log_test("Decorator tests", False, f"Error: {e}")
    
    def test_convenience_functions(self):
        """Test convenience functions from package init"""
        print("\n=== Testing Convenience Functions ===")
        
        try:
            # Test quick validation functions
            result = validate_email("test@example.com")
            self.log_test("Quick email validation", result, "Quick email validation should work")
            
            # Test quick sanitization
            dirty_input = "<script>alert('xss')</script>Hello"
            clean_input = sanitize_input(dirty_input)
            self.log_test("Quick sanitization", "<script>" not in clean_input, "Quick sanitization should work")
            
            # Test quick preprocessing
            text = "Hello World! Visit https://example.com"
            processed = preprocess_text(text)
            self.log_test("Quick preprocessing", processed != text, "Quick preprocessing should work")
            
            # Test safe filename
            unsafe = "test<>file?.txt"
            safe = get_safe_filename(unsafe)
            self.log_test("Quick safe filename", '<' not in safe, "Quick filename sanitization should work")
            
            # Test ID generation
            user_id = generate_id(8)
            self.log_test("Quick ID generation", len(user_id) == 8, "ID generation should work")
            
            # Test preprocessing pipeline
            pipeline = create_preprocessing_pipeline()
            sample_text = "This is a test with <html>tags</html>"
            processed = pipeline.process(sample_text)
            self.log_test("Preprocessing pipeline", processed != sample_text, "Pipeline should process text")
            
        except Exception as e:
            self.log_test("Convenience function tests", False, f"Error: {e}")
    
    def test_configuration_and_setup(self):
        """Test configuration and setup functions"""
        print("\n=== Testing Configuration and Setup ===")
        
        try:
            # Test logging setup
            logger = setup_logging("test_logger", level="DEBUG")
            self.log_test("Logging setup", logger is not None, "Logger should be created")
            
            # Test configuration loading
            config_data = {
                "app_name": "Test App",
                "version": "1.0.0",
                "debug": True
            }
            config_file = Path(self.temp_dir) / "config.json"
            config_file.write_text(json.dumps(config_data))
            
            loaded_config = ConfigurationUtils.load_json_config(config_file)
            self.log_test("Config loading", loaded_config.get("app_name") == "Test App", "Config should be loaded")
            
        except Exception as e:
            self.log_test("Configuration tests", False, f"Error: {e}")
    
    def run_all_tests(self):
        """Run all tests"""
        print("=" * 80)
        print("COMPREHENSIVE UTILITY FUNCTIONS TEST SUITE")
        print("=" * 80)
        
        self.setup()
        
        try:
            if UTILS_AVAILABLE:
                self.test_validation_utilities()
                self.test_data_sanitization()
                self.test_format_validation()
                self.test_business_validation()
                self.test_text_preprocessing()
                self.test_data_cleaning()
                self.test_content_normalization()
                self.test_format_conversion()
                self.test_file_system_utils()
                self.test_string_utils()
                self.test_data_utils()
                self.test_decorators_and_handlers()
                self.test_convenience_functions()
                self.test_configuration_and_setup()
            else:
                print("ERROR: Utility modules could not be imported")
                self.log_test("Import verification", False, "All utility modules should be importable")
        
        finally:
            self.cleanup()
        
        self.print_summary()
    
    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        passed = sum(1 for _, status, _ in self.test_results if status == "PASS")
        failed = sum(1 for _, status, _ in self.test_results if status == "FAIL")
        total = len(self.test_results)
        
        print(f"Total Tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {failed}")
        print(f"Success Rate: {(passed/total*100):.1f}%" if total > 0 else "No tests run")
        
        if failed > 0:
            print("\nFailed Tests:")
            for test_name, status, message in self.test_results:
                if status == "FAIL":
                    print(f"  - {test_name}: {message}")
        
        print("\n" + "=" * 80)
        
        # Return success status for CI/CD integration
        return failed == 0


def main():
    """Main test execution"""
    test_suite = UtilityFunctionTests()
    success = test_suite.run_all_tests()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
