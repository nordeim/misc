"""
Document Processing Utilities for RAG System.

This module provides utilities for parsing and processing various document formats
including PDF, DOCX, TXT, MD, and HTML files for ingestion into the RAG system.

Features:
- Multi-format document parsing
- Content extraction and cleaning
- Metadata extraction
- Document validation and security
- Batch processing capabilities
"""

import asyncio
import hashlib
import json
import logging
import mimetypes
import os
import re
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
import uuid

import PyPDF2
import docx
from bs4 import BeautifulSoup
import markdown
from pypdf import PdfReader
from docx import Document
import html2text

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class DocumentInfo:
    """Information about a processed document."""
    file_path: str
    content: str
    metadata: Dict[str, Any]
    file_type: str
    file_size: int
    processing_time: float
    validation_status: str
    errors: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class DocumentParser:
    """Handles parsing of various document formats."""
    
    def __init__(self):
        self.supported_formats = settings.document_supported_formats
        self.max_file_size = settings.document_max_size_bytes
        
        # Initialize parsers
        self.html_parser = html2text.HTML2Text()
        self.html_parser.ignore_links = True
        self.html_parser.ignore_images = True
    
    async def parse_file(self, file_path: str) -> DocumentInfo:
        """
        Parse a document file and extract content and metadata.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            DocumentInfo with parsed content and metadata
        """
        start_time = time.time()
        file_path_obj = Path(file_path)
        
        if not file_path_obj.exists():
            return DocumentInfo(
                file_path=file_path,
                content="",
                metadata={},
                file_type="unknown",
                file_size=0,
                processing_time=time.time() - start_time,
                validation_status="failed",
                errors=[f"File not found: {file_path}"]
            )
        
        # Validate file
        validation_status, errors = self._validate_file(file_path_obj)
        if validation_status != "valid":
            return DocumentInfo(
                file_path=file_path,
                content="",
                metadata=self._extract_basic_metadata(file_path_obj),
                file_type=file_path_obj.suffix.lower().lstrip('.'),
                file_size=file_path_obj.stat().st_size,
                processing_time=time.time() - start_time,
                validation_status=validation_status,
                errors=errors
            )
        
        try:
            # Extract content based on file type
            content, extraction_errors = await self._extract_content(file_path_obj)
            
            # Extract metadata
            metadata = self._extract_basic_metadata(file_path_obj)
            metadata.update({
                "hash": self._calculate_file_hash(file_path_obj),
                "mime_type": mimetypes.guess_type(file_path)[0],
                "extracted_at": time.time()
            })
            
            processing_time = time.time() - start_time
            
            return DocumentInfo(
                file_path=file_path,
                content=content,
                metadata=metadata,
                file_type=file_path_obj.suffix.lower().lstrip('.'),
                file_size=file_path_obj.stat().st_size,
                processing_time=processing_time,
                validation_status="valid",
                errors=extraction_errors
            )
            
        except Exception as e:
            error_msg = f"Failed to parse file {file_path}: {str(e)}"
            logger.error(error_msg)
            
            return DocumentInfo(
                file_path=file_path,
                content="",
                metadata=self._extract_basic_metadata(file_path_obj),
                file_type=file_path_obj.suffix.lower().lstrip('.'),
                file_size=file_path_obj.stat().st_size,
                processing_time=time.time() - start_time,
                validation_status="failed",
                errors=[error_msg]
            )
    
    def _validate_file(self, file_path: Path) -> Tuple[str, List[str]]:
        """
        Validate file for processing.
        
        Args:
            file_path: Path object for the file
            
        Returns:
            Tuple of (validation_status, list_of_errors)
        """
        errors = []
        
        # Check if file exists
        if not file_path.exists():
            return "not_found", ["File does not exist"]
        
        # Check file size
        file_size = file_path.stat().st_size
        if file_size == 0:
            errors.append("File is empty")
        elif file_size > self.max_file_size:
            errors.append(f"File too large: {file_size} bytes (max: {self.max_file_size})")
        
        # Check file format
        file_ext = file_path.suffix.lower().lstrip('.')
        if file_ext not in self.supported_formats:
            errors.append(f"Unsupported file format: {file_ext}")
        
        # Check if file is readable
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                f.read(1024)  # Try to read first 1KB
        except UnicodeDecodeError:
            # Try different encodings
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    f.read(1024)
            except Exception:
                errors.append("File encoding not supported")
        except Exception as e:
            errors.append(f"File not readable: {str(e)}")
        
        if errors:
            return "invalid", errors
        return "valid", []
    
    async def _extract_content(self, file_path: Path) -> Tuple[str, List[str]]:
        """
        Extract content from a document file.
        
        Args:
            file_path: Path object for the file
            
        Returns:
            Tuple of (content_string, list_of_errors)
        """
        errors = []
        file_ext = file_path.suffix.lower().lstrip('.')
        
        try:
            if file_ext == 'pdf':
                content = await self._extract_pdf_content(file_path)
            elif file_ext == 'docx':
                content = await self._extract_docx_content(file_path)
            elif file_ext == 'txt':
                content = await self._extract_txt_content(file_path)
            elif file_ext == 'md':
                content = await self._extract_markdown_content(file_path)
            elif file_ext == 'html':
                content = await self._extract_html_content(file_path)
            else:
                # Fallback to text extraction
                content = await self._extract_txt_content(file_path)
                errors.append(f"No specific parser for {file_ext}, used text parser")
            
            # Clean content
            content = self._clean_content(content)
            
            return content, errors
            
        except Exception as e:
            error_msg = f"Content extraction failed: {str(e)}"
            logger.error(error_msg)
            return "", [error_msg]
    
    async def _extract_pdf_content(self, file_path: Path) -> str:
        """Extract text content from PDF file."""
        try:
            # Try PyPDF2 first
            content = []
            with open(file_path, 'rb') as file:
                reader = PdfReader(file)
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        content.append(page_text)
            
            if not content:
                # Fallback to PyPDF2
                content = []
                with open(file_path, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    for page in pdf_reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            content.append(page_text)
            
            return '\n'.join(content)
            
        except Exception as e:
            logger.error(f"PDF extraction failed: {e}")
            raise
    
    async def _extract_docx_content(self, file_path: Path) -> str:
        """Extract text content from DOCX file."""
        try:
            doc = Document(file_path)
            content = []
            
            # Extract paragraphs
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    content.append(paragraph.text)
            
            # Extract tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_text.append(cell.text.strip())
                    if row_text:
                        content.append(' | '.join(row_text))
            
            return '\n'.join(content)
            
        except Exception as e:
            logger.error(f"DOCX extraction failed: {e}")
            raise
    
    async def _extract_txt_content(self, file_path: Path) -> str:
        """Extract text content from TXT file."""
        # Try UTF-8 first
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return file.read()
        except UnicodeDecodeError:
            # Try other encodings
            encodings = ['latin-1', 'cp1252', 'iso-8859-1']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as file:
                        return file.read()
                except UnicodeDecodeError:
                    continue
            raise Exception("Could not decode file with any supported encoding")
    
    async def _extract_markdown_content(self, file_path: Path) -> str:
        """Extract and convert markdown content to text."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                markdown_content = file.read()
            
            # Convert markdown to HTML, then to text
            html = markdown.markdown(markdown_content)
            return self.html_parser.handle(html)
            
        except Exception as e:
            logger.error(f"Markdown extraction failed: {e}")
            # Fallback to text extraction
            return await self._extract_txt_content(file_path)
    
    async def _extract_html_content(self, file_path: Path) -> str:
        """Extract text content from HTML file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                html_content = file.read()
            
            # Parse HTML and extract text
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Get text content
            text = soup.get_text()
            
            # Clean up whitespace
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            return text
            
        except Exception as e:
            logger.error(f"HTML extraction failed: {e}")
            raise
    
    def _extract_basic_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract basic file metadata."""
        stat = file_path.stat()
        
        return {
            "source_file": file_path.name,
            "source_path": str(file_path),
            "file_extension": file_path.suffix.lower().lstrip('.'),
            "file_size": stat.st_size,
            "created_at": stat.st_ctime,
            "modified_at": stat.st_mtime,
            "mime_type": mimetypes.guess_type(str(file_path))[0],
        }
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA256 hash of file."""
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as file:
            for chunk in iter(lambda: file.read(4096), b""):
                hasher.update(chunk)
        return hasher.hexdigest()
    
    def _clean_content(self, content: str) -> str:
        """Clean and normalize extracted content."""
        # Remove excessive whitespace
        content = re.sub(r'\s+', ' ', content)
        
        # Remove control characters except newlines and tabs
        content = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', content)
        
        # Normalize line endings
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        
        # Remove excessive blank lines
        content = re.sub(r'\n\s*\n\s*\n+', '\n\n', content)
        
        return content.strip()


class BatchDocumentProcessor:
    """Process multiple documents in batch with optimization."""
    
    def __init__(self, max_concurrent: int = 5):
        self.parser = DocumentParser()
        self.max_concurrent = max_concurrent
    
    async def process_files(
        self,
        file_paths: List[str],
        progress_callback: Optional[callable] = None
    ) -> List[DocumentInfo]:
        """
        Process multiple document files concurrently.
        
        Args:
            file_paths: List of file paths to process
            progress_callback: Optional callback function for progress updates
            
        Returns:
            List of DocumentInfo objects for processed files
        """
        semaphore = asyncio.Semaphore(self.max_concurrent)
        
        async def process_single_file(file_path: str) -> DocumentInfo:
            async with semaphore:
                try:
                    result = await self.parser.parse_file(file_path)
                    if progress_callback:
                        progress_callback(1)
                    return result
                except Exception as e:
                    logger.error(f"Failed to process {file_path}: {str(e)}")
                    return DocumentInfo(
                        file_path=file_path,
                        content="",
                        metadata={},
                        file_type="unknown",
                        file_size=0,
                        processing_time=0,
                        validation_status="failed",
                        errors=[str(e)]
                    )
        
        # Process files concurrently
        tasks = [process_single_file(file_path) for file_path in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle exceptions and filter results
        processed_results = []
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Batch processing error: {str(result)}")
                continue
            processed_results.append(result)
        
        return processed_results
    
    async def process_directory(
        self,
        directory_path: str,
        recursive: bool = True,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        progress_callback: Optional[callable] = None
    ) -> List[DocumentInfo]:
        """
        Process all documents in a directory.
        
        Args:
            directory_path: Path to directory containing documents
            recursive: Whether to search subdirectories
            include_patterns: File name patterns to include (e.g., ['*.pdf', '*.docx'])
            exclude_patterns: File name patterns to exclude
            progress_callback: Optional callback function for progress updates
            
        Returns:
            List of DocumentInfo objects for processed files
        """
        directory = Path(directory_path)
        if not directory.exists():
            raise ValueError(f"Directory not found: {directory_path}")
        
        # Find files
        file_paths = []
        glob_patterns = [f"*.{ext}" for ext in self.parser.supported_formats]
        
        if recursive:
            for pattern in glob_patterns:
                file_paths.extend(directory.rglob(pattern))
        else:
            for pattern in glob_patterns:
                file_paths.extend(directory.glob(pattern))
        
        # Filter by include/exclude patterns
        if include_patterns:
            include_files = []
            for pattern in include_patterns:
                include_files.extend(directory.rglob(pattern) if recursive else directory.glob(pattern))
            file_paths = [f for f in file_paths if f in include_files]
        
        if exclude_patterns:
            exclude_files = set()
            for pattern in exclude_patterns:
                exclude_files.update(
                    directory.rglob(pattern) if recursive else directory.glob(pattern)
                )
            file_paths = [f for f in file_paths if f not in exclude_files]
        
        # Convert to string paths
        file_paths = [str(f) for f in file_paths]
        
        logger.info(f"Found {len(file_paths)} files to process in {directory_path}")
        
        # Process files
        return await self.process_files(file_paths, progress_callback)


# Utility functions for common document processing tasks

def validate_document_content(content: str) -> Tuple[bool, str]:
    """
    Validate document content for RAG processing.
    
    Args:
        content: Document content to validate
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not content or len(content.strip()) < 10:
        return False, "Document content too short"
    
    # Check for excessive whitespace
    non_whitespace_ratio = len(re.sub(r'\s', '', content)) / len(content)
    if non_whitespace_ratio < 0.1:
        return False, "Document contains excessive whitespace"
    
    # Check for meaningful content
    word_count = len(content.split())
    if word_count < 5:
        return False, "Document has insufficient word count"
    
    return True, "Valid"


def extract_document_summary(content: str, max_length: int = 200) -> str:
    """
    Extract a summary from document content.
    
    Args:
        content: Document content
        max_length: Maximum length of summary
        
    Returns:
        Summary string
    """
    # Simple summary extraction - take first sentences until max length
    sentences = re.split(r'[.!?]+', content)
    summary_parts = []
    current_length = 0
    
    for sentence in sentences:
        sentence = sentence.strip()
        if current_length + len(sentence) + 1 <= max_length:
            summary_parts.append(sentence)
            current_length += len(sentence) + 1
        else:
            # Add partial sentence if it fits
            remaining_length = max_length - current_length - 1
            if remaining_length > 10:
                summary_parts.append(sentence[:remaining_length] + "...")
            break
    
    return '. '.join(summary_parts) + ('.' if summary_parts and not summary_parts[-1].endswith('.') else '')


def calculate_content_hash(content: str) -> str:
    """Calculate hash of document content."""
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


# Export main classes and functions
__all__ = [
    'DocumentParser',
    'BatchDocumentProcessor', 
    'DocumentInfo',
    'validate_document_content',
    'extract_document_summary',
    'calculate_content_hash'
]