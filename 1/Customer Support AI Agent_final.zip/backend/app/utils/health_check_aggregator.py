"""
Health Check Aggregator and Advanced Monitoring.

This module provides comprehensive health monitoring and aggregation capabilities:
- Multi-level health check aggregation
- Health trend analysis
- Service dependency health monitoring
- Health-based alerting and notifications
- Health dashboard data generation
- Proactive health recommendations
- Health score calculation
- Historical health data analysis

Features:
- Hierarchical health checks
- Dependency-aware health assessment
- Health trend prediction
- Automated health remediation suggestions
- Comprehensive health reporting
"""

import asyncio
import time
import logging
import json
from typing import Dict, List, Optional, Any, Callable, Union
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from collections import defaultdict, deque
from enum import Enum
import statistics

from app.monitoring.health_check import (
    HealthCheckOrchestrator, HealthCheckResult, HealthStatus,
    BaseHealthCheck, register_health_check, health_orchestrator
)
from app.services.observability_service import get_observability_service

logger = logging.getLogger(__name__)

class HealthLevel(Enum):
    """Health check aggregation levels."""
    COMPONENT = "component"      # Individual component health
    SERVICE = "service"          # Service-level health
    SYSTEM = "system"           # Overall system health
    BUSINESS = "business"       # Business process health

class HealthTrend(Enum):
    """Health trend indicators."""
    IMPROVING = "improving"
    STABLE = "stable"
    DEGRADING = "degrading"
    CRITICAL = "critical"

@dataclass
class HealthMetric:
    """Individual health metric."""
    name: str
    value: float
    threshold_warning: float
    threshold_critical: float
    unit: str
    weight: float = 1.0
    direction: str = "lower"  # "lower" means lower is better, "higher" means higher is better

@dataclass
class ComponentHealth:
    """Health status of a system component."""
    name: str
    level: HealthLevel
    status: HealthStatus
    score: float  # 0.0 to 1.0
    metrics: Dict[str, HealthMetric] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    last_check: Optional[datetime] = None
    uptime_percentage: float = 100.0
    issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)

@dataclass
class HealthAggregationResult:
    """Result of health aggregation."""
    overall_status: HealthStatus
    overall_score: float
    component_health: Dict[str, ComponentHealth]
    system_metrics: Dict[str, float]
    health_trend: HealthTrend
    critical_issues: List[str]
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.utcnow)

class HealthMetricCollector:
    """Collects and analyzes health metrics."""
    
    def __init__(self, max_history: int = 1000):
        self.max_history = max_history
        self.metric_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=max_history))
        
    def add_metric(self, name: str, value: float, unit: str = "", timestamp: datetime = None):
        """Add a metric to history."""
        if timestamp is None:
            timestamp = datetime.utcnow()
        
        self.metric_history[name].append({
            "value": value,
            "timestamp": timestamp,
            "unit": unit
        })
    
    def get_metric_value(self, name: str, minutes: int = 5) -> Optional[float]:
        """Get recent metric value."""
        cutoff_time = datetime.utcnow() - timedelta(minutes=minutes)
        
        for entry in reversed(self.metric_history[name]):
            if entry["timestamp"] >= cutoff_time:
                return entry["value"]
        
        return None
    
    def calculate_trend(self, name: str, hours: int = 1) -> HealthTrend:
        """Calculate health trend for a metric."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        values = [
            entry["value"] for entry in self.metric_history[name]
            if entry["timestamp"] >= cutoff_time
        ]
        
        if len(values) < 3:
            return HealthTrend.STABLE
        
        # Calculate trend using linear regression
        n = len(values)
        x_sum = sum(range(n))
        y_sum = sum(values)
        xy_sum = sum(i * values[i] for i in range(n))
        x2_sum = sum(i * i for i in range(n))
        
        slope = (n * xy_sum - x_sum * y_sum) / (n * x2_sum - x_sum * x_sum)
        
        if slope > 0.1:
            return HealthTrend.IMPROVING
        elif slope < -0.1:
            return HealthTrend.DEGRADING
        else:
            return HealthTrend.STABLE

class ServiceHealthCheck(BaseHealthCheck):
    """Advanced service health check with dependency analysis."""
    
    def __init__(self, service_name: str, dependencies: List[str] = None, critical: bool = True):
        super().__init__(f"service_{service_name}", timeout=10.0)
        self.service_name = service_name
        self.dependencies = dependencies or []
        self.critical = critical
        self.start_time = time.time()
        self.health_history = deque(maxlen=100)
    
    async def check(self) -> HealthCheckResult:
        """Perform comprehensive service health check."""
        start_time = time.time()
        
        try:
            # Check service availability
            service_status = await self._check_service_availability()
            
            # Check dependencies
            dependency_status = await self._check_dependencies()
            
            # Check performance metrics
            performance_status = await self._check_performance_metrics()
            
            # Check resource usage
            resource_status = await self._check_resource_usage()
            
            # Aggregate results
            overall_status = self._aggregate_status([
                service_status, dependency_status, performance_status, resource_status
            ])
            
            duration_ms = (time.time() - start_time) * 1000
            
            # Store health history
            self.health_history.append({
                "timestamp": datetime.utcnow(),
                "status": overall_status,
                "duration": duration_ms
            })
            
            return HealthCheckResult(
                service=self.service_name,
                status=overall_status,
                message=f"Service health check completed",
                details={
                    "service_availability": service_status.value,
                    "dependency_health": dependency_status.value,
                    "performance_status": performance_status.value,
                    "resource_status": resource_status.value,
                    "dependencies": self.dependencies
                },
                duration_ms=duration_ms
            )
            
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            return HealthCheckResult(
                service=self.service_name,
                status=HealthStatus.UNHEALTHY,
                message=f"Service health check failed: {str(e)}",
                error=str(e),
                duration_ms=duration_ms
            )
    
    async def _check_service_availability(self) -> HealthStatus:
        """Check basic service availability."""
        # This would implement actual service availability checks
        # For now, simulate a check
        await asyncio.sleep(0.1)
        return HealthStatus.HEALTHY
    
    async def _check_dependencies(self) -> HealthStatus:
        """Check dependency health."""
        if not self.dependencies:
            return HealthStatus.HEALTHY
        
        # This would check actual dependencies
        # For now, assume healthy
        return HealthStatus.HEALTHY
    
    async def _check_performance_metrics(self) -> HealthStatus:
        """Check service performance metrics."""
        # This would check response times, throughput, etc.
        return HealthStatus.HEALTHY
    
    async def _check_resource_usage(self) -> HealthStatus:
        """Check resource usage."""
        import psutil
        
        cpu_percent = psutil.cpu_percent(interval=1)
        memory_percent = psutil.virtual_memory().percent
        
        if cpu_percent > 90 or memory_percent > 90:
            return HealthStatus.UNHEALTHY
        elif cpu_percent > 75 or memory_percent > 75:
            return HealthStatus.DEGRADED
        
        return HealthStatus.HEALTHY
    
    def _aggregate_status(self, statuses: List[HealthStatus]) -> HealthStatus:
        """Aggregate multiple health statuses."""
        if HealthStatus.UNHEALTHY in statuses:
            return HealthStatus.UNHEALTHY
        elif HealthStatus.DEGRADED in statuses:
            return HealthStatus.DEGRADED
        elif all(status == HealthStatus.HEALTHY for status in statuses):
            return HealthStatus.HEALTHY
        else:
            return HealthStatus.UNKNOWN
    
    def get_health_trend(self, hours: int = 24) -> HealthTrend:
        """Get health trend over specified period."""
        if len(self.health_history) < 2:
            return HealthTrend.STABLE
        
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        recent_health = [
            entry for entry in self.health_history
            if entry["timestamp"] >= cutoff_time
        ]
        
        if len(recent_health) < 3:
            return HealthTrend.STABLE
        
        # Convert statuses to numeric values for trend analysis
        status_values = []
        for entry in recent_health:
            if entry["status"] == HealthStatus.HEALTHY:
                status_values.append(1.0)
            elif entry["status"] == HealthStatus.DEGRADED:
                status_values.append(0.5)
            else:
                status_values.append(0.0)
        
        # Calculate trend
        if len(status_values) < 3:
            return HealthTrend.STABLE
        
        # Simple trend calculation
        n = len(status_values)
        first_half = status_values[:n//2]
        second_half = status_values[n//2:]
        
        if not first_half or not second_half:
            return HealthTrend.STABLE
        
        first_avg = sum(first_half) / len(first_half)
        second_avg = sum(second_half) / len(second_half)
        
        improvement = second_avg - first_avg
        
        if improvement > 0.2:
            return HealthTrend.IMPROVING
        elif improvement < -0.2:
            return HealthTrend.DEGRADING
        else:
            return HealthTrend.STABLE
    
    def get_uptime_percentage(self, hours: int = 24) -> float:
        """Calculate uptime percentage."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        recent_health = [
            entry for entry in self.health_history
            if entry["timestamp"] >= cutoff_time
        ]
        
        if not recent_health:
            return 100.0
        
        healthy_checks = sum(
            1 for entry in recent_health
            if entry["status"] == HealthStatus.HEALTHY
        )
        
        return (healthy_checks / len(recent_health)) * 100

class HealthAggregator:
    """Main health aggregation and analysis system."""
    
    def __init__(self):
        self.metric_collector = HealthMetricCollector()
        self.service_health_checks: Dict[str, ServiceHealthCheck] = {}
        self.component_health: Dict[str, ComponentHealth] = {}
        self.health_rules = self._load_health_rules()
        self.recommendation_engine = HealthRecommendationEngine()
        
        logger.info("Health aggregator initialized")
    
    def _load_health_rules(self) -> Dict[str, Dict[str, Any]]:
        """Load health evaluation rules."""
        return {
            "response_time": {
                "warning_threshold": 2.0,  # seconds
                "critical_threshold": 5.0,
                "weight": 0.3
            },
            "error_rate": {
                "warning_threshold": 0.05,  # 5%
                "critical_threshold": 0.1,  # 10%
                "weight": 0.3
            },
            "cpu_usage": {
                "warning_threshold": 70.0,  # 70%
                "critical_threshold": 85.0,
                "weight": 0.2
            },
            "memory_usage": {
                "warning_threshold": 75.0,  # 75%
                "critical_threshold": 90.0,
                "weight": 0.2
            },
            "availability": {
                "warning_threshold": 99.0,  # 99%
                "critical_threshold": 95.0,  # 95%
                "weight": 0.5
            }
        }
    
    def register_service_health_check(self, service_name: str, dependencies: List[str] = None, critical: bool = True):
        """Register a service for health monitoring."""
        health_check = ServiceHealthCheck(service_name, dependencies, critical)
        self.service_health_checks[service_name] = health_check
        
        # Register with health orchestrator
        register_health_check(health_check)
        
        logger.info("Service health check registered", service=service_name, critical=critical)
    
    async def aggregate_health(self) -> HealthAggregationResult:
        """Perform comprehensive health aggregation."""
        try:
            # Get component health status
            component_health = await self._get_component_health()
            
            # Get system metrics
            system_metrics = await self._collect_system_metrics()
            
            # Calculate overall health
            overall_status, overall_score = self._calculate_overall_health(component_health, system_metrics)
            
            # Determine health trend
            health_trend = self._calculate_health_trend(component_health)
            
            # Identify critical issues
            critical_issues = self._identify_critical_issues(component_health, system_metrics)
            
            # Generate recommendations
            recommendations = self.recommendation_engine.generate_recommendations(
                component_health, system_metrics, critical_issues
            )
            
            result = HealthAggregationResult(
                overall_status=overall_status,
                overall_score=overall_score,
                component_health=component_health,
                system_metrics=system_metrics,
                health_trend=health_trend,
                critical_issues=critical_issues,
                recommendations=recommendations
            )
            
            logger.debug("Health aggregation completed",
                        overall_status=overall_status.value,
                        score=overall_score,
                        components=len(component_health))
            
            return result
            
        except Exception as e:
            logger.error("Health aggregation failed", error=str(e))
            return HealthAggregationResult(
                overall_status=HealthStatus.UNKNOWN,
                overall_score=0.0,
                component_health={},
                system_metrics={},
                health_trend=HealthTrend.CRITICAL,
                critical_issues=[f"Health aggregation failed: {str(e)}"],
                recommendations=["Check system logs for health aggregation errors"]
            )
    
    async def _get_component_health(self) -> Dict[str, ComponentHealth]:
        """Get health status for all components."""
        component_health = {}
        
        # Get basic component health from health orchestrator
        health_results = await health_orchestrator.run_all_checks()
        
        for check_name, result in health_results.items():
            component = ComponentHealth(
                name=check_name,
                level=HealthLevel.COMPONENT,
                status=result.status,
                score=self._calculate_component_score(result),
                last_check=datetime.fromtimestamp(result.timestamp) if result.timestamp else None,
                issues=[result.message] if result.status != HealthStatus.HEALTHY else [],
            )
            
            component_health[check_name] = component
        
        # Add service-level health
        for service_name, health_check in self.service_health_checks.items():
            component = ComponentHealth(
                name=service_name,
                level=HealthLevel.SERVICE,
                status=HealthStatus.HEALTHY,  # Would be determined by actual health check
                score=0.9,  # Placeholder
                uptime_percentage=health_check.get_uptime_percentage(),
                dependencies=health_check.dependencies
            )
            
            component_health[f"service_{service_name}"] = component
        
        return component_health
    
    async def _collect_system_metrics(self) -> Dict[str, float]:
        """Collect system-level metrics."""
        import psutil
        import requests
        
        metrics = {}
        
        try:
            # CPU and Memory
            metrics['cpu_usage'] = psutil.cpu_percent(interval=1)
            metrics['memory_usage'] = psutil.virtual_memory().percent
            
            # Disk
            disk = psutil.disk_usage('/')
            metrics['disk_usage'] = (disk.used / disk.total) * 100
            
            # Network connections
            metrics['active_connections'] = len(psutil.net_connections())
            
            # Process count
            metrics['process_count'] = len(psutil.pids())
            
            # Load average (Unix systems)
            try:
                metrics['load_average'] = psutil.getloadavg()[0] if hasattr(psutil, 'getloadavg') else 0.0
            except:
                metrics['load_average'] = 0.0
            
            # Application-specific metrics
            obs_service = get_observability_service()
            service_metrics = obs_service._service_metrics
            
            metrics['uptime_hours'] = service_metrics.uptime_seconds / 3600
            metrics['total_requests'] = service_metrics.total_requests
            metrics['error_rate'] = (
                service_metrics.error_count / max(service_metrics.total_requests, 1)
            )
            metrics['avg_response_time'] = service_metrics.avg_response_time
            
        except Exception as e:
            logger.error("Failed to collect system metrics", error=str(e))
        
        return metrics
    
    def _calculate_component_score(self, health_result: HealthCheckResult) -> float:
        """Calculate component health score."""
        if health_result.status == HealthStatus.HEALTHY:
            return 1.0
        elif health_result.status == HealthStatus.DEGRADED:
            return 0.6
        elif health_result.status == HealthStatus.UNHEALTHY:
            return 0.2
        else:
            return 0.5
    
    def _calculate_overall_health(self, component_health: Dict[str, ComponentHealth], system_metrics: Dict[str, float]) -> tuple[HealthStatus, float]:
        """Calculate overall system health and score."""
        if not component_health:
            return HealthStatus.UNKNOWN, 0.0
        
        # Calculate weighted score
        total_score = 0.0
        total_weight = 0.0
        
        # Component scores (weight: 0.7)
        for component in component_health.values():
            weight = 1.0  # Could be different per component
            total_score += component.score * weight * 0.7
            total_weight += weight * 0.7
        
        # System metric scores (weight: 0.3)
        metric_score = self._calculate_system_metric_score(system_metrics)
        total_score += metric_score * 0.3
        total_weight += 0.3
        
        if total_weight == 0:
            final_score = 0.0
        else:
            final_score = total_score / total_weight
        
        # Determine status based on score
        if final_score >= 0.8:
            status = HealthStatus.HEALTHY
        elif final_score >= 0.6:
            status = HealthStatus.DEGRADED
        elif final_score >= 0.3:
            status = HealthStatus.UNHEALTHY
        else:
            status = HealthStatus.UNKNOWN
        
        return status, final_score
    
    def _calculate_system_metric_score(self, system_metrics: Dict[str, float]) -> float:
        """Calculate score based on system metrics."""
        scores = []
        
        for metric_name, value in system_metrics.items():
            if metric_name in self.health_rules:
                rule = self.health_rules[metric_name]
                
                if metric_name in ['cpu_usage', 'memory_usage', 'disk_usage']:
                    # For usage metrics, lower is better
                    if value <= rule["warning_threshold"]:
                        scores.append(1.0)
                    elif value <= rule["critical_threshold"]:
                        scores.append(0.6)
                    else:
                        scores.append(0.2)
                
                elif metric_name == 'error_rate':
                    # For error rate, lower is better
                    if value <= rule["warning_threshold"]:
                        scores.append(1.0)
                    elif value <= rule["critical_threshold"]:
                        scores.append(0.6)
                    else:
                        scores.append(0.2)
                
                elif metric_name == 'uptime_hours':
                    # For uptime, higher is better
                    if value >= 24:  # At least 24 hours
                        scores.append(1.0)
                    elif value >= 1:  # At least 1 hour
                        scores.append(0.8)
                    else:
                        scores.append(0.4)
        
        return sum(scores) / len(scores) if scores else 0.8
    
    def _calculate_health_trend(self, component_health: Dict[str, ComponentHealth]) -> HealthTrend:
        """Calculate overall health trend."""
        trends = []
        
        for component in component_health.values():
            if hasattr(component, 'health_trend'):
                trends.append(component.health_trend)
        
        if not trends:
            return HealthTrend.STABLE
        
        # Count trend types
        trend_counts = defaultdict(int)
        for trend in trends:
            trend_counts[trend] += 1
        
        # Determine dominant trend
        if trend_counts[HealthTrend.CRITICAL] > 0:
            return HealthTrend.CRITICAL
        elif trend_counts[HealthTrend.DEGRADING] > trend_counts[HealthTrend.IMPROVING]:
            return HealthTrend.DEGRADING
        elif trend_counts[HealthTrend.IMPROVING] > trend_counts[HealthTrend.DEGRADING]:
            return HealthTrend.IMPROVING
        else:
            return HealthTrend.STABLE
    
    def _identify_critical_issues(self, component_health: Dict[str, ComponentHealth], system_metrics: Dict[str, float]) -> List[str]:
        """Identify critical health issues."""
        issues = []
        
        # Check component health
        for component in component_health.values():
            if component.status == HealthStatus.UNHEALTHY:
                issues.append(f"Component {component.name} is unhealthy")
            elif component.status == HealthStatus.DEGRADED:
                issues.append(f"Component {component.name} is degraded")
        
        # Check system metrics
        for metric_name, value in system_metrics.items():
            if metric_name in self.health_rules:
                rule = self.health_rules[metric_name]
                
                if value >= rule["critical_threshold"]:
                    issues.append(f"Critical: {metric_name} is {value:.1f} (threshold: {rule['critical_threshold']})")
        
        return issues
    
    def get_health_dashboard_data(self) -> Dict[str, Any]:
        """Get data for health dashboard."""
        return asyncio.run(self.aggregate_health()).__dict__
    
    def export_health_report(self, filepath: str, hours: int = 24) -> bool:
        """Export health report to file."""
        try:
            health_data = self.get_health_dashboard_data()
            
            report = {
                "report_timestamp": datetime.utcnow().isoformat(),
                "report_period_hours": hours,
                "health_summary": health_data,
                "recommendations": self.recommendation_engine.get_all_recommendations(),
                "system_info": {
                    "components_monitored": len(self.component_health),
                    "services_monitored": len(self.service_health_checks),
                    "health_rules": self.health_rules
                }
            }
            
            with open(filepath, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            logger.info("Health report exported", filepath=filepath)
            return True
            
        except Exception as e:
            logger.error("Failed to export health report", error=str(e))
            return False

class HealthRecommendationEngine:
    """Generates health improvement recommendations."""
    
    def __init__(self):
        self.recommendation_patterns = self._load_recommendation_patterns()
    
    def _load_recommendation_patterns(self) -> Dict[str, Dict[str, Any]]:
        """Load recommendation patterns."""
        return {
            "high_cpu_usage": {
                "condition": lambda metrics: metrics.get('cpu_usage', 0) > 80,
                "recommendations": [
                    "Consider scaling up CPU resources",
                    "Review CPU-intensive processes",
                    "Implement load balancing",
                    "Optimize database queries"
                ],
                "priority": "high"
            },
            "high_memory_usage": {
                "condition": lambda metrics: metrics.get('memory_usage', 0) > 85,
                "recommendations": [
                    "Consider scaling up memory",
                    "Review memory leaks in application",
                    "Optimize data structures",
                    "Implement better caching strategy"
                ],
                "priority": "high"
            },
            "high_error_rate": {
                "condition": lambda metrics: metrics.get('error_rate', 0) > 0.05,
                "recommendations": [
                    "Review error logs for patterns",
                    "Implement better error handling",
                    "Add retry mechanisms",
                    "Review dependency health"
                ],
                "priority": "high"
            },
            "slow_response_time": {
                "condition": lambda metrics: metrics.get('avg_response_time', 0) > 2.0,
                "recommendations": [
                    "Optimize database queries",
                    "Implement caching",
                    "Review API performance",
                    "Consider service optimization"
                ],
                "priority": "medium"
            }
        }
    
    def generate_recommendations(self, component_health: Dict[str, ComponentHealth], system_metrics: Dict[str, float], critical_issues: List[str]) -> List[str]:
        """Generate health improvement recommendations."""
        recommendations = []
        
        # Pattern-based recommendations
        for pattern_name, pattern in self.recommendation_patterns.items():
            if pattern["condition"](system_metrics):
                recommendations.extend(pattern["recommendations"])
        
        # Issue-based recommendations
        for issue in critical_issues:
            if "unhealthy" in issue.lower():
                recommendations.append(f"Investigate and resolve: {issue}")
            elif "degraded" in issue.lower():
                recommendations.append(f"Monitor closely and address: {issue}")
        
        # Component-specific recommendations
        for component in component_health.values():
            if component.status == HealthStatus.DEGRADED:
                recommendations.append(f"Performance tune component: {component.name}")
            elif component.status == HealthStatus.UNHEALTHY:
                recommendations.append(f"Immediate attention required for: {component.name}")
        
        return list(set(recommendations))  # Remove duplicates
    
    def get_all_recommendations(self) -> Dict[str, List[str]]:
        """Get all available recommendations."""
        return {
            "cpu_optimization": [
                "Monitor CPU usage patterns",
                "Implement efficient algorithms",
                "Use connection pooling",
                "Optimize loops and iterations"
            ],
            "memory_management": [
                "Implement memory pooling",
                "Review garbage collection tuning",
                "Use memory-efficient data structures",
                "Implement lazy loading"
            ],
            "performance_optimization": [
                "Implement caching strategies",
                "Optimize database queries",
                "Use asynchronous processing",
                "Implement circuit breakers"
            ],
            "reliability": [
                "Implement health checks",
                "Add monitoring and alerting",
                "Use graceful degradation",
                "Implement backup systems"
            ]
        }

# Global health aggregator instance
health_aggregator = HealthAggregator()

# Auto-register common services
def initialize_common_health_checks():
    """Initialize common service health checks."""
    services = [
        ("database", ["redis"]),
        ("redis", []),
        ("ai_service", ["database"]),
        ("file_storage", []),
        ("cache", [])
    ]
    
    for service_name, dependencies in services:
        health_aggregator.register_service_health_check(service_name, dependencies)

# Export main components
__all__ = [
    'HealthAggregator',
    'ServiceHealthCheck',
    'HealthMetricCollector',
    'ComponentHealth',
    'HealthAggregationResult',
    'HealthRecommendationEngine',
    'health_aggregator',
    'initialize_common_health_checks',
    'HealthLevel',
    'HealthTrend'
]