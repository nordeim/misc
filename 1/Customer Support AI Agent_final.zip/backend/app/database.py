"""
Database setup and session management using SQLAlchemy.

Provides database initialization, session management, and connection handling.
"""

import logging
from contextlib import asynccontextmanager, contextmanager
from typing import Generator, AsyncGenerator

from sqlalchemy import create_engine, event, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool
from sqlalchemy.exc import DisconnectionError, OperationalError

from app.config import settings

logger = logging.getLogger(__name__)

# Base class for ORM models
Base = declarative_base()

# Database configuration - handle SQLite vs PostgreSQL differences
DATABASE_CONFIG = {
    "echo": settings.debug,
    "pool_pre_ping": True,
    "pool_recycle": 300,  # Recycle connections after 5 minutes
}

# Add pool settings only for PostgreSQL (not SQLite)
if "postgresql" in settings.database_url.lower():
    DATABASE_CONFIG.update({
        "pool_size": settings.db_pool_size,
        "max_overflow": settings.db_max_overflow,
    })
else:
    # SQLite specific configuration
    DATABASE_CONFIG.update({
        "poolclass": StaticPool,
        "connect_args": {
            "check_same_thread": False
        },
    })

# Create async engine for SQLite
async_engine = create_async_engine(
    settings.database_url,
    **DATABASE_CONFIG,
    future=True,
)

# Create session factory for async operations
AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=True,
    autocommit=False,
)

# Sync engine for Alembic migrations and other sync operations
sync_database_url = settings.database_url.replace("+aiosqlite", "") if "+aiosqlite" in settings.database_url else settings.database_url

# Prepare sync engine config
sync_config = DATABASE_CONFIG.copy()

sync_engine = create_engine(
    sync_database_url,
    **sync_config,
)

SyncSessionLocal = sessionmaker(
    bind=sync_engine,
    autoflush=True,
    autocommit=False,
    expire_on_commit=False,
)

# Metadata for Alembic
metadata = MetaData()


@event.listens_for(sync_engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    """Set SQLite-specific configuration."""
    if "sqlite" in sync_database_url:
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA cache_size=10000")
        cursor.execute("PRAGMA temp_store=memory")
        cursor.close()


@event.listens_for(sync_engine, "checkout")
def ping_connection(connection, connection_record, connection_proxy):
    """Ping connection to ensure it's still valid."""
    try:
        connection.execute("SELECT 1")
    except DisconnectionError:
        connection_proxy.invalidate()


async def init_db():
    """Initialize database tables."""
    try:
        async with async_engine.begin() as conn:
            # Import all models to ensure they are registered with Base
            from app.models import UserORM, SessionORM, MessageORM, MemoryORM
            from app.models.escalation import EscalationORM, EscalationLogORM
            
            # Create all tables
            await conn.run_sync(Base.metadata.create_all)
            
        logger.info("Database initialized successfully")
        
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise


async def close_db():
    """Close database connections."""
    try:
        await async_engine.dispose()
        logger.info("Database connections closed")
    except Exception as e:
        logger.error(f"Error closing database: {e}")


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency to get database session for FastAPI endpoints."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_db_context() -> AsyncGenerator[AsyncSession, None]:
    """Context manager for database sessions."""
    session = AsyncSessionLocal()
    try:
        yield session
        await session.commit()
    except Exception as e:
        await session.rollback()
        logger.error(f"Database session error: {e}")
        raise
    finally:
        await session.close()


def get_sync_db() -> Generator[Session, None, None]:
    """Get sync database session for Alembic migrations and sync operations."""
    db = SyncSessionLocal()
    try:
        yield db
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Sync database session error: {e}")
        raise
    finally:
        db.close()


@contextmanager
def get_sync_db_context() -> Generator[Session, None, None]:
    """Context manager for sync database sessions."""
    db = SyncSessionLocal()
    try:
        yield db
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Sync database session error: {e}")
        raise
    finally:
        db.close()


def check_db_connection() -> bool:
    """Check if database connection is working."""
    try:
        with get_sync_db_context() as db:
            db.execute("SELECT 1")
        return True
    except Exception as e:
        logger.error(f"Database connection check failed: {e}")
        return False


async def check_db_connection_async() -> bool:
    """Check if database connection is working (async version)."""
    try:
        async with get_db_context() as db:
            await db.execute("SELECT 1")
        return True
    except Exception as e:
        logger.error(f"Database connection check failed: {e}")
        return False


def recreate_tables():
    """Drop and recreate all tables (development only)."""
    if not settings.debug:
        raise RuntimeError("Table recreation is only allowed in debug mode")
    
    with get_sync_db_context() as db:
        Base.metadata.drop_all(db.bind)
        Base.metadata.create_all(db.bind)
    
    logger.info("Database tables recreated")


# Export frequently used classes and functions
__all__ = [
    "Base",
    "async_engine",
    "sync_engine",
    "AsyncSessionLocal",
    "SyncSessionLocal",
    "metadata",
    "init_db",
    "close_db",
    "get_db",
    "get_db_context",
    "get_sync_db",
    "get_sync_db_context",
    "check_db_connection",
    "check_db_connection_async",
    "recreate_tables",
]