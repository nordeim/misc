"""
Example demonstrating the complete BaseTool and ToolRegistry pattern.

This example shows how to:
1. Create tools using the BaseTool pattern
2. Register tools with the ToolRegistry
3. Configure tools for different environments
4. Use resilience patterns and monitoring
5. Execute tools with proper error handling and metrics

Run this example to see the complete tool system in action.
"""

import asyncio
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Any, List

# Add the app directory to the path so we can import the tools
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Example 1: Create a simple tool using BaseTool pattern
class ExampleTool(BaseTool):
    """Example tool demonstrating BaseTool features."""
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config)
        self.processed_count = 0
    
    @property
    def name(self) -> str:
        return "example_tool"
    
    def _get_metadata(self) -> ToolMetadata:
        return ToolMetadata(
            name=self.name,
            version="1.0.0",
            description="Example tool demonstrating BaseTool pattern",
            category="example",
            tags=["demo", "example", "tutorial"],
            timeout_seconds=30,
            max_retries=2,
            max_concurrent_executions=5,
            memory_limit_mb=128,
            default_config={"greeting": "Hello", "repeat_count": 1}
        )
    
    async def execute(self, message: str = "Hello World", **kwargs) -> Dict[str, Any]:
        """Execute the tool with the given parameters."""
        await asyncio.sleep(0.1)  # Simulate some work
        
        greeting = self.get_config("greeting", "Hello")
        repeat_count = self.get_config("repeat_count", 1)
        
        result = {
            "tool_name": self.name,
            "message": greeting + " " + message,
            "repeated": [greeting + " " + message] * repeat_count,
            "processed_count": self.processed_count + 1,
            "config_used": {
                "greeting": greeting,
                "repeat_count": repeat_count
            }
        }
        
        self.processed_count += 1
        return result


# Example 2: Create a more complex tool with patterns
class ResilientDataTool(BaseTool):
    """Example tool with resilience patterns and advanced features."""
    
    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config)
        self.data_store = {}
        self.failure_count = 0
    
    @property
    def name(self) -> str:
        return "resilient_data_tool"
    
    def _get_metadata(self) -> ToolMetadata:
        return ToolMetadata(
            name=self.name,
            version="2.0.0",
            description="Resilient data processing tool with patterns",
            category="data",
            tags=["data", "resilience", "patterns"],
            timeout_seconds=60,
            max_retries=5,
            circuit_breaker_threshold=3,
            circuit_breaker_timeout_seconds=30,
            max_concurrent_executions=10,
            memory_limit_mb=256,
            default_config={
                "failure_rate": 0.0,
                "delay_seconds": 0.0,
                "data_size_limit": 1000
            }
        )
    
    async def store_data(self, key: str, value: Any) -> bool:
        """Store data with error simulation."""
        await asyncio.sleep(self.get_config("delay_seconds", 0.0))
        
        # Simulate failures based on configuration
        failure_rate = self.get_config("failure_rate", 0.0)
        if failure_rate > 0 and hash(key) % 100 < failure_rate * 100:
            self.failure_count += 1
            raise ToolExecutionError(f"Simulated failure for key: {key}")
        
        # Store data
        data_size_limit = self.get_config("data_size_limit", 1000)
        if len(str(value)) > data_size_limit:
            raise ToolResourceError(f"Data size exceeds limit: {len(str(value))} > {data_size_limit}")
        
        self.data_store[key] = value
        return True
    
    async def retrieve_data(self, key: str) -> Any:
        """Retrieve data."""
        return self.data_store.get(key)
    
    async def execute(self, operation: str, **kwargs) -> Dict[str, Any]:
        """Main execution method."""
        start_time = time.time()
        
        try:
            if operation == "store":
                key = kwargs.get("key", "default")
                value = kwargs.get("value", "default_value")
                success = await self.store_data(key, value)
                return {"success": success, "operation": operation}
            
            elif operation == "retrieve":
                key = kwargs.get("key", "default")
                value = await self.retrieve_data(key)
                return {"success": True, "operation": operation, "value": value}
            
            elif operation == "status":
                return {
                    "success": True,
                    "operation": operation,
                    "data_count": len(self.data_store),
                    "failure_count": self.failure_count,
                    "health_score": self.health_score
                }
            
            else:
                return {"success": False, "error": f"Unknown operation: {operation}"}
                
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            logger.error(f"Tool execution failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "execution_time_ms": execution_time
            }


async def demonstrate_basic_usage():
    """Demonstrate basic BaseTool usage."""
    logger.info("=== Basic BaseTool Usage Demo ===")
    
    # Create and initialize a tool
    tool = ExampleTool(config={"greeting": "Hi there", "repeat_count": 3})
    
    # Initialize the tool
    logger.info("Initializing tool...")
    init_result = await tool.initialize()
    logger.info(f"Tool initialization result: {init_result}")
    
    # Check health
    health_result = await tool.health_check()
    logger.info(f"Tool health check: {health_result}")
    
    # Execute the tool
    logger.info("Executing tool...")
    result = await tool.execute("This is a test message")
    logger.info(f"Tool execution result: {result}")
    
    # Get metrics
    metrics = tool.get_metrics()
    logger.info(f"Tool metrics: {metrics}")
    
    # Shutdown
    await tool.shutdown()
    logger.info("Tool shutdown complete")


async def demonstrate_resilience_patterns():
    """Demonstrate resilience patterns."""
    logger.info("=== Resilience Patterns Demo ===")
    
    # Create a tool that fails sometimes
    tool = ResilientDataTool(config={
        "failure_rate": 0.3,  # 30% failure rate
        "delay_seconds": 0.05
    })
    
    await tool.initialize()
    
    # Test resilience with multiple attempts
    logger.info("Testing tool resilience...")
    
    for i in range(10):
        try:
            result = await tool.execute("store", key=f"test_key_{i}", value=f"test_value_{i}")
            logger.info(f"Store operation {i}: {'SUCCESS' if result['success'] else 'FAILED'}")
            
        except Exception as e:
            logger.info(f"Store operation {i}: EXCEPTION - {e}")
    
    # Check final status
    status_result = await tool.execute("status")
    logger.info(f"Final tool status: {status_result}")
    
    # Test with zero failure rate
    logger.info("Testing with zero failure rate...")
    tool.update_config({"failure_rate": 0.0})
    
    for i in range(5):
        result = await tool.execute("store", key=f"reliable_key_{i}", value=f"reliable_value_{i}")
        logger.info(f"Reliable store operation {i}: {'SUCCESS' if result['success'] else 'FAILED'}")
    
    await tool.shutdown()


async def demonstrate_tool_registry():
    """Demonstrate ToolRegistry functionality."""
    logger.info("=== ToolRegistry Demo ===")
    
    # Create registry
    async with ToolRegistry(auto_discover=False) as registry:
        
        # Register tools
        logger.info("Registering tools...")
        
        registry.register_tool(
            ExampleTool,
            config={"greeting": "Hello from Registry", "repeat_count": 2}
        )
        
        registry.register_tool(
            ResilientDataTool,
            config={"failure_rate": 0.1, "delay_seconds": 0.01}
        )
        
        # List registered tools
        tools = registry.list_tools()
        logger.info(f"Registered tools: {tools}")
        
        # Execute tools through registry
        logger.info("Executing tools through registry...")
        
        for tool_name in tools:
            try:
                if tool_name == "example_tool":
                    result = await registry.execute_tool(
                        tool_name,
                        message="Executed via registry!"
                    )
                else:
                    result = await registry.execute_tool(
                        tool_name,
                        operation="status"
                    )
                
                logger.info(f"Registry execution result for {tool_name}: {result}")
                
            except Exception as e:
                logger.error(f"Registry execution failed for {tool_name}: {e}")
        
        # Get registry statistics
        stats = registry.get_registry_stats()
        logger.info(f"Registry statistics: {stats}")


async def demonstrate_configuration_management():
    """Demonstrate configuration management."""
    logger.info("=== Configuration Management Demo ===")
    
    config_manager = get_global_config()
    
    # Create configuration for tools
    logger.info("Creating tool configurations...")
    
    # Example tool configuration
    example_config = create_tool_config(
        "example_tool",
        timeout=45,
        max_retries=5,
        environment="development"
    )
    
    config_manager.register_tool_config(example_config)
    
    # Deployment configuration
    deployment_config = create_deployment_config(
        "example_tool",
        mode=DeploymentMode.SCALED,
        instance_count=3,
        memory_limit_mb=512,
        auto_scaling=True
    )
    
    config_manager.register_deployment_config(deployment_config)
    
    # Load from environment variables
    logger.info("Loading configuration from environment...")
    config_manager.load_from_environment(prefix="EXAMPLE_TOOL_")
    
    # Get statistics
    stats = config_manager.get_config_stats()
    logger.info(f"Configuration statistics: {stats}")
    
    # Validate configurations
    validation_results = config_manager.validate_all_configs()
    logger.info(f"Configuration validation results: {validation_results}")


async def demonstrate_environment_management():
    """Demonstrate environment-specific configurations."""
    logger.info("=== Environment Management Demo ===")
    
    environment_manager = get_global_environment()
    
    # Show current environment
    current_env = environment_manager.current_environment
    logger.info(f"Current environment: {current_env}")
    
    # Get deployment strategy for current environment
    strategy = environment_manager.get_deployment_strategy("example_tool")
    logger.info(f"Deployment strategy for current environment: {strategy}")
    
    # Simulate selecting tool for different environment
    for env in ["development", "staging", "production"]:
        selected_tool = environment_manager.select_tool_for_environment("example_tool", env)
        logger.info(f"Selected tool for {env}: {selected_tool}")


async def demonstrate_monitoring_and_analytics():
    """Demonstrate monitoring and analytics features."""
    logger.info("=== Monitoring and Analytics Demo ===")
    
    # Create a tool with monitoring
    tool = ResilientDataTool(config={"failure_rate": 0.2})
    
    await tool.initialize()
    
    # Execute multiple operations to generate metrics
    logger.info("Executing operations to generate metrics...")
    
    for i in range(20):
        try:
            await tool.execute("store", key=f"metric_key_{i}", value=f"metric_value_{i}" * 10)
        except Exception:
            pass  # Expected some failures due to failure_rate
    
    # Get detailed metrics
    metrics = tool.get_metrics()
    logger.info(f"Detailed tool metrics: {metrics}")
    
    # Use patterns for advanced monitoring
    patterns = get_global_patterns()
    
    # Check metrics collector
    if "metrics_collector" in patterns:
        mc = patterns["metrics_collector"]
        all_metrics = mc.get_all_metrics()
        logger.info(f"Global metrics collection: {list(all_metrics.keys())}")
    
    await tool.shutdown()


async def demonstrate_tool_validation():
    """Demonstrate tool validation and testing."""
    logger.info("=== Tool Validation Demo ===")
    
    # Create test instances
    tools = [
        ExampleTool(),
        ResilientDataTool(),
        enhanced_memory_tool  # From the enhanced memory tool
    ]
    
    for tool in tools:
        logger.info(f"Validating tool: {tool.name}")
        
        # Basic validation
        validation_result = validate_tool(tool)
        logger.info(f"Validation result for {tool.name}:")
        logger.info(f"  Valid: {validation_result.is_valid}")
        logger.info(f"  Score: {validation_result.score}")
        logger.info(f"  Errors: {validation_result.errors}")
        logger.info(f"  Warnings: {validation_result.warnings}")
        
        # Quick functionality test
        test_result = await quick_tool_test(tool.__class__)
        logger.info(f"Quick test result for {tool.name}:")
        logger.info(f"  Overall status: {test_result.get('overall_status', 'unknown')}")
        logger.info(f"  Basic test status: {test_result.get('basic_test', {}).get('status', 'unknown')}")
        
        # Generate documentation schema
        schema = get_tool_schema(tool)
        logger.info(f"Configuration schema for {tool.name}: {len(schema.get('properties', {}))} properties")
    
    # Get test summary if tester was used
    utilities = get_global_utilities()
    if "tester" in utilities and hasattr(utilities["tester"], 'get_test_summary'):
        summary = utilities["tester"].get_test_summary()
        logger.info(f"Test summary: {summary}")


async def demonstrate_comprehensive_workflow():
    """Demonstrate a comprehensive workflow combining all features."""
    logger.info("=== Comprehensive Workflow Demo ===")
    
    # 1. Setup tool system
    registry = await initialize_tools(auto_discover=False, environment="demo")
    
    # 2. Create and register tools
    tools_to_register = [
        (ExampleTool, {"greeting": "Comprehensive Demo", "repeat_count": 2}),
        (ResilientDataTool, {"failure_rate": 0.1, "delay_seconds": 0.02})
    ]
    
    for tool_class, config in tools_to_register:
        tool_name = registry.register_tool(tool_class, config=config)
        logger.info(f"Registered tool: {tool_name}")
    
    # 3. Execute workflow
    workflow_results = []
    
    for tool_name in registry.list_tools():
        logger.info(f"Executing comprehensive workflow for tool: {tool_name}")
        
        # Create execution context
        context = ToolExecutionContext(
            session_id="workflow_session",
            user_id="demo_user",
            priority=ToolPriority.HIGH,
            metadata={"workflow_step": "comprehensive_demo"}
        )
        
        try:
            # Execute tool
            if tool_name == "example_tool":
                result = await registry.execute_tool(
                    tool_name,
                    context=context,
                    message="Comprehensive workflow execution"
                )
            else:
                result = await registry.execute_tool(
                    tool_name,
                    context=context,
                    operation="status"
                )
            
            workflow_results.append({
                "tool_name": tool_name,
                "success": True,
                "result": result
            })
            
            logger.info(f"Workflow step completed for {tool_name}")
            
        except Exception as e:
            workflow_results.append({
                "tool_name": tool_name,
                "success": False,
                "error": str(e)
            })
            logger.error(f"Workflow step failed for {tool_name}: {e}")
    
    # 4. Generate comprehensive report
    logger.info("Generating comprehensive report...")
    
    # Get system status
    registry_stats = registry.get_registry_stats()
    config_stats = get_global_config().get_config_stats()
    tool_system_info = get_tool_system_info()
    
    report = {
        "workflow_results": workflow_results,
        "registry_statistics": registry_stats,
        "configuration_statistics": config_stats,
        "tool_system_info": tool_system_info,
        "timestamp": time.time(),
        "environment": get_global_environment().current_environment
    }
    
    logger.info("Comprehensive Workflow Report:")
    logger.info(f"  Tools executed: {len(workflow_results)}")
    logger.info(f"  Successful operations: {sum(1 for r in workflow_results if r['success'])}")
    logger.info(f"  Registry uptime: {registry_stats.get('uptime_seconds', 0):.1f} seconds")
    logger.info(f"  New tool system available: {tool_system_info['new_components_available']}")
    
    # 5. Cleanup
    await registry.stop()
    
    return report


async def main():
    """Main demonstration function."""
    logger.info("Starting BaseTool and ToolRegistry Pattern Demonstration")
    logger.info("=" * 60)
    
    try:
        # Run individual demonstrations
        await demonstrate_basic_usage()
        await demonstrate_resilience_patterns()
        await demonstrate_tool_registry()
        await demonstrate_configuration_management()
        await demonstrate_environment_management()
        await demonstrate_monitoring_and_analytics()
        await demonstrate_tool_validation()
        
        # Run comprehensive workflow
        final_report = await demonstrate_comprehensive_workflow()
        
        logger.info("=" * 60)
        logger.info("All demonstrations completed successfully!")
        
        # Print final summary
        print("\n" + "=" * 60)
        print("DEMONSTRATION SUMMARY")
        print("=" * 60)
        print(f"✓ Basic BaseTool pattern demonstrated")
        print(f"✓ Resilience patterns (retry, circuit breaker) shown")
        print(f"✓ ToolRegistry with dynamic tool loading working")
        print(f"✓ Configuration management system active")
        print(f"✓ Environment-specific configurations tested")
        print(f"✓ Monitoring and metrics collection functional")
        print(f"✓ Tool validation and testing framework ready")
        print(f"✓ Comprehensive workflow executed successfully")
        print("\nThe complete BaseTool and ToolRegistry pattern is now available!")
        print("All tools can be dynamically loaded, configured, and managed.")
        
    except Exception as e:
        logger.error(f"Demonstration failed: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    # Run the demonstration
    asyncio.run(main())
