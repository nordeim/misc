"""
ToolRegistry for dynamic tool loading and management.

Provides centralized registry for discovering, registering, loading,
and managing tool instances with configuration and monitoring.
"""

import logging
import asyncio
import importlib
import inspect
import pkgutil
from typing import (
    Dict, List, Optional, Type, Any, Callable, Union,
    Set, Tuple, AsyncIterator
)
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum
import json
import weakref

from .base_tool import (
    BaseTool, ToolMetadata, ToolExecutionContext, ToolStatus,
    ToolError, ToolFactory, ToolInterface
)


class RegistryEventType(Enum):
    """Types of registry events."""
    TOOL_REGISTERED = "tool_registered"
    TOOL_UNREGISTERED = "tool_unregistered"
    TOOL_INITIALIZED = "tool_initialized"
    TOOL_SHUTDOWN = "tool_shutdown"
    TOOL_ERROR = "tool_error"
    TOOL_HEALTH_CHANGED = "tool_health_changed"
    REGISTRY_STARTED = "registry_started"
    REGISTRY_STOPPED = "registry_stopped"


@dataclass
class RegistryEvent:
    """Event emitted by the tool registry."""
    event_type: RegistryEventType
    tool_name: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    data: Dict[str, Any] = field(default_factory=dict)
    source: str = "tool_registry"


@dataclass
class ToolRegistration:
    """Registration information for a tool."""
    tool_class: Type[BaseTool]
    factory: Optional[ToolFactory] = None
    config: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    priority: int = 0  # Lower numbers = higher priority
    
    # Lifecycle management
    auto_initialize: bool = True
    auto_shutdown: bool = True
    health_check_interval: int = 300  # 5 minutes
    
    # Resource management
    max_instances: int = 1  # 0 = unlimited
    instance_pool_size: int = 1
    
    # Metadata
    registration_time: datetime = field(default_factory=datetime.utcnow)
    last_used: Optional[datetime] = None
    usage_count: int = 0


@dataclass
class ToolInstance:
    """Wrapper for tool instance with metadata."""
    tool: BaseTool
    registration: ToolRegistration
    status: ToolStatus = ToolStatus.IDLE
    last_health_check: Optional[datetime] = None
    health_score: float = 0.0
    instance_id: str = ""  # Set during initialization
    
    def __post_init__(self):
        if not self.instance_id:
            self.instance_id = f"{self.tool.name}-{id(self.tool)}"


class ToolRegistryEventHandler:
    """Event handler interface for tool registry events."""
    
    async def handle_event(self, event: RegistryEvent):
        """Handle a registry event."""
        pass


class LoggingEventHandler(ToolRegistryEventHandler):
    """Event handler that logs registry events."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger("tool_registry.events")
    
    async def handle_event(self, event: RegistryEvent):
        """Log the event."""
        if event.tool_name:
            self.logger.info(
                f"Registry event: {event.event_type.value} - {event.tool_name}",
                extra={"event": event}
            )
        else:
            self.logger.info(
                f"Registry event: {event.event_type.value}",
                extra={"event": event}
            )


class HealthCheckEventHandler(ToolRegistryEventHandler):
    """Event handler for health check monitoring."""
    
    def __init__(self, registry: 'ToolRegistry'):
        self.registry = weakref.ref(registry)
    
    async def handle_event(self, event: RegistryEvent):
        """Handle health-related events."""
        if event.event_type == RegistryEventType.TOOL_HEALTH_CHANGED:
            # Update registry health metrics
            if event.tool_name and event.data:
                health_score = event.data.get('health_score', 0.0)
                registry = self.registry()
                if registry:
                    registry._update_tool_health_score(event.tool_name, health_score)


class ToolRegistry:
    """
    Central registry for managing tool instances.
    
    Provides dynamic tool loading, configuration management, health monitoring,
    and execution coordination.
    """
    
    def __init__(
        self,
        auto_discover: bool = True,
        discovery_paths: Optional[List[str]] = None,
        default_timeout: int = 300,
        max_concurrent_executions: int = 100
    ):
        # Core registry data
        self._tools: Dict[str, ToolRegistration] = {}
        self._instances: Dict[str, ToolInstance] = {}
        self._instances_by_tool: Dict[str, Set[str]] = {}
        
        # Configuration and discovery
        self.auto_discover = auto_discover
        self.discovery_paths = discovery_paths or []
        self.default_timeout = default_timeout
        self.max_concurrent_executions = max_concurrent_executions
        
        # Event handling
        self._event_handlers: List[ToolRegistryEventHandler] = []
        self._event_queue = asyncio.Queue()
        self._event_processor_task: Optional[asyncio.Task] = None
        
        # Health monitoring
        self._health_check_tasks: Dict[str, asyncio.Task] = {}
        self._health_check_interval = 300  # 5 minutes
        self._health_scores: Dict[str, float] = {}
        
        # Execution management
        self._execution_semaphore = asyncio.Semaphore(max_concurrent_executions)
        self._active_executions: Dict[str, ToolExecutionContext] = {}
        
        # Logging and monitoring
        self.logger = logging.getLogger("tool_registry")
        self._start_time: Optional[datetime] = None
        self._total_executions = 0
        self._successful_executions = 0
        self._failed_executions = 0
        
        # Registry state
        self._running = False
        self._shutdown_event = asyncio.Event()
    
    async def start(self):
        """Start the tool registry and begin monitoring."""
        if self._running:
            return
        
        self.logger.info("Starting tool registry...")
        self._start_time = datetime.utcnow()
        self._running = True
        
        # Add default event handlers
        self.add_event_handler(LoggingEventHandler())
        self.add_event_handler(HealthCheckEventHandler(self))
        
        # Start event processor
        self._event_processor_task = asyncio.create_task(self._process_events())
        
        # Auto-discover tools if enabled
        if self.auto_discover:
            await self.discover_tools()
        
        # Start health monitoring
        await self._start_health_monitoring()
        
        await self._emit_event(RegistryEventType.REGISTRY_STARTED)
        self.logger.info("Tool registry started successfully")
    
    async def stop(self):
        """Stop the tool registry and clean up resources."""
        if not self._running:
            return
        
        self.logger.info("Stopping tool registry...")
        self._running = False
        
        # Stop event processing
        if self._event_processor_task:
            self._event_processor_task.cancel()
            try:
                await self._event_processor_task
            except asyncio.CancelledError:
                pass
        
        # Shutdown all tool instances
        await self.shutdown_all_tools()
        
        # Cancel health check tasks
        for task in self._health_check_tasks.values():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        # Clear data structures
        self._tools.clear()
        self._instances.clear()
        self._instances_by_tool.clear()
        self._health_check_tasks.clear()
        self._active_executions.clear()
        
        await self._emit_event(RegistryEventType.REGISTRY_STOPPED)
        self.logger.info("Tool registry stopped")
    
    async def discover_tools(self, paths: Optional[List[str]] = None):
        """
        Auto-discover and register tools from specified paths.
        
        Args:
            paths: List of Python module paths to search for tools.
                   If None, uses self.discovery_paths.
        """
        search_paths = paths or self.discovery_paths
        
        if not search_paths:
            # Default discovery paths
            search_paths = [
                "app.tools",
                "tools",
                "backend.app.tools"
            ]
        
        discovered_classes = []
        
        for path in search_paths:
            try:
                # Import the module
                module = importlib.import_module(path)
                
                # Walk through the module to find tool classes
                for _, obj in inspect.getmembers(module, inspect.isclass):
                    if (
                        issubclass(obj, BaseTool) and 
                        obj != BaseTool and
                        hasattr(obj, 'name')
                    ):
                        discovered_classes.append(obj)
                        
            except ImportError as e:
                self.logger.warning(f"Failed to import discovery path {path}: {e}")
                continue
        
        # Register discovered tools
        for tool_class in discovered_classes:
            try:
                # Create a temporary instance to get the name
                temp_instance = tool_class()
                tool_name = temp_instance.name
                
                # Check if already registered
                if tool_name in self._tools:
                    self.logger.info(f"Tool {tool_name} already registered, skipping discovery")
                    continue
                
                # Register the tool
                registration = ToolRegistration(
                    tool_class=tool_class,
                    auto_initialize=True,
                    health_check_interval=300
                )
                
                self._tools[tool_name] = registration
                self.logger.info(f"Discovered and registered tool: {tool_name}")
                
                await self._emit_event(
                    RegistryEventType.TOOL_REGISTERED,
                    tool_name=tool_name,
                    data={"discovery_path": path}
                )
                
            except Exception as e:
                self.logger.error(f"Failed to register discovered tool {tool_class.__name__}: {e}")
        
        # Initialize registered tools
        for tool_name, registration in self._tools.items():
            if registration.enabled and registration.auto_initialize:
                try:
                    await self.initialize_tool(tool_name)
                except Exception as e:
                    self.logger.error(f"Failed to initialize discovered tool {tool_name}: {e}")
    
    def register_tool(
        self,
        tool_class: Type[BaseTool],
        tool_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        enabled: bool = True,
        priority: int = 0,
        **kwargs
    ) -> str:
        """
        Register a tool class with the registry.
        
        Args:
            tool_class: BaseTool subclass to register
            tool_name: Optional name override (defaults to tool.name)
            config: Tool configuration
            enabled: Whether the tool is enabled
            priority: Tool priority (lower = higher priority)
            **kwargs: Additional registration options
            
        Returns:
            The registered tool name
        """
        # Create temporary instance to get name
        temp_instance = tool_class()
        name = tool_name or temp_instance.name
        
        if name in self._tools:
            self.logger.warning(f"Tool {name} already registered, overwriting")
        
        registration = ToolRegistration(
            tool_class=tool_class,
            config=config or {},
            enabled=enabled,
            priority=priority,
            **kwargs
        )
        
        self._tools[name] = registration
        self._instances_by_tool[name] = set()
        
        self.logger.info(f"Registered tool: {name}")
        
        # Emit event
        asyncio.create_task(self._emit_event(
            RegistryEventType.TOOL_REGISTERED,
            tool_name=name,
            data={"tool_class": tool_class.__name__}
        ))
        
        return name
    
    def unregister_tool(self, tool_name: str) -> bool:
        """
        Unregister a tool from the registry.
        
        Args:
            tool_name: Name of the tool to unregister
            
        Returns:
            True if tool was unregistered, False if not found
        """
        if tool_name not in self._tools:
            return False
        
        # Shutdown tool instances if running
        asyncio.create_task(self.shutdown_tool(tool_name))
        
        # Remove from registry
        del self._tools[tool_name]
        
        self.logger.info(f"Unregistered tool: {tool_name}")
        
        # Emit event
        asyncio.create_task(self._emit_event(
            RegistryEventType.TOOL_UNREGISTERED,
            tool_name=tool_name
        ))
        
        return True
    
    async def initialize_tool(self, tool_name: str, config: Optional[Dict[str, Any]] = None) -> bool:
        """
        Initialize a tool instance.
        
        Args:
            tool_name: Name of the tool to initialize
            config: Optional config override
            
        Returns:
            True if initialization successful, False otherwise
        """
        if tool_name not in self._tools:
            raise ToolError(f"Tool {tool_name} not found in registry")
        
        registration = self._tools[tool_name]
        
        if not registration.enabled:
            self.logger.info(f"Tool {tool_name} is disabled, skipping initialization")
            return False
        
        # Check instance limits
        current_instances = len(self._instances_by_tool.get(tool_name, set()))
        if registration.max_instances > 0 and current_instances >= registration.max_instances:
            self.logger.warning(f"Tool {tool_name} has reached max instances limit")
            return False
        
        try:
            # Create tool instance
            tool_config = registration.config.copy()
            if config:
                tool_config.update(config)
            
            tool_instance = registration.tool_class(config=tool_config)
            
            # Initialize the tool
            if not await tool_instance.initialize():
                raise ToolError(f"Tool {tool_name} initialization failed")
            
            # Create instance wrapper
            instance = ToolInstance(
                tool=tool_instance,
                registration=registration
            )
            
            # Store instance
            instance_id = instance.instance_id
            self._instances[instance_id] = instance
            
            if tool_name not in self._instances_by_tool:
                self._instances_by_tool[tool_name] = set()
            self._instances_by_tool[tool_name].add(instance_id)
            
            # Update registration stats
            registration.usage_count += 1
            registration.last_used = datetime.utcnow()
            
            # Start health monitoring for this tool
            if registration.health_check_interval > 0:
                await self._start_health_check(tool_name, registration.health_check_interval)
            
            self.logger.info(f"Initialized tool instance: {tool_name} ({instance_id})")
            
            # Emit event
            await self._emit_event(
                RegistryEventType.TOOL_INITIALIZED,
                tool_name=tool_name,
                data={"instance_id": instance_id}
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize tool {tool_name}: {e}")
            
            # Emit error event
            await self._emit_event(
                RegistryEventType.TOOL_ERROR,
                tool_name=tool_name,
                data={"error": str(e), "operation": "initialize"}
            )
            
            return False
    
    async def shutdown_tool(self, tool_name: str, instance_id: Optional[str] = None) -> bool:
        """
        Shutdown a tool instance or all instances of a tool.
        
        Args:
            tool_name: Name of the tool
            instance_id: Specific instance to shutdown (None for all)
            
        Returns:
            True if shutdown successful
        """
        instances_to_shutdown = []
        
        if instance_id:
            # Shutdown specific instance
            if instance_id in self._instances:
                instances_to_shutdown.append(self._instances[instance_id])
        else:
            # Shutdown all instances of the tool
            if tool_name in self._instances_by_tool:
                for inst_id in self._instances_by_tool[tool_name]:
                    if inst_id in self._instances:
                        instances_to_shutdown.append(self._instances[inst_id])
        
        success = True
        for instance in instances_to_shutdown:
            try:
                await instance.tool.shutdown()
                
                # Remove from tracking
                del self._instances[instance.instance_id]
                if instance.registration in self._tools.values():
                    tool_name = None
                    for name, reg in self._tools.items():
                        if reg == instance.registration:
                            tool_name = name
                            break
                    if tool_name and tool_name in self._instances_by_tool:
                        self._instances_by_tool[tool_name].discard(instance.instance_id)
                
                # Stop health monitoring
                if instance.registration.health_check_interval > 0:
                    task = self._health_check_tasks.get(instance.instance_id)
                    if task:
                        task.cancel()
                        try:
                            await task
                        except asyncio.CancelledError:
                            pass
                        del self._health_check_tasks[instance.instance_id]
                
                self.logger.info(f"Shutdown tool instance: {instance.instance_id}")
                
                # Emit event
                await self._emit_event(
                    RegistryEventType.TOOL_SHUTDOWN,
                    tool_name=tool_name,
                    data={"instance_id": instance.instance_id}
                )
                
            except Exception as e:
                self.logger.error(f"Failed to shutdown tool instance {instance.instance_id}: {e}")
                success = False
        
        return success
    
    async def shutdown_all_tools(self):
        """Shutdown all registered tool instances."""
        tasks = []
        for tool_name in list(self._tools.keys()):
            tasks.append(self.shutdown_tool(tool_name))
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def execute_tool(
        self,
        tool_name: str,
        *args,
        context: Optional[ToolExecutionContext] = None,
        instance_id: Optional[str] = None,
        **kwargs
    ) -> Any:
        """
        Execute a tool through the registry.
        
        Args:
            tool_name: Name of the tool to execute
            *args: Arguments to pass to tool
            context: Execution context
            instance_id: Specific instance to use (None for auto-select)
            **kwargs: Keyword arguments to pass to tool
            
        Returns:
            Tool execution result
        """
        if tool_name not in self._tools:
            raise ToolError(f"Tool {tool_name} not found in registry")
        
        if not context:
            context = ToolExecutionContext()
        
        # Acquire execution semaphore
        async with self._execution_semaphore:
            # Get or create tool instance
            instance = await self._get_or_create_instance(tool_name, instance_id)
            
            if not instance:
                raise ToolError(f"Failed to get tool instance for {tool_name}")
            
            # Track active execution
            self._active_executions[context.execution_id] = context
            
            try:
                # Execute tool with monitoring
                self._total_executions += 1
                result = await instance.tool.execute_with_context(
                    *args,
                    context=context,
                    **kwargs
                )
                
                self._successful_executions += 1
                return result
                
            except Exception as e:
                self._failed_executions += 1
                raise
                
            finally:
                # Clean up active execution
                self._active_executions.pop(context.execution_id, None)
    
    async def _get_or_create_instance(
        self, 
        tool_name: str, 
        instance_id: Optional[str] = None
    ) -> Optional[ToolInstance]:
        """Get existing instance or create new one if needed."""
        registration = self._tools[tool_name]
        
        if instance_id:
            # Get specific instance
            return self._instances.get(instance_id)
        
        # Get existing instance if available
        if tool_name in self._instances_by_tool:
            existing_instances = list(self._instances_by_tool[tool_name])
            if existing_instances:
                return self._instances[existing_instances[0]]
        
        # Create new instance if under limit
        current_instances = len(self._instances_by_tool.get(tool_name, set()))
        if registration.max_instances == 0 or current_instances < registration.max_instances:
            success = await self.initialize_tool(tool_name)
            if success and tool_name in self._instances_by_tool:
                existing_instances = list(self._instances_by_tool[tool_name])
                return self._instances[existing_instances[-1]]  # Return newest
        
        return None
    
    def get_tool_instance(self, tool_name: str, instance_id: Optional[str] = None) -> Optional[ToolInstance]:
        """
        Get a tool instance without executing it.
        
        Args:
            tool_name: Name of the tool
            instance_id: Specific instance to get
            
        Returns:
            Tool instance or None if not found
        """
        if instance_id:
            return self._instances.get(instance_id)
        
        # Get first available instance
        if tool_name in self._instances_by_tool:
            instances = self._instances_by_tool[tool_name]
            if instances:
                return self._instances[next(iter(instances))]
        
        return None
    
    def list_tools(self, enabled_only: bool = False) -> List[str]:
        """
        List registered tool names.
        
        Args:
            enabled_only: If True, only list enabled tools
            
        Returns:
            List of tool names
        """
        if enabled_only:
            return [name for name, reg in self._tools.items() if reg.enabled]
        return list(self._tools.keys())
    
    def get_tool_info(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a registered tool.
        
        Args:
            tool_name: Name of the tool
            
        Returns:
            Tool information dictionary or None if not found
        """
        if tool_name not in self._tools:
            return None
        
        registration = self._tools[tool_name]
        instances = self._instances_by_tool.get(tool_name, set())
        
        return {
            "name": tool_name,
            "class": registration.tool_class.__name__,
            "enabled": registration.enabled,
            "priority": registration.priority,
            "config": registration.config,
            "instance_count": len(instances),
            "max_instances": registration.max_instances,
            "auto_initialize": registration.auto_initialize,
            "auto_shutdown": registration.auto_shutdown,
            "registration_time": registration.registration_time.isoformat(),
            "last_used": registration.last_used.isoformat() if registration.last_used else None,
            "usage_count": registration.usage_count,
            "health_score": self._health_scores.get(tool_name, 0.0)
        }
    
    def get_registry_stats(self) -> Dict[str, Any]:
        """Get registry statistics."""
        total_tools = len(self._tools)
        enabled_tools = sum(1 for reg in self._tools.values() if reg.enabled)
        running_instances = len(self._instances)
        
        return {
            "start_time": self._start_time.isoformat() if self._start_time else None,
            "uptime_seconds": (
                (datetime.utcnow() - self._start_time).total_seconds() 
                if self._start_time else None
            ),
            "total_tools": total_tools,
            "enabled_tools": enabled_tools,
            "running_instances": running_instances,
            "max_concurrent_executions": self.max_concurrent_executions,
            "active_executions": len(self._active_executions),
            "total_executions": self._total_executions,
            "successful_executions": self._successful_executions,
            "failed_executions": self._failed_executions,
            "success_rate": (
                self._successful_executions / max(1, self._total_executions)
            ),
            "health_scores": self._health_scores.copy()
        }
    
    def add_event_handler(self, handler: ToolRegistryEventHandler):
        """Add an event handler to the registry."""
        self._event_handlers.append(handler)
    
    def remove_event_handler(self, handler: ToolRegistryEventHandler):
        """Remove an event handler from the registry."""
        if handler in self._event_handlers:
            self._event_handlers.remove(handler)
    
    async def _emit_event(
        self, 
        event_type: RegistryEventType, 
        tool_name: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None
    ):
        """Emit an event to all handlers."""
        event = RegistryEvent(
            event_type=event_type,
            tool_name=tool_name,
            data=data or {}
        )
        
        await self._event_queue.put(event)
    
    async def _process_events(self):
        """Process events from the event queue."""
        while self._running:
            try:
                event = await asyncio.wait_for(
                    self._event_queue.get(), 
                    timeout=1.0
                )
                
                # Process event with all handlers
                tasks = [
                    handler.handle_event(event) 
                    for handler in self._event_handlers
                    if asyncio.iscoroutinefunction(handler.handle_event)
                ]
                
                if tasks:
                    await asyncio.gather(*tasks, return_exceptions=True)
                
            except asyncio.TimeoutError:
                # Normal timeout, continue loop
                continue
            except Exception as e:
                self.logger.error(f"Error processing event: {e}")
    
    async def _start_health_monitoring(self):
        """Start global health monitoring."""
        for tool_name in self._tools:
            registration = self._tools[tool_name]
            if registration.health_check_interval > 0:
                await self._start_health_check(tool_name, registration.health_check_interval)
    
    async def _start_health_check(self, tool_name: str, interval: int):
        """Start health monitoring for a specific tool."""
        async def health_check_loop():
            while self._running and tool_name in self._tools:
                try:
                    # Get all instances of this tool
                    instances = []
                    if tool_name in self._instances_by_tool:
                        for inst_id in self._instances_by_tool[tool_name]:
                            if inst_id in self._instances:
                                instances.append(self._instances[inst_id])
                    
                    # Check health of each instance
                    for instance in instances:
                        try:
                            is_healthy = await instance.tool.health_check()
                            
                            if is_healthy:
                                instance.health_score = instance.tool.health_score
                            else:
                                instance.health_score = 0.0
                            
                            instance.last_health_check = datetime.utcnow()
                            
                            # Emit health change event if significant
                            current_score = self._health_scores.get(tool_name, 0.0)
                            if abs(instance.health_score - current_score) > 0.1:
                                await self._emit_event(
                                    RegistryEventType.TOOL_HEALTH_CHANGED,
                                    tool_name=tool_name,
                                    data={
                                        "instance_id": instance.instance_id,
                                        "health_score": instance.health_score,
                                        "previous_score": current_score
                                    }
                                )
                            
                        except Exception as e:
                            self.logger.error(f"Health check failed for {instance.instance_id}: {e}")
                            instance.health_score = 0.0
                    
                    # Update registry health scores
                    if instances:
                        avg_health = sum(inst.health_score for inst in instances) / len(instances)
                        self._health_scores[tool_name] = avg_health
                    
                except Exception as e:
                    self.logger.error(f"Health check loop error for {tool_name}: {e}")
                
                await asyncio.sleep(interval)
        
        # Start the health check task
        task = asyncio.create_task(health_check_loop())
        self._health_check_tasks[tool_name] = task
    
    def _update_tool_health_score(self, tool_name: str, health_score: float):
        """Update tool health score in registry."""
        self._health_scores[tool_name] = health_score
    
    async def enable_tool(self, tool_name: str) -> bool:
        """Enable a disabled tool."""
        if tool_name not in self._tools:
            return False
        
        self._tools[tool_name].enabled = True
        
        if self._tools[tool_name].auto_initialize:
            return await self.initialize_tool(tool_name)
        
        return True
    
    async def disable_tool(self, tool_name: str) -> bool:
        """Disable an enabled tool."""
        if tool_name not in self._tools:
            return False
        
        self._tools[tool_name].enabled = False
        
        # Shutdown all instances
        await self.shutdown_tool(tool_name)
        
        return True
    
    async def update_tool_config(self, tool_name: str, config: Dict[str, Any]) -> bool:
        """Update tool configuration."""
        if tool_name not in self._tools:
            return False
        
        # Update registration config
        self._tools[tool_name].config.update(config)
        
        # Update instance configs if they exist
        if tool_name in self._instances_by_tool:
            for inst_id in self._instances_by_tool[tool_name]:
                if inst_id in self._instances:
                    instance = self._instances[inst_id]
                    instance.tool.update_config(config)
        
        return True
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.stop()


# Global registry instance
_registry: Optional[ToolRegistry] = None


def get_registry() -> ToolRegistry:
    """Get the global tool registry instance."""
    global _registry
    if _registry is None:
        _registry = ToolRegistry()
    return _registry


async def setup_registry(**kwargs) -> ToolRegistry:
    """Setup and start the global tool registry."""
    global _registry
    _registry = ToolRegistry(**kwargs)
    await _registry.start()
    return _registry


async def cleanup_registry():
    """Cleanup the global tool registry."""
    global _registry
    if _registry:
        await _registry.stop()
        _registry = None
