"""
Enhanced Attachment Tool with MarkItDown Integration

This module provides comprehensive file processing capabilities including:
- Multi-format document parsing and extraction
- MarkItDown integration for document processing
- Security scanning and validation
- File type detection and routing
- Content extraction and metadata handling
- File storage management and cleanup
- Processing analytics and monitoring

Features:
- Support for PDF, Office documents, images, text files
- OCR capabilities for images and scanned documents
- Content cleaning and preprocessing
- Metadata extraction and storage
- File validation and security scanning
- Temporary file management
- Storage optimization and access control
- Processing statistics and error tracking
"""

import logging
import os
import mimetypes
import hashlib
import json
import tempfile
import shutil
import subprocess
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional, Union, Tuple
from datetime import datetime, timedelta
from contextlib import asynccontextmanager
from dataclasses import dataclass, asdict
from enum import Enum
import aiofiles
import filetype
import magic
from concurrent.futures import ThreadPoolExecutor

from app.config import settings

# Content extraction libraries
try:
    import pdfplumber
    import PyPDF2
    from docx import Document
    from openpyxl import load_workbook
    from pptx import Presentation
    from PIL import Image
    import pytesseract
    from bs4 import BeautifulSoup
    import markdown
    import xlrd
    from langchain_community.document_loaders import (
        PyPDFLoader, 
        Docx2txtLoader, 
        TextLoader, 
        UnstructuredHTMLLoader,
        CSVLoader,
        UnstructuredImageLoader
    )
    MARKITDOWN_AVAILABLE = True
except ImportError as e:
    logging.warning(f"Some document processing libraries not available: {e}")
    MARKITDOWN_AVAILABLE = False

logger = logging.getLogger(__name__)

# Constants for file processing
MAX_TEXT_LENGTH = 100000  # 100KB characters
MAX_PAGES = 50  # Max pages to process from large documents
CHUNK_SIZE = 8000  # Chunk size for large content
OCR_ENABLED = True  # Enable OCR for images
SUPPORTED_FORMATS = {
    # Document formats
    'pdf': 'application/pdf',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'doc': 'application/msword',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'ppt': 'application/vnd.ms-powerpoint',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'xls': 'application/vnd.ms-excel',
    'csv': 'text/csv',
    'tsv': 'text/tab-separated-values',
    
    # Text formats
    'txt': 'text/plain',
    'md': 'text/markdown',
    'html': 'text/html',
    'htm': 'text/html',
    'rtf': 'application/rtf',
    'xml': 'application/xml',
    'json': 'application/json',
    'yaml': 'application/x-yaml',
    'yml': 'application/x-yaml',
    
    # Image formats
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'bmp': 'image/bmp',
    'tiff': 'image/tiff',
    'tif': 'image/tiff',
    'webp': 'image/webp',
    'svg': 'image/svg+xml',
}

# Security thresholds
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_EXTENSIONS = set(SUPPORTED_FORMATS.keys())
BLOCKED_EXTENSIONS = {
    'exe', 'dll', 'bat', 'cmd', 'com', 'scr', 'vbs', 'js', 'jar', 
    'ps1', 'sh', 'bash', 'py', 'pl', 'rb', 'php', 'asp', 'aspx'
}


class FileType(Enum):
    """Supported file types."""
    DOCUMENT = "document"
    TEXT = "text"
    IMAGE = "image"
    SPREADSHEET = "spreadsheet"
    PRESENTATION = "presentation"
    ARCHIVE = "archive"
    UNKNOWN = "unknown"


@dataclass
class FileMetadata:
    """File metadata information."""
    name: str
    path: str
    size: int
    mime_type: str
    file_type: FileType
    extension: str
    hash: str
    created_at: str
    modified_at: str
    pages: Optional[int] = None
    dimensions: Optional[Tuple[int, int]] = None
    word_count: Optional[int] = None
    language: Optional[str] = None
    encoding: Optional[str] = None


@dataclass
class ProcessingResult:
    """Result of file processing."""
    success: bool
    content: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    warnings: Optional[List[str]] = None
    processing_time: Optional[float] = None
    content_type: Optional[str] = None


class SecurityScanner:
    """Security scanner for uploaded files."""
    
    @staticmethod
    async def scan_file(file_path: str) -> Dict[str, Any]:
        """
        Scan file for security threats.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Security scan results
        """
        scan_result = {
            "safe": True,
            "threats": [],
            "warnings": [],
            "scan_time": datetime.utcnow().isoformat()
        }
        
        try:
            # Check file extension
            extension = Path(file_path).suffix.lower()[1:]
            if extension in BLOCKED_EXTENSIONS:
                scan_result["safe"] = False
                scan_result["threats"].append(f"Blocked file extension: .{extension}")
            
            # Check file size
            file_size = Path(file_path).stat().st_size
            if file_size > MAX_FILE_SIZE:
                scan_result["warnings"].append(f"Large file size: {file_size} bytes")
            
            # Check file type using magic numbers
            try:
                with magic.Magic() as m:
                    file_mime = m.id_filename(file_path)
                    if 'executable' in file_mime.lower():
                        scan_result["safe"] = False
                        scan_result["threats"].append(f"Executable file detected: {file_mime}")
            except Exception as e:
                scan_result["warnings"].append(f"File type detection failed: {str(e)}")
            
            # Check for suspicious content patterns
            async with aiofiles.open(file_path, 'rb') as f:
                content = await f.read(1024)  # Read first 1KB
                
                # Check for script indicators
                if b'<script' in content.lower():
                    scan_result["warnings"].append("Potential script content detected")
                if b'javascript:' in content.lower():
                    scan_result["warnings"].append("Potential JavaScript code detected")
                    
        except Exception as e:
            scan_result["warnings"].append(f"Security scan error: {str(e)}")
        
        return scan_result


class MarkItDownProcessor:
    """MarkItDown integration for document processing."""
    
    def __init__(self):
        self.enabled = MARKITDOWN_AVAILABLE
        self.executor = ThreadPoolExecutor(max_workers=4)
        
    async def process_file(
        self, 
        file_path: str, 
        file_type: FileType,
        metadata: FileMetadata
    ) -> ProcessingResult:
        """
        Process file using appropriate method based on file type.
        
        Args:
            file_path: Path to the file
            file_type: Detected file type
            metadata: File metadata
            
        Returns:
            Processing result
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not self.enabled:
                return ProcessingResult(
                    success=False,
                    error="MarkItDown integration not available"
                )
            
            # Route to appropriate processor
            if file_type == FileType.DOCUMENT:
                result = await self._process_document(file_path, metadata)
            elif file_type == FileType.IMAGE:
                result = await self._process_image(file_path, metadata)
            elif file_type == FileType.TEXT:
                result = await self._process_text(file_path, metadata)
            elif file_type == FileType.SPREADSHEET:
                result = await self._process_spreadsheet(file_path, metadata)
            elif file_type == FileType.PRESENTATION:
                result = await self._process_presentation(file_path, metadata)
            else:
                result = ProcessingResult(
                    success=False,
                    error=f"Unsupported file type: {file_type.value}"
                )
            
            # Add processing time
            processing_time = asyncio.get_event_loop().time() - start_time
            result.processing_time = processing_time
            
            return result
            
        except Exception as e:
            logger.error(f"Error processing file {file_path}: {str(e)}")
            return ProcessingResult(
                success=False,
                error=str(e),
                processing_time=asyncio.get_event_loop().time() - start_time
            )
    
    async def _process_document(self, file_path: str, metadata: FileMetadata) -> ProcessingResult:
        """Process document files (PDF, DOCX, etc.)."""
        extension = metadata.extension.lower()
        warnings = []
        
        if extension == 'pdf':
            return await self._process_pdf(file_path, warnings)
        elif extension in ['docx', 'doc']:
            return await self._process_word_document(file_path, warnings)
        else:
            return ProcessingResult(
                success=False,
                error=f"Unsupported document format: {extension}"
            )
    
    async def _process_pdf(self, file_path: str, warnings: List[str]) -> ProcessingResult:
        """Process PDF files."""
        try:
            content_parts = []
            metadata_info = {}
            
            # Try pdfplumber first (better text extraction)
            try:
                with pdfplumber.open(file_path) as pdf:
                    metadata_info['pages'] = len(pdf.pages)
                    
                    for i, page in enumerate(pdf.pages[:MAX_PAGES]):
                        page_text = page.extract_text()
                        if page_text:
                            content_parts.append(f"[Page {i+1}]\n{page_text}")
                        
                        # Extract tables if any
                        tables = page.extract_tables()
                        if tables:
                            for j, table in enumerate(tables):
                                content_parts.append(f"[Table {i+1}.{j+1}]\n" + "\n".join([
                                    " | ".join([cell or "" for cell in row]) 
                                    for row in table
                                ]))
                    
                    # Add metadata
                    if pdf.metadata:
                        metadata_info.update({
                            'title': pdf.metadata.get('/Title'),
                            'author': pdf.metadata.get('/Author'),
                            'subject': pdf.metadata.get('/Subject'),
                            'creator': pdf.metadata.get('/Creator'),
                        })
            
            except Exception as e:
                warnings.append(f"pdfplumber failed: {str(e)}, trying PyPDF2")
                
                # Fallback to PyPDF2
                try:
                    with open(file_path, 'rb') as f:
                        pdf_reader = PyPDF2.PdfReader(f)
                        metadata_info['pages'] = len(pdf_reader.pages)
                        
                        for i, page in enumerate(pdf_reader.pages[:MAX_PAGES]):
                            page_text = page.extract_text()
                            if page_text:
                                content_parts.append(f"[Page {i+1}]\n{page_text}")
                except Exception as e:
                    return ProcessingResult(
                        success=False,
                        error=f"PyPDF2 also failed: {str(e)}"
                    )
            
            content = "\n\n".join(content_parts)
            
            # Limit content length
            if len(content) > MAX_TEXT_LENGTH:
                content = content[:MAX_TEXT_LENGTH] + "\n\n[Content truncated due to size limit]"
                warnings.append("Content truncated due to size limit")
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info,
                warnings=warnings
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))
    
    async def _process_word_document(self, file_path: str, warnings: List[str]) -> ProcessingResult:
        """Process Word documents."""
        try:
            doc = Document(file_path)
            content_parts = []
            
            # Extract paragraphs
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    content_parts.append(paragraph.text)
            
            # Extract tables
            for table in doc.tables:
                table_rows = []
                for row in table.rows:
                    row_data = []
                    for cell in row.cells:
                        row_data.append(cell.text.strip())
                    table_rows.append(" | ".join(row_data))
                content_parts.append("\n".join(table_rows))
            
            content = "\n\n".join(content_parts)
            
            # Add metadata
            metadata_info = {
                'paragraphs': len(doc.paragraphs),
                'tables': len(doc.tables),
            }
            
            if doc.core_properties:
                metadata_info.update({
                    'title': doc.core_properties.title,
                    'author': doc.core_properties.author,
                    'subject': doc.core_properties.subject,
                    'created': str(doc.core_properties.created) if doc.core_properties.created else None,
                    'modified': str(doc.core_properties.modified) if doc.core_properties.modified else None,
                })
            
            if len(content) > MAX_TEXT_LENGTH:
                content = content[:MAX_TEXT_LENGTH] + "\n\n[Content truncated due to size limit]"
                warnings.append("Content truncated due to size limit")
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info,
                warnings=warnings
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))
    
    async def _process_image(self, file_path: str, metadata: FileMetadata) -> ProcessingResult:
        """Process image files with OCR."""
        try:
            content_parts = []
            metadata_info = {}
            
            # Extract basic image info
            with Image.open(file_path) as img:
                metadata_info.update({
                    'dimensions': img.size,
                    'mode': img.mode,
                    'format': img.format,
                })
            
            # OCR processing if enabled
            if OCR_ENABLED:
                try:
                    # Use pytesseract for OCR
                    text = await asyncio.get_event_loop().run_in_executor(
                        self.executor,
                        lambda: pytesseract.image_to_string(Image.open(file_path))
                    )
                    
                    if text.strip():
                        content_parts.append("[OCR Text]\n" + text)
                    else:
                        content_parts.append("[Image processed - no readable text found]")
                        
                except Exception as e:
                    content_parts.append(f"[OCR failed: {str(e)}]")
                    metadata_info['ocr_error'] = str(e)
            else:
                content_parts.append("[Image processing disabled]")
            
            content = "\n\n".join(content_parts)
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info,
                warnings=[] if not OCR_ENABLED else None
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))
    
    async def _process_text(self, file_path: str, metadata: FileMetadata) -> ProcessingResult:
        """Process text files."""
        try:
            # Try different encodings
            encodings = ['utf-8', 'utf-16', 'iso-8859-1', 'cp1252']
            content = None
            
            for encoding in encodings:
                try:
                    async with aiofiles.open(file_path, 'r', encoding=encoding) as f:
                        content = await f.read()
                        metadata_info = {'encoding': encoding}
                        break
                except UnicodeDecodeError:
                    continue
            
            if content is None:
                return ProcessingResult(success=False, error="Could not decode file with any supported encoding")
            
            # Process markdown if applicable
            if metadata.extension.lower() == 'md':
                try:
                    html_content = markdown.markdown(content)
                    soup = BeautifulSoup(html_content, 'html.parser')
                    content = soup.get_text()
                    metadata_info['format'] = 'markdown_to_text'
                except Exception as e:
                    logger.warning(f"Markdown processing failed: {str(e)}")
            
            # Add basic text statistics
            word_count = len(content.split())
            char_count = len(content)
            line_count = len(content.splitlines())
            
            metadata_info.update({
                'word_count': word_count,
                'char_count': char_count,
                'line_count': line_count
            })
            
            if len(content) > MAX_TEXT_LENGTH:
                content = content[:MAX_TEXT_LENGTH] + "\n\n[Content truncated due to size limit]"
                metadata_info['truncated'] = True
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))
    
    async def _process_spreadsheet(self, file_path: str, metadata: FileMetadata) -> ProcessingResult:
        """Process spreadsheet files."""
        try:
            extension = metadata.extension.lower()
            content_parts = []
            metadata_info = {'sheets': []}
            
            if extension in ['xlsx', 'xls']:
                # Process Excel files
                if extension == 'xlsx':
                    wb = load_workbook(file_path, data_only=True)
                else:
                    wb = xlrd.open_workbook(file_path)
                
                metadata_info['sheet_names'] = wb.sheetnames() if hasattr(wb, 'sheetnames') else []
                
                for sheet_name in wb.sheetnames[:10]:  # Limit to first 10 sheets
                    try:
                        if extension == 'xlsx':
                            ws = wb[sheet_name]
                            max_row = min(ws.max_row, 1000)  # Limit rows
                            max_col = min(ws.max_column, 50)  # Limit columns
                        else:
                            sheet = wb.sheet_by_name(sheet_name)
                            max_row = min(sheet.nrows, 1000)
                            max_col = min(sheet.ncols, 50)
                        
                        # Extract sheet data
                        sheet_data = []
                        for row_idx in range(max_row):
                            row_data = []
                            for col_idx in range(max_col):
                                try:
                                    if extension == 'xlsx':
                                        cell_value = ws.cell(row_idx + 1, col_idx + 1).value
                                    else:
                                        cell_value = sheet.cell_value(row_idx, col_idx)
                                    
                                    # Convert to string and handle None
                                    cell_str = str(cell_value) if cell_value is not None else ""
                                    row_data.append(cell_str)
                                except:
                                    row_data.append("")
                            sheet_data.append(" | ".join(row_data))
                        
                        content_parts.append(f"[Sheet: {sheet_name}]\n" + "\n".join(sheet_data))
                        metadata_info['sheets'].append({
                            'name': sheet_name,
                            'rows': max_row,
                            'columns': max_col
                        })
                        
                    except Exception as e:
                        content_parts.append(f"[Sheet {sheet_name} - Error: {str(e)}]")
            
            elif extension in ['csv', 'tsv']:
                # Process CSV files
                import csv
                async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                    content = await f.read()
                
                # Parse CSV
                lines = content.splitlines()
                if lines:
                    delimiter = ',' if extension == 'csv' else '\t'
                    reader = csv.reader(lines[:1000], delimiter=delimiter)  # Limit to 1000 rows
                    
                    sheet_data = []
                    for i, row in enumerate(reader):
                        sheet_data.append(" | ".join(row))
                    
                    content_parts.append(f"[CSV Data]\n" + "\n".join(sheet_data))
                    metadata_info.update({
                        'rows': len(lines),
                        'columns': len(lines[0].split(delimiter)) if lines else 0,
                        'delimiter': delimiter
                    })
            
            content = "\n\n".join(content_parts)
            
            if len(content) > MAX_TEXT_LENGTH:
                content = content[:MAX_TEXT_LENGTH] + "\n\n[Content truncated due to size limit]"
                metadata_info['truncated'] = True
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))
    
    async def _process_presentation(self, file_path: str, metadata: FileMetadata) -> ProcessingResult:
        """Process presentation files."""
        try:
            prs = Presentation(file_path)
            content_parts = []
            metadata_info = {
                'slides': len(prs.slides)
            }
            
            for i, slide in enumerate(prs.slides[:50]):  # Limit to first 50 slides
                slide_content = [f"[Slide {i+1}]"]
                
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text.strip():
                        slide_content.append(shape.text.strip())
                
                content_parts.append("\n".join(slide_content))
                
                # Extract tables if any
                for shape in slide.shapes:
                    if shape.has_table:
                        table = shape.table
                        table_data = []
                        for row in table.rows:
                            row_data = []
                            for cell in row.cells:
                                row_data.append(cell.text.strip())
                            table_data.append(" | ".join(row_data))
                        content_parts.append(f"[Table - Slide {i+1}]\n" + "\n".join(table_data))
            
            content = "\n\n".join(content_parts)
            
            if len(content) > MAX_TEXT_LENGTH:
                content = content[:MAX_TEXT_LENGTH] + "\n\n[Content truncated due to size limit]"
                metadata_info['truncated'] = True
            
            return ProcessingResult(
                success=True,
                content=content,
                metadata=metadata_info
            )
            
        except Exception as e:
            return ProcessingResult(success=False, error=str(e))


class FileTypeDetector:
    """Advanced file type detection."""
    
    @staticmethod
    def detect_file_type(file_path: str) -> Tuple[FileType, str]:
        """
        Detect file type using multiple methods.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Tuple of (file_type, mime_type)
        """
        path = Path(file_path)
        extension = path.suffix.lower()[1:]
        
        # Primary detection by extension
        if extension in ALLOWED_EXTENSIONS:
            mime_type = SUPPORTED_FORMATS[extension]
            
            # Categorize by type
            if extension in ['pdf', 'doc', 'docx']:
                return FileType.DOCUMENT, mime_type
            elif extension in ['txt', 'md', 'html', 'htm', 'rtf', 'xml', 'json', 'yaml', 'yml']:
                return FileType.TEXT, mime_type
            elif extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'tif', 'webp', 'svg']:
                return FileType.IMAGE, mime_type
            elif extension in ['xlsx', 'xls', 'csv', 'tsv']:
                return FileType.SPREADSHEET, mime_type
            elif extension in ['pptx', 'ppt']:
                return FileType.PRESENTATION, mime_type
        
        # Fallback to magic number detection
        try:
            with magic.Magic() as m:
                mime_type = m.id_filename(file_path)
                
                if 'pdf' in mime_type:
                    return FileType.DOCUMENT, mime_type
                elif 'text' in mime_type:
                    return FileType.TEXT, mime_type
                elif 'image' in mime_type:
                    return FileType.IMAGE, mime_type
                elif 'excel' in mime_type or 'spreadsheet' in mime_type:
                    return FileType.SPREADSHEET, mime_type
                elif 'powerpoint' in mime_type or 'presentation' in mime_type:
                    return FileType.PRESENTATION, mime_type
                    
        except Exception:
            pass
        
        return FileType.UNKNOWN, "application/octet-stream"


class StorageManager:
    """File storage management."""
    
    def __init__(self, base_path: str = "./data/uploads"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        
    async def save_file(
        self, 
        uploaded_file, 
        session_id: str, 
        filename: str
    ) -> Tuple[str, FileMetadata]:
        """
        Save uploaded file and return path and metadata.
        
        Args:
            uploaded_file: FastAPI UploadFile object
            session_id: Session ID for organization
            filename: Original filename
            
        Returns:
            Tuple of (file_path, file_metadata)
        """
        # Create session directory
        session_dir = self.base_path / session_id
        session_dir.mkdir(exist_ok=True)
        
        # Generate unique filename with timestamp
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
        safe_filename = f"{timestamp}_{filename}"
        file_path = session_dir / safe_filename
        
        # Save file
        async with aiofiles.open(file_path, 'wb') as f:
            content = await uploaded_file.read()
            await f.write(content)
        
        # Calculate file hash
        file_hash = await self._calculate_file_hash(file_path)
        
        # Create metadata
        stat = file_path.stat()
        metadata = FileMetadata(
            name=filename,
            path=str(file_path),
            size=stat.st_size,
            mime_type=uploaded_file.content_type or "application/octet-stream",
            file_type=FileType.UNKNOWN,  # Will be updated by detector
            extension=Path(filename).suffix.lower()[1:],
            hash=file_hash,
            created_at=datetime.fromtimestamp(stat.st_ctime).isoformat(),
            modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(),
        )
        
        logger.info(f"Saved uploaded file: {file_path}")
        return str(file_path), metadata
    
    async def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA256 hash of file."""
        sha256_hash = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    
    async def cleanup_old_files(self, days: int = 7) -> int:
        """
        Clean up uploaded files older than specified days.
        
        Args:
            days: Number of days after which files should be deleted
            
        Returns:
            Number of files deleted
        """
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        deleted_count = 0
        
        try:
            for session_dir in self.base_path.iterdir():
                if session_dir.is_dir():
                    for file_path in session_dir.rglob("*"):
                        if file_path.is_file():
                            file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                            if file_time < cutoff_date:
                                file_path.unlink()
                                deleted_count += 1
            
            logger.info(f"Cleaned up {deleted_count} old files")
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
        
        return deleted_count
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        total_files = 0
        total_size = 0
        file_types = {}
        
        try:
            for file_path in self.base_path.rglob("*"):
                if file_path.is_file():
                    total_files += 1
                    size = file_path.stat().st_size
                    total_size += size
                    
                    extension = file_path.suffix.lower()[1:] or "no_extension"
                    file_types[extension] = file_types.get(extension, 0) + 1
        except Exception as e:
            logger.error(f"Error getting storage stats: {str(e)}")
        
        return {
            "total_files": total_files,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "file_types": file_types,
            "storage_path": str(self.base_path)
        }


class ProcessingAnalytics:
    """Analytics and monitoring for file processing."""
    
    def __init__(self):
        self.stats = {
            "total_processed": 0,
            "successful": 0,
            "failed": 0,
            "file_types": {},
            "processing_times": [],
            "errors": [],
            "start_time": datetime.utcnow()
        }
    
    def record_processing_result(self, result: ProcessingResult, file_type: FileType):
        """Record processing result for analytics."""
        self.stats["total_processed"] += 1
        
        if result.success:
            self.stats["successful"] += 1
        else:
            self.stats["failed"] += 1
        
        # Record file type
        type_name = file_type.value
        self.stats["file_types"][type_name] = self.stats["file_types"].get(type_name, 0) + 1
        
        # Record processing time
        if result.processing_time:
            self.stats["processing_times"].append(result.processing_time)
        
        # Record errors
        if result.error:
            self.stats["errors"].append({
                "error": result.error,
                "file_type": type_name,
                "timestamp": datetime.utcnow().isoformat()
            })
    
    def get_analytics_report(self) -> Dict[str, Any]:
        """Get comprehensive analytics report."""
        processing_times = self.stats["processing_times"]
        
        return {
            "summary": {
                "total_processed": self.stats["total_processed"],
                "successful": self.stats["successful"],
                "failed": self.stats["failed"],
                "success_rate": round(self.stats["successful"] / max(self.stats["total_processed"], 1) * 100, 2),
                "uptime_hours": round((datetime.utcnow() - self.stats["start_time"]).total_seconds() / 3600, 2)
            },
            "file_types": self.stats["file_types"],
            "performance": {
                "avg_processing_time": round(sum(processing_times) / len(processing_times), 3) if processing_times else 0,
                "min_processing_time": min(processing_times) if processing_times else 0,
                "max_processing_time": max(processing_times) if processing_times else 0
            },
            "errors": self.stats["errors"][-10:],  # Last 10 errors
            "generated_at": datetime.utcnow().isoformat()
        }


class AttachmentTool:
    """Enhanced attachment processing tool with MarkItDown integration."""
    
    def __init__(self):
        """Initialize the attachment tool with all components."""
        # Initialize components
        self.security_scanner = SecurityScanner()
        self.processor = MarkItDownProcessor()
        self.storage_manager = StorageManager(settings.upload_permanent_path)
        self.file_detector = FileTypeDetector()
        self.analytics = ProcessingAnalytics()
        
        # Ensure directories exist
        settings.create_directories()
        
        # Cleanup old files on startup
        asyncio.create_task(self.storage_manager.cleanup_old_files())
        
        logger.info("Enhanced AttachmentTool initialized with MarkItDown integration")
    
    async def process_attachments(
        self,
        file_paths: List[str],
        session_id: Optional[str] = None,
        extract_metadata: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Process uploaded file attachments with comprehensive analysis.
        
        Args:
            file_paths: List of file paths to process
            session_id: Optional session ID for organization
            extract_metadata: Whether to extract detailed metadata
            
        Returns:
            List of processed file information with enhanced details
        """
        processed_files = []
        
        logger.info(f"Processing {len(file_paths)} attachments")
        
        for file_path in file_paths:
            try:
                # Get file information
                file_info = await self._get_file_info(file_path)
                
                # Security scan
                security_result = await self.security_scanner.scan_file(file_path)
                
                if not security_result["safe"]:
                    processed_files.append({
                        "original_name": file_info["name"],
                        "stored_name": file_path,
                        "file_type": file_info["type"],
                        "file_size": file_info["size"],
                        "security_scan": security_result,
                        "status": "blocked",
                        "processed_at": datetime.utcnow().isoformat(),
                        "error": f"Security scan failed: {', '.join(security_result['threats'])}"
                    })
                    continue
                
                # Detect file type
                file_type, mime_type = self.file_detector.detect_file_type(file_path)
                
                # Create metadata object
                metadata = FileMetadata(
                    name=file_info["name"],
                    path=file_path,
                    size=file_info["size"],
                    mime_type=mime_type,
                    file_type=file_type,
                    extension=file_info["extension"],
                    hash=file_info["hash"],
                    created_at=file_info.get("created_at", datetime.utcnow().isoformat()),
                    modified_at=file_info.get("modified_at", datetime.utcnow().isoformat())
                )
                
                # Process file content
                if file_type != FileType.UNKNOWN:
                    processing_result = await self.processor.process_file(file_path, file_type, metadata)
                    
                    # Record analytics
                    self.analytics.record_processing_result(processing_result, file_type)
                    
                    processed_file = {
                        "original_name": file_info["name"],
                        "stored_name": file_path,
                        "file_type": file_type.value,
                        "file_size": file_info["size"],
                        "mime_type": mime_type,
                        "file_hash": file_info["hash"],
                        "security_scan": security_result,
                        "status": "processed" if processing_result.success else "failed",
                        "processed_content": processing_result.content,
                        "content_type": processing_result.content_type,
                        "content_length": len(processing_result.content) if processing_result.content else 0,
                        "metadata": {
                            **asdict(metadata),
                            **processing_result.metadata,
                            "processing_time": processing_result.processing_time,
                            "warnings": processing_result.warnings
                        },
                        "processing_result": {
                            "success": processing_result.success,
                            "error": processing_result.error,
                            "warnings": processing_result.warnings
                        },
                        "processed_at": datetime.utcnow().isoformat()
                    }
                else:
                    processed_file = {
                        "original_name": file_info["name"],
                        "stored_name": file_path,
                        "file_type": "unknown",
                        "file_size": file_info["size"],
                        "mime_type": mime_type,
                        "security_scan": security_result,
                        "status": "unsupported",
                        "processed_at": datetime.utcnow().isoformat(),
                        "error": "Unsupported file type"
                    }
                
                processed_files.append(processed_file)
                logger.info(f"Processed attachment: {file_info['name']} ({file_type.value})")
                
            except Exception as e:
                logger.error(f"Error processing attachment {file_path}: {str(e)}")
                processed_files.append({
                    "original_name": file_path,
                    "error": str(e),
                    "status": "error",
                    "processed_at": datetime.utcnow().isoformat()
                })
        
        return processed_files
    
    async def _get_file_info(self, file_path: str) -> Dict[str, Any]:
        """Get comprehensive information about a file."""
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Calculate file hash
        hash_sha256 = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                hash_sha256.update(chunk)
        
        stat = path.stat()
        
        return {
            "name": path.name,
            "path": str(path.absolute()),
            "extension": path.suffix[1:] if path.suffix else "",  # Remove the dot
            "size": stat.st_size,
            "mime_type": mimetypes.guess_type(file_path)[0] or "application/octet-stream",
            "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "hash": hash_sha256.hexdigest()
        }
    
    async def validate_file(
        self,
        file_path: str,
        max_size: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive file validation.
        
        Args:
            file_path: Path to the file
            max_size: Maximum allowed file size in bytes
            
        Returns:
            Validation result dictionary
        """
        file_info = await self._get_file_info(file_path)
        
        # Check file size
        if max_size and file_info["size"] > max_size:
            return {
                "valid": False,
                "error": f"File size ({file_info['size']} bytes) exceeds maximum allowed size ({max_size} bytes)"
            }
        
        # Check if file type is allowed
        file_ext = file_info["extension"].lower()
        if file_ext not in ALLOWED_EXTENSIONS:
            return {
                "valid": False,
                "error": f"File type .{file_ext} is not allowed. Allowed types: {list(ALLOWED_EXTENSIONS)}"
            }
        
        # Security scan
        security_result = await self.security_scanner.scan_file(file_path)
        
        if not security_result["safe"]:
            return {
                "valid": False,
                "error": f"Security scan failed: {', '.join(security_result['threats'])}",
                "security_scan": security_result
            }
        
        # Detect file type for additional validation
        file_type, mime_type = self.file_detector.detect_file_type(file_path)
        
        if file_type == FileType.UNKNOWN:
            return {
                "valid": False,
                "error": "Could not determine file type"
            }
        
        return {
            "valid": True,
            "file_info": file_info,
            "file_type": file_type.value,
            "mime_type": mime_type,
            "security_scan": security_result
        }
    
    async def save_uploaded_file(
        self,
        uploaded_file,
        session_id: str,
        filename: str
    ) -> str:
        """
        Save an uploaded file to the designated directory.
        
        Args:
            uploaded_file: FastAPI UploadFile object
            session_id: Session ID for organization
            filename: Original filename
            
        Returns:
            Path to the saved file
        """
        file_path, metadata = await self.storage_manager.save_file(uploaded_file, session_id, filename)
        return file_path
    
    async def extract_text_from_file(
        self,
        file_path: str,
        max_length: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Extract text content from a file.
        
        Args:
            file_path: Path to the file
            max_length: Maximum text length to extract
            
        Returns:
            Extracted text and metadata
        """
        try:
            # Validate file first
            validation = await self.validate_file(file_path)
            if not validation["valid"]:
                return {
                    "success": False,
                    "error": validation["error"]
                }
            
            # Detect file type
            file_type, mime_type = self.file_detector.detect_file_type(file_path)
            
            if file_type == FileType.UNKNOWN:
                return {
                    "success": False,
                    "error": "Unsupported file type"
                }
            
            # Get file metadata
            file_info = await self._get_file_info(file_path)
            metadata = FileMetadata(
                name=file_info["name"],
                path=file_path,
                size=file_info["size"],
                mime_type=mime_type,
                file_type=file_type,
                extension=file_info["extension"],
                hash=file_info["hash"],
                created_at=file_info.get("created_at", datetime.utcnow().isoformat()),
                modified_at=file_info.get("modified_at", datetime.utcnow().isoformat())
            )
            
            # Process file
            processing_result = await self.processor.process_file(file_path, file_type, metadata)
            
            # Record analytics
            self.analytics.record_processing_result(processing_result, file_type)
            
            # Truncate if requested
            content = processing_result.content
            if max_length and content and len(content) > max_length:
                content = content[:max_length] + "\n\n[Content truncated]"
            
            return {
                "success": processing_result.success,
                "content": content,
                "metadata": {
                    **asdict(metadata),
                    **processing_result.metadata
                },
                "file_type": file_type.value,
                "content_length": len(content) if content else 0,
                "error": processing_result.error,
                "warnings": processing_result.warnings
            }
            
        except Exception as e:
            logger.error(f"Error extracting text from {file_path}: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_processing_analytics(self) -> Dict[str, Any]:
        """Get processing analytics and statistics."""
        storage_stats = self.storage_manager.get_storage_stats()
        processing_stats = self.analytics.get_analytics_report()
        
        return {
            "storage": storage_stats,
            "processing": processing_stats,
            "markitdown_enabled": self.processor.enabled,
            "ocr_enabled": OCR_ENABLED,
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def cleanup_old_files(self, days: int = 7) -> int:
        """
        Clean up uploaded files older than specified days.
        
        Args:
            days: Number of days after which files should be deleted
            
        Returns:
            Number of files deleted
        """
        return await self.storage_manager.cleanup_old_files(days)
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on the attachment tool."""
        health_status = {
            "status": "healthy",
            "components": {},
            "checks": {}
        }
        
        try:
            # Check storage directory
            if self.storage_manager.base_path.exists():
                health_status["components"]["storage"] = "ok"
            else:
                health_status["components"]["storage"] = "error"
                health_status["status"] = "unhealthy"
            
            # Check MarkItDown integration
            health_status["components"]["markitdown"] = "ok" if self.processor.enabled else "disabled"
            
            # Check file type detection
            health_status["components"]["file_detection"] = "ok"
            
            # Check security scanner
            health_status["components"]["security_scanner"] = "ok"
            
            # Test file write capability
            try:
                test_file = self.storage_manager.base_path / "health_check.tmp"
                async with aiofiles.open(test_file, 'w') as f:
                    await f.write("health check")
                test_file.unlink()
                health_status["checks"]["file_write"] = "ok"
            except Exception as e:
                health_status["checks"]["file_write"] = f"error: {str(e)}"
                health_status["status"] = "degraded"
            
        except Exception as e:
            health_status["status"] = "unhealthy"
            health_status["error"] = str(e)
        
        health_status["timestamp"] = datetime.utcnow().isoformat()
        return health_status


# Global instance
attachment_tool = AttachmentTool()
