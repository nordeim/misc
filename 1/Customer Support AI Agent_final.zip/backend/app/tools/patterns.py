"""
Tool patterns for resilience, execution context, metrics, and monitoring.

Provides ready-to-use implementations of common tool patterns including:
- Retry mechanisms with exponential backoff
- Circuit breaker patterns
- Execution context isolation
- Metrics collection and monitoring
- Tool versioning and updates
"""

import asyncio
import time
import logging
from typing import (
    Any, Dict, List, Optional, Callable, Union, Awaitable,
    Generic, TypeVar, Protocol
)
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from contextlib import asynccontextmanager, contextmanager
from functools import wraps
import json
import weakref
import traceback

from .base_tool import (
    BaseTool, ToolExecutionContext, ToolStatus, ToolError,
    ToolExecutionError, ToolTimeoutError, ToolResourceError
)

T = TypeVar('T')


class RetryStrategy(Enum):
    """Retry strategy enumeration."""
    FIXED_DELAY = "fixed_delay"
    EXPONENTIAL_BACKOFF = "exponential_backoff"
    LINEAR_BACKOFF = "linear_backoff"
    IMMEDIATE = "immediate"


class CircuitBreakerState(Enum):
    """Circuit breaker state enumeration."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class RetryConfig:
    """Configuration for retry mechanisms."""
    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_BACKOFF
    jitter: bool = True
    backoff_multiplier: float = 2.0
    exceptions: tuple = (Exception,)
    timeout_per_attempt: Optional[float] = None


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker."""
    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    expected_exception: tuple = (Exception,)
    success_threshold: int = 3  # For half-open state


@dataclass
class ExecutionMetrics:
    """Detailed execution metrics for tools."""
    # Basic metrics
    execution_id: str
    tool_name: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    duration_ms: Optional[float] = None
    
    # Performance metrics
    memory_peak_mb: float = 0.0
    cpu_peak_percent: float = 0.0
    io_operations: int = 0
    
    # Retry metrics
    retry_count: int = 0
    total_retry_delay_ms: float = 0.0
    
    # Error metrics
    error_count: int = 0
    last_error: Optional[str] = None
    error_types: List[str] = field(default_factory=list)
    
    # Context metrics
    context_size_bytes: int = 0
    metadata_entries: int = 0
    tags_count: int = 0
    
    # Resource metrics
    files_opened: int = 0
    network_requests: int = 0
    database_queries: int = 0
    
    # Success metrics
    success: bool = False
    result_size_bytes: Optional[int] = None
    result_type: Optional[str] = None
    
    def mark_success(self, result: Any = None):
        """Mark execution as successful."""
        self.success = True
        self.ended_at = datetime.utcnow()
        self.duration_ms = (self.ended_at - self.started_at).total_seconds() * 1000
        
        if result is not None:
            try:
                self.result_size_bytes = len(json.dumps(result)) if isinstance(result, (dict, list)) else 0
                self.result_type = type(result).__name__
            except Exception:
                self.result_size_bytes = 0
                self.result_type = type(result).__name__ if result else None
    
    def mark_failure(self, error: Exception):
        """Mark execution as failed."""
        self.success = False
        self.ended_at = datetime.utcnow()
        self.duration_ms = (self.ended_at - self.started_at).total_seconds() * 1000
        
        self.error_count += 1
        self.last_error = str(error)
        error_type = type(error).__name__
        if error_type not in self.error_types:
            self.error_types.append(error_type)
    
    def add_retry_delay(self, delay_ms: float):
        """Add retry delay to metrics."""
        self.retry_count += 1
        self.total_retry_delay_ms += delay_ms


class RetryManager:
    """Advanced retry management with multiple strategies."""
    
    def __init__(self, config: Optional[RetryConfig] = None):
        self.config = config or RetryConfig()
        self.logger = logging.getLogger("tool.retry")
    
    async def execute_with_retry(
        self,
        func: Callable,
        *args,
        context: Optional[ToolExecutionContext] = None,
        **kwargs
    ) -> Any:
        """Execute function with retry logic."""
        last_exception = None
        
        for attempt in range(self.config.max_attempts):
            try:
                if asyncio.iscoroutinefunction(func):
                    if self.config.timeout_per_attempt:
                        result = await asyncio.wait_for(
                            func(*args, **kwargs),
                            timeout=self.config.timeout_per_attempt
                        )
                    else:
                        result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)
                
                return result
                
            except self.config.exceptions as e:
                last_exception = e
                
                if attempt < self.config.max_attempts - 1:
                    delay = self._calculate_delay(attempt)
                    self.logger.warning(
                        f"Attempt {attempt + 1} failed, retrying in {delay:.2f}s: {str(e)}"
                    )
                    await asyncio.sleep(delay)
                    continue
                else:
                    # All attempts failed
                    break
        
        # Re-raise the last exception
        if last_exception:
            raise last_exception
        else:
            raise ToolExecutionError("All retry attempts failed without exception")
    
    def _calculate_delay(self, attempt: int) -> float:
        """Calculate delay for retry attempt."""
        base_delay = self.config.base_delay
        
        if self.config.strategy == RetryStrategy.FIXED_DELAY:
            delay = base_delay
            
        elif self.config.strategy == RetryStrategy.LINEAR_BACKOFF:
            delay = base_delay * (attempt + 1)
            
        elif self.config.strategy == RetryStrategy.EXPONENTIAL_BACKOFF:
            delay = base_delay * (self.config.backoff_multiplier ** attempt)
            
        elif self.config.strategy == RetryStrategy.IMMEDIATE:
            delay = 0
            
        else:
            delay = base_delay
        
        # Apply max delay limit
        delay = min(delay, self.config.max_delay)
        
        # Add jitter if enabled
        if self.config.jitter and delay > 0:
            import random
            jitter_range = delay * 0.1  # 10% jitter
            delay += random.uniform(-jitter_range, jitter_range)
        
        return max(0, delay)


class AdvancedCircuitBreaker:
    """Advanced circuit breaker with detailed state management."""
    
    def __init__(self, config: Optional[CircuitBreakerConfig] = None):
        self.config = config or CircuitBreakerConfig()
        
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.last_success_time: Optional[datetime] = None
        
        self.logger = logging.getLogger("tool.circuit_breaker")
        self._lock = asyncio.Lock() if asyncio.iscoroutinefunction(self.call) else None
    
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection."""
        if self._lock:
            async with self._lock:
                return await self._execute(func, *args, **kwargs)
        else:
            return await self._execute(func, *args, **kwargs)
    
    async def _execute(self, func: Callable, *args, **kwargs) -> Any:
        """Internal execution with circuit breaker logic."""
        
        # Check state
        if self.state == CircuitBreakerState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitBreakerState.HALF_OPEN
                self.logger.info("Circuit breaker moved to HALF_OPEN state")
            else:
                raise ToolResourceError(
                    f"Circuit breaker is OPEN. Last failure: {self.last_failure_time}"
                )
        
        try:
            # Execute function
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            await self._on_success()
            return result
            
        except self.config.expected_exception as e:
            await self._on_failure()
            raise
    
    def _should_attempt_reset(self) -> bool:
        """Check if circuit breaker should attempt reset."""
        if not self.last_failure_time:
            return True
        
        return (datetime.utcnow() - self.last_failure_time).total_seconds() >= self.config.recovery_timeout
    
    async def _on_success(self):
        """Handle successful execution."""
        current_time = datetime.utcnow()
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.config.success_threshold:
                self.state = CircuitBreakerState.CLOSED
                self.failure_count = 0
                self.success_count = 0
                self.logger.info("Circuit breaker moved to CLOSED state")
        else:
            self.failure_count = 0
        
        self.last_success_time = current_time
    
    async def _on_failure(self):
        """Handle failed execution."""
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            # Failure in half-open state immediately opens circuit
            self.state = CircuitBreakerState.OPEN
            self.logger.warning("Circuit breaker moved to OPEN state (half-open failure)")
        elif self.failure_count >= self.config.failure_threshold:
            # Failure threshold reached
            self.state = CircuitBreakerState.OPEN
            self.logger.warning(f"Circuit breaker moved to OPEN state after {self.failure_count} failures")
    
    def get_state(self) -> Dict[str, Any]:
        """Get current circuit breaker state information."""
        return {
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "last_failure_time": self.last_failure_time.isoformat() if self.last_failure_time else None,
            "last_success_time": self.last_success_time.isoformat() if self.last_success_time else None,
            "should_attempt_reset": self._should_attempt_reset()
        }


class MetricsCollector:
    """Advanced metrics collection for tools."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.metrics")
        self._execution_metrics: Dict[str, ExecutionMetrics] = {}
        self._aggregated_metrics: Dict[str, Dict[str, Any]] = {}
    
    async def start_execution(
        self,
        execution_id: str,
        tool_name: str,
        context: ToolExecutionContext
    ) -> ExecutionMetrics:
        """Start tracking execution metrics."""
        metrics = ExecutionMetrics(
            execution_id=execution_id,
            tool_name=tool_name,
            started_at=datetime.utcnow(),
            context_size_bytes=len(json.dumps(context.to_dict())),
            metadata_entries=len(context.metadata),
            tags_count=len(context.tags)
        )
        
        self._execution_metrics[execution_id] = metrics
        return metrics
    
    async def end_execution(
        self,
        execution_id: str,
        success: bool,
        result: Any = None,
        error: Optional[Exception] = None
    ) -> Optional[ExecutionMetrics]:
        """End execution tracking and calculate final metrics."""
        if execution_id not in self._execution_metrics:
            return None
        
        metrics = self._execution_metrics[execution_id]
        
        if success:
            metrics.mark_success(result)
        elif error:
            metrics.mark_failure(error)
        
        # Update aggregated metrics
        await self._update_aggregated_metrics(metrics)
        
        # Remove from active tracking (could keep for historical data)
        # del self._execution_metrics[execution_id]
        
        return metrics
    
    async def _update_aggregated_metrics(self, metrics: ExecutionMetrics):
        """Update aggregated metrics for the tool."""
        tool_name = metrics.tool_name
        
        if tool_name not in self._aggregated_metrics:
            self._aggregated_metrics[tool_name] = {
                "total_executions": 0,
                "successful_executions": 0,
                "failed_executions": 0,
                "total_duration_ms": 0.0,
                "average_duration_ms": 0.0,
                "min_duration_ms": float('inf'),
                "max_duration_ms": 0.0,
                "total_memory_mb": 0.0,
                "average_memory_mb": 0.0,
                "total_retry_count": 0,
                "total_error_count": 0,
                "error_rate": 0.0,
                "success_rate": 0.0,
                "last_execution": None,
                "execution_times": [],  # Keep for percentile calculations
            }
        
        agg = self._aggregated_metrics[tool_name]
        
        # Update counters
        agg["total_executions"] += 1
        if metrics.success:
            agg["successful_executions"] += 1
        else:
            agg["failed_executions"] += 1
        
        # Update timing metrics
        if metrics.duration_ms is not None:
            agg["total_duration_ms"] += metrics.duration_ms
            agg["average_duration_ms"] = agg["total_duration_ms"] / agg["total_executions"]
            agg["min_duration_ms"] = min(agg["min_duration_ms"], metrics.duration_ms)
            agg["max_duration_ms"] = max(agg["max_duration_ms"], metrics.duration_ms)
            
            # Keep recent execution times for percentile calculations (limit to 1000)
            agg["execution_times"].append(metrics.duration_ms)
            if len(agg["execution_times"]) > 1000:
                agg["execution_times"] = agg["execution_times"][-1000:]
        
        # Update memory metrics
        agg["total_memory_mb"] += metrics.memory_peak_mb
        agg["average_memory_mb"] = agg["total_memory_mb"] / agg["total_executions"]
        
        # Update retry and error metrics
        agg["total_retry_count"] += metrics.retry_count
        agg["total_error_count"] += metrics.error_count
        
        # Calculate rates
        if agg["total_executions"] > 0:
            agg["success_rate"] = agg["successful_executions"] / agg["total_executions"]
            agg["error_rate"] = agg["failed_executions"] / agg["total_executions"]
        
        agg["last_execution"] = metrics.ended_at.isoformat() if metrics.ended_at else None
    
    def get_tool_metrics(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """Get aggregated metrics for a specific tool."""
        return self._aggregated_metrics.get(tool_name)
    
    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Get metrics for all tools."""
        return self._aggregated_metrics.copy()
    
    def get_execution_metrics(self, execution_id: str) -> Optional[ExecutionMetrics]:
        """Get metrics for a specific execution."""
        return self._execution_metrics.get(execution_id)
    
    def calculate_percentile(self, tool_name: str, percentile: float) -> Optional[float]:
        """Calculate percentile for execution times."""
        if tool_name not in self._aggregated_metrics:
            return None
        
        execution_times = self._aggregated_metrics[tool_name]["execution_times"]
        if not execution_times:
            return None
        
        sorted_times = sorted(execution_times)
        index = int(len(sorted_times) * percentile / 100)
        index = min(index, len(sorted_times) - 1)
        
        return sorted_times[index]


class IsolationManager:
    """Manages tool execution isolation and resource constraints."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.isolation")
        self._execution_locks: Dict[str, asyncio.Lock] = {}
        self._resource_monitors: Dict[str, Any] = {}
    
    @asynccontextmanager
    async def isolated_execution(
        self,
        execution_id: str,
        isolation_level: str = "default",
        resource_limits: Optional[Dict[str, Any]] = None
    ):
        """Execute tool in isolated context."""
        # Acquire execution lock
        lock = self._execution_locks.get(execution_id)
        if not lock:
            lock = asyncio.Lock()
            self._execution_locks[execution_id] = lock
        
        async with lock:
            try:
                # Apply resource limits
                if resource_limits:
                    await self._apply_resource_limits(execution_id, resource_limits)
                
                # Yield control to the tool execution
                yield
                
            finally:
                # Clean up resource monitors
                if execution_id in self._resource_monitors:
                    del self._resource_monitors[execution_id]
    
    async def _apply_resource_limits(self, execution_id: str, limits: Dict[str, Any]):
        """Apply resource limits for execution."""
        # This is a simplified implementation
        # In production, you'd want to use cgroups, containers, or similar
        
        memory_limit = limits.get('memory_mb')
        if memory_limit:
            self._resource_monitors[execution_id] = {
                'memory_limit': memory_limit,
                'start_time': time.time()
            }
            self.logger.info(f"Applied memory limit {memory_limit}MB for execution {execution_id}")
        
        # Add other resource limit implementations here
        # - CPU limits
        # - Disk I/O limits
        # - Network limits
        # - File descriptor limits
    
    async def check_resource_usage(self, execution_id: str) -> Dict[str, Any]:
        """Check current resource usage for execution."""
        monitor = self._resource_monitors.get(execution_id)
        if not monitor:
            return {}
        
        # Simplified resource check
        # In production, use psutil or similar for actual resource monitoring
        current_time = time.time()
        elapsed = current_time - monitor.get('start_time', current_time)
        
        return {
            "execution_time_seconds": elapsed,
            "memory_limit_mb": monitor.get('memory_limit'),
            # Add more resource metrics as needed
        }


class VersionManager:
    """Manages tool versioning and updates."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.version")
        self._versions: Dict[str, str] = {}
        self._update_history: Dict[str, List[Dict[str, Any]]] = {}
    
    def register_tool_version(self, tool_name: str, version: str):
        """Register a tool version."""
        self._versions[tool_name] = version
        
        if tool_name not in self._update_history:
            self._update_history[tool_name] = []
        
        self._update_history[tool_name].append({
            "version": version,
            "timestamp": datetime.utcnow().isoformat(),
            "action": "registered"
        })
        
        self.logger.info(f"Registered tool {tool_name} version {version}")
    
    def update_tool_version(self, tool_name: str, new_version: str) -> bool:
        """Update tool version."""
        if tool_name not in self._versions:
            return False
        
        old_version = self._versions[tool_name]
        self._versions[tool_name] = new_version
        
        if tool_name not in self._update_history:
            self._update_history[tool_name] = []
        
        self._update_history[tool_name].append({
            "old_version": old_version,
            "new_version": new_version,
            "timestamp": datetime.utcnow().isoformat(),
            "action": "updated"
        })
        
        self.logger.info(f"Updated tool {tool_name} from {old_version} to {new_version}")
        return True
    
    def get_tool_version(self, tool_name: str) -> Optional[str]:
        """Get tool version."""
        return self._versions.get(tool_name)
    
    def get_version_history(self, tool_name: str) -> List[Dict[str, Any]]:
        """Get version history for a tool."""
        return self._update_history.get(tool_name, []).copy()
    
    def is_compatible(self, tool_name: str, required_version: str) -> bool:
        """Check if tool version is compatible with requirements."""
        current_version = self._versions.get(tool_name)
        if not current_version:
            return False
        
        # Simple version comparison (in production, use proper semver)
        return self._compare_versions(current_version, required_version) >= 0
    
    def _compare_versions(self, version1: str, version2: str) -> int:
        """Compare two version strings."""
        v1_parts = [int(x) for x in version1.split('.')]
        v2_parts = [int(x) for x in version2.split('.')]
        
        # Pad shorter version with zeros
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts.extend([0] * (max_len - len(v1_parts)))
        v2_parts.extend([0] * (max_len - len(v2_parts)))
        
        for v1, v2 in zip(v1_parts, v2_parts):
            if v1 > v2:
                return 1
            elif v1 < v2:
                return -1
        
        return 0


# Global instances for shared patterns
_global_retry_manager = RetryManager()
_global_circuit_breaker = AdvancedCircuitBreaker()
_global_metrics_collector = MetricsCollector()
_global_isolation_manager = IsolationManager()
_global_version_manager = VersionManager()


def get_global_patterns() -> Dict[str, Any]:
    """Get global pattern instances."""
    return {
        "retry_manager": _global_retry_manager,
        "circuit_breaker": _global_circuit_breaker,
        "metrics_collector": _global_metrics_collector,
        "isolation_manager": _global_isolation_manager,
        "version_manager": _global_version_manager
    }


# Decorator factory for creating resilient tool methods
def create_resilient_method(
    retry_config: Optional[RetryConfig] = None,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
    isolation_level: str = "default"
):
    """Create a decorator that adds resilience patterns to tool methods."""
    
    def decorator(func: Callable) -> Callable:
        retry_mgr = RetryManager(retry_config) if retry_config else _global_retry_manager
        circuit_breaker = AdvancedCircuitBreaker(circuit_breaker_config) if circuit_breaker_config else _global_circuit_breaker
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Extract context from args (assuming first arg is tool instance)
            context = kwargs.get('context')
            if not context and len(args) > 1:
                context = getattr(args[0], 'execution_context', None)
            
            # Execute with circuit breaker protection
            async with _global_isolation_manager.isolated_execution(
                execution_id=str(id(func)),
                isolation_level=isolation_level
            ):
                # Use circuit breaker for the retry execution
                return await circuit_breaker.call(
                    retry_mgr.execute_with_retry,
                    func,
                    *args,
                    **kwargs
                )
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # For sync functions, use a simpler approach
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # In production, you'd want to handle retries for sync functions too
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    
    return decorator
