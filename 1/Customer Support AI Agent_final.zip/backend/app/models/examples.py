"""
Example usage of SQLAlchemy models and database operations.

This file demonstrates how to use the database models for various operations.
"""

from typing import List, Optional
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import UserORM, SessionORM, MessageORM, MemoryORM
from app.models.schemas import (
    UserCreate, UserUpdate,
    SessionCreate, SessionUpdate, SessionClose,
    MessageCreate, MessageFeedback,
    MemoryCreate, MemoryUpdate
)


# User operations
async def create_user_example(db: AsyncSession, user_data: UserCreate) -> UserORM:
    """Example of creating a new user."""
    # Check if user already exists
    existing_user = UserORM.get_by_email(db, user_data.email)
    if existing_user:
        raise ValueError("User already exists")
    
    existing_username = UserORM.get_by_username(db, user_data.username)
    if existing_username:
        raise ValueError("Username already exists")
    
    # Create user
    user = UserORM.create_user(
        db,
        email=user_data.email,
        username=user_data.username,
        full_name=user_data.full_name,
        hashed_password="hashed_password_here",  # In real app, hash the password
        bio=user_data.bio,
        timezone=user_data.timezone,
        language=user_data.language
    )
    
    return user


async def authenticate_user_example(db: AsyncSession, email: str, password: str) -> Optional[UserORM]:
    """Example of user authentication."""
    user = UserORM.get_by_email(db, email)
    if user and user.is_active:
        # In real app, verify password hash
        user.verify_login()
        return user
    return None


# Session operations
async def create_chat_session_example(db: AsyncSession, user_id: str, title: str) -> SessionORM:
    """Example of creating a chat session."""
    session = SessionORM.create_session(
        db,
        user_id=user_id,
        title=title,
        session_type="chat",
        model_name="gpt-3.5-turbo",
        provider="openai"
    )
    return session


async def get_user_sessions_example(db: AsyncSession, user_id: str) -> List[SessionORM]:
    """Example of getting user's sessions."""
    return SessionORM.get_active_sessions(db, user_id)


# Message operations
async def add_user_message_example(db: AsyncSession, session_id: str, content: str) -> MessageORM:
    """Example of adding a user message."""
    message = MessageORM.create_message(
        db,
        session_id=session_id,
        role="user",
        content=content,
        content_type="text"
    )
    
    # Update session activity
    session = db.get(SessionORM, session_id)
    if session:
        session.add_message(message)
    
    return message


async def add_assistant_message_example(
    db: AsyncSession, 
    session_id: str, 
    content: str,
    usage_stats: dict
) -> MessageORM:
    """Example of adding an assistant message with usage statistics."""
    message = MessageORM.create_message(
        db,
        session_id=session_id,
        role="assistant",
        content=content,
        content_type="text",
        model_name="gpt-3.5-turbo",
        provider="openai"
    )
    
    # Set usage statistics
    message.set_usage_stats(
        prompt_tokens=usage_stats["prompt_tokens"],
        completion_tokens=usage_stats["completion_tokens"],
        total_tokens=usage_stats["total_tokens"]
    )
    
    message.set_costs(
        input_cost=usage_stats["input_cost"],
        output_cost=usage_stats["output_cost"]
    )
    
    message.mark_as_processed()
    
    return message


async def get_conversation_context_example(db: AsyncSession, session_id: str, limit: int = 10) -> List[MessageORM]:
    """Example of getting conversation context."""
    return MessageORM.get_recent_messages(db, session_id, limit)


# Memory operations
async def store_user_preference_example(db: AsyncSession, session_id: str, key: str, value: str) -> MemoryORM:
    """Example of storing a user preference in memory."""
    memory = MemoryORM.create_memory(
        db,
        session_id=session_id,
        key=key,
        value=value,
        memory_type="user_preference",
        category="preferences",
        importance_score=0.8,
        source="user"
    )
    return memory


async def store_conversation_context_example(db: AsyncSession, session_id: str) -> List[MemoryORM]:
    """Example of storing conversation context in memory."""
    # Get recent messages for context
    messages = MessageORM.get_recent_messages(db, session_id, limit=5)
    
    context_memories = []
    for message in messages:
        # Create memory from message content
        memory = MemoryORM.create_memory(
            db,
            session_id=session_id,
            key=f"message_{message.id[:8]}",
            value=message.content[:200] + "..." if len(message.content) > 200 else message.content,
            memory_type="conversation",
            category="context",
            importance_score=0.6,
            source="system"
        )
        context_memories.append(memory)
    
    return context_memories


async def get_important_memories_example(db: AsyncSession, session_id: str) -> List[MemoryORM]:
    """Example of retrieving important memories."""
    return MemoryORM.get_important_memories(db, session_id, threshold=0.7)


# Complete conversation flow example
async def complete_conversation_flow_example(db: AsyncSession, user_id: str, initial_message: str):
    """Example of a complete conversation flow."""
    
    # 1. Create session
    session = await create_chat_session_example(db, user_id, "Chat Session")
    
    # 2. Add user message
    user_message = await add_user_message_example(db, session.id, initial_message)
    
    # 3. Store user message in memory
    await store_user_preference_example(
        db, 
        session.id, 
        f"user_preference_{user_message.id[:8]}",
        f"User mentioned: {initial_message[:50]}..."
    )
    
    # 4. Simulate AI response
    ai_response = f"I understand you're saying: {initial_message}"
    usage_stats = {
        "prompt_tokens": 10,
        "completion_tokens": 15,
        "total_tokens": 25,
        "input_cost": 0.0002,
        "output_cost": 0.0004
    }
    
    ai_message = await add_assistant_message_example(
        db, 
        session.id, 
        ai_response,
        usage_stats
    )
    
    # 5. Store conversation context
    await store_conversation_context_example(db, session.id)
    
    # 6. Get conversation summary
    context = await get_conversation_context_example(db, session.id)
    important_memories = await get_important_memories_example(db, session.id)
    
    return {
        "session": session,
        "messages": context,
        "memories": important_memories,
        "summary": session.to_summary_dict()
    }


# User management examples
async def update_user_profile_example(db: AsyncSession, user_id: str, profile_data: UserUpdate) -> UserORM:
    """Example of updating user profile."""
    user = db.get(UserORM, user_id)
    if not user:
        raise ValueError("User not found")
    
    # Update fields
    if profile_data.full_name:
        user.full_name = profile_data.full_name
    if profile_data.bio:
        user.bio = profile_data.bio
    if profile_data.avatar_url:
        user.avatar_url = profile_data.avatar_url
    
    user.update()
    return user


async def deactivate_user_example(db: AsyncSession, user_id: str) -> UserORM:
    """Example of deactivating a user."""
    user = db.get(UserORM, user_id)
    if not user:
        raise ValueError("User not found")
    
    user.deactivate()
    return user


# Session management examples
async def close_session_with_feedback_example(db: AsyncSession, session_id: str, feedback: str, rating: int):
    """Example of closing a session with user feedback."""
    session = db.get(SessionORM, session_id)
    if not session:
        raise ValueError("Session not found")
    
    session.close_session()
    session.set_feedback(feedback, rating)
    
    return session


# Search and query examples
async def search_conversation_memories_example(db: AsyncSession, session_id: str, query: str) -> List[MemoryORM]:
    """Example of searching conversation memories."""
    return MemoryORM.search_memories(db, session_id, query)


async def get_session_statistics_example(db: AsyncSession, user_id: str) -> dict:
    """Example of getting session statistics."""
    from sqlalchemy import func, and_
    
    # Count sessions by status
    session_counts = db.query(
        SessionORM.status,
        func.count(SessionORM.id).label('count')
    ).filter(
        SessionORM.user_id == user_id
    ).group_by(SessionORM.status).all()
    
    # Count total messages
    total_messages = db.query(func.count(MessageORM.id)).join(
        SessionORM, MessageORM.session_id == SessionORM.id
    ).filter(SessionORM.user_id == user_id).scalar()
    
    # Count total memories
    total_memories = db.query(func.count(MemoryORM.id)).join(
        SessionORM, MemoryORM.session_id == SessionORM.id
    ).filter(SessionORM.user_id == user_id).scalar()
    
    return {
        "session_counts": {status: count for status, count in session_counts},
        "total_messages": total_messages,
        "total_memories": total_memories
    }


# Cleanup examples
async def cleanup_expired_memories_example(db: AsyncSession) -> int:
    """Example of cleaning up expired memories."""
    from datetime import datetime
    
    expired_memories = db.query(MemoryORM).filter(
        and_(
            MemoryORM.expires_at.isnot(None),
            MemoryORM.expires_at < datetime.utcnow()
        )
    ).all()
    
    for memory in expired_memories:
        memory.deactivate()
    
    return len(expired_memories)


# Main execution example
async def main_example():
    """Example of using the database models in a FastAPI endpoint."""
    
    # This would typically be used in a FastAPI route handler
    async with get_db() as db:
        try:
            # Create a user
            user_data = UserCreate(
                email="user@example.com",
                username="testuser",
                full_name="Test User"
            )
            user = await create_user_example(db, user_data)
            
            # Create a conversation
            conversation_result = await complete_conversation_flow_example(
                db, 
                user.id, 
                "Hello, how are you?"
            )
            
            # Get user statistics
            stats = await get_session_statistics_example(db, user.id)
            
            return {
                "user": user.to_dict(),
                "conversation": conversation_result,
                "statistics": stats
            }
            
        except Exception as e:
            print(f"Error in example: {e}")
            raise


if __name__ == "__main__":
    import asyncio
    
    # Run the example
    asyncio.run(main_example())