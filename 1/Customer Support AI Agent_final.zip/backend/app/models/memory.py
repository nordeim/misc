"""
Memory ORM model for conversation memory and context storage.
"""

from datetime import datetime
from typing import List, Optional, Any
from uuid import UUID, uuid4

from sqlalchemy import (
    Column, String, DateTime, Text, JSON, Integer, 
    ForeignKey, Boolean, Float, Index
)
from sqlalchemy.orm import relationship

from .base import Base, ORMBase, BaseSchema
from pydantic import Field


class MemoryORM(Base, ORMBase):
    """Memory ORM model for conversation memory and context storage."""
    
    __tablename__ = "memories"
    
    # Core memory information
    session_id = Column(String, ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    key = Column(String(255), nullable=False, index=True)
    value = Column(Text, nullable=False)
    
    # Memory classification
    memory_type = Column(String(50), default="conversation", nullable=False, index=True)  
    # Types: 'conversation', 'context', 'preference', 'knowledge', 'fact', 'user_info'
    
    # Memory properties
    importance_score = Column(Float, default=0.5, nullable=False)  # 0.0 to 1.0
    confidence_score = Column(Float, default=1.0, nullable=False)   # 0.0 to 1.0
    access_count = Column(Integer, default=0, nullable=False)
    
    # Memory lifecycle
    expires_at = Column(DateTime, nullable=True, index=True)
    last_accessed = Column(DateTime, nullable=True)
    
    # Memory metadata
    source_message_id = Column(String, ForeignKey("messages.id"), nullable=True, index=True)
    tags = Column(JSON, nullable=True)  # List of tags for categorization
    meta_data = Column(JSON, nullable=True)    # Additional metadata
    
    # Memory relationships
    session = relationship("SessionORM", back_populates="memories")
    source_message = relationship("MessageORM", backref="memories")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_memories_session_type', 'session_id', 'memory_type'),
        Index('idx_memories_importance', 'importance_score'),
        Index('idx_memories_expires', 'expires_at'),
    )
    
    def __repr__(self) -> str:
        return f"<MemoryORM(id={self.id}, key='{self.key}', type='{self.memory_type}', session_id='{self.session_id}')>"
    
    def access(self) -> None:
        """Mark memory as accessed."""
        self.access_count += 1
        self.last_accessed = datetime.utcnow()
        self.update()
    
    def set_expiry(self, expires_at: datetime) -> None:
        """Set memory expiry time."""
        self.expires_at = expires_at
        self.update()
    
    def add_tag(self, tag: str) -> None:
        """Add a tag to the memory."""
        if self.tags is None:
            self.tags = []
        if tag not in self.tags:
            self.tags.append(tag)
            self.update()
    
    def remove_tag(self, tag: str) -> None:
        """Remove a tag from the memory."""
        if self.tags and tag in self.tags:
            self.tags.remove(tag)
            self.update()
    
    def update_value(self, value: str, source: str = "update") -> None:
        """Update memory value with versioning."""
        if self.meta_data is None:
            self.meta_data = {}
        
        # Store previous value
        if "value_history" not in self.meta_data:
            self.meta_data["value_history"] = []
        
        self.meta_data["value_history"].append({
            "value": self.value,
            "updated_at": self.updated_at.isoformat(),
            "source": source
        })
        
        self.value = value
        self.update()
    
    def get_importance_level(self) -> str:
        """Get importance level as string."""
        if self.importance_score >= 0.8:
            return "high"
        elif self.importance_score >= 0.5:
            return "medium"
        else:
            return "low"
    
    def is_expired(self) -> bool:
        """Check if memory has expired."""
        return self.expires_at and datetime.utcnow() > self.expires_at
    
    @classmethod
    def get_session_memories(cls, session, session_id: str, memory_type: Optional[str] = None) -> List["MemoryORM"]:
        """Get memories for a session."""
        query = session.query(cls).filter(cls.session_id == session_id)
        
        if memory_type:
            query = query.filter(cls.memory_type == memory_type)
        
        return query.order_by(cls.importance_score.desc(), cls.created_at.desc()).all()
    
    @classmethod
    def get_active_memories(cls, session, session_id: str) -> List["MemoryORM"]:
        """Get non-expired memories for a session."""
        return (session.query(cls)
                .filter(cls.session_id == session_id)
                .filter(cls.expires_at.is_(None) | (cls.expires_at > datetime.utcnow()))
                .order_by(cls.importance_score.desc())
                .all())
    
    @classmethod
    def get_by_key(cls, session, session_id: str, key: str) -> Optional["MemoryORM"]:
        """Get memory by session and key."""
        return (session.query(cls)
                .filter(cls.session_id == session_id, cls.key == key)
                .first())
    
    @classmethod
    def create_memory(cls, session, session_id: str, key: str, value: str, **kwargs) -> "MemoryORM":
        """Create a new memory."""
        memory = cls(
            session_id=session_id,
            key=key,
            value=value,
            **kwargs
        )
        session.add(memory)
        session.flush()
        return memory
    
    @classmethod
    def cleanup_expired(cls, session) -> int:
        """Clean up expired memories and return count."""
        expired = (session.query(cls)
                   .filter(cls.expires_at.isnot(None))
                   .filter(cls.expires_at <= datetime.utcnow())
                   .all())
        
        count = len(expired)
        for memory in expired:
            session.delete(memory)
        
        return count


# Pydantic Schemas for Memory
class MemoryBase(BaseSchema):
    """Base memory schema."""
    key: str = Field(..., max_length=255)
    value: str
    memory_type: str = Field(default="conversation", max_length=50)
    importance_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    confidence_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    expires_at: Optional[datetime] = None
    source_message_id: Optional[str] = None
    tags: Optional[List[str]] = None
    metadata: Optional[dict] = None


class MemoryCreate(MemoryBase):
    """Schema for creating a memory."""
    pass


class MemoryUpdate(BaseSchema):
    """Schema for updating a memory."""
    value: Optional[str] = None
    importance_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    confidence_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    expires_at: Optional[datetime] = None
    tags: Optional[List[str]] = None
    metadata: Optional[dict] = None


class MemoryRead(MemoryBase):
    """Schema for reading memory data."""
    id: str
    session_id: str
    access_count: int
    last_accessed: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class MemoryContext(BaseSchema):
    """Schema for memory in context."""
    key: str
    value: str
    memory_type: str
    importance_score: float


class MemoryStats(BaseSchema):
    """Schema for memory statistics."""
    session_id: str
    total_memories: int
    by_type: dict
    importance_distribution: dict
    expired_count: int
