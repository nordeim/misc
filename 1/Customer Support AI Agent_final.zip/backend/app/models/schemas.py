"""
Consolidated Pydantic schemas for all database models.
"""

# Import all schemas from individual model files
from .user import (
    UserBase, UserCreate, UserUpdate, UserRead,
    UserLogin, UserPasswordReset, UserPasswordUpdate
)
from .session import (
    SessionBase, SessionCreate, SessionUpdate, SessionRead,
    SessionSummary, SessionClose
)
from .message import (
    MessageBase, MessageCreate, MessageUpdate, MessageRead,
    MessageContext
)
from .memory import (
    MemoryBase, MemoryCreate, MemoryUpdate, MemoryRead
)
from .escalation_schemas import (
    # Enums
    EscalationStatus, EscalationPriority, EscalationReason, EscalationType,
    
    # Escalation schemas
    EscalationBase, EscalationCreate, EscalationUpdate, EscalationRead,
    EscalationAssignment, EscalationResolution,
    
    # Queue schemas
    EscalationQueueBase, EscalationQueueCreate, EscalationQueueUpdate, EscalationQueueRead,
    QueueAssignment,
    
    # Policy schemas
    EscalationPolicyBase, EscalationPolicyCreate, EscalationPolicyUpdate, EscalationPolicyRead,
    
    # Analytics schemas
    EscalationAnalyticsBase, EscalationAnalyticsCreate, EscalationAnalyticsRead,
    EscalationMetrics, QueuePerformance, EscalationTrends,
    
    # Decision schemas
    EscalationDecision, EscalationContext,
    
    # Notification schemas
    EscalationNotification, NotificationStatus
)

# Re-export all schemas for easy importing
__all__ = [
    # User schemas
    "UserBase", "UserCreate", "UserUpdate", "UserRead",
    "UserLogin", "UserPasswordReset", "UserPasswordUpdate",
    
    # Session schemas
    "SessionBase", "SessionCreate", "SessionUpdate", "SessionRead",
    "SessionSummary", "SessionClose",
    
    # Message schemas
    "MessageBase", "MessageCreate", "MessageUpdate", "MessageRead",
    "MessageWithContext", "MessageFeedback", "MessageUsage",
    "MessageCreateWithUsage",
    
    # Memory schemas
    "MemoryBase", "MemoryCreate", "MemoryUpdate", "MemoryRead",
    "MemorySearch", "MemoryImport", "MemoryWithDecay",
    
    # Escalation enums
    "EscalationStatus", "EscalationPriority", "EscalationReason", "EscalationType",
    
    # Escalation schemas
    "EscalationBase", "EscalationCreate", "EscalationUpdate", "EscalationRead",
    "EscalationAssignment", "EscalationResolution",
    
    # Queue schemas
    "EscalationQueueBase", "EscalationQueueCreate", "EscalationQueueUpdate", "EscalationQueueRead",
    "QueueAssignment",
    
    # Policy schemas
    "EscalationPolicyBase", "EscalationPolicyCreate", "EscalationPolicyUpdate", "EscalationPolicyRead",
    
    # Analytics schemas
    "EscalationAnalyticsBase", "EscalationAnalyticsCreate", "EscalationAnalyticsRead",
    "EscalationMetrics", "QueuePerformance", "EscalationTrends",
    
    # Decision schemas
    "EscalationDecision", "EscalationContext",
    
    # Notification schemas
    "EscalationNotification", "NotificationStatus"
]