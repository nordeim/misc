"""
Logging middleware for FastAPI application.

Provides comprehensive request/response logging with:
- Structured logging with JSON format
- Request correlation IDs
- Performance timing
- Security-aware logging (PII handling)
- Log rotation and management
"""

import time
import uuid
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Middleware to add correlation IDs to requests and responses."""
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Add correlation ID to request and response."""
        # Get correlation ID from header or generate new one
        correlation_id = (
            request.headers.get("X-Correlation-ID") or
            request.headers.get("X-Request-ID") or
            str(uuid.uuid4())
        )
        
        # Add correlation ID to request state
        request.state.correlation_id = correlation_id
        
        # Get client info
        client_ip = self._get_client_ip(request)
        request.state.client_ip = client_ip
        
        # Add to request headers for downstream services
        request.state.correlation_id = correlation_id
        
        # Process request
        response = await call_next(request)
        
        # Add correlation ID to response headers
        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Request-ID"] = correlation_id
        
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """Extract client IP address from request."""
        # Check for forwarded headers
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        # Fallback to direct client IP
        if request.client:
            return request.client.host
        return "unknown"

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for comprehensive request/response logging."""
    
    SENSITIVE_HEADERS = {
        "authorization", "proxy-authorization", "cookie", "x-api-key",
        "x-auth-token", "x-access-token", "x-session-token"
    }
    
    SENSITIVE_FIELDS = {
        "password", "token", "secret", "key", "auth", "credential",
        "ssn", "social_security", "credit_card", "card_number", "cvv"
    }
    
    def __init__(self, app):
        super().__init__(app)
        self.sensitive_headers = {h.lower() for h in self.SENSITIVE_HEADERS}
        self.sensitive_fields = {f.lower() for f in self.SENSITIVE_FIELDS}
        
        # Setup structured logging
        self._setup_structured_logging()
    
    def _setup_structured_logging(self):
        """Configure structured logging for the application."""
        # Configure structlog
        structlog.configure(
            processors=[
                structlog.stdlib.filter_by_level,
                structlog.stdlib.add_logger_name,
                structlog.stdlib.add_log_level,
                structlog.stdlib.PositionalArgumentsFormatter(),
                structlog.processors.TimeStamper(fmt="ISO"),
                structlog.processors.StackInfoRenderer(),
                structlog.processors.format_exc_info,
                structlog.processors.UnicodeDecoder(),
                structlog.processors.JSONRenderer()
            ],
            context_class=dict,
            logger_factory=structlog.stdlib.LoggerFactory(),
            wrapper_class=structlog.stdlib.BoundLogger,
            cache_logger_on_first_use=True,
        )
        
        logger.info("Request logging middleware configured")
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Log request and response with comprehensive details."""
        start_time = time.time()
        
        # Extract request information
        request_info = self._extract_request_info(request)
        
        # Add to request state
        request.state.start_time = start_time
        request.state.request_info = request_info
        
        # Log incoming request
        self._log_request(request_info, request)
        
        try:
            # Process request
            response = await call_next(request)
            
            # Calculate processing time
            process_time = time.time() - start_time
            
            # Extract response information
            response_info = self._extract_response_info(response, process_time)
            
            # Log successful response
            self._log_response(request_info, response_info, response)
            
            # Add timing header
            response.headers["X-Process-Time"] = str(process_time)
            
            return response
            
        except Exception as exc:
            # Calculate processing time
            process_time = time.time() - start_time
            
            # Log error
            self._log_error(request_info, exc, process_time)
            raise
    
    def _extract_request_info(self, request: Request) -> Dict[str, Any]:
        """Extract request information for logging."""
        return {
            "method": request.method,
            "url": str(request.url),
            "path": request.url.path,
            "query_params": dict(request.query_params) if request.query_params else {},
            "headers": self._sanitize_headers(request.headers),
            "client_ip": getattr(request.state, 'client_ip', 'unknown'),
            "user_agent": request.headers.get("User-Agent", ""),
            "correlation_id": getattr(request.state, 'correlation_id', str(uuid.uuid4())),
            "content_type": request.headers.get("content-type", ""),
            "content_length": request.headers.get("content-length", ""),
        }
    
    def _extract_response_info(self, response: Response, process_time: float) -> Dict[str, Any]:
        """Extract response information for logging."""
        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "process_time": round(process_time, 4),
        }
    
    def _sanitize_headers(self, headers) -> Dict[str, str]:
        """Sanitize headers by removing sensitive information."""
        sanitized = {}
        for key, value in headers.items():
            if key.lower() in self.sensitive_headers:
                sanitized[key] = "[REDACTED]"
            else:
                sanitized[key] = value
        return sanitized
    
    def _sanitize_body(self, body: Any) -> Any:
        """Sanitize request/response body by removing sensitive fields."""
        if not isinstance(body, dict):
            return body
        
        sanitized = {}
        for key, value in body.items():
            if any(sensitive in key.lower() for sensitive in self.sensitive_fields):
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, dict):
                sanitized[key] = self._sanitize_body(value)
            else:
                sanitized[key] = value
        
        return sanitized
    
    def _log_request(self, request_info: Dict[str, Any], request: Request):
        """Log incoming request."""
        log_data = {
            "event": "request_received",
            **request_info,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        # Add body info if available and safe
        if request.method in ["POST", "PUT", "PATCH"] and request.state.body:
            try:
                body = getattr(request.state, 'body', None)
                if body:
                    log_data["body_size"] = len(body)
            except Exception:
                pass
        
        logger.info("Incoming request", **log_data)
    
    def _log_response(self, request_info: Dict[str, Any], response_info: Dict[str, Any], response: Response):
        """Log successful response."""
        log_data = {
            "event": "request_completed",
            "request": request_info,
            "response": response_info,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        # Add response status level
        if response.status_code >= 500:
            log_level = "error"
        elif response.status_code >= 400:
            log_level = "warning"
        else:
            log_level = "info"
        
        logger.log(log_level, "Request completed", **log_data)
    
    def _log_error(self, request_info: Dict[str, Any], exc: Exception, process_time: float):
        """Log error occurred during request processing."""
        log_data = {
            "event": "request_error",
            "request": request_info,
            "error": {
                "type": type(exc).__name__,
                "message": str(exc),
                "process_time": round(process_time, 4),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        logger.error("Request failed", **log_data)

class PerformanceLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for performance monitoring and logging."""
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Monitor and log performance metrics."""
        start_time = time.time()
        start_memory = self._get_memory_usage()
        
        # Add timing info to request state
        request.state.start_time = start_time
        request.state.start_memory = start_memory
        
        # Process request
        response = await call_next(request)
        
        # Calculate performance metrics
        end_time = time.time()
        end_memory = self._get_memory_usage()
        
        process_time = end_time - start_time
        memory_delta = end_memory - start_memory
        
        # Log performance if threshold exceeded
        if process_time > 1.0:  # Log slow requests
            logger.warning(
                "Slow request detected",
                process_time=round(process_time, 3),
                memory_delta_mb=round(memory_delta / 1024 / 1024, 2),
                method=request.method,
                path=request.url.path,
                status_code=response.status_code
            )
        
        # Add performance headers
        response.headers["X-Process-Time"] = str(round(process_time, 4))
        response.headers["X-Memory-Delta-MB"] = str(round(memory_delta / 1024 / 1024, 2))
        
        return response
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in bytes."""
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss
        except ImportError:
            return 0.0

class SecurityEventLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware for logging security-related events."""
    
    SUSPICIOUS_PATTERNS = [
        r' UNION\s+SELECT',      # SQL injection
        r'<script[^>]*>.*?</script>',  # XSS
        r'\.\./',                # Path traversal
        r'javascript:',          # JavaScript protocol
        r'on\w+\s*=',            # Event handlers
        r'or\s+1\s*=\s*1',       # SQL injection
    ]
    
    def __init__(self, app):
        super().__init__(app)
        import re
        self.suspicious_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.SUSPICIOUS_PATTERNS]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Check for security events and log them."""
        # Check for suspicious patterns in request
        if self._is_suspicious_request(request):
            logger.warning(
                "Suspicious request detected",
                method=request.method,
                path=request.url.path,
                query_params=dict(request.query_params),
                client_ip=getattr(request.state, 'client_ip', 'unknown'),
                user_agent=request.headers.get("User-Agent", ""),
                event_type="suspicious_request"
            )
        
        # Process request
        response = await call_next(request)
        
        # Log security-related status codes
        if response.status_code in [401, 403, 429]:
            logger.warning(
                "Security event",
                status_code=response.status_code,
                method=request.method,
                path=request.url.path,
                client_ip=getattr(request.state, 'client_ip', 'unknown'),
                event_type="security_event"
            )
        
        return response
    
    def _is_suspicious_request(self, request: Request) -> bool:
        """Check if request contains suspicious patterns."""
        # Check path
        if self._contains_suspicious_patterns(request.url.path):
            return True
        
        # Check query parameters
        for value in request.query_params.values():
            if self._contains_suspicious_patterns(value):
                return True
        
        return False
    
    def _contains_suspicious_patterns(self, content: str) -> bool:
        """Check if content contains suspicious patterns."""
        return any(pattern.search(content) for pattern in self.suspicious_patterns)

def setup_logging_middleware(app) -> None:
    """
    Setup all logging middleware for the FastAPI app.
    
    Args:
        app: FastAPI application instance
    """
    # Add correlation ID middleware first
    app.add_middleware(CorrelationIdMiddleware)
    
    # Add performance logging middleware
    app.add_middleware(PerformanceLoggingMiddleware)
    
    # Add main request logging middleware
    app.add_middleware(RequestLoggingMiddleware)
    
    # Add security event logging middleware
    app.add_middleware(SecurityEventLoggingMiddleware)
    
    logger.info("Logging middleware configured successfully")

# Utility functions for structured logging
def log_structured_event(event_type: str, data: Dict[str, Any], level: str = "info") -> None:
    """Log a structured event with consistent format."""
    structured_data = {
        "event": event_type,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **data
    }
    
    log_method = getattr(logger, level)
    log_method("Structured event", **structured_data)

def get_request_logger(request: Request) -> structlog.BoundLogger:
    """Get a request-specific logger with correlation ID."""
    return logger.bind(
        correlation_id=getattr(request.state, 'correlation_id', None),
        client_ip=getattr(request.state, 'client_ip', None)
    )