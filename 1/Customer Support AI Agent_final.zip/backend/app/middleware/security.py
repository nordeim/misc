"""
Security middleware for FastAPI application.

Provides comprehensive security features including:
- JWT token authentication
- Security headers (HSTS, CSP, etc.)
- API key authentication
- Request validation and sanitization
"""

import jwt
import re
import time
import json
from typing import Optional, Dict, Any, Callable, List
from datetime import datetime, timedelta
from urllib.parse import urlparse
from pathlib import Path

from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

# Security scheme for JWT
security = HTTPBearer(auto_error=False)

class JWTAuthMiddleware(BaseHTTPMiddleware):
    """Middleware for JWT token authentication."""
    
    def __init__(self, app, whitelist_paths: Optional[List[str]] = None):
        """Initialize JWT auth middleware.
        
        Args:
            app: FastAPI application
            whitelist_paths: Paths to exclude from JWT authentication
        """
        super().__init__(app)
        self.whitelist_paths = whitelist_paths or [
            "/health",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/metrics",
            "/api/v1/auth/login",
            "/api/v1/auth/register",
        ]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Process request and add JWT authentication."""
        path = request.url.path
        
        # Skip authentication for whitelisted paths
        if any(path.startswith(whitelist_path) for whitelist_path in self.whitelist_paths):
            return await call_next(request)
        
        # Skip if security is disabled
        if not settings.security_headers_enabled:
            return await call_next(request)
        
        # Get authorization header
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            logger.warning("Missing authorization header", path=path)
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Authorization header missing"}
            )
        
        try:
            # Parse Bearer token
            if not auth_header.startswith("Bearer "):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid authorization header format"
                )
            
            token = auth_header.replace("Bearer ", "")
            
            # Decode JWT token
            payload = jwt.decode(
                token, 
                settings.jwt_secret_key.get_secret_value(),
                algorithms=[settings.jwt_algorithm]
            )
            
            # Add user info to request state
            request.state.user = {
                "id": payload.get("sub"),
                "email": payload.get("email"),
                "role": payload.get("role", "user"),
                "permissions": payload.get("permissions", []),
                "exp": payload.get("exp"),
                "iat": payload.get("iat")
            }
            
            logger.debug("JWT authentication successful", user_id=payload.get("sub"))
            
        except jwt.ExpiredSignatureError:
            logger.warning("JWT token expired", path=path)
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Token has expired"}
            )
        except jwt.InvalidTokenError as e:
            logger.warning("Invalid JWT token", error=str(e), path=path)
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Invalid token"}
            )
        
        return await call_next(request)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware to add security headers to responses."""
    
    def __init__(self, app):
        super().__init__(app)
        self.security_headers = self._build_security_headers()
    
    def _build_security_headers(self) -> Dict[str, str]:
        """Build security headers dictionary."""
        headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
        }
        
        # Add HSTS header if SSL is enabled
        if settings.ssl_enabled:
            headers["Strict-Transport-Security"] = f"max-age={settings.hsts_max_age}; includeSubDomains; preload"
        
        # Add CSP header
        if settings.content_security_policy:
            headers["Content-Security-Policy"] = settings.content_security_policy
        
        # Add permissions policy
        permissions_policy = (
            "accelerometer=(), camera=(), geolocation=(), "
            "gyroscope=(), magnetometer=(), microphone=(), "
            "payment=(), usb=()"
        )
        headers["Permissions-Policy"] = permissions_policy
        
        return headers
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Add security headers to response."""
        response = await call_next(request)
        
        # Add security headers
        for header, value in self.security_headers.items():
            response.headers[header] = value
        
        return response

class APIKeyAuthMiddleware(BaseHTTPMiddleware):
    """Middleware for API key authentication."""
    
    def __init__(self, app, whitelist_paths: Optional[List[str]] = None):
        super().__init__(app)
        self.whitelist_paths = whitelist_paths or [
            "/health",
            "/docs",
            "/redoc",
            "/openapi.json",
        ]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Process request and check API key if present."""
        # Skip for whitelisted paths
        path = request.url.path
        if any(path.startswith(whitelist_path) for whitelist_path in self.whitelist_paths):
            return await call_next(request)
        
        # Check for API key in headers
        api_key = request.headers.get("X-API-Key")
        if api_key and settings.api_key:
            if api_key == settings.api_key.get_secret_value():
                logger.debug("API key authentication successful")
                request.state.api_key_valid = True
            else:
                logger.warning("Invalid API key provided", path=path)
                return JSONResponse(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    content={"detail": "Invalid API key"}
                )
        
        return await call_next(request)

class RequestValidationMiddleware(BaseHTTPMiddleware):
    """Middleware for request validation and sanitization."""
    
    # Dangerous patterns to block
    DANGEROUS_PATTERNS = [
        r"../",           # Path traversal
        r"\\.\\.\\/",     # Windows path traversal
        r"javascript:",   # JavaScript protocol
        r"data:",         # Data URL scheme
        r"vbscript:",     # VBScript protocol
        r"on\w+\s*=",     # Event handlers
    ]
    
    def __init__(self, app):
        super().__init__(app)
        self.dangerous_patterns = [re.compile(pattern) for pattern in self.DANGEROUS_PATTERNS]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Validate and sanitize request."""
        # Check query parameters
        for key, value in request.query_params.items():
            if self._contains_dangerous_content(value):
                logger.warning("Dangerous content in query parameter", 
                             key=key, value=value, client=request.client.host)
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={"detail": "Invalid request parameters"}
                )
        
        # Check path parameters
        path = str(request.url.path)
        if self._contains_dangerous_content(path):
            logger.warning("Dangerous content in path", path=path, client=request.client.host)
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={"detail": "Invalid request path"}
            )
        
        return await call_next(request)
    
    def _contains_dangerous_content(self, content: str) -> bool:
        """Check if content contains dangerous patterns."""
        return any(pattern.search(content) for pattern in self.dangerous_patterns)

# JWT utilities
async def get_current_user(request: Request) -> Dict[str, Any]:
    """Get current user from request state."""
    if not hasattr(request.state, 'user'):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required"
        )
    return request.state.user

async def get_current_active_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current active user (extend this for user status checks)."""
    return current_user

async def get_current_admin_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current admin user."""
    if current_user.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required"
        )
    return current_user

def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Create JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.jwt_secret_key.get_secret_value(), 
        algorithm=settings.jwt_algorithm
    )
    return encoded_jwt

def create_refresh_token(data: Dict[str, Any]) -> str:
    """Create JWT refresh token."""
    expire = datetime.utcnow() + timedelta(days=settings.jwt_refresh_expire_days)
    to_encode = data.copy()
    to_encode.update({
        "exp": expire,
        "type": "refresh"
    })
    
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.jwt_secret_key.get_secret_value(), 
        algorithm=settings.jwt_algorithm
    )
    return encoded_jwt


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware to prevent abuse."""
    
    def __init__(self, app: FastAPI, requests_per_minute: int = 100):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.request_times: Dict[str, List[float]] = {}
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Apply rate limiting."""
        client_ip = self._get_client_ip(request)
        current_time = time.time()
        
        # Clean old requests (older than 1 minute)
        if client_ip in self.request_times:
            self.request_times[client_ip] = [
                req_time for req_time in self.request_times[client_ip]
                if current_time - req_time < 60
            ]
        else:
            self.request_times[client_ip] = []
        
        # Check rate limit
        if len(self.request_times[client_ip]) >= self.requests_per_minute:
            logger.warning("Rate limit exceeded", client_ip=client_ip, path=request.url.path)
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": "Rate limit exceeded. Try again later."}
            )
        
        # Add current request time
        self.request_times[client_ip].append(current_time)
        
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = max(0, self.requests_per_minute - len(self.request_times[client_ip]))
        response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(int(current_time + 60))
        
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """Get client IP address."""
        if settings.trust_proxy_headers:
            forwarded_for = request.headers.get("X-Forwarded-For")
            if forwarded_for:
                return forwarded_for.split(",")[0].strip()
            
            real_ip = request.headers.get("X-Real-IP")
            if real_ip:
                return real_ip
        
        return request.client.host if request.client else "unknown"


class IPWhitelistMiddleware(BaseHTTPMiddleware):
    """IP allowlisting middleware."""
    
    def __init__(self, app: FastAPI, allowed_ips: Optional[List[str]] = None):
        super().__init__(app)
        self.allowed_ips = set(allowed_ips or [])
        # Add localhost and current host in development
        if settings.is_development:
            self.allowed_ips.update([
                "127.0.0.1", "localhost", "::1", "0.0.0.0"
            ])
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Check IP allowlist."""
        client_ip = self._get_client_ip(request)
        
        # Skip allowlist check in development if no IPs are configured
        if settings.is_development and not self.allowed_ips:
            return await call_next(request)
        
        if self.allowed_ips and client_ip not in self.allowed_ips:
            logger.warning("IP not in allowlist", client_ip=client_ip, path=request.url.path)
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content={"detail": "Access denied"}
            )
        
        return await call_next(request)
    
    def _get_client_ip(self, request: Request) -> str:
        """Get client IP address."""
        if settings.trust_proxy_headers:
            forwarded_for = request.headers.get("X-Forwarded-For")
            if forwarded_for:
                return forwarded_for.split(",")[0].strip()
            
            real_ip = request.headers.get("X-Real-IP")
            if real_ip:
                return real_ip
        
        return request.client.host if request.client else "unknown"


class InputSanitizationMiddleware(BaseHTTPMiddleware):
    """Sanitize request inputs to prevent injection attacks."""
    
    def __init__(self, app: FastAPI):
        super().__init__(app)
        # SQL injection patterns
        self.sql_injection_patterns = [
            re.compile(r"(\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b)", re.IGNORECASE),
            re.compile(r"('|(\\)|(%27)|(%5C))", re.IGNORECASE),
            re.compile(r"(;|--|/\\*)", re.IGNORECASE),
        ]
        
        # XSS patterns
        self.xss_patterns = [
            re.compile(r"<script[^>]*>.*?</script>", re.IGNORECASE | re.DOTALL),
            re.compile(r"javascript:", re.IGNORECASE),
            re.compile(r"on\w+\s*=", re.IGNORECASE),
            re.compile(r"vbscript:", re.IGNORECASE),
            re.compile(r"data:text/html", re.IGNORECASE),
        ]
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Sanitize request inputs."""
        # Check query parameters
        for key, value in request.query_params.items():
            if self._is_malicious(value):
                logger.warning("Malicious query parameter detected", 
                             key=key, value=value, client=request.client.host)
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={"detail": "Malicious input detected"}
                )
        
        # Check path parameters
        path = str(request.url.path)
        if self._is_malicious(path):
            logger.warning("Malicious path detected", path=path, client=request.client.host)
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={"detail": "Malicious input detected"}
            )
        
        return await call_next(request)
    
    def _is_malicious(self, content: str) -> bool:
        """Check if content contains malicious patterns."""
        if not isinstance(content, str):
            content = str(content)
        
        # Check SQL injection patterns
        for pattern in self.sql_injection_patterns:
            if pattern.search(content):
                return True
        
        # Check XSS patterns
        for pattern in self.xss_patterns:
            if pattern.search(content):
                return True
        
        return False


def setup_security_middleware(app: FastAPI):
    """Set up all security middleware in the correct order."""
    
    # Add security middleware (order matters!)
    app.add_middleware(RequestValidationMiddleware)
    app.add_middleware(InputSanitizationMiddleware)
    app.add_middleware(IPWhitelistMiddleware)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(JWTAuthMiddleware, whitelist_paths=[
        "/health", "/docs", "/redoc", "/openapi.json", "/metrics"
    ])
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(APIKeyAuthMiddleware, whitelist_paths=[
        "/health", "/docs", "/redoc", "/openapi.json"
    ])


class SecurityAuditLogger:
    """Security audit logging utility."""
    
    @staticmethod
    def log_auth_attempt(
        user_id: Optional[str], 
        ip_address: str, 
        user_agent: str, 
        success: bool, 
        reason: str = ""
    ):
        """Log authentication attempts."""
        logger.info(
            "Authentication attempt",
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent[:200],  # Truncate long user agents
            success=success,
            reason=reason
        )
    
    @staticmethod
    def log_security_violation(
        violation_type: str, 
        ip_address: str, 
        user_agent: str, 
        details: str
    ):
        """Log security violations."""
        logger.warning(
            "Security violation",
            violation_type=violation_type,
            ip_address=ip_address,
            user_agent=user_agent[:200],
            details=details
        )
    
    @staticmethod
    def log_permission_denied(
        user_id: str, 
        action: str, 
        resource: str, 
        ip_address: str
    ):
        """Log permission denials."""
        logger.warning(
            "Permission denied",
            user_id=user_id,
            action=action,
            resource=resource,
            ip_address=ip_address
        )


def get_security_context(request: Request) -> Dict[str, Any]:
    """Get security context from request."""
    return {
        "client_ip": request.client.host if request.client else None,
        "user_agent": request.headers.get("User-Agent"),
        "user": getattr(request.state, 'user', None),
        "api_key_valid": getattr(request.state, 'api_key_valid', False),
        "timestamp": datetime.utcnow().isoformat()
    }