"""
Rate limiting middleware for FastAPI application.

Provides comprehensive rate limiting with:
- Redis-based distributed rate limiting
- In-memory fallback for development
- Multiple rate limiting strategies
- Custom rate limit key functions
- Burst handling and sliding window
"""

import time
import asyncio
import json
from typing import Dict, Any, Optional, Callable, List, Union
from functools import wraps
from collections import defaultdict, deque
from datetime import datetime, timedelta
from enum import Enum

from fastapi import Request, HTTPException, status
from fastapi.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse, Response
from starlette.middleware.base import RequestResponseEndpoint
import structlog

from app.config import settings
from app.database import get_db

logger = structlog.get_logger(__name__)

class RateLimitStrategy(Enum):
    """Rate limiting strategies."""
    FIXED_WINDOW = "fixed_window"
    SLIDING_WINDOW = "sliding_window"
    TOKEN_BUCKET = "token_bucket"
    LEAKY_BUCKET = "leaky_bucket"

class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Comprehensive rate limiting middleware.
    
    Supports multiple rate limiting strategies:
    - Fixed Window: Simple count-based limiting
    - Sliding Window: More accurate time-based limiting
    - Token Bucket: Allows bursts up to bucket size
    - Leaky Bucket: Smooths traffic flow
    """
    
    def __init__(self, app):
        super().__init__(app)
        self.strategy = RateLimitStrategy.SLIDING_WINDOW
        self.redis_client = None
        self.memory_cache = defaultdict(deque)
        
        # Rate limit configurations
        self.configs = self._load_rate_limit_configs()
        
        # Initialize Redis client if available
        if settings.rate_limit_enabled:
            asyncio.create_task(self._initialize_redis())
        
        logger.info("Rate limiting middleware initialized", 
                   strategy=self.strategy.value,
                   redis_available=self.redis_client is not None)
    
    def _load_rate_limit_configs(self) -> Dict[str, Dict[str, Any]]:
        """Load rate limit configurations for different endpoints."""
        configs = {
            "default": {
                "requests": settings.rate_limit_requests_per_minute,
                "window": 60,
                "burst": settings.rate_limit_burst_size,
                "strategy": RateLimitStrategy.SLIDING_WINDOW
            },
            "api": {
                "requests": 1000,
                "window": 60,
                "burst": 100,
                "strategy": RateLimitStrategy.SLIDING_WINDOW
            },
            "auth": {
                "requests": 10,
                "window": 60,
                "burst": 3,
                "strategy": RateLimitStrategy.TOKEN_BUCKET
            },
            "search": {
                "requests": 50,
                "window": 60,
                "burst": 10,
                "strategy": RateLimitStrategy.SLIDING_WINDOW
            },
            "upload": {
                "requests": 20,
                "window": 60,
                "burst": 5,
                "strategy": RateLimitStrategy.TOKEN_BUCKET
            },
            "admin": {
                "requests": 100,
                "window": 60,
                "burst": 20,
                "strategy": RateLimitStrategy.LEAKY_BUCKET
            }
        }
        
        # Override with environment-specific configs
        if settings.is_development:
            configs["default"]["requests"] = 10000
            configs["auth"]["requests"] = 1000
        elif settings.is_production:
            configs["default"]["requests"] = max(10, settings.rate_limit_requests_per_minute // 2)
        
        return configs
    
    async def _initialize_redis(self):
        """Initialize Redis client for distributed rate limiting."""
        try:
            import aioredis
            
            self.redis_client = aioredis.from_url(
                settings.redis_url,
                password=settings.redis_password,
                decode_responses=True,
                socket_timeout=settings.redis_timeout,
                socket_connect_timeout=settings.redis_timeout,
                max_connections=settings.redis_max_connections
            )
            
            # Test connection
            await self.redis_client.ping()
            logger.info("Redis connection established for rate limiting")
            
        except ImportError:
            logger.warning("Redis not available, using in-memory rate limiting")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self.redis_client = None
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Apply rate limiting to request."""
        if not settings.rate_limit_enabled:
            return await call_next(request)
        
        # Get rate limit key
        rate_limit_key = self._get_rate_limit_key(request)
        
        # Determine endpoint category
        endpoint_category = self._get_endpoint_category(request.url.path)
        config = self.configs.get(endpoint_category, self.configs["default"])
        
        # Check rate limit
        allowed, remaining, reset_time = await self._check_rate_limit(
            rate_limit_key, config
        )
        
        if not allowed:
            logger.warning(
                "Rate limit exceeded",
                key=rate_limit_key,
                endpoint=endpoint_category,
                client_ip=request.client.host if request.client else "unknown",
                remaining=remaining
            )
            
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "detail": "Rate limit exceeded",
                    "type": "rate_limit_exceeded",
                    "retry_after": reset_time,
                    "limit": config["requests"],
                    "remaining": 0,
                    "reset": datetime.fromtimestamp(reset_time).isoformat()
                },
                headers={
                    "X-RateLimit-Limit": str(config["requests"]),
                    "X-RateLimit-Remaining": str(remaining),
                    "X-RateLimit-Reset": str(reset_time),
                    "Retry-After": str(reset_time),
                    "X-RateLimit-Strategy": config["strategy"].value
                }
            )
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers to response
        response.headers["X-RateLimit-Limit"] = str(config["requests"])
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(reset_time)
        response.headers["X-RateLimit-Strategy"] = config["strategy"].value
        
        return response
    
    def _get_rate_limit_key(self, request: Request) -> str:
        """Generate rate limit key for the request."""
        # Try to get user ID from authenticated user
        if hasattr(request.state, 'user') and request.state.user:
            return f"user:{request.state.user.get('id', 'anonymous')}"
        
        # Fall back to IP-based limiting
        client_ip = getattr(request.state, 'client_ip', 'unknown')
        
        # Add header to identify API clients
        if request.headers.get("X-API-Key"):
            return f"api_key:{request.headers.get('X-API-Key')[:8]}"
        
        # Add path-based isolation for some endpoints
        if any(path in request.url.path for path in ["/auth/", "/upload/"]):
            return f"ip:{client_ip}:{request.url.path.split('/')[2]}"
        
        return f"ip:{client_ip}"
    
    def _get_endpoint_category(self, path: str) -> str:
        """Determine endpoint category for rate limiting."""
        categories = {
            "auth": ["/auth/", "/login", "/register"],
            "api": ["/api/", "/v1/"],
            "search": ["/search", "/query"],
            "upload": ["/upload", "/files/"],
            "admin": ["/admin", "/manage"],
            "chat": ["/chat", "/ws"]
        }
        
        for category, patterns in categories.items():
            if any(pattern in path for pattern in patterns):
                return category
        
        return "default"
    
    async def _check_rate_limit(
        self, key: str, config: Dict[str, Any]
    ) -> tuple[bool, int, int]:
        """Check if request is within rate limit."""
        if self.redis_client and settings.rate_limit_storage == "redis":
            return await self._check_redis_rate_limit(key, config)
        else:
            return await self._check_memory_rate_limit(key, config)
    
    async def _check_redis_rate_limit(
        self, key: str, config: Dict[str, Any]
    ) -> tuple[bool, int, int]:
        """Check rate limit using Redis."""
        try:
            strategy = config["strategy"]
            requests = config["requests"]
            window = config["window"]
            
            now = int(time.time())
            
            if strategy == RateLimitStrategy.FIXED_WINDOW:
                return await self._redis_fixed_window(key, requests, window, now)
            elif strategy == RateLimitStrategy.SLIDING_WINDOW:
                return await self._redis_sliding_window(key, requests, window, now)
            elif strategy == RateLimitStrategy.TOKEN_BUCKET:
                return await self._redis_token_bucket(key, requests, config.get("burst", 10), window, now)
            else:
                return await self._redis_sliding_window(key, requests, window, now)
                
        except Exception as e:
            logger.error(f"Redis rate limit check failed: {e}")
            # Fall back to in-memory
            return await self._check_memory_rate_limit(key, config)
    
    async def _redis_fixed_window(
        self, key: str, requests: int, window: int, now: int
    ) -> tuple[bool, int, int]:
        """Fixed window rate limiting with Redis."""
        redis_key = f"rate_limit:fixed:{key}:{now // window}"
        
        pipe = self.redis_client.pipeline()
        pipe.incr(redis_key)
        pipe.expire(redis_key, window)
        results = await pipe.execute()
        
        current = results[0]
        reset_time = (now // window + 1) * window
        
        if current <= requests:
            return True, requests - current, reset_time
        else:
            return False, 0, reset_time
    
    async def _redis_sliding_window(
        self, key: str, requests: int, window: int, now: int
    ) -> tuple[bool, int, int]:
        """Sliding window rate limiting with Redis."""
        redis_key = f"rate_limit:sliding:{key}"
        
        # Remove old entries
        cutoff = now - window
        await self.redis_client.zremrangebyscore(redis_key, 0, cutoff)
        
        # Count current requests
        current = await self.redis_client.zcard(redis_key)
        reset_time = now + window
        
        if current < requests:
            # Add current request
            await self.redis_client.zadd(redis_key, {str(now): now})
            await self.redis_client.expire(redis_key, window)
            return True, requests - current - 1, reset_time
        else:
            return False, 0, reset_time
    
    async def _redis_token_bucket(
        self, key: str, rate: int, capacity: int, window: int, now: int
    ) -> tuple[bool, int, int]:
        """Token bucket rate limiting with Redis."""
        redis_key = f"rate_limit:token:{key}"
        
        # Get current tokens
        pipe = self.redis_client.pipeline()
        pipe.get(redis_key)
        pipe.ttl(redis_key)
        
        results = await pipe.execute()
        current_tokens = float(results[0]) if results[0] else float(capacity)
        ttl = results[1] if results[1] != -1 else window
        
        # Calculate tokens to add based on time passed
        if ttl < window:
            time_passed = window - ttl
            tokens_to_add = (time_passed / window) * rate
            current_tokens = min(capacity, current_tokens + tokens_to_add)
        
        # Check if we have tokens
        if current_tokens >= 1:
            current_tokens -= 1
            remaining = int(current_tokens)
            reset_time = now + window
            
            # Update Redis
            pipe = self.redis_client.pipeline()
            pipe.setex(redis_key, window, str(current_tokens))
            await pipe.execute()
            
            return True, remaining, reset_time
        else:
            reset_time = now + window
            return False, 0, reset_time
    
    async def _check_memory_rate_limit(
        self, key: str, config: Dict[str, Any]
    ) -> tuple[bool, int, int]:
        """Check rate limit using in-memory storage (development only)."""
        strategy = config["strategy"]
        requests = config["requests"]
        window = config["window"]
        
        now = time.time()
        
        if strategy == RateLimitStrategy.SLIDING_WINDOW:
            return self._memory_sliding_window(key, requests, window, now)
        else:
            # Default to sliding window for memory storage
            return self._memory_sliding_window(key, requests, window, now)
    
    def _memory_sliding_window(
        self, key: str, requests: int, window: int, now: float
    ) -> tuple[bool, int, int]:
        """In-memory sliding window rate limiting."""
        cutoff = now - window
        
        # Remove old entries and count current
        queue = self.memory_cache[key]
        while queue and queue[0] < cutoff:
            queue.popleft()
        
        current = len(queue)
        
        if current < requests:
            # Add current request
            queue.append(now)
            return True, requests - current - 1, int(now) + window
        else:
            return False, 0, int(now) + window

# Rate limiting decorators
def rate_limit(category: str = "default"):
    """
    Decorator for applying rate limiting to specific endpoints.
    
    Args:
        category: Rate limit category to use
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get request from function arguments
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            
            if not request:
                # No request found, skip rate limiting
                return await func(*args, **kwargs)
            
            # Apply rate limiting logic here (simplified)
            # In a real implementation, you'd extract the middleware logic
            
            return await func(*args, **kwargs)
        
        return wrapper
    
    return decorator

# Rate limiting utilities
async def get_rate_limit_status(
    key: str, category: str = "default"
) -> Dict[str, Any]:
    """Get current rate limit status for a key."""
    config = RateLimitMiddleware({}).configs.get(category, {})
    
    if settings.rate_limit_enabled:
        # Check current usage
        try:
            if RateLimitMiddleware._check_memory_rate_limit(key, config):
                remaining = config["requests"] - 1
            else:
                remaining = 0
        except Exception:
            remaining = config["requests"]
    else:
        remaining = config["requests"]
    
    return {
        "limit": config["requests"],
        "remaining": remaining,
        "reset": int(time.time()) + config["window"],
        "strategy": config["strategy"].value if hasattr(config["strategy"], "value") else str(config["strategy"])
    }

def setup_rate_limiting_middleware(app) -> None:
    """
    Setup rate limiting middleware for the FastAPI app.
    
    Args:
        app: FastAPI application instance
    """
    if settings.rate_limit_enabled:
        app.add_middleware(RateLimitMiddleware)
        logger.info("Rate limiting middleware configured")
    else:
        logger.info("Rate limiting is disabled")

# Rate limit configuration helpers
def configure_endpoint_limits(limits: Dict[str, Dict[str, int]]) -> None:
    """Configure custom rate limits for specific endpoints."""
    # This would update the rate limit configs
    # Implementation would depend on how you want to manage this
    logger.info("Custom endpoint limits configured", limits=list(limits.keys()))