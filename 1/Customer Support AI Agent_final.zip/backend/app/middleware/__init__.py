"""
Middleware package for FastAPI application.

This package provides comprehensive middleware components including:
- CORS configuration and policies
- Security headers and JWT authentication
- Request/response logging and monitoring
- Rate limiting with multiple strategies
- Global error handling and response standardization
"""

from .cors import setup_cors_middleware
from .security import (
    JWTAuthMiddleware,
    SecurityHeadersMiddleware,
    APIKeyAuthMiddleware,
    RequestValidationMiddleware,
    get_current_user,
    get_current_active_user,
    create_access_token,
    create_refresh_token
)
from .logging import (
    setup_logging_middleware,
    log_structured_event,
    get_request_logger
)
from .rate_limiting import (
    setup_rate_limiting_middleware,
    rate_limit
)
from .error_handling import (
    setup_global_exception_handlers,
    ErrorHandlingMiddleware,
    create_error_response,
    create_validation_error_response,
    ErrorCategory,
    ErrorSeverity
)

__all__ = [
    # CORS
    "setup_cors_middleware",
    
    # Security
    "JWTAuthMiddleware",
    "SecurityHeadersMiddleware", 
    "APIKeyAuthMiddleware",
    "RequestValidationMiddleware",
    "get_current_user",
    "get_current_active_user",
    "create_access_token",
    "create_refresh_token",
    
    # Logging
    "setup_logging_middleware",
    "log_structured_event",
    "get_request_logger",
    
    # Rate Limiting
    "setup_rate_limiting_middleware",
    "rate_limit",
    
    # Error Handling
    "setup_global_exception_handlers",
    "ErrorHandlingMiddleware",
    "create_error_response",
    "create_validation_error_response",
    "ErrorCategory",
    "ErrorSeverity"
]