"""
Application dependencies for FastAPI.

Provides comprehensive dependency injection for:
- Database sessions
- Authentication and authorization
- Rate limiting
- Health checks
- Caching
- External services
"""

import time
import asyncio
from typing import Dict, Any, Optional, List, Generator, AsyncGenerator
from functools import wraps
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

from fastapi import (
    Depends, 
    HTTPException, 
    status, 
    Request,
    Header,
    BackgroundTasks
)
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text, inspect
import aioredis
import structlog

from app.config import settings
from app.database import AsyncSessionLocal, init_db
from app.middleware.security import get_current_user, get_current_active_user, get_current_admin_user

logger = structlog.get_logger(__name__)

# Security schemes
security = HTTPBearer(auto_error=False)
api_key_security = HTTPBearer(auto_error=False)

# ==============================================================================
# DATABASE DEPENDENCIES
# ==============================================================================

async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency to get database session with proper cleanup.
    
    Yields:
        AsyncSession: Database session
        
    Raises:
        HTTPException: If database connection fails
    """
    async with AsyncSessionLocal() as session:
        try:
            # Test connection
            await session.execute(text("SELECT 1"))
            yield session
        except Exception as e:
            logger.error("Database session error", error=str(e))
            await session.rollback()
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database service unavailable"
            )
        finally:
            await session.close()

async def get_db_session_dependency() -> AsyncSession:
    """
    Simplified database dependency for dependency injection.
    
    Returns:
        AsyncSession: Database session
    """
    async for session in get_db_session():
        return session

# ==============================================================================
# AUTHENTICATION DEPENDENCIES
# ==============================================================================

async def get_current_user_optional(
    request: Request,
    authorization: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[Dict[str, Any]]:
    """
    Get current user if authenticated, return None otherwise.
    
    Args:
        request: FastAPI request object
        authorization: HTTP Bearer credentials
        
    Returns:
        Optional[Dict[str, Any]]: User info if authenticated, None otherwise
    """
    if not authorization:
        return None
    
    # Use the middleware's user from request state
    if hasattr(request.state, 'user') and request.state.user:
        return request.state.user
    
    # If middleware didn't set user, try to parse token
    try:
        from app.middleware.security import jwt
        payload = jwt.decode(
            authorization.credentials,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        user = {
            "id": payload.get("sub"),
            "email": payload.get("email"),
            "role": payload.get("role", "user"),
            "permissions": payload.get("permissions", []),
            "exp": payload.get("exp"),
            "iat": payload.get("iat")
        }
        
        return user
    except Exception as e:
        logger.warning("Failed to parse optional token", error=str(e))
        return None

async def get_current_active_user_optional(
    current_user: Optional[Dict[str, Any]] = Depends(get_current_user_optional)
) -> Optional[Dict[str, Any]]:
    """
    Get current active user if authenticated.
    
    Args:
        current_user: Current user from optional auth
        
    Returns:
        Optional[Dict[str, Any]]: Active user info
    """
    if not current_user:
        return None
    
    # Check if user is active (extend this based on your user model)
    # For now, assume all authenticated users are active
    return current_user

# ==============================================================================
# API KEY DEPENDENCIES
# ==============================================================================

async def verify_api_key(
    api_key: str = Header(..., alias="X-API-Key")
) -> Dict[str, Any]:
    """
    Verify API key for API access.
    
    Args:
        api_key: API key from header
        
    Returns:
        Dict[str, Any]: API key info
        
    Raises:
        HTTPException: If API key is invalid
    """
    if not settings.api_key:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="API key authentication not configured"
        )
    
    if api_key != settings.api_key.get_secret_value():
        logger.warning("Invalid API key provided", api_key_prefix=api_key[:8] + "...")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key"
        )
    
    return {"api_key": "valid", "type": "api_key"}

async def verify_api_key_optional(
    api_key: Optional[str] = Header(None, alias="X-API-Key")
) -> Optional[Dict[str, Any]]:
    """
    Verify API key if provided, return None otherwise.
    
    Args:
        api_key: Optional API key from header
        
    Returns:
        Optional[Dict[str, Any]]: API key info if provided and valid
    """
    if not api_key:
        return None
    
    try:
        return await verify_api_key(api_key)
    except HTTPException:
        return None

# ==============================================================================
# RATE LIMITING DEPENDENCIES
# ==============================================================================

async def get_rate_limit_key(
    request: Request,
    current_user: Optional[Dict[str, Any]] = Depends(get_current_user_optional),
    api_key_info: Optional[Dict[str, Any]] = Depends(verify_api_key_optional)
) -> str:
    """
    Generate rate limit key based on authentication context.
    
    Args:
        request: FastAPI request object
        current_user: Current authenticated user
        api_key_info: API key information
        
    Returns:
        str: Rate limit key
    """
    # User-based limiting
    if current_user:
        return f"user:{current_user['id']}"
    
    # API key-based limiting
    if api_key_info:
        return f"api_key:{api_key_info['api_key'][:8]}"
    
    # IP-based limiting
    client_ip = getattr(request.state, 'client_ip', 'unknown')
    return f"ip:{client_ip}"

async def check_rate_limit(
    rate_limit_key: str = Depends(get_rate_limit_key),
    endpoint_category: str = "default"
) -> Dict[str, Any]:
    """
    Check rate limit for the current request.
    
    Args:
        rate_limit_key: Rate limit key
        endpoint_category: Endpoint category for rate limiting
        
    Returns:
        Dict[str, Any]: Rate limit status
        
    Raises:
        HTTPException: If rate limit exceeded
    """
    if not settings.rate_limit_enabled:
        return {"allowed": True, "remaining": 999999, "reset_time": int(time.time()) + 3600}
    
    try:
        # This would integrate with the rate limiting middleware
        # For now, return a basic rate limit check
        redis_client = await get_redis_client()
        
        if redis_client:
            # Redis-based rate limiting
            key = f"rate_limit:{rate_limit_key}:{endpoint_category}"
            current = await redis_client.get(key)
            current_count = int(current) if current else 0
            
            limit = 100  # Get from config based on endpoint_category
            remaining = max(0, limit - current_count)
            
            if current_count >= limit:
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Rate limit exceeded",
                    headers={
                        "X-RateLimit-Limit": str(limit),
                        "X-RateLimit-Remaining": "0",
                        "X-RateLimit-Reset": str(int(time.time()) + 3600)
                    }
                )
            
            # Increment counter
            pipe = redis_client.pipeline()
            pipe.incr(key)
            pipe.expire(key, 3600)
            await pipe.execute()
            
            return {
                "allowed": True,
                "remaining": remaining - 1,
                "reset_time": int(time.time()) + 3600
            }
        else:
            # Fallback - allow request
            return {"allowed": True, "remaining": 50, "reset_time": int(time.time()) + 3600}
            
    except Exception as e:
        logger.error("Rate limit check failed", error=str(e))
        # Allow request on error
        return {"allowed": True, "remaining": 50, "reset_time": int(time.time()) + 3600}

# ==============================================================================
# CACHING DEPENDENCIES
# ==============================================================================

@asynccontextmanager
async def get_redis_client() -> AsyncGenerator[Optional[aioredis.Redis], None]:
    """
    Get Redis client for caching and rate limiting.
    
    Yields:
        Optional[aioredis.Redis]: Redis client instance
    """
    client = None
    try:
        if not settings.redis_url:
            yield None
            return
            
        client = aioredis.from_url(
            settings.redis_url,
            password=settings.redis_password,
            decode_responses=True,
            socket_timeout=settings.redis_timeout,
            socket_connect_timeout=settings.redis_timeout
        )
        
        # Test connection
        await client.ping()
        yield client
        
    except Exception as e:
        logger.warning("Redis connection failed", error=str(e))
        yield None
    finally:
        if client:
            await client.close()

async def get_cache(
    redis_client: Optional[aioredis.Redis] = Depends(get_redis_client)
) -> Dict[str, Any]:
    """
    Get cache instance for the current request.
    
    Args:
        redis_client: Redis client
        
    Returns:
        Dict[str, Any]: Cache interface
    """
    if not redis_client:
        # Return simple in-memory cache
        return {
            "type": "memory",
            "get": lambda key: None,
            "set": lambda key, value, expire: None,
            "delete": lambda key: None,
            "exists": lambda key: False
        }
    
    return {
        "type": "redis",
        "client": redis_client,
        "get": lambda key: redis_client.get(key),
        "set": lambda key, value, expire=3600: redis_client.setex(key, expire, value),
        "delete": lambda key: redis_client.delete(key),
        "exists": lambda key: redis_client.exists(key) > 0,
        "expire": lambda key, seconds: redis_client.expire(key, seconds)
    }

# ==============================================================================
# HEALTH CHECK DEPENDENCIES
# ==============================================================================

async def check_database_health() -> Dict[str, Any]:
    """
    Check database health status.
    
    Returns:
        Dict[str, Any]: Database health information
    """
    try:
        async with AsyncSessionLocal() as session:
            start_time = time.time()
            await session.execute(text("SELECT 1"))
            response_time = (time.time() - start_time) * 1000
            
            # Check database info
            inspector = inspect(session.get_bind())
            tables = inspector.get_table_names()
            
            return {
                "status": "healthy",
                "response_time_ms": round(response_time, 2),
                "tables_count": len(tables),
                "connection_pool_size": "N/A",  # Would get from pool info
                "last_check": datetime.utcnow().isoformat()
            }
    except Exception as e:
        logger.error("Database health check failed", error=str(e))
        return {
            "status": "unhealthy",
            "error": str(e),
            "last_check": datetime.utcnow().isoformat()
        }

async def check_redis_health() -> Dict[str, Any]:
    """
    Check Redis health status.
    
    Returns:
        Dict[str, Any]: Redis health information
    """
    try:
        async with get_redis_client() as client:
            if not client:
                return {
                    "status": "not_configured",
                    "message": "Redis not configured",
                    "last_check": datetime.utcnow().isoformat()
                }
            
            start_time = time.time()
            await client.ping()
            response_time = (time.time() - start_time) * 1000
            
            # Get Redis info
            info = await client.info()
            
            return {
                "status": "healthy",
                "response_time_ms": round(response_time, 2),
                "version": info.get("redis_version", "unknown"),
                "used_memory_human": info.get("used_memory_human", "unknown"),
                "connected_clients": info.get("connected_clients", 0),
                "last_fork_time": info.get("last_fork_time", 0),
                "last_check": datetime.utcnow().isoformat()
            }
    except Exception as e:
        logger.error("Redis health check failed", error=str(e))
        return {
            "status": "unhealthy",
            "error": str(e),
            "last_check": datetime.utcnow().isoformat()
        }

async def get_system_health() -> Dict[str, Any]:
    """
    Get comprehensive system health status.
    
    Returns:
        Dict[str, Any]: System health information
    """
    # Check all components
    db_health = await check_database_health()
    redis_health = await check_redis_health()
    
    # Determine overall status
    components_healthy = [
        db_health["status"] in ["healthy"],
        redis_health["status"] in ["healthy", "not_configured"]
    ]
    
    overall_status = "healthy" if all(components_healthy) else "unhealthy"
    
    return {
        "status": overall_status,
        "timestamp": datetime.utcnow().isoformat(),
        "version": settings.app_version,
        "environment": settings.environment,
        "components": {
            "database": db_health,
            "redis": redis_health,
            "application": {
                "status": "healthy",
                "uptime": "N/A",  # Would calculate from startup time
                "memory_usage": "N/A",  # Would get from system
                "cpu_usage": "N/A"  # Would get from system
            }
        }
    }

# ==============================================================================
# AUTHORIZATION DEPENDENCIES
# ==============================================================================

def require_permissions(permissions: List[str]):
    """
    Dependency decorator to require specific permissions.
    
    Args:
        permissions: List of required permissions
        
    Returns:
        Dependency function
    """
    async def dependency(
        current_user: Dict[str, Any] = Depends(get_current_active_user)
    ) -> Dict[str, Any]:
        user_permissions = current_user.get("permissions", [])
        user_role = current_user.get("role", "user")
        
        # Admin users have all permissions
        if user_role == "admin":
            return current_user
        
        # Check if user has all required permissions
        missing_permissions = [p for p in permissions if p not in user_permissions]
        if missing_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required: {missing_permissions}"
            )
        
        return current_user
    
    return dependency

def require_role(role: str):
    """
    Dependency decorator to require specific role.
    
    Args:
        role: Required user role
        
    Returns:
        Dependency function
    """
    async def dependency(
        current_user: Dict[str, Any] = Depends(get_current_active_user)
    ) -> Dict[str, Any]:
        user_role = current_user.get("role", "user")
        
        if user_role != role and user_role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{role}' required"
            )
        
        return current_user
    
    return dependency

# ==============================================================================
# UTILITY DEPENDENCIES
# ==============================================================================

async def get_background_tasks() -> BackgroundTasks:
    """
    Get background tasks instance for the current request.
    
    Returns:
        BackgroundTasks: Background tasks instance
    """
    # This is a placeholder - FastAPI injects BackgroundTasks automatically
    # This function can be used for documentation purposes
    pass

async def get_request_info(
    request: Request,
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
    user_agent: Optional[str] = Header(None, alias="User-Agent")
) -> Dict[str, Any]:
    """
    Get comprehensive request information.
    
    Args:
        request: FastAPI request object
        correlation_id: Request correlation ID
        user_agent: User agent string
        
    Returns:
        Dict[str, Any]: Request information
    """
    return {
        "method": request.method,
        "url": str(request.url),
        "path": request.url.path,
        "query_params": dict(request.query_params),
        "correlation_id": correlation_id or getattr(request.state, 'correlation_id', None),
        "client_ip": getattr(request.state, 'client_ip', None),
        "user_agent": user_agent,
        "content_type": request.headers.get("content-type"),
        "content_length": request.headers.get("content-length")
    }

async def validate_request_size(
    request: Request,
    max_size_mb: int = 50
) -> None:
    """
    Validate request size.
    
    Args:
        request: FastAPI request object
        max_size_mb: Maximum allowed size in MB
        
    Raises:
        HTTPException: If request size exceeds limit
    """
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            size_bytes = int(content_length)
            max_size_bytes = max_size_mb * 1024 * 1024
            
            if size_bytes > max_size_bytes:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"Request size exceeds limit of {max_size_mb}MB"
                )
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid content-length header"
            )

# ==============================================================================
# DEPENDENCY DECORATORS
# ==============================================================================

def cached_dependency(
    key_prefix: str,
    expire: int = 300,
    key_func: Optional[callable] = None
):
    """
    Decorator to cache dependency results.
    
    Args:
        key_prefix: Cache key prefix
        expire: Cache expiration in seconds
        key_func: Function to generate cache key from function arguments
        
    Returns:
        Decorated dependency function
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Generate cache key
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                # Simple key generation from function name and args
                cache_key = f"{key_prefix}:{func.__name__}:{hash(str(args) + str(sorted(kwargs.items())))}"
            
            # Get cache from request context or create simple cache
            cache = kwargs.get('cache') or {}
            
            # Check cache
            if cache_key in cache:
                return cache[cache_key]
            
            # Execute function and cache result
            result = await func(*args, **kwargs)
            cache[cache_key] = result
            
            return result
        
        return wrapper
    
    return decorator

# Export all dependencies
__all__ = [
    # Database
    "get_db_session",
    "get_db_session_dependency",
    
    # Authentication
    "get_current_user",
    "get_current_active_user",
    "get_current_user_optional",
    "get_current_active_user_optional",
    
    # API Key
    "verify_api_key",
    "verify_api_key_optional",
    
    # Rate Limiting
    "get_rate_limit_key",
    "check_rate_limit",
    
    # Caching
    "get_cache",
    "get_redis_client",
    
    # Health Checks
    "check_database_health",
    "check_redis_health",
    "get_system_health",
    
    # Authorization
    "require_permissions",
    "require_role",
    
    # Utilities
    "get_background_tasks",
    "get_request_info",
    "validate_request_size",
    
    # Decorators
    "cached_dependency"
]