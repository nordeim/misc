"""
Test file for the Customer Support Agent System.

This file provides basic tests to verify the agent system can be
properly imported and initialized.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add the backend directory to Python path
backend_path = Path(__file__).parent
sys.path.insert(0, str(backend_path))

async def test_agent_imports():
    """Test that all agent components can be imported."""
    print("Testing agent system imports...")
    
    try:
        # Test core imports
        from app.agents import (
            CustomerSupportAgent,
            AgentContext,
            AgentResponse,
            AgentConfiguration,
            AgentMetrics,
            AgentState,
            EscalationType,
            ToolExecutionStatus
        )
        print("✓ Core agent classes imported successfully")
        
        # Test factory imports
        from app.agents import (
            AgentRegistry,
            AgentConfigurationManager,
            AgentPool,
            AgentFactory,
            AgentStateManager,
            agent_factory,
            agent_state_manager
        )
        print("✓ Agent factory components imported successfully")
        
        # Test utilities imports
        from app.agents import (
            AgentMonitor,
            AgentPerformanceTracker,
            AgentResourceManager,
            AgentDiagnosticTool,
            AgentAlert,
            AlertSeverity,
            agent_monitor,
            performance_tracker,
            resource_manager,
            diagnostic_tool
        )
        print("✓ Agent utilities imported successfully")
        
        # Test monitoring imports
        from app.agents import (
            AgentMetricsCollector,
            AgentHealthChecker,
            AgentAlertManager,
            AgentMonitoringIntegration,
            agent_monitoring
        )
        print("✓ Agent monitoring components imported successfully")
        
        return True
        
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False


async def test_agent_creation():
    """Test basic agent creation."""
    print("\nTesting agent creation...")
    
    try:
        from app.agents.agent_factory import agent_factory
        
        # Create a test agent with minimal configuration
        agent = await agent_factory.create_agent(
            configuration_name="testing",
            metadata={"test": True},
            start_immediately=False  # Don't start it in test
        )
        
        print(f"✓ Agent created with ID: {agent.agent_id}")
        print(f"✓ Agent state: {agent.state.value}")
        print(f"✓ Configuration loaded: {len(agent.get_configuration().__dict__)} settings")
        
        return True
        
    except Exception as e:
        print(f"✗ Agent creation failed: {e}")
        return False


async def test_configuration_manager():
    """Test configuration management."""
    print("\nTesting configuration management...")
    
    try:
        from app.agents.agent_factory import agent_factory
        
        config_manager = agent_factory.config_manager
        configurations = config_manager.get_all_configurations()
        
        print(f"✓ Configuration manager loaded {len(configurations)} configurations")
        
        for name, config in configurations.items():
            print(f"  - {name}: {config.max_history_length} max history")
        
        return True
        
    except Exception as e:
        print(f"✗ Configuration management failed: {e}")
        return False


async def test_monitoring_components():
    """Test monitoring components."""
    print("\nTesting monitoring components...")
    
    try:
        from app.agents.agent_utils import agent_monitor, performance_tracker
        
        # Test monitoring stats
        stats = agent_monitor.get_monitoring_stats()
        print(f"✓ Monitoring stats retrieved: {len(stats)} metrics")
        
        # Test performance tracking
        performance_data = await performance_tracker.get_system_performance(hours=1)
        print(f"✓ Performance data retrieved: {performance_data.get('message', 'data available')}")
        
        return True
        
    except Exception as e:
        print(f"✗ Monitoring components test failed: {e}")
        return False


async def test_api_routes():
    """Test that API routes can be imported."""
    print("\nTesting API routes...")
    
    try:
        from app.api.routes.agents import router as agents_router
        
        print(f"✓ Agent routes imported successfully")
        print(f"✓ Routes count: {len(agents_router.routes)}")
        
        # Check for key routes
        route_paths = [route.path for route in agents_router.routes]
        expected_routes = ["/", "/pools", "/sessions", "/health", "/metrics/summary"]
        
        found_routes = 0
        for expected in expected_routes:
            for path in route_paths:
                if expected in path:
                    found_routes += 1
                    break
        
        print(f"✓ Found {found_routes}/{len(expected_routes)} expected routes")
        
        return True
        
    except Exception as e:
        print(f"✗ API routes test failed: {e}")
        return False


async def test_main_integration():
    """Test integration with main application."""
    print("\nTesting main application integration...")
    
    try:
        # This test verifies that the agent system can be integrated
        # without breaking the main application
        from app.main import app
        
        print("✓ FastAPI app loaded successfully")
        
        # Check that the API router includes agent routes
        agent_routes = [route for route in app.routes if hasattr(route, 'path') and '/agents' in route.path]
        print(f"✓ Found {len(agent_routes)} agent-related routes in main app")
        
        return True
        
    except Exception as e:
        print(f"✗ Main integration test failed: {e}")
        return False


async def run_all_tests():
    """Run all tests."""
    print("=" * 60)
    print("CUSTOMER SUPPORT AGENT SYSTEM - TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Agent Imports", test_agent_imports),
        ("Agent Creation", test_agent_creation),
        ("Configuration Management", test_configuration_manager),
        ("Monitoring Components", test_monitoring_components),
        ("API Routes", test_api_routes),
        ("Main Integration", test_main_integration),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            if result:
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"✗ {test_name} failed with exception: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("TEST RESULTS SUMMARY")
    print("=" * 60)
    print(f"Total Tests: {passed + failed}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Success Rate: {(passed / (passed + failed)) * 100:.1f}%")
    
    if failed == 0:
        print("\n🎉 ALL TESTS PASSED! Agent system is ready for use.")
    else:
        print(f"\n⚠️  {failed} tests failed. Please review the issues above.")
    
    return failed == 0


if __name__ == "__main__":
    # Run the test suite
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)