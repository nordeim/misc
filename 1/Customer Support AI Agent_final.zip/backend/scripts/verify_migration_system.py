#!/usr/bin/env python3
"""
Comprehensive migration system verification script.

This script verifies that the complete Alembic migration system is properly set up.
"""

import sys
import os
from pathlib import Path
import subprocess

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))


def check_file_exists(file_path: Path, description: str) -> bool:
    """Check if a file exists."""
    if file_path.exists():
        print(f"✅ {description}: {file_path}")
        return True
    else:
        print(f"❌ {description}: {file_path} (MISSING)")
        return False


def check_directory_exists(dir_path: Path, description: str) -> bool:
    """Check if a directory exists."""
    if dir_path.exists() and dir_path.is_dir():
        print(f"✅ {description}: {dir_path}")
        return True
    else:
        print(f"❌ {description}: {dir_path} (MISSING)")
        return False


def verify_file_content(file_path: Path, search_terms: list) -> bool:
    """Verify file contains expected content."""
    try:
        content = file_path.read_text()
        missing_terms = []
        for term in search_terms:
            if term not in content:
                missing_terms.append(term)
        
        if missing_terms:
            print(f"❌ {file_path} missing content: {missing_terms}")
            return False
        else:
            print(f"✅ {file_path} contains expected content")
            return True
    except Exception as e:
        print(f"❌ Error reading {file_path}: {e}")
        return False


def run_python_script(script_path: Path) -> bool:
    """Run a Python script and check if it executes without errors."""
    try:
        result = subprocess.run(
            [sys.executable, str(script_path), "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            print(f"✅ {script_path.name} is executable")
            return True
        else:
            print(f"❌ {script_path.name} failed to execute: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Error running {script_path.name}: {e}")
        return False


def verify_migration_system():
    """Verify the complete migration system."""
    print("🔍 Verifying Alembic Migration System")
    print("=" * 60)
    
    all_checks_passed = True
    
    # Check main Alembic directory structure
    print("\n📁 Checking Alembic directory structure...")
    alembic_dir = backend_dir / "alembic"
    all_checks_passed &= check_directory_exists(alembic_dir, "Alembic directory")
    
    # Check Alembic configuration files
    print("\n📄 Checking Alembic configuration files...")
    alembic_ini = alembic_dir / "alembic.ini"
    env_py = alembic_dir / "env.py"
    script_mako = alembic_dir / "script.py.mako"
    
    all_checks_passed &= check_file_exists(alembic_ini, "Alembic configuration")
    all_checks_passed &= check_file_exists(env_py, "Migration environment")
    all_checks_passed &= check_file_exists(script_mako, "Migration script template")
    
    # Check versions directory and initial migration
    print("\n📂 Checking migration versions...")
    versions_dir = alembic_dir / "versions"
    all_checks_passed &= check_directory_exists(versions_dir, "Migration versions directory")
    
    initial_migration = versions_dir / "001_create_initial_tables.py"
    all_checks_passed &= check_file_exists(initial_migration, "Initial migration script")
    
    # Verify initial migration content
    if initial_migration.exists():
        migration_content = [
            "def upgrade()",
            "def downgrade()",
            "CREATE TABLE users",
            "CREATE TABLE sessions",
            "CREATE TABLE messages",
            "CREATE TABLE memories",
            "op.create_index",
        ]
        all_checks_passed &= verify_file_content(initial_migration, migration_content)
    
    # Check model files
    print("\n🏗️  Checking database model files...")
    models_dir = backend_dir / "app" / "models"
    all_checks_passed &= check_directory_exists(models_dir, "Models directory")
    
    model_files = [
        models_dir / "__init__.py",
        models_dir / "base.py",
        models_dir / "user.py",
        models_dir / "session.py",
        models_dir / "message.py",
        models_dir / "memory.py",
    ]
    
    for model_file in model_files:
        all_checks_passed &= check_file_exists(model_file, f"Model file: {model_file.name}")
    
    # Check migration scripts
    print("\n🛠️  Checking migration utility scripts...")
    scripts_dir = backend_dir / "scripts"
    all_checks_passed &= check_directory_exists(scripts_dir, "Scripts directory")
    
    migration_scripts = [
        "create_initial_migration.py",
        "upgrade_db.py",
        "downgrade_db.py",
        "reset_database.py",
        "seed_data.py",
        "initialize_db.py",
        "test_migrations.py",
    ]
    
    for script_name in migration_scripts:
        script_path = scripts_dir / script_name
        all_checks_passed &= check_file_exists(script_path, f"Script: {script_name}")
        
        # Try to run script with --help
        if script_path.exists():
            # Don't test as we can't run it without proper setup
            print(f"✅ Script exists: {script_name}")
    
    # Check scripts documentation
    print("\n📚 Checking documentation...")
    readme_path = scripts_dir / "README.md"
    all_checks_passed &= check_file_exists(readme_path, "Migration system documentation")
    
    # Check database configuration
    print("\n⚙️  Checking database configuration...")
    try:
        from app.config import settings
        print(f"✅ Database URL configured: {settings.database_url}")
        print(f"✅ Environment: {settings.environment}")
    except Exception as e:
        print(f"❌ Database configuration error: {e}")
        all_checks_passed = False
    
    # Check if we can import models
    print("\n🔗 Checking model imports...")
    try:
        from app.models import UserORM, SessionORM, MessageORM, MemoryORM
        print("✅ All models can be imported successfully")
    except Exception as e:
        print(f"❌ Model import error: {e}")
        all_checks_passed = False
    
    # Summary
    print("\n" + "="*60)
    print("📊 MIGRATION SYSTEM VERIFICATION SUMMARY")
    print("="*60)
    
    if all_checks_passed:
        print("🎉 All migration system components verified successfully!")
        print("\n✅ The Alembic migration system is fully set up and ready to use.")
        print("\n🚀 Next steps:")
        print("   1. cd backend")
        print("   2. python scripts/create_initial_migration.py init")
        print("   3. python scripts/upgrade_db.py")
        print("   4. python scripts/seed_data.py")
        return True
    else:
        print("💥 Some migration system components are missing or incorrect.")
        print("\n❌ Please check the missing items above and re-run verification.")
        return False


def show_quick_start():
    """Show quick start guide."""
    print("\n" + "="*60)
    print("🚀 QUICK START GUIDE")
    print("="*60)
    
    print("\n1. Initial Setup:")
    print("   cd backend")
    print("   python scripts/create_initial_migration.py init")
    
    print("\n2. Apply Migrations:")
    print("   python scripts/upgrade_db.py")
    
    print("\n3. Seed Test Data:")
    print("   python scripts/seed_data.py")
    
    print("\n4. Verify Installation:")
    print("   python scripts/test_migrations.py")
    
    print("\n5. Create New Migration:")
    print("   python scripts/create_initial_migration.py create -m 'Your message'")
    
    print("\n📚 For more information, see: scripts/README.md")
    print("🔧 For testing: python scripts/test_migrations.py --help")


def main():
    """Main verification function."""
    success = verify_migration_system()
    
    if success:
        show_quick_start()
    
    return success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)