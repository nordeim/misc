#!/usr/bin/env python3
"""
Migration testing script.

This script tests migration operations, data integrity, and rollback procedures.
"""

import sys
import os
import argparse
import tempfile
import shutil
from pathlib import Path
from datetime import datetime

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from alembic.config import Config
from alembic import command

from app.models import UserORM, SessionORM, MessageORM, MemoryORM
from app.config import settings


class MigrationTestSuite:
    """Comprehensive migration testing suite."""
    
    def __init__(self, test_db_path: str = None):
        self.backend_dir = backend_dir
        self.test_db_path = test_db_path or ":memory:"
        self.alembic_cfg = None
        self.test_results = []
    
    def setup_test_environment(self):
        """Set up isolated test environment."""
        print("🔧 Setting up test environment...")
        
        # Create test database
        self.database_url = f"sqlite:///{self.test_db_path}"
        
        # Create Alembic configuration
        self.alembic_cfg = Config()
        self.alembic_cfg.set_main_option("script_location", str(self.backend_dir / "alembic"))
        self.alembic_cfg.set_main_option("sqlalchemy.url", self.database_url)
        
        print(f"✅ Test environment setup completed")
        return True
    
    def test_migration_upgrade(self):
        """Test migration upgrade operations."""
        print("\n🔄 Testing migration upgrade...")
        
        try:
            # Get initial revision
            initial_revision = command.current(self.alembic_cfg)
            print(f"Initial revision: {initial_revision}")
            
            # Perform upgrade
            command.upgrade(self.alembic_cfg, "head", verbose=True)
            
            # Verify upgrade
            final_revision = command.current(self.alembic_cfg)
            print(f"Final revision: {final_revision}")
            
            # Check that all tables exist
            engine = create_engine(self.database_url)
            with engine.connect() as conn:
                # Test tables exist
                tables = ['users', 'sessions', 'messages', 'memories']
                for table in tables:
                    result = conn.execute(text(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'"))
                    if not result.fetchone():
                        raise Exception(f"Table {table} not created")
                    print(f"✅ Table {table} exists")
            
            self.test_results.append(("Migration Upgrade", True, "All migrations applied successfully"))
            return True
            
        except Exception as e:
            self.test_results.append(("Migration Upgrade", False, str(e)))
            print(f"❌ Migration upgrade failed: {e}")
            return False
    
    def test_data_integrity(self):
        """Test data integrity after migrations."""
        print("\n🔍 Testing data integrity...")
        
        try:
            engine = create_engine(self.database_url)
            
            # Test 1: Foreign key constraints
            with engine.connect() as conn:
                # Try to insert invalid foreign key
                try:
                    conn.execute(text("INSERT INTO sessions (id, user_id, title, status, session_type, message_count, token_count, created_at, updated_at) VALUES ('test', 'nonexistent', 'test', 'active', 'test', 0, 0, datetime('now'), datetime('now'))"))
                    raise Exception("Foreign key constraint not working")
                except Exception as e:
                    if "FOREIGN KEY" in str(e).upper():
                        print("✅ Foreign key constraints working")
                    else:
                        raise e
            
            # Test 2: Unique constraints
            with engine.connect() as conn:
                try:
                    conn.execute(text("""
                        INSERT INTO users (id, email, username, hashed_password, is_active, is_verified, is_superuser, login_count, timezone, language, created_at, updated_at, is_deleted) 
                        VALUES ('test1', 'test@example.com', 'testuser', 'hash', true, true, false, 0, 'UTC', 'en', datetime('now'), datetime('now'), false)
                    """))
                    conn.execute(text("""
                        INSERT INTO users (id, email, username, hashed_password, is_active, is_verified, is_superuser, login_count, timezone, language, created_at, updated_at, is_deleted) 
                        VALUES ('test2', 'test@example.com', 'testuser2', 'hash', true, true, false, 0, 'UTC', 'en', datetime('now'), datetime('now'), false)
                    """))
                    raise Exception("Unique constraint not working")
                except Exception as e:
                    if "UNIQUE" in str(e).upper() or "unique" in str(e).lower():
                        print("✅ Unique constraints working")
                    else:
                        raise e
            
            # Test 3: Data types
            with engine.connect() as conn:
                # Test float precision
                conn.execute(text("""
                    INSERT INTO memories (id, session_id, key, value, memory_type, importance_score, confidence_score, access_count, created_at, updated_at, is_deleted)
                    VALUES ('test', 'test', 'key', 'value', 'test', 0.123456789, 0.987654321, 0, datetime('now'), datetime('now'), false)
                """))
                
                result = conn.execute(text("SELECT importance_score, confidence_score FROM memories WHERE id='test'"))
                row = result.fetchone()
                if row:
                    print(f"✅ Float precision maintained: {row}")
            
            self.test_results.append(("Data Integrity", True, "All data integrity tests passed"))
            return True
            
        except Exception as e:
            self.test_results.append(("Data Integrity", False, str(e)))
            print(f"❌ Data integrity test failed: {e}")
            return False
    
    def test_rollback_procedures(self):
        """Test rollback/migration downgrade procedures."""
        print("\n↩️  Testing rollback procedures...")
        
        try:
            # Get current revision
            current_revision = command.current(self.alembic_cfg)
            print(f"Current revision before rollback: {current_revision}")
            
            # Perform downgrade
            command.downgrade(self.alembic_cfg, "-1", verbose=True)
            
            # Verify downgrade
            new_revision = command.current(self.alembic_cfg)
            print(f"New revision after rollback: {new_revision}")
            
            # Test that rollback worked
            if new_revision != current_revision:
                print("✅ Rollback completed successfully")
            else:
                raise Exception("Rollback did not change revision")
            
            # Perform upgrade again to verify idempotency
            command.upgrade(self.alembic_cfg, "head", verbose=True)
            final_revision = command.current(self.alembic_cfg)
            
            if final_revision == current_revision:
                print("✅ Upgrade after rollback works correctly")
            else:
                raise Exception("Migration state inconsistent after rollback")
            
            self.test_results.append(("Rollback Procedures", True, "Rollback and recovery tested successfully"))
            return True
            
        except Exception as e:
            self.test_results.append(("Rollback Procedures", False, str(e)))
            print(f"❌ Rollback test failed: {e}")
            return False
    
    def test_performance_indexes(self):
        """Test performance of database indexes."""
        print("\n⚡ Testing performance indexes...")
        
        try:
            engine = create_engine(self.database_url)
            
            # Create test data
            with sessionmaker(bind=engine)() as session:
                # Create test user
                user = UserORM(
                    email="perf_test@example.com",
                    username="perf_test",
                    hashed_password="hash",
                    is_active=True,
                    is_verified=True,
                    is_superuser=False,
                    timezone="UTC",
                    language="en"
                )
                session.add(user)
                session.flush()
                
                # Create multiple sessions for testing indexes
                for i in range(100):
                    session_obj = SessionORM(
                        user_id=user.id,
                        title=f"Test Session {i}",
                        status=random.choice(["active", "closed", "archived"]),
                        session_type="test",
                        message_count=i,
                        token_count=i * 100
                    )
                    session.add(session_obj)
                
                session.commit()
            
            # Test query performance
            with sessionmaker(bind=engine)() as session:
                start_time = datetime.now()
                
                # Test indexed queries
                result = session.query(SessionORM).filter(
                    SessionORM.user_id == user.id,
                    SessionORM.status == "active"
                ).all()
                
                end_time = datetime.now()
                query_time = (end_time - start_time).total_seconds()
                
                print(f"✅ Indexed query completed in {query_time:.4f} seconds")
                print(f"   Found {len(result)} results")
                
                if query_time > 1.0:
                    print("⚠️  Query performance might be slow")
            
            self.test_results.append(("Performance Indexes", True, "Index performance acceptable"))
            return True
            
        except Exception as e:
            self.test_results.append(("Performance Indexes", False, str(e)))
            print(f"❌ Performance test failed: {e}")
            return False
    
    def test_migration_idempotency(self):
        """Test that migrations can be run multiple times safely."""
        print("\n🔄 Testing migration idempotency...")
        
        try:
            # Run upgrade twice
            command.upgrade(self.alembic_cfg, "head")
            revision1 = command.current(self.alembic_cfg)
            
            command.upgrade(self.alembic_cfg, "head")
            revision2 = command.current(self.alembic_cfg)
            
            if revision1 == revision2:
                print("✅ Migration idempotency verified")
            else:
                raise Exception("Migrations are not idempotent")
            
            self.test_results.append(("Migration Idempotency", True, "Migrations can be safely rerun"))
            return True
            
        except Exception as e:
            self.test_results.append(("Migration Idempotency", False, str(e)))
            print(f"❌ Idempotency test failed: {e}")
            return False
    
    def run_all_tests(self):
        """Run all migration tests."""
        print("🧪 Running comprehensive migration tests...")
        print("=" * 60)
        
        # Setup
        if not self.setup_test_environment():
            return False
        
        tests = [
            self.test_migration_upgrade,
            self.test_data_integrity,
            self.test_rollback_procedures,
            self.test_performance_indexes,
            self.test_migration_idempotency,
        ]
        
        for test_func in tests:
            try:
                test_func()
            except Exception as e:
                print(f"❌ Test {test_func.__name__} failed with exception: {e}")
        
        return self.print_test_summary()
    
    def print_test_summary(self):
        """Print summary of all test results."""
        print("\n" + "="*60)
        print("📊 MIGRATION TEST SUMMARY")
        print("="*60)
        
        passed = 0
        failed = 0
        
        for test_name, success, message in self.test_results:
            status = "✅ PASS" if success else "❌ FAIL"
            print(f"{status} {test_name}: {message}")
            
            if success:
                passed += 1
            else:
                failed += 1
        
        print(f"\nTotal Tests: {len(self.test_results)}")
        print(f"Passed: {passed}")
        print(f"Failed: {failed}")
        
        if failed == 0:
            print("\n🎉 All migration tests passed!")
            return True
        else:
            print(f"\n💥 {failed} migration tests failed!")
            return False


def run_test_suite():
    """Run the migration test suite."""
    parser = argparse.ArgumentParser(description="Test migration procedures")
    parser.add_argument("--db-path", help="Path to test database")
    parser.add_argument("--test", choices=[
        "upgrade", "integrity", "rollback", "performance", "idempotency", "all"
    ], default="all", help="Specific test to run")
    
    args = parser.parse_args()
    
    # Create test database
    if args.db_path:
        test_db_path = args.db_path
    else:
        test_db_path = backend_dir / "data" / "test_migrations.db"
        # Clean up any existing test database
        if test_db_path.exists():
            test_db_path.unlink()
    
    # Run tests
    test_suite = MigrationTestSuite(str(test_db_path))
    
    try:
        if args.test == "all":
            success = test_suite.run_all_tests()
        else:
            test_suite.setup_test_environment()
            
            if args.test == "upgrade":
                success = test_suite.test_migration_upgrade()
            elif args.test == "integrity":
                success = test_suite.test_data_integrity()
            elif args.test == "rollback":
                success = test_suite.test_rollback_procedures()
            elif args.test == "performance":
                success = test_suite.test_performance_indexes()
            elif args.test == "idempotency":
                success = test_suite.test_migration_idempotency()
        
        return success
        
    finally:
        # Clean up test database
        if test_db_path and test_db_path.exists():
            test_db_path.unlink()
            print(f"🧹 Cleaned up test database: {test_db_path}")


if __name__ == "__main__":
    import random
    
    success = run_test_suite()
    sys.exit(0 if success else 1)