#!/usr/bin/env python3
"""
Script to initialize the database for production.

This script sets up the database schema, creates initial users, and prepares the system for production use.
"""

import sys
import os
import argparse
from pathlib import Path
import getpass

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from alembic.config import Config
from alembic import command

from app.models import UserORM, SessionORM, MessageORM, MemoryORM
from app.config import settings


def setup_database_schema():
    """Set up the database schema by running migrations."""
    print("🔧 Setting up database schema...")
    
    # Create Alembic configuration
    alembic_cfg = Config()
    alembic_cfg.set_main_option("script_location", str(backend_dir / "alembic"))
    
    # Override database URL from settings
    if hasattr(settings, 'database_url') and settings.database_url:
        sync_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
        alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    
    try:
        # Check current revision
        current_revision = command.current(alembic_cfg)
        
        if current_revision:
            print(f"Current revision: {current_revision}")
            upgrade_choice = input("Schema already exists. Upgrade to latest? (y/n): ")
            if upgrade_choice.lower() != 'y':
                print("Skipping schema upgrade.")
                return True
        
        # Upgrade to head
        print("Applying migrations...")
        command.upgrade(alembic_cfg, "head", verbose=True)
        
        print("✅ Database schema setup completed!")
        return True
        
    except Exception as e:
        print(f"❌ Failed to setup database schema: {e}")
        return False


def create_initial_admin_user():
    """Create the initial admin user."""
    print("👤 Creating initial admin user...")
    
    database_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
    engine = create_engine(database_url)
    
    with sessionmaker(bind=engine)() as session:
        try:
            # Check if admin user already exists
            existing_admin = session.query(UserORM).filter(UserORM.is_superuser == True).first()
            if existing_admin:
                print(f"ℹ️  Admin user already exists: {existing_admin.email}")
                return True
            
            # Get admin user details
            print("Creating admin user...")
            print("Please provide the following information:")
            
            email = input("Admin email: ").strip()
            if not email:
                print("❌ Email is required")
                return False
            
            username = input("Admin username: ").strip() or "admin"
            
            password = getpass.getpass("Admin password: ")
            if not password or len(password) < 8:
                print("❌ Password must be at least 8 characters")
                return False
            
            confirm_password = getpass.getpass("Confirm password: ")
            if password != confirm_password:
                print("❌ Passwords do not match")
                return False
            
            full_name = input("Full name (optional): ").strip() or "System Administrator"
            
            # Hash password (simple implementation - in production, use proper password hashing)
            from bcrypt import hashpw, gensalt
            hashed_password = hashpw(password.encode('utf-8'), gensalt()).decode('utf-8')
            
            # Create admin user
            admin_user = UserORM(
                email=email,
                username=username,
                full_name=full_name,
                hashed_password=hashed_password,
                is_active=True,
                is_verified=True,
                is_superuser=True,
                timezone="UTC",
                language="en"
            )
            
            session.add(admin_user)
            session.commit()
            
            print("✅ Admin user created successfully!")
            print(f"   Email: {email}")
            print(f"   Username: {username}")
            
            return True
            
        except Exception as e:
            session.rollback()
            print(f"❌ Failed to create admin user: {e}")
            return False


def validate_database_connection():
    """Validate database connection and schema."""
    print("🔍 Validating database connection...")
    
    try:
        database_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
        engine = create_engine(database_url)
        
        # Test connection
        with engine.connect() as conn:
            result = conn.execute("SELECT 1")
            result.fetchone()
        
        print("✅ Database connection successful")
        
        # Check if tables exist
        with sessionmaker(bind=engine)() as session:
            tables = ['users', 'sessions', 'messages', 'memories']
            missing_tables = []
            
            for table in tables:
                try:
                    session.query(UserORM if table == 'users' else
                                SessionORM if table == 'sessions' else
                                MessageORM if table == 'messages' else
                                MemoryORM).limit(1).all()
                    print(f"✅ Table '{table}' exists")
                except Exception:
                    print(f"❌ Table '{table}' missing")
                    missing_tables.append(table)
            
            if missing_tables:
                print(f"\n⚠️  Missing tables: {', '.join(missing_tables)}")
                print("Run the database setup again to create the schema.")
                return False
            
        print("✅ All database tables are present and accessible")
        return True
        
    except Exception as e:
        print(f"❌ Database validation failed: {e}")
        return False


def create_indexes():
    """Create additional performance indexes if needed."""
    print("📈 Creating performance indexes...")
    
    try:
        database_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
        engine = create_engine(database_url)
        
        with engine.connect() as conn:
            # Create additional indexes for performance
            additional_indexes = [
                "CREATE INDEX IF NOT EXISTS idx_messages_session_created ON messages (session_id, created_at)",
                "CREATE INDEX IF NOT EXISTS idx_memories_importance_session ON memories (importance_score, session_id)",
                "CREATE INDEX IF NOT EXISTS idx_sessions_user_active ON sessions (user_id, status)",
            ]
            
            for index_sql in additional_indexes:
                try:
                    conn.execute(index_sql)
                    print(f"✅ Created index: {index_sql.split()[-1]}")
                except Exception as e:
                    print(f"⚠️  Failed to create index: {e}")
        
        print("✅ Performance indexes setup completed")
        return True
        
    except Exception as e:
        print(f"❌ Failed to create indexes: {e}")
        return False


def check_environment():
    """Check environment configuration."""
    print("🌍 Checking environment configuration...")
    
    issues = []
    
    # Check database URL
    if not hasattr(settings, 'database_url') or not settings.database_url:
        issues.append("Database URL not configured")
    
    # Check secret key
    if hasattr(settings, 'secret_key') and settings.secret_key:
        secret_value = settings.secret_key.get_secret_value()
        if len(secret_value) < 32:
            issues.append("Secret key should be at least 32 characters for production")
    else:
        issues.append("Secret key not configured")
    
    # Check if in production environment
    if hasattr(settings, 'environment'):
        if settings.environment == 'production':
            print("⚠️  Running in PRODUCTION environment")
            if not hasattr(settings, 'ssl_enabled') or not settings.ssl_enabled:
                issues.append("SSL should be enabled in production")
            
            if "sqlite" in settings.database_url.lower():
                issues.append("Production should use PostgreSQL, not SQLite")
    
    if issues:
        print("\n⚠️  Configuration issues found:")
        for issue in issues:
            print(f"   - {issue}")
        return False
    else:
        print("✅ Environment configuration looks good")
        return True


def initialize_production_database(force=False):
    """Initialize the database for production use."""
    print("🚀 Initializing database for production...")
    print("=" * 60)
    
    if settings.environment == 'development':
        print("⚠️  WARNING: You are initializing production database in DEVELOPMENT mode")
        if not force:
            response = input("Continue? (y/n): ")
            if response.lower() != 'y':
                print("Initialization cancelled")
                return False
    
    steps = [
        ("Check environment", check_environment),
        ("Validate database connection", validate_database_connection),
        ("Setup database schema", setup_database_schema),
        ("Create performance indexes", create_indexes),
        ("Create initial admin user", create_initial_admin_user),
        ("Final validation", validate_database_connection),
    ]
    
    for step_name, step_func in steps:
        print(f"\n{'='*20} {step_name} {'='*20}")
        
        try:
            if not step_func():
                print(f"\n❌ Failed at step: {step_name}")
                return False
        except Exception as e:
            print(f"\n❌ Exception during {step_name}: {e}")
            return False
    
    print("\n🎉 Database initialization completed successfully!")
    print("\n📋 Next steps:")
    print("   1. Configure your web server and SSL certificates")
    print("   2. Set up monitoring and logging")
    print("   3. Configure backup procedures")
    print("   4. Test your application")
    
    return True


def main():
    """Main function."""
    parser = argparse.ArgumentParser(
        description="Initialize database for production",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This script will:
1. Check environment configuration
2. Validate database connection
3. Run migrations to create database schema
4. Create additional performance indexes
5. Create initial admin user
6. Perform final validation

Make sure your database is accessible and migrations are configured.
        """
    )
    
    parser.add_argument("--force", "-f", action="store_true",
                       help="Skip confirmation prompts and safety checks")
    
    args = parser.parse_args()
    
    success = initialize_production_database(args.force)
    
    if success:
        print("\n✅ Database initialization completed successfully!")
        return True
    else:
        print("\n💥 Database initialization failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)