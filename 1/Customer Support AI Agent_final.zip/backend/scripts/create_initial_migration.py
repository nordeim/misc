#!/usr/bin/env python3
"""
Script to create and manage initial migrations.

This script handles creating the initial database schema and managing migrations.
"""

import sys
import os
import subprocess
import argparse
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from app.config import settings


def run_command(cmd: list, check: bool = True) -> subprocess.CompletedProcess:
    """Run a shell command."""
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, check=check)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    return result


def create_initial_migration():
    """Create the initial migration for the database."""
    print("Creating initial migration...")
    
    # Change to backend directory
    os.chdir(backend_dir)
    
    # Create initial migration
    cmd = [
        "alembic", "revision", "--autogenerate", 
        "-m", "Create initial database tables"
    ]
    
    try:
        run_command(cmd)
        print("✅ Initial migration created successfully!")
        
        # List migrations
        list_migrations()
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to create initial migration: {e}")
        return False
    
    return True


def apply_migrations():
    """Apply all pending migrations."""
    print("Applying migrations...")
    
    os.chdir(backend_dir)
    cmd = ["alembic", "upgrade", "head"]
    
    try:
        run_command(cmd)
        print("✅ All migrations applied successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to apply migrations: {e}")
        return False


def show_current_revision():
    """Show current database revision."""
    print("Current database revision:")
    
    os.chdir(backend_dir)
    cmd = ["alembic", "current"]
    
    try:
        result = run_command(cmd, check=False)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ Failed to get current revision: {e}")
        return False


def list_migrations():
    """List all migrations."""
    print("Database migrations:")
    
    os.chdir(backend_dir)
    cmd = ["alembic", "history", "--verbose"]
    
    try:
        run_command(cmd, check=False)
        return True
    except Exception as e:
        print(f"❌ Failed to list migrations: {e}")
        return False


def downgrade(revision: str = "-1"):
    """Downgrade to a specific revision."""
    print(f"Downgrading to revision: {revision}")
    
    os.chdir(backend_dir)
    cmd = ["alembic", "downgrade", revision]
    
    try:
        run_command(cmd)
        print("✅ Database downgraded successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to downgrade: {e}")
        return False


def create_migration(message: str):
    """Create a new migration with the given message."""
    print(f"Creating migration: {message}")
    
    os.chdir(backend_dir)
    cmd = ["alembic", "revision", "--autogenerate", "-m", message]
    
    try:
        run_command(cmd)
        print("✅ Migration created successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to create migration: {e}")
        return False


def main():
    """Main function to handle command line arguments."""
    parser = argparse.ArgumentParser(description="Database migration management script")
    
    parser.add_argument("command", choices=[
        "init", "migrate", "downgrade", "current", "history", 
        "create", "reset"
    ], help="Migration command to execute")
    
    parser.add_argument("--message", "-m", help="Migration message (for create command)")
    parser.add_argument("--revision", "-r", default="-1", help="Revision for downgrade command")
    
    args = parser.parse_args()
    
    print("🚀 Database Migration Manager")
    print("=" * 40)
    
    success = True
    
    if args.command == "init":
        success = create_initial_migration()
    elif args.command == "migrate":
        success = apply_migrations()
    elif args.command == "downgrade":
        success = downgrade(args.revision)
    elif args.command == "current":
        success = show_current_revision()
    elif args.command == "history":
        success = list_migrations()
    elif args.command == "create":
        if not args.message:
            print("❌ Error: --message is required for create command")
            return False
        success = create_migration(args.message)
    elif args.command == "reset":
        print("⚠️  WARNING: This will delete ALL data in the database!")
        confirm = input("Are you sure you want to reset the database? (yes/no): ")
        if confirm.lower() == "yes":
            success = downgrade("base")
        else:
            print("Reset cancelled.")
            success = True
    
    if success:
        print("\n✅ Migration command completed successfully!")
        return True
    else:
        print("\n❌ Migration command failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)