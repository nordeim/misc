# Database Migration System

This directory contains a comprehensive database migration system for the Customer Support AI Agent backend application using Alembic.

## Overview

The migration system provides:

- **Complete Database Schema Management**: Version-controlled database schema changes
- **Automated Migration Scripts**: Tools to create, apply, and rollback migrations
- **Database Seeding**: Test data and production initialization scripts
- **Comprehensive Testing**: Migration validation and rollback testing
- **Safe Operations**: Confirmation prompts and backup functionality

## Directory Structure

```
scripts/
├── README.md                  # This file
├── create_initial_migration.py  # Migration management tool
├── upgrade_db.py              # Database upgrade script
├── downgrade_db.py            # Database downgrade script
├── reset_database.py          # Complete database reset
├── seed_data.py               # Test data seeding
├── initialize_db.py           # Production initialization
└── test_migrations.py         # Migration testing suite
```

## Quick Start

### 1. Initial Setup

```bash
# Make scripts executable
chmod +x scripts/*.py

# Create initial migration
cd backend
python scripts/create_initial_migration.py init

# Apply migrations
python scripts/upgrade_db.py
```

### 2. Development Workflow

```bash
# Create new migration
python scripts/create_initial_migration.py create -m "Add new field to users"

# Apply migrations
python scripts/upgrade_db.py

# Check migration status
python scripts/create_initial_migration.py current

# View migration history
python scripts/create_initial_migration.py history
```

### 3. Seeding Test Data

```bash
# Seed database with test data
python scripts/seed_data.py

# Force seed (override existing data)
python scripts/seed_data.py --force
```

## Migration Management

### Available Commands

#### `create_initial_migration.py`

Main migration management tool with the following commands:

```bash
# Create initial migration
python scripts/create_initial_migration.py init

# Apply all pending migrations
python scripts/create_initial_migration.py migrate

# Create new migration with message
python scripts/create_initial_migration.py create -m "Your migration message"

# Show current revision
python scripts/create_initial_migration.py current

# Show migration history
python scripts/create_initial_migration.py history

# Downgrade to specific revision
python scripts/create_initial_migration.py downgrade -r -1

# Reset database (delete all data!)
python scripts/create_initial_migration.py reset
```

#### `upgrade_db.py`

Simple script to upgrade database to latest revision:

```bash
python scripts/upgrade_db.py
```

#### `downgrade_db.py`

Rollback database to previous revision:

```bash
# Downgrade to previous revision
python scripts/downgrade_db.py

# Downgrade to specific revision
python scripts/downgrade_db.py -r 001

# Force downgrade without confirmation
python scripts/downgrade_db.py --force
```

#### `reset_database.py`

Dangerous script that completely resets the database:

```bash
# Interactive reset with backup
python scripts/reset_database.py

# Force reset (skips confirmation)
python scripts/reset_database.py --force

# Reset without backup
python scripts/reset_database.py --no-backup

# Clean migration files
python scripts/reset_database.py --clean-migrations
```

## Database Seeding

### Test Data (`seed_data.py`)

Creates realistic test data for development and testing:

```bash
# Seed database with default test data
python scripts/seed_data.py

# Create specific number of test users
python scripts/seed_data.py --users 5

# Force seed (override existing data)
python scripts/seed_data.py --force
```

**Test Account Credentials:**
- `admin@example.com` / `admin123` (Admin user)
- `test@example.com` / `test123` (Regular user)
- `demo@example.com` / `demo123` (Demo user)

### Production Initialization (`initialize_db.py`)

Sets up production database with admin user:

```bash
# Interactive production initialization
python scripts/initialize_db.py

# Force initialization (skip prompts)
python scripts/initialize_db.py --force
```

The initialization process:
1. Checks environment configuration
2. Validates database connection
3. Applies migrations
4. Creates performance indexes
5. Creates initial admin user
6. Performs final validation

## Migration Testing

### Test Suite (`test_migration.py`)

Comprehensive testing of migration operations:

```bash
# Run all migration tests
python scripts/test_migrations.py

# Run specific test
python scripts/test_migrations.py --test upgrade
python scripts/test_migrations.py --test integrity
python scripts/test_migrations.py --test rollback
python scripts/test_migrations.py --test performance
python scripts/test_migrations.py --test idempotency

# Use custom test database
python scripts/test_migrations.py --db-path /path/to/test.db
```

**Test Coverage:**
- ✅ Migration upgrade operations
- ✅ Data integrity constraints
- ✅ Rollback and recovery procedures
- ✅ Performance index validation
- ✅ Migration idempotency

## Database Schema

The system creates the following tables:

### Users Table
```sql
CREATE TABLE users (
    id VARCHAR PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    hashed_password VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    is_superuser BOOLEAN NOT NULL DEFAULT FALSE,
    avatar_url VARCHAR(500),
    bio TEXT,
    timezone VARCHAR(50) NOT NULL DEFAULT 'UTC',
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    login_count INTEGER NOT NULL DEFAULT 0,
    last_login TIMESTAMP,
    last_login_ip VARCHAR(45),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at TIMESTAMP
);
```

### Sessions Table
```sql
CREATE TABLE sessions (
    id VARCHAR PRIMARY KEY,
    user_id VARCHAR NOT NULL,
    title VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    session_type VARCHAR(50) NOT NULL DEFAULT 'chat',
    model_name VARCHAR(100),
    provider VARCHAR(50),
    model_config JSON,
    metadata JSON,
    tags JSON,
    message_count INTEGER NOT NULL DEFAULT 0,
    token_count INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMP NOT NULL,
    ended_at TIMESTAMP,
    last_activity TIMESTAMP NOT NULL,
    user_feedback VARCHAR(50),
    rating INTEGER,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE (user_id, title)
);
```

### Messages Table
```sql
CREATE TABLE messages (
    id VARCHAR PRIMARY KEY,
    session_id VARCHAR NOT NULL,
    role VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    content_type VARCHAR(50) NOT NULL DEFAULT 'text',
    model_name VARCHAR(100),
    provider VARCHAR(50),
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    cost_usd FLOAT NOT NULL DEFAULT 0.0,
    is_error BOOLEAN NOT NULL DEFAULT FALSE,
    is_system_prompt BOOLEAN NOT NULL DEFAULT FALSE,
    is_final_response BOOLEAN NOT NULL DEFAULT FALSE,
    attachments JSON,
    tool_calls JSON,
    metadata JSON,
    temperature FLOAT,
    max_tokens INTEGER,
    top_p FLOAT,
    frequency_penalty FLOAT,
    presence_penalty FLOAT,
    sequence_number INTEGER NOT NULL,
    parent_message_id VARCHAR,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_message_id) REFERENCES messages(id) ON DELETE SET NULL
);
```

### Memories Table
```sql
CREATE TABLE memories (
    id VARCHAR PRIMARY KEY,
    session_id VARCHAR NOT NULL,
    key VARCHAR(255) NOT NULL,
    value TEXT NOT NULL,
    memory_type VARCHAR(50) NOT NULL DEFAULT 'conversation',
    importance_score FLOAT NOT NULL DEFAULT 0.5,
    confidence_score FLOAT NOT NULL DEFAULT 1.0,
    access_count INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMP,
    last_accessed TIMESTAMP,
    source_message_id VARCHAR,
    tags JSON,
    metadata JSON,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (source_message_id) REFERENCES messages(id) ON DELETE SET NULL,
    UNIQUE (session_id, key)
);
```

## Performance Indexes

The system creates optimized indexes for common queries:

```sql
-- User queries
CREATE INDEX ix_users_email ON users (email);
CREATE INDEX ix_users_username ON users (username);
CREATE INDEX ix_users_is_active ON users (is_active);

-- Session queries
CREATE INDEX ix_sessions_user_id ON sessions (user_id);
CREATE INDEX ix_sessions_status ON sessions (status);
CREATE INDEX ix_sessions_session_type ON sessions (session_type);
CREATE INDEX ix_sessions_last_activity ON sessions (last_activity);
CREATE INDEX idx_sessions_user_status ON sessions (user_id, status);

-- Message queries
CREATE INDEX ix_messages_session_id ON messages (session_id);
CREATE INDEX ix_messages_role ON messages (role);
CREATE INDEX ix_messages_sequence_number ON messages (sequence_number);
CREATE INDEX ix_messages_created_at ON messages (created_at);

-- Memory queries
CREATE INDEX ix_memories_session_id ON memories (session_id);
CREATE INDEX ix_memories_key ON memories (key);
CREATE INDEX ix_memories_memory_type ON memories (memory_type);
CREATE INDEX ix_memories_importance ON memories (importance_score);
CREATE INDEX ix_memories_expires_at ON memories (expires_at);
CREATE INDEX idx_memories_session_type ON memories (session_id, memory_type);
```

## Best Practices

### 1. Migration Development

```bash
# 1. Create migration file
python scripts/create_initial_migration.py create -m "Add user preferences"

# 2. Edit the migration file in alembic/versions/
# 3. Test the migration
python scripts/test_migrations.py --test upgrade

# 4. Apply to development database
python scripts/upgrade_db.py

# 5. Test rollback
python scripts/downgrade_db.py -r -1

# 6. Re-apply and verify
python scripts/upgrade_db.py
```

### 2. Production Deployment

```bash
# 1. Backup production database
# 2. Test migrations on staging environment
python scripts/test_migrations.py

# 3. Apply migrations during maintenance window
python scripts/upgrade_db.py

# 4. Verify application works
# 5. Monitor for issues
```

### 3. Data Safety

- Always backup before major changes
- Test migrations in development first
- Use staging environment for production testing
- Implement proper rollback procedures
- Monitor database performance after migrations

### 4. Migration Best Practices

- Keep migrations small and focused
- Test both upgrade and downgrade paths
- Use descriptive migration messages
- Don't modify existing migrations
- Consider data migration for schema changes
- Use transactions for data integrity

## Troubleshooting

### Common Issues

#### Migration Fails

```bash
# Check migration status
python scripts/create_initial_migration.py current

# Check migration history
python scripts/create_initial_migration.py history

# Test migration in isolation
python scripts/test_migrations.py --test upgrade
```

#### Foreign Key Violations

```bash
# Check database integrity
python scripts/test_migrations.py --test integrity

# Review foreign key relationships in migration files
```

#### Performance Issues

```bash
# Test query performance
python scripts/test_migrations.py --test performance

# Review index usage with EXPLAIN QUERY PLAN
```

### Debug Commands

```bash
# Show current database schema
sqlite3 data/sqlite/customer_support.db ".schema"

# Check table data
sqlite3 data/sqlite/customer_support.db "SELECT * FROM users LIMIT 5;"

# View migration history
sqlite3 data/sqlite/customer_support.db "SELECT * FROM alembic_version;"

# Check foreign keys
sqlite3 data/sqlite/customer_support.db "PRAGMA foreign_key_check;"
```

## Environment Configuration

### Development

```python
# app/config.py
settings = Settings(
    environment="development",
    database_url="sqlite+aiosqlite:///./data/sqlite/customer_support.db",
    debug=True,
)
```

### Production

```python
# app/config.py
settings = Settings(
    environment="production",
    database_url="postgresql://user:pass@localhost/dbname",
    ssl_enabled=True,
    debug=False,
)
```

## Contributing

When adding new migrations:

1. Create migration using the provided tools
2. Add comprehensive tests
3. Test upgrade/downgrade paths
4. Update documentation
5. Consider performance implications
6. Follow the established patterns

## Support

For issues with the migration system:

1. Check the troubleshooting section
2. Run the test suite
3. Review migration logs
4. Check database connection
5. Verify configuration settings

Remember: Database migrations are critical operations that can cause data loss. Always test thoroughly and maintain backups!