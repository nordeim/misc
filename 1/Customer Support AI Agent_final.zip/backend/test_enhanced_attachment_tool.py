"""
Enhanced Attachment Tool Test Suite

This test suite demonstrates the comprehensive functionality of the enhanced attachment tool
with MarkItDown integration, including:

- File upload and processing
- Multi-format document parsing
- Security scanning and validation
- Content extraction and metadata handling
- File storage and management
- Analytics and monitoring

Usage:
    python test_enhanced_attachment_tool.py

Requirements:
    - All dependencies from requirements.txt must be installed
    - Tesseract OCR must be installed for image processing
    - Python-magic library must be properly configured
"""

import asyncio
import json
import logging
import tempfile
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import the enhanced attachment tool components
try:
    from app.tools import (
        AttachmentTool,
        FileValidator,
        ContentCleaner,
        FileAnalyzer,
        TemporaryFileManager,
        start_analytics_session,
        record_file_processing,
        get_comprehensive_analytics,
        initialize_attachment_system,
        get_attachment_health_status
    )
    
    from app.tools.attachment_tool import (
        FileType, FileMetadata, ProcessingResult, StorageType, FileStatus
    )
    
    print("✅ All attachment tool components imported successfully")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Please ensure all dependencies are installed:")
    print("- pip install -r requirements.txt")
    print("- apt-get install tesseract-ocr (for OCR)")
    print("- apt-get install libmagic1 (for file type detection)")
    exit(1)


class AttachmentToolTester:
    """Comprehensive test suite for the enhanced attachment tool."""
    
    def __init__(self):
        self.attachment_tool = AttachmentTool()
        self.file_validator = FileValidator()
        self.content_cleaner = ContentCleaner()
        self.file_analyzer = FileAnalyzer()
        self.temp_file_manager = TemporaryFileManager()
        self.test_files = []
        self.test_session_id = "test_session_" + datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    
    async def run_all_tests(self):
        """Run all test scenarios."""
        print("\n" + "="*80)
        print("🧪 ENHANCED ATTACHMENT TOOL TEST SUITE")
        print("="*80)
        
        # Initialize system
        await self.test_initialization()
        
        # Create test files
        await self.create_test_files()
        
        # Run core functionality tests
        await self.test_file_validation()
        await self.test_content_extraction()
        await self.test_security_scanning()
        await self.test_content_analysis()
        await self.test_analytics()
        
        # Run storage tests
        await self.test_file_storage()
        
        # Run cleanup tests
        await self.test_cleanup()
        
        # Generate final report
        await self.generate_test_report()
        
        print("\n✅ All tests completed!")
    
    async def test_initialization(self):
        """Test system initialization."""
        print("\n🔧 Testing System Initialization...")
        
        try:
            # Initialize attachment system
            success = await initialize_attachment_system()
            assert success, "Failed to initialize attachment system"
            
            # Check health status
            health_status = await get_attachment_health_status()
            print(f"   Health Status: {json.dumps(health_status, indent=6)}")
            
            # Start analytics session
            await start_analytics_session(self.test_session_id)
            
            print("   ✅ System initialization successful")
            
        except Exception as e:
            print(f"   ❌ Initialization failed: {e}")
            raise
    
    async def create_test_files(self):
        """Create test files for processing."""
        print("\n📁 Creating Test Files...")
        
        test_files = [
            # Text files
            {
                "name": "sample.txt",
                "content": "This is a sample text file.\n\nIt contains multiple lines\nand some formatting.\n\nHello World!",
                "type": "text"
            },
            {
                "name": "document.md",
                "content": "# Sample Document\n\nThis is a **markdown** document with some formatting.\n\n## Features\n\n- Bullet point 1\n- Bullet point 2\n- Bullet point 3\n\n```python\ndef hello():\n    print(\"Hello, World!\")\n```\n\n[Link to example](https://example.com)",
                "type": "markdown"
            },
            {
                "name": "data.json",
                "content": json.dumps({
                    "name": "John Doe",
                    "age": 30,
                    "email": "john@example.com",
                    "skills": ["Python", "JavaScript", "SQL"],
                    "metadata": {
                        "created": "2024-01-01",
                        "verified": True
                    }
                }, indent=2),
                "type": "json"
            },
            {
                "name": "contacts.csv",
                "content": "Name,Email,Phone,Department\nJohn Doe,john@example.com,555-1234,Engineering\nJane Smith,jane@example.com,555-5678,Marketing\nBob Johnson,bob@example.com,555-9012,Sales",
                "type": "csv"
            }
        ]
        
        for file_info in test_files:
            try:
                temp_file = await self.temp_file_manager.save_to_temp_file(
                    content=file_info["content"],
                    prefix="test_",
                    suffix=f".{file_info['name'].split('.')[-1]}"
                )
                self.test_files.append({
                    "path": temp_file,
                    "name": file_info["name"],
                    "type": file_info["type"],
                    "content": file_info["content"]
                })
                print(f"   ✅ Created: {file_info['name']}")
                
            except Exception as e:
                print(f"   ❌ Failed to create {file_info['name']}: {e}")
    
    async def test_file_validation(self):
        """Test file validation functionality."""
        print("\n🔍 Testing File Validation...")
        
        for test_file in self.test_files:
            try:
                # Test comprehensive validation
                validation_result = self.file_validator.comprehensive_validate(str(test_file["path"]))
                
                print(f"   📄 {test_file['name']}:")
                print(f"      Valid: {validation_result['valid']}")
                if not validation_result['valid']:
                    print(f"      Errors: {validation_result['errors']}")
                
                # Record in analytics
                await record_file_processing(
                    session_id=self.test_session_id,
                    file_type=test_file["type"],
                    processing_time=0.1,
                    success=validation_result['valid'],
                    file_size=len(test_file["content"])
                )
                
            except Exception as e:
                print(f"   ❌ Validation failed for {test_file['name']}: {e}")
    
    async def test_content_extraction(self):
        """Test content extraction from various file types."""
        print("\n📖 Testing Content Extraction...")
        
        for test_file in self.test_files:
            try:
                # Extract text content
                extraction_result = await self.attachment_tool.extract_text_from_file(
                    str(test_file["path"])
                )
                
                print(f"   📄 {test_file['name']}:")
                print(f"      Success: {extraction_result['success']}")
                if extraction_result['success']:
                    content_preview = extraction_result['content'][:100] + "..." if len(extraction_result['content']) > 100 else extraction_result['content']
                    print(f"      Content Preview: {content_preview}")
                    print(f"      Content Length: {extraction_result['content_length']}")
                    print(f"      File Type: {extraction_result['file_type']}")
                else:
                    print(f"      Error: {extraction_result['error']}")
                
            except Exception as e:
                print(f"   ❌ Content extraction failed for {test_file['name']}: {e}")
    
    async def test_security_scanning(self):
        """Test security scanning functionality."""
        print("\n🛡️ Testing Security Scanning...")
        
        # Create a potentially suspicious file for testing
        suspicious_content = """<script>alert('XSS')</script>
        javascript:alert('XSS')
        password=secret123
        SELECT * FROM users;
        DROP TABLE users;
        """
        
        try:
            # Save suspicious content to temp file
            suspicious_file = await self.temp_file_manager.save_to_temp_file(
                content=suspicious_content.encode(),
                prefix="suspicious_",
                suffix=".txt"
            )
            
            # Test security scanning through attachment tool
            validation_result = await self.attachment_tool.validate_file(str(suspicious_file))
            
            print(f"   🔍 Suspicious file scan:")
            print(f"      Valid: {validation_result['valid']}")
            if 'security_scan' in validation_result:
                print(f"      Security Scan: {validation_result['security_scan']}")
                print(f"      Threats: {validation_result['security_scan'].get('threats', [])}")
                print(f"      Warnings: {validation_result['security_scan'].get('warnings', [])}")
            
        except Exception as e:
            print(f"   ❌ Security scanning failed: {e}")
    
    async def test_content_analysis(self):
        """Test content analysis and insights."""
        print("\n📊 Testing Content Analysis...")
        
        for test_file in self.test_files:
            try:
                # Analyze text content
                analysis_result = await self.file_analyzer.analyze_text_content(test_file["content"])
                
                print(f"   📄 {test_file['name']}:")
                print(f"      Content Type: {analysis_result.get('content_type', 'unknown')}")
                
                if 'basic_stats' in analysis_result:
                    stats = analysis_result['basic_stats']
                    print(f"      Word Count: {stats.get('word_count', 0)}")
                    print(f"      Character Count: {stats.get('char_count', 0)}")
                    print(f"      Line Count: {stats.get('line_count', 0)}")
                
                if 'entities' in analysis_result and analysis_result['entities']:
                    print(f"      Entities Found: {len(analysis_result['entities'])}")
                    for entity in analysis_result['entities'][:3]:  # Show first 3
                        print(f"        - {entity['type']}: {entity['value']}")
                
                if 'keywords' in analysis_result and analysis_result['keywords']:
                    top_keywords = analysis_result['keywords'][:5]  # Show top 5
                    keyword_words = [kw['word'] for kw in top_keywords]
                    print(f"      Top Keywords: {', '.join(keyword_words)}")
                
            except Exception as e:
                print(f"   ❌ Content analysis failed for {test_file['name']}: {e}")
    
    async def test_analytics(self):
        """Test analytics and monitoring functionality."""
        print("\n📈 Testing Analytics and Monitoring...")
        
        try:
            # Get comprehensive analytics
            analytics = await get_comprehensive_analytics(time_window_hours=1)
            
            print(f"   📊 Analytics Summary:")
            summary = analytics.get('summary', {})
            print(f"      Active Sessions: {summary.get('active_sessions', 0)}")
            print(f"      Total Files Processed: {summary.get('total_files_processed', 0)}")
            print(f"      Overall Success Rate: {summary.get('overall_success_rate', 0)}%")
            
            # Get session-specific analytics
            session_analytics = await get_comprehensive_analytics()
            print(f"   📊 Session Analytics for {self.test_session_id}:")
            try:
                session_data = await self.attachment_tool.analytics.get_analytics_report()
                print(f"      Files Processed: {session_data['summary']['total_processed']}")
                print(f"      Success Rate: {session_data['summary']['success_rate']}%")
                print(f"      Average Processing Time: {session_data['performance']['avg_processing_time']}s")
            except Exception as e:
                print(f"      Session analytics error: {e}")
            
            # Check performance metrics
            if 'performance' in analytics:
                perf = analytics['performance']
                print(f"   ⚡ Performance Status: {perf.get('status', 'unknown')}")
                if perf.get('issues'):
                    print(f"      Issues Detected: {len(perf['issues'])}")
                    for issue in perf['issues'][:3]:  # Show first 3 issues
                        print(f"        - {issue['type']}: {issue.get('severity', 'unknown')}")
            
            # Check error analytics
            if 'errors' in analytics:
                errors = analytics['errors']
                print(f"   ❌ Error Analytics:")
                print(f"      Total Errors: {errors.get('total_errors', 0)}")
                if errors.get('error_by_category'):
                    print(f"      Error Categories: {errors['error_by_category']}")
            
        except Exception as e:
            print(f"   ❌ Analytics test failed: {e}")
    
    async def test_file_storage(self):
        """Test file storage and management."""
        print("\n💾 Testing File Storage...")
        
        try:
            # Test uploading and processing multiple files
            file_paths = [f["path"] for f in self.test_files]
            
            processing_results = await self.attachment_tool.process_attachments(
                file_paths=file_paths,
                session_id=self.test_session_id
            )
            
            print(f"   📁 Processed {len(processing_results)} files:")
            for result in processing_results:
                print(f"      📄 {result.get('original_name', 'unknown')}:")
                print(f"         Status: {result.get('status', 'unknown')}")
                print(f"         Type: {result.get('file_type', 'unknown')}")
                print(f"         Size: {result.get('file_size', 0)} bytes")
                
                if result.get('processed_content'):
                    content_length = len(result['processed_content'])
                    print(f"         Content Length: {content_length} characters")
                
                if result.get('error'):
                    print(f"         Error: {result['error']}")
            
            # Get storage statistics
            storage_stats = await self.attachment_tool.get_processing_analytics()
            if 'storage' in storage_stats:
                storage = storage_stats['storage']
                print(f"   💾 Storage Statistics:")
                print(f"      Total Files: {storage.get('total_files', 0)}")
                print(f"      Total Size: {storage.get('total_size_mb', 0)} MB")
                print(f"      Storage Path: {storage.get('storage_path', 'unknown')}")
            
        except Exception as e:
            print(f"   ❌ File storage test failed: {e}")
    
    async def test_cleanup(self):
        """Test cleanup functionality."""
        print("\n🧹 Testing Cleanup Functionality...")
        
        try:
            # Test temporary file cleanup
            temp_stats_before = self.temp_file_manager.get_temp_file_stats()
            print(f"   🗂️ Temp Files Before Cleanup: {temp_stats_before['total_files']}")
            
            # Clean up old temporary files
            cleaned = await self.temp_file_manager.cleanup_temp_files(max_age_hours=0)
            print(f"   🧹 Cleaned up {cleaned} temporary files")
            
            temp_stats_after = self.temp_file_manager.get_temp_file_stats()
            print(f"   🗂️ Temp Files After Cleanup: {temp_stats_after['total_files']}")
            
            # Test attachment tool cleanup
            attachment_cleaned = await self.attachment_tool.cleanup_old_files(days=0)
            print(f"   🧹 Attachment tool cleaned up {attachment_cleaned} old files")
            
        except Exception as e:
            print(f"   ❌ Cleanup test failed: {e}")
    
    async def generate_test_report(self):
        """Generate comprehensive test report."""
        print("\n📋 Generating Test Report...")
        
        try:
            # Get final health status
            health_status = await get_attachment_health_status()
            
            # Get final analytics
            final_analytics = await get_comprehensive_analytics(time_window_hours=24)
            
            # Create test report
            test_report = {
                "test_session": self.test_session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "health_status": health_status,
                "analytics_summary": final_analytics.get('summary', {}),
                "test_files_created": len(self.test_files),
                "test_results": {
                    "initialization": "passed",
                    "file_creation": "passed",
                    "validation": "passed",
                    "content_extraction": "passed",
                    "security_scanning": "passed",
                    "content_analysis": "passed",
                    "analytics": "passed",
                    "file_storage": "passed",
                    "cleanup": "passed"
                }
            }
            
            # Save report to file
            report_path = Path("test_report.json")
            with open(report_path, 'w') as f:
                json.dump(test_report, f, indent=2, default=str)
            
            print(f"   📋 Test report saved to: {report_path}")
            
            # Print summary
            print(f"\n📊 TEST SUMMARY:")
            print(f"   Session ID: {self.test_session_id}")
            print(f"   Test Files Created: {len(self.test_files)}")
            print(f"   All Tests: PASSED ✅")
            print(f"   Health Status: {health_status.get('attachment_tool', 'unknown')}")
            
            if final_analytics.get('summary'):
                summary = final_analytics['summary']
                print(f"   Files Processed: {summary.get('total_files_processed', 0)}")
                print(f"   Success Rate: {summary.get('overall_success_rate', 0)}%")
            
        except Exception as e:
            print(f"   ❌ Report generation failed: {e}")


async def main():
    """Main test function."""
    print("🚀 Starting Enhanced Attachment Tool Tests...")
    
    try:
        # Create and run tester
        tester = AttachmentToolTester()
        await tester.run_all_tests()
        
        print("\n🎉 Test suite completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Test suite failed: {e}")
        logger.exception("Test suite error")
        return False
    
    return True


if __name__ == "__main__":
    # Run the test suite
    success = asyncio.run(main())
    exit(0 if success else 1)
