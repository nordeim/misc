# Session Management API Documentation

## Overview

The Session Management API provides comprehensive REST endpoints for managing chat conversation sessions, including CRUD operations, analytics, security features, utilities, and monitoring capabilities.

## Features

### 1. CRUD Operations
- **Create Sessions**: Create new chat sessions with configurable parameters
- **Read Sessions**: Retrieve session details with optional message and memory inclusion
- **Update Sessions**: Modify session properties and metadata
- **Delete Sessions**: Soft delete (archive) or hard delete sessions
- **Close Sessions**: Close sessions with user feedback and ratings

### 2. Search and Filtering
- **Advanced Search**: Multi-criteria search with date ranges, content search, and statistical filters
- **Query Suggestions**: Auto-complete suggestions for session titles and tags
- **Pagination**: Efficient pagination for large result sets
- **Sorting**: Sort by various fields (last_activity, created_at, message_count, etc.)

### 3. Analytics and Reporting
- **Overview Analytics**: Comprehensive statistics including session counts, usage metrics, and distributions
- **Performance Metrics**: Session duration analysis, completion rates, and user satisfaction metrics
- **Usage Analytics**: Time-based grouping and trend analysis
- **Feedback Statistics**: User feedback and rating analysis

### 4. Session Management Utilities
- **Batch Operations**: Bulk archive, close, delete, or transfer multiple sessions
- **Migration**: Move sessions between users with history preservation
- **Export**: Export user session data in JSON or CSV format
- **Cleanup**: Automatic cleanup of expired and inactive sessions

### 5. Security Features
- **Session Locking**: Lock sessions for security purposes
- **Audit Logging**: Track session modifications and security events
- **Access Control**: User-based access restrictions with admin override
- **Permissions**: Role-based endpoint access control

### 6. Monitoring and Alerts
- **Health Monitoring**: Session system health status and metrics
- **Alert System**: Real-time alerts for expired sessions, long-running sessions, and high usage
- **Real-time Metrics**: Live session statistics and performance indicators

## API Endpoints

### Base URL
```
/api/sessions
```

### Authentication
All endpoints require authentication unless otherwise specified. Admin-only endpoints require the `admin` role.

### Endpoints Summary

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/` | Create new session | User |
| GET | `/` | List sessions with filters | User |
| GET | `/{session_id}` | Get session details | User |
| PUT | `/{session_id}` | Update session | User |
| DELETE | `/{session_id}` | Delete session | User |
| POST | `/{session_id}/close` | Close session | User |
| GET | `/search/advanced` | Advanced search | User |
| GET | `/search/suggestions` | Search suggestions | User |
| GET | `/analytics/overview` | Analytics overview | User |
| GET | `/analytics/performance` | Performance metrics | User |
| GET | `/analytics/usage` | Usage analytics | User |
| POST | `/cleanup/expired` | Cleanup expired sessions | Admin |
| POST | `/batch/operations` | Batch operations | User |
| POST | `/migrate/{session_id}` | Migrate session | Admin |
| GET | `/export/{user_id}` | Export user sessions | User |
| POST | `/{session_id}/lock` | Lock session | Admin |
| POST | `/{session_id}/unlock` | Unlock session | Admin |
| GET | `/audit/logs` | Get audit logs | Admin |
| GET | `/monitoring/health` | System health | Admin |
| GET | `/monitoring/alerts` | Get alerts | Admin |
| GET | `/monitoring/metrics` | Real-time metrics | Admin |

## Detailed Endpoint Documentation

### CRUD Operations

#### POST `/`
Create a new session.

**Request Body:**
```json
{
  "title": "My Chat Session",
  "session_type": "chat",
  "model_name": "gpt-3.5-turbo",
  "provider": "openai",
  "model_config": {"temperature": 0.7},
  "metadata": {"priority": "normal"},
  "tags": ["support", "general"]
}
```

**Response:**
```json
{
  "success": true,
  "message": "Session created successfully",
  "session": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "title": "My Chat Session",
    "status": "active",
    "user_id": "user123",
    "created_at": "2025-11-04T05:32:20Z",
    ...
  }
}
```

#### GET `/`
List sessions with filtering and pagination.

**Query Parameters:**
- `status`: Filter by status (active, closed, archived, locked)
- `session_type`: Filter by session type
- `model_name`: Filter by model name
- `provider`: Filter by provider
- `search`: Search in title and metadata
- `tags`: Filter by tags (multiple values allowed)
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20, max: 100)
- `sort_by`: Sort field (default: last_activity)
- `sort_order`: Sort order (asc or desc)

**Response:**
```json
{
  "success": true,
  "sessions": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

#### GET `/{session_id}`
Get detailed session information.

**Query Parameters:**
- `include_messages`: Include message history (default: false)
- `include_memories`: Include session memories (default: false)

#### PUT `/{session_id}`
Update session properties.

**Request Body:**
```json
{
  "title": "Updated Session Title",
  "tags": ["updated", "new-tag"],
  "metadata": {"priority": "high"}
}
```

#### DELETE `/{session_id}`
Delete a session.

**Query Parameters:**
- `hard_delete`: Perform hard delete (default: false)

#### POST `/{session_id}/close`
Close a session with feedback.

**Request Body:**
```json
{
  "user_feedback": "positive",
  "rating": 5
}
```

### Search and Filtering

#### GET `/search/advanced`
Advanced search with multiple criteria.

**Query Parameters:**
- `q`: General search query
- `content_search`: Search in message content
- `date_from`: Date range start (ISO format)
- `date_to`: Date range end (ISO format)
- `min_messages`: Minimum message count
- `max_messages`: Maximum message count
- `min_tokens`: Minimum token count
- `max_tokens`: Maximum token count
- `rating`: Filter by rating (1-5)
- `feedback`: Filter by feedback type
- `has_attachments`: Filter sessions with attachments

#### GET `/search/suggestions`
Get search suggestions for titles and tags.

**Query Parameters:**
- `q`: Search query prefix (min 2 characters)
- `limit`: Number of suggestions (default: 10, max: 50)

### Analytics and Reporting

#### GET `/analytics/overview`
Comprehensive analytics overview.

**Query Parameters:**
- `date_from`: Date range start
- `date_to`: Date range end
- `user_id`: Filter by user ID (admin only)

**Response includes:**
- Session counts and distributions
- Usage statistics (messages, tokens)
- Session type and model usage
- Daily activity trends
- User feedback analysis

#### GET `/analytics/performance`
Performance metrics and trends.

**Response includes:**
- Average session duration
- Session completion rates
- Message and token distributions
- Peak activity analysis
- Performance brackets

#### GET `/analytics/usage`
Detailed usage analytics with time-based grouping.

**Query Parameters:**
- `date_from`: Date range start
- `date_to`: Date range end
- `group_by`: Time grouping (hour, day, week, month)

### Management Utilities

#### POST `/cleanup/expired`
Clean up expired and inactive sessions.

**Query Parameters:**
- `dry_run`: Perform dry run (default: true)
- `max_age_hours`: Maximum session age (default: 24)

#### POST `/batch/operations`
Perform batch operations on multiple sessions.

**Request Body:**
```json
{
  "operation": "archive",
  "session_ids": ["id1", "id2", "id3"],
  "reason": "Bulk archive operation"
}
```

Supported operations: `archive`, `close`, `delete`, `transfer`

#### POST `/migrate/{session_id}`
Migrate session to another user.

**Query Parameters:**
- `target_user_id`: Target user ID
- `preserve_history`: Preserve session history (default: true)

#### GET `/export/{user_id}`
Export user session data.

**Query Parameters:**
- `date_from`: Date range start
- `date_to`: Date range end
- `include_messages`: Include messages (default: false)
- `include_memories`: Include memories (default: false)
- `format`: Export format (json or csv)

### Security Features

#### POST `/{session_id}/lock`
Lock a session for security purposes.

**Query Parameters:**
- `reason`: Lock reason

#### POST `/{session_id}/unlock`
Unlock a previously locked session.

**Query Parameters:**
- `reason`: Unlock reason

#### GET `/audit/logs`
Get session audit logs.

**Query Parameters:**
- `session_id`: Filter by session ID
- `user_id`: Filter by user ID
- `action`: Filter by action type
- `date_from`: Date range start
- `date_to`: Date range end
- `page`: Page number
- `limit`: Items per page

### Monitoring and Alerts

#### GET `/monitoring/health`
Get session system health status.

**Response includes:**
- Overall health status (healthy, warning, unhealthy)
- Key metrics (total sessions, active sessions, expired sessions)
- System alerts and recommendations

#### GET `/monitoring/alerts`
Get session-related alerts.

**Query Parameters:**
- `active_only`: Show only active alerts (default: true)
- `alert_type`: Filter by alert type

**Alert Types:**
- `EXPIRED_SESSIONS`: Sessions inactive for extended periods
- `LONG_SESSIONS`: Sessions active for more than 7 days
- `HIGH_USAGE`: Users with unusually high session counts

#### GET `/monitoring/metrics`
Get real-time session metrics.

**Response includes:**
- Current session counts
- Recent activity metrics
- Performance indicators
- Top users by usage
- Session distribution by status

## Error Handling

### Standard HTTP Status Codes
- `200`: Success
- `400`: Bad Request (validation errors)
- `401`: Unauthorized (authentication required)
- `403`: Forbidden (insufficient permissions)
- `404`: Not Found (resource doesn't exist)
- `429`: Too Many Requests (rate limits exceeded)
- `500`: Internal Server Error

### Error Response Format
```json
{
  "success": false,
  "error": {
    "code": "SESSION_NOT_FOUND",
    "message": "The requested session was not found",
    "details": {
      "session_id": "550e8400-e29b-41d4-a716-446655440000"
    }
  }
}
```

### Common Error Codes
- `SESSION_NOT_FOUND`: Session ID doesn't exist
- `ACCESS_DENIED`: User lacks permissions
- `VALIDATION_ERROR`: Invalid request data
- `RATE_LIMIT_EXCEEDED`: Too many requests
- `SESSION_LIMIT_EXCEEDED`: User has reached session limit
- `BATCH_OPERATION_FAILED`: Batch operation encountered errors

## Rate Limiting

Rate limits are applied based on:
- **Authenticated Users**: 100 requests per hour per user
- **API Key Users**: 1000 requests per hour per API key
- **Anonymous Users**: 20 requests per hour per IP

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Total allowed requests
- `X-RateLimit-Remaining`: Remaining requests
- `X-RateLimit-Reset`: Reset timestamp

## Data Models

### Session Object
```json
{
  "id": "string (UUID)",
  "user_id": "string",
  "title": "string",
  "status": "string (active|closed|archived|locked)",
  "session_type": "string (chat|support|analysis|...)",
  "model_name": "string",
  "provider": "string",
  "model_config": "object",
  "metadata": "object",
  "tags": "array of strings",
  "message_count": "integer",
  "token_count": "integer",
  "started_at": "datetime",
  "ended_at": "datetime (nullable)",
  "last_activity": "datetime",
  "user_feedback": "string (positive|negative|neutral)",
  "rating": "integer (1-5)",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Analytics Object
```json
{
  "success": true,
  "period": {
    "from": "datetime",
    "to": "datetime"
  },
  "overview": {
    "total_sessions": "integer",
    "active_sessions": "integer",
    "closed_sessions": "integer",
    "total_messages": "integer",
    "total_tokens": "integer",
    "avg_messages_per_session": "number",
    "avg_tokens_per_session": "number"
  },
  "distributions": {
    "session_types": [
      {
        "type": "string",
        "count": "integer"
      }
    ],
    "models": [
      {
        "model": "string",
        "sessions": "integer",
        "total_tokens": "integer"
      }
    ]
  },
  "activity": [
    {
      "date": "date string",
      "sessions": "integer"
    }
  ]
}
```

## Best Practices

### 1. Session Creation
- Use descriptive titles for easy identification
- Include relevant tags for better organization
- Set appropriate model configuration
- Add metadata for custom tracking

### 2. Search and Filtering
- Use specific date ranges for better performance
- Combine multiple filters for precise results
- Use pagination for large result sets
- Leverage search suggestions for better UX

### 3. Batch Operations
- Test with dry_run first
- Monitor batch operation results
- Provide meaningful reasons for operations
- Use appropriate operation types

### 4. Analytics
- Use appropriate date ranges for meaningful insights
- Cache analytics results when possible
- Monitor performance metrics regularly
- Set up alerts for unusual patterns

### 5. Security
- Lock sessions only when necessary
- Document audit actions with reasons
- Review audit logs regularly
- Monitor for security events

### 6. Monitoring
- Check system health regularly
- Review alerts and take action
- Monitor real-time metrics
- Set up automated cleanup processes

## Integration Examples

### Python Client Example
```python
import requests

class SessionManager:
    def __init__(self, base_url, auth_token):
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {auth_token}"}
    
    def create_session(self, title, session_type="chat"):
        response = requests.post(
            f"{self.base_url}/sessions/",
            json={"title": title, "session_type": session_type},
            headers=self.headers
        )
        return response.json()
    
    def list_sessions(self, page=1, limit=20):
        response = requests.get(
            f"{self.base_url}/sessions/",
            params={"page": page, "limit": limit},
            headers=self.headers
        )
        return response.json()
    
    def get_analytics(self, date_from, date_to):
        response = requests.get(
            f"{self.base_url}/sessions/analytics/overview",
            params={"date_from": date_from, "date_to": date_to},
            headers=self.headers
        )
        return response.json()
```

### JavaScript/Node.js Client Example
```javascript
class SessionManager {
    constructor(baseUrl, authToken) {
        this.baseUrl = baseUrl;
        this.headers = {
            'Authorization': `Bearer ${authToken}`,
            'Content-Type': 'application/json'
        };
    }
    
    async createSession(title, sessionType = 'chat') {
        const response = await fetch(`${this.baseUrl}/sessions/`, {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify({ title, session_type: sessionType })
        });
        return await response.json();
    }
    
    async listSessions(page = 1, limit = 20) {
        const params = new URLSearchParams({ page, limit });
        const response = await fetch(`${this.baseUrl}/sessions/?${params}`, {
            headers: this.headers
        });
        return await response.json();
    }
    
    async getAnalytics(dateFrom, dateTo) {
        const params = new URLSearchParams({ date_from: dateFrom, date_to: dateTo });
        const response = await fetch(`${this.baseUrl}/sessions/analytics/overview?${params}`, {
            headers: this.headers
        });
        return await response.json();
    }
}
```

## Testing

### Unit Tests
The API includes comprehensive unit tests covering:
- CRUD operations
- Search and filtering
- Analytics calculations
- Batch operations
- Security features
- Error handling

### Integration Tests
Integration tests verify:
- End-to-end workflows
- Database operations
- Authentication and authorization
- Rate limiting
- Performance benchmarks

### Test Data
Use the provided test utilities to:
- Create test sessions
- Generate analytics data
- Simulate user workflows
- Validate response formats

## Monitoring and Observability

### Key Metrics to Monitor
1. **Session Creation Rate**: New sessions per minute/hour
2. **Active Session Count**: Current active sessions
3. **Session Duration**: Average and distribution
4. **Error Rates**: API error percentages
5. **Response Times**: Endpoint performance
6. **Resource Usage**: Database and memory usage

### Alerting Rules
1. High session creation rate
2. Large number of expired sessions
3. API error rate > 5%
4. Response time > 2 seconds
5. Database connection issues

### Logging
- All session operations are logged
- Security events are audited
- Performance metrics are tracked
- Error details are captured

This comprehensive session management API provides all the tools needed for effective session lifecycle management, monitoring, and optimization.