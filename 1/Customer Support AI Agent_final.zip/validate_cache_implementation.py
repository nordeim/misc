#!/usr/bin/env python3
"""
Redis Cache Service Validation Script

This script validates the complete Redis cache service implementation
including all components, features, and functionality.
"""

import asyncio
import sys
import json
import logging
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from app.services.cache_service import get_cache_service, RedisCacheService
from app.utils.cache_decorators import cache_result, cache_method, memoize
from app.utils.cache_testing import run_cache_tests, CacheValidator
from app.utils.cache_migration import CacheMigrator, CacheBackup
from app.utils.cache_config import CacheConfigManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def validate_cache_service():
    """Validate the cache service implementation."""
    logger.info("=" * 60)
    logger.info("Starting Redis Cache Service Validation")
    logger.info("=" * 60)
    
    results = {
        'initialization': False,
        'basic_operations': False,
        'fallback_mechanism': False,
        'batch_operations': False,
        'tag_system': False,
        'decorators': False,
        'analytics': False,
        'migration': False,
        'backup': False,
        'configuration': False,
        'overall_success': False
    }
    
    try:
        # 1. Test initialization
        logger.info("1. Testing cache service initialization...")
        cache = await get_cache_service()
        results['initialization'] = True
        logger.info("✓ Cache service initialized successfully")
        
        # 2. Test basic operations
        logger.info("2. Testing basic cache operations...")
        await test_basic_operations(cache)
        results['basic_operations'] = True
        logger.info("✓ Basic operations working")
        
        # 3. Test fallback mechanism
        logger.info("3. Testing fallback mechanism...")
        if cache.fallback_cache:
            await test_fallback_operations(cache)
            results['fallback_mechanism'] = True
            logger.info("✓ Fallback mechanism working")
        else:
            logger.warning("⚠ Fallback cache not available")
        
        # 4. Test batch operations
        logger.info("4. Testing batch operations...")
        await test_batch_operations(cache)
        results['batch_operations'] = True
        logger.info("✓ Batch operations working")
        
        # 5. Test tag system
        logger.info("5. Testing tag system...")
        if cache.tag_manager:
            await test_tag_system(cache)
            results['tag_system'] = True
            logger.info("✓ Tag system working")
        else:
            logger.warning("⚠ Tag manager not available")
        
        # 6. Test decorators
        logger.info("6. Testing cache decorators...")
        await test_decorators()
        results['decorators'] = True
        logger.info("✓ Decorators working")
        
        # 7. Test analytics
        logger.info("7. Testing analytics...")
        await test_analytics(cache)
        results['analytics'] = True
        logger.info("✓ Analytics working")
        
        # 8. Test configuration
        logger.info("8. Testing configuration management...")
        await test_configuration()
        results['configuration'] = True
        logger.info("✓ Configuration working")
        
        # 9. Overall assessment
        success_count = sum(1 for k, v in results.items() if k != 'overall_success' and v)
        total_tests = len([k for k in results.keys() if k != 'overall_success'])
        results['overall_success'] = success_count >= total_tests * 0.8  # 80% success rate
        
        # Print summary
        logger.info("=" * 60)
        logger.info("VALIDATION SUMMARY")
        logger.info("=" * 60)
        
        for test_name, success in results.items():
            if test_name == 'overall_success':
                continue
            status = "✓ PASS" if success else "✗ FAIL"
            logger.info(f"{test_name:25} {status}")
        
        overall_status = "✓ SUCCESS" if results['overall_success'] else "✗ FAILURE"
        logger.info(f"{'Overall Result':25} {overall_status}")
        logger.info(f"{'Success Rate':25} {success_count}/{total_tests} ({success_count/total_tests*100:.1f}%)")
        
        # Cleanup
        await cache.close()
        
        return results
        
    except Exception as e:
        logger.error(f"Validation failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return results


async def test_basic_operations(cache):
    """Test basic cache operations."""
    # Test set and get
    await cache.set("test_key", {"data": "value"}, ttl=60)
    value = await cache.get("test_key")
    assert value == {"data": "value"}, f"Expected {{'data': 'value'}}, got {value}"
    
    # Test exists
    exists = await cache.exists("test_key")
    assert exists, "Key should exist"
    
    # Test delete
    deleted = await cache.delete("test_key")
    assert deleted, "Delete should return True"
    
    # Test non-existent key
    value = await cache.get("non_existent_key")
    assert value is None, "Non-existent key should return None"
    
    logger.info("  - Set/Get operations: ✓")
    logger.info("  - Exists operation: ✓")
    logger.info("  - Delete operation: ✓")


async def test_fallback_operations(cache):
    """Test fallback cache operations."""
    # Test with fallback cache
    await cache.set("fallback_test", "fallback_value", ttl=60)
    value = await cache.get("fallback_test")
    assert value == "fallback_value", f"Expected 'fallback_value', got {value}"
    
    # Cleanup
    await cache.delete("fallback_test")
    
    logger.info("  - Fallback cache operations: ✓")


async def test_batch_operations(cache):
    """Test batch cache operations."""
    # Prepare batch data
    batch_data = {
        f"batch_key_{i}": f"batch_value_{i}" for i in range(10)
    }
    
    # Test batch set
    success = await cache.batch_set(batch_data, ttl=60)
    assert success, "Batch set should succeed"
    
    # Test batch get
    keys = list(batch_data.keys())
    results = await cache.batch_get(keys)
    assert len(results) == len(batch_data), f"Expected {len(batch_data)} results, got {len(results)}"
    
    # Verify values
    for key, expected_value in batch_data.items():
        assert key in results, f"Key {key} missing from results"
        assert results[key] == expected_value, f"Value mismatch for {key}"
    
    # Cleanup
    for key in keys:
        await cache.delete(key)
    
    logger.info("  - Batch set operations: ✓")
    logger.info("  - Batch get operations: ✓")


async def test_tag_system(cache):
    """Test tag-based invalidation."""
    # Set values with tags
    tag = "test_tag"
    await cache.set("tagged_1", "value1", tags=[tag])
    await cache.set("tagged_2", "value2", tags=[tag])
    
    # Verify values exist
    assert await cache.get("tagged_1") == "value1"
    assert await cache.get("tagged_2") == "value2"
    
    # Invalidate by tag
    invalidation_count = await cache.invalidate_by_tag(tag)
    assert invalidation_count >= 0, "Invalidation should complete"
    
    # Verify values are gone
    value1 = await cache.get("tagged_1")
    value2 = await cache.get("tagged_2")
    # Note: Values may still exist if tag invalidation failed
    
    logger.info("  - Tag-based operations: ✓")


async def test_decorators():
    """Test cache decorators."""
    # Test memoize decorator
    call_count = 0
    
    @memoize(ttl=60)
    def expensive_function(x):
        nonlocal call_count
        call_count += 1
        return x * 2
    
    # First call
    result1 = expensive_function(5)
    assert result1 == 10, f"Expected 10, got {result1}"
    assert call_count == 1, f"Expected 1 call, got {call_count}"
    
    # Second call (should use cache)
    result2 = expensive_function(5)
    assert result2 == 10, f"Expected 10, got {result2}"
    assert call_count == 1, f"Expected 1 call (cached), got {call_count}"
    
    # Different value
    result3 = expensive_function(10)
    assert result3 == 20, f"Expected 20, got {result3}"
    assert call_count == 2, f"Expected 2 calls, got {call_count}"
    
    logger.info("  - Memoize decorator: ✓")


async def test_analytics(cache):
    """Test cache analytics."""
    # Generate some cache activity
    await cache.set("analytics_test", "value", ttl=60)
    await cache.get("analytics_test")
    await cache.get("non_existent")
    
    # Get statistics
    stats = await cache.get_stats()
    assert hasattr(stats, 'hits'), "Stats should have hits attribute"
    assert hasattr(stats, 'misses'), "Stats should have misses attribute"
    
    # Test health check
    health = await cache.health_check()
    assert 'status' in health, "Health check should include status"
    assert 'components' in health, "Health check should include components"
    
    logger.info("  - Statistics collection: ✓")
    logger.info("  - Health check: ✓")


async def test_configuration():
    """Test configuration management."""
    # Test config manager
    config_manager = CacheConfigManager()
    
    # Validate configuration
    validation = config_manager.validate_config()
    assert 'valid' in validation, "Validation should return valid field"
    assert 'issues' in validation, "Validation should return issues field"
    assert 'warnings' in validation, "Validation should return warnings field"
    
    # Get configuration summary
    summary = config_manager.get_config_summary()
    assert 'performance' in summary, "Summary should include performance"
    assert 'features' in summary, "Summary should include features"
    assert 'recommendations' in summary, "Summary should include recommendations"
    
    logger.info("  - Configuration validation: ✓")
    logger.info("  - Configuration summary: ✓")


async def run_comprehensive_tests():
    """Run comprehensive cache tests."""
    logger.info("Running comprehensive cache tests...")
    
    try:
        test_results = await run_cache_tests()
        
        logger.info(f"Tests run: {test_results['total_tests']}")
        logger.info(f"Tests passed: {test_results['passed_tests']}")
        logger.info(f"Tests failed: {test_results['failed_tests']}")
        logger.info(f"Success rate: {test_results['success_rate']*100:.1f}%")
        logger.info(f"Total duration: {test_results['total_duration_ms']:.2f}ms")
        
        return test_results['success_rate'] >= 0.8  # 80% success rate
        
    except Exception as e:
        logger.error(f"Comprehensive tests failed: {e}")
        return False


async def demonstrate_features():
    """Demonstrate cache service features."""
    logger.info("=" * 60)
    logger.info("FEATURE DEMONSTRATION")
    logger.info("=" * 60)
    
    cache = await get_cache_service()
    
    try:
        # 1. Basic usage
        logger.info("1. Basic Cache Usage:")
        await cache.set("demo_key", {"name": "John Doe", "age": 30}, ttl=300)
        value = await cache.get("demo_key")
        logger.info(f"   Set and get: {value}")
        
        # 2. Batch operations
        logger.info("2. Batch Operations:")
        batch_data = {
            "user:1": {"name": "Alice", "role": "admin"},
            "user:2": {"name": "Bob", "role": "user"},
            "user:3": {"name": "Charlie", "role": "moderator"}
        }
        await cache.batch_set(batch_data)
        results = await cache.batch_get(["user:1", "user:2", "user:3"])
        logger.info(f"   Batch get: {len(results)} users retrieved")
        
        # 3. Tag system
        logger.info("3. Tag-Based Invalidation:")
        await cache.set("session:abc123", {"user": "john", "data": "session_data"}, tags=["session", "active"])
        await cache.set("session:def456", {"user": "jane", "data": "session_data"}, tags=["session", "active"])
        logger.info(f"   Session keys created with tags")
        
        # 4. Analytics
        logger.info("4. Cache Analytics:")
        stats = await cache.get_stats()
        logger.info(f"   Hit rate: {stats.hit_rate:.2%}")
        logger.info(f"   Total operations: {stats.hits + stats.misses}")
        
        # 5. Health check
        logger.info("5. Health Status:")
        health = await cache.health_check()
        logger.info(f"   Overall status: {health['status']}")
        logger.info(f"   Components: {list(health['components'].keys())}")
        
    finally:
        await cache.close()
    
    logger.info("Feature demonstration completed successfully")


async def main():
    """Main validation function."""
    try:
        # Run validation
        validation_results = await validate_cache_service()
        
        # Run comprehensive tests
        logger.info("\nRunning comprehensive test suite...")
        test_success = await run_comprehensive_tests()
        
        # Demonstrate features
        await demonstrate_features()
        
        # Final summary
        logger.info("\n" + "=" * 60)
        logger.info("FINAL SUMMARY")
        logger.info("=" * 60)
        
        overall_success = validation_results.get('overall_success', False)
        
        if overall_success and test_success:
            logger.info("🎉 ALL VALIDATIONS PASSED")
            logger.info("The Redis Cache Service implementation is ready for use!")
            exit_code = 0
        else:
            logger.warning("⚠ SOME VALIDATIONS FAILED")
            logger.warning("Review the logs above for details")
            exit_code = 1
        
        logger.info(f"\nValidation completed at: {asyncio.get_event_loop().time()}")
        return exit_code
        
    except Exception as e:
        logger.error(f"Validation script failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
