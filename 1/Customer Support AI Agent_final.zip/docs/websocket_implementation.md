# WebSocket Implementation Documentation

## Overview

This document describes the comprehensive WebSocket implementation for real-time communication in the Customer Support AI Agent system. The WebSocket endpoint provides secure, scalable, and feature-rich real-time communication capabilities.

## Features

### 🔐 Authentication & Authorization
- **JWT Token Validation**: Automatic JWT token validation for authenticated connections
- **Session-based Authentication**: Support for session-based authentication
- **Role-based Access Control**: Role-based permissions for different actions
- **Token Refresh Handling**: Support for token renewal and expiration handling
- **Connection Authorization**: Granular authorization for specific actions and resources

### 📡 Connection Management
- **Connection Pooling**: Efficient connection pooling for high scalability
- **Heartbeat Handling**: Automatic heartbeat detection and dead connection cleanup
- **Connection Health Monitoring**: Real-time connection health tracking
- **Connection Limits**: Configurable limits on connections per user and total connections
- **Graceful Disconnection**: Clean connection termination with proper cleanup

### 💬 Message Handling
- **Message Queuing**: Persistent message queuing for offline clients
- **Delivery Guarantees**: Configurable delivery guarantees with retry logic
- **Message Broadcasting**: Efficient broadcasting to rooms and individual clients
- **Message Validation**: Comprehensive message format and content validation
- **Message Size Limits**: Protection against oversized messages

### 🏠 Room & Channel Management
- **Room-based Communication**: Support for topic-based rooms and channels
- **Dynamic Room Joining/Leaving**: Runtime room membership management
- **Room Permissions**: Granular room access control
- **Room Statistics**: Real-time room member tracking

### 🚦 Rate Limiting & Security
- **Rate Limiting**: Per-client rate limiting to prevent abuse
- **DDoS Protection**: Built-in protection against distributed denial of service
- **Connection Security**: Secure connection handling with proper error responses
- **Input Sanitization**: Protection against malicious input and injection attacks
- **Audit Logging**: Comprehensive audit logging for security monitoring

### 📊 Monitoring & Diagnostics
- **Health Checks**: Real-time system health monitoring
- **Connection Diagnostics**: Detailed connection health analysis
- **Performance Metrics**: Comprehensive performance tracking
- **Statistics Endpoints**: Administrative endpoints for system statistics
- **Debugging Utilities**: Built-in testing and debugging capabilities

## Architecture

### Core Components

#### ConnectionManager
The central connection management system that handles:
- Active connection tracking
- Connection lifecycle management
- Message queuing and delivery
- Room membership management
- Rate limiting enforcement

#### WebSocketAuthentication
Handles authentication and authorization:
- JWT token validation
- Permission checking
- Role-based access control
- Security audit logging

#### WebSocketTester
Testing and debugging utilities:
- Connection testing
- Message simulation
- Connection diagnostics
- Automated testing capabilities

#### WebSocketDiagnostics
System monitoring and analysis:
- Health status monitoring
- Connection pattern analysis
- Performance metrics
- System diagnostics

### Data Models

#### ConnectionInfo
Contains detailed connection information:
```python
@dataclass
class ConnectionInfo:
    websocket: WebSocket
    client_id: str
    user_id: Optional[str]
    session_id: Optional[str]
    user_role: str
    permissions: List[str]
    connection_time: datetime
    last_heartbeat: datetime
    message_count: int
    bytes_sent: int
    bytes_received: int
    ip_address: Optional[str]
    user_agent: Optional[str]
    is_authenticated: bool
    rooms: Set[str]
```

#### MessageQueueItem
Represents queued messages:
```python
@dataclass
class MessageQueueItem:
    id: str
    target_client_id: str
    message: Dict[str, Any]
    timestamp: datetime
    retry_count: int
    max_retries: int
    delivery_guaranteed: bool
```

#### AuditLogEntry
Security audit log entries:
```python
@dataclass
class AuditLogEntry:
    timestamp: datetime
    event_type: str
    client_id: str
    user_id: Optional[str]
    ip_address: Optional[str]
    details: Dict[str, Any]
```

## API Reference

### WebSocket Endpoint

**URL**: `/ws`
**Protocol**: WebSocket (ws:// or wss://)

### Connection Process

1. **Handshake**: Client connects to WebSocket endpoint
2. **Authentication**: JWT token is validated from headers
3. **Authorization**: User permissions are checked
4. **Connection Data**: Client sends connection information
5. **Connection Confirmation**: Server confirms successful connection

### Message Types

#### Connection Message
```json
{
    "client_id": "unique_client_id",
    "session_id": "session_identifier",
    "rooms": ["room1", "room2"]
}
```

#### Chat Message
```json
{
    "type": "chat_message",
    "content": "Message content",
    "session_id": "session_identifier",
    "room": "optional_room"
}
```

#### Room Management
```json
{
    "type": "join_room",
    "room": "room_name"
}
```

```json
{
    "type": "leave_room",
    "room": "room_name"
}
```

#### Typing Indicator
```json
{
    "type": "typing_indicator",
    "is_typing": true,
    "session_id": "session_identifier"
}
```

#### Heartbeat
```json
{
    "type": "ping"
}
```

#### Broadcast (Admin Only)
```json
{
    "type": "broadcast",
    "message": "Broadcast message",
    "room": "optional_room"
}
```

#### Admin Actions (Admin Only)
```json
{
    "type": "admin_action",
    "action": "disconnect_client",
    "target_client_id": "client_to_disconnect"
}
```

### Response Types

#### Connection Response
```json
{
    "type": "connection",
    "status": "connected",
    "client_id": "client_id",
    "user_id": "user_id",
    "is_authenticated": true,
    "rooms": ["room1", "room2"],
    "timestamp": "2025-11-04T05:32:20Z"
}
```

#### Chat Response
```json
{
    "type": "chat_response",
    "session_id": "session_identifier",
    "request_id": "unique_request_id",
    "response": {
        "content": "Response content",
        "attachments_processed": false,
        "escalation_triggered": false,
        "sources": [],
        "confidence_score": 0.95,
        "processing_time": 0.234,
        "timestamp": "2025-11-04T05:32:20Z"
    }
}
```

#### Error Response
```json
{
    "type": "error",
    "error_code": "ERROR_CODE",
    "message": "Error message",
    "timestamp": "2025-11-04T05:32:20Z"
}
```

## HTTP Endpoints

### Health Checks

#### WebSocket Health
- **URL**: `GET /health/websocket`
- **Description**: Get WebSocket system health status
- **Response**: Detailed health information including connection statistics

#### System Health
- **URL**: `GET /health`
- **Description**: Overall system health including WebSocket status

### Statistics

#### WebSocket Statistics
- **URL**: `GET /stats/websocket`
- **Description**: Get comprehensive WebSocket system statistics
- **Authorization**: Admin access required

## Configuration

### Environment Variables

```bash
# WebSocket Configuration
WEBSOCKET_MAX_CONNECTIONS=1000
WEBSOCKET_MAX_CONNECTIONS_PER_USER=5
WEBSOCKET_MAX_MESSAGES_PER_MINUTE=60
WEBSOCKET_MAX_MESSAGE_SIZE=1048576
WEBSOCKET_HEARTBEAT_INTERVAL=30
WEBSOCKET_MESSAGE_QUEUE_MAX_SIZE=10000

# Authentication
JWT_SECRET_KEY=your_jwt_secret_key
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30
JWT_REFRESH_EXPIRE_DAYS=7

# Security
RATE_LIMIT_ENABLED=true
SECURITY_HEADERS_ENABLED=true
SSL_ENABLED=false
```

### Runtime Configuration

Connection limits and other parameters can be configured at runtime through the `ConnectionManager`:

```python
manager = ConnectionManager()
manager.max_connections = 2000
manager.max_connections_per_user = 10
manager.max_messages_per_minute = 120
manager.heartbeat_interval = 45
```

## Security Considerations

### Authentication
- All connections can optionally provide JWT tokens
- Tokens are validated for expiration and integrity
- Invalid tokens result in connection rejection
- Token refresh should be handled by the client

### Authorization
- Role-based permissions system
- Granular action-based authorization
- Admin actions require admin role
- Room access can be restricted

### Rate Limiting
- Per-client message rate limiting
- Automatic blocking for excessive requests
- Configurable limits and blocking duration
- Integration with overall system rate limiting

### Input Validation
- Message format validation
- Size limits on messages
- Sanitization of user input
- Protection against injection attacks

### Audit Logging
- All connection events are logged
- Security violations are logged
- Message activity is tracked
- Admin actions are logged

## Performance Optimization

### Connection Management
- Asynchronous connection handling
- Efficient connection pooling
- Dead connection detection and cleanup
- Memory-efficient message queuing

### Message Handling
- Async/await for non-blocking operations
- Batched message processing
- Priority-based message queuing
- Efficient message serialization

### Scalability
- Horizontal scaling support
- Redis integration for distributed setups
- Configurable connection limits
- Resource usage monitoring

## Monitoring & Observability

### Health Checks
- Real-time connection health monitoring
- System resource usage tracking
- Performance metrics collection
- Automated health reporting

### Metrics
- Connection counts and durations
- Message throughput and latency
- Error rates and types
- Resource utilization

### Logging
- Structured logging with correlation IDs
- Audit trail for security events
- Performance profiling data
- Error tracking and reporting

## Testing

### Test Suite
The comprehensive test suite (`test_websocket_comprehensive.py`) includes:
- Basic connection testing
- Chat functionality testing
- Room management testing
- Rate limiting verification
- Multiple connection testing
- Error handling verification
- Health monitoring validation

### Running Tests
```bash
# Run the test suite
python backend/test_websocket_comprehensive.py

# The tests require the backend server to be running
# Start the server first:
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### Manual Testing
You can also test the WebSocket connection manually using browser developer tools or WebSocket clients:

```javascript
// Example WebSocket connection in browser
const ws = new WebSocket('ws://localhost:8000/ws');

// Send connection data
ws.send(JSON.stringify({
    client_id: 'test_client',
    session_id: 'test_session',
    rooms: ['test_room']
}));

// Handle messages
ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log('Received:', data);
};

// Send chat message
ws.send(JSON.stringify({
    type: 'chat_message',
    content: 'Hello, WebSocket!',
    session_id: 'test_session'
}));
```

## Troubleshooting

### Common Issues

#### Connection Refused
- Ensure the backend server is running
- Check the WebSocket endpoint URL
- Verify firewall settings

#### Authentication Failures
- Check JWT token validity
- Verify token format (Bearer token)
- Ensure token hasn't expired

#### Rate Limiting
- Check rate limit configuration
- Monitor client message frequency
- Review rate limit logs

#### Heartbeat Timeouts
- Check network connectivity
- Verify heartbeat interval settings
- Monitor client activity

### Debugging
- Use the WebSocket diagnostics endpoint
- Check connection statistics
- Review audit logs
- Enable debug logging

## Production Deployment

### Requirements
- FastAPI application with WebSocket support
- Redis for message queuing (optional)
- Proper JWT authentication setup
- SSL/TLS for secure connections

### Configuration
- Set appropriate connection limits
- Configure rate limiting
- Set up monitoring and alerting
- Enable audit logging

### Monitoring
- Set up health check monitoring
- Configure performance alerts
- Monitor connection patterns
- Track error rates

## Future Enhancements

### Planned Features
- WebSocket clustering support
- Message persistence
- Advanced room permissions
- Message encryption
- Real-time collaboration features

### Performance Improvements
- Connection pooling optimization
- Message batching enhancements
- Resource usage optimization
- Horizontal scaling improvements

## Support

For issues, questions, or contributions:
- Check the troubleshooting section
- Review the audit logs
- Use the diagnostic endpoints
- Submit issues through the appropriate channels
