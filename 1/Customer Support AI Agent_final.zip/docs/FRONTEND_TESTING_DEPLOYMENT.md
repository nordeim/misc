# Frontend Testing and Deployment Guide

## Table of Contents

1. [Testing Framework Setup](#testing-framework-setup)
2. [Component Testing](#component-testing)
3. [Integration Testing](#integration-testing)
4. [End-to-End Testing](#end-to-end-testing)
5. [Accessibility Testing](#accessibility-testing)
6. [Deployment Process](#deployment-process)
7. [CI/CD Pipeline](#cicd-pipeline)
8. [Performance Monitoring](#performance-monitoring)
9. [Production Optimization](#production-optimization)

## Testing Framework Setup

### Technologies Used

- **Vitest**: Fast unit testing framework
- **React Testing Library**: Component testing utilities
- **Jest**: Test runner and assertions
- **MSW**: API mocking
- **Playwright**: E2E testing
- **Lighthouse CI**: Performance testing

### Configuration Files

- `vitest.config.ts` - Test configuration
- `playwright.config.ts` - E2E test configuration
- `lighthouserc.js` - Performance testing configuration
- `src/test/` - Test utilities and setup

### Running Tests

```bash
# Unit tests
npm run test

# Unit tests with coverage
npm run test:coverage

# Integration tests
npm run test:integration

# E2E tests
npm run e2e:install && npm run test:e2e

# All tests
./scripts/testing/run-tests.sh all
```

## Component Testing

### Test Structure

Each component has corresponding test files:

```
src/
├── components/
│   ├── Header.tsx
│   ├── Header.test.tsx        # Unit tests
│   ├── ChatInterface.tsx
│   ├── ChatInterface.test.tsx # Unit + integration
│   ├── MessageBubble.tsx
│   ├── MessageBubble.test.tsx # Unit tests
│   ├── FileUpload.tsx
│   ├── FileUpload.test.tsx    # Unit tests
│   └── TypingIndicator.tsx
│       └── TypingIndicator.test.tsx # Unit tests
```

### Test Utilities

- `renderWithProviders()` - Render with required providers
- `createMockUser()` - Create test user data
- `createMockMessage()` - Create test messages
- `createMockFile()` - Create test files

### Component Test Coverage

#### Header Component
- ✅ Navigation links functionality
- ✅ Responsive design
- ✅ Accessibility attributes
- ✅ Active state management

#### Chat Interface
- ✅ Message sending
- ✅ Real-time updates
- ✅ File attachment handling
- ✅ Error handling
- ✅ Connection status

#### Message Bubble
- ✅ User/Agent message rendering
- ✅ Timestamp formatting
- ✅ File attachments
- ✅ Message status indicators
- ✅ Quoted messages

#### File Upload
- ✅ Drag and drop
- ✅ File validation
- ✅ Upload progress
- ✅ Multiple file support
- ✅ Error handling

#### Typing Indicator
- ✅ Animation timing
- ✅ Accessibility
- ✅ Custom styling
- ✅ Reduced motion support

## Integration Testing

### API Integration Tests

Test complete user workflows:

```typescript
// Example: Complete chat flow
test('should handle complete chat workflow', async () => {
  // 1. Send message
  // 2. Receive response
  // 3. Upload file
  // 4. Send message with file
});
```

### WebSocket Integration

- Connection management
- Real-time message handling
- Typing indicators
- Connection recovery

### Error Handling Integration

- Network failures
- API errors
- WebSocket disconnections
- File upload failures

## End-to-End Testing

### Playwright Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './e2e',
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  ],
});
```

### E2E Test Scenarios

#### Chat Flow E2E Tests
- Complete user conversation
- File upload in chat
- Message history persistence
- Real-time updates

#### Accessibility E2E Tests
- Keyboard navigation
- Screen reader compatibility
- ARIA labels
- Color contrast

#### Performance E2E Tests
- Page load times
- Interaction responsiveness
- Bundle size analysis

### Running E2E Tests

```bash
# Install Playwright browsers
npm run e2e:install

# Run tests
npm run test:e2e

# Run with UI
npm run test:e2e:ui

# Run in headed mode
npm run test:e2e:headed
```

## Accessibility Testing

### WCAG 2.1 AA Compliance

- Keyboard navigation
- Screen reader support
- Color contrast (4.5:1 ratio)
- Focus management
- ARIA labels

### Testing Tools

- Playwright with axe-core
- Manual keyboard testing
- Screen reader testing
- Color contrast analyzers

### Test Coverage

- All interactive elements
- Form validation
- Dynamic content updates
- Error states
- Loading states

## Deployment Process

### Build Process

1. **Lint and Type Check**
   ```bash
   npm run lint
   npx tsc --noEmit
   ```

2. **Run Tests**
   ```bash
   npm run test:coverage
   npm run test:e2e
   ```

3. **Build Application**
   ```bash
   npm run build
   ```

4. **Security Scan**
   ```bash
   npm audit
   ```

5. **Performance Check**
   ```bash
   lhci autorun
   ```

### Docker Deployment

```bash
# Build production image
docker build -t frontend:latest .

# Run container
docker run -p 80:80 frontend:latest
```

### Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -f k8s/

# Check status
kubectl get pods -n frontend
kubectl get ingress -n frontend
```

### Deployment Script

```bash
# Deploy to staging
./scripts/deployment/deploy-frontend.sh staging v1.0.0

# Deploy to production
./scripts/deployment/deploy-frontend.sh production v1.0.0

# Rollback
./scripts/deployment/deploy-frontend.sh rollback production
```

## CI/CD Pipeline

### GitHub Actions Workflow

The CI/CD pipeline includes:

1. **Lint and Format Check**
2. **Unit and Integration Tests**
3. **E2E Tests**
4. **Accessibility Tests**
5. **Security Scan**
6. **Performance Tests**
7. **Build Docker Image**
8. **Deploy to Environment**

### Quality Gates

- ✅ All tests passing
- ✅ Code coverage ≥ 80%
- ✅ No security vulnerabilities
- ✅ Performance score ≥ 90
- ✅ Accessibility score ≥ 95

### Deployment Triggers

- **Staging**: Push to `develop` branch
- **Production**: Push to `main` branch

## Performance Monitoring

### Lighthouse CI

Automated performance testing:

```json
{
  "assertions": {
    "categories:performance": ["warn", {"minScore": 0.8}],
    "categories:accessibility": ["error", {"minScore": 0.9}],
    "first-contentful-paint": ["warn", {"maxNumericValue": 2000}]
  }
}
```

### Metrics Monitored

- First Contentful Paint (FCP)
- Largest Contentful Paint (LCP)
- Cumulative Layout Shift (CLS)
- Total Blocking Time (TBT)
- Performance Score

### Bundle Analysis

```bash
# Analyze bundle size
npm run build
npx vite-bundle-analyzer dist
```

## Production Optimization

### Build Optimization

- **Code Splitting**: Automatic route-based splitting
- **Tree Shaking**: Remove unused code
- **Minification**: CSS and JS minification
- **Compression**: Gzip/Brotli compression

### Caching Strategy

- **Static Assets**: 1 year cache
- **HTML**: No cache
- **API**: Dynamic caching

### CDN Configuration

```nginx
# Static asset caching
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### Security Headers

```nginx
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
```

## Environment Configuration

### Development

```bash
npm run dev          # Start dev server
npm run test:watch   # Run tests in watch mode
npm run lint:fix     # Fix linting issues
```

### Testing

```bash
npm run test:coverage    # Run tests with coverage
npm run test:ui         # Run tests with UI
./scripts/testing/run-tests.sh all  # Run all tests
```

### Production

```bash
npm run build       # Build for production
npm run preview     # Preview production build
```

## Troubleshooting

### Common Issues

1. **Tests failing**
   - Check mock configurations
   - Verify test environment
   - Update snapshot files

2. **E2E tests timing out**
   - Increase wait times
   - Check element selectors
   - Verify server startup

3. **Build failures**
   - Check TypeScript errors
   - Verify dependencies
   - Clear build cache

4. **Performance issues**
   - Analyze bundle size
   - Check network requests
   - Optimize images

### Debug Commands

```bash
# Debug tests
npm run test:debug

# Debug E2E tests
npx playwright test --debug

# Debug build
npm run build -- --debug

# Debug deployment
./scripts/deployment/deploy-frontend.sh staging --debug
```

## Best Practices

### Testing

- Write tests before fixing bugs
- Keep tests independent
- Use meaningful test names
- Mock external dependencies
- Test edge cases and error states

### Deployment

- Always test in staging first
- Use semantic versioning
- Monitor deployment metrics
- Have rollback plan ready
- Document deployment steps

### Performance

- Monitor Core Web Vitals
- Optimize images and assets
- Use lazy loading
- Minimize bundle size
- Implement proper caching

### Security

- Scan for vulnerabilities
- Use HTTPS everywhere
- Implement CSP headers
- Regular dependency updates
- Security code reviews

## Support

For questions or issues:

1. Check the troubleshooting section
2. Review test logs
3. Check deployment logs
4. Create an issue in the repository

## Changelog

### Version 1.0.0

- ✅ Complete testing framework setup
- ✅ Component unit tests
- ✅ Integration tests
- ✅ E2E tests with Playwright
- ✅ Accessibility testing
- ✅ CI/CD pipeline
- ✅ Docker/Kubernetes deployment
- ✅ Performance monitoring
- ✅ Security scanning
- ✅ Comprehensive documentation