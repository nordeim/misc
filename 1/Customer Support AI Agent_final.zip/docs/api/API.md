# 📡 API Documentation

This document provides comprehensive documentation for the Customer Support AI Agent API.

## Table of Contents

- [Overview](#overview)
- [Authentication](#authentication)
- [Base URLs](#base-urls)
- [Error Handling](#error-handling)
- [Rate Limiting](#rate-limiting)
- [Session Management](#session-management)
- [Chat Operations](#chat-operations)
- [Search Operations](#search-operations)
- [File Upload](#file-upload)
- [Health Checks](#health-checks)
- [WebSocket API](#websocket-api)
- [Webhooks](#webhooks)
- [SDK Examples](#sdk-examples)

---

## Overview

The Customer Support AI Agent API provides RESTful endpoints for managing chat sessions, sending messages, and searching the knowledge base. All endpoints return JSON responses and follow consistent error handling patterns.

### API Versioning

The API uses URL versioning:
- Current version: `v1`
- Base URL: `https://api.yourdomain.com/api/v1`

### Content Type

All API requests and responses use JSON:
```
Content-Type: application/json
```

### API Standards

- **HTTP Methods**: Uses standard HTTP methods (GET, POST, PUT, DELETE)
- **Status Codes**: Follows HTTP status code conventions
- **Timestamps**: All timestamps are in ISO 8601 format (UTC)
- **IDs**: All IDs are UUID strings
- **Pagination**: List endpoints support cursor-based pagination

---

## Authentication

The API uses JWT (JSON Web Tokens) for authentication. Tokens are obtained through the authentication endpoint and must be included in the Authorization header.

### Token Acquisition

```http
POST /api/v1/auth/token
Content-Type: application/json

{
  "username": "user@example.com",
  "password": "secure_password"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600,
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### Using Tokens

Include the token in the Authorization header:

```http
GET /api/v1/sessions
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Token Refresh

```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

### Public Endpoints

The following endpoints do not require authentication:
- `GET /api/v1/health`
- `POST /api/v1/sessions` (creates anonymous sessions)
- `POST /api/v1/auth/token`

---

## Base URLs

| Environment | Base URL | Description |
|-------------|----------|-------------|
| Development | `http://localhost:8000/api/v1` | Local development server |
| Staging | `https://staging-api.yourdomain.com/api/v1` | Staging environment |
| Production | `https://api.yourdomain.com/api/v1` | Production environment |

---

## Error Handling

All errors follow [RFC 7807](https://tools.ietf.org/html/rfc7807) Problem Details format.

### Error Response Format

```json
{
  "type": "https://api.yourdomain.com/errors/validation-error",
  "title": "Validation Error",
  "status": 400,
  "detail": "The provided message is too long",
  "instance": "/api/v1/chat/sessions/123/messages",
  "errors": {
    "message": ["String should have at most 1000 characters"],
    "session_id": ["Session does not exist"]
  },
  "timestamp": "2024-01-15T10:30:00Z",
  "request_id": "req_123456789"
}
```

### HTTP Status Codes

| Code | Description | Usage |
|------|-------------|-------|
| `200` | OK | Successful GET, PUT requests |
| `201` | Created | Successful POST requests |
| `204` | No Content | Successful DELETE requests |
| `400` | Bad Request | Invalid request format or parameters |
| `401` | Unauthorized | Missing or invalid authentication |
| `403` | Forbidden | Valid auth but insufficient permissions |
| `404` | Not Found | Resource does not exist |
| `409` | Conflict | Resource conflict (e.g., duplicate session) |
| `422` | Unprocessable Entity | Validation errors |
| `429` | Too Many Requests | Rate limit exceeded |
| `500` | Internal Server Error | Server error |
| `503` | Service Unavailable | Service temporarily unavailable |

### Common Error Types

| Type | Description |
|------|-------------|
| `validation-error` | Request validation failed |
| `authentication-error` | Authentication required or failed |
| `authorization-error` | Insufficient permissions |
| `not-found` | Requested resource not found |
| `rate-limit-exceeded` | Too many requests |
| `service-unavailable` | Dependency service unavailable |
| `server-error` | Internal server error |

---

## Rate Limiting

The API implements rate limiting to prevent abuse and ensure fair usage.

### Rate Limits

| Endpoint Category | Limit | Window |
|------------------|-------|--------|
| Authentication | 5 requests | 1 minute |
| Session Management | 100 requests | 1 hour |
| Chat Messages | 30 requests | 1 minute |
| Search | 60 requests | 1 minute |
| File Upload | 10 requests | 1 minute |
| Health Checks | 1000 requests | 1 minute |

### Rate Limit Headers

Every response includes rate limit information:

```http
X-RateLimit-Limit: 30
X-RateLimit-Remaining: 25
X-RateLimit-Reset: 1642248000
X-RateLimit-Window: 60
```

### Rate Limit Exceeded Response

```json
{
  "type": "https://api.yourdomain.com/errors/rate-limit-exceeded",
  "title": "Rate Limit Exceeded",
  "status": 429,
  "detail": "Too many requests. Please try again later.",
  "instance": "/api/v1/chat/sessions/123/messages",
  "retry_after": 45,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Session Management

Sessions represent individual conversation contexts. Each session maintains its own conversation history and memory.

### Create Session

```http
POST /api/v1/sessions
Content-Type: application/json

{
  "user_id": "user_123",  // Optional: Associate with user
  "metadata": {           // Optional: Custom metadata
    "source": "web",
    "campaign": "summer2024"
  }
}
```

**Response (201 Created):**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "user_id": "user_123",
  "status": "active",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z",
  "message_count": 0,
  "metadata": {
    "source": "web",
    "campaign": "summer2024"
  }
}
```

### Get Session

```http
GET /api/v1/sessions/{session_id}
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "user_id": "user_123",
  "status": "active",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:30:00Z",
  "message_count": 5,
  "metadata": {
    "source": "web",
    "campaign": "summer2024"
  }
}
```

### List Sessions

```http
GET /api/v1/sessions?limit=20&cursor=eyJpZCI6IjU1MGU4NDAwLWUyOWItNDFkNC1hNzE2LTQ0NjY1NTQ0MDAwMCJ9
Authorization: Bearer <token>
```

**Query Parameters:**
- `limit` (integer, default: 20, max: 100): Number of sessions to return
- `cursor` (string): Pagination cursor from previous response
- `user_id` (string, optional): Filter by user ID
- `status` (string, optional): Filter by status (active, ended)
- `created_after` (string, optional): ISO 8601 timestamp
- `created_before` (string, optional): ISO 8601 timestamp

**Response (200 OK):**
```json
{
  "sessions": [
    {
      "session_id": "550e8400-e29b-41d4-a716-446655440000",
      "user_id": "user_123",
      "status": "active",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z",
      "message_count": 5,
      "metadata": {}
    }
  ],
  "pagination": {
    "cursor": "eyJpZCI6IjU1MGU4NDAwLWUyOWItNDFkNC1hNzE2LTQ0NjY1NTQ0MDAwMCJ9",
    "has_more": true,
    "next_cursor": "eyJpZCI6IjY2MWE0MDkyLWUzYmQtNDFkNC1hNzE2LTQ0NjY1NTQ1MDAwMCJ9"
  }
}
```

### Update Session

```http
PUT /api/v1/sessions/{session_id}
Content-Type: application/json
Authorization: Bearer <token>

{
  "metadata": {
    "priority": "high",
    "category": "billing"
  }
}
```

**Response (200 OK):**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "user_id": "user_123",
  "status": "active",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:35:00Z",
  "message_count": 5,
  "metadata": {
    "priority": "high",
    "category": "billing"
  }
}
```

### End Session

```http
DELETE /api/v1/sessions/{session_id}
Authorization: Bearer <token>
```

**Response (204 No Content)**

### Get Session History

```http
GET /api/v1/sessions/{session_id}/history?limit=50&include_metadata=true
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "messages": [
    {
      "message_id": "msg_123456",
      "role": "user",
      "content": "Hello, I need help with my order",
      "timestamp": "2024-01-15T10:30:00Z",
      "metadata": {
        "source": "web"
      }
    },
    {
      "message_id": "msg_123457",
      "role": "assistant",
      "content": "I'd be happy to help you with your order. Can you provide your order number?",
      "timestamp": "2024-01-15T10:30:01Z",
      "sources": [
        {
          "content": "Order lookup process...",
          "metadata": {
            "document": "order_management.pdf",
            "page": 5
          },
          "relevance_score": 0.95
        }
      ],
      "confidence": 0.92,
      "metadata": {
        "processing_time_ms": 1200
      }
    }
  ],
  "total_count": 5,
  "has_more": false
}
```

---

## Chat Operations

### Send Message

```http
POST /api/v1/chat/sessions/{session_id}/messages
Content-Type: application/json
Authorization: Bearer <token>

{
  "message": "How do I reset my password?",
  "include_sources": true,
  "stream": false,
  "context": {
    "user_agent": "Mozilla/5.0...",
    "ip_address": "192.168.1.1"
  }
}
```

**Request Parameters:**
- `message` (string, required): The user's message (max 1000 characters)
- `include_sources` (boolean, default: true): Include source documents in response
- `stream` (boolean, default: false): Stream response tokens (use WebSocket for streaming)
- `context` (object, optional): Additional context for the request

**Response (200 OK):**
```json
{
  "message_id": "msg_123458",
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "role": "assistant",
  "content": "To reset your password, follow these steps:\n\n1. Go to the login page\n2. Click 'Forgot Password?'\n3. Enter your email address\n4. Check your email for reset link\n5. Follow the instructions in the email",
  "timestamp": "2024-01-15T10:35:00Z",
  "sources": [
    {
      "content": "Password Reset Procedure\n\nIf you've forgotten your password...",
      "metadata": {
        "document": "account_management.pdf",
        "page": 12,
        "section": "password_reset"
      },
      "relevance_score": 0.98,
      "url": "https://docs.yourdomain.com/account-management#password-reset"
    }
  ],
  "confidence": 0.95,
  "requires_escalation": false,
  "metadata": {
    "processing_time_ms": 1500,
    "model_used": "gpt-4o-mini",
    "token_count": {
      "input": 45,
      "output": 78
    }
  }
}
```

### Send Message with Attachments

```http
POST /api/v1/chat/sessions/{session_id}/messages
Content-Type: multipart/form-data
Authorization: Bearer <token>

message: "Can you analyze this document?"
file1: [binary data]
```

**Response (200 OK):**
```json
{
  "message_id": "msg_123459",
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "role": "assistant",
  "content": "I've analyzed the document you provided. Here are the key points:\n\n- The document contains contract terms for service agreement\n- Payment terms are net 30 days\n- Termination clause requires 30 days notice",
  "timestamp": "2024-01-15T10:35:00Z",
  "attachments": [
    {
      "file_id": "file_abc123",
      "filename": "contract.pdf",
      "processed": true,
      "content_type": "application/pdf",
      "size_bytes": 245678,
      "extracted_text": "Service Agreement\n\nThis agreement...",
      "page_count": 5
    }
  ],
  "metadata": {
    "processing_time_ms": 3200,
    "attachment_processing_time_ms": 1800
  }
}
```

### Get Message

```http
GET /api/v1/chat/messages/{message_id}
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "message_id": "msg_123458",
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "role": "assistant",
  "content": "To reset your password...",
  "timestamp": "2024-01-15T10:35:00Z",
  "sources": [...],
  "confidence": 0.95,
  "metadata": {...}
}
```

### Bulk Message Operations

#### Send Multiple Messages

```http
POST /api/v1/chat/sessions/{session_id}/messages/bulk
Content-Type: application/json
Authorization: Bearer <token>

{
  "messages": [
    {
      "content": "First message",
      "role": "user"
    },
    {
      "content": "Second message",
      "role": "user"
    }
  ]
}
```

**Response (207 Multi-Status):**
```json
{
  "results": [
    {
      "index": 0,
      "status": 201,
      "message_id": "msg_123460",
      "content": "Response to first message"
    },
    {
      "index": 1,
      "status": 201,
      "message_id": "msg_123461",
      "content": "Response to second message"
    }
  ],
  "failed_count": 0
}
```

---

## Search Operations

### Search Knowledge Base

```http
POST /api/v1/search
Content-Type: application/json
Authorization: Bearer <token>

{
  "query": "refund policy",
  "limit": 10,
  "filters": {
    "category": "policies",
    "document_type": "pdf",
    "date_after": "2024-01-01T00:00:00Z"
  },
  "include_metadata": true
}
```

**Request Parameters:**
- `query` (string, required): Search query
- `limit` (integer, default: 10, max: 50): Number of results
- `filters` (object, optional): Metadata filters
- `include_metadata` (boolean, default: true): Include document metadata
- `similarity_threshold` (float, optional): Minimum similarity score (0.0-1.0)

**Response (200 OK):**
```json
{
  "query": "refund policy",
  "total_results": 15,
  "results": [
    {
      "content": "Refund Policy\n\n1. Refunds are available within 30 days of purchase...\n2. Items must be in original condition...\n3. Refunds will be processed within 5-7 business days",
      "metadata": {
        "document": "refund_policy_2024.pdf",
        "page": 1,
        "section": "overview",
        "category": "policies",
        "last_updated": "2024-01-01T00:00:00Z"
      },
      "relevance_score": 0.95,
      "highlights": [
        "Refunds are available within 30 days of purchase",
        "processed within 5-7 business days"
      ]
    },
    {
      "content": "Return Process\n\nTo initiate a return:\n1. Contact customer service\n2. Receive return authorization\n3. Package item securely\n4. Ship using provided label",
      "metadata": {
        "document": "returns_guide.pdf",
        "page": 2,
        "category": "processes",
        "last_updated": "2023-12-15T00:00:00Z"
      },
      "relevance_score": 0.87,
      "highlights": [
        "Contact customer service",
        "receive return authorization"
      ]
    }
  ],
  "search_metadata": {
    "processing_time_ms": 245,
    "index_version": "v2.1.0",
    "total_documents_searched": 1247
  }
}
```

### Semantic Search

```http
POST /api/v1/search/semantic
Content-Type: application/json
Authorization: Bearer <token>

{
  "query": "How long does shipping take?",
  "vector_search": true,
  "limit": 5,
  "expand_query": true
}
```

**Response (200 OK):**
```json
{
  "query": "How long does shipping take?",
  "expanded_query": "shipping delivery time duration transit period",
  "results": [
    {
      "content": "Standard Shipping\n\nDelivery time: 5-7 business days\nTracking: Available after 24 hours",
      "relevance_score": 0.92,
      "metadata": {
        "document": "shipping_info.pdf",
        "page": 1
      }
    }
  ],
  "related_queries": [
    "delivery timeframes",
    "shipping duration",
    "how long for delivery"
  ]
}
```

### Search Suggestions

```http
GET /api/v1/search/suggestions?q=refund
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "query": "refund",
  "suggestions": [
    "refund policy",
    "refund process",
    "refund timeline",
    "refund status"
  ],
  "popular_searches": [
    "track order",
    "return item",
    "contact support",
    "account settings"
  ]
}
```

---

## File Upload

### Upload File

```http
POST /api/v1/files
Content-Type: multipart/form-data
Authorization: Bearer <token>

file: [binary data]
category: documents
tags: contract,agreement
```

**Request Parameters:**
- `file` (file, required): The file to upload
- `category` (string, optional): File category
- `tags` (string, optional): Comma-separated tags
- `description` (string, optional): File description

**Response (201 Created):**
```json
{
  "file_id": "file_abc123",
  "filename": "contract.pdf",
  "original_filename": "service_agreement.pdf",
  "content_type": "application/pdf",
  "size_bytes": 245678,
  "category": "documents",
  "tags": ["contract", "agreement"],
  "description": "Service agreement contract",
  "uploaded_at": "2024-01-15T10:30:00Z",
  "status": "processed",
  "metadata": {
    "page_count": 5,
    "word_count": 1250,
    "language": "en"
  },
  "download_url": "https://api.yourdomain.com/api/v1/files/file_abc123/download"
}
```

### Get File Info

```http
GET /api/v1/files/{file_id}
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "file_id": "file_abc123",
  "filename": "contract.pdf",
  "content_type": "application/pdf",
  "size_bytes": 245678,
  "category": "documents",
  "uploaded_at": "2024-01-15T10:30:00Z",
  "status": "processed",
  "metadata": {
    "page_count": 5,
    "word_count": 1250
  },
  "download_url": "https://api.yourdomain.com/api/v1/files/file_abc123/download"
}
```

### Download File

```http
GET /api/v1/files/{file_id}/download
Authorization: Bearer <token>
```

**Response (200 OK):**
```
[Binary file data]
Content-Disposition: attachment; filename="contract.pdf"
Content-Type: application/pdf
Content-Length: 245678
```

### List Files

```http
GET /api/v1/files?limit=20&category=documents&tags=contract
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "files": [
    {
      "file_id": "file_abc123",
      "filename": "contract.pdf",
      "size_bytes": 245678,
      "category": "documents",
      "uploaded_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "has_more": false,
    "next_cursor": null
  }
}
```

### Delete File

```http
DELETE /api/v1/files/{file_id}
Authorization: Bearer <token>
```

**Response (204 No Content)**

---

## Health Checks

### Basic Health Check

```http
GET /api/v1/health
```

**Response (200 OK):**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "uptime_seconds": 86400
}
```

### Detailed Health Check

```http
GET /api/v1/health/detailed
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "uptime_seconds": 86400,
  "services": {
    "database": {
      "status": "healthy",
      "response_time_ms": 15,
      "connection_pool": {
        "active": 5,
        "idle": 15,
        "max": 20
      }
    },
    "redis": {
      "status": "healthy",
      "response_time_ms": 2,
      "memory_usage_mb": 45
    },
    "chromadb": {
      "status": "healthy",
      "response_time_ms": 25,
      "collections_count": 15,
      "documents_count": 1247
    },
    "openai": {
      "status": "healthy",
      "response_time_ms": 1200,
      "rate_limit_remaining": 950
    }
  },
  "system": {
    "cpu_usage_percent": 35.2,
    "memory_usage_percent": 68.5,
    "disk_usage_percent": 42.1,
    "network_io_mbps": 15.6
  }
}
```

### Readiness Check

```http
GET /api/v1/health/ready
```

**Response (200 OK):**
```json
{
  "ready": true,
  "checks": {
    "database": true,
    "redis": true,
    "chromadb": true,
    "openai": true
  }
}
```

### Liveness Check

```http
GET /api/v1/health/live
```

**Response (200 OK):**
```json
{
  "alive": true,
  "pid": 12345,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## WebSocket API

The WebSocket API provides real-time streaming for chat messages and agent responses.

### Connection

```javascript
const ws = new WebSocket('wss://api.yourdomain.com/api/v1/ws?session_id=550e8400-e29b-41d4-a716-446655440000');

ws.onopen = function(event) {
  console.log('WebSocket connected');
};

ws.onmessage = function(event) {
  const data = JSON.parse(event.data);
  console.log('Received:', data);
};

ws.onclose = function(event) {
  console.log('WebSocket closed:', event.code, event.reason);
};

ws.onerror = function(error) {
  console.error('WebSocket error:', error);
};
```

### Authentication

For authenticated sessions, include the token:

```javascript
const token = 'your-jwt-token';
const ws = new WebSocket(
  `wss://api.yourdomain.com/api/v1/ws?session_id=550e8400-e29b-41d4-a716-446655440000&token=${token}`
);
```

### Message Types

#### Send Message

```javascript
// Client sends message
ws.send(JSON.stringify({
  type: 'message',
  content: 'Hello, I need help with my order',
  timestamp: '2024-01-15T10:30:00Z'
}));
```

#### Receive Response

```javascript
// Server sends token stream
{
  "type": "token",
  "content": "Hello! I'd be happy",
  "timestamp": "2024-01-15T10:30:01Z"
}

// Server sends source reference
{
  "type": "source",
  "content": "Order lookup process...",
  "metadata": {
    "document": "order_management.pdf",
    "page": 5,
    "relevance_score": 0.95
  }
}

// Server indicates tool usage
{
  "type": "tool_call",
  "tool": "rag_search",
  "parameters": {
    "query": "order status lookup"
  }
}

// Server sends completion
{
  "type": "complete",
  "final_message": "Hello! I'd be happy to help you with your order. Can you provide your order number?",
  "sources": [...],
  "metadata": {
    "processing_time_ms": 1200,
    "confidence": 0.92
  }
}
```

#### Error Messages

```javascript
{
  "type": "error",
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests. Please wait before sending another message.",
    "retry_after": 30
  }
}
```

### Heartbeat

WebSocket connections require periodic heartbeats:

```javascript
// Server sends ping
{
  "type": "ping",
  "timestamp": "2024-01-15T10:30:00Z"
}

// Client responds with pong
{
  "type": "pong",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Connection Limits

- Maximum connections per IP: 10
- Connection timeout: 60 seconds
- Message rate limit: 30 messages per minute

---

## Webhooks

Webhooks allow receiving real-time notifications about events in your application.

### Register Webhook

```http
POST /api/v1/webhooks
Content-Type: application/json
Authorization: Bearer <token>

{
  "url": "https://yourdomain.com/webhooks/customer-support",
  "events": ["message.created", "session.ended", "escalation.required"],
  "secret": "webhook_secret_key",
  "active": true
}
```

**Response (201 Created):**
```json
{
  "webhook_id": "wh_abc123",
  "url": "https://yourdomain.com/webhooks/customer-support",
  "events": ["message.created", "session.ended", "escalation.required"],
  "status": "active",
  "created_at": "2024-01-15T10:30:00Z",
  "secret": "webhook_secret_key"
}
```

### Webhook Events

#### Message Created

```json
{
  "event": "message.created",
  "timestamp": "2024-01-15T10:35:00Z",
  "data": {
    "message_id": "msg_123458",
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "role": "assistant",
    "content": "To reset your password...",
    "confidence": 0.95,
    "requires_escalation": false
  }
}
```

#### Session Ended

```json
{
  "event": "session.ended",
  "timestamp": "2024-01-15T11:00:00Z",
  "data": {
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "user_id": "user_123",
    "ended_at": "2024-01-15T11:00:00Z",
    "duration_seconds": 1800,
    "message_count": 12,
    "resolution_status": "resolved"
  }
}
```

#### Escalation Required

```json
{
  "event": "escalation.required",
  "timestamp": "2024-01-15T10:45:00Z",
  "data": {
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "message_id": "msg_123465",
    "reason": "complex_technical_issue",
    "confidence_score": 0.45,
    "priority": "high",
    "assigned_to": "agent_456"
  }
}
```

### Webhook Security

Webhooks are signed with HMAC-SHA256 using your webhook secret:

```http
X-Webhook-Signature: sha256=abc123def456...
X-Webhook-Timestamp: 1642248000
X-Webhook-Event: message.created
```

**Verify Signature (Python):**
```python
import hashlib
import hmac

def verify_webhook_signature(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(f"sha256={expected_signature}", signature)
```

### Retry Policy

Webhooks are retried with exponential backoff:
- Retry attempts: 5
- Initial delay: 1 second
- Maximum delay: 300 seconds

---

## SDK Examples

### Python SDK

```python
from customer_support_api import APIClient

# Initialize client
client = APIClient(
    base_url="https://api.yourdomain.com/api/v1",
    api_key="your-api-key"
)

# Create session
session = client.sessions.create(
    user_id="user_123",
    metadata={"source": "web"}
)

# Send message
response = client.chat.send_message(
    session_id=session["session_id"],
    message="Hello, I need help with my order"
)

print(response["content"])

# Close session
client.sessions.end(session["session_id"])
```

### JavaScript/Node.js SDK

```javascript
import { APIClient } from '@yourdomain/customer-support-api';

const client = new APIClient({
  baseURL: 'https://api.yourdomain.com/api/v1',
  apiKey: 'your-api-key'
});

// Create session
const session = await client.sessions.create({
  userId: 'user_123',
  metadata: { source: 'web' }
});

// Send message
const response = await client.chat.sendMessage({
  sessionId: session.sessionId,
  message: 'Hello, I need help with my order'
});

console.log(response.content);

// WebSocket for streaming
const ws = await client.chat.connectWebSocket(session.sessionId);
ws.on('token', (token) => {
  process.stdout.write(token.content);
});
ws.on('complete', (response) => {
  console.log('\n' + JSON.stringify(response.sources, null, 2));
});
```

### cURL Examples

#### Create Session
```bash
curl -X POST https://api.yourdomain.com/api/v1/sessions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "user_id": "user_123",
    "metadata": {"source": "mobile_app"}
  }'
```

#### Send Message
```bash
curl -X POST https://api.yourdomain.com/api/v1/chat/sessions/SESSION_ID/messages \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "message": "How do I track my order?",
    "include_sources": true
  }'
```

#### Search Knowledge Base
```bash
curl -X POST https://api.yourdomain.com/api/v1/search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "query": "shipping options",
    "limit": 5,
    "filters": {
      "category": "shipping"
    }
  }'
```

### Response Examples

All responses follow consistent patterns:

#### Success Response
```json
{
  "success": true,
  "data": {
    // Response data
  },
  "metadata": {
    "request_id": "req_123456789",
    "timestamp": "2024-01-15T10:30:00Z",
    "processing_time_ms": 245
  }
}
```

#### Error Response
```json
{
  "success": false,
  "error": {
    "type": "validation-error",
    "title": "Invalid Request",
    "detail": "The message field is required",
    "code": "VALIDATION_ERROR"
  },
  "metadata": {
    "request_id": "req_123456789",
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

---

## API Changes and Versioning

### Version Strategy

- **URL Versioning**: `/api/v1/`, `/api/v2/`
- **Deprecation Notice**: 90 days before removal
- **Backward Compatibility**: Maintained within major versions
- **Breaking Changes**: Only in new major versions

### Changelog

#### v1.0.0 (2024-01-15)
- Initial API release
- Session management endpoints
- Chat messaging endpoints
- Knowledge base search
- File upload functionality
- WebSocket streaming support
- Webhook notifications

#### Planned v1.1.0
- Batch operations for messages
- Advanced search filters
- Custom agent instructions API
- Analytics and reporting endpoints

### Migration Guide

#### From v1.0 to v1.1

```python
# Old API (v1.0)
response = client.send_message(session_id, "Hello")

# New API (v1.1) - Same interface
response = client.send_message(session_id, "Hello")
# No changes required
```

For more detailed API documentation, visit the interactive documentation at:
- Development: http://localhost:8000/docs
- Production: https://api.yourdomain.com/docs
