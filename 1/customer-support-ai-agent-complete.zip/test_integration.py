#!/usr/bin/env python3
"""
End-to-End Integration Test Suite for Customer Support AI Agent

This comprehensive integration test suite validates the complete system functionality
including database operations, API endpoints, WebSocket connections, RAG functionality,
file uploads, authentication, and all system integrations.

Features:
- Complete API endpoint testing
- Database integration validation
- WebSocket communication testing
- RAG functionality verification
- File upload and processing validation
- Authentication and authorization testing
- CORS and security validation
- Error handling and recovery testing
- Performance baseline validation
- Concurrent user simulation

Usage:
    python test_integration.py [--host HOST] [--port PORT] [--verbose] [--parallel]
"""

import asyncio
import json
import time
import logging
import sys
import os
import argparse
import random
import string
import tempfile
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
from contextlib import asynccontextmanager

import requests
import websockets
import pytest
from requests.auth import HTTPBasicAuth

# Test configuration
@dataclass
class TestConfig:
    """Test configuration for integration tests."""
    base_url: str = "http://localhost:8000"
    ws_url: str = "ws://localhost:8000/ws"
    api_key: Optional[str] = None
    username: str = "test_user"
    password: str = "test_password"
    timeout: int = 30
    max_retries: int = 3
    concurrent_users: int = 10
    test_data_size: int = 100
    verbose: bool = False
    parallel: bool = False

class IntegrationTestSuite:
    """Comprehensive integration test suite for the Customer Support AI Agent."""
    
    def __init__(self, config: TestConfig):
        self.config = config
        self.logger = self._setup_logging()
        self.session = requests.Session()
        self.test_results = {
            'total_tests': 0,
            'passed': 0,
            'failed': 0,
            'skipped': 0,
            'errors': [],
            'performance_metrics': {},
            'system_health': {}
        }
        self.auth_token = None
        self.test_files = []
        
    def _setup_logging(self) -> logging.Logger:
        """Setup test logging configuration."""
        logger = logging.getLogger('integration_tests')
        logger.setLevel(logging.DEBUG if self.config.verbose else logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
        return logger
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make HTTP request with retry logic."""
        url = f"{self.config.base_url}{endpoint}"
        
        headers = kwargs.get('headers', {})
        if self.auth_token:
            headers['Authorization'] = f"Bearer {self.auth_token}"
        
        kwargs['headers'] = headers
        kwargs['timeout'] = self.config.timeout
        
        for attempt in range(self.config.max_retries):
            try:
                response = self.session.request(method, url, **kwargs)
                if response.status_code < 500:  # Don't retry on client errors
                    return response
            except requests.RequestException as e:
                if attempt == self.config.max_retries - 1:
                    raise
                self.logger.warning(f"Request failed (attempt {attempt + 1}): {e}")
                time.sleep(2 ** attempt)  # Exponential backoff
        
        raise requests.RequestException("Max retries exceeded")
    
    async def _make_ws_request(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make WebSocket request with timeout."""
        ws_url = f"{self.config.ws_url}{endpoint}"
        headers = {}
        if self.auth_token:
            headers['Authorization'] = f"Bearer {self.auth_token}"
        
        try:
            async with websockets.connect(ws_url, extra_headers=headers) as websocket:
                await websocket.send(json.dumps(data))
                response = await asyncio.wait_for(websocket.recv(), timeout=self.config.timeout)
                return json.loads(response)
        except asyncio.TimeoutError:
            raise Exception(f"WebSocket request timed out after {self.config.timeout} seconds")
        except Exception as e:
            raise Exception(f"WebSocket request failed: {e}")
    
    def test_system_health(self) -> Dict[str, Any]:
        """Test system health endpoints."""
        self.logger.info("Testing system health endpoints...")
        
        try:
            # Health check endpoint
            response = self._make_request('GET', '/health')
            assert response.status_code == 200
            
            health_data = response.json()
            assert health_data['status'] == 'healthy'
            
            # Ready check endpoint
            response = self._make_request('GET', '/ready')
            assert response.status_code == 200
            
            ready_data = response.json()
            assert ready_data['status'] == 'ready'
            
            # Metrics endpoint (if enabled)
            try:
                response = self._make_request('GET', '/metrics')
                if response.status_code == 200:
                    metrics_data = response.json()
                    assert 'system_info' in metrics_data
            except:
                self.logger.info("Metrics endpoint not available (expected in production)")
            
            self.test_results['system_health'] = {
                'status': 'healthy',
                'endpoints_working': True,
                'response_time': response.elapsed.total_seconds()
            }
            
            self._log_test_result("System Health", True)
            return {'success': True}
            
        except Exception as e:
            self._log_test_result("System Health", False, str(e))
            self.test_results['system_health'] = {'status': 'unhealthy', 'error': str(e)}
            return {'success': False, 'error': str(e)}
    
    def test_api_documentation(self) -> Dict[str, Any]:
        """Test API documentation endpoints."""
        self.logger.info("Testing API documentation endpoints...")
        
        try:
            # OpenAPI/Swagger documentation
            response = self._make_request('GET', '/docs')
            assert response.status_code == 200
            assert 'text/html' in response.headers.get('content-type', '')
            
            # ReDoc documentation
            response = self._make_request('GET', '/redoc')
            assert response.status_code == 200
            assert 'text/html' in response.headers.get('content-type', '')
            
            # OpenAPI JSON schema
            response = self._make_request('GET', '/openapi.json')
            assert response.status_code == 200
            openapi_schema = response.json()
            assert 'openapi' in openapi_schema
            assert 'info' in openapi_schema
            
            self._log_test_result("API Documentation", True)
            return {'success': True}
            
        except Exception as e:
            self._log_test_result("API Documentation", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_user_authentication(self) -> Dict[str, Any]:
        """Test user authentication and authorization."""
        self.logger.info("Testing user authentication...")
        
        try:
            # Test login endpoint
            login_data = {
                'username': self.config.username,
                'password': self.config.password
            }
            
            response = self._make_request('POST', '/auth/login', json=login_data)
            
            if response.status_code == 200:
                auth_data = response.json()
                assert 'access_token' in auth_data
                assert 'token_type' in auth_data
                self.auth_token = auth_data['access_token']
                
                # Test authenticated endpoint
                response = self._make_request('GET', '/auth/me')
                assert response.status_code == 200
                
                user_data = response.json()
                assert user_data['username'] == self.config.username
                
                self._log_test_result("User Authentication", True)
                return {'success': True, 'authenticated': True}
                
            elif response.status_code == 401:
                self.logger.warning("Authentication endpoint returned 401 - may need user setup")
                self._log_test_result("User Authentication", True, "No auth required or user not set up")
                return {'success': True, 'authenticated': False}
            else:
                raise Exception(f"Unexpected status code: {response.status_code}")
                
        except Exception as e:
            self._log_test_result("User Authentication", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_session_management(self) -> Dict[str, Any]:
        """Test session management functionality."""
        self.logger.info("Testing session management...")
        
        try:
            # Create session
            session_data = {
                'user_id': 'test_user',
                'metadata': {'source': 'integration_test'}
            }
            
            response = self._make_request('POST', '/sessions', json=session_data)
            
            if response.status_code == 200:
                created_session = response.json()
                session_id = created_session['session_id']
                
                # Get session
                response = self._make_request('GET', f'/sessions/{session_id}')
                assert response.status_code == 200
                
                session_info = response.json()
                assert session_info['session_id'] == session_id
                
                # Update session
                update_data = {'metadata': {'updated': True}}
                response = self._make_request('PATCH', f'/sessions/{session_id}', json=update_data)
                assert response.status_code == 200
                
                # List sessions
                response = self._make_request('GET', '/sessions')
                assert response.status_code == 200
                sessions_list = response.json()
                assert 'sessions' in sessions_list
                
                self._log_test_result("Session Management", True)
                return {'success': True}
            else:
                self.logger.warning(f"Session endpoint returned {response.status_code}")
                self._log_test_result("Session Management", True, f"Endpoint status: {response.status_code}")
                return {'success': True}
                
        except Exception as e:
            self._log_test_result("Session Management", False, str(e))
            return {'success': False, 'error': str(e)}
    
    async def test_websocket_functionality(self) -> Dict[str, Any]:
        """Test WebSocket functionality for real-time communication."""
        self.logger.info("Testing WebSocket functionality...")
        
        try:
            # Test WebSocket connection and basic messaging
            ws_data = {
                'type': 'chat_message',
                'content': 'Hello, this is an integration test',
                'session_id': 'test_session'
            }
            
            response = await self._make_ws_request('', ws_data)
            
            assert 'response' in response or 'message' in response
            
            # Test WebSocket with authentication
            if self.auth_token:
                auth_ws_data = {
                    'type': 'auth_chat',
                    'content': 'Authenticated message',
                    'session_id': 'auth_test_session'
                }
                
                auth_response = await self._make_ws_request('', auth_ws_data)
                assert auth_response is not None
            
            self._log_test_result("WebSocket Functionality", True)
            return {'success': True}
            
        except Exception as e:
            self._log_test_result("WebSocket Functionality", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_rag_functionality(self) -> Dict[str, Any]:
        """Test RAG (Retrieval-Augmented Generation) functionality."""
        self.logger.info("Testing RAG functionality...")
        
        try:
            # Test document upload and indexing
            test_document = {
                'title': 'Test Document',
                'content': 'This is a test document for RAG functionality testing.',
                'metadata': {'type': 'test', 'source': 'integration_test'}
            }
            
            response = self._make_request('POST', '/rag/documents', json=test_document)
            
            if response.status_code == 200:
                doc_data = response.json()
                assert 'document_id' in doc_data
                
                # Test document search
                search_data = {'query': 'test document'}
                response = self._make_request('POST', '/rag/search', json=search_data)
                
                if response.status_code == 200:
                    search_results = response.json()
                    assert 'results' in search_results
                    
                    # Test RAG query
                    rag_query = {
                        'query': 'What is this document about?',
                        'use_rag': True,
                        'max_results': 5
                    }
                    
                    response = self._make_request('POST', '/rag/query', json=rag_query)
                    if response.status_code == 200:
                        rag_response = response.json()
                        assert 'answer' in rag_response
                        
                    self._log_test_result("RAG Functionality", True)
                    return {'success': True}
                else:
                    self.logger.warning(f"RAG search returned {response.status_code}")
                    self._log_test_result("RAG Functionality", True, "Basic functionality available")
                    return {'success': True}
            else:
                self.logger.warning(f"RAG document upload returned {response.status_code}")
                self._log_test_result("RAG Functionality", True, "RAG endpoints available")
                return {'success': True}
                
        except Exception as e:
            self._log_test_result("RAG Functionality", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_file_upload(self) -> Dict[str, Any]:
        """Test file upload and processing functionality."""
        self.logger.info("Testing file upload functionality...")
        
        try:
            # Create test file
            test_file_content = "This is a test file for upload testing."
            test_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
            test_file.write(test_file_content)
            test_file.close()
            
            self.test_files.append(test_file.name)
            
            # Test file upload
            with open(test_file.name, 'rb') as f:
                files = {'file': ('test.txt', f, 'text/plain')}
                response = self._make_request('POST', '/upload', files=files)
            
            if response.status_code == 200:
                upload_data = response.json()
                assert 'file_id' in upload_data or 'filename' in upload_data
                
                # Test file download (if supported)
                try:
                    file_id = upload_data.get('file_id', 'test.txt')
                    response = self._make_request('GET', f'/files/{file_id}')
                    assert response.status_code == 200
                except:
                    self.logger.info("File download endpoint not available")
                
                self._log_test_result("File Upload", True)
                return {'success': True}
            else:
                self.logger.warning(f"File upload returned {response.status_code}")
                self._log_test_result("File Upload", True, "Upload endpoint available")
                return {'success': True}
                
        except Exception as e:
            self._log_test_result("File Upload", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_cors_configuration(self) -> Dict[str, Any]:
        """Test CORS configuration and headers."""
        self.logger.info("Testing CORS configuration...")
        
        try:
            # Test CORS preflight request
            headers = {
                'Origin': 'http://localhost:3000',
                'Access-Control-Request-Method': 'POST',
                'Access-Control-Request-Headers': 'Content-Type,Authorization'
            }
            
            response = self._make_request('OPTIONS', '/health', headers=headers)
            
            # CORS headers should be present
            cors_headers = [
                'access-control-allow-origin',
                'access-control-allow-methods',
                'access-control-allow-headers'
            ]
            
            for header in cors_headers:
                assert any(h.lower() == header for h in response.headers.keys()), f"CORS header {header} not found"
            
            self._log_test_result("CORS Configuration", True)
            return {'success': True}
            
        except Exception as e:
            self._log_test_result("CORS Configuration", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_rate_limiting(self) -> Dict[str, Any]:
        """Test rate limiting functionality."""
        self.logger.info("Testing rate limiting...")
        
        try:
            # Make multiple rapid requests to trigger rate limiting
            endpoint = '/health'
            responses = []
            
            for i in range(15):  # Exceed typical rate limits
                response = self._make_request('GET', endpoint)
                responses.append(response.status_code)
            
            # Check if rate limiting is working (either 429 or throttling behavior)
            rate_limited = any(status == 429 for status in responses)
            
            if rate_limited:
                self.logger.info("Rate limiting is active")
            else:
                self.logger.info("Rate limiting may not be configured or is using different thresholds")
            
            self._log_test_result("Rate Limiting", True)
            return {'success': True, 'rate_limited': rate_limited}
            
        except Exception as e:
            self._log_test_result("Rate Limiting", False, str(e))
            return {'success': False, 'error': str(e)}
    
    async def test_concurrent_users(self) -> Dict[str, Any]:
        """Test system behavior under concurrent user load."""
        self.logger.info("Testing concurrent user handling...")
        
        try:
            async def simulate_user(user_id: int) -> Dict[str, Any]:
                """Simulate a user interaction."""
                try:
                    # Health check
                    response = self._make_request('GET', '/health')
                    health_ok = response.status_code == 200
                    
                    # Chat message (if authenticated)
                    chat_data = {
                        'message': f'Hello from user {user_id}',
                        'session_id': f'user_{user_id}_session'
                    }
                    
                    chat_response = self._make_request('POST', '/chat', json=chat_data)
                    chat_ok = chat_response.status_code in [200, 401]  # 401 is ok if auth required
                    
                    return {
                        'user_id': user_id,
                        'health_ok': health_ok,
                        'chat_ok': chat_ok,
                        'success': health_ok and chat_ok
                    }
                except Exception as e:
                    return {
                        'user_id': user_id,
                        'success': False,
                        'error': str(e)
                    }
            
            # Run concurrent users
            tasks = [simulate_user(i) for i in range(self.config.concurrent_users)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            successful_users = sum(1 for r in results if isinstance(r, dict) and r.get('success', False))
            success_rate = successful_users / len(results)
            
            self.logger.info(f"Concurrent test results: {successful_users}/{len(results)} users successful ({success_rate:.2%})")
            
            self.test_results['performance_metrics']['concurrent_users'] = {
                'total_users': len(results),
                'successful_users': successful_users,
                'success_rate': success_rate,
                'timestamp': time.time()
            }
            
            # Consider test passed if >90% success rate
            test_passed = success_rate >= 0.9
            
            self._log_test_result("Concurrent Users", test_passed, 
                                f"Success rate: {success_rate:.2%}")
            return {'success': test_passed, 'success_rate': success_rate}
            
        except Exception as e:
            self._log_test_result("Concurrent Users", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_database_connectivity(self) -> Dict[str, Any]:
        """Test database connectivity and basic operations."""
        self.logger.info("Testing database connectivity...")
        
        try:
            # Test database health through API
            response = self._make_request('GET', '/health')
            
            if response.status_code == 200:
                health_data = response.json()
                
                # Check for database-related health indicators
                db_healthy = (
                    health_data.get('status') == 'healthy' and
                    'database' in health_data.get('services', {})
                )
                
                if not db_healthy:
                    # Try alternative database check
                    try:
                        response = self._make_request('GET', '/sessions')
                        db_healthy = response.status_code in [200, 401]  # 401 means auth required, but DB is working
                    except:
                        db_healthy = False
                
                if db_healthy:
                    self._log_test_result("Database Connectivity", True)
                    return {'success': True}
                else:
                    self._log_test_result("Database Connectivity", False, "Database health check failed")
                    return {'success': False, 'error': 'Database connectivity issues'}
            else:
                self._log_test_result("Database Connectivity", False, "Health check failed")
                return {'success': False, 'error': 'Health check failed'}
                
        except Exception as e:
            self._log_test_result("Database Connectivity", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_redis_connectivity(self) -> Dict[str, Any]:
        """Test Redis connectivity and caching functionality."""
        self.logger.info("Testing Redis connectivity...")
        
        try:
            # Test cache operations through API
            cache_test_data = {'key': 'test_cache_key', 'value': 'test_cache_value'}
            
            # Set cache
            response = self._make_request('POST', '/cache/set', json=cache_test_data)
            set_ok = response.status_code in [200, 404]  # 404 if cache endpoint not exposed
            
            # Get cache
            if set_ok:
                response = self._make_request('GET', f'/cache/get/{cache_test_data["key"]}')
                get_ok = response.status_code in [200, 404]
                
                if get_ok:
                    self._log_test_result("Redis Connectivity", True)
                    return {'success': True}
                else:
                    self.logger.info("Cache get endpoint not available, but Redis likely working")
                    self._log_test_result("Redis Connectivity", True, "Basic Redis connectivity assumed")
                    return {'success': True}
            else:
                self.logger.warning("Cache endpoints not available")
                self._log_test_result("Redis Connectivity", True, "Redis endpoints not exposed")
                return {'success': True}
                
        except Exception as e:
            self._log_test_result("Redis Connectivity", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_error_handling(self) -> Dict[str, Any]:
        """Test error handling and recovery."""
        self.logger.info("Testing error handling...")
        
        try:
            error_tests = [
                # Test 404 handling
                ('GET', '/nonexistent-endpoint', None, 404),
                # Test invalid JSON
                ('POST', '/chat', {'invalid': 'json'}, [400, 422]),
                # Test missing required fields
                ('POST', '/sessions', {}, [400, 422]),
                # Test invalid authentication
                ('GET', '/auth/me', None, 401),
            ]
            
            all_errors_handled = True
            for method, endpoint, data, expected_status in error_tests:
                if data:
                    response = self._make_request(method, endpoint, json=data)
                else:
                    response = self._make_request(method, endpoint)
                
                if isinstance(expected_status, list):
                    status_ok = response.status_code in expected_status
                else:
                    status_ok = response.status_code == expected_status
                
                if not status_ok:
                    all_errors_handled = False
                    self.logger.warning(f"Error handling test failed for {method} {endpoint}: "
                                      f"expected {expected_status}, got {response.status_code}")
            
            if all_errors_handled:
                self._log_test_result("Error Handling", True)
                return {'success': True}
            else:
                self._log_test_result("Error Handling", False, "Some error cases not handled correctly")
                return {'success': False, 'error': 'Inconsistent error handling'}
                
        except Exception as e:
            self._log_test_result("Error Handling", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def test_performance_baseline(self) -> Dict[str, Any]:
        """Test performance baseline metrics."""
        self.logger.info("Testing performance baseline...")
        
        try:
            endpoint = '/health'
            num_requests = 20
            
            response_times = []
            for i in range(num_requests):
                start_time = time.time()
                response = self._make_request('GET', endpoint)
                end_time = time.time()
                
                if response.status_code == 200:
                    response_times.append(end_time - start_time)
            
            if response_times:
                avg_response_time = sum(response_times) / len(response_times)
                min_response_time = min(response_times)
                max_response_time = max(response_times)
                
                # Performance thresholds
                avg_threshold = 1.0  # 1 second
                max_threshold = 3.0  # 3 seconds
                
                performance_ok = avg_response_time <= avg_threshold and max_response_time <= max_threshold
                
                self.test_results['performance_metrics']['baseline'] = {
                    'average_response_time': avg_response_time,
                    'min_response_time': min_response_time,
                    'max_response_time': max_response_time,
                    'total_requests': num_requests,
                    'successful_requests': len(response_times),
                    'avg_threshold': avg_threshold,
                    'max_threshold': max_threshold,
                    'performance_ok': performance_ok,
                    'timestamp': time.time()
                }
                
                if performance_ok:
                    self._log_test_result("Performance Baseline", True, 
                                        f"Avg: {avg_response_time:.3f}s, Max: {max_response_time:.3f}s")
                    return {'success': True, 'performance_ok': True}
                else:
                    self._log_test_result("Performance Baseline", False, 
                                        f"Performance below threshold - Avg: {avg_response_time:.3f}s")
                    return {'success': False, 'performance_ok': False}
            else:
                self._log_test_result("Performance Baseline", False, "No successful requests")
                return {'success': False, 'error': 'No successful requests for performance testing'}
                
        except Exception as e:
            self._log_test_result("Performance Baseline", False, str(e))
            return {'success': False, 'error': str(e)}
    
    def _log_test_result(self, test_name: str, success: bool, message: str = ""):
        """Log test result and update counters."""
        self.test_results['total_tests'] += 1
        
        if success:
            self.test_results['passed'] += 1
            status = "✓ PASS"
        else:
            self.test_results['failed'] += 1
            status = "✗ FAIL"
            if message:
                self.test_results['errors'].append(f"{test_name}: {message}")
        
        log_message = f"{status} {test_name}"
        if message:
            log_message += f" - {message}"
        
        if success:
            self.logger.info(log_message)
        else:
            self.logger.error(log_message)
    
    def cleanup_test_files(self):
        """Clean up test files created during testing."""
        for file_path in self.test_files:
            try:
                if os.path.exists(file_path):
                    os.unlink(file_path)
            except Exception as e:
                self.logger.warning(f"Failed to clean up test file {file_path}: {e}")
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate comprehensive integration test report."""
        report = {
            'test_summary': {
                'total_tests': self.test_results['total_tests'],
                'passed': self.test_results['passed'],
                'failed': self.test_results['failed'],
                'skipped': self.test_results['skipped'],
                'success_rate': (self.test_results['passed'] / self.test_results['total_tests']) if self.test_results['total_tests'] > 0 else 0,
                'overall_status': 'PASSED' if self.test_results['failed'] == 0 else 'FAILED'
            },
            'system_health': self.test_results['system_health'],
            'performance_metrics': self.test_results['performance_metrics'],
            'errors': self.test_results['errors'],
            'test_timestamp': datetime.now().isoformat(),
            'configuration': {
                'base_url': self.config.base_url,
                'concurrent_users': self.config.concurrent_users,
                'test_data_size': self.config.test_data_size
            }
        }
        
        return report
    
    async def run_all_tests(self) -> Dict[str, Any]:
        """Run all integration tests."""
        self.logger.info("Starting comprehensive integration test suite...")
        self.logger.info(f"Testing against: {self.config.base_url}")
        
        start_time = time.time()
        
        # Define test execution order
        test_sequence = [
            ("System Health", self.test_system_health),
            ("API Documentation", self.test_api_documentation),
            ("Database Connectivity", self.test_database_connectivity),
            ("Redis Connectivity", self.test_redis_connectivity),
            ("User Authentication", self.test_user_authentication),
            ("Session Management", self.test_session_management),
            ("CORS Configuration", self.test_cors_configuration),
            ("Rate Limiting", self.test_rate_limiting),
            ("Error Handling", self.test_error_handling),
            ("File Upload", self.test_file_upload),
            ("RAG Functionality", self.test_rag_functionality),
            ("WebSocket Functionality", self.test_websocket_functionality),
            ("Concurrent Users", self.test_concurrent_users),
            ("Performance Baseline", self.test_performance_baseline),
        ]
        
        # Run synchronous tests
        for test_name, test_func in test_sequence:
            if asyncio.iscoroutinefunction(test_func):
                continue
            
            try:
                result = test_func()
                if not result.get('success', True):
                    self.logger.warning(f"Test {test_name} failed")
            except Exception as e:
                self.logger.error(f"Test {test_name} encountered error: {e}")
                self._log_test_result(test_name, False, str(e))
        
        # Run async tests
        async_tests = [
            ("WebSocket Functionality", self.test_websocket_functionality),
            ("Concurrent Users", self.test_concurrent_users),
        ]
        
        for test_name, test_func in async_tests:
            try:
                result = await test_func()
                if not result.get('success', True):
                    self.logger.warning(f"Test {test_name} failed")
            except Exception as e:
                self.logger.error(f"Test {test_name} encountered error: {e}")
                self._log_test_result(test_name, False, str(e))
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Generate final report
        report = self.generate_report()
        report['total_execution_time'] = total_time
        
        self.logger.info(f"Integration test suite completed in {total_time:.2f} seconds")
        self.logger.info(f"Results: {report['test_summary']['passed']}/{report['test_summary']['total_tests']} tests passed "
                        f"({report['test_summary']['success_rate']:.1%})")
        
        # Cleanup
        self.cleanup_test_files()
        
        return report

def main():
    """Main function to run integration tests."""
    parser = argparse.ArgumentParser(description='Customer Support AI Agent Integration Tests')
    parser.add_argument('--host', default='localhost', help='API host (default: localhost)')
    parser.add_argument('--port', type=int, default=8000, help='API port (default: 8000)')
    parser.add_argument('--api-key', help='API key for authentication')
    parser.add_argument('--username', default='test_user', help='Username for authentication')
    parser.add_argument('--password', default='test_password', help='Password for authentication')
    parser.add_argument('--timeout', type=int, default=30, help='Request timeout in seconds')
    parser.add_argument('--max-retries', type=int, default=3, help='Max request retries')
    parser.add_argument('--concurrent-users', type=int, default=10, help='Concurrent users for load testing')
    parser.add_argument('--test-data-size', type=int, default=100, help='Test data size')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--parallel', action='store_true', help='Run tests in parallel (experimental)')
    parser.add_argument('--output', help='Output file for test results (JSON format)')
    parser.add_argument('--quiet', action='store_true', help='Suppress output except errors')
    
    args = parser.parse_args()
    
    # Configure test
    config = TestConfig(
        base_url=f"http://{args.host}:{args.port}",
        ws_url=f"ws://{args.host}:{args.port}/ws",
        api_key=args.api_key,
        username=args.username,
        password=args.password,
        timeout=args.timeout,
        max_retries=args.max_retries,
        concurrent_users=args.concurrent_users,
        test_data_size=args.test_data_size,
        verbose=args.verbose
    )
    
    # Initialize test suite
    test_suite = IntegrationTestSuite(config)
    
    # Configure logging level based on quiet flag
    if args.quiet:
        test_suite.logger.setLevel(logging.ERROR)
    
    # Run tests
    try:
        report = asyncio.run(test_suite.run_all_tests())
        
        # Save report if output file specified
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\nTest report saved to: {args.output}")
        
        # Print summary
        summary = report['test_summary']
        print(f"\n{'='*60}")
        print("INTEGRATION TEST SUMMARY")
        print(f"{'='*60}")
        print(f"Total Tests: {summary['total_tests']}")
        print(f"Passed: {summary['passed']}")
        print(f"Failed: {summary['failed']}")
        print(f"Success Rate: {summary['success_rate']:.1%}")
        print(f"Overall Status: {summary['overall_status']}")
        print(f"Execution Time: {report.get('total_execution_time', 0):.2f} seconds")
        
        if report['errors']:
            print(f"\nErrors encountered:")
            for error in report['errors']:
                print(f"  - {error}")
        
        # Exit with appropriate code
        exit_code = 0 if summary['failed'] == 0 else 1
        sys.exit(exit_code)
        
    except KeyboardInterrupt:
        print("\nTest execution interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\nTest execution failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()