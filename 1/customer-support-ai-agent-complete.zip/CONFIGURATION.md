# Environment Configuration Templates

This directory contains comprehensive environment configuration templates for the Customer Support AI Agent application. These templates provide a structured approach to managing different environments (development, production, testing) with proper security and performance considerations.

## 📁 Files Overview

### Core Configuration Files

| File | Purpose | Environment |
|------|---------|-------------|
| `.env.example` | Complete template with all possible variables | All |
| `.env.development` | Development environment settings | Development |
| `.env.production` | Production environment settings (security-focused) | Production |
| `.env.testing` | Testing environment settings (optimized for tests) | Testing |
| `backend/app/config.py` | Pydantic settings class with validation | Backend |

## 🚀 Quick Start

### 1. Environment Setup

```bash
# Copy the example file
cp .env.example .env

# Or use environment-specific templates
cp .env.development .env  # For development
cp .env.production .env   # For production
cp .env.testing .env      # For testing
```

### 2. Configure Required Variables

Edit the `.env` file and configure the essential variables:

```bash
# Required for all environments
ENVIRONMENT=development  # or production, testing
SECRET_KEY=your-secret-key-here  # Generate with: python -c "import secrets; print(secrets.token_urlsafe(32))"

# AI/LLM Configuration (choose one)
OPENAI_API_KEY=your-openai-api-key
# OR
AZURE_OPENAI_API_KEY=your-azure-openai-api-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=your-deployment-name

# Database Configuration
# Development: SQLite (default)
DATABASE_URL=sqlite+aiosqlite:///./data/sqlite/customer_support.db

# Production: PostgreSQL
# DATABASE_URL=postgresql://username:password@host:5432/database
```

### 3. Backend Configuration

The backend uses Pydantic settings with automatic validation:

```python
from backend.app.config import settings

# Access configuration
print(f"Environment: {settings.environment}")
print(f"Database URL: {settings.database_url}")
print(f"Is production: {settings.is_production}")

# Validate configuration
validation_result = settings.validate_configuration()
if not validation_result["valid"]:
    print("Configuration issues:", validation_result["issues"])
```

## 🔧 Configuration Categories

### Application Settings

```bash
# Basic application configuration
ENVIRONMENT=development
APP_NAME=Customer Support AI Agent
APP_VERSION=1.0.0
APP_DEBUG=true
```

### Security Configuration

```bash
# Security keys (CRITICAL: Change for production)
SECRET_KEY=your-secret-key-minimum-32-characters
JWT_SECRET_KEY=your-jwt-secret-key
SESSION_SECRET_KEY=your-session-secret-key

# API authentication
API_KEY=your-api-key-for-additional-security
```

### Database Configuration

```bash
# SQLite (Development)
DATABASE_URL=sqlite+aiosqlite:///./data/sqlite/customer_support.db

# PostgreSQL (Production)
DATABASE_URL=postgresql://username:password@host:5432/database

# Connection pool settings
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
DB_POOL_TIMEOUT=30
```

### AI/LLM Configuration

```bash
# OpenAI Configuration
OPENAI_API_KEY=your-openai-api-key
OPENAI_MODEL=gpt-3.5-turbo
OPENAI_MAX_TOKENS=2000
OPENAI_TEMPERATURE=0.7

# Azure OpenAI (Alternative)
AZURE_OPENAI_API_KEY=your-azure-openai-api-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=your-deployment-name
AZURE_OPENAI_API_VERSION=2024-02-01

# Embedding model for RAG
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
EMBEDDING_DIMENSION=384
```

### Redis Configuration

```bash
# Redis connection
REDIS_URL=redis://localhost:6379/0
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=your-redis-password

# Connection settings
REDIS_TIMEOUT=5
REDIS_MAX_CONNECTIONS=20
REDIS_SESSION_EXPIRE=86400
```

### ChromaDB Configuration

```bash
# Vector database settings
CHROMA_HOST=localhost
CHROMA_PORT=8001
CHROMA_PERSIST_DIRECTORY=./data/chromadb
CHROMA_COLLECTION_NAME=customer_support_docs

# Vector search settings
VECTOR_SEARCH_TOP_K=5
VECTOR_SEARCH_SCORE_THRESHOLD=0.7
VECTOR_CHUNK_SIZE=1000
VECTOR_CHUNK_OVERLAP=200
```

### File Upload Configuration

```bash
# File upload settings
UPLOAD_ENABLED=true
UPLOAD_MAX_FILE_SIZE_MB=50
UPLOAD_ALLOWED_EXTENSIONS=["pdf", "docx", "txt", "md"]

# Storage paths
UPLOAD_TEMP_PATH=./data/temp_uploads
UPLOAD_PERMANENT_PATH=./data/uploads
```

### Logging and Monitoring

```bash
# Logging configuration
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE_PATH=./data/logs/app.log
LOG_MAX_FILE_SIZE_MB=100
LOG_BACKUP_COUNT=10

# Prometheus metrics
PROMETHEUS_ENABLED=true
PROMETHEUS_PORT=9090
METRICS_ENDPOINT=/metrics

# Health checks
HEALTH_CHECK_ENABLED=true
HEALTH_CHECK_ENDPOINT=/health
```

### Rate Limiting

```bash
# Rate limiting settings
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS_PER_MINUTE=100
RATE_LIMIT_BURST_SIZE=20
RATE_LIMIT_STORAGE=redis
```

## 🏗️ Environment-Specific Configurations

### Development Environment

**File**: `.env.development`

**Characteristics**:
- Relaxed security settings
- SQLite database
- Debug logging enabled
- Hot reload enabled
- Relaxed CORS settings
- Rate limiting disabled

**Key Settings**:
```bash
ENVIRONMENT=development
APP_DEBUG=true
LOG_LEVEL=DEBUG
RATE_LIMIT_ENABLED=false
DEBUG_SQL=true
HOT_RELOAD=true
```

### Production Environment

**File**: `.env.production`

**Characteristics**:
- Strict security settings
- PostgreSQL database
- SSL/TLS enabled
- Rate limiting enabled
- Restricted CORS origins
- Comprehensive logging

**Key Settings**:
```bash
ENVIRONMENT=production
APP_DEBUG=false
SSL_ENABLED=true
RATE_LIMIT_ENABLED=true
SECURITY_HEADERS_ENABLED=true
BACKUP_ENABLED=true
```

**Security Checklist**:
- ☑ Generate strong secret keys (32+ characters)
- ☑ Use PostgreSQL, not SQLite
- ☑ Enable SSL/TLS certificates
- ☑ Configure proper CORS origins
- ☑ Enable security headers
- ☑ Set up monitoring and backups

### Testing Environment

**File**: `.env.testing`

**Characteristics**:
- In-memory SQLite database
- Mock external services
- Minimal timeouts
- Relaxed security (for testing convenience)
- Automatic cleanup

**Key Settings**:
```bash
ENVIRONMENT=testing
DATABASE_URL=sqlite+aiosqlite:///:memory:
RATE_LIMIT_ENABLED=false
SECURITY_HEADERS_ENABLED=false
MOCK_EXTERNAL_APIS=true
```

## 🔐 Security Best Practices

### 1. Secret Key Generation

```bash
# Generate secure keys
python -c "import secrets; print('SECRET_KEY=' + secrets.token_urlsafe(32))"
python -c "import secrets; print('JWT_SECRET_KEY=' + secrets.token_urlsafe(32))"

# For production, use different keys for each environment
```

### 2. Database Security

```bash
# Production database
DATABASE_URL=postgresql://username:strong-password@secure-host:5432/database

# Use connection pooling
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=30
DB_POOL_TIMEOUT=30
DB_POOL_RECYCLE=3600
```

### 3. Redis Security

```bash
# Redis with password
REDIS_URL=redis://username:password@secure-host:6379/0
REDIS_PASSWORD=strong-redis-password

# Connection security
REDIS_TIMEOUT=5
REDIS_MAX_CONNECTIONS=50
```

### 4. CORS Configuration

```bash
# Production - restrictive
CORS_ORIGINS=["https://yourdomain.com", "https://app.yourdomain.com"]

# Development - permissive
CORS_ORIGINS=["http://localhost:3000", "http://localhost:5173"]

# Testing - very permissive
CORS_ORIGINS=["*"]
```

## 🧪 Testing Configuration

### Test Database Setup

```python
# Use in-memory SQLite for fast testing
DATABASE_URL="sqlite+aiosqlite:///:memory:"

# Configure test isolation
USE_TRANSACTIONS_FOR_TESTS=true
ROLLBACK_AFTER_TESTS=true
```

### Mock External Services

```bash
# Mock AI/LLM services for testing
MOCK_OPENAI=true
MOCK_EXTERNAL_APIS=true

# Mock faster response times
MOCK_RESPONSE_DELAY_MS=0
MOCK_PROCESSING_TIME_MS=10
```

### Test Data Management

```bash
# Automatic cleanup
TEST_DATA_CLEANUP=true
TEST_DATA_ISOLATION=true

# Use transactions for isolation
USE_TRANSACTIONS_FOR_TESTS=true
```

## 🚀 Deployment Configuration

### Docker Deployment

```yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    env_file: .env.production
    environment:
      - ENVIRONMENT=production
    ports:
      - "8000:8000"
    
  database:
    image: postgres:15
    environment:
      - POSTGRES_DB=customer_support
      - POSTGRES_USER=app_user
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      
  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
```

### Environment-Specific Commands

```bash
# Development
export ENVIRONMENT=development
uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000

# Production
export ENVIRONMENT=production
gunicorn backend.app.main:app -w 4 -k uvicorn.workers.UvicornWorker

# Testing
export ENVIRONMENT=testing
pytest backend/tests/ -v
```

## 📊 Monitoring and Health Checks

### Health Check Endpoint

```bash
# Enable health checks
HEALTH_CHECK_ENABLED=true
HEALTH_CHECK_ENDPOINT=/health

# Health check interval (production)
HEALTH_CHECK_INTERVAL=30
HEALTH_CHECK_TIMEOUT=10
```

### Metrics Collection

```bash
# Prometheus metrics
PROMETHEUS_ENABLED=true
PROMETHEUS_PORT=9090
METRICS_ENDPOINT=/metrics

# Logging for monitoring
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE_PATH=/var/log/app/customer-support.log
```

## 🔧 Advanced Configuration

### Custom Environment Variables

```python
# Add custom settings in config.py
class Settings(BaseSettings):
    # ... existing settings ...
    
    # Custom setting
    my_custom_setting: str = Field(default="default_value")
    
    @validator("my_custom_setting")
    def validate_custom_setting(cls, v):
        # Custom validation logic
        return v
```

### Configuration Validation

```python
from backend.app.config import settings

# Validate configuration on startup
validation_result = settings.validate_configuration()
if not validation_result["valid"]:
    raise ValueError(f"Configuration issues: {validation_result['issues']}")

print(f"Configuration summary: {validation_result['configuration_summary']}")
```

### Directory Management

```python
# Settings automatically create required directories
settings.create_directories()

# Access path properties
chroma_path = settings.chroma_persist_path
upload_path = settings.upload_permanent_path
log_path = settings.log_file_path
```

## 🆘 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check DATABASE_URL format
   DATABASE_URL=postgresql://user:pass@host:port/database
   
   # For SQLite (development)
   DATABASE_URL=sqlite+aiosqlite:///./path/to/database.db
   ```

2. **Redis Connection Failed**
   ```bash
   # Check Redis URL
   REDIS_URL=redis://username:password@host:port/db
   
   # For development
   REDIS_URL=redis://localhost:6379/0
   ```

3. **ChromaDB Connection Failed**
   ```bash
   # Ensure ChromaDB is running
   # Check host and port
   CHROMA_HOST=localhost
   CHROMA_PORT=8001
   ```

4. **OpenAI API Key Issues**
   ```bash
   # Verify API key format
   OPENAI_API_KEY=sk-your-actual-api-key
   
   # For Azure OpenAI
   AZURE_OPENAI_API_KEY=your-azure-key
   AZURE_OPENAI_ENDPOINT=https://resource.openai.azure.com/
   ```

### Debug Configuration

```bash
# Enable debugging for troubleshooting
LOG_LEVEL=DEBUG
DEBUG_SQL=true
DEBUG_ASYNCIO=true

# Check configuration validation
# The backend will print validation issues on startup
```

## 📚 Additional Resources

- [Pydantic Settings Documentation](https://docs.pydantic.dev/latest/usage/pydantic_settings/)
- [FastAPI Configuration](https://fastapi.tiangolo.com/advanced/settings/)
- [PostgreSQL Connection Strings](https://www.postgresql.org/docs/current/libpq-connect.html)
- [Redis Configuration](https://redis.io/topics/config)
- [ChromaDB Documentation](https://docs.trychroma.com/)

## 🔄 Version History

- **v1.0.0**: Initial comprehensive configuration templates
  - Environment-specific configurations
  - Security best practices
  - Testing optimizations
  - Production deployment guidelines

## 🤝 Contributing

When adding new configuration options:

1. Add the variable to `.env.example` with description
2. Add to the Settings class in `backend/app/config.py`
3. Add appropriate validators
4. Update environment-specific files
5. Update this documentation

For questions or issues, please refer to the troubleshooting section or create an issue.