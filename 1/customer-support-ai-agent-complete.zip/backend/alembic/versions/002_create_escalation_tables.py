"""Create escalation tables

Revision ID: 002_create_escalation_tables
Revises: 001_create_initial_tables
Create Date: 2025-11-04 05:17:19.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy import Enum

# revision identifiers, used by Alembic.
revision = '002_create_escalation_tables'
down_revision = '001_create_initial_tables'
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create escalation-related tables."""
    
    # Create escalation queue table
    op.create_table('escalation_queues',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('department', sa.String(length=100), nullable=False),
        sa.Column('skill_requirements', sa.JSON(), nullable=True),
        sa.Column('business_hours', sa.JSON(), nullable=True),
        sa.Column('time_zone', sa.String(length=50), nullable=True),
        sa.Column('max_wait_time_minutes', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False),
        sa.Column('capacity', sa.Integer(), nullable=True),
        sa.Column('current_load', sa.Integer(), nullable=True),
        sa.Column('routing_rules', sa.JSON(), nullable=True),
        sa.Column('auto_assignment', sa.Boolean(), nullable=True),
        sa.Column('avg_resolution_time_minutes', sa.Float(), nullable=True),
        sa.Column('customer_satisfaction_score', sa.Float(), nullable=True),
        sa.Column('escalation_rate', sa.Float(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_escalation_queues_id'), 'escalation_queues', ['id'], unique=False)
    op.create_index(op.f('ix_escalation_queues_name'), 'escalation_queues', ['name'], unique=False)
    op.create_index(op.f('ix_escalation_queues_department'), 'escalation_queues', ['department'], unique=False)
    
    # Create escalation policy table
    op.create_table('escalation_policies',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('policy_type', sa.String(length=50), nullable=False),
        sa.Column('rules', sa.JSON(), nullable=False),
        sa.Column('thresholds', sa.JSON(), nullable=True),
        sa.Column('target_department', sa.String(length=100), nullable=False),
        sa.Column('target_queue_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('priority_score', sa.Integer(), nullable=True),
        sa.Column('time_conditions', sa.JSON(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False),
        sa.Column('version', sa.Integer(), nullable=True),
        sa.Column('trigger_count', sa.Integer(), nullable=True),
        sa.Column('success_rate', sa.Float(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.Column('last_triggered', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['target_queue_id'], ['escalation_queues.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_escalation_policies_id'), 'escalation_policies', ['id'], unique=False)
    op.create_index(op.f('ix_escalation_policies_name'), 'escalation_policies', ['name'], unique=False)
    op.create_index(op.f('ix_escalation_policies_policy_type'), 'escalation_policies', ['policy_type'], unique=False)
    op.create_index(op.f('ix_escalation_policies_is_active'), 'escalation_policies', ['is_active'], unique=False)
    
    # Create escalation table
    op.create_table('escalations',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('session_id', sa.String(), nullable=False),
        sa.Column('user_id', sa.String(), nullable=False),
        sa.Column('policy_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('queue_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('escalation_type', sa.Enum('AUTOMATIC', 'MANUAL', 'SCHEDULED', name='escalationtype'), nullable=True),
        sa.Column('status', sa.Enum('PENDING', 'ROUTED', 'IN_PROGRESS', 'RESOLVED', 'CANCELLED', 'ESCALATED_AGAIN', name='escalationstatus'), nullable=True),
        sa.Column('priority', sa.Enum('LOW', 'MEDIUM', 'HIGH', 'CRITICAL', 'URGENT', name='escalationpriority'), nullable=True),
        sa.Column('reasons', sa.JSON(), nullable=False),
        sa.Column('trigger_score', sa.Float(), nullable=False),
        sa.Column('trigger_context', sa.JSON(), nullable=True),
        sa.Column('assigned_agent_id', sa.String(), nullable=True),
        sa.Column('assigned_agent_name', sa.String(length=255), nullable=True),
        sa.Column('assigned_at', sa.DateTime(), nullable=True),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
        sa.Column('resolution_time_minutes', sa.Float(), nullable=True),
        sa.Column('resolution_notes', sa.Text(), nullable=True),
        sa.Column('customer_feedback', sa.Text(), nullable=True),
        sa.Column('satisfaction_score', sa.Integer(), nullable=True),
        sa.Column('response_time_minutes', sa.Float(), nullable=True),
        sa.Column('resolution_time_sla_minutes', sa.Integer(), nullable=True),
        sa.Column('escalation_trend', sa.String(length=50), nullable=True),
        sa.Column('complexity_score', sa.Float(), nullable=True),
        sa.Column('reintegration_needed', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(['policy_id'], ['escalation_policies.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['queue_id'], ['escalation_queues.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_escalations_id'), 'escalations', ['id'], unique=False)
    op.create_index(op.f('ix_escalations_session_id'), 'escalations', ['session_id'], unique=False)
    op.create_index(op.f('ix_escalations_user_id'), 'escalations', ['user_id'], unique=False)
    op.create_index(op.f('ix_escalations_status'), 'escalations', ['status'], unique=False)
    op.create_index(op.f('ix_escalations_priority'), 'escalations', ['priority'], unique=False)
    op.create_index(op.f('ix_escalations_created_at'), 'escalations', ['created_at'], unique=False)
    
    # Create escalation analytics table
    op.create_table('escalation_analytics',
        sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('escalation_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('date', sa.DateTime(), nullable=False),
        sa.Column('hour', sa.Integer(), nullable=False),
        sa.Column('escalation_count', sa.Integer(), nullable=True),
        sa.Column('avg_response_time_minutes', sa.Float(), nullable=True),
        sa.Column('avg_resolution_time_minutes', sa.Float(), nullable=True),
        sa.Column('customer_satisfaction_avg', sa.Float(), nullable=True),
        sa.Column('queue_utilization', sa.Float(), nullable=True),
        sa.Column('wait_time_avg_minutes', sa.Float(), nullable=True),
        sa.Column('abandoned_rate', sa.Float(), nullable=True),
        sa.Column('first_contact_resolution_rate', sa.Float(), nullable=True),
        sa.Column('escalation_resolution_rate', sa.Float(), nullable=True),
        sa.Column('callback_required_rate', sa.Float(), nullable=True),
        sa.Column('agent_performance_score', sa.Float(), nullable=True),
        sa.Column('customer_reachability_rate', sa.Float(), nullable=True),
        sa.Column('issue_complexity_avg', sa.Float(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(['escalation_id'], ['escalations.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_escalation_analytics_id'), 'escalation_analytics', ['id'], unique=False)
    op.create_index(op.f('ix_escalation_analytics_escalation_id'), 'escalation_analytics', ['escalation_id'], unique=False)
    op.create_index(op.f('ix_escalation_analytics_date'), 'escalation_analytics', ['date'], unique=False)
    
    # Create composite indexes for performance
    op.create_index('idx_escalations_session_status', 'escalations', ['session_id', 'status'])
    op.create_index('idx_escalations_user_created', 'escalations', ['user_id', 'created_at'])
    op.create_index('idx_escalations_queue_priority', 'escalations', ['queue_id', 'priority'])
    op.create_index('idx_escalations_created_status', 'escalations', ['created_at', 'status'])
    op.create_index('idx_analytics_date_hour', 'escalation_analytics', ['date', 'hour'])


def downgrade() -> None:
    """Drop escalation-related tables."""
    # Drop composite indexes
    op.drop_index('idx_analytics_date_hour', table_name='escalation_analytics')
    op.drop_index('idx_escalations_created_status', table_name='escalations')
    op.drop_index('idx_escalations_queue_priority', table_name='escalations')
    op.drop_index('idx_escalations_user_created', table_name='escalations')
    op.drop_index('idx_escalations_session_status', table_name='escalations')
    
    # Drop individual indexes
    op.drop_index(op.f('ix_escalation_analytics_date'), table_name='escalation_analytics')
    op.drop_index(op.f('ix_escalation_analytics_escalation_id'), table_name='escalation_analytics')
    op.drop_index(op.f('ix_escalation_analytics_id'), table_name='escalation_analytics')
    
    op.drop_index(op.f('ix_escalations_created_at'), table_name='escalations')
    op.drop_index(op.f('ix_escalations_priority'), table_name='escalations')
    op.drop_index(op.f('ix_escalations_status'), table_name='escalations')
    op.drop_index(op.f('ix_escalations_user_id'), table_name='escalations')
    op.drop_index(op.f('ix_escalations_session_id'), table_name='escalations')
    op.drop_index(op.f('ix_escalations_id'), table_name='escalations')
    
    op.drop_index(op.f('ix_escalation_policies_is_active'), table_name='escalation_policies')
    op.drop_index(op.f('ix_escalation_policies_policy_type'), table_name='escalation_policies')
    op.drop_index(op.f('ix_escalation_policies_name'), table_name='escalation_policies')
    op.drop_index(op.f('ix_escalation_policies_id'), table_name='escalation_policies')
    
    op.drop_index(op.f('ix_escalation_queues_department'), table_name='escalation_queues')
    op.drop_index(op.f('ix_escalation_queues_name'), table_name='escalation_queues')
    op.drop_index(op.f('ix_escalation_queues_id'), table_name='escalation_queues')
    
    # Drop tables
    op.drop_table('escalation_analytics')
    op.drop_table('escalations')
    op.drop_table('escalation_policies')
    op.drop_table('escalation_queues')