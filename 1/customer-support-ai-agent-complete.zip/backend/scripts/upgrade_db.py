#!/usr/bin/env python3
"""
Script to upgrade the database to the latest migration.

This script handles applying database migrations and ensuring the database schema is up to date.
"""

import sys
import os
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from alembic.config import Config
from alembic import command
from app.config import settings


def upgrade_database():
    """Upgrade database to the latest revision."""
    print("🚀 Upgrading database to latest revision...")
    print("=" * 50)
    
    # Create Alembic configuration
    alembic_cfg = Config()
    alembic_cfg.set_main_option("script_location", str(backend_dir / "alembic"))
    
    # Override database URL from settings
    if hasattr(settings, 'database_url') and settings.database_url:
        sync_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
        alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    
    try:
        # Get current revision
        current_revision = command.current(alembic_cfg, verbose=True)
        print(f"Current revision: {current_revision}")
        
        # Upgrade to head
        print("\nApplying migrations...")
        command.upgrade(alembic_cfg, "head", verbose=True)
        
        # Verify upgrade
        new_revision = command.current(alembic_cfg, verbose=True)
        print(f"New revision: {new_revision}")
        
        print("\n✅ Database upgrade completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Database upgrade failed: {e}")
        return False


def main():
    """Main function."""
    success = upgrade_database()
    
    if success:
        print("\n🎉 Database is now up to date!")
        return True
    else:
        print("\n💥 Database upgrade failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)