#!/usr/bin/env python3
"""
Command-line interface for backup and restore operations.

Provides CLI commands for:
- Database backup and restore
- Configuration management
- File system operations
- Scheduling and automation
- Monitoring and reporting

Usage:
    python backup_cli.py --help
    python backup_cli.py backup database --type full
    python backup_cli.py restore database --backup-id backup_123
    python backup_cli.py list backups --type database
    python backup_cli.py verify backup --backup-id backup_123
"""

import argparse
import asyncio
import json
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, List

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))

from app.utils.backup_restore_service import backup_service
from app.config import settings


def print_json(data: dict, pretty: bool = True):
    """Print data as JSON."""
    if pretty:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def print_success(message: str):
    """Print success message."""
    print(f"✅ {message}")


def print_error(message: str):
    """Print error message."""
    print(f"❌ {message}")


def print_warning(message: str):
    """Print warning message."""
    print(f"⚠️  {message}")


def print_info(message: str):
    """Print info message."""
    print(f"ℹ️  {message}")


async def cmd_backup_database(args):
    """Backup database command."""
    try:
        print_info("Starting database backup...")
        
        backup_id = await backup_service.create_database_backup(
            backup_type=args.type,
            compress=not args.no_compress,
            encrypt=args.encrypt,
            backup_name=args.name
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        print_success(f"Database backup completed: {backup_id}")
        print_json({
            "backup_id": backup_id,
            "backup_type": metadata.backup_type,
            "timestamp": metadata.timestamp.isoformat(),
            "database_type": metadata.database_type,
            "total_size": metadata.total_size,
            "file_count": metadata.file_count,
            "status": metadata.status
        }, pretty=not args.json)
        
    except Exception as e:
        print_error(f"Database backup failed: {e}")
        sys.exit(1)


async def cmd_backup_configuration(args):
    """Backup configuration command."""
    try:
        print_info("Starting configuration backup...")
        
        backup_id = await backup_service.create_configuration_backup(
            backup_name=args.name,
            compress=not args.no_compress,
            encrypt=args.encrypt
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        print_success(f"Configuration backup completed: {backup_id}")
        print_json({
            "backup_id": backup_id,
            "backup_type": metadata.backup_type,
            "timestamp": metadata.timestamp.isoformat(),
            "total_size": metadata.total_size,
            "file_count": metadata.file_count,
            "status": metadata.status
        }, pretty=not args.json)
        
    except Exception as e:
        print_error(f"Configuration backup failed: {e}")
        sys.exit(1)


async def cmd_backup_filesystem(args):
    """Backup file system command."""
    try:
        print_info("Starting file system backup...")
        
        backup_id = await backup_service.create_file_system_backup(
            backup_name=args.name,
            compress=not args.no_compress,
            encrypt=args.encrypt,
            include_patterns=args.include,
            exclude_patterns=args.exclude
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        print_success(f"File system backup completed: {backup_id}")
        print_json({
            "backup_id": backup_id,
            "backup_type": metadata.backup_type,
            "timestamp": metadata.timestamp.isoformat(),
            "total_size": metadata.total_size,
            "file_count": metadata.file_count,
            "status": metadata.status
        }, pretty=not args.json)
        
    except Exception as e:
        print_error(f"File system backup failed: {e}")
        sys.exit(1)


async def cmd_backup_full_system(args):
    """Backup full system command."""
    try:
        print_info("Starting full system backup...")
        
        backup_id = await backup_service.create_full_system_backup(
            backup_name=args.name,
            compress=not args.no_compress,
            encrypt=args.encrypt,
            include_configs=not args.skip_configs,
            include_files=not args.skip_files
        )
        
        metadata = backup_service.get_backup_info(backup_id)
        
        print_success(f"Full system backup completed: {backup_id}")
        print_json({
            "backup_id": backup_id,
            "backup_type": metadata.backup_type,
            "timestamp": metadata.timestamp.isoformat(),
            "total_size": metadata.total_size,
            "file_count": metadata.file_count,
            "status": metadata.status
        }, pretty=not args.json)
        
    except Exception as e:
        print_error(f"Full system backup failed: {e}")
        sys.exit(1)


async def cmd_restore_database(args):
    """Restore database command."""
    try:
        print_info(f"Starting database restore from backup: {args.backup_id}")
        
        result = await backup_service.restore_database(
            backup_id=args.backup_id,
            target_location=args.target,
            verify_checksum=not args.no_verify
        )
        
        print_success(f"Database restore completed: {result.restore_id}")
        print_json({
            "restore_id": result.restore_id,
            "status": result.status,
            "source_backup": result.source_backup,
            "target_location": result.target_location,
            "restored_files": result.restored_files,
            "restored_size": result.restored_size,
            "warnings": result.warnings,
            "errors": result.errors
        }, pretty=not args.json)
        
        if result.errors:
            for error in result.errors:
                print_error(f"Restore error: {error}")
        
        if result.warnings:
            for warning in result.warnings:
                print_warning(f"Restore warning: {warning}")
        
    except Exception as e:
        print_error(f"Database restore failed: {e}")
        sys.exit(1)


async def cmd_restore_configuration(args):
    """Restore configuration command."""
    try:
        print_info(f"Starting configuration restore from backup: {args.backup_id}")
        
        result = await backup_service.restore_configuration(
            backup_id=args.backup_id,
            verify_checksum=not args.no_verify
        )
        
        print_success(f"Configuration restore completed: {result.restore_id}")
        print_json({
            "restore_id": result.restore_id,
            "status": result.status,
            "source_backup": result.source_backup,
            "restored_files": result.restored_files,
            "restored_size": result.restored_size,
            "warnings": result.warnings,
            "errors": result.errors
        }, pretty=not args.json)
        
        if result.errors:
            for error in result.errors:
                print_error(f"Restore error: {error}")
        
        if result.warnings:
            for warning in result.warnings:
                print_warning(f"Restore warning: {warning}")
        
    except Exception as e:
        print_error(f"Configuration restore failed: {e}")
        sys.exit(1)


async def cmd_restore_filesystem(args):
    """Restore file system command."""
    try:
        print_info(f"Starting file system restore from backup: {args.backup_id}")
        
        result = await backup_service.restore_file_system(
            backup_id=args.backup_id,
            target_location=args.target,
            verify_checksum=not args.no_verify,
            selective_restore=args.selective
        )
        
        print_success(f"File system restore completed: {result.restore_id}")
        print_json({
            "restore_id": result.restore_id,
            "status": result.status,
            "source_backup": result.source_backup,
            "target_location": result.target_location,
            "restored_files": result.restored_files,
            "restored_size": result.restored_size,
            "warnings": result.warnings,
            "errors": result.errors
        }, pretty=not args.json)
        
        if result.errors:
            for error in result.errors:
                print_error(f"Restore error: {error}")
        
        if result.warnings:
            for warning in result.warnings:
                print_warning(f"Restore warning: {warning}")
        
    except Exception as e:
        print_error(f"File system restore failed: {e}")
        sys.exit(1)


def cmd_list_backups(args):
    """List backups command."""
    try:
        backups = backup_service.get_backup_list(backup_type=args.type)
        
        if args.limit:
            backups = backups[:args.limit]
        
        if args.json:
            backups_data = []
            for backup in backups:
                backups_data.append({
                    "backup_id": backup.backup_id,
                    "backup_type": backup.backup_type,
                    "timestamp": backup.timestamp.isoformat(),
                    "database_type": backup.database_type,
                    "compression": backup.compression,
                    "encrypted": backup.encrypted,
                    "total_size": backup.total_size,
                    "file_count": backup.file_count,
                    "status": backup.status,
                    "error_message": backup.error_message
                })
            print_json({"backups": backups_data, "total": len(backups_data)}, pretty=not args.json)
        else:
            print(f"Found {len(backups)} backup(s):")
            print("-" * 100)
            print(f"{'ID':<25} {'Type':<15} {'Timestamp':<20} {'Size':<12} {'Files':<8} {'Status':<10}")
            print("-" * 100)
            
            for backup in backups:
                size_str = f"{backup.total_size / 1024 / 1024:.1f}MB" if backup.total_size > 0 else "0B"
                timestamp_str = backup.timestamp.strftime("%Y-%m-%d %H:%M:%S")
                
                status_icon = "✅" if backup.status == "completed" else "❌"
                
                print(f"{backup.backup_id:<25} {backup.backup_type:<15} {timestamp_str:<20} {size_str:<12} {backup.file_count:<8} {status_icon} {backup.status:<6}")
    
    except Exception as e:
        print_error(f"Failed to list backups: {e}")
        sys.exit(1)


def cmd_verify_backup(args):
    """Verify backup command."""
    try:
        print_info(f"Verifying backup: {args.backup_id}")
        
        is_valid = asyncio.run(backup_service.verify_backup(args.backup_id))
        
        if is_valid:
            print_success(f"Backup verification passed: {args.backup_id}")
        else:
            print_error(f"Backup verification failed: {args.backup_id}")
            sys.exit(1)
    
    except Exception as e:
        print_error(f"Backup verification failed: {e}")
        sys.exit(1)


def cmd_cleanup_backups(args):
    """Cleanup backups command."""
    try:
        print_info(f"Cleaning up backups older than {args.days} days...")
        
        cleaned_up = backup_service.cleanup_old_backups(retention_days=args.days)
        
        print_success(f"Cleanup completed: {cleaned_up} backups removed")
    
    except Exception as e:
        print_error(f"Cleanup failed: {e}")
        sys.exit(1)


def cmd_export_report(args):
    """Export report command."""
    try:
        print_info("Exporting backup report...")
        
        report_path = backup_service.export_backup_report(args.output)
        
        print_success(f"Report exported to: {report_path}")
    
    except Exception as e:
        print_error(f"Report export failed: {e}")
        sys.exit(1)


def cmd_health_report(args):
    """Health report command."""
    try:
        print_info("Generating system health report...")
        
        health_report = backup_service.get_system_health_report()
        
        print_json(health_report, pretty=not args.json)
        
        # Print summary
        if not args.json:
            print("\n" + "="*50)
            print("HEALTH REPORT SUMMARY")
            print("="*50)
            
            status = health_report.get("backup_service_status", "unknown")
            if status == "healthy":
                print_success(f"Backup service status: {status}")
            else:
                print_warning(f"Backup service status: {status}")
            
            # Print recommendations
            recommendations = health_report.get("recommendations", [])
            if recommendations:
                print("\nRecommendations:")
                for i, rec in enumerate(recommendations, 1):
                    print(f"  {i}. {rec}")
            
            # Print backup statistics
            backup_counts = health_report.get("backup_counts", {})
            print(f"\nBackup Statistics:")
            print(f"  Total backups: {backup_counts.get('total', 0)}")
            print(f"  Completed: {backup_counts.get('completed', 0)}")
            print(f"  Failed: {backup_counts.get('failed', 0)}")
            
            # Print disk usage
            disk_usage = health_report.get("disk_usage", {})
            if disk_usage:
                print(f"\nDisk Usage:")
                for directory, usage in disk_usage.items():
                    print(f"  {directory}: {usage['total_size_mb']}MB ({usage['file_count']} files)")
    
    except Exception as e:
        print_error(f"Health report failed: {e}")
        sys.exit(1)


async def cmd_disaster_recovery(args):
    """Disaster recovery command."""
    try:
        print_info(f"Starting disaster recovery restore with {len(args.backup_ids)} backups...")
        
        results = await backup_service.disaster_recovery_restore(
            backup_ids=args.backup_ids,
            validate_before_restore=not args.no_validate,
            create_recovery_snapshot=not args.no_snapshot
        )
        
        # Print results
        print_success("Disaster recovery restore completed")
        print_json({
            "total_operations": len(results),
            "successful_operations": sum(1 for r in results.values() if r.status == "completed"),
            "failed_operations": sum(1 for r in results.values() if r.status == "failed"),
            "results": {bid: {
                "restore_id": r.restore_id,
                "status": r.status,
                "restored_files": r.restored_files,
                "restored_size": r.restored_size,
                "warnings": r.warnings,
                "errors": r.errors
            } for bid, r in results.items()}
        }, pretty=not args.json)
        
    except Exception as e:
        print_error(f"Disaster recovery failed: {e}")
        sys.exit(1)


def create_parser():
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        description="Backup and Restore CLI Utility",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create database backup
  %(prog)s backup database --type full --compress
  
  # Create full system backup
  %(prog)s backup full-system --name "backup_$(date +%Y%m%d)"
  
  # Restore database
  %(prog)s restore database --backup-id backup_123 --target /path/to/db
  
  # List all backups
  %(prog)s list backups --type database --limit 10
  
  # Verify backup
  %(prog)s verify backup --backup-id backup_123
  
  # Export report
  %(prog)s export report --output backup_report.csv
  
  # Disaster recovery
  %(prog)s disaster-recovery --backup-ids backup1 backup2 backup3
        """
    )
    
    # Global arguments
    parser.add_argument("--json", action="store_true", help="Output in JSON format")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Backup subcommands
    backup_parser = subparsers.add_parser("backup", help="Create backups")
    backup_subparsers = backup_parser.add_subparsers(dest="backup_type", help="Backup types")
    
    # Database backup
    db_backup_parser = backup_subparsers.add_parser("database", help="Backup database")
    db_backup_parser.add_argument("--type", choices=["full", "incremental"], default="full", help="Backup type")
    db_backup_parser.add_argument("--name", help="Custom backup name")
    db_backup_parser.add_argument("--compress", action="store_true", help="Enable compression")
    db_backup_parser.add_argument("--no-compress", action="store_true", help="Disable compression")
    db_backup_parser.add_argument("--encrypt", action="store_true", help="Enable encryption")
    db_backup_parser.set_defaults(func=cmd_backup_database)
    
    # Configuration backup
    config_backup_parser = backup_subparsers.add_parser("configuration", help="Backup configuration")
    config_backup_parser.add_argument("--name", help="Custom backup name")
    config_backup_parser.add_argument("--compress", action="store_true", help="Enable compression")
    config_backup_parser.add_argument("--no-compress", action="store_true", help="Disable compression")
    config_backup_parser.add_argument("--encrypt", action="store_true", help="Enable encryption")
    config_backup_parser.set_defaults(func=cmd_backup_configuration)
    
    # File system backup
    fs_backup_parser = backup_subparsers.add_parser("filesystem", help="Backup file system")
    fs_backup_parser.add_argument("--name", help="Custom backup name")
    fs_backup_parser.add_argument("--compress", action="store_true", help="Enable compression")
    fs_backup_parser.add_argument("--no-compress", action="store_true", help="Disable compression")
    fs_backup_parser.add_argument("--encrypt", action="store_true", help="Enable encryption")
    fs_backup_parser.add_argument("--include", nargs="*", help="Include patterns")
    fs_backup_parser.add_argument("--exclude", nargs="*", help="Exclude patterns")
    fs_backup_parser.set_defaults(func=cmd_backup_filesystem)
    
    # Full system backup
    full_backup_parser = backup_subparsers.add_parser("full-system", help="Backup full system")
    full_backup_parser.add_argument("--name", help="Custom backup name")
    full_backup_parser.add_argument("--compress", action="store_true", help="Enable compression")
    full_backup_parser.add_argument("--no-compress", action="store_true", help="Disable compression")
    full_backup_parser.add_argument("--encrypt", action="store_true", help="Enable encryption")
    full_backup_parser.add_argument("--skip-configs", action="store_true", help="Skip configuration backup")
    full_backup_parser.add_argument("--skip-files", action="store_true", help="Skip file system backup")
    full_backup_parser.set_defaults(func=cmd_backup_full_system)
    
    # Restore subcommands
    restore_parser = subparsers.add_parser("restore", help="Restore from backups")
    restore_subparsers = restore_parser.add_subparsers(dest="restore_type", help="Restore types")
    
    # Database restore
    db_restore_parser = restore_subparsers.add_parser("database", help="Restore database")
    db_restore_parser.add_argument("--backup-id", required=True, help="Backup ID to restore")
    db_restore_parser.add_argument("--target", help="Target database location")
    db_restore_parser.add_argument("--no-verify", action="store_true", help="Skip checksum verification")
    db_restore_parser.set_defaults(func=cmd_restore_database)
    
    # Configuration restore
    config_restore_parser = restore_subparsers.add_parser("configuration", help="Restore configuration")
    config_restore_parser.add_argument("--backup-id", required=True, help="Backup ID to restore")
    config_restore_parser.add_argument("--no-verify", action="store_true", help="Skip checksum verification")
    config_restore_parser.set_defaults(func=cmd_restore_configuration)
    
    # File system restore
    fs_restore_parser = restore_subparsers.add_parser("filesystem", help="Restore file system")
    fs_restore_parser.add_argument("--backup-id", required=True, help="Backup ID to restore")
    fs_restore_parser.add_argument("--target", help="Target location for restore")
    fs_restore_parser.add_argument("--no-verify", action="store_true", help="Skip checksum verification")
    fs_restore_parser.add_argument("--selective", nargs="*", help="Specific files/directories to restore")
    fs_restore_parser.set_defaults(func=cmd_restore_filesystem)
    
    # List command
    list_parser = subparsers.add_parser("list", help="List backups")
    list_subparsers = list_parser.add_subparsers(dest="list_type", help="List types")
    
    backups_list_parser = list_subparsers.add_parser("backups", help="List backups")
    backups_list_parser.add_argument("--type", help="Filter by backup type")
    backups_list_parser.add_argument("--limit", type=int, help="Limit number of results")
    backups_list_parser.set_defaults(func=cmd_list_backups)
    
    # Verify command
    verify_parser = subparsers.add_parser("verify", help="Verify backups")
    verify_subparsers = verify_parser.add_subparsers(dest="verify_type", help="Verify types")
    
    backup_verify_parser = verify_subparsers.add_parser("backup", help="Verify backup")
    backup_verify_parser.add_argument("--backup-id", required=True, help="Backup ID to verify")
    backup_verify_parser.set_defaults(func=cmd_verify_backup)
    
    # Cleanup command
    cleanup_parser = subparsers.add_parser("cleanup", help="Cleanup old backups")
    cleanup_parser.add_argument("--days", type=int, default=30, help="Retention period in days")
    cleanup_parser.set_defaults(func=cmd_cleanup_backups)
    
    # Export command
    export_parser = subparsers.add_parser("export", help="Export data")
    export_subparsers = export_parser.add_subparsers(dest="export_type", help="Export types")
    
    report_export_parser = export_subparsers.add_parser("report", help="Export backup report")
    report_export_parser.add_argument("--output", help="Output file path")
    report_export_parser.set_defaults(func=cmd_export_report)
    
    # Health command
    health_parser = subparsers.add_parser("health", help="System health report")
    health_parser.set_defaults(func=cmd_health_report)
    
    # Disaster recovery command
    dr_parser = subparsers.add_parser("disaster-recovery", help="Disaster recovery restore")
    dr_parser.add_argument("--backup-ids", nargs="+", required=True, help="Backup IDs to restore")
    dr_parser.add_argument("--no-validate", action="store_true", help="Skip backup validation")
    dr_parser.add_argument("--no-snapshot", action="store_true", help="Skip recovery snapshot")
    dr_parser.set_defaults(func=cmd_disaster_recovery)
    
    return parser


def main():
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Set up logging
    if args.debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)
    
    # Validate dependencies
    try:
        from app.config import settings
        # Check database connection
        if not settings:
            print_error("Failed to load application configuration")
            sys.exit(1)
    except Exception as e:
        print_error(f"Failed to initialize: {e}")
        sys.exit(1)
    
    # Execute command
    if hasattr(args, 'func'):
        if asyncio.iscoroutinefunction(args.func):
            asyncio.run(args.func(args))
        else:
            args.func(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
