#!/usr/bin/env python3
"""
Script to completely reset the database.

This script drops all tables and recreates the database from scratch.
USE WITH EXTREME CAUTION - THIS WILL DELETE ALL DATA!
"""

import sys
import os
import argparse
from pathlib import Path
import sqlite3

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from app.config import settings


def reset_database(force: bool = False, backup: bool = True):
    """Reset the database to a clean state."""
    print("🚀 Resetting database to clean state...")
    print("=" * 50)
    
    if not force:
        print("⚠️  WARNING: This will DELETE ALL DATA in the database!")
        print("This action cannot be undone.")
        response = input("Type 'YES I AM SURE' to confirm: ")
        if response != "YES I AM SURE":
            print("Database reset cancelled.")
            return False
    
    # Get database path
    if hasattr(settings, 'database_url') and settings.database_url:
        if "sqlite" in settings.database_url.lower():
            # Extract SQLite database path
            db_path = settings.database_url.replace("sqlite+aiosqlite://", "").replace("sqlite://", "")
            if db_path.startswith("./"):
                db_path = backend_dir / db_path[2:]
            elif db_path.startswith("."):
                db_path = backend_dir / db_path
        else:
            print(f"❌ Cannot reset non-SQLite database: {settings.database_url}")
            return False
    else:
        db_path = backend_dir / "data" / "sqlite" / "customer_support.db"
    
    db_path = Path(db_path)
    
    # Create backup if requested and database exists
    if backup and db_path.exists():
        import shutil
        backup_path = db_path.parent / f"{db_path.name}.backup"
        print(f"Creating backup at: {backup_path}")
        shutil.copy2(db_path, backup_path)
        print("✅ Backup created successfully!")
    
    try:
        # Remove database file
        if db_path.exists():
            print(f"Removing database file: {db_path}")
            db_path.unlink()
        
        # Remove Alembic version table by removing the database
        # This will be recreated when we run the migrations
        
        print("✅ Database file removed successfully!")
        print("\n🎯 Database has been reset.")
        print("Run 'python scripts/upgrade_db.py' to recreate the schema.")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Failed to reset database: {e}")
        return False


def clean_migrations(force: bool = False):
    """Remove all migration files except the initial one."""
    print("🧹 Cleaning migration files...")
    
    if not force:
        print("⚠️  WARNING: This will remove all migration files!")
        print("Make sure you've backed up any important migrations.")
        response = input("Are you sure you want to continue? (yes/no): ")
        if response.lower() != "yes":
            print("Migration cleanup cancelled.")
            return False
    
    versions_dir = backend_dir / "alembic" / "versions"
    
    if not versions_dir.exists():
        print("No migration files found.")
        return True
    
    # Keep only essential migration files
    keep_files = ["001_create_initial_tables.py"]
    removed_count = 0
    
    for file_path in versions_dir.glob("*.py"):
        if file_path.name not in keep_files:
            print(f"Removing migration file: {file_path.name}")
            file_path.unlink()
            removed_count += 1
    
    if removed_count > 0:
        print(f"✅ Removed {removed_count} migration files!")
    else:
        print("✅ No migration files to remove!")
    
    return True


def main():
    """Main function."""
    parser = argparse.ArgumentParser(
        description="Reset database to clean state. USE WITH EXTREME CAUTION!",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Interactive reset with backup
  python scripts/reset_database.py

  # Force reset without confirmation
  python scripts/reset_database.py --force

  # Reset without creating backup
  python scripts/reset_database.py --no-backup

  # Clean migration files
  python scripts/reset_database.py --clean-migrations
        """
    )
    
    parser.add_argument("--force", "-f", action="store_true",
                       help="Skip confirmation prompts")
    parser.add_argument("--no-backup", action="store_true",
                       help="Don't create backup before reset")
    parser.add_argument("--clean-migrations", action="store_true",
                       help="Clean migration files (keeps initial migration)")
    
    args = parser.parse_args()
    
    success = True
    
    if args.clean_migrations:
        success = clean_migrations(args.force)
    else:
        success = reset_database(args.force, not args.no_backup)
    
    if success:
        print("\n🎉 Operation completed successfully!")
        return True
    else:
        print("\n💥 Operation failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)