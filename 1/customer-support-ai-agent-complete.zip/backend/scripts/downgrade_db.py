#!/usr/bin/env python3
"""
Script to downgrade the database.

This script handles reverting database migrations and rolling back database schema changes.
"""

import sys
import os
from pathlib import Path
import argparse

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from alembic.config import Config
from alembic import command
from app.config import settings


def downgrade_database(revision: str = "-1", force: bool = False):
    """Downgrade database to the specified revision."""
    print(f"🚀 Downgrading database to revision: {revision}")
    print("=" * 50)
    
    if not force and revision == "-1":
        print("⚠️  WARNING: You are about to downgrade the database!")
        print("This will lose ALL data created after the target revision.")
        response = input("Are you sure you want to continue? (yes/no): ")
        if response.lower() != "yes":
            print("Downgrade cancelled.")
            return False
    
    # Create Alembic configuration
    alembic_cfg = Config()
    alembic_cfg.set_main_option("script_location", str(backend_dir / "alembic"))
    
    # Override database URL from settings
    if hasattr(settings, 'database_url') and settings.database_url:
        sync_url = settings.database_url.replace("+aiosqlite", "").replace("sqlite+aiosqlite://", "sqlite://")
        alembic_cfg.set_main_option("sqlalchemy.url", sync_url)
    
    try:
        # Get current revision
        current_revision = command.current(alembic_cfg, verbose=True)
        print(f"Current revision: {current_revision}")
        
        # Downgrade
        print(f"\nReverting migrations to {revision}...")
        command.downgrade(alembic_cfg, revision, verbose=True)
        
        # Verify downgrade
        new_revision = command.current(alembic_cfg, verbose=True)
        print(f"New revision: {new_revision}")
        
        print("\n✅ Database downgrade completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Database downgrade failed: {e}")
        return False


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Downgrade database migrations")
    parser.add_argument("--revision", "-r", default="-1", 
                       help="Revision to downgrade to (default: -1 for previous)")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Skip confirmation prompt")
    
    args = parser.parse_args()
    
    success = downgrade_database(args.revision, args.force)
    
    if success:
        print("\n🎉 Database downgrade completed!")
        return True
    else:
        print("\n💥 Database downgrade failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)