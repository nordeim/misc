#!/usr/bin/env python3
"""
Validation test script for the comprehensive error handling and validation system.

This script tests:
1. All validation components can be imported
2. Basic validation functionality works
3. Security validation detects threats
4. API documentation generation works
5. Monitoring system initializes properly
"""

import sys
import asyncio
from datetime import datetime
from typing import Dict, Any

def test_imports():
    """Test that all validation components can be imported."""
    print("Testing imports...")
    
    try:
        # Test validation imports
        from app.validation import (
            RequestValidator,
            ValidationConfig,
            SchemaValidator,
            BusinessLogicValidator,
            SecurityValidator,
            validate_request,
            validate_response,
            validate_business_rules,
            sanitize_input,
            validate_user_registration,
            validate_user_login,
            validate_chat_message
        )
        print("✓ Validation components imported successfully")
        
        # Test documentation imports
        from app.docs.api_documentation import (
            EnhancedAPIDocumentation,
            setup_enhanced_api_docs,
            APIExample,
            ErrorCodeInfo,
            APIEndpointDoc
        )
        print("✓ Documentation components imported successfully")
        
        # Test monitoring imports
        from app.monitoring.enhanced_monitoring import (
            APIMonitoringMiddleware,
            APIMetricsCollector,
            APIAnalyticsCollector,
            AlertingSystem,
            HealthMonitoringSystem,
            setup_api_monitoring,
            create_analytics_endpoints
        )
        print("✓ Monitoring components imported successfully")
        
        return True
        
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False

def test_schema_validation():
    """Test schema validation functionality."""
    print("\nTesting schema validation...")
    
    try:
        from app.validation.schema_validator import (
            SchemaValidator,
            ValidationRule,
            ValidationType
        )
        
        validator = SchemaValidator()
        
        # Test email validation
        result = validator.validate_field("test@example.com", ValidationType.EMAIL)
        assert result.is_valid, "Valid email should pass validation"
        print("✓ Email validation works correctly")
        
        # Test invalid email
        result = validator.validate_field("invalid-email", ValidationType.EMAIL)
        assert not result.is_valid, "Invalid email should fail validation"
        print("✓ Invalid email correctly rejected")
        
        # Test password validation
        result = validator.validate_field("StrongPass123!", ValidationType.PASSWORD)
        assert result.is_valid, "Strong password should pass validation"
        print("✓ Password validation works correctly")
        
        return True
        
    except Exception as e:
        print(f"✗ Schema validation test failed: {e}")
        return False

def test_security_validation():
    """Test security validation functionality."""
    print("\nTesting security validation...")
    
    try:
        from app.validation.security_validator_enhanced import (
            SecurityValidator,
            SecurityCheckType,
            SecurityThreatLevel
        )
        
        validator = SecurityValidator()
        
        # Test XSS detection
        malicious_input = "<script>alert('xss')</script>"
        result = validator.validate_input({"message": malicious_input})
        
        xss_issues = [issue for issue in result.issues 
                     if issue.check_type == SecurityCheckType.XSS]
        assert len(xss_issues) > 0, "XSS pattern should be detected"
        print("✓ XSS detection works correctly")
        
        # Test SQL injection detection
        sql_injection = "'; DROP TABLE users; --"
        result = validator.validate_input({"query": sql_injection})
        
        sql_issues = [issue for issue in result.issues 
                     if issue.check_type == SecurityCheckType.SQL_INJECTION]
        assert len(sql_issues) > 0, "SQL injection should be detected"
        print("✓ SQL injection detection works correctly")
        
        # Test clean input
        clean_input = "Hello world"
        result = validator.validate_input({"message": clean_input})
        assert result.is_safe, "Clean input should be safe"
        print("✓ Clean input validation works correctly")
        
        return True
        
    except Exception as e:
        print(f"✗ Security validation test failed: {e}")
        return False

def test_business_validation():
    """Test business logic validation."""
    print("\nTesting business validation...")
    
    try:
        from app.validation.business_validator import (
            BusinessLogicValidator,
            ValidationSeverity,
            build_user_context
        )
        
        validator = BusinessLogicValidator()
        
        # Test user context
        user_data = {"username": "testuser", "email": "test@example.com"}
        context = build_user_context(user_data)
        
        assert "user" in context, "Context should contain user data"
        assert "timestamp" in context, "Context should contain timestamp"
        print("✓ User context building works correctly")
        
        # Test business rules
        data = {"username": "testuser", "password": "Weak"}
        business_issues = validator.validate_business_rules(
            data, context, ["password_strength"]
        )
        
        password_issues = [issue for issue in business_issues 
                         if "password" in issue.message.lower()]
        assert len(password_issues) > 0, "Weak password should trigger validation"
        print("✓ Business rule validation works correctly")
        
        return True
        
    except Exception as e:
        print(f"✗ Business validation test failed: {e}")
        return False

def test_api_documentation():
    """Test API documentation generation."""
    print("\nTesting API documentation...")
    
    try:
        from app.docs.api_documentation import EnhancedAPIDocumentation
        
        doc_generator = EnhancedAPIDocumentation()
        
        # Test endpoint documentation loading
        assert len(doc_generator.endpoint_docs) > 0, "Should have endpoint documentation"
        print("✓ Endpoint documentation loaded")
        
        # Test error codes loading
        assert len(doc_generator.error_codes) > 0, "Should have error code documentation"
        print("✓ Error code documentation loaded")
        
        # Test version information
        assert len(doc_generator.api_versions) > 0, "Should have version information"
        print("✓ API version information loaded")
        
        # Test HTML generation
        html_content = doc_generator.create_api_documentation_page()
        assert len(html_content) > 1000, "Should generate substantial HTML content"
        assert "<html" in html_content.lower(), "Should contain HTML structure"
        print("✓ HTML documentation generation works")
        
        return True
        
    except Exception as e:
        print(f"✗ API documentation test failed: {e}")
        return False

def test_monitoring_system():
    """Test monitoring system initialization."""
    print("\nTesting monitoring system...")
    
    try:
        from app.monitoring.enhanced_monitoring import (
            APIMetricsCollector,
            APIAnalyticsCollector,
            AlertingSystem
        )
        
        # Test metrics collector
        metrics = APIMetricsCollector()
        metrics.increment_counter("test_counter", labels={"test": "value"})
        metrics.set_gauge("test_gauge", 42.0, labels={"test": "value"})
        
        retrieved_metrics = metrics.get_metrics()
        assert "counters" in retrieved_metrics, "Should have counter metrics"
        assert "gauges" in retrieved_metrics, "Should have gauge metrics"
        print("✓ Metrics collection works correctly")
        
        # Test analytics collector
        analytics = APIAnalyticsCollector()
        from app.monitoring.enhanced_monitoring import APIAnalytics
        
        # Add a mock request
        mock_request = APIAnalytics(
            endpoint="/test",
            method="GET",
            timestamp=datetime.utcnow(),
            response_time=0.1,
            status_code=200
        )
        analytics.record_request(mock_request)
        
        unique_endpoints = analytics.get_unique_endpoints()
        assert "/test" in unique_endpoints, "Should track unique endpoints"
        print("✓ Analytics collection works correctly")
        
        # Test alerting system
        alerts = AlertingSystem()
        alerts.trigger_alert(
            "test_alert",
            "warning",  # Simple string for testing
            "Test alert message",
            {"test": "data"}
        )
        
        pending_alerts = alerts.get_pending_alerts()
        assert len(pending_alerts) > 0, "Should have pending alerts"
        print("✓ Alerting system works correctly")
        
        return True
        
    except Exception as e:
        print(f"✗ Monitoring system test failed: {e}")
        return False

def test_validation_decorators():
    """Test validation decorators."""
    print("\nTesting validation decorators...")
    
    try:
        from app.validation.validation_decorators import (
            ValidateRequest,
            ValidationMode
        )
        from pydantic import BaseModel
        
        # Create a simple test schema
        class TestSchema(BaseModel):
            name: str
            email: str
        
        # Test decorator creation
        @ValidateRequest(
            schema=TestSchema,
            mode=ValidationMode.STRICT,
            security_check=True
        )
        async def test_endpoint(request_data: TestSchema):
            return {"message": "success"}
        
        print("✓ Validation decorator creation works")
        
        # Test convenience decorators
        from app.validation.validation_decorators import (
            validate_user_registration,
            validate_user_login,
            validate_chat_message
        )
        
        print("✓ Convenience decorators imported successfully")
        
        return True
        
    except Exception as e:
        print(f"✗ Validation decorators test failed: {e}")
        return False

def test_configuration():
    """Test configuration handling."""
    print("\nTesting configuration...")
    
    try:
        from app.config import settings
        
        # Test that settings are accessible
        assert hasattr(settings, 'app_name'), "Should have app_name setting"
        assert hasattr(settings, 'app_version'), "Should have app_version setting"
        assert hasattr(settings, 'environment'), "Should have environment setting"
        print("✓ Configuration settings accessible")
        
        # Test environment detection
        env = settings.environment
        assert env in ['development', 'production', 'testing'], "Should have valid environment"
        print(f"✓ Environment detected: {env}")
        
        return True
        
    except Exception as e:
        print(f"✗ Configuration test failed: {e}")
        return False

def main():
    """Run all validation tests."""
    print("=" * 60)
    print("COMPREHENSIVE ERROR HANDLING & VALIDATION TEST")
    print("=" * 60)
    
    tests = [
        ("Import Test", test_imports),
        ("Schema Validation", test_schema_validation),
        ("Security Validation", test_security_validation),
        ("Business Validation", test_business_validation),
        ("API Documentation", test_api_documentation),
        ("Monitoring System", test_monitoring_system),
        ("Validation Decorators", test_validation_decorators),
        ("Configuration", test_configuration),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n{'='*20} {test_name} {'='*20}")
        try:
            if test_func():
                passed += 1
                print(f"✓ {test_name} PASSED")
            else:
                failed += 1
                print(f"✗ {test_name} FAILED")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} FAILED with exception: {e}")
    
    print(f"\n{'='*60}")
    print(f"TEST SUMMARY: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 ALL TESTS PASSED! The comprehensive error handling and validation system is working correctly.")
        return 0
    else:
        print(f"⚠️  {failed} tests failed. Please check the implementation.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
