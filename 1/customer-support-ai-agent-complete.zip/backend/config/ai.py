"""
AI service configuration module.

This module provides specialized AI/LLM configuration management with
support for multiple providers, model settings, and AI-specific validation.
"""

import logging
import time
from typing import Optional, List, Dict, Any, Union
from enum import Enum

from pydantic import BaseSettings, Field, validator, SecretStr


logger = logging.getLogger(__name__)


class LLMProvider(str, Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    ANTHROPIC = "anthropic"
    COHERE = "cohere"
    HUGGINGFACE = "huggingface"
    LOCAL = "local"


class EmbeddingProvider(str, Enum):
    """Supported embedding providers."""
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    HUGGINGFACE = "huggingface"
    SENTENCE_TRANSFORMERS = "sentence_transformers"
    LOCAL = "local"


class AIConfig(BaseSettings):
    """
    AI service configuration with support for multiple providers.
    
    This class handles all AI-related configuration including LLM providers,
    embedding models, RAG settings, and AI-specific validations.
    """
    
    # Primary LLM configuration
    llm_provider: str = Field(default="openai", description="Primary LLM provider")
    llm_enabled: bool = Field(default=True, description="Enable LLM functionality")
    
    # OpenAI configuration
    openai_api_key: Optional[SecretStr] = Field(default=None, description="OpenAI API key")
    openai_model: str = Field(default="gpt-3.5-turbo", description="OpenAI model name")
    openai_max_tokens: int = Field(default=2000, ge=1, description="OpenAI max tokens")
    openai_temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="OpenAI temperature")
    openai_timeout: int = Field(default=60, ge=1, description="OpenAI timeout in seconds")
    openai_max_retries: int = Field(default=3, ge=0, description="OpenAI max retries")
    openai_retry_delay: float = Field(default=1.0, ge=0.1, description="OpenAI retry delay")
    
    # Azure OpenAI configuration
    azure_openai_api_key: Optional[SecretStr] = Field(default=None, description="Azure OpenAI API key")
    azure_openai_endpoint: Optional[str] = Field(default=None, description="Azure OpenAI endpoint")
    azure_openai_deployment_name: Optional[str] = Field(default=None, description="Azure OpenAI deployment name")
    azure_openai_api_version: str = Field(default="2024-02-01", description="Azure OpenAI API version")
    azure_openai_timeout: int = Field(default=60, ge=1, description="Azure OpenAI timeout")
    
    # Anthropic configuration
    anthropic_api_key: Optional[SecretStr] = Field(default=None, description="Anthropic API key")
    anthropic_model: str = Field(default="claude-3-sonnet-20240229", description="Anthropic model name")
    anthropic_max_tokens: int = Field(default=2000, ge=1, description="Anthropic max tokens")
    anthropic_timeout: int = Field(default=60, ge=1, description="Anthropic timeout")
    
    # Cohere configuration
    cohere_api_key: Optional[SecretStr] = Field(default=None, description="Cohere API key")
    cohere_model: str = Field(default="command", description="Cohere model name")
    cohere_max_tokens: int = Field(default=2000, ge=1, description="Cohere max tokens")
    
    # Local model configuration
    local_model_path: Optional[str] = Field(default=None, description="Path to local model")
    local_model_type: str = Field(default="transformers", description="Local model type")
    local_model_device: str = Field(default="cpu", description="Local model device")
    local_model_load_in_8bit: bool = Field(default=False, description="Load model in 8-bit precision")
    local_model_load_in_4bit: bool = Field(default=False, description="Load model in 4-bit precision")
    
    # Embedding configuration
    embedding_provider: str = Field(default="sentence_transformers", description="Embedding provider")
    embedding_model: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2",
        description="Embedding model for vector generation"
    )
    embedding_dimension: int = Field(default=384, ge=1, description="Embedding dimension")
    embedding_batch_size: int = Field(default=32, ge=1, description="Embedding batch size")
    embedding_max_sequence_length: int = Field(default=512, ge=1, description="Max sequence length for embeddings")
    
    # OpenAI Embeddings
    openai_embedding_model: str = Field(default="text-embedding-ada-002", description="OpenAI embedding model")
    openai_embedding_dimensions: int = Field(default=1536, ge=1, description="OpenAI embedding dimensions")
    
    # Azure OpenAI Embeddings
    azure_openai_embedding_deployment: Optional[str] = Field(default=None, description="Azure OpenAI embedding deployment")
    
    # HuggingFace configuration
    huggingface_api_key: Optional[SecretStr] = Field(default=None, description="HuggingFace API key")
    huggingface_model_repo: Optional[str] = Field(default=None, description="HuggingFace model repository")
    
    # RAG (Retrieval-Augmented Generation) configuration
    rag_enabled: bool = Field(default=True, description="Enable RAG functionality")
    rag_return_metadata: bool = Field(default=True, description="Return metadata in RAG results")
    rag_max_chunks_per_query: int = Field(default=5, ge=1, description="Max chunks per query")
    rag_chunk_size: int = Field(default=1000, ge=100, description="RAG chunk size")
    rag_chunk_overlap: int = Field(default=200, ge=0, description="RAG chunk overlap")
    rag_similarity_threshold: float = Field(default=0.7, ge=0.0, le=1.0, description="Similarity threshold")
    rag_max_context_length: int = Field(default=4000, ge=1, description="Max context length for RAG")
    
    # Vector database configuration (ChromaDB)
    vector_db_enabled: bool = Field(default=True, description="Enable vector database")
    vector_db_host: str = Field(default="localhost", description="Vector DB host")
    vector_db_port: int = Field(default=8001, ge=1, le=65535, description="Vector DB port")
    vector_db_persist_directory: str = Field(
        default="./data/chromadb",
        description="Vector DB persistence directory"
    )
    vector_db_collection_name: str = Field(
        default="customer_support_docs",
        description="Vector DB collection name"
    )
    vector_db_tenant_name: str = Field(default="customer_support", description="Vector DB tenant name")
    vector_db_database_name: str = Field(default="customer_support", description="Vector DB database name")
    
    # Document processing
    document_chunking_enabled: bool = Field(default=True, description="Enable document chunking")
    document_supported_formats: List[str] = Field(
        default=["pdf", "docx", "txt", "md", "html"],
        description="Supported document formats"
    )
    document_max_size_mb: int = Field(default=50, ge=1, description="Max document size in MB")
    document_upload_path: str = Field(default="./data/uploads", description="Document upload path")
    
    # AI Safety and Content Filtering
    enable_content_filtering: bool = Field(default=True, description="Enable content filtering")
    max_response_length: int = Field(default=4000, ge=1, description="Max response length")
    enable_toxicity_check: bool = Field(default=True, description="Enable toxicity checking")
    enable_pii_detection: bool = Field(default=True, description="Enable PII detection")
    
    # Prompt Engineering
    system_prompt_template: str = Field(
        default="You are a helpful customer support assistant. Provide accurate and helpful responses.",
        description="System prompt template"
    )
    prompt_optimization_enabled: bool = Field(default=False, description="Enable prompt optimization")
    few_shot_examples: int = Field(default=3, ge=0, le=10, description="Number of few-shot examples")
    
    # Streaming and Real-time
    streaming_enabled: bool = Field(default=True, description="Enable streaming responses")
    streaming_chunk_size: int = Field(default=100, ge=10, description="Streaming chunk size")
    
    # Caching
    ai_response_cache_enabled: bool = Field(default=True, description="Enable AI response caching")
    ai_cache_ttl: int = Field(default=3600, ge=1, description="AI cache TTL in seconds")
    ai_cache_max_size: int = Field(default=1000, ge=1, description="AI cache max size")
    
    # Monitoring and Analytics
    ai_monitoring_enabled: bool = Field(default=True, description="Enable AI monitoring")
    track_token_usage: bool = Field(default=True, description="Track token usage")
    track_response_time: bool = Field(default=True, description="Track response time")
    
    # Cost Management
    cost_tracking_enabled: bool = Field(default=False, description="Enable cost tracking")
    max_daily_cost: Optional[float] = Field(default=None, ge=0.0, description="Maximum daily cost")
    cost_alert_threshold: float = Field(default=0.8, ge=0.0, le=1.0, description="Cost alert threshold")
    
    class Config:
        env_prefix = "AI_"
        case_sensitive = False
    
    @property
    def is_openai_configured(self) -> bool:
        """Check if OpenAI is configured."""
        return bool(self.openai_api_key)
    
    @property
    def is_azure_openai_configured(self) -> bool:
        """Check if Azure OpenAI is configured."""
        return bool(self.azure_openai_api_key and self.azure_openai_endpoint)
    
    @property
    def is_anthropic_configured(self) -> bool:
        """Check if Anthropic is configured."""
        return bool(self.anthropic_api_key)
    
    @property
    def is_cohere_configured(self) -> bool:
        """Check if Cohere is configured."""
        return bool(self.cohere_api_key)
    
    @property
    def is_huggingface_configured(self) -> bool:
        """Check if HuggingFace is configured."""
        return bool(self.huggingface_api_key)
    
    @property
    def active_llm_provider(self) -> Optional[str]:
        """Get the active LLM provider."""
        provider_map = {
            "openai": self.is_openai_configured,
            "azure_openai": self.is_azure_openai_configured,
            "anthropic": self.is_anthropic_configured,
            "cohere": self.is_cohere_configured,
        }
        
        # Check if the configured provider is available
        if self.llm_provider in provider_map and provider_map[self.llm_provider]:
            return self.llm_provider
        
        # Fall back to first available provider
        for provider, available in provider_map.items():
            if available:
                return provider
        
        return None
    
    def get_llm_config(self) -> Dict[str, Any]:
        """Get configuration for the active LLM provider."""
        provider = self.active_llm_provider
        
        if provider == "openai":
            return {
                "provider": "openai",
                "api_key": self.openai_api_key.get_secret_value() if self.openai_api_key else None,
                "model": self.openai_model,
                "max_tokens": self.openai_max_tokens,
                "temperature": self.openai_temperature,
                "timeout": self.openai_timeout,
                "max_retries": self.openai_max_retries,
            }
        
        elif provider == "azure_openai":
            return {
                "provider": "azure_openai",
                "api_key": self.azure_openai_api_key.get_secret_value() if self.azure_openai_api_key else None,
                "endpoint": self.azure_openai_endpoint,
                "deployment": self.azure_openai_deployment_name,
                "api_version": self.azure_openai_api_version,
                "timeout": self.azure_openai_timeout,
            }
        
        elif provider == "anthropic":
            return {
                "provider": "anthropic",
                "api_key": self.anthropic_api_key.get_secret_value() if self.anthropic_api_key else None,
                "model": self.anthropic_model,
                "max_tokens": self.anthropic_max_tokens,
                "timeout": self.anthropic_timeout,
            }
        
        elif provider == "cohere":
            return {
                "provider": "cohere",
                "api_key": self.cohere_api_key.get_secret_value() if self.cohere_api_key else None,
                "model": self.cohere_model,
                "max_tokens": self.cohere_max_tokens,
            }
        
        return {}
    
    def get_embedding_config(self) -> Dict[str, Any]:
        """Get configuration for the embedding provider."""
        if self.embedding_provider == "openai" and self.is_openai_configured:
            return {
                "provider": "openai",
                "model": self.openai_embedding_model,
                "dimensions": self.openai_embedding_dimensions,
                "api_key": self.openai_api_key.get_secret_value() if self.openai_api_key else None,
            }
        
        elif self.embedding_provider == "azure_openai" and self.is_azure_openai_configured:
            return {
                "provider": "azure_openai",
                "model": self.azure_openai_embedding_deployment or self.openai_embedding_model,
                "api_key": self.azure_openai_api_key.get_secret_value() if self.azure_openai_api_key else None,
                "endpoint": self.azure_openai_endpoint,
                "api_version": self.azure_openai_api_version,
            }
        
        elif self.embedding_provider == "sentence_transformers":
            return {
                "provider": "sentence_transformers",
                "model_name": self.embedding_model,
                "dimension": self.embedding_dimension,
                "batch_size": self.embedding_batch_size,
                "max_seq_length": self.embedding_max_sequence_length,
            }
        
        elif self.embedding_provider == "huggingface" and self.is_huggingface_configured:
            return {
                "provider": "huggingface",
                "model_repo": self.huggingface_model_repo,
                "api_key": self.huggingface_api_key.get_secret_value() if self.huggingface_api_key else None,
                "dimension": self.embedding_dimension,
            }
        
        return {}
    
    @validator("llm_provider")
    def validate_llm_provider(cls, v):
        """Validate LLM provider."""
        valid_providers = [provider.value for provider in LLMProvider]
        if v not in valid_providers:
            raise ValueError(f"Invalid LLM provider: {v}. Must be one of: {valid_providers}")
        return v
    
    @validator("embedding_provider")
    def validate_embedding_provider(cls, v):
        """Validate embedding provider."""
        valid_providers = [provider.value for provider in EmbeddingProvider]
        if v not in valid_providers:
            raise ValueError(f"Invalid embedding provider: {v}. Must be one of: {valid_providers}")
        return v
    
    @validator("openai_temperature")
    def validate_temperature(cls, v):
        """Validate temperature is within acceptable range."""
        if not 0.0 <= v <= 2.0:
            raise ValueError("Temperature must be between 0.0 and 2.0")
        return v
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate AI configuration."""
        issues = []
        warnings = []
        
        # Check if any LLM is configured
        if not self.active_llm_provider:
            issues.append("No LLM provider configured or available")
        
        # Check embedding provider configuration
        if not self.get_embedding_config():
            warnings.append("No embedding provider configured")
        
        # Validate chunk size and overlap
        if self.rag_chunk_size <= self.rag_chunk_overlap:
            issues.append("RAG chunk size must be greater than chunk overlap")
        
        # Check similarity threshold
        if not 0.0 <= self.rag_similarity_threshold <= 1.0:
            issues.append("RAG similarity threshold must be between 0.0 and 1.0")
        
        # Check document processing settings
        if self.document_max_size_mb > 100:
            warnings.append("Large document size may impact performance")
        
        # Validate embedding dimension vs provider
        embedding_config = self.get_embedding_config()
        if embedding_config.get("provider") == "openai" and self.embedding_dimension != self.openai_embedding_dimensions:
            warnings.append("Embedding dimension mismatch with OpenAI model")
        
        # Check cost management
        if self.cost_tracking_enabled and not self.is_openai_configured and not self.is_azure_openai_configured:
            warnings.append("Cost tracking enabled but OpenAI/Azure OpenAI not configured")
        
        # Check RAG settings
        if self.rag_enabled and not self.vector_db_enabled:
            issues.append("RAG enabled but vector database disabled")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "ai_summary": {
                "llm_provider": self.active_llm_provider,
                "embedding_provider": self.embedding_provider,
                "rag_enabled": self.rag_enabled,
                "vector_db_enabled": self.vector_db_enabled,
                "streaming_enabled": self.streaming_enabled,
                "cost_tracking": self.cost_tracking_enabled,
            },
        }
    
    def get_cost_estimate(self, prompt_tokens: int, completion_tokens: int) -> float:
        """Estimate cost for API usage."""
        if not self.cost_tracking_enabled:
            return 0.0
        
        # Pricing per 1K tokens (example rates - would need to be updated)
        pricing = {
            "openai": {
                "gpt-3.5-turbo": {"prompt": 0.0015, "completion": 0.002},
                "gpt-4": {"prompt": 0.03, "completion": 0.06},
            },
            "azure_openai": {
                "gpt-35-turbo": {"prompt": 0.0015, "completion": 0.002},
                "gpt-4": {"prompt": 0.03, "completion": 0.06},
            }
        }
        
        provider = self.active_llm_provider
        if provider in pricing:
            model_pricing = pricing[provider].get(self.openai_model)
            if model_pricing:
                prompt_cost = (prompt_tokens / 1000) * model_pricing["prompt"]
                completion_cost = (completion_tokens / 1000) * model_pricing["completion"]
                return prompt_cost + completion_cost
        
        return 0.0
    
    def create_prompt_template(self, **kwargs) -> str:
        """Create a formatted prompt template."""
        template = self.system_prompt_template
        
        # Replace placeholders with actual values
        for key, value in kwargs.items():
            template = template.replace(f"{{{key}}}", str(value))
        
        return template


class AIManager:
    """Manages AI operations and provider initialization."""
    
    def __init__(self, config: AIConfig):
        self.config = config
        self._llm_client = None
        self._embedding_client = None
        self._token_usage = 0
        self._total_cost = 0.0
        
    async def initialize(self):
        """Initialize AI clients."""
        try:
            # Initialize LLM client
            llm_config = self.config.get_llm_config()
            if llm_config:
                await self._initialize_llm_client(llm_config)
            
            # Initialize embedding client
            embedding_config = self.config.get_embedding_config()
            if embedding_config:
                await self._initialize_embedding_client(embedding_config)
            
            logger.info("AI manager initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize AI manager: {e}")
            raise
    
    async def _initialize_llm_client(self, config: Dict[str, Any]):
        """Initialize LLM client based on provider."""
        # This would be implemented based on the specific provider
        # For now, just store the configuration
        self._llm_client = config
        logger.info(f"LLM client initialized for provider: {config['provider']}")
    
    async def _initialize_embedding_client(self, config: Dict[str, Any]):
        """Initialize embedding client based on provider."""
        # This would be implemented based on the specific provider
        # For now, just store the configuration
        self._embedding_client = config
        logger.info(f"Embedding client initialized for provider: {config['provider']}")
    
    async def generate_response(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Generate AI response."""
        start_time = time.time()
        
        try:
            # This would implement the actual AI response generation
            # For now, return a placeholder response
            response = {
                "content": "AI response generation not yet implemented",
                "tokens_used": 0,
                "cost": 0.0,
                "response_time": time.time() - start_time,
            }
            
            if self.config.track_token_usage:
                self._token_usage += response["tokens_used"]
            
            if self.config.cost_tracking_enabled:
                cost = self.config.get_cost_estimate(len(prompt.split()), response["tokens_used"])
                self._total_cost += cost
                response["cost"] = cost
            
            return response
            
        except Exception as e:
            logger.error(f"AI response generation failed: {e}")
            raise
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """Get AI usage statistics."""
        return {
            "tokens_used": self._token_usage,
            "total_cost": self._total_cost,
            "daily_cost": self._total_cost,  # Would track daily usage separately
        }


# AI configuration instance
ai_config = AIConfig()
ai_manager = AIManager(ai_config)