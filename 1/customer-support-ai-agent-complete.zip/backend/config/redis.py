"""
Redis configuration module.

This module provides specialized Redis configuration management with
connection pooling, cluster settings, and Redis-specific validation.
"""

import logging
import time
from typing import Optional, Dict, Any, List
from urllib.parse import urlparse

from pydantic import BaseSettings, Field, validator, RedisDsn


logger = logging.getLogger(__name__)


class RedisConfig(BaseSettings):
    """
    Redis configuration with connection pooling and clustering support.
    
    This class handles all Redis-related configuration including connection
    strings, pool settings, clustering, and Redis-specific validations.
    """
    
    # Connection settings
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL"
    )
    redis_password: Optional[str] = Field(default=None, description="Redis password")
    
    # Individual connection parameters (fallback when URL not provided)
    redis_host: str = Field(default="localhost", description="Redis host")
    redis_port: int = Field(default=6379, ge=1, le=65535, description="Redis port")
    redis_db: int = Field(default=0, ge=0, le=15, description="Redis database number")
    
    # Connection pool settings
    redis_max_connections: int = Field(default=20, ge=1, description="Max connections in pool")
    redis_connection_timeout: int = Field(default=5, ge=1, description="Connection timeout")
    redis_socket_timeout: int = Field(default=5, ge=1, description="Socket timeout")
    redis_socket_connect_timeout: int = Field(default=5, ge=1, description="Socket connect timeout")
    redis_socket_keepalive: bool = Field(default=True, description="Enable socket keepalive")
    redis_socket_keepalive_options: Dict[str, int] = Field(
        default_factory=dict,
        description="Socket keepalive options"
    )
    
    # Retry settings
    redis_retry_on_timeout: bool = Field(default=True, description="Retry on timeout")
    redis_max_retries: int = Field(default=3, ge=0, description="Max retries")
    redis_retry_delay: float = Field(default=1.0, ge=0.1, description="Retry delay in seconds")
    
    # Connection health checks
    redis_health_check_interval: int = Field(default=30, ge=1, description="Health check interval")
    redis_socket_keepalive_interval: Optional[int] = Field(default=None, ge=1, description="Keepalive interval")
    
    # SSL/TLS settings
    redis_ssl_enabled: bool = Field(default=False, description="Enable SSL/TLS")
    redis_ssl_cert_reqs: str = Field(default="CERT_REQUIRED", description="SSL certificate requirements")
    redis_ssl_ca_certs: Optional[str] = Field(default=None, description="CA certificates file")
    redis_ssl_certfile: Optional[str] = Field(default=None, description="Client certificate file")
    redis_ssl_keyfile: Optional[str] = Field(default=None, description="Client key file")
    redis_ssl_check_hostname: bool = Field(default=True, description="Check SSL hostname")
    
    # Redis Sentinel settings (for high availability)
    redis_sentinel_enabled: bool = Field(default=False, description="Enable Redis Sentinel")
    redis_sentinel_master_name: Optional[str] = Field(default=None, description="Sentinel master name")
    redis_sentinel_nodes: List[str] = Field(default_factory=list, description="Sentinel nodes")
    
    # Redis Cluster settings
    redis_cluster_enabled: bool = Field(default=False, description="Enable Redis Cluster")
    redis_cluster_startup_nodes: List[str] = Field(default_factory=list, description="Cluster startup nodes")
    redis_cluster_skip_full_coverage_check: bool = Field(default=False, description="Skip cluster coverage check")
    
    # Session settings
    redis_session_expire: int = Field(default=86400, ge=1, description="Session expiration in seconds")
    redis_cache_expire: int = Field(default=3600, ge=1, description="Cache expiration in seconds")
    redis_lock_expire: int = Field(default=60, ge=1, description="Lock expiration in seconds")
    
    # Memory and performance settings
    redis_maxmemory_policy: str = Field(default="allkeys-lru", description="Maxmemory policy")
    redis_tcp_keepalive: int = Field(default=300, ge=0, description="TCP keepalive")
    
    # Monitoring and debugging
    redis_health_check_enabled: bool = Field(default=True, description="Enable health checks")
    redis_debug_mode: bool = Field(default=False, description="Enable debug mode")
    redis_slowlog_enabled: bool = Field(default=True, description="Enable slow log")
    redis_slowlog_log_slower_than: int = Field(default=10000, ge=0, description="Slow log threshold")
    redis_slowlog_max_len: int = Field(default=128, ge=1, description="Slow log max length")
    
    class Config:
        env_prefix = "REDIS_"
        case_sensitive = False
    
    @property
    def is_cluster_mode(self) -> bool:
        """Check if Redis is in cluster mode."""
        return self.redis_cluster_enabled
    
    @property
    def is_sentinel_mode(self) -> bool:
        """Check if Redis Sentinel is enabled."""
        return self.redis_sentinel_enabled
    
    @property
    def connection_url(self) -> str:
        """Get actual connection URL."""
        if self.redis_url != "redis://localhost:6379/0":
            return self.redis_url
        
        # Build URL from individual components
        auth = f":{self.redis_password}@" if self.redis_password else ""
        protocol = "rediss" if self.redis_ssl_enabled else "redis"
        return f"{protocol}://{auth}{self.redis_host}:{self.redis_port}/{self.redis_db}"
    
    def get_connection_kwargs(self) -> Dict[str, Any]:
        """Get Redis connection kwargs."""
        kwargs = {
            "max_connections": self.redis_max_connections,
            "connection_timeout": self.redis_connection_timeout,
            "socket_timeout": self.redis_socket_timeout,
            "socket_connect_timeout": self.redis_socket_connect_timeout,
            "retry_on_timeout": self.redis_retry_on_timeout,
            "max_retries": self.redis_max_retries,
            "health_check_interval": self.redis_health_check_interval,
        }
        
        # Add SSL configuration
        if self.redis_ssl_enabled:
            kwargs.update({
                "ssl": True,
                "ssl_cert_reqs": self.redis_ssl_cert_reqs,
                "ssl_check_hostname": self.redis_ssl_check_hostname,
            })
            
            if self.redis_ssl_ca_certs:
                kwargs["ssl_ca_certs"] = self.redis_ssl_ca_certs
            if self.redis_ssl_certfile:
                kwargs["ssl_certfile"] = self.redis_ssl_certfile
            if self.redis_ssl_keyfile:
                kwargs["ssl_keyfile"] = self.redis_ssl_keyfile
        
        # Add socket options
        if self.redis_socket_keepalive:
            kwargs["socket_keepalive"] = True
            if self.redis_socket_keepalive_options:
                kwargs["socket_keepalive_options"] = self.redis_socket_keepalive_options
            if self.redis_socket_keepalive_interval:
                kwargs["socket_keepalive_interval"] = self.redis_socket_keepalive_interval
        
        return kwargs
    
    def get_cluster_kwargs(self) -> Dict[str, Any]:
        """Get Redis cluster configuration kwargs."""
        if not self.redis_cluster_enabled:
            return {}
            
        cluster_kwargs = self.get_connection_kwargs()
        cluster_kwargs.update({
            "startup_nodes": [{"host": node.split(":")[0], "port": int(node.split(":")[1]) if ":" in node else 6379} 
                             for node in self.redis_cluster_startup_nodes],
            "skip_full_coverage_check": self.redis_cluster_skip_full_coverage_check,
        })
        
        return cluster_kwargs
    
    def get_sentinel_kwargs(self) -> Dict[str, Any]:
        """Get Redis Sentinel configuration kwargs."""
        if not self.redis_sentinel_enabled:
            return {}
            
        sentinel_kwargs = self.get_connection_kwargs()
        sentinel_kwargs.update({
            "master_name": self.redis_sentinel_master_name,
            "sentinels": [{"host": node.split(":")[0], "port": int(node.split(":")[1]) if ":" in node else 26379} 
                         for node in self.redis_sentinel_nodes],
        })
        
        return sentinel_kwargs
    
    def parse_sentinel_nodes(self) -> List[str]:
        """Parse sentinel nodes from environment variable."""
        if isinstance(self.redis_sentinel_nodes, str):
            return [node.strip() for node in self.redis_sentinel_nodes.split(",")]
        return self.redis_sentinel_nodes
    
    def parse_cluster_nodes(self) -> List[str]:
        """Parse cluster nodes from environment variable."""
        if isinstance(self.redis_cluster_startup_nodes, str):
            return [node.strip() for node in self.redis_cluster_startup_nodes.split(",")]
        return self.redis_cluster_startup_nodes
    
    @validator("redis_sentinel_nodes", pre=True)
    def validate_sentinel_nodes(cls, v):
        """Validate and parse sentinel nodes."""
        if isinstance(v, str):
            return [node.strip() for node in v.split(",") if node.strip()]
        return v
    
    @validator("redis_cluster_startup_nodes", pre=True)
    def validate_cluster_nodes(cls, v):
        """Validate and parse cluster nodes."""
        if isinstance(v, str):
            return [node.strip() for node in v.split(",") if node.strip()]
        return v
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate Redis configuration."""
        issues = []
        warnings = []
        
        # Check basic connectivity
        if not self.redis_host and not self.redis_url:
            issues.append("No Redis host or URL configured")
            
        # Validate SSL configuration
        if self.redis_ssl_enabled:
            if not self.redis_ssl_ca_certs and not self.redis_ssl_cert_reqs == "CERT_NONE":
                warnings.append("SSL enabled but no CA certificates provided")
                
        # Validate cluster configuration
        if self.redis_cluster_enabled:
            if not self.redis_cluster_startup_nodes:
                issues.append("Cluster mode enabled but no startup nodes configured")
                
        # Validate sentinel configuration
        if self.redis_sentinel_enabled:
            if not self.redis_sentinel_master_name:
                issues.append("Sentinel mode enabled but master name not configured")
            if not self.redis_sentinel_nodes:
                issues.append("Sentinel mode enabled but no sentinel nodes configured")
                
        # Check memory policy
        valid_policies = [
            "noeviction", "allkeys-lru", "allkeys-random", "allkeys-lfu",
            "volatile-lru", "volatile-random", "volatile-ttl", "volatile-lfu"
        ]
        if self.redis_maxmemory_policy not in valid_policies:
            warnings.append(f"Unknown maxmemory policy: {self.redis_maxmemory_policy}")
            
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "connection_info": {
                "host": self.redis_host,
                "port": self.redis_port,
                "db": self.redis_db,
                "ssl_enabled": self.redis_ssl_enabled,
                "cluster_mode": self.is_cluster_mode,
                "sentinel_mode": self.is_sentinel_mode,
            },
            "connection_pool_configured": self.redis_max_connections > 0,
        }
    
    async def test_connection(self) -> Dict[str, Any]:
        """Test Redis connection."""
        try:
            import redis.asyncio as redis
            
            if self.is_cluster_mode:
                r = redis.RedisCluster(**self.get_cluster_kwargs())
            elif self.is_sentinel_mode:
                r = redis.Sentinel(**self.get_sentinel_kwargs())
            else:
                r = redis.Redis.from_url(self.connection_url, **self.get_connection_kwargs())
            
            # Test basic operations
            await r.ping()
            info = await r.info()
            
            # Test write/read
            test_key = "config_test_connection"
            await r.set(test_key, "ok", ex=10)
            value = await r.get(test_key)
            await r.delete(test_key)
            
            await r.close()
            
            return {
                "connected": True,
                "redis_version": info.get("redis_version"),
                "memory_usage": info.get("used_memory_human"),
                "connected_clients": info.get("connected_clients"),
                "role": info.get("role"),
            }
            
        except Exception as e:
            logger.error(f"Redis connection test failed: {e}")
            return {
                "connected": False,
                "error": str(e),
            }


class RedisConnectionManager:
    """Manages Redis connections with lifecycle management."""
    
    def __init__(self, config: RedisConfig):
        self.config = config
        self._connection = None
        
    async def initialize(self):
        """Initialize Redis connection."""
        try:
            import redis.asyncio as redis
            
            if self.config.is_cluster_mode:
                self._connection = redis.RedisCluster(**self.config.get_cluster_kwargs())
            elif self.config.is_sentinel_mode:
                self._connection = redis.Sentinel(**self.config.get_sentinel_kwargs())
            else:
                self._connection = redis.Redis.from_url(
                    self.config.connection_url, 
                    **self.config.get_connection_kwargs()
                )
            
            # Test connection
            result = await self.config.test_connection()
            if not result.get("connected"):
                raise ConnectionError(f"Redis connection test failed: {result.get('error')}")
            
            logger.info("Redis connection manager initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Redis connection manager: {e}")
            raise
    
    async def get_connection(self):
        """Get Redis connection."""
        if not self._connection:
            await self.initialize()
        return self._connection
    
    async def close(self):
        """Close Redis connection."""
        if self._connection:
            await self._connection.close()
        logger.info("Redis connection manager closed")
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on Redis connection."""
        try:
            if not self._connection:
                return {"healthy": False, "error": "No connection established"}
            
            start_time = time.time()
            await self._connection.ping()
            latency = (time.time() - start_time) * 1000  # Convert to ms
            
            return {
                "healthy": True,
                "latency_ms": round(latency, 2),
                "timestamp": time.time(),
            }
            
        except Exception as e:
            return {
                "healthy": False,
                "error": str(e),
                "timestamp": time.time(),
            }


# Redis configuration instance
redis_config = RedisConfig()
redis_manager = RedisConnectionManager(redis_config)