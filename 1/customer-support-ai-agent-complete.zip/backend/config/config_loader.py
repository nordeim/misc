"""
Configuration loader for environment-specific settings.

This module provides intelligent configuration loading with support for
multiple environments, file formats, and configuration inheritance.
"""

import os
import json
import yaml
import logging
from typing import Dict, Any, Optional, List, Union
from pathlib import Path
from dataclasses import dataclass
from enum import Enum

from pydantic import BaseSettings


logger = logging.getLogger(__name__)


class Environment(str, Enum):
    """Supported environments."""
    DEVELOPMENT = "development"
    PRODUCTION = "production"
    TESTING = "testing"
    STAGING = "staging"


class ConfigFormat(str, Enum):
    """Supported configuration file formats."""
    ENV = "env"
    JSON = "json"
    YAML = "yaml"
    YAMLML = "yamlml"


@dataclass
class ConfigSource:
    """Configuration source definition."""
    name: str
    path: str
    format: ConfigFormat
    priority: int = 0
    required: bool = False
    environment_specific: bool = False
    encrypted: bool = False
    description: str = ""


class ConfigurationLoader:
    """Intelligent configuration loader with environment support."""
    
    def __init__(self, base_path: Optional[Path] = None):
        self.base_path = base_path or Path.cwd()
        self.config_sources: List[ConfigSource] = []
        self.environment: Optional[Environment] = None
        self.loaded_configs: Dict[str, Any] = {}
        self._setup_default_sources()
    
    def _setup_default_sources(self):
        """Setup default configuration sources."""
        # Environment file
        self.add_source(ConfigSource(
            name="env_file",
            path=str(self.base_path / ".env"),
            format=ConfigFormat.ENV,
            priority=1,
            description="Environment variables file"
        ))
        
        # Environment-specific env file
        self.add_source(ConfigSource(
            name="env_specific",
            path=str(self.base_path / ".env.{env}"),
            format=ConfigFormat.ENV,
            priority=2,
            environment_specific=True,
            description="Environment-specific variables file"
        ))
        
        # JSON config files
        self.add_source(ConfigSource(
            name="config_json",
            path=str(self.base_path / "config" / "config.json"),
            format=ConfigFormat.JSON,
            priority=3,
            description="JSON configuration file"
        ))
        
        # Environment-specific JSON config
        self.add_source(ConfigSource(
            name="config_json_specific",
            path=str(self.base_path / "config" / "config.{env}.json"),
            format=ConfigFormat.JSON,
            priority=4,
            environment_specific=True,
            description="Environment-specific JSON configuration"
        ))
        
        # YAML config files
        self.add_source(ConfigSource(
            name="config_yaml",
            path=str(self.base_path / "config" / "config.yaml"),
            format=ConfigFormat.YAML,
            priority=5,
            description="YAML configuration file"
        ))
        
        # Environment-specific YAML config
        self.add_source(ConfigSource(
            name="config_yaml_specific",
            path=str(self.base_path / "config" / "config.{env}.yaml"),
            format=ConfigFormat.YAML,
            priority=6,
            environment_specific=True,
            description="Environment-specific YAML configuration"
        ))
    
    def add_source(self, source: ConfigSource):
        """Add a configuration source."""
        self.config_sources.append(source)
        # Sort by priority (higher priority first)
        self.config_sources.sort(key=lambda x: x.priority, reverse=True)
    
    def remove_source(self, name: str):
        """Remove a configuration source by name."""
        self.config_sources = [s for s in self.config_sources if s.name != name]
    
    def set_environment(self, environment: Union[str, Environment]):
        """Set the target environment."""
        if isinstance(environment, str):
            try:
                self.environment = Environment(environment)
            except ValueError:
                raise ValueError(f"Unknown environment: {environment}")
        else:
            self.environment = environment
    
    def detect_environment(self) -> Environment:
        """Automatically detect environment from environment variables."""
        # Check common environment variables
        env_vars = [
            "ENVIRONMENT",
            "ENV",
            "APP_ENV",
            "FLASK_ENV",
            "DJANGO_ENV",
        ]
        
        for var in env_vars:
            value = os.getenv(var)
            if value:
                try:
                    return Environment(value.lower())
                except ValueError:
                    logger.warning(f"Unknown environment value from {var}: {value}")
        
        # Check if running in specific environments
        if os.getenv("CI"):
            return Environment.TESTING
        if os.getenv("DEBUG") == "1":
            return Environment.DEVELOPMENT
        if os.getenv("PRODUCTION") == "1":
            return Environment.PRODUCTION
        
        # Default to development
        logger.info("Environment not detected, defaulting to development")
        return Environment.DEVELOPMENT
    
    def load_config_file(self, source: ConfigSource, environment: Optional[Environment] = None) -> Dict[str, Any]:
        """Load configuration from a single source."""
        file_path = source.path
        
        # Substitute environment placeholder
        if source.environment_specific and environment:
            file_path = file_path.replace("{env}", environment.value)
        
        config_path = Path(file_path)
        
        # Check if file exists
        if not config_path.exists():
            if source.required:
                raise FileNotFoundError(f"Required config file not found: {config_path}")
            return {}
        
        logger.debug(f"Loading configuration from: {config_path}")
        
        try:
            if source.format == ConfigFormat.ENV:
                return self._load_env_file(config_path)
            elif source.format == ConfigFormat.JSON:
                return self._load_json_file(config_path)
            elif source.format == ConfigFormat.YAML:
                return self._load_yaml_file(config_path)
            else:
                raise ValueError(f"Unsupported config format: {source.format}")
                
        except Exception as e:
            logger.error(f"Failed to load config file {config_path}: {e}")
            if source.required:
                raise
            return {}
    
    def _load_env_file(self, file_path: Path) -> Dict[str, Any]:
        """Load environment file."""
        config = {}
        
        with open(file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                # Parse KEY=VALUE
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Remove quotes
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                    
                    config[key] = value
                else:
                    logger.warning(f"Invalid env format at line {line_num}: {line}")
        
        return config
    
    def _load_json_file(self, file_path: Path) -> Dict[str, Any]:
        """Load JSON file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def _load_yaml_file(self, file_path: Path) -> Dict[str, Any]:
        """Load YAML file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    
    def merge_configs(self, configs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Merge multiple configuration dictionaries."""
        merged = {}
        
        for config in configs:
            merged = self._deep_merge(merged, config)
        
        return merged
    
    def _deep_merge(self, base: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
        """Deep merge two dictionaries."""
        result = base.copy()
        
        for key, value in update.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def load_all_configs(self, environment: Optional[Environment] = None) -> Dict[str, Any]:
        """Load all configurations for the specified environment."""
        if environment:
            self.set_environment(environment)
        elif not self.environment:
            self.environment = self.detect_environment()
        
        logger.info(f"Loading configuration for environment: {self.environment}")
        
        all_configs = []
        
        for source in self.config_sources:
            try:
                config = self.load_config_file(source, self.environment)
                if config:
                    logger.debug(f"Loaded config from {source.name}: {len(config)} keys")
                    all_configs.append(config)
                    self.loaded_configs[source.name] = config
            except Exception as e:
                logger.error(f"Failed to load config from {source.name}: {e}")
                if source.required:
                    raise
        
        # Merge all configurations
        merged_config = self.merge_configs(all_configs)
        
        # Add environment information
        merged_config["_environment"] = self.environment.value
        merged_config["_config_sources"] = [source.name for source in self.config_sources if source.name in self.loaded_configs]
        
        logger.info(f"Configuration loaded successfully with {len(merged_config)} keys")
        return merged_config
    
    def load_for_pydantic(self, settings_class: type, environment: Optional[Environment] = None) -> settings_class:
        """Load configuration and create Pydantic settings instance."""
        config_dict = self.load_all_configs(environment)
        
        # Convert dot notation keys to nested dict
        nested_config = self._expand_dot_notation(config_dict)
        
        try:
            return settings_class(**nested_config)
        except Exception as e:
            logger.error(f"Failed to create settings instance: {e}")
            logger.error(f"Config dict keys: {list(nested_config.keys())}")
            raise
    
    def _expand_dot_notation(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Expand dot notation keys into nested dictionaries."""
        expanded = {}
        
        for key, value in config.items():
            if '.' in key and not key.startswith('_'):
                # Split and create nested structure
                parts = key.split('.')
                current = expanded
                
                for part in parts[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                
                current[parts[-1]] = value
            else:
                expanded[key] = value
        
        return expanded
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Get summary of loaded configuration."""
        return {
            "environment": self.environment.value if self.environment else None,
            "sources_configured": len(self.config_sources),
            "sources_loaded": len(self.loaded_configs),
            "loaded_source_names": list(self.loaded_configs.keys()),
            "base_path": str(self.base_path),
        }
    
    def save_config_template(self, file_path: Optional[Path] = None, format: ConfigFormat = ConfigFormat.YAML):
        """Save a configuration template file."""
        if not file_path:
            file_path = self.base_path / "config" / f"config.template.{format.value}"
        
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Create template configuration
        template = {
            "application": {
                "name": "Customer Support Application",
                "version": "1.0.0",
                "environment": "{{ENVIRONMENT}}",
                "debug": "{{DEBUG}}",
            },
            "database": {
                "url": "{{DATABASE_URL}}",
                "pool_size": "{{DB_POOL_SIZE}}",
                "max_overflow": "{{DB_MAX_OVERFLOW}}",
            },
            "redis": {
                "host": "{{REDIS_HOST}}",
                "port": "{{REDIS_PORT}}",
                "db": "{{REDIS_DB}}",
            },
            "security": {
                "secret_key": "{{SECRET_KEY}}",
                "jwt_secret_key": "{{JWT_SECRET_KEY}}",
            },
            "ai": {
                "provider": "{{AI_PROVIDER}}",
                "api_key": "{{AI_API_KEY}}",
            },
            "monitoring": {
                "enabled": "{{MONITORING_ENABLED}}",
                "log_level": "{{LOG_LEVEL}}",
            }
        }
        
        if format == ConfigFormat.JSON:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(template, f, indent=2)
        elif format == ConfigFormat.YAML:
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(template, f, default_flow_style=False)
        
        logger.info(f"Configuration template saved to: {file_path}")
    
    def validate_loaded_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate loaded configuration."""
        from .config_validator import validate_config_with_details
        
        # Remove internal keys for validation
        clean_config = {k: v for k, v in config.items() if not k.startswith('_')}
        
        validation_result = validate_config_with_details(clean_config)
        
        logger.info(f"Configuration validation: {'PASSED' if validation_result['validation_result']['valid'] else 'FAILED'}")
        
        if validation_result['validation_result']['issues']:
            logger.warning(f"Configuration issues: {validation_result['validation_result']['issues']}")
        
        if validation_result['validation_result']['warnings']:
            logger.warning(f"Configuration warnings: {validation_result['validation_result']['warnings']}")
        
        return validation_result


# Global configuration loader instance
configuration_loader = ConfigurationLoader()


def load_environment_config(environment: Optional[Union[str, Environment]] = None) -> Dict[str, Any]:
    """Load configuration for the specified environment."""
    if environment:
        configuration_loader.set_environment(environment)
    else:
        configuration_loader.set_environment(configuration_loader.detect_environment())
    
    return configuration_loader.load_all_configs()


def load_pydantic_settings(settings_class: type, environment: Optional[Union[str, Environment]] = None) -> BaseSettings:
    """Load Pydantic settings for the specified environment."""
    return configuration_loader.load_for_pydantic(settings_class, environment)