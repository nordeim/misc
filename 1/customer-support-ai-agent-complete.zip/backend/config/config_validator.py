"""
Configuration validation utilities.

This module provides comprehensive validation for configuration settings
with detailed error reporting and configuration health checks.
"""

import logging
import os
import re
from typing import Dict, List, Any, Optional, Tuple, Set
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from pydantic import ValidationError


logger = logging.getLogger(__name__)


class ValidationResult:
    """Configuration validation result."""
    
    def __init__(self, valid: bool = True, issues: List[str] = None, warnings: List[str] = None):
        self.valid = valid
        self.issues = issues or []
        self.warnings = warnings or []
        self.timestamp = datetime.utcnow()
    
    def add_issue(self, issue: str):
        """Add a validation issue."""
        self.issues.append(issue)
        self.valid = False
    
    def add_warning(self, warning: str):
        """Add a validation warning."""
        self.warnings.append(warning)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "valid": self.valid,
            "issues": self.issues,
            "warnings": self.warnings,
            "timestamp": self.timestamp.isoformat(),
        }


class ConfigurationValidator:
    """Comprehensive configuration validator."""
    
    def __init__(self):
        self.validation_rules = self._load_validation_rules()
        self.dependency_graph = self._build_dependency_graph()
    
    def _load_validation_rules(self) -> Dict[str, Any]:
        """Load validation rules and constraints."""
        return {
            "security": {
                "secret_key_min_length": 32,
                "jwt_secret_key_min_length": 32,
                "password_min_length": 8,
                "max_login_attempts_range": (1, 20),
                "rate_limit_range": (1, 10000),
            },
            "database": {
                "pool_size_range": (1, 100),
                "connection_timeout_range": (1, 300),
                "ssl_modes": ["disable", "require", "verify-ca", "verify-full"],
            },
            "redis": {
                "connection_timeout_range": (1, 300),
                "database_range": (0, 15),
                "port_range": (1, 65535),
            },
            "ai": {
                "temperature_range": (0.0, 2.0),
                "max_tokens_range": (1, 32000),
                "chunk_size_range": (100, 10000),
                "similarity_threshold_range": (0.0, 1.0),
            },
            "monitoring": {
                "log_level_options": ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                "port_range": (1, 65535),
                "retention_range": (1, 3650),
            },
        }
    
    def _build_dependency_graph(self) -> Dict[str, List[str]]:
        """Build configuration dependencies."""
        return {
            "rag_enabled": ["vector_db_enabled", "embedding_provider"],
            "ssl_enabled": ["ssl_cert_path", "ssl_key_path"],
            "azure_openai_configured": ["azure_openai_api_key", "azure_openai_endpoint"],
            "openai_configured": ["openai_api_key"],
            "rate_limit_enabled": ["redis_enabled"],
            "alerting_enabled": ["notification_channels"],
            "backup_enabled": ["backup_storage"],
        }
    
    def validate_environment_config(self, env: str) -> ValidationResult:
        """Validate environment-specific configuration."""
        result = ValidationResult()
        
        environment_rules = {
            "development": {
                "required": [],
                "recommended": ["debug_mode", "hot_reload"],
                "forbidden": ["ssl_enabled"],  # Development shouldn't require SSL
            },
            "production": {
                "required": ["secret_key", "ssl_enabled"],
                "recommended": ["backup_enabled", "monitoring_enabled", "rate_limit_enabled"],
                "forbidden": ["debug_mode"],
            },
            "testing": {
                "required": [],
                "recommended": ["fast_tests"],
                "forbidden": [],
            },
        }
        
        if env not in environment_rules:
            result.add_issue(f"Unknown environment: {env}")
            return result
        
        rules = environment_rules[env]
        
        # Add environment-specific validation logic here
        # This would check actual configuration values against rules
        
        return result
    
    def validate_security_config(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate security-related configuration."""
        result = ValidationResult()
        
        # Secret key validation
        secret_key = config.get("secret_key")
        if secret_key:
            if len(secret_key) < self.validation_rules["security"]["secret_key_min_length"]:
                result.add_issue(
                    f"Secret key too short (minimum {self.validation_rules['security']['secret_key_min_length']} characters)"
                )
        
        # JWT secret validation
        jwt_secret = config.get("jwt_secret_key")
        if jwt_secret:
            if len(jwt_secret) < self.validation_rules["security"]["jwt_secret_key_min_length"]:
                result.add_issue(
                    f"JWT secret key too short (minimum {self.validation_rules['security']['jwt_secret_key_min_length']} characters)"
                )
        
        # CORS validation
        cors_origins = config.get("cors_origins", [])
        if "*" in cors_origins:
            if config.get("environment") == "production":
                result.add_issue("Production should not allow wildcard CORS origins")
            else:
                result.add_warning("Wildcard CORS origins not recommended")
        
        # Password policy validation
        password_min_length = config.get("password_min_length", 8)
        if password_min_length < self.validation_rules["security"]["password_min_length"]:
            result.add_warning(f"Password minimum length below recommended {self.validation_rules['security']['password_min_length']}")
        
        return result
    
    def validate_database_config(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate database configuration."""
        result = ValidationResult()
        
        database_url = config.get("database_url")
        if not database_url:
            result.add_issue("Database URL not configured")
            return result
        
        # Parse and validate database URL
        try:
            parsed = urlparse(database_url)
            if not parsed.scheme:
                result.add_issue("Database URL missing scheme")
            if not parsed.netloc:
                result.add_issue("Database URL missing network location")
        except Exception as e:
            result.add_issue(f"Invalid database URL: {e}")
        
        # Pool size validation
        db_pool_size = config.get("db_pool_size", 10)
        pool_range = self.validation_rules["database"]["pool_size_range"]
        if not pool_range[0] <= db_pool_size <= pool_range[1]:
            result.add_issue(f"Database pool size out of range {pool_range}")
        
        # Environment-specific database validation
        environment = config.get("environment")
        if environment == "production":
            if "sqlite" in database_url.lower():
                result.add_issue("Production should use PostgreSQL or MySQL, not SQLite")
            
            # Check for SSL
            if "postgres" in database_url.lower() and "sslmode" not in database_url.lower():
                result.add_warning("PostgreSQL production should use SSL")
        
        return result
    
    def validate_redis_config(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate Redis configuration."""
        result = ValidationResult()
        
        redis_host = config.get("redis_host")
        redis_port = config.get("redis_port", 6379)
        
        if not redis_host:
            result.add_issue("Redis host not configured")
        
        # Port validation
        port_range = self.validation_rules["redis"]["port_range"]
        if not port_range[0] <= redis_port <= port_range[1]:
            result.add_issue(f"Redis port out of range {port_range}")
        
        # Database number validation
        redis_db = config.get("redis_db", 0)
        db_range = self.validation_rules["redis"]["database_range"]
        if not db_range[0] <= redis_db <= db_range[1]:
            result.add_issue(f"Redis database number out of range {db_range}")
        
        return result
    
    def validate_ai_config(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate AI configuration."""
        result = ValidationResult()
        
        # Temperature validation
        temperature = config.get("openai_temperature", 0.7)
        temp_range = self.validation_rules["ai"]["temperature_range"]
        if not temp_range[0] <= temperature <= temp_range[1]:
            result.add_issue(f"Temperature out of range {temp_range}")
        
        # Max tokens validation
        max_tokens = config.get("openai_max_tokens", 2000)
        tokens_range = self.validation_rules["ai"]["max_tokens_range"]
        if not tokens_range[0] <= max_tokens <= tokens_range[1]:
            result.add_issue(f"Max tokens out of range {tokens_range}")
        
        # Chunk size validation
        rag_chunk_size = config.get("rag_chunk_size", 1000)
        chunk_range = self.validation_rules["ai"]["chunk_size_range"]
        if not chunk_range[0] <= rag_chunk_size <= chunk_range[1]:
            result.add_issue(f"RAG chunk size out of range {chunk_range}")
        
        # Similarity threshold validation
        similarity_threshold = config.get("rag_similarity_threshold", 0.7)
        sim_range = self.validation_rules["ai"]["similarity_threshold_range"]
        if not sim_range[0] <= similarity_threshold <= sim_range[1]:
            result.add_issue(f"Similarity threshold out of range {sim_range}")
        
        # LLM provider validation
        llm_provider = config.get("llm_provider")
        if llm_provider == "openai" and not config.get("openai_api_key"):
            result.add_issue("OpenAI provider selected but API key not configured")
        elif llm_provider == "azure_openai":
            required_azure_fields = ["azure_openai_api_key", "azure_openai_endpoint"]
            for field in required_azure_fields:
                if not config.get(field):
                    result.add_issue(f"Azure OpenAI requires {field}")
        
        return result
    
    def validate_monitoring_config(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate monitoring configuration."""
        result = ValidationResult()
        
        # Log level validation
        log_level = config.get("log_level", "INFO")
        valid_levels = self.validation_rules["monitoring"]["log_level_options"]
        if log_level not in valid_levels:
            result.add_issue(f"Invalid log level: {log_level}. Must be one of: {valid_levels}")
        
        # Prometheus port validation
        if config.get("prometheus_enabled"):
            prometheus_port = config.get("prometheus_port", 9090)
            port_range = self.validation_rules["monitoring"]["port_range"]
            if not port_range[0] <= prometheus_port <= port_range[1]:
                result.add_issue(f"Prometheus port out of range {port_range}")
        
        # Retention validation
        retention_days = config.get("metrics_retention_days", 30)
        retention_range = self.validation_rules["monitoring"]["retention_range"]
        if not retention_range[0] <= retention_days <= retention_range[1]:
            result.add_issue(f"Metrics retention out of range {retention_range}")
        
        return result
    
    def validate_dependencies(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate configuration dependencies."""
        result = ValidationResult()
        
        for dependency, required_configs in self.dependency_graph.items():
            dependency_value = config.get(dependency)
            
            # Skip if dependency is not enabled/present
            if not dependency_value:
                continue
            
            # Check required configurations
            for required_config in required_configs:
                if not config.get(required_config):
                    result.add_issue(f"Configuration '{dependency}' requires '{required_config}'")
        
        return result
    
    def validate_paths_and_permissions(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate file paths and permissions."""
        result = ValidationResult()
        
        path_configs = [
            "log_file_path",
            "chroma_persist_directory",
            "upload_path",
            "backup_path",
        ]
        
        for path_config in path_configs:
            path_value = config.get(path_config)
            if path_value:
                path = Path(path_value)
                
                # Check if path can be created
                try:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    
                    # Check write permissions
                    if not os.access(path.parent, os.W_OK):
                        result.add_issue(f"No write permission for {path_config}: {path_value}")
                        
                except Exception as e:
                    result.add_issue(f"Cannot create path for {path_config}: {e}")
        
        return result
    
    def validate_network_connectivity(self, config: Dict[str, Any]) -> ValidationResult:
        """Validate network connectivity and endpoints."""
        result = ValidationResult()
        
        # Check for localhost dependencies in production
        if config.get("environment") == "production":
            localhost_configs = [
                ("redis_host", "Redis"),
                ("database_host", "Database"),
            ]
            
            for config_key, service_name in localhost_configs:
                host = config.get(config_key)
                if host in ["localhost", "127.0.0.1"]:
                    result.add_warning(f"{service_name} configured with localhost - may not be suitable for production")
        
        return result
    
    def validate_comprehensive(self, config: Dict[str, Any]) -> ValidationResult:
        """Run comprehensive validation."""
        result = ValidationResult()
        
        # Environment validation
        env_result = self.validate_environment_config(config.get("environment", "development"))
        result.issues.extend(env_result.issues)
        result.warnings.extend(env_result.warnings)
        
        # Security validation
        security_result = self.validate_security_config(config)
        result.issues.extend(security_result.issues)
        result.warnings.extend(security_result.warnings)
        
        # Database validation
        db_result = self.validate_database_config(config)
        result.issues.extend(db_result.issues)
        result.warnings.extend(db_result.warnings)
        
        # Redis validation
        redis_result = self.validate_redis_config(config)
        result.issues.extend(redis_result.issues)
        result.warnings.extend(redis_result.warnings)
        
        # AI validation
        ai_result = self.validate_ai_config(config)
        result.issues.extend(ai_result.issues)
        result.warnings.extend(ai_result.warnings)
        
        # Monitoring validation
        monitoring_result = self.validate_monitoring_config(config)
        result.issues.extend(monitoring_result.issues)
        result.warnings.extend(monitoring_result.warnings)
        
        # Dependencies validation
        deps_result = self.validate_dependencies(config)
        result.issues.extend(deps_result.issues)
        result.warnings.extend(deps_result.warnings)
        
        # Paths validation
        paths_result = self.validate_paths_and_permissions(config)
        result.issues.extend(paths_result.issues)
        result.warnings.extend(paths_result.warnings)
        
        # Network validation
        network_result = self.validate_network_connectivity(config)
        result.issues.extend(network_result.issues)
        result.warnings.extend(network_result.warnings)
        
        # Final validation
        if result.issues:
            result.valid = False
        
        return result
    
    def get_validation_summary(self, result: ValidationResult) -> Dict[str, Any]:
        """Get detailed validation summary."""
        return {
            "valid": result.valid,
            "total_issues": len(result.issues),
            "total_warnings": len(result.warnings),
            "issues_by_category": self._categorize_issues(result.issues),
            "warnings_by_category": self._categorize_issues(result.warnings),
            "recommendations": self._generate_recommendations(result),
            "timestamp": result.timestamp.isoformat(),
        }
    
    def _categorize_issues(self, issues: List[str]) -> Dict[str, int]:
        """Categorize issues by type."""
        categories = {
            "security": 0,
            "database": 0,
            "network": 0,
            "performance": 0,
            "configuration": 0,
            "dependency": 0,
        }
        
        for issue in issues:
            issue_lower = issue.lower()
            if any(word in issue_lower for word in ["security", "secret", "ssl", "cors"]):
                categories["security"] += 1
            elif any(word in issue_lower for word in ["database", "db_", "pool"]):
                categories["database"] += 1
            elif any(word in issue_lower for word in ["network", "connectivity", "localhost"]):
                categories["network"] += 1
            elif any(word in issue_lower for word in ["performance", "timeout", "retry"]):
                categories["performance"] += 1
            elif any(word in issue_lower for word in ["requires", "missing", "not configured"]):
                categories["dependency"] += 1
            else:
                categories["configuration"] += 1
        
        return categories
    
    def _generate_recommendations(self, result: ValidationResult) -> List[str]:
        """Generate configuration recommendations."""
        recommendations = []
        
        if any("localhost" in issue for issue in result.warnings):
            recommendations.append("Consider using environment variables or service discovery for production")
        
        if any("ssl" in issue.lower() for issue in result.warnings):
            recommendations.append("Enable SSL/TLS for production environments")
        
        if any("backup" in issue.lower() for issue in result.warnings):
            recommendations.append("Enable automated backups for production data")
        
        if any("monitoring" in issue.lower() for issue in result.warnings):
            recommendations.append("Enable monitoring and alerting for production")
        
        return recommendations


# Global validator instance
configuration_validator = ConfigurationValidator()


def validate_config_with_details(config: Dict[str, Any]) -> Dict[str, Any]:
    """Validate configuration with detailed reporting."""
    result = configuration_validator.validate_comprehensive(config)
    summary = configuration_validator.get_validation_summary(result)
    
    return {
        "validation_result": result.to_dict(),
        "summary": summary,
    }