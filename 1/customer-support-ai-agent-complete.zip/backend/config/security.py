"""
Security configuration module.

This module provides specialized security configuration management with
encryption, authentication, authorization, and security policy settings.
"""

import logging
import secrets
from typing import Optional, List, Dict, Any
from datetime import timedelta

from pydantic import BaseSettings, Field, validator, SecretStr


logger = logging.getLogger(__name__)


class SecurityConfig(BaseSettings):
    """
    Security configuration with encryption, authentication, and authorization settings.
    
    This class handles all security-related configuration including JWT tokens,
    API keys, encryption, rate limiting, and security policies.
    """
    
    # Core security keys
    secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="Secret key for encryption and JWT signing"
    )
    jwt_secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="JWT secret key"
    )
    session_secret_key: SecretStr = Field(
        default_factory=lambda: secrets.token_urlsafe(32),
        description="Session secret key"
    )
    
    # JWT configuration
    jwt_algorithm: str = Field(default="HS256", description="JWT algorithm")
    jwt_expire_minutes: int = Field(default=30, ge=1, description="JWT expiration in minutes")
    jwt_refresh_expire_days: int = Field(default=7, ge=1, description="JWT refresh expiration in days")
    jwt_issuer: Optional[str] = Field(default=None, description="JWT issuer")
    jwt_audience: Optional[str] = Field(default=None, description="JWT audience")
    
    # API authentication
    api_key: Optional[SecretStr] = Field(default=None, description="API key for authentication")
    api_key_header: str = Field(default="X-API-Key", description="API key header name")
    
    # Password security
    password_min_length: int = Field(default=8, ge=1, description="Minimum password length")
    password_require_uppercase: bool = Field(default=True, description="Require uppercase letters")
    password_require_lowercase: bool = Field(default=True, description="Require lowercase letters")
    password_require_numbers: bool = Field(default=True, description="Require numbers")
    password_require_symbols: bool = Field(default=True, description="Require symbols")
    password_max_age_days: int = Field(default=90, ge=1, description="Password maximum age in days")
    
    # Account security
    max_login_attempts: int = Field(default=5, ge=1, description="Maximum login attempts")
    account_lockout_duration: int = Field(default=30, ge=1, description="Account lockout duration in minutes")
    require_email_verification: bool = Field(default=False, description="Require email verification")
    
    # Session security
    session_timeout_minutes: int = Field(default=30, ge=1, description="Session timeout")
    session_extend_on_activity: bool = Field(default=True, description="Extend session on activity")
    max_concurrent_sessions: int = Field(default=3, ge=1, description="Maximum concurrent sessions per user")
    
    # Rate limiting
    rate_limit_enabled: bool = Field(default=True, description="Enable rate limiting")
    rate_limit_requests_per_minute: int = Field(default=100, ge=1, description="Requests per minute")
    rate_limit_burst_size: int = Field(default=20, ge=1, description="Rate limit burst size")
    rate_limit_storage: str = Field(default="redis", description="Rate limit storage backend")
    
    # CORS configuration
    cors_origins: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:5173"],
        description="CORS allowed origins"
    )
    cors_allow_credentials: bool = Field(default=True, description="Allow CORS credentials")
    cors_allow_methods: List[str] = Field(
        default=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        description="CORS allowed methods"
    )
    cors_allow_headers: List[str] = Field(
        default=["*"],
        description="CORS allowed headers"
    )
    cors_max_age: int = Field(default=86400, ge=0, description="CORS preflight cache max age")
    
    # Security headers
    security_headers_enabled: bool = Field(default=True, description="Enable security headers")
    hsts_max_age: int = Field(default=31536000, ge=0, description="HSTS max age")
    content_security_policy: str = Field(
        default="default-src 'self'",
        description="Content Security Policy"
    )
    x_frame_options: str = Field(default="DENY", description="X-Frame-Options")
    x_content_type_options: str = Field(default="nosniff", description="X-Content-Type-Options")
    
    # HTTPS/SSL configuration
    ssl_enabled: bool = Field(default=False, description="Enable SSL/TLS")
    ssl_cert_path: Optional[str] = Field(default=None, description="SSL certificate path")
    ssl_key_path: Optional[str] = Field(default=None, description="SSL key path")
    ssl_ca_path: Optional[str] = Field(default=None, description="SSL CA certificate path")
    force_https: bool = Field(default=False, description="Force HTTPS redirect")
    
    # Encryption configuration
    encryption_algorithm: str = Field(default="AES-256-GCM", description="Encryption algorithm")
    encryption_key_rotation_days: int = Field(default=90, ge=1, description="Encryption key rotation interval")
    encrypt_sensitive_data: bool = Field(default=True, description="Encrypt sensitive data in storage")
    
    # Audit logging
    audit_log_enabled: bool = Field(default=True, description="Enable audit logging")
    audit_log_events: List[str] = Field(
        default=["login", "logout", "failed_login", "password_change", "api_access"],
        description="Events to audit log"
    )
    audit_log_retention_days: int = Field(default=30, ge=1, description="Audit log retention days")
    
    # IP filtering and geolocation
    ip_whitelist: List[str] = Field(default_factory=list, description="Whitelisted IP addresses")
    ip_blacklist: List[str] = Field(default_factory=list, description="Blacklisted IP addresses")
    block_suspicious_ips: bool = Field(default=True, description="Block suspicious IP addresses")
    
    # Two-factor authentication
    totp_enabled: bool = Field(default=False, description="Enable TOTP 2FA")
    totp_issuer: str = Field(default="CustomerSupportApp", description="TOTP issuer name")
    backup_codes_count: int = Field(default=10, ge=5, ge=20, description="Number of backup codes")
    
    # Security monitoring
    security_monitoring_enabled: bool = Field(default=True, description="Enable security monitoring")
    alert_on_failed_logins: bool = Field(default=True, description="Alert on multiple failed logins")
    failed_login_threshold: int = Field(default=3, ge=1, description="Failed login threshold for alerts")
    security_alert_email: Optional[str] = Field(default=None, description="Security alert email address")
    
    class Config:
        env_prefix = "SECURITY_"
        case_sensitive = False
    
    @property
    def jwt_expire_delta(self) -> timedelta:
        """Get JWT expiration delta."""
        return timedelta(minutes=self.jwt_expire_minutes)
    
    @property
    def jwt_refresh_expire_delta(self) -> timedelta:
        """Get JWT refresh expiration delta."""
        return timedelta(days=self.jwt_refresh_expire_days)
    
    @property
    def is_secure_mode(self) -> bool:
        """Check if running in secure mode (production with all security features)."""
        return self.ssl_enabled and self.security_headers_enabled and not self.rate_limit_enabled
    
    def get_cors_settings(self) -> Dict[str, Any]:
        """Get CORS settings for FastAPI."""
        return {
            "allow_origins": self.cors_origins,
            "allow_credentials": self.cors_allow_credentials,
            "allow_methods": self.cors_allow_methods,
            "allow_headers": self.cors_allow_headers,
            "max_age": self.cors_max_age,
        }
    
    def get_security_headers(self) -> Dict[str, str]:
        """Get security headers."""
        headers = {}
        
        if self.security_headers_enabled:
            headers.update({
                "Strict-Transport-Security": f"max-age={self.hsts_max_age}",
                "X-Frame-Options": self.x_frame_options,
                "X-Content-Type-Options": self.x_content_type_options,
                "Content-Security-Policy": self.content_security_policy,
            })
        
        return headers
    
    def validate_password(self, password: str) -> Dict[str, Any]:
        """Validate password against security requirements."""
        errors = []
        warnings = []
        
        if len(password) < self.password_min_length:
            errors.append(f"Password must be at least {self.password_min_length} characters long")
        
        if self.password_require_uppercase and not any(c.isupper() for c in password):
            errors.append("Password must contain at least one uppercase letter")
        
        if self.password_require_lowercase and not any(c.islower() for c in password):
            errors.append("Password must contain at least one lowercase letter")
        
        if self.password_require_numbers and not any(c.isdigit() for c in password):
            errors.append("Password must contain at least one number")
        
        if self.password_require_symbols and not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            errors.append("Password must contain at least one symbol")
        
        # Check for common passwords (basic implementation)
        common_passwords = ["password", "123456", "qwerty", "admin", "letmein"]
        if password.lower() in common_passwords:
            errors.append("Password is too common")
        
        # Calculate password strength
        strength_score = 0
        if len(password) >= 8:
            strength_score += 1
        if len(password) >= 12:
            strength_score += 1
        if self.password_require_uppercase and any(c.isupper() for c in password):
            strength_score += 1
        if self.password_require_lowercase and any(c.islower() for c in password):
            strength_score += 1
        if self.password_require_numbers and any(c.isdigit() for c in password):
            strength_score += 1
        if self.password_require_symbols and any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            strength_score += 1
        
        strength_level = "weak"
        if strength_score >= 4:
            strength_level = "medium"
        if strength_score >= 6:
            strength_level = "strong"
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "strength": {
                "score": strength_score,
                "level": strength_level,
                "max_score": 7,
            }
        }
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate security configuration."""
        issues = []
        warnings = []
        
        # Check secret keys strength
        if len(self.secret_key.get_secret_value()) < 32:
            issues.append("Secret key is too short (minimum 32 characters)")
        
        if len(self.jwt_secret_key.get_secret_value()) < 32:
            issues.append("JWT secret key is too short (minimum 32 characters)")
        
        # Check SSL configuration for production
        if self.ssl_enabled:
            if not self.ssl_cert_path or not self.ssl_key_path:
                issues.append("SSL enabled but certificate or key path not configured")
        else:
            warnings.append("SSL not enabled - consider enabling for production")
        
        # Check CORS configuration
        if "*" in self.cors_origins:
            warnings.append("CORS allows all origins - restrict for production")
        
        # Check rate limiting
        if not self.rate_limit_enabled:
            warnings.append("Rate limiting disabled - consider enabling for security")
        
        # Check audit logging
        if not self.audit_log_enabled:
            warnings.append("Audit logging disabled - important for security monitoring")
        
        # Check encryption
        if not self.encrypt_sensitive_data:
            warnings.append("Sensitive data encryption disabled")
        
        # Validate algorithm choices
        if self.jwt_algorithm not in ["HS256", "HS384", "HS512", "RS256", "RS384", "RS512"]:
            warnings.append(f"Non-standard JWT algorithm: {self.jwt_algorithm}")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "security_summary": {
                "jwt_configured": bool(self.jwt_secret_key.get_secret_value()),
                "ssl_enabled": self.ssl_enabled,
                "rate_limiting_enabled": self.rate_limit_enabled,
                "security_headers_enabled": self.security_headers_enabled,
                "audit_logging_enabled": self.audit_log_enabled,
                "encryption_enabled": self.encrypt_sensitive_data,
            },
        }
    
    def generate_backup_codes(self) -> List[str]:
        """Generate backup codes for 2FA."""
        import random
        import string
        
        codes = []
        for _ in range(self.backup_codes_count):
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            # Format as XXXX-XXXX
            formatted_code = f"{code[:4]}-{code[4:]}"
            codes.append(formatted_code)
        
        return codes
    
    def is_ip_allowed(self, ip_address: str) -> bool:
        """Check if IP address is allowed based on whitelist/blacklist."""
        # Check blacklist first
        if ip_address in self.ip_blacklist:
            return False
        
        # Check whitelist (if non-empty)
        if self.ip_whitelist and ip_address not in self.ip_whitelist:
            return False
        
        return True
    
    def get_rate_limit_config(self) -> Dict[str, Any]:
        """Get rate limiting configuration."""
        return {
            "enabled": self.rate_limit_enabled,
            "requests_per_minute": self.rate_limit_requests_per_minute,
            "burst_size": self.rate_limit_burst_size,
            "storage": self.rate_limit_storage,
        }


class SecurityManager:
    """Manages security operations including encryption and authentication."""
    
    def __init__(self, config: SecurityConfig):
        self.config = config
        
    def encrypt_data(self, data: str) -> str:
        """Encrypt sensitive data using Fernet."""
        try:
            from cryptography.fernet import Fernet
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            import base64
            import os
            
            # Derive key from secret key
            salt = os.urandom(16)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(self.config.secret_key.get_secret_value().encode()))
            
            f = Fernet(key)
            encrypted_data = f.encrypt(data.encode())
            
            # Combine salt and encrypted data
            return base64.urlsafe_b64encode(salt + encrypted_data).decode()
            
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise
    
    def decrypt_data(self, encrypted_data: str) -> str:
        """Decrypt sensitive data using Fernet."""
        try:
            from cryptography.fernet import Fernet
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            import base64
            
            # Decode combined salt and encrypted data
            combined = base64.urlsafe_b64decode(encrypted_data.encode())
            salt = combined[:16]
            encrypted_data_bytes = combined[16:]
            
            # Derive same key
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(self.config.secret_key.get_secret_value().encode()))
            
            f = Fernet(key)
            decrypted_data = f.decrypt(encrypted_data_bytes)
            
            return decrypted_data.decode()
            
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise


# Security configuration instance
security_config = SecurityConfig()
security_manager = SecurityManager(security_config)