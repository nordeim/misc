"""
Monitoring configuration module.

This module provides specialized monitoring configuration management with
support for metrics, logging, alerting, and observability settings.
"""

import logging
import time
from typing import Optional, List, Dict, Any, Union
from pathlib import Path

from pydantic import BaseSettings, Field, validator


logger = logging.getLogger(__name__)


class MonitoringConfig(BaseSettings):
    """
    Monitoring and observability configuration.
    
    This class handles all monitoring-related configuration including metrics,
    logging, alerting, health checks, and observability settings.
    """
    
    # General monitoring settings
    monitoring_enabled: bool = Field(default=True, description="Enable monitoring functionality")
    monitoring_level: str = Field(default="INFO", description="Monitoring log level")
    
    # Prometheus metrics
    prometheus_enabled: bool = Field(default=True, description="Enable Prometheus metrics")
    prometheus_port: int = Field(default=9090, ge=1, le=65535, description="Prometheus port")
    prometheus_endpoint: str = Field(default="/metrics", description="Prometheus metrics endpoint")
    prometheus_metrics_prefix: str = Field(default="customer_support", description="Prometheus metrics prefix")
    
    # Grafana configuration
    grafana_enabled: bool = Field(default=False, description="Enable Grafana integration")
    grafana_url: Optional[str] = Field(default=None, description="Grafana URL")
    grafana_api_key: Optional[str] = Field(default=None, description="Grafana API key")
    grafana_dashboard_refresh_interval: int = Field(default=30, ge=5, description="Dashboard refresh interval")
    
    # Health checks
    health_check_enabled: bool = Field(default=True, description="Enable health checks")
    health_check_endpoint: str = Field(default="/health", description="Health check endpoint")
    health_check_interval: int = Field(default=30, ge=1, description="Health check interval in seconds")
    health_check_timeout: int = Field(default=5, ge=1, description="Health check timeout")
    
    # Detailed health checks
    database_health_check: bool = Field(default=True, description="Check database health")
    redis_health_check: bool = Field(default=True, description="Check Redis health")
    ai_service_health_check: bool = Field(default=True, description="Check AI service health")
    vector_db_health_check: bool = Field(default=True, description="Check vector database health")
    
    # Logging configuration
    log_level: str = Field(default="INFO", description="Main logging level")
    log_format: str = Field(default="json", description="Logging format (json, text)")
    log_file_enabled: bool = Field(default=True, description="Enable file logging")
    log_file_path: str = Field(default="./data/logs/app.log", description="Log file path")
    log_max_file_size_mb: int = Field(default=100, ge=1, description="Max log file size in MB")
    log_backup_count: int = Field(default=10, ge=1, description="Log backup count")
    log_rotate_daily: bool = Field(default=True, description="Rotate logs daily")
    
    # Console logging
    log_console_enabled: bool = Field(default=True, description="Enable console logging")
    log_console_level: str = Field(default="INFO", description="Console logging level")
    log_colored_console: bool = Field(default=True, description="Use colored console output")
    
    # Structured logging
    log_structured: bool = Field(default=True, description="Use structured logging")
    log_include_trace_id: bool = Field(default=True, description="Include trace ID in logs")
    log_include_span_id: bool = Field(default=True, description="Include span ID in logs")
    
    # Application Performance Monitoring (APM)
    apm_enabled: bool = Field(default=False, description="Enable APM")
    apm_service_name: str = Field(default="customer-support-app", description="APM service name")
    apm_server_url: Optional[str] = Field(default=None, description="APM server URL")
    apm_api_key: Optional[str] = Field(default=None, description="APM API key")
    apm_environment: str = Field(default="development", description="APM environment")
    
    # Distributed tracing
    tracing_enabled: bool = Field(default=False, description="Enable distributed tracing")
    tracing_service_name: str = Field(default="customer-support-service", description="Tracing service name")
    tracing_jaeger_enabled: bool = Field(default=False, description="Enable Jaeger tracing")
    tracing_zipkin_enabled: bool = Field(default=False, description="Enable Zipkin tracing")
    tracing_otlp_enabled: bool = Field(default=False, description="Enable OTLP tracing")
    tracing_endpoint: Optional[str] = Field(default=None, description="Tracing endpoint URL")
    
    # Metrics collection
    metrics_enabled: bool = Field(default=True, description="Enable metrics collection")
    metrics_retention_days: int = Field(default=30, ge=1, description="Metrics retention in days")
    metrics_sample_rate: float = Field(default=1.0, ge=0.0, le=1.0, description="Metrics sampling rate")
    
    # Custom metrics
    custom_metrics_enabled: bool = Field(default=True, description="Enable custom metrics")
    business_metrics_enabled: bool = Field(default=True, description="Enable business metrics")
    performance_metrics_enabled: bool = Field(default=True, description="Enable performance metrics")
    
    # Alerting configuration
    alerting_enabled: bool = Field(default=False, description="Enable alerting")
    alert_webhook_url: Optional[str] = Field(default=None, description="Alert webhook URL")
    alert_email_enabled: bool = Field(default=False, description="Enable email alerts")
    alert_email_recipients: List[str] = Field(default_factory=list, description="Alert email recipients")
    alert_slack_enabled: bool = Field(default=False, description="Enable Slack alerts")
    alert_slack_webhook: Optional[str] = Field(default=None, description="Slack webhook URL")
    alert_discord_enabled: bool = Field(default=False, description="Enable Discord alerts")
    alert_discord_webhook: Optional[str] = Field(default=None, description="Discord webhook URL")
    
    # Alert thresholds
    high_error_rate_threshold: float = Field(default=0.05, ge=0.0, le=1.0, description="High error rate threshold")
    high_response_time_threshold: float = Field(default=5.0, ge=0.1, description="High response time threshold")
    high_cpu_usage_threshold: float = Field(default=80.0, ge=0.0, le=100.0, description="High CPU usage threshold")
    high_memory_usage_threshold: float = Field(default=80.0, ge=0.0, le=100.0, description="High memory usage threshold")
    
    # Database monitoring
    db_query_logging_enabled: bool = Field(default=False, description="Enable database query logging")
    db_slow_query_threshold: float = Field(default=1.0, ge=0.0, description="Slow query threshold in seconds")
    db_connection_pool_monitoring: bool = Field(default=True, description="Monitor DB connection pool")
    
    # Redis monitoring
    redis_monitoring_enabled: bool = Field(default=True, description="Enable Redis monitoring")
    redis_slow_log_enabled: bool = Field(default=True, description="Enable Redis slow log")
    redis_slow_log_threshold: float = Field(default=10.0, ge=0.0, description="Redis slow log threshold")
    
    # AI service monitoring
    ai_service_monitoring_enabled: bool = Field(default=True, description="Enable AI service monitoring")
    ai_token_usage_tracking: bool = Field(default=True, description="Track AI token usage")
    ai_cost_tracking: bool = Field(default=False, description="Track AI costs")
    ai_response_time_tracking: bool = Field(default=True, description="Track AI response times")
    
    # Uptime monitoring
    uptime_monitoring_enabled: bool = Field(default=True, description="Enable uptime monitoring")
    uptime_check_interval: int = Field(default=60, ge=1, description="Uptime check interval in seconds")
    uptime_check_timeout: int = Field(default=10, ge=1, description="Uptime check timeout")
    uptime_expect_status_code: int = Field(default=200, ge=100, le=599, description="Expected status code")
    
    # Error tracking
    error_tracking_enabled: bool = Field(default=True, description="Enable error tracking")
    error_sentry_enabled: bool = Field(default=False, description="Enable Sentry error tracking")
    sentry_dsn: Optional[str] = Field(default=None, description="Sentry DSN")
    sentry_environment: str = Field(default="development", description="Sentry environment")
    
    # Log aggregation
    log_aggregation_enabled: bool = Field(default=False, description="Enable log aggregation")
    elasticsearch_enabled: bool = Field(default=False, description="Enable Elasticsearch")
    elasticsearch_url: Optional[str] = Field(default=None, description="Elasticsearch URL")
    logstash_enabled: bool = Field(default=False, description="Enable Logstash")
    kibana_enabled: bool = Field(default=False, description="Enable Kibana")
    
    # Performance monitoring
    performance_monitoring_enabled: bool = Field(default=True, description="Enable performance monitoring")
    response_time_tracking: bool = Field(default=True, description="Track response times")
    throughput_tracking: bool = Field(default=True, description="Track throughput")
    error_rate_tracking: bool = Field(default=True, description="Track error rates")
    
    # Security monitoring
    security_monitoring_enabled: bool = Field(default=True, description="Enable security monitoring")
    failed_login_tracking: bool = Field(default=True, description="Track failed logins")
    suspicious_activity_detection: bool = Field(default=True, description="Detect suspicious activity")
    security_audit_logging: bool = Field(default=True, description="Enable security audit logging")
    
    class Config:
        env_prefix = "MONITORING_"
        case_sensitive = False
    
    @validator("log_level", "log_console_level", "monitoring_level")
    def validate_log_levels(cls, v):
        """Validate log levels."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"Log level must be one of: {valid_levels}")
        return v.upper()
    
    @validator("metrics_sample_rate")
    def validate_sample_rate(cls, v):
        """Validate metrics sampling rate."""
        if not 0.0 <= v <= 1.0:
            raise ValueError("Sample rate must be between 0.0 and 1.0")
        return v
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Get logging configuration for Python logging."""
        config = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {},
            "handlers": {},
            "loggers": {},
            "root": {
                "level": self.log_level,
                "handlers": [],
            },
        }
        
        # Formatter configuration
        if self.log_format == "json":
            from pythonjsonlogger import jsonlogger
            config["formatters"]["json"] = {
                "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
                "format": "%(asctime)s %(name)s %(levelname)s %(message)s",
            }
        else:
            config["formatters"]["standard"] = {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            }
        
        # Handler configuration
        if self.log_console_enabled:
            config["handlers"]["console"] = {
                "class": "logging.StreamHandler",
                "level": self.log_console_level,
                "formatter": "json" if self.log_format == "json" else "standard",
                "stream": "ext://sys.stdout",
            }
            config["root"]["handlers"].append("console")
        
        if self.log_file_enabled:
            from logging.handlers import RotatingFileHandler
            config["handlers"]["file"] = {
                "class": "logging.handlers.RotatingFileHandler",
                "level": self.log_level,
                "formatter": "json" if self.log_format == "json" else "standard",
                "filename": self.log_file_path,
                "maxBytes": self.log_max_file_size_mb * 1024 * 1024,
                "backupCount": self.log_backup_count,
            }
            config["root"]["handlers"].append("file")
        
        return config
    
    def get_prometheus_config(self) -> Dict[str, Any]:
        """Get Prometheus configuration."""
        return {
            "enabled": self.prometheus_enabled,
            "port": self.prometheus_port,
            "endpoint": self.prometheus_endpoint,
            "metrics_prefix": self.prometheus_metrics_prefix,
        }
    
    def get_health_check_config(self) -> Dict[str, Any]:
        """Get health check configuration."""
        return {
            "enabled": self.health_check_enabled,
            "endpoint": self.health_check_endpoint,
            "interval": self.health_check_interval,
            "timeout": self.health_check_timeout,
            "checks": {
                "database": self.database_health_check,
                "redis": self.redis_health_check,
                "ai_service": self.ai_service_health_check,
                "vector_db": self.vector_db_health_check,
            },
        }
    
    def get_alerting_config(self) -> Dict[str, Any]:
        """Get alerting configuration."""
        return {
            "enabled": self.alerting_enabled,
            "webhook_url": self.alert_webhook_url,
            "email": {
                "enabled": self.alert_email_enabled,
                "recipients": self.alert_email_recipients,
            },
            "slack": {
                "enabled": self.alert_slack_enabled,
                "webhook": self.alert_slack_webhook,
            },
            "discord": {
                "enabled": self.alert_discord_enabled,
                "webhook": self.alert_discord_webhook,
            },
            "thresholds": {
                "error_rate": self.high_error_rate_threshold,
                "response_time": self.high_response_time_threshold,
                "cpu_usage": self.high_cpu_usage_threshold,
                "memory_usage": self.high_memory_usage_threshold,
            },
        }
    
    def get_tracing_config(self) -> Dict[str, Any]:
        """Get distributed tracing configuration."""
        return {
            "enabled": self.tracing_enabled,
            "service_name": self.tracing_service_name,
            "jaeger": {
                "enabled": self.tracing_jaeger_enabled,
            },
            "zipkin": {
                "enabled": self.tracing_zipkin_enabled,
            },
            "otlp": {
                "enabled": self.tracing_otlp_enabled,
                "endpoint": self.tracing_endpoint,
            },
        }
    
    def create_directories(self):
        """Create necessary monitoring directories."""
        directories = [
            Path(self.log_file_path).parent,
            Path("./data/metrics"),
            Path("./data/traces"),
            Path("./data/logs"),
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate monitoring configuration."""
        issues = []
        warnings = []
        
        # Check logging configuration
        if self.log_file_enabled:
            log_dir = Path(self.log_file_path).parent
            if not log_dir.exists():
                issues.append(f"Log directory does not exist: {log_dir}")
        
        # Check Prometheus configuration
        if self.prometheus_enabled:
            if not (1 <= self.prometheus_port <= 65535):
                issues.append("Invalid Prometheus port")
        
        # Check health check configuration
        if self.health_check_enabled:
            if not (1 <= self.health_check_interval <= 3600):
                warnings.append("Health check interval seems unusual")
        
        # Check alerting configuration
        if self.alerting_enabled:
            if not any([self.alert_webhook_url, self.alert_email_enabled, self.alert_slack_enabled, self.alert_discord_enabled]):
                issues.append("Alerting enabled but no notification channels configured")
        
        # Check metrics retention
        if self.metrics_retention_days > 365:
            warnings.append("Metrics retention period is very long")
        
        # Check sampling rate
        if self.metrics_sample_rate < 0.1:
            warnings.append("Very low metrics sampling rate may miss important data")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "monitoring_summary": {
                "metrics_enabled": self.metrics_enabled,
                "logging_enabled": self.log_console_enabled or self.log_file_enabled,
                "health_checks": self.health_check_enabled,
                "alerting": self.alerting_enabled,
                "tracing": self.tracing_enabled,
                "apm": self.apm_enabled,
            },
        }


class MonitoringManager:
    """Manages monitoring operations including metrics, logging, and alerting."""
    
    def __init__(self, config: MonitoringConfig):
        self.config = config
        self._metrics_registry = None
        self._alert_manager = None
        
    async def initialize(self):
        """Initialize monitoring system."""
        try:
            # Create directories
            self.config.create_directories()
            
            # Setup logging
            self._setup_logging()
            
            # Initialize metrics registry
            if self.config.metrics_enabled:
                await self._initialize_metrics()
            
            # Initialize alerting
            if self.config.alerting_enabled:
                await self._initialize_alerting()
            
            logger.info("Monitoring manager initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize monitoring manager: {e}")
            raise
    
    def _setup_logging(self):
        """Setup logging configuration."""
        import logging.config
        
        logging_config = self.config.get_logging_config()
        logging.config.dictConfig(logging_config)
        
        logger.info(f"Logging configured with level: {self.config.log_level}")
    
    async def _initialize_metrics(self):
        """Initialize metrics collection."""
        # This would integrate with Prometheus client or similar
        self._metrics_registry = {}
        logger.info("Metrics collection initialized")
    
    async def _initialize_alerting(self):
        """Initialize alerting system."""
        # This would set up alert channels
        self._alert_manager = {}
        logger.info("Alerting system initialized")
    
    async def record_metric(self, name: str, value: float, labels: Dict[str, str] = None):
        """Record a metric."""
        if not self.config.metrics_enabled:
            return
        
        # This would implement actual metric recording
        logger.debug(f"Recording metric: {name}={value}")
    
    async def send_alert(self, title: str, message: str, severity: str = "warning"):
        """Send an alert."""
        if not self.config.alerting_enabled:
            return
        
        # This would implement actual alert sending
        logger.info(f"Sending alert: {title} - {message}")
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform comprehensive health check."""
        health_status = {
            "healthy": True,
            "timestamp": time.time(),
            "checks": {},
        }
        
        try:
            # Check monitoring system itself
            health_status["checks"]["monitoring"] = {
                "status": "healthy",
                "metrics_enabled": self.config.metrics_enabled,
            }
            
            # Additional health checks would be implemented here
            # For example: database connectivity, external services, etc.
            
        except Exception as e:
            health_status["healthy"] = False
            health_status["checks"]["monitoring"] = {
                "status": "unhealthy",
                "error": str(e),
            }
        
        return health_status
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        return {
            "metrics_enabled": self.config.metrics_enabled,
            "metrics_collection": "active" if self._metrics_registry else "inactive",
            "alerting_enabled": self.config.alerting_enabled,
            "health_checks_enabled": self.config.health_check_enabled,
        }


# Monitoring configuration instance
monitoring_config = MonitoringConfig()
monitoring_manager = MonitoringManager(monitoring_config)