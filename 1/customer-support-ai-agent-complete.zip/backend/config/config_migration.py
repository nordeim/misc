"""
Configuration migration utilities.

This module provides configuration migration tools for updating configurations
across versions, handling deprecated settings, and ensuring backward compatibility.
"""

import json
import logging
from typing import Dict, Any, List, Optional, Tuple, Union
from pathlib import Path
from datetime import datetime
import re

from pydantic import BaseSettings


logger = logging.getLogger(__name__)


class MigrationRule:
    """Configuration migration rule."""
    
    def __init__(
        self,
        version_from: str,
        version_to: str,
        description: str,
        rules: List[Dict[str, Any]]
    ):
        self.version_from = version_from
        self.version_to = version_to
        self.description = description
        self.rules = rules
        self.applied_at: Optional[datetime] = None


class ConfigurationMigrator:
    """Configuration migration manager."""
    
    def __init__(self):
        self.migration_rules: List[MigrationRule] = []
        self._load_default_migrations()
    
    def _load_default_migrations(self):
        """Load default migration rules."""
        # Migration from 1.0 to 1.1 - renamed database settings
        self.add_migration_rule(MigrationRule(
            version_from="1.0",
            version_to="1.1",
            description="Rename database.pool_size to database.db_pool_size",
            rules=[
                {
                    "type": "rename_key",
                    "old_key": "database.pool_size",
                    "new_key": "database.db_pool_size"
                }
            ]
        ))
        
        # Migration from 1.1 to 1.2 - restructure Redis configuration
        self.add_migration_rule(MigrationRule(
            version_from="1.1",
            version_to="1.2",
            description="Restructure Redis configuration",
            rules=[
                {
                    "type": "rename_key",
                    "old_key": "redis.timeout",
                    "new_key": "redis.connection_timeout"
                },
                {
                    "type": "add_default",
                    "key": "redis.max_connections",
                    "value": 20
                }
            ]
        ))
        
        # Migration from 1.2 to 1.3 - AI configuration restructuring
        self.add_migration_rule(MigrationRule(
            version_from="1.2",
            version_to="1.3",
            description="Restructure AI configuration",
            rules=[
                {
                    "type": "rename_key",
                    "old_key": "ai.openai_model",
                    "new_key": "ai.openai.model"
                },
                {
                    "type": "move_key",
                    "source": "ai.temperature",
                    "target": "ai.openai.temperature"
                }
            ]
        ))
    
    def add_migration_rule(self, rule: MigrationRule):
        """Add a migration rule."""
        self.migration_rules.append(rule)
        # Sort by version (chronological order)
        self.migration_rules.sort(key=lambda x: x.version_from)
    
    def remove_migration_rule(self, version_from: str, version_to: str):
        """Remove a migration rule."""
        self.migration_rules = [
            r for r in self.migration_rules
            if not (r.version_from == version_from and r.version_to == version_to)
        ]
    
    def get_migration_path(self, from_version: str, to_version: str) -> List[MigrationRule]:
        """Get migration path from one version to another."""
        if from_version == to_version:
            return []
        
        path = []
        current_version = from_version
        
        # Find the shortest path to the target version
        while current_version != to_version:
            # Find next migration rule
            next_rule = None
            for rule in self.migration_rules:
                if rule.version_from == current_version:
                    # Check if this rule leads us closer to the target
                    next_rule = rule
                    break
            
            if not next_rule:
                raise ValueError(f"No migration path found from {current_version} to {to_version}")
            
            path.append(next_rule)
            current_version = next_rule.version_to
        
        return path
    
    def apply_migration(self, config: Dict[str, Any], rule: MigrationRule) -> Dict[str, Any]:
        """Apply a single migration rule to configuration."""
        migrated_config = config.copy()
        
        for migration_rule in rule.rules:
            rule_type = migration_rule["type"]
            
            if rule_type == "rename_key":
                old_key = migration_rule["old_key"]
                new_key = migration_rule["new_key"]
                migrated_config = self._rename_key(migrated_config, old_key, new_key)
            
            elif rule_type == "move_key":
                source = migration_rule["source"]
                target = migration_rule["target"]
                migrated_config = self._move_key(migrated_config, source, target)
            
            elif rule_type == "delete_key":
                key = migration_rule["key"]
                migrated_config = self._delete_key(migrated_config, key)
            
            elif rule_type == "add_default":
                key = migration_rule["key"]
                value = migration_rule["value"]
                migrated_config = self._add_default(migrated_config, key, value)
            
            elif rule_type == "transform_value":
                key = migration_rule["key"]
                transform_func = migration_rule["transform_func"]
                migrated_config = self._transform_value(migrated_config, key, transform_func)
            
            elif rule_type == "split_key":
                key = migration_rule["key"]
                new_keys = migration_rule["new_keys"]
                migrated_config = self._split_key(migrated_config, key, new_keys)
            
            elif rule_type == "merge_keys":
                source_keys = migration_rule["source_keys"]
                target_key = migration_rule["target_key"]
                migrated_config = self._merge_keys(migrated_config, source_keys, target_key)
            
            else:
                logger.warning(f"Unknown migration rule type: {rule_type}")
        
        rule.applied_at = datetime.utcnow()
        logger.info(f"Applied migration: {rule.version_from} -> {rule.version_to}")
        
        return migrated_config
    
    def _get_nested_value(self, config: Dict[str, Any], key: str) -> Tuple[Any, bool]:
        """Get value from nested dictionary using dot notation."""
        keys = key.split('.')
        current = config
        
        for k in keys[:-1]:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return None, False
        
        if isinstance(current, dict) and keys[-1] in current:
            return current[keys[-1]], True
        return None, False
    
    def _set_nested_value(self, config: Dict[str, Any], key: str, value: Any):
        """Set value in nested dictionary using dot notation."""
        keys = key.split('.')
        current = config
        
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        current[keys[-1]] = value
    
    def _delete_nested_key(self, config: Dict[str, Any], key: str) -> bool:
        """Delete key from nested dictionary using dot notation."""
        keys = key.split('.')
        current = config
        
        for k in keys[:-1]:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return False
        
        if isinstance(current, dict) and keys[-1] in current:
            del current[keys[-1]]
            return True
        return False
    
    def _rename_key(self, config: Dict[str, Any], old_key: str, new_key: str) -> Dict[str, Any]:
        """Rename a configuration key."""
        value, exists = self._get_nested_value(config, old_key)
        if exists:
            self._set_nested_value(config, new_key, value)
            self._delete_nested_key(config, old_key)
        return config
    
    def _move_key(self, config: Dict[str, Any], source: str, target: str) -> Dict[str, Any]:
        """Move a configuration key to a new location."""
        value, exists = self._get_nested_value(config, source)
        if exists:
            self._set_nested_value(config, target, value)
            self._delete_nested_key(config, source)
        return config
    
    def _delete_key(self, config: Dict[str, Any], key: str) -> Dict[str, Any]:
        """Delete a configuration key."""
        self._delete_nested_key(config, key)
        return config
    
    def _add_default(self, config: Dict[str, Any], key: str, default_value: Any) -> Dict[str, Any]:
        """Add default value for a key if it doesn't exist."""
        value, exists = self._get_nested_value(config, key)
        if not exists:
            self._set_nested_value(config, key, default_value)
        return config
    
    def _transform_value(self, config: Dict[str, Any], key: str, transform_func: str) -> Dict[str, Any]:
        """Transform a configuration value using a function."""
        value, exists = self._get_nested_value(config, key)
        if exists:
            # Apply transformation based on function name
            if transform_func == "string_to_int":
                try:
                    new_value = int(value)
                    self._set_nested_value(config, key, new_value)
                except ValueError:
                    logger.warning(f"Failed to transform {key} from string to int: {value}")
            elif transform_func == "string_to_bool":
                if isinstance(value, str):
                    new_value = value.lower() in ('true', '1', 'yes', 'on')
                    self._set_nested_value(config, key, new_value)
            elif transform_func == "url_to_dict":
                if isinstance(value, str) and "://" in value:
                    # Parse URL into components
                    from urllib.parse import urlparse
                    parsed = urlparse(value)
                    url_dict = {
                        "scheme": parsed.scheme,
                        "host": parsed.hostname,
                        "port": parsed.port,
                        "path": parsed.path,
                        "query": parsed.query,
                    }
                    self._set_nested_value(config, key, url_dict)
        return config
    
    def _split_key(self, config: Dict[str, Any], key: str, new_keys: List[str]) -> Dict[str, Any]:
        """Split a configuration value into multiple keys."""
        value, exists = self._get_nested_value(config, key)
        if exists and isinstance(value, str):
            # Simple string splitting (could be enhanced for complex parsing)
            parts = value.split(':')
            if len(parts) >= len(new_keys):
                for i, new_key in enumerate(new_keys):
                    if i < len(parts):
                        self._set_nested_value(config, new_key, parts[i])
                self._delete_nested_key(config, key)
        return config
    
    def _merge_keys(self, config: Dict[str, Any], source_keys: List[str], target_key: str) -> Dict[str, Any]:
        """Merge multiple configuration keys into one."""
        values = []
        for source_key in source_keys:
            value, exists = self._get_nested_value(config, source_key)
            if exists:
                values.append(value)
        
        if values:
            # Join values with appropriate separator
            merged_value = ":".join(str(v) for v in values)
            self._set_nested_value(config, target_key, merged_value)
            
            # Delete source keys
            for source_key in source_keys:
                self._delete_nested_key(config, source_key)
        
        return config
    
    def migrate_configuration(
        self, 
        config: Dict[str, Any], 
        from_version: str, 
        to_version: str
    ) -> Dict[str, Any]:
        """Migrate configuration from one version to another."""
        logger.info(f"Migrating configuration from version {from_version} to {to_version}")
        
        if from_version == to_version:
            logger.info("No migration needed - versions are the same")
            return config
        
        try:
            migration_path = self.get_migration_path(from_version, to_version)
            migrated_config = config.copy()
            
            for rule in migration_path:
                logger.info(f"Applying migration: {rule.version_from} -> {rule.version_to}")
                logger.info(f"Description: {rule.description}")
                migrated_config = self.apply_migration(migrated_config, rule)
            
            # Add migration metadata
            migrated_config["_migration_info"] = {
                "from_version": from_version,
                "to_version": to_version,
                "applied_at": datetime.utcnow().isoformat(),
                "migration_path": [f"{rule.version_from}->{rule.version_to}" for rule in migration_path]
            }
            
            logger.info(f"Configuration migration completed successfully")
            return migrated_config
            
        except Exception as e:
            logger.error(f"Configuration migration failed: {e}")
            raise
    
    def validate_migration(self, old_config: Dict[str, Any], new_config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate that migration preserved all necessary data."""
        validation_result = {
            "valid": True,
            "warnings": [],
            "errors": [],
            "changes": []
        }
        
        # Check for data loss
        old_keys = self._get_all_keys(old_config, exclude_internal=True)
        new_keys = self._get_all_keys(new_config, exclude_internal=True)
        
        missing_keys = set(old_keys) - set(new_keys)
        if missing_keys:
            validation_result["warnings"].append(f"Keys lost during migration: {missing_keys}")
            validation_result["changes"].append(f"Lost keys: {missing_keys}")
        
        # Check for new keys
        new_keys_only = set(new_keys) - set(old_keys)
        if new_keys_only:
            validation_result["changes"].append(f"New keys added: {new_keys_only}")
        
        # Validate critical keys exist
        critical_keys = [
            "database.url",
            "redis.host",
            "security.secret_key",
            "application.environment"
        ]
        
        for critical_key in critical_keys:
            value, exists = self._get_nested_value(new_config, critical_key)
            if not exists:
                validation_result["errors"].append(f"Critical key missing after migration: {critical_key}")
                validation_result["valid"] = False
        
        return validation_result
    
    def _get_all_keys(self, config: Dict[str, Any], exclude_internal: bool = False, prefix: str = "") -> List[str]:
        """Get all keys from nested dictionary."""
        keys = []
        
        for key, value in config.items():
            if exclude_internal and key.startswith('_'):
                continue
            
            full_key = f"{prefix}.{key}" if prefix else key
            keys.append(full_key)
            
            if isinstance(value, dict):
                keys.extend(self._get_all_keys(value, exclude_internal, full_key))
        
        return keys
    
    def create_migration_report(self, old_config: Dict[str, Any], new_config: Dict[str, Any]) -> Dict[str, Any]:
        """Create detailed migration report."""
        validation = self.validate_migration(old_config, new_config)
        
        return {
            "migration_successful": validation["valid"],
            "validation": validation,
            "configuration_summary": {
                "old_config_keys": len(self._get_all_keys(old_config)),
                "new_config_keys": len(self._get_all_keys(new_config)),
                "key_changes": len(validation.get("changes", [])),
            },
            "timestamp": datetime.utcnow().isoformat(),
        }
    
    def backup_configuration(self, config: Dict[str, Any], backup_path: Path) -> Path:
        """Backup configuration before migration."""
        backup_path = backup_path.with_suffix(f".backup.{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json")
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, default=str)
        
        logger.info(f"Configuration backed up to: {backup_path}")
        return backup_path


# Global migrator instance
configuration_migrator = ConfigurationMigrator()


def migrate_config_to_version(
    config: Dict[str, Any], 
    current_version: str, 
    target_version: str,
    backup: bool = True
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Migrate configuration to target version.
    
    Returns:
        Tuple of (migrated_config, migration_report)
    """
    # Backup original configuration
    backup_path = Path("config_backup.json")
    if backup:
        configuration_migrator.backup_configuration(config, backup_path)
    
    # Perform migration
    migrated_config = configuration_migrator.migrate_configuration(config, current_version, target_version)
    
    # Create validation report
    report = configuration_migrator.create_migration_report(config, migrated_config)
    
    return migrated_config, report