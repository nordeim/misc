"""
Simple test script for observability system components.

This script tests basic functionality without complex dependencies.
"""

import asyncio
import time
import json
import os
from datetime import datetime
import sys

# Add the backend directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

def test_imports():
    """Test that all observability modules can be imported."""
    print("🧪 Testing Module Imports...")
    
    try:
        # Test basic imports
        import psutil
        print("✅ psutil imported")
        
        from prometheus_client import Counter, Histogram, Gauge
        print("✅ prometheus_client imported")
        
        import structlog
        print("✅ structlog imported")
        
        # Test local imports
        from app.monitoring.backend_monitoring import SystemInfo
        print("✅ backend_monitoring imported")
        
        from app.monitoring.health_check import HealthStatus
        print("✅ health_check imported")
        
        from app.utils.performance_monitor import PerformanceMonitor
        print("✅ performance_monitor imported")
        
        return True
        
    except Exception as e:
        print(f"❌ Import failed: {e}")
        return False

def test_basic_functionality():
    """Test basic monitoring functionality."""
    print("\n⚡ Testing Basic Functionality...")
    
    try:
        # Test psutil system info
        import psutil
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        
        print(f"✅ CPU usage: {cpu_percent}%")
        print(f"✅ Memory usage: {memory.percent}%")
        
        # Test structlog
        import structlog
        logger = structlog.get_logger(__name__)
        logger.info("Test log message", test=True)
        print("✅ Structlog working")
        
        # Test Prometheus metrics creation
        from prometheus_client import Counter, Histogram, Gauge
        
        test_counter = Counter('test_counter_total', 'Test counter')
        test_histogram = Histogram('test_histogram_seconds', 'Test histogram')
        test_gauge = Gauge('test_gauge', 'Test gauge')
        
        test_counter.inc()
        test_histogram.observe(0.1)
        test_gauge.set(42)
        
        print("✅ Prometheus metrics creation working")
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        return False

def test_health_monitoring():
    """Test health monitoring components."""
    print("\n🏥 Testing Health Monitoring...")
    
    try:
        from app.monitoring.health_check import HealthStatus, HealthCheckResult
        
        # Test health status enum
        assert HealthStatus.HEALTHY.value == "healthy"
        assert HealthStatus.DEGRADED.value == "degraded"
        assert HealthStatus.UNHEALTHY.value == "unhealthy"
        
        # Test health check result
        result = HealthCheckResult(
            service="test_service",
            status=HealthStatus.HEALTHY,
            message="Test health check"
        )
        
        assert result.service == "test_service"
        assert result.status == HealthStatus.HEALTHY
        
        print("✅ Health monitoring components working")
        return True
        
    except Exception as e:
        print(f"❌ Health monitoring test failed: {e}")
        return False

def test_performance_monitoring():
    """Test performance monitoring."""
    print("\n⚡ Testing Performance Monitoring...")
    
    try:
        from app.utils.performance_monitor import PerformanceMonitor, PerformanceContext
        
        # Create performance monitor
        monitor = PerformanceMonitor()
        
        # Test performance context
        with PerformanceContext(monitor, "test_operation"):
            time.sleep(0.01)  # Simulate work
        
        # Record a metric
        monitor.record_metric("test_metric", 42.0, "units")
        
        print("✅ Performance monitoring working")
        return True
        
    except Exception as e:
        print(f"❌ Performance monitoring test failed: {e}")
        return False

def test_system_info():
    """Test system information collection."""
    print("\n💻 Testing System Information...")
    
    try:
        from app.monitoring.backend_monitoring import SystemInfo
        
        # Get system info
        system_info = SystemInfo.get_system_info()
        
        # Validate structure
        assert 'system' in system_info
        assert 'process' in system_info
        assert 'platform' in system_info
        
        # Validate system metrics
        system_data = system_info['system']
        assert 'cpu_usage_percent' in system_data
        assert 'memory_percent' in system_data
        
        print(f"✅ System info collected - CPU: {system_data['cpu_usage_percent']:.1f}%")
        print(f"✅ Memory: {system_data['memory_percent']:.1f}%")
        
        return True
        
    except Exception as e:
        print(f"❌ System info test failed: {e}")
        return False

def test_config_loading():
    """Test configuration loading."""
    print("\n⚙️  Testing Configuration...")
    
    try:
        from config.monitoring import monitoring_config
        
        # Test basic config attributes
        assert hasattr(monitoring_config, 'monitoring_enabled')
        assert hasattr(monitoring_config, 'prometheus_enabled')
        assert hasattr(monitoring_config, 'health_check_enabled')
        
        print(f"✅ Monitoring enabled: {monitoring_config.monitoring_enabled}")
        print(f"✅ Prometheus enabled: {monitoring_config.prometheus_enabled}")
        print(f"✅ Health checks enabled: {monitoring_config.health_check_enabled}")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False

def create_simple_observability_service():
    """Create a simple observability service for testing."""
    print("\n🔧 Creating Simple Observability Service...")
    
    try:
        from prometheus_client import Counter, Histogram, Gauge
        import structlog
        from app.monitoring.backend_monitoring import SystemInfo
        
        class SimpleObservabilityService:
            def __init__(self):
                self.logger = structlog.get_logger(__name__)
                
                # Create simple metrics
                self.request_counter = Counter('requests_total', 'Total requests', ['method', 'endpoint'])
                self.response_time_histogram = Histogram('response_time_seconds', 'Response time', ['endpoint'])
                self.active_connections = Gauge('active_connections', 'Active connections')
                
                self.logger.info("Simple observability service initialized")
            
            def record_request(self, method: str, endpoint: str, status_code: int, response_time: float):
                # Record metrics
                self.request_counter.labels(method=method, endpoint=endpoint).inc()
                self.response_time_histogram.labels(endpoint=endpoint).observe(response_time)
                
                self.logger.info("Request recorded",
                               method=method,
                               endpoint=endpoint,
                               status_code=status_code,
                               response_time=response_time)
            
            def get_system_health(self):
                system_info = SystemInfo.get_system_info()
                return {
                    "status": "healthy",
                    "system": system_info,
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            def get_metrics_text(self):
                from prometheus_client import generate_latest
                return generate_latest().decode('utf-8')
        
        # Create and test service
        service = SimpleObservabilityService()
        
        # Record some test requests
        service.record_request("GET", "/test", 200, 0.1)
        service.record_request("POST", "/api/users", 201, 0.25)
        
        # Test health endpoint
        health = service.get_system_health()
        assert health["status"] == "healthy"
        
        # Test metrics endpoint
        metrics_text = service.get_metrics_text()
        assert "requests_total" in metrics_text
        
        print("✅ Simple observability service working")
        return True
        
    except Exception as e:
        print(f"❌ Simple observability service test failed: {e}")
        return False

def main():
    """Run all tests."""
    print("🚀 Starting Simple Observability Tests")
    print("=" * 50)
    
    tests = [
        test_imports,
        test_basic_functionality,
        test_health_monitoring,
        test_performance_monitoring,
        test_system_info,
        test_config_loading,
        create_simple_observability_service
    ]
    
    results = []
    
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)
    
    # Print summary
    print("\n" + "=" * 50)
    print("🎯 TEST SUMMARY")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"✅ Tests Passed: {passed}/{total}")
    print(f"❌ Tests Failed: {total - passed}/{total}")
    print(f"📊 Success Rate: {(passed/total)*100:.1f}%")
    
    if passed == total:
        print("\n🎉 ALL BASIC TESTS PASSED!")
        print("📋 Core observability components are working correctly.")
        print("\n📚 Next steps:")
        print("   - Integration tests with FastAPI app")
        print("   - Full observability service testing")
        print("   - Performance benchmarking")
        print("   - Production deployment validation")
    else:
        print(f"\n⚠️  {total - passed} tests failed.")
        print("🔧 Please check the implementation and dependencies.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
