"""
Agent System API Routes.

This module provides REST API endpoints for managing and monitoring
the Customer Support Agent system.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, status, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.agents import (
    agent_factory,
    agent_monitoring,
    performance_tracker,
    resource_manager,
    diagnostic_tool,
    AgentConfiguration,
    CustomerSupportAgent
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/agents", tags=["Agent System"])


# ==============================================================================
# Pydantic Models for API
# ==============================================================================

class AgentCreateRequest(BaseModel):
    """Request model for creating agents."""
    configuration_name: Optional[str] = None
    custom_config: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    start_immediately: bool = True


class AgentPoolCreateRequest(BaseModel):
    """Request model for creating agent pools."""
    pool_name: str = Field(..., min_length=1, max_length=50)
    min_size: int = Field(default=1, ge=1, le=10)
    max_size: int = Field(default=10, ge=1, le=50)
    configuration_name: Optional[str] = None
    custom_config: Optional[Dict[str, Any]] = None


class AgentResponse(BaseModel):
    """Response model for agent information."""
    agent_id: str
    state: str
    active_sessions: int
    configuration: Dict[str, Any]
    metrics: Dict[str, Any]
    health_status: Dict[str, Any]
    created_at: Optional[str] = None


class SessionCreateRequest(BaseModel):
    """Request model for creating sessions."""
    session_id: str = Field(..., min_length=1, max_length=100)
    user_id: str = Field(..., min_length=1, max_length=100)
    metadata: Optional[Dict[str, Any]] = None


class MessageRequest(BaseModel):
    """Request model for processing messages."""
    message: str = Field(..., min_length=1, max_length=10000)
    session_id: str = Field(..., min_length=1, max_length=100)
    enable_streaming: bool = False


# ==============================================================================
# Agent Management Endpoints
# ==============================================================================

@router.post("/", response_model=Dict[str, Any], status_code=status.HTTP_201_CREATED)
async def create_agent(request: AgentCreateRequest):
    """Create a new agent instance."""
    try:
        agent = await agent_factory.create_agent(
            configuration_name=request.configuration_name,
            custom_config=request.custom_config,
            metadata=request.metadata,
            start_immediately=request.start_immediately
        )
        
        return {
            "message": "Agent created successfully",
            "agent": {
                "agent_id": agent.agent_id,
                "state": agent.state.value,
                "configuration": agent.get_configuration().__dict__
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to create agent: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create agent: {str(e)}"
        )


@router.get("/", response_model=Dict[str, Any])
async def list_agents():
    """Get list of all registered agents."""
    try:
        agents = agent_factory.get_all_agents()
        
        agent_list = []
        for agent_id, agent in agents.items():
            agent_list.append({
                "agent_id": agent_id,
                "state": agent.state.value,
                "active_sessions": len(agent._active_sessions),
                "configuration": agent.get_configuration().__dict__,
                "metrics": agent.get_metrics().__dict__,
                "created_at": datetime.utcnow().isoformat()
            })
        
        return {
            "total_agents": len(agents),
            "agents": agent_list
        }
        
    except Exception as e:
        logger.error(f"Failed to list agents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list agents: {str(e)}"
        )


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str):
    """Get detailed information about a specific agent."""
    try:
        agent = agent_factory.get_agent(agent_id)
        if not agent:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Agent {agent_id} not found"
            )
        
        health = await agent.health_check()
        
        return AgentResponse(
            agent_id=agent_id,
            state=agent.state.value,
            active_sessions=len(agent._active_sessions),
            configuration=agent.get_configuration().__dict__,
            metrics=agent.get_metrics().__dict__,
            health_status=health
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get agent {agent_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get agent: {str(e)}"
        )


@router.delete("/{agent_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_agent(agent_id: str):
    """Delete an agent instance."""
    try:
        agent = agent_factory.get_agent(agent_id)
        if not agent:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Agent {agent_id} not found"
            )
        
        await agent.stop()
        agent_factory.registry.unregister_agent(agent_id)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete agent {agent_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete agent: {str(e)}"
        )


@router.post("/{agent_id}/restart", response_model=Dict[str, Any])
async def restart_agent(agent_id: str):
    """Restart an agent instance."""
    try:
        agent = agent_factory.get_agent(agent_id)
        if not agent:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Agent {agent_id} not found"
            )
        
        # Stop the agent
        await agent.stop()
        
        # Create a new agent with same configuration
        new_agent = await agent_factory.create_agent(
            custom_config=agent.get_configuration(),
            metadata={"restarted_from": agent_id},
            start_immediately=True
        )
        
        return {
            "message": "Agent restarted successfully",
            "original_agent_id": agent_id,
            "new_agent_id": new_agent.agent_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to restart agent {agent_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to restart agent: {str(e)}"
        )


# ==============================================================================
# Agent Pool Management Endpoints
# ==============================================================================

@router.post("/pools", response_model=Dict[str, Any], status_code=status.HTTP_201_CREATED)
async def create_agent_pool(request: AgentPoolCreateRequest):
    """Create a new agent pool."""
    try:
        pool = await agent_factory.create_agent_pool(
            pool_name=request.pool_name,
            min_size=request.min_size,
            max_size=request.max_size,
            configuration_name=request.configuration_name,
            custom_config=request.custom_config
        )
        
        return {
            "message": "Agent pool created successfully",
            "pool": {
                "name": request.pool_name,
                "min_size": request.min_size,
                "max_size": request.max_size,
                "stats": pool.get_stats()
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to create agent pool: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create agent pool: {str(e)}"
        )


@router.get("/pools", response_model=Dict[str, Any])
async def list_agent_pools():
    """Get list of all agent pools."""
    try:
        pools = agent_factory.get_all_pools()
        
        pool_list = []
        for pool_name, pool in pools.items():
            pool_list.append({
                "name": pool_name,
                "stats": pool.get_stats()
            })
        
        return {
            "total_pools": len(pools),
            "pools": pool_list
        }
        
    except Exception as e:
        logger.error(f"Failed to list agent pools: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list agent pools: {str(e)}"
        )


@router.delete("/pools/{pool_name}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_agent_pool(pool_name: str):
    """Delete an agent pool."""
    try:
        pool = agent_factory.get_agent_pool(pool_name)
        if not pool:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Agent pool {pool_name} not found"
            )
        
        await pool.shutdown()
        # Remove from factory's pools dict (this would need to be added to the factory)
        # For now, just log the deletion
        logger.info(f"Agent pool {pool_name} deleted")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete agent pool {pool_name}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete agent pool: {str(e)}"
        )


# ==============================================================================
# Session Management Endpoints
# ==============================================================================

@router.post("/sessions", response_model=Dict[str, Any], status_code=status.HTTP_201_CREATED)
async def create_session(request: SessionCreateRequest):
    """Create a new conversation session."""
    try:
        # For this example, we'll use the first available agent
        agents = agent_factory.get_all_agents()
        if not agents:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="No agents available to handle session"
            )
        
        # Use the first agent (in production, this would use load balancing)
        agent = next(iter(agents.values()))
        
        from app.agents.agent_factory import agent_state_manager
        context = await agent_state_manager.create_session(
            session_id=request.session_id,
            user_id=request.user_id,
            agent=agent,
            metadata=request.metadata
        )
        
        return {
            "message": "Session created successfully",
            "session": {
                "session_id": request.session_id,
                "user_id": request.user_id,
                "agent_id": agent.agent_id,
                "created_at": context.created_at.isoformat()
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create session: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create session: {str(e)}"
        )


@router.post("/sessions/{session_id}/message", response_model=Dict[str, Any])
async def process_message(session_id: str, request: MessageRequest):
    """Process a message through the agent system."""
    try:
        from app.agents.agent_factory import agent_state_manager
        
        # Get session context
        context = await agent_state_manager.get_session_context(session_id)
        if not context:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {session_id} not found"
            )
        
        # Get agent for session
        agent = await agent_state_manager.get_agent_for_session(session_id)
        if not agent:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No agent found for session {session_id}"
            )
        
        # Process message through agent
        response = await agent.process_message(
            message=request.message,
            context=context,
            enable_streaming=request.enable_streaming
        )
        
        return {
            "session_id": session_id,
            "message": request.message,
            "response": response.to_dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to process message for session {session_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process message: {str(e)}"
        )


# ==============================================================================
# Monitoring and Diagnostics Endpoints
# ==============================================================================

@router.get("/metrics/summary", response_model=Dict[str, Any])
async def get_metrics_summary(hours: int = Query(24, ge=1, le=168)):
    """Get system-wide metrics summary."""
    try:
        metrics = await agent_factory.get_metrics_summary()
        
        # Add performance data
        performance_data = await performance_tracker.get_system_performance(hours)
        
        return {
            "time_period_hours": hours,
            "timestamp": datetime.utcnow().isoformat(),
            "metrics_summary": metrics,
            "performance_data": performance_data
        }
        
    except Exception as e:
        logger.error(f"Failed to get metrics summary: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get metrics summary: {str(e)}"
        )


@router.get("/health", response_model=Dict[str, Any])
async def get_health_status():
    """Get comprehensive health status of the agent system."""
    try:
        health_status = await agent_factory.get_health_status()
        monitoring_status = agent_monitoring.get_monitoring_status()
        resource_stats = resource_manager.get_resource_stats()
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": health_status["overall_health"],
            "health_status": health_status,
            "monitoring_status": monitoring_status,
            "resource_stats": resource_stats
        }
        
    except Exception as e:
        logger.error(f"Failed to get health status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get health status: {str(e)}"
        )


@router.get("/diagnostics", response_model=Dict[str, Any])
async def run_diagnostics():
    """Run comprehensive diagnostics on the agent system."""
    try:
        diagnostic_results = await diagnostic_tool.run_full_diagnostic()
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "diagnostic_results": diagnostic_results
        }
        
    except Exception as e:
        logger.error(f"Failed to run diagnostics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to run diagnostics: {str(e)}"
        )


@router.get("/alerts", response_model=Dict[str, Any])
async def get_alerts(hours: int = Query(24, ge=1, le=168)):
    """Get recent alerts from the agent monitoring system."""
    try:
        recent_alerts = agent_monitor.get_recent_alerts(hours)
        alert_summary = agent_monitor.get_monitoring_stats()
        
        return {
            "time_period_hours": hours,
            "timestamp": datetime.utcnow().isoformat(),
            "total_alerts": len(recent_alerts),
            "alerts": [alert.to_dict() for alert in recent_alerts],
            "monitoring_stats": alert_summary
        }
        
    except Exception as e:
        logger.error(f"Failed to get alerts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get alerts: {str(e)}"
        )


@router.get("/configurations", response_model=Dict[str, Any])
async def get_configurations():
    """Get available agent configurations."""
    try:
        config_manager = agent_factory.config_manager
        configurations = config_manager.get_all_configurations()
        
        config_list = []
        for name, config in configurations.items():
            config_list.append({
                "name": name,
                "configuration": config.__dict__
            })
        
        return {
            "total_configurations": len(configurations),
            "configurations": config_list
        }
        
    except Exception as e:
        logger.error(f"Failed to get configurations: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get configurations: {str(e)}"
        )


@router.post("/cleanup", response_model=Dict[str, Any])
async def trigger_cleanup():
    """Trigger manual cleanup of idle agents and expired sessions."""
    try:
        # Cleanup idle agents
        cleaned_agents = await agent_factory.cleanup_idle_agents(idle_threshold_hours=1)
        
        # Cleanup expired sessions
        from app.agents.agent_factory import agent_state_manager
        cleaned_sessions = await agent_state_manager.cleanup_expired_sessions(expiry_hours=1)
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "cleaned_agents": cleaned_agents,
            "cleaned_sessions": cleaned_sessions,
            "message": "Cleanup completed successfully"
        }
        
    except Exception as e:
        logger.error(f"Failed to trigger cleanup: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to trigger cleanup: {str(e)}"
        )


# ==============================================================================
# System Information Endpoints
# ==============================================================================

@router.get("/info", response_model=Dict[str, Any])
async def get_system_info():
    """Get general system information."""
    try:
        agents = agent_factory.get_all_agents()
        pools = agent_factory.get_all_pools()
        
        # Calculate agent state distribution
        state_distribution = {}
        for agent in agents.values():
            state = agent.state.value
            state_distribution[state] = state_distribution.get(state, 0) + 1
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "system_info": {
                "total_agents": len(agents),
                "total_pools": len(pools),
                "agent_state_distribution": state_distribution,
                "version": "1.0.0"
            },
            "agent_factory_status": {
                "registry_size": len(agents),
                "pool_count": len(pools),
                "configurations_available": len(agent_factory.config_manager.get_all_configurations())
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to get system info: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get system info: {str(e)}"
        )