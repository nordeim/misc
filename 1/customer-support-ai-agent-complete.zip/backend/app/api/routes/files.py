"""
Comprehensive File Upload and Processing API Routes

This module provides complete file upload and processing capabilities including:
- Multipart file uploads with progress tracking
- File validation and security scanning
- File processing queue management
- Batch file operations
- File sharing and collaboration
- File versioning and history
- File search and discovery
- Access control and permissions
- File analytics and monitoring

Features:
- Real-time upload progress tracking
- Comprehensive security scanning
- Background processing queue
- File organization and categorization
- Version control and audit logging
- Search and discovery capabilities
- Sharing and collaboration features
"""

import asyncio
import logging
import json
import hashlib
import os
from pathlib import Path
from typing import List, Optional, Dict, Any, Union
from datetime import datetime, timedelta
from uuid import uuid4
import aiofiles
try:
    import magic
except ImportError:
    magic = None
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks, Form
from fastapi import Query, Path as FastAPIPath, Body, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field, validator
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.responses import StreamingResponse as StarletteStreamingResponse

from app.database import get_db
from app.dependencies import get_current_user, get_request_info
from app.config import settings

# Import existing file handling infrastructure
from app.tools.attachment_tool import AttachmentTool, FileType, ProcessingResult
from app.tools.file_storage import StorageManager, StorageType, FileStatus, get_storage_manager
from app.tools.file_analytics import FileAnalyticsEngine, analytics_engine
from app.tools.file_utils import FileValidator, TemporaryFileManager, ContentCleaner

logger = logging.getLogger(__name__)
router = APIRouter()

# Global instances (initialized in startup)
attachment_tool: Optional[AttachmentTool] = None
storage_manager: Optional[StorageManager] = None
file_validator = FileValidator()
temp_file_manager = TemporaryFileManager()
content_cleaner = ContentCleaner()

# Pydantic models for API requests/responses
class UploadProgressResponse(BaseModel):
    """File upload progress response."""
    upload_id: str
    filename: str
    progress: float = Field(ge=0, le=100)
    status: str
    message: Optional[str] = None
    bytes_uploaded: int = 0
    total_bytes: int = 0
    created_at: datetime

class FileProcessingStatus(BaseModel):
    """File processing status response."""
    upload_id: str
    file_id: Optional[int]
    status: str  # pending, processing, completed, failed
    progress: float = Field(ge=0, le=100)
    message: Optional[str] = None
    processed_content: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    processing_time: Optional[float] = None
    created_at: datetime
    completed_at: Optional[datetime] = None

class FileMetadataRequest(BaseModel):
    """File metadata update request."""
    title: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = []
    category: Optional[str] = None
    custom_metadata: Dict[str, Any] = {}

class FileSearchRequest(BaseModel):
    """File search request."""
    query: Optional[str] = None
    file_types: List[str] = []
    tags: List[str] = []
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    size_min: Optional[int] = None
    size_max: Optional[int] = None
    limit: int = Field(default=50, le=500)
    offset: int = Field(default=0, ge=0)

class FileShareRequest(BaseModel):
    """File sharing request."""
    share_with_users: List[str] = []
    permissions: Dict[str, str] = {}  # user_id -> permission level
    expires_at: Optional[datetime] = None
    generate_link: bool = True

class BatchProcessingRequest(BaseModel):
    """Batch file processing request."""
    file_ids: List[int]
    processing_options: Dict[str, Any] = {}
    priority: str = Field(default="normal", regex="^(low|normal|high|urgent)$")

class FileVersionRequest(BaseModel):
    """File versioning request."""
    version_note: Optional[str] = None
    make_current: bool = True

class FileCompressionRequest(BaseModel):
    """File compression request."""
    compression_level: int = Field(default=6, ge=1, le=9)
    output_format: Optional[str] = None

class UploadSessionManager:
    """Manages upload sessions and progress tracking."""
    
    def __init__(self):
        self.upload_sessions = {}
        self.processing_queue = asyncio.Queue()
        self.active_uploads = {}
        
    def create_upload_session(
        self, 
        filename: str, 
        total_size: int, 
        user_id: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create a new upload session."""
        upload_id = str(uuid4())
        
        session = {
            "upload_id": upload_id,
            "filename": filename,
            "total_size": total_size,
            "bytes_uploaded": 0,
            "status": "initializing",
            "user_id": user_id,
            "created_at": datetime.utcnow(),
            "chunks": {},
            "metadata": metadata or {},
            "file_hash": None,
            "validation_results": None
        }
        
        self.upload_sessions[upload_id] = session
        self.active_uploads[upload_id] = session
        
        logger.info(f"Created upload session {upload_id} for file {filename}")
        return upload_id
    
    def update_upload_progress(self, upload_id: str, bytes_uploaded: int) -> Dict[str, Any]:
        """Update upload progress for a session."""
        if upload_id not in self.upload_sessions:
            raise ValueError(f"Upload session {upload_id} not found")
        
        session = self.upload_sessions[upload_id]
        session["bytes_uploaded"] = bytes_uploaded
        session["progress"] = (bytes_uploaded / session["total_size"]) * 100
        
        if bytes_uploaded >= session["total_size"]:
            session["status"] = "completed"
            if upload_id in self.active_uploads:
                del self.active_uploads[upload_id]
        else:
            session["status"] = "uploading"
        
        return self.get_upload_progress(upload_id)
    
    def get_upload_progress(self, upload_id: str) -> UploadProgressResponse:
        """Get upload progress for a session."""
        if upload_id not in self.upload_sessions:
            raise ValueError(f"Upload session {upload_id} not found")
        
        session = self.upload_sessions[upload_id]
        
        return UploadProgressResponse(
            upload_id=upload_id,
            filename=session["filename"],
            progress=session.get("progress", 0),
            status=session["status"],
            bytes_uploaded=session["bytes_uploaded"],
            total_bytes=session["total_size"],
            created_at=session["created_at"],
            message=session.get("error_message")
        )
    
    def add_to_processing_queue(self, upload_id: str, file_data: Dict[str, Any]):
        """Add upload to processing queue."""
        queue_item = {
            "upload_id": upload_id,
            "file_data": file_data,
            "enqueued_at": datetime.utcnow(),
            "priority": file_data.get("priority", "normal")
        }
        
        self.processing_queue.put_nowait(queue_item)
        logger.info(f"Added upload {upload_id} to processing queue")

# Global upload session manager
upload_session_manager = UploadSessionManager()

class FileProcessingQueue:
    """Background file processing queue with priority support."""
    
    def __init__(self):
        self.queue = asyncio.PriorityQueue()
        self.processing_tasks = {}
        self.completed_tasks = {}
        
    async def add_file_processing_task(
        self,
        upload_id: str,
        file_data: Dict[str, Any],
        priority: int = 10  # Lower numbers = higher priority
    ):
        """Add file processing task to queue."""
        task = {
            "upload_id": upload_id,
            "file_data": file_data,
            "created_at": datetime.utcnow(),
            "priority": priority,
            "status": "queued"
        }
        
        await self.queue.put((priority, datetime.utcnow().timestamp(), task))
        logger.info(f"Added file processing task for upload {upload_id} with priority {priority}")
    
    async def get_next_task(self) -> Optional[Dict[str, Any]]:
        """Get next task from queue."""
        try:
            priority, timestamp, task = await asyncio.wait_for(self.queue.get(), timeout=1.0)
            return task
        except asyncio.TimeoutError:
            return None
    
    def update_task_status(self, upload_id: str, status: str, **kwargs):
        """Update task status."""
        if upload_id in self.processing_tasks:
            self.processing_tasks[upload_id].update(kwargs)
            self.processing_tasks[upload_id]["status"] = status
    
    async def process_queue_worker(self):
        """Background worker to process file processing queue."""
        while True:
            try:
                task = await self.get_next_task()
                if not task:
                    await asyncio.sleep(1)
                    continue
                
                upload_id = task["upload_id"]
                logger.info(f"Starting processing for upload {upload_id}")
                
                # Mark as processing
                self.processing_tasks[upload_id] = task
                task["status"] = "processing"
                task["started_at"] = datetime.utcnow()
                
                # Process the file
                try:
                    result = await process_uploaded_file(task["upload_id"], task["file_data"])
                    
                    # Mark as completed
                    task.update({
                        "status": "completed",
                        "result": result,
                        "completed_at": datetime.utcnow(),
                        "processing_time": (datetime.utcnow() - task["started_at"]).total_seconds()
                    })
                    
                    self.completed_tasks[upload_id] = task
                    logger.info(f"Successfully processed upload {upload_id}")
                    
                except Exception as e:
                    logger.error(f"Error processing upload {upload_id}: {str(e)}")
                    
                    # Mark as failed
                    task.update({
                        "status": "failed",
                        "error": str(e),
                        "completed_at": datetime.utcnow()
                    })
                    
                    self.completed_tasks[upload_id] = task
                
            except Exception as e:
                logger.error(f"Error in processing queue worker: {str(e)}")
                await asyncio.sleep(5)

# Global processing queue
processing_queue = FileProcessingQueue()

# Start background processing worker
async def start_processing_workers():
    """Start background processing workers."""
    asyncio.create_task(processing_queue.process_queue_worker())

# ==============================================================================
# FILE UPLOAD ENDPOINTS
# ==============================================================================

@router.post("/upload/initiate", response_model=UploadProgressResponse)
async def initiate_file_upload(
    filename: str = Form(...),
    total_size: int = Form(...),
    user_id: Optional[str] = Depends(get_current_user),
    metadata: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db)
):
    """
    Initiate a file upload session.
    
    Returns an upload session ID for tracking upload progress.
    """
    try:
        # Parse metadata if provided
        upload_metadata = {}
        if metadata:
            try:
                upload_metadata = json.loads(metadata)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid metadata format")
        
        # Validate filename and size
        if not filename or total_size <= 0:
            raise HTTPException(status_code=400, detail="Invalid filename or size")
        
        # Check file size limits
        if total_size > settings.upload_max_file_size_mb * 1024 * 1024:
            raise HTTPException(
                status_code=413, 
                detail=f"File too large. Maximum size is {settings.upload_max_file_size_mb}MB"
            )
        
        # Create upload session
        upload_id = upload_session_manager.create_upload_session(
            filename=filename,
            total_size=total_size,
            user_id=user_id,
            metadata=upload_metadata
        )
        
        logger.info(f"Initiated upload session {upload_id} for file {filename}")
        
        return upload_session_manager.get_upload_progress(upload_id)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error initiating upload: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to initiate upload")

@router.post("/upload/chunk")
async def upload_file_chunk(
    upload_id: str = Form(...),
    chunk_data: bytes = File(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """
    Upload a file chunk for multipart file upload.
    
    Supports large file uploads by splitting into chunks.
    """
    try:
        # Validate upload session
        if upload_id not in upload_session_manager.upload_sessions:
            raise HTTPException(status_code=404, detail="Upload session not found")
        
        session = upload_session_manager.upload_sessions[upload_id]
        
        # Verify chunk index
        if chunk_index < 0 or chunk_index >= total_chunks:
            raise HTTPException(status_code=400, detail="Invalid chunk index")
        
        # Store chunk temporarily
        chunk_key = f"{upload_id}_chunk_{chunk_index}"
        temp_file_path = temp_file_manager.temp_dir / chunk_key
        
        async with aiofiles.open(temp_file_path, 'wb') as f:
            await f.write(chunk_data)
        
        # Update progress
        bytes_uploaded = (chunk_index + 1) * len(chunk_data)
        progress = upload_session_manager.update_upload_progress(upload_id, bytes_uploaded)
        
        # If this was the last chunk, prepare for processing
        if chunk_index == total_chunks - 1:
            session["status"] = "ready_for_processing"
            logger.info(f"All chunks received for upload {upload_id}")
        
        return progress
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error uploading chunk: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to upload chunk")

@router.post("/upload/complete", response_model=FileProcessingStatus)
async def complete_file_upload(
    upload_id: str = Form(...),
    user_id: Optional[str] = Depends(get_current_user),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """
    Complete a file upload and start processing.
    
    Combines chunks and validates the final file.
    """
    try:
        # Validate upload session
        if upload_id not in upload_session_manager.upload_sessions:
            raise HTTPException(status_code=404, detail="Upload session not found")
        
        session = upload_session_manager.upload_sessions[upload_id]
        
        # Combine chunks into final file
        final_file_path = await combine_upload_chunks(upload_id, session)
        
        # Calculate file hash
        file_hash = await calculate_file_hash(final_file_path)
        session["file_hash"] = file_hash
        
        # Validate file
        validation_result = await validate_uploaded_file(final_file_path, session)
        session["validation_results"] = validation_result
        
        if not validation_result["valid"]:
            # Clean up and remove session
            await cleanup_upload_session(upload_id)
            raise HTTPException(
                status_code=400, 
                detail=f"File validation failed: {validation_result['error']}"
            )
        
        # Add to processing queue
        file_data = {
            "file_path": str(final_file_path),
            "session": session,
            "validation_result": validation_result,
            "priority": "normal"
        }
        
        await processing_queue.add_file_processing_task(upload_id, file_data, priority=10)
        
        # Create processing status response
        processing_status = FileProcessingStatus(
            upload_id=upload_id,
            file_id=None,  # Will be set after processing
            status="processing",
            progress=0,
            message="File queued for processing",
            created_at=session["created_at"]
        )
        
        return processing_status
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error completing upload: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to complete upload")

@router.get("/upload/progress/{upload_id}", response_model=UploadProgressResponse)
async def get_upload_progress(
    upload_id: str = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get upload progress for a given upload session."""
    try:
        return upload_session_manager.get_upload_progress(upload_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

# ==============================================================================
# FILE PROCESSING ENDPOINTS
# ==============================================================================

@router.get("/processing/status/{upload_id}", response_model=FileProcessingStatus)
async def get_processing_status(
    upload_id: str = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get file processing status."""
    try:
        # Check if task exists in processing queue
        if upload_id in processing_queue.processing_tasks:
            task = processing_queue.processing_tasks[upload_id]
            
            return FileProcessingStatus(
                upload_id=upload_id,
                file_id=task["file_data"].get("file_id"),
                status=task["status"],
                progress=task.get("progress", 0),
                message=task.get("message"),
                processed_content=task.get("result", {}).get("content"),
                metadata=task.get("result", {}).get("metadata"),
                processing_time=task.get("processing_time"),
                created_at=task["created_at"],
                completed_at=task.get("completed_at")
            )
        
        # Check completed tasks
        if upload_id in processing_queue.completed_tasks:
            task = processing_queue.completed_tasks[upload_id]
            
            return FileProcessingStatus(
                upload_id=upload_id,
                file_id=task["file_data"].get("file_id"),
                status=task["status"],
                progress=100,
                message="Processing completed" if task["status"] == "completed" else task.get("error"),
                processed_content=task.get("result", {}).get("content"),
                metadata=task.get("result", {}).get("metadata"),
                processing_time=task.get("processing_time"),
                created_at=task["created_at"],
                completed_at=task.get("completed_at")
            )
        
        raise HTTPException(status_code=404, detail="Processing task not found")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting processing status: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get processing status")

@router.post("/processing/retry/{upload_id}")
async def retry_file_processing(
    upload_id: str = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Retry failed file processing."""
    try:
        if upload_id not in processing_queue.completed_tasks:
            raise HTTPException(status_code=404, detail="Original upload not found")
        
        original_task = processing_queue.completed_tasks[upload_id]
        
        if original_task["status"] != "failed":
            raise HTTPException(status_code=400, detail="Upload processing did not fail")
        
        # Add back to processing queue with higher priority
        await processing_queue.add_file_processing_task(
            upload_id, 
            original_task["file_data"], 
            priority=1  # High priority for retries
        )
        
        # Remove from completed tasks
        del processing_queue.completed_tasks[upload_id]
        
        return {"message": "File added back to processing queue"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrying processing: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to retry processing")

@router.post("/batch/upload")
async def batch_file_upload(
    files: List[UploadFile] = File(...),
    user_id: Optional[str] = Depends(get_current_user),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """Upload multiple files simultaneously."""
    try:
        upload_ids = []
        
        for file in files:
            if not file.filename:
                continue
            
            # Read file content
            content = await file.read()
            file_size = len(content)
            
            # Create upload session
            upload_id = upload_session_manager.create_upload_session(
                filename=file.filename,
                total_size=file_size,
                user_id=user_id,
                metadata={"original_filename": file.filename}
            )
            
            # Save file directly (small files)
            final_file_path = await save_file_directly(content, file.filename, upload_id)
            
            # Validate file
            validation_result = await validate_uploaded_file(final_file_path)
            
            if validation_result["valid"]:
                # Add to processing queue
                file_data = {
                    "file_path": str(final_file_path),
                    "session": {
                        "filename": file.filename,
                        "total_size": file_size,
                        "user_id": user_id
                    },
                    "validation_result": validation_result,
                    "priority": "normal"
                }
                
                await processing_queue.add_file_processing_task(upload_id, file_data, priority=10)
                upload_ids.append(upload_id)
            else:
                logger.warning(f"File validation failed for {file.filename}")
        
        return {
            "upload_ids": upload_ids,
            "total_files": len(files),
            "successful_uploads": len(upload_ids),
            "failed_uploads": len(files) - len(upload_ids)
        }
        
    except Exception as e:
        logger.error(f"Error in batch upload: {str(e)}")
        raise HTTPException(status_code=500, detail="Batch upload failed")

@router.post("/batch/process", response_model=Dict[str, Any])
async def batch_process_files(
    request: BatchProcessingRequest,
    user_id: Optional[str] = Depends(get_current_user)
):
    """Process multiple files in batch."""
    try:
        processed_count = 0
        failed_files = []
        
        for file_id in request.file_ids:
            try:
                # Get file data from storage
                if storage_manager:
                    file_data = await storage_manager.get_file(file_id)
                    
                    if file_data:
                        # Add to processing queue
                        await processing_queue.add_file_processing_task(
                            f"batch_{file_id}",
                            {
                                "file_id": file_id,
                                "file_data": file_data,
                                "options": request.processing_options
                            },
                            priority={"low": 20, "normal": 10, "high": 5, "urgent": 1}[request.priority]
                        )
                        processed_count += 1
                    else:
                        failed_files.append(file_id)
                else:
                    failed_files.append(file_id)
                    
            except Exception as e:
                logger.error(f"Error processing file {file_id}: {str(e)}")
                failed_files.append(file_id)
        
        return {
            "processed_count": processed_count,
            "failed_count": len(failed_files),
            "failed_files": failed_files,
            "priority": request.priority
        }
        
    except Exception as e:
        logger.error(f"Error in batch processing: {str(e)}")
        raise HTTPException(status_code=500, detail="Batch processing failed")

# ==============================================================================
# FILE MANAGEMENT ENDPOINTS
# ==============================================================================

@router.get("/files/list")
async def list_files(
    session_id: Optional[str] = Query(None),
    file_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=500),
    offset: int = Query(0, ge=0),
    user_id: Optional[str] = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List files with filtering and pagination."""
    try:
        files = []
        
        if storage_manager:
            if session_id:
                storage_files = await storage_manager.get_files_by_session(session_id)
                
                for file_record in storage_files:
                    # Filter by type if specified
                    if file_type and file_record.file_type != file_type:
                        continue
                    
                    # Filter by status if specified
                    if status and file_record.status.value != status:
                        continue
                    
                    files.append({
                        "id": file_record.id,
                        "filename": file_record.original_name,
                        "file_type": file_record.file_type,
                        "mime_type": file_record.mime_type,
                        "size": file_record.file_size,
                        "status": file_record.status.value,
                        "created_at": file_record.created_at,
                        "modified_at": file_record.modified_at,
                        "hash": file_record.file_hash,
                        "tags": file_record.tags or []
                    })
            else:
                # Get all files (limited by storage manager capabilities)
                stats = await storage_manager.db_storage.get_storage_stats()
                files = [{
                    "total_files": stats.total_files,
                    "total_size_mb": stats.total_size_mb,
                    "files_by_type": stats.files_by_type,
                    "files_by_status": stats.files_by_status
                }]
        
        # Apply pagination
        paginated_files = files[offset:offset + limit]
        
        return {
            "files": paginated_files,
            "total_count": len(files),
            "limit": limit,
            "offset": offset,
            "has_more": len(files) > offset + limit
        }
        
    except Exception as e:
        logger.error(f"Error listing files: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to list files")

@router.get("/files/{file_id}/download")
async def download_file(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Download a file by ID."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_data = await storage_manager.get_file(file_id)
        
        if not file_data:
            raise HTTPException(status_code=404, detail="File not found")
        
        file_record = file_data["record"]
        content = file_data["content"]
        
        if not content:
            raise HTTPException(status_code=404, detail="File content not found")
        
        # Update access time
        await storage_manager.db_storage.update_access_time(file_id)
        
        # Return file as streaming response
        return StreamingResponse(
            iter([content]),
            media_type=file_record.mime_type,
            headers={
                "Content-Disposition": f'attachment; filename="{file_record.original_name}"',
                "Content-Length": str(len(content))
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to download file")

@router.get("/files/{file_id}/metadata")
async def get_file_metadata(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get comprehensive file metadata."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_record = await storage_manager.db_storage.get_file_record(file_id)
        
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found")
        
        return {
            "id": file_record.id,
            "filename": file_record.original_name,
            "file_path": file_record.file_path,
            "file_type": file_record.file_type,
            "mime_type": file_record.mime_type,
            "size": file_record.file_size,
            "hash": file_record.file_hash,
            "status": file_record.status.value,
            "created_at": file_record.created_at,
            "modified_at": file_record.modified_at,
            "accessed_at": file_record.accessed_at,
            "processing_started": file_record.processing_started,
            "processing_completed": file_record.processing_completed,
            "metadata": file_record.metadata or {},
            "tags": file_record.tags or [],
            "error_message": file_record.error_message
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting file metadata: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get file metadata")

@router.put("/files/{file_id}/metadata")
async def update_file_metadata(
    file_id: int = FastAPIPath(...),
    metadata: FileMetadataRequest = Body(...),
    user_id: Optional[str] = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update file metadata and tags."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_record = await storage_manager.db_storage.get_file_record(file_id)
        
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found")
        
        # Update metadata
        new_metadata = file_record.metadata or {}
        
        if metadata.title:
            new_metadata["title"] = metadata.title
        
        if metadata.description:
            new_metadata["description"] = metadata.description
        
        if metadata.category:
            new_metadata["category"] = metadata.category
        
        if metadata.custom_metadata:
            new_metadata.update(metadata.custom_metadata)
        
        # Update database
        await storage_manager.db_storage.update_file_status(
            file_id,
            file_record.status,
            metadata=new_metadata,
            tags=metadata.tags
        )
        
        return {"message": "File metadata updated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating file metadata: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update file metadata")

@router.delete("/files/{file_id}")
async def delete_file(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Delete a file completely."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        success = await storage_manager.delete_file(file_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="File not found")
        
        return {"message": "File deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting file: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to delete file")

@router.post("/files/{file_id}/archive")
async def archive_file(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Archive a file to long-term storage."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        success = await storage_manager.archive_file(file_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="File not found")
        
        return {"message": "File archived successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error archiving file: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to archive file")

# ==============================================================================
# FILE SEARCH AND DISCOVERY
# ==============================================================================

@router.post("/files/search")
async def search_files(
    request: FileSearchRequest,
    user_id: Optional[str] = Depends(get_current_user)
):
    """Search files with advanced filtering."""
    try:
        # This is a simplified search implementation
        # In production, you'd use a proper search engine like Elasticsearch
        
        results = []
        
        if storage_manager:
            # Get all files from database
            stats = await storage_manager.db_storage.get_storage_stats()
            
            # For now, return basic statistics
            # In production, implement proper search with database queries
            results.append({
                "type": "search_results_summary",
                "total_files": stats.total_files,
                "files_by_type": stats.files_by_type,
                "files_by_status": stats.files_by_status,
                "query": request.query,
                "filters_applied": {
                    "file_types": request.file_types,
                    "tags": request.tags,
                    "date_range": {
                        "from": request.date_from.isoformat() if request.date_from else None,
                        "to": request.date_to.isoformat() if request.date_to else None
                    },
                    "size_range": {
                        "min": request.size_min,
                        "max": request.size_max
                    }
                }
            })
        
        return {
            "results": results,
            "total_count": len(results),
            "query": request.query,
            "limit": request.limit,
            "offset": request.offset
        }
        
    except Exception as e:
        logger.error(f"Error searching files: {str(e)}")
        raise HTTPException(status_code=500, detail="File search failed")

@router.get("/files/search/suggestions")
async def get_search_suggestions(
    query: str = Query(..., min_length=1),
    limit: int = Query(10, le=50),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get search suggestions based on query."""
    try:
        # Generate suggestions based on existing file metadata
        suggestions = []
        
        if storage_manager:
            # Get storage stats and generate suggestions
            stats = await storage_manager.db_storage.get_storage_stats()
            
            # Add file type suggestions
            for file_type, count in stats.files_by_type.items():
                if query.lower() in file_type.lower():
                    suggestions.append({
                        "type": "file_type",
                        "value": file_type,
                        "count": count
                    })
        
        # Add common file extensions
        common_extensions = ['pdf', 'docx', 'txt', 'jpg', 'png', 'csv', 'xlsx']
        for ext in common_extensions:
            if query.lower() in ext.lower() and ext not in [s["value"] for s in suggestions]:
                suggestions.append({
                    "type": "extension",
                    "value": ext,
                    "count": 0
                })
        
        return {
            "suggestions": suggestions[:limit],
            "query": query,
            "total_suggestions": len(suggestions)
        }
        
    except Exception as e:
        logger.error(f"Error getting search suggestions: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get suggestions")

# ==============================================================================
# FILE SHARING AND COLLABORATION
# ==============================================================================

@router.post("/files/{file_id}/share")
async def share_file(
    file_id: int = FastAPIPath(...),
    request: FileShareRequest = Body(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Share a file with other users."""
    try:
        # Generate share link if requested
        share_link = None
        if request.generate_link:
            share_link = f"/api/v1/files/shared/{file_id}?token={str(uuid4())}"
        
        # Create sharing record (simplified)
        # In production, implement proper access control and permissions
        share_record = {
            "file_id": file_id,
            "shared_by": user_id,
            "shared_with": request.share_with_users,
            "permissions": request.permissions,
            "expires_at": request.expires_at,
            "share_link": share_link,
            "created_at": datetime.utcnow()
        }
        
        # Store sharing information (simplified)
        # In production, use database with proper access control
        logger.info(f"File {file_id} shared by {user_id}")
        
        return {
            "message": "File shared successfully",
            "share_link": share_link,
            "shared_with": request.share_with_users,
            "expires_at": request.expires_at
        }
        
    except Exception as e:
        logger.error(f"Error sharing file: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to share file")

@router.get("/files/shared/{token}")
async def access_shared_file(
    token: str = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Access a file through a shared link."""
    try:
        # Validate token and return file access
        # This is a simplified implementation
        # In production, implement proper token validation and access control
        
        return {
            "message": "Shared file access granted",
            "token": token,
            "access_granted": True,
            "expires_at": datetime.utcnow() + timedelta(hours=24)
        }
        
    except Exception as e:
        logger.error(f"Error accessing shared file: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to access shared file")

# ==============================================================================
# FILE VERSIONING AND HISTORY
# ==============================================================================

@router.get("/files/{file_id}/versions")
async def get_file_versions(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get file version history."""
    try:
        # Simplified version history
        # In production, implement proper version control system
        
        versions = [
            {
                "version_id": 1,
                "file_id": file_id,
                "created_at": datetime.utcnow() - timedelta(days=1),
                "created_by": "user1",
                "size": 1024,
                "hash": "abc123",
                "note": "Initial version",
                "is_current": True
            },
            {
                "version_id": 2,
                "file_id": file_id,
                "created_at": datetime.utcnow(),
                "created_by": user_id,
                "size": 2048,
                "hash": "def456",
                "note": "Updated with new content",
                "is_current": False
            }
        ]
        
        return {
            "versions": versions,
            "current_version": 1,
            "total_versions": len(versions)
        }
        
    except Exception as e:
        logger.error(f"Error getting file versions: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get file versions")

@router.post("/files/{file_id}/versions")
async def create_file_version(
    file_id: int = FastAPIPath(...),
    request: FileVersionRequest = Body(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Create a new version of a file."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_record = await storage_manager.db_storage.get_file_record(file_id)
        
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found")
        
        # Create new version (simplified)
        # In production, implement proper version control
        
        new_version = {
            "version_id": int(datetime.utcnow().timestamp()),
            "file_id": file_id,
            "created_at": datetime.utcnow(),
            "created_by": user_id,
            "note": request.version_note,
            "is_current": request.make_current
        }
        
        if request.make_current:
            # Update file as current version
            await storage_manager.db_storage.update_file_status(
                file_id,
                file_record.status,
                metadata={"current_version": new_version["version_id"]}
            )
        
        logger.info(f"Created version {new_version['version_id']} for file {file_id}")
        
        return {
            "message": "File version created successfully",
            "version": new_version
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating file version: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to create file version")

# ==============================================================================
# FILE SECURITY AND AUDIT
# ==============================================================================

@router.get("/security/audit/files")
async def get_file_audit_log(
    file_id: Optional[int] = Query(None),
    user_id: Optional[str] = Depends(get_current_user),
    limit: int = Query(100, le=1000)
):
    """Get file access audit log."""
    try:
        # Simplified audit log
        # In production, implement comprehensive audit logging
        
        audit_events = [
            {
                "event_id": 1,
                "file_id": file_id,
                "event_type": "upload",
                "user_id": "user1",
                "timestamp": datetime.utcnow() - timedelta(hours=2),
                "ip_address": "192.168.1.1",
                "user_agent": "Mozilla/5.0...",
                "details": "File uploaded successfully"
            },
            {
                "event_id": 2,
                "file_id": file_id,
                "event_type": "process",
                "user_id": "system",
                "timestamp": datetime.utcnow() - timedelta(hours=1),
                "ip_address": "127.0.0.1",
                "user_agent": "FileProcessor/1.0",
                "details": "File processing completed"
            },
            {
                "event_id": 3,
                "file_id": file_id,
                "event_type": "download",
                "user_id": user_id,
                "timestamp": datetime.utcnow() - timedelta(minutes=30),
                "ip_address": "192.168.1.2",
                "user_agent": "Mozilla/5.0...",
                "details": "File downloaded by user"
            }
        ]
        
        return {
            "audit_events": audit_events[:limit],
            "total_events": len(audit_events),
            "file_id": file_id
        }
        
    except Exception as e:
        logger.error(f"Error getting audit log: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get audit log")

@router.get("/security/scan/{file_id}")
async def security_scan_file(
    file_id: int = FastAPIPath(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Perform security scan on a file."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_record = await storage_manager.db_storage.get_file_record(file_id)
        
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found")
        
        # Perform security scan (simplified)
        # In production, integrate with actual antivirus/anti-malware engines
        
        scan_result = {
            "file_id": file_id,
            "scan_time": datetime.utcnow(),
            "status": "clean",
            "threats": [],
            "warnings": [],
            "scan_engine": "BasicFileScanner v1.0",
            "definitions_version": "2024.1.1"
        }
        
        # Check for basic security issues
        if file_record.file_type in ["exe", "bat", "cmd", "com", "scr"]:
            scan_result["status"] = "warning"
            scan_result["warnings"].append("Executable file detected")
        
        if file_record.file_size > 50 * 1024 * 1024:  # 50MB
            scan_result["warnings"].append("Large file size")
        
        return scan_result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error performing security scan: {str(e)}")
        raise HTTPException(status_code=500, detail="Security scan failed")

# ==============================================================================
# FILE UTILITIES AND PROCESSING
# ==============================================================================

@router.post("/utils/detect-format")
async def detect_file_format(
    file: UploadFile = File(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Detect file format and metadata."""
    try:
        # Save temporarily for analysis
        file_content = await file.read()
        temp_path = await run_in_threadpool(
            lambda: temp_file_manager.save_to_temp_file(
                file_content, 
                prefix=f"detect_{uuid4()}_", 
                suffix=Path(file.filename).suffix
            )
        )
        
        # Analyze file
        file_info = await attachment_tool._get_file_info(str(temp_path))
        file_type, mime_type = attachment_tool.file_detector.detect_file_type(str(temp_path))
        
        # Clean up
        temp_path.unlink(missing_ok=True)
        
        return {
            "filename": file.filename,
            "detected_format": {
                "file_type": file_type.value,
                "mime_type": mime_type,
                "extension": file_info["extension"]
            },
            "file_info": {
                "size": file_info["size"],
                "hash": file_info["hash"],
                "created_at": file_info["created_at"],
                "modified_at": file_info["modified_at"]
            },
            "validation": {
                "is_supported": file_type != FileType.UNKNOWN,
                "is_safe": True  # Basic check
            }
        }
        
    except Exception as e:
        logger.error(f"Error detecting file format: {str(e)}")
        raise HTTPException(status_code=500, detail="Format detection failed")

@router.post("/utils/compress/{file_id}")
async def compress_file(
    file_id: int = FastAPIPath(...),
    request: FileCompressionRequest = Body(...),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Compress a file."""
    try:
        if not storage_manager:
            raise HTTPException(status_code=503, detail="Storage service unavailable")
        
        file_record = await storage_manager.db_storage.get_file_record(file_id)
        
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found")
        
        # Get file content
        file_data = await storage_manager.get_file(file_id)
        content = file_data["content"]
        
        if not content:
            raise HTTPException(status_code=404, detail="File content not found")
        
        # Create compressed version
        import gzip
        import zlib
        
        compressed_content = zlib.compress(content, level=request.compression_level)
        
        # Save compressed version
        compressed_file_path = temp_file_manager.temp_dir / f"compressed_{file_id}.gz"
        
        async with aiofiles.open(compressed_file_path, 'wb') as f:
            await f.write(compressed_content)
        
        compression_ratio = len(content) / len(compressed_content) if compressed_content else 0
        
        # Clean up
        compressed_file_path.unlink(missing_ok=True)
        
        return {
            "file_id": file_id,
            "original_size": len(content),
            "compressed_size": len(compressed_content),
            "compression_ratio": round(compression_ratio, 2),
            "space_saved": len(content) - len(compressed_content),
            "compression_level": request.compression_level
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error compressing file: {str(e)}")
        raise HTTPException(status_code=500, detail="File compression failed")

@router.get("/analytics/files")
async def get_file_analytics(
    time_window_hours: int = Query(24, le=168),
    user_id: Optional[str] = Depends(get_current_user)
):
    """Get comprehensive file processing analytics."""
    try:
        # Get analytics from various components
        analytics_data = {}
        
        # Storage analytics
        if storage_manager:
            storage_stats = await storage_manager.get_comprehensive_stats()
            analytics_data["storage"] = storage_stats
        
        # Processing analytics
        processing_analytics = await analytics_engine.get_comprehensive_analytics(time_window_hours)
        analytics_data["processing"] = processing_analytics
        
        # Attachment tool analytics
        attachment_analytics = await attachment_tool.get_processing_analytics()
        analytics_data["attachment_tool"] = attachment_analytics
        
        return {
            "time_window_hours": time_window_hours,
            "analytics": analytics_data,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting file analytics: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get file analytics")

@router.post("/maintenance/cleanup")
async def perform_maintenance_cleanup(
    user_id: Optional[str] = Depends(get_current_user)
):
    """Perform maintenance cleanup operations."""
    try:
        cleanup_results = {}
        
        # Clean up old files
        if storage_manager:
            cleaned_count = await storage_manager.cleanup_expired_files()
            cleanup_results["expired_files_cleaned"] = cleaned_count
        
        # Clean up temporary files
        temp_cleaned = await temp_file_manager.cleanup_temp_files(max_age_hours=24)
        cleanup_results["temp_files_cleaned"] = temp_cleaned
        
        # Clean up upload sessions
        upload_session_manager.upload_sessions = {
            k: v for k, v in upload_session_manager.upload_sessions.items()
            if v["status"] != "completed"
        }
        cleanup_results["old_upload_sessions_cleaned"] = len(upload_session_manager.upload_sessions)
        
        # Clean up analytics data
        await analytics_engine.cleanup_old_data()
        cleanup_results["old_analytics_cleaned"] = True
        
        return {
            "message": "Maintenance cleanup completed",
            "cleanup_results": cleanup_results,
            "cleanup_time": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error during maintenance cleanup: {str(e)}")
        raise HTTPException(status_code=500, detail="Maintenance cleanup failed")

# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================

async def process_uploaded_file(upload_id: str, file_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process an uploaded file."""
    try:
        session = file_data["session"]
        validation_result = file_data["validation_result"]
        
        # Update processing status
        processing_queue.update_task_status(upload_id, "processing", progress=25)
        
        # Process with attachment tool
        processed_files = await attachment_tool.process_attachments([file_data["file_path"]])
        
        processing_queue.update_task_status(upload_id, "processing", progress=75)
        
        if processed_files:
            processed_file = processed_files[0]
            
            # Store file if storage manager is available
            file_id = None
            if storage_manager:
                record_id, file_hash = await storage_manager.store_file(
                    content=open(file_data["file_path"], 'rb').read(),
                    session_id=session.get("session_id", upload_id),
                    filename=session["filename"],
                    file_type=processed_file["file_type"],
                    mime_type=processed_file["mime_type"],
                    metadata={
                        "processing_result": processed_file,
                        "upload_session": upload_id,
                        "original_validation": validation_result
                    }
                )
                file_id = record_id
            
            # Record analytics
            await analytics_engine.record_file_processing(
                session_id=upload_id,
                file_type=processed_file["file_type"],
                processing_time=0,  # Will be calculated separately
                success=True,
                file_size=processed_file["file_size"],
                content=processed_file.get("processed_content")
            )
            
            return {
                "file_id": file_id,
                "content": processed_file.get("processed_content"),
                "metadata": processed_file.get("metadata"),
                "status": "completed",
                "message": "File processed successfully"
            }
        else:
            raise Exception("No processed files returned")
            
    except Exception as e:
        logger.error(f"Error processing uploaded file {upload_id}: {str(e)}")
        
        # Record error in analytics
        await analytics_engine.record_file_processing(
            session_id=upload_id,
            file_type="unknown",
            processing_time=0,
            success=False,
            file_size=0,
            error_message=str(e)
        )
        
        raise

async def combine_upload_chunks(upload_id: str, session: Dict[str, Any]) -> Path:
    """Combine upload chunks into final file."""
    try:
        # Create final file path
        final_file_path = temp_file_manager.temp_dir / f"final_{upload_id}_{session['filename']}"
        
        # Combine all chunks
        with open(final_file_path, 'wb') as final_file:
            # Get all chunk files
            chunk_files = sorted(
                temp_file_manager.temp_dir.glob(f"{upload_id}_chunk_*"),
                key=lambda x: int(x.name.split('_')[-1])
            )
            
            for chunk_file in chunk_files:
                async with aiofiles.open(chunk_file, 'rb') as chunk:
                    content = await chunk.read()
                    await final_file.write(content)
                
                # Clean up chunk file
                chunk_file.unlink(missing_ok=True)
        
        return final_file_path
        
    except Exception as e:
        logger.error(f"Error combining chunks for {upload_id}: {str(e)}")
        raise

async def calculate_file_hash(file_path: Path) -> str:
    """Calculate SHA256 hash of file."""
    sha256_hash = hashlib.sha256()
    async with aiofiles.open(file_path, 'rb') as f:
        while chunk := await f.read(8192):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()

async def validate_uploaded_file(file_path: Path, session: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Validate uploaded file."""
    try:
        # Use file validator
        validation_result = file_validator.comprehensive_validate(str(file_path))
        
        # Additional security scan
        if attachment_tool:
            security_scan = await attachment_tool.security_scanner.scan_file(str(file_path))
            validation_result["security_scan"] = security_scan
            
            if not security_scan["safe"]:
                validation_result["valid"] = False
                validation_result["error"] = f"Security scan failed: {', '.join(security_scan['threats'])}"
        
        return validation_result
        
    except Exception as e:
        logger.error(f"Error validating uploaded file: {str(e)}")
        return {
            "valid": False,
            "error": f"Validation error: {str(e)}"
        }

async def save_file_directly(content: bytes, filename: str, upload_id: str) -> Path:
    """Save file content directly."""
    file_path = temp_file_manager.temp_dir / f"direct_{upload_id}_{filename}"
    
    async with aiofiles.open(file_path, 'wb') as f:
        await f.write(content)
    
    return file_path

async def cleanup_upload_session(upload_id: str):
    """Clean up upload session and temporary files."""
    try:
        # Remove from active uploads
        if upload_id in upload_session_manager.active_uploads:
            del upload_session_manager.active_uploads[upload_id]
        
        # Clean up session
        if upload_id in upload_session_manager.upload_sessions:
            del upload_session_manager.upload_sessions[upload_id]
        
        # Clean up chunk files
        chunk_pattern = f"{upload_id}_chunk_*"
        for chunk_file in temp_file_manager.temp_dir.glob(chunk_pattern):
            chunk_file.unlink(missing_ok=True)
        
        logger.info(f"Cleaned up upload session {upload_id}")
        
    except Exception as e:
        logger.error(f"Error cleaning up upload session {upload_id}: {str(e)}")

# ==============================================================================
# STARTUP INITIALIZATION
# ==============================================================================

async def initialize_file_upload_system():
    """Initialize file upload system components."""
    global attachment_tool, storage_manager
    
    try:
        # Initialize attachment tool
        attachment_tool = AttachmentTool()
        logger.info("Attachment tool initialized")
        
        # Initialize storage manager
        storage_manager = await get_storage_manager()
        logger.info("Storage manager initialized")
        
        # Start processing workers
        await start_processing_workers()
        logger.info("File processing workers started")
        
        # Start temporary file cleanup
        await temp_file_manager.start_auto_cleanup()
        logger.info("Temporary file cleanup started")
        
        logger.info("File upload system initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing file upload system: {str(e)}")
        raise

# Export initialization function for main application
__all__ = [
    "router",
    "initialize_file_upload_system",
    "upload_session_manager",
    "processing_queue"
]