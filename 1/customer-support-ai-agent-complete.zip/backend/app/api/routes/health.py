"""
Comprehensive health check and monitoring endpoints.

This module provides:
- /health: Basic health check
- /health/ready: Readiness probe with dependencies
- /health/live: Liveness probe
- /health/dependencies: Detailed dependency status
- /health/metrics: System metrics
- /health/system: System information
- /health/version: Application version
- /health/config: Non-sensitive configuration
"""

from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import JSONResponse, PlainTextResponse
from typing import Dict, Any, Optional
import time
import psutil
import os
from datetime import datetime

from app.monitoring import (
    HealthStatus,
    run_health_checks,
    get_health_summary,
    SystemInfo,
    metrics
)
from app.config import settings

router = APIRouter()

@router.get("/health")
async def basic_health_check():
    """
    Basic health check endpoint.
    
    Returns a simple status indicator for basic load balancer health checks.
    This endpoint performs minimal checks to ensure fast response times.
    """
    start_time = time.time()
    
    try:
        # Basic checks - only essential services
        checks = await run_health_checks(["database"])
        health_summary = get_health_summary(checks)
        
        # Determine response status
        overall_status = health_summary["overall_status"]
        response_code = 200 if overall_status in ["healthy", "degraded"] else 503
        
        response_time_ms = (time.time() - start_time) * 1000
        
        result = {
            "status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "version": settings.app_version,
            "environment": settings.environment,
            "checks": {
                "database": checks.get("database", {}).to_dict() if "database" in checks else None
            }
        }
        
        return JSONResponse(status_code=response_code, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e),
                "version": settings.app_version,
                "environment": settings.environment
            }
        )

@router.get("/health/ready")
async def readiness_probe():
    """
    Readiness probe endpoint.
    
    Checks all dependencies and services to determine if the application
    is ready to receive traffic. Returns 200 if ready, 503 if not ready.
    """
    start_time = time.time()
    
    try:
        # Run all dependency checks
        checks = await run_health_checks()
        health_summary = get_health_summary(checks)
        
        # Determine readiness based on critical services
        critical_services = ["database", "redis", "filesystem"]
        critical_checks = {name: result for name, result in checks.items() 
                          if name in critical_services}
        
        # Application is ready if no critical services are unhealthy
        critical_unhealthy = any(
            result.status == HealthStatus.UNHEALTHY 
            for result in critical_checks.values()
        )
        
        overall_status = "ready" if not critical_unhealthy else "not_ready"
        response_code = 200 if overall_status == "ready" else 503
        
        response_time_ms = (time.time() - start_time) * 1000
        
        result = {
            "status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "checks": {
                name: result.to_dict() 
                for name, result in checks.items()
            },
            "critical_services": {
                name: result.to_dict() 
                for name, result in critical_checks.items()
            },
            "summary": health_summary["summary"]
        }
        
        return JSONResponse(status_code=response_code, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e),
                "checks": {},
                "critical_services": {}
            }
        )

@router.get("/health/live")
async def liveness_probe():
    """
    Liveness probe endpoint.
    
    Simple check to determine if the application is alive and responsive.
    This should never return 503 unless the application is completely broken.
    """
    start_time = time.time()
    
    try:
        # Minimal check - just verify we can respond
        response_time_ms = (time.time() - start_time) * 1000
        
        # Check if process is still running
        process = psutil.Process()
        if process.status() == psutil.STATUS_ZOMBIE:
            raise Exception("Process is in zombie state")
        
        result = {
            "status": "alive",
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "process": {
                "pid": process.pid,
                "status": process.status(),
                "create_time": datetime.fromtimestamp(process.create_time()).isoformat(),
                "memory_percent": process.memory_percent(),
                "cpu_percent": process.cpu_percent()
            }
        }
        
        return JSONResponse(status_code=200, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "dead",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@router.get("/health/dependencies")
async def dependency_status():
    """
    Detailed dependency status endpoint.
    
    Provides comprehensive information about all service dependencies
    including connectivity status, response times, and configuration.
    """
    start_time = time.time()
    
    try:
        # Run all dependency checks
        checks = await run_health_checks()
        health_summary = get_health_summary(checks)
        
        response_time_ms = (time.time() - start_time) * 1000
        
        # Group checks by category
        dependency_categories = {
            "database": ["database"],
            "cache": ["redis"],
            "vector_store": ["chromadb"],
            "ai_services": ["openai", "azure_openai"],
            "storage": ["filesystem"]
        }
        
        categorized_checks = {}
        for category, service_list in dependency_categories.items():
            categorized_checks[category] = {
                name: result.to_dict() 
                for name, result in checks.items() 
                if name in service_list
            }
        
        # Add any uncategorized checks
        categorized_checks["other"] = {
            name: result.to_dict() 
            for name, result in checks.items() 
            if not any(name in services for services in dependency_categories.values())
        }
        
        result = {
            "overall_status": health_summary["overall_status"],
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "total_checks": health_summary["total_checks"],
            "summary": health_summary["summary"],
            "dependencies": categorized_checks,
            "all_checks": {
                name: result.to_dict() 
                for name, result in checks.items()
            }
        }
        
        return JSONResponse(status_code=200, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "overall_status": "error",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e),
                "dependencies": {}
            }
        )

@router.get("/health/metrics")
async def system_metrics():
    """
    System metrics endpoint.
    
    Returns current system metrics and performance information
    in both human-readable JSON format and Prometheus text format.
    """
    start_time = time.time()
    
    try:
        # Get system information
        system_info = SystemInfo.get_system_info()
        
        # Get Prometheus metrics
        prometheus_metrics = metrics.get_metrics()
        
        response_time_ms = (time.time() - start_time) * 1000
        
        result = {
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "system": system_info,
            "application": {
                "name": settings.app_name,
                "version": settings.app_version,
                "environment": settings.environment,
                "uptime_seconds": time.time() - psutil.Process().create_time()
            },
            "configuration": {
                "database_type": "sqlite" if "sqlite" in settings.database_url.lower() else "postgresql",
                "redis_enabled": bool(settings.redis_host),
                "prometheus_enabled": settings.prometheus_enabled,
                "health_checks_enabled": settings.health_check_enabled
            }
        }
        
        return JSONResponse(status_code=200, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e),
                "system": {},
                "application": {}
            }
        )

@router.get("/health/system")
async def system_information():
    """
    System information endpoint.
    
    Returns detailed system information including OS details,
    resource usage, and process information.
    """
    start_time = time.time()
    
    try:
        # Get comprehensive system information
        system_info = SystemInfo.get_system_info()
        
        # Add additional system details
        try:
            # Load average (Unix-like systems)
            load_avg = os.getloadavg() if hasattr(os, 'getloadavg') else None
            
            # Network interfaces
            network_stats = {}
            try:
                network_io = psutil.net_io_counters()
                network_stats = {
                    "bytes_sent": network_io.bytes_sent,
                    "bytes_recv": network_io.bytes_recv,
                    "packets_sent": network_io.packets_sent,
                    "packets_recv": network_io.packets_recv
                }
            except:
                network_stats = {"error": "Could not retrieve network statistics"}
            
            # Disk I/O
            disk_io_stats = {}
            try:
                disk_io = psutil.disk_io_counters()
                disk_io_stats = {
                    "read_count": disk_io.read_count,
                    "write_count": disk_io.write_count,
                    "read_bytes": disk_io.read_bytes,
                    "write_bytes": disk_io.write_bytes
                }
            except:
                disk_io_stats = {"error": "Could not retrieve disk I/O statistics"}
            
        except Exception as e:
            load_avg = None
            network_stats = {"error": str(e)}
            disk_io_stats = {"error": str(e)}
        
        response_time_ms = (time.time() - start_time) * 1000
        
        result = {
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2),
            "system": system_info.get("system", {}),
            "process": system_info.get("process", {}),
            "platform": system_info.get("platform", {}),
            "additional": {
                "load_average": load_avg,
                "network_io": network_stats,
                "disk_io": disk_io_stats
            }
        }
        
        return JSONResponse(status_code=200, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@router.get("/health/version")
async def version_info():
    """
    Application version endpoint.
    
    Returns version information and build details.
    """
    start_time = time.time()
    
    try:
        response_time_ms = (time.time() - start_time) * 1000
        
        # Get process information
        process = psutil.Process()
        
        result = {
            "application": {
                "name": settings.app_name,
                "version": settings.app_version,
                "environment": settings.environment,
                "debug_mode": settings.app_debug
            },
            "runtime": {
                "python_version": process.username(),  # This is not actually Python version
                "process_id": process.pid,
                "start_time": datetime.fromtimestamp(process.create_time()).isoformat(),
                "uptime_seconds": time.time() - process.create_time()
            },
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2)
        }
        
        return JSONResponse(status_code=200, content=result)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@router.get("/health/config")
async def configuration_info():
    """
    Non-sensitive configuration endpoint.
    
    Returns configuration information excluding sensitive data like API keys.
    """
    start_time = time.time()
    
    try:
        response_time_ms = (time.time() - start_time) * 1000
        
        # Extract non-sensitive configuration
        config_info = {
            "application": {
                "name": settings.app_name,
                "version": settings.app_version,
                "environment": settings.environment,
                "debug_mode": settings.app_debug,
                "log_level": settings.log_level
            },
            "server": {
                "api_host": settings.api_host,
                "api_port": settings.api_port,
                "cors_origins": list(settings.cors_origins),
                "cors_allow_credentials": settings.cors_allow_credentials
            },
            "database": {
                "url": settings.database_url.split("@")[-1] if "@" in settings.database_url else "sqlite:///",
                "pool_size": settings.db_pool_size,
                "pool_timeout": settings.db_pool_timeout
            },
            "redis": {
                "host": settings.redis_host,
                "port": settings.redis_port,
                "db": settings.redis_db,
                "enabled": bool(settings.redis_host and settings.redis_host != "localhost")
            },
            "chromadb": {
                "host": settings.chroma_host,
                "port": settings.chroma_port,
                "persist_directory": str(settings.chroma_persist_path),
                "collection_name": settings.chroma_collection_name
            },
            "ai": {
                "openai_model": settings.openai_model,
                "azure_openai_deployment": settings.azure_openai_deployment_name,
                "embedding_model": settings.embedding_model,
                "openai_configured": bool(settings.openai_api_key),
                "azure_openai_configured": bool(settings.azure_openai_api_key and settings.azure_openai_endpoint)
            },
            "monitoring": {
                "prometheus_enabled": settings.prometheus_enabled,
                "prometheus_port": settings.prometheus_port,
                "metrics_endpoint": settings.metrics_endpoint,
                "health_check_enabled": settings.health_check_enabled
            },
            "features": {
                "rag_enabled": settings.rag_enabled,
                "memory_enabled": settings.memory_enabled,
                "upload_enabled": settings.upload_enabled,
                "rate_limit_enabled": settings.rate_limit_enabled,
                "escalation_enabled": settings.escalation_enabled
            },
            "validation": settings.validate_configuration(),
            "timestamp": datetime.utcnow().isoformat(),
            "response_time_ms": round(response_time_ms, 2)
        }
        
        return JSONResponse(status_code=200, content=config_info)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )