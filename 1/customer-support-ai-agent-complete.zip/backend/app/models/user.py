"""
User ORM model for authentication and user management.
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer
from sqlalchemy.orm import relationship

from .base import Base, ORMBase, BaseSchema
from pydantic import EmailStr, Field


class UserORM(Base, ORMBase):
    """User ORM model for authentication and user management."""
    
    __tablename__ = "users"
    
    # Core user information
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    full_name = Column(String(100), nullable=True)
    
    # Authentication
    hashed_password = Column(String(255), nullable=False)
    
    # Status and metadata
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)
    
    # Profile information
    avatar_url = Column(String(500), nullable=True)
    bio = Column(Text, nullable=True)
    timezone = Column(String(50), default="UTC", nullable=False)
    language = Column(String(10), default="en", nullable=False)
    
    # Usage tracking
    login_count = Column(Integer, default=0, nullable=False)
    last_login = Column(DateTime, nullable=True)
    last_login_ip = Column(String(45), nullable=True)  # Support IPv6
    
    # Relationships
    sessions = relationship("SessionORM", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<UserORM(id={self.id}, email='{self.email}', username='{self.username}')>"
    
    def verify_login(self) -> None:
        """Update login statistics."""
        self.login_count += 1
        self.last_login = datetime.utcnow()
        self.last_active_at = datetime.utcnow()
    
    def deactivate(self) -> None:
        """Deactivate user account."""
        self.is_active = False
        self.updated_at = datetime.utcnow()
    
    def activate(self) -> None:
        """Activate user account."""
        self.is_active = True
        self.updated_at = datetime.utcnow()
    
    def promote_to_superuser(self) -> None:
        """Promote user to superuser."""
        self.is_superuser = True
        self.updated_at = datetime.utcnow()
    
    @classmethod
    def get_by_email(cls, session, email: str) -> Optional["UserORM"]:
        """Get user by email."""
        return session.query(cls).filter(cls.email == email).first()
    
    @classmethod
    def get_by_username(cls, session, username: str) -> Optional["UserORM"]:
        """Get user by username."""
        return session.query(cls).filter(cls.username == username).first()
    
    @classmethod
    def create_user(cls, session, **kwargs) -> "UserORM":
        """Create a new user."""
        user = cls(**kwargs)
        session.add(user)
        session.flush()
        return user


# Pydantic Schemas for User
class UserBase(BaseSchema):
    """Base user schema."""
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=50)
    full_name: Optional[str] = Field(None, max_length=100)
    bio: Optional[str] = Field(None, max_length=500)
    timezone: str = Field(default="UTC", max_length=50)
    language: str = Field(default="en", max_length=10)


class UserCreate(UserBase):
    """Schema for creating a user."""
    password: str = Field(..., min_length=8, max_length=128)


class UserUpdate(BaseSchema):
    """Schema for updating a user."""
    full_name: Optional[str] = Field(None, max_length=100)
    bio: Optional[str] = Field(None, max_length=500)
    timezone: Optional[str] = Field(None, max_length=50)
    language: Optional[str] = Field(None, max_length=10)
    avatar_url: Optional[str] = Field(None, max_length=500)


class UserRead(UserBase):
    """Schema for reading user data."""
    id: str
    is_active: bool
    is_verified: bool
    is_superuser: bool
    avatar_url: Optional[str]
    login_count: int
    last_login: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class UserLogin(BaseSchema):
    """Schema for user login."""
    email: EmailStr
    password: str


class UserPasswordReset(BaseSchema):
    """Schema for password reset."""
    email: EmailStr


class UserPasswordUpdate(BaseSchema):
    """Schema for password update."""
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)