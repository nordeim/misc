"""
Base model class with common fields and functionality.
"""

from datetime import datetime
from typing import Any, Dict, Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, DateTime, String, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import DeclarativeBase

from pydantic import BaseModel as PydanticBaseModel

# SQLAlchemy Base
class Base(DeclarativeBase):
    """Base class for all SQLAlchemy models."""
    pass


class ORMBase:
    """Base functionality for all ORM models."""
    
    # Common columns
    id = Column(String, primary_key=True, default=lambda: str(uuid4()))
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model instance to dictionary."""
        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }
    
    def to_pydantic(self, schema_class=None):
        """Convert SQLAlchemy model to Pydantic model."""
        if schema_class:
            return schema_class(**self.to_dict())
        return self.to_dict()
    
    def update(self, **kwargs) -> None:
        """Update model fields."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.updated_at = datetime.utcnow()
    
    def soft_delete(self) -> None:
        """Mark model as deleted without removing from database."""
        self.is_deleted = True
        self.deleted_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()


# Pydantic Base Schema
class BaseSchema(PydanticBaseModel):
    """Base Pydantic schema with common functionality."""
    
    id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: str,
        }
    
    def dict(self, **kwargs) -> Dict[str, Any]:
        """Convert schema to dictionary."""
        data = super().dict(**kwargs)
        # Convert UUID objects to strings
        for key, value in data.items():
            if isinstance(value, UUID):
                data[key] = str(value)
        return data