"""
Escalation-related database models.
"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum

from sqlalchemy import (
    Column, String, DateTime, Boolean, Integer, Float, Text, JSON, Enum as SQLEnum,
    ForeignKey, Index
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.models.base import Base, ORMBase


class EscalationStatus(str, Enum):
    """Status of escalation."""
    PENDING = "pending"
    ROUTED = "routed"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"
    ESCALATED_AGAIN = "escalated_again"


class EscalationPriority(str, Enum):
    """Priority levels for escalations."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    URGENT = "urgent"


class EscalationReason(str, Enum):
    """Reasons for escalation."""
    SENTIMENT = "sentiment"
    KEYWORDS = "keywords"
    CONVERSATION_LENGTH = "conversation_length"
    CONFIDENCE = "confidence"
    COMPLEXITY = "complexity"
    MANUAL_REQUEST = "manual_request"
    TECHNICAL_ISSUE = "technical_issue"
    BILLING_ISSUE = "billing_issue"
    POLICY_VIOLATION = "policy_violation"
    COMPLAINT = "complaint"
    FRAUD = "fraud"


class EscalationType(str, Enum):
    """Type of escalation."""
    AUTOMATIC = "automatic"
    MANUAL = "manual"
    SCHEDULED = "scheduled"


class EscalationQueueORM(Base, ORMBase):
    """Escalation queue for managing human handoffs."""
    
    __tablename__ = "escalation_queues"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    
    # Queue configuration
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    department = Column(String(100), nullable=False)
    skill_requirements = Column(JSON, nullable=True)  # List of required skills
    business_hours = Column(JSON, nullable=True)  # Business hours configuration
    time_zone = Column(String(50), default="UTC")
    max_wait_time_minutes = Column(Integer, default=30)
    
    # Queue status and availability
    is_active = Column(Boolean, default=True, nullable=False)
    capacity = Column(Integer, default=10)  # Max concurrent cases
    current_load = Column(Integer, default=0)
    
    # Routing rules
    routing_rules = Column(JSON, nullable=True)  # Priority and routing rules
    auto_assignment = Column(Boolean, default=True)
    
    # Performance metrics
    avg_resolution_time_minutes = Column(Float, default=0.0)
    customer_satisfaction_score = Column(Float, default=0.0)
    escalation_rate = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    escalations = relationship("EscalationORM", back_populates="queue")


class EscalationPolicyORM(Base, ORMBase):
    """Escalation policies and rules."""
    
    __tablename__ = "escalation_policies"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    
    # Policy configuration
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    policy_type = Column(String(50), nullable=False)  # sentiment, keywords, complexity, etc.
    
    # Rules and thresholds
    rules = Column(JSON, nullable=False)  # Policy rules and conditions
    thresholds = Column(JSON, nullable=True)  # Thresholds for triggering escalation
    
    # Department and queue routing
    target_department = Column(String(100), nullable=False)
    target_queue_id = Column(UUID(as_uuid=True), ForeignKey("escalation_queues.id"))
    
    # Priority and time-based rules
    priority_score = Column(Integer, default=1)  # Policy priority
    time_conditions = Column(JSON, nullable=True)  # Time-based conditions
    
    # Policy status
    is_active = Column(Boolean, default=True, nullable=False)
    version = Column(Integer, default=1)
    
    # Performance tracking
    trigger_count = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_triggered = Column(DateTime, nullable=True)
    
    # Relationships
    queue = relationship("EscalationQueueORM", foreign_keys=[target_queue_id])
    escalations = relationship("EscalationORM", back_populates="policy")


class EscalationORM(Base, ORMBase):
    """Escalation case for human handoff."""
    
    __tablename__ = "escalations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    
    # Related entities
    session_id = Column(String, nullable=False, index=True)
    user_id = Column(String, nullable=False, index=True)
    policy_id = Column(UUID(as_uuid=True), ForeignKey("escalation_policies.id"), nullable=True)
    queue_id = Column(UUID(as_uuid=True), ForeignKey("escalation_queues.id"), nullable=False)
    
    # Escalation details
    escalation_type = Column(SQLEnum(EscalationType), default=EscalationType.AUTOMATIC)
    status = Column(SQLEnum(EscalationStatus), default=EscalationStatus.PENDING, index=True)
    priority = Column(SQLEnum(EscalationPriority), default=EscalationPriority.MEDIUM, index=True)
    
    # Reasons and triggers
    reasons = Column(JSON, nullable=False)  # List of escalation reasons
    trigger_score = Column(Float, nullable=False)  # Escalation trigger score
    trigger_context = Column(JSON, nullable=True)  # Context that triggered escalation
    
    # Human assignment
    assigned_agent_id = Column(String, nullable=True)
    assigned_agent_name = Column(String(255), nullable=True)
    assigned_at = Column(DateTime, nullable=True)
    
    # Resolution tracking
    resolved_at = Column(DateTime, nullable=True)
    resolution_time_minutes = Column(Float, nullable=True)
    resolution_notes = Column(Text, nullable=True)
    customer_feedback = Column(Text, nullable=True)
    satisfaction_score = Column(Integer, nullable=True)  # 1-5 scale
    
    # SLA tracking
    response_time_minutes = Column(Float, nullable=True)
    resolution_time_sla_minutes = Column(Integer, default=120)  # 2 hours default
    
    # Analytics and metrics
    escalation_trend = Column(String(50), nullable=True)  # improving, stable, declining
    complexity_score = Column(Float, default=0.0)
    reintegration_needed = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    policy = relationship("EscalationPolicyORM", back_populates="escalations")
    queue = relationship("EscalationQueueORM", back_populates="escalations")
    analytics = relationship("EscalationAnalyticsORM", back_populates="escalation")


class EscalationAnalyticsORM(Base, ORMBase):
    """Analytics and metrics for escalations."""
    
    __tablename__ = "escalation_analytics"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    escalation_id = Column(UUID(as_uuid=True), ForeignKey("escalations.id"), nullable=False, index=True)
    
    # Time-based analytics
    date = Column(DateTime, default=datetime.utcnow, nullable=False)
    hour = Column(Integer, nullable=False)  # 0-23
    
    # Metrics
    escalation_count = Column(Integer, default=1)
    avg_response_time_minutes = Column(Float, default=0.0)
    avg_resolution_time_minutes = Column(Float, default=0.0)
    customer_satisfaction_avg = Column(Float, default=0.0)
    
    # Queue performance
    queue_utilization = Column(Float, default=0.0)
    wait_time_avg_minutes = Column(Float, default=0.0)
    abandoned_rate = Column(Float, default=0.0)
    
    # Resolution patterns
    first_contact_resolution_rate = Column(Float, default=0.0)
    escalation_resolution_rate = Column(Float, default=0.0)
    callback_required_rate = Column(Float, default=0.0)
    
    # Quality metrics
    agent_performance_score = Column(Float, default=0.0)
    customer_reachability_rate = Column(Float, default=0.0)
    issue_complexity_avg = Column(Float, default=0.0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationships
    escalation = relationship("EscalationORM", back_populates="analytics")


# Indexes for performance
Index('idx_escalations_session_status', EscalationORM.session_id, EscalationORM.status)
Index('idx_escalations_user_created', EscalationORM.user_id, EscalationORM.created_at)
Index('idx_escalations_queue_priority', EscalationORM.queue_id, EscalationORM.priority)
Index('idx_escalations_created_status', EscalationORM.created_at, EscalationORM.status)
Index('idx_analytics_date_hour', EscalationAnalyticsORM.date, EscalationAnalyticsORM.hour)