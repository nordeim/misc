"""
Message ORM model for conversation messages.
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID, uuid4

from sqlalchemy import (
    Column, String, DateTime, Text, JSON, Integer, 
    ForeignKey, Boolean, Float, LargeBinary
)
from sqlalchemy.orm import relationship

from .base import Base, ORMBase, BaseSchema
from pydantic import Field


class MessageORM(Base, ORMBase):
    """Message ORM model for conversation messages."""
    
    __tablename__ = "messages"
    
    # Core message information
    session_id = Column(String, ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    role = Column(String(20), nullable=False, index=True)  # 'user', 'assistant', 'system'
    content = Column(Text, nullable=False)
    
    # Message metadata
    content_type = Column(String(50), default="text", nullable=False)  # 'text', 'image', 'file', 'json'
    model_name = Column(String(100), nullable=True)
    provider = Column(String(50), nullable=True)
    
    # Token and cost tracking
    prompt_tokens = Column(Integer, default=0, nullable=False)
    completion_tokens = Column(Integer, default=0, nullable=False)
    total_tokens = Column(Integer, default=0, nullable=False)
    cost_usd = Column(Float, default=0.0, nullable=False)
    
    # Message status and flags
    is_error = Column(Boolean, default=False, nullable=False)
    is_system_prompt = Column(Boolean, default=False, nullable=False)
    is_final_response = Column(Boolean, default=False, nullable=False)
    
    # Attachments and metadata
    attachments = Column(JSON, nullable=True)  # Store file references, images, etc.
    tool_calls = Column(JSON, nullable=True)  # Store tool call information
    meta_data = Column(JSON, nullable=True)    # Additional metadata
    
    # Generation parameters
    temperature = Column(Float, nullable=True)
    max_tokens = Column(Integer, nullable=True)
    top_p = Column(Float, nullable=True)
    frequency_penalty = Column(Float, nullable=True)
    presence_penalty = Column(Float, nullable=True)
    
    # Message sequence and threading
    sequence_number = Column(Integer, nullable=False, index=True)  # Order in session
    parent_message_id = Column(String, ForeignKey("messages.id"), nullable=True)
    
    # Relationships
    session = relationship("SessionORM", back_populates="messages")
    parent_message = relationship("MessageORM", remote_side=[id], backref="child_messages")
    
    def __repr__(self) -> str:
        return f"<MessageORM(id={self.id}, session_id='{self.session_id}', role='{self.role}')>"


# Pydantic Schemas for Message
class MessageBase(BaseSchema):
    """Base message schema."""
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str
    content_type: Optional[str] = Field(None, max_length=50)
    model_name: Optional[str] = Field(None, max_length=100)
    provider: Optional[str] = Field(None, max_length=50)
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    top_p: Optional[float] = Field(None, ge=0.0, le=1.0)
    attachments: Optional[List[dict]] = None
    metadata: Optional[dict] = Field(default=None, description="Message metadata")


class MessageCreate(MessageBase):
    """Schema for creating a message."""
    pass


class MessageUpdate(BaseSchema):
    """Schema for updating a message."""
    content: Optional[str] = None
    content_type: Optional[str] = Field(None, max_length=50)
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    top_p: Optional[float] = Field(None, ge=0.0, le=1.0)
    attachments: Optional[List[dict]] = None
    metadata: Optional[dict] = None


class MessageRead(MessageBase):
    """Schema for reading message data."""
    id: str
    session_id: str
    sequence_number: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_usd: float
    is_error: bool
    is_system_prompt: bool
    is_final_response: bool
    tool_calls: Optional[List[dict]]
    parent_message_id: Optional[str]
    created_at: datetime
    updated_at: datetime


class MessageContext(BaseSchema):
    """Schema for message in context."""
    role: str
    content: str
