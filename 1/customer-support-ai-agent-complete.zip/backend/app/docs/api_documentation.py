"""
Enhanced API documentation system.

Provides comprehensive API documentation including:
- OpenAPI/Swagger enhancement
- Request/response examples
- Error code documentation
- API versioning and compatibility
- Interactive documentation features
"""

import json
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, status
from fastapi.openapi.utils import get_openapi
from pydantic import BaseModel, Field
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class APIExample(BaseModel):
    """API endpoint example."""
    name: str
    description: Optional[str] = None
    request_example: Optional[Dict[str, Any]] = None
    response_example: Optional[Dict[str, Any]] = None
    curl_example: Optional[str] = None
    parameters: Optional[Dict[str, str]] = None

class ErrorCodeInfo(BaseModel):
    """Error code information."""
    code: str
    status_code: int
    message: str
    description: Optional[str] = None
    troubleshooting: Optional[List[str]] = None
    examples: Optional[List[Dict[str, Any]]] = None

class APIEndpointDoc(BaseModel):
    """Complete API endpoint documentation."""
    endpoint: str
    method: str
    summary: str
    description: str
    tags: List[str]
    deprecated: bool = False
    version_added: str = "1.0.0"
    version_changed: Optional[str] = None
    examples: List[APIExample] = []
    error_codes: List[ErrorCodeInfo] = []
    rate_limits: Optional[Dict[str, Any]] = None
    authentication_required: bool = True
    permissions_required: Optional[List[str]] = None
    related_endpoints: Optional[List[str]] = None

class APIVersionInfo(BaseModel):
    """API version information."""
    version: str
    status: str  # "stable", "beta", "deprecated"
    release_date: str
    deprecation_date: Optional[str] = None
    breaking_changes: Optional[List[str]] = None
    new_features: Optional[List[str]] = None
    bug_fixes: Optional[List[str]] = None

class APICompatibilityInfo(BaseModel):
    """API compatibility information."""
    backward_compatible: bool
    breaking_changes: List[str]
    migration_guide: Optional[str] = None
    version_support: Dict[str, str]  # version -> support status

class EnhancedAPIDocumentation:
    """Enhanced API documentation system."""
    
    def __init__(self):
        self.endpoint_docs = self._load_endpoint_documentation()
        self.error_codes = self._load_error_codes()
        self.api_versions = self._load_api_versions()
        self.compatibility_info = self._load_compatibility_info()
        
        logger.info("Enhanced API documentation initialized")
    
    def _load_endpoint_documentation(self) -> Dict[str, APIEndpointDoc]:
        """Load endpoint documentation."""
        return {
            # Authentication endpoints
            "POST /api/v1/auth/login": APIEndpointDoc(
                endpoint="/api/v1/auth/login",
                method="POST",
                summary="User login",
                description="Authenticate user and receive access tokens",
                tags=["authentication"],
                examples=[
                    APIExample(
                        name="Successful login",
                        description="Example of successful user login",
                        request_example={
                            "username": "john_doe",
                            "password": "SecurePass123!"
                        },
                        response_example={
                            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                            "token_type": "Bearer",
                            "expires_in": 3600,
                            "refresh_token": "def50200...",
                            "user": {
                                "id": "user_123",
                                "username": "john_doe",
                                "email": "john@example.com",
                                "role": "user"
                            }
                        },
                        curl_example="""curl -X POST "https://api.example.com/api/v1/auth/login" \\
  -H "Content-Type: application/json" \\
  -H "Accept: application/json" \\
  -d '{
    "username": "john_doe",
    "password": "SecurePass123!"
  }'""",
                        parameters={
                            "username": "Unique username or email address",
                            "password": "User's password"
                        }
                    ),
                    APIExample(
                        name="Invalid credentials",
                        description="Example of login failure due to invalid credentials",
                        request_example={
                            "username": "john_doe",
                            "password": "WrongPassword"
                        },
                        response_example={
                            "error": {
                                "type": "AuthenticationError",
                                "category": "authentication_error",
                                "detail": "Invalid credentials provided",
                                "status_code": 401,
                                "suggestions": [
                                    "Check your username and password",
                                    "Verify your account is active",
                                    "Contact support if problems persist"
                                ]
                            }
                        }
                    )
                ],
                error_codes=[
                    ErrorCodeInfo(
                        code="INVALID_CREDENTIALS",
                        status_code=401,
                        message="Invalid username or password",
                        description="The provided credentials do not match any user in the system",
                        troubleshooting=[
                            "Verify username spelling and case",
                            "Ensure password is correct",
                            "Check if account is locked"
                        ]
                    ),
                    ErrorCodeInfo(
                        code="ACCOUNT_LOCKED",
                        status_code=423,
                        message="Account is locked",
                        description="User account has been temporarily locked due to multiple failed login attempts",
                        troubleshooting=[
                            "Wait 30 minutes before trying again",
                            "Contact support to unlock account",
                            "Use password reset if available"
                        ]
                    )
                ],
                rate_limits={
                    "requests_per_minute": 10,
                    "requests_per_hour": 100,
                    "burst_size": 3
                },
                authentication_required=False,
                related_endpoints=["POST /api/v1/auth/logout", "POST /api/v1/auth/refresh"]
            ),
            
            "POST /api/v1/auth/register": APIEndpointDoc(
                endpoint="/api/v1/auth/register",
                method="POST",
                summary="User registration",
                description="Register a new user account",
                tags=["authentication"],
                examples=[
                    APIExample(
                        name="Successful registration",
                        request_example={
                            "username": "jane_doe",
                            "email": "jane@example.com",
                            "password": "SecurePass123!",
                            "confirm_password": "SecurePass123!"
                        },
                        response_example={
                            "message": "User registered successfully",
                            "user_id": "user_456",
                            "username": "jane_doe",
                            "email": "jane@example.com"
                        }
                    )
                ],
                error_codes=[
                    ErrorCodeInfo(
                        code="USERNAME_TAKEN",
                        status_code=409,
                        message="Username already exists",
                        troubleshooting=[
                            "Choose a different username",
                            "Use a longer or more unique username"
                        ]
                    ),
                    ErrorCodeInfo(
                        code="EMAIL_TAKEN",
                        status_code=409,
                        message="Email address already registered",
                        troubleshooting=[
                            "Use password reset if this is your email",
                            "Use a different email address"
                        ]
                    )
                ],
                rate_limits={
                    "requests_per_hour": 3,
                    "requests_per_day": 10
                },
                authentication_required=False
            ),
            
            # Chat endpoints
            "POST /api/v1/chat": APIEndpointDoc(
                endpoint="/api/v1/chat",
                method="POST",
                summary="Send chat message",
                description="Send a message to the AI chat agent",
                tags=["chat"],
                examples=[
                    APIExample(
                        name="Send message",
                        request_example={
                            "message": "I need help with my order #12345",
                            "session_id": "session_abc123"
                        },
                        response_example={
                            "session_id": "session_abc123",
                            "response": {
                                "content": "I'll be happy to help you with your order #12345. Let me look that up for you.",
                                "attachments_processed": [],
                                "escalation_triggered": False,
                                "sources": ["knowledge_base", "order_system"],
                                "confidence_score": 0.95,
                                "processing_time": 1.23
                            }
                        },
                        curl_example="""curl -X POST "https://api.example.com/api/v1/chat" \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "message": "I need help with my order #12345",
    "session_id": "session_abc123"
  }'"""
                    )
                ],
                error_codes=[
                    ErrorCodeInfo(
                        code="MESSAGE_TOO_LONG",
                        status_code=422,
                        message="Message exceeds maximum length",
                        troubleshooting=[
                            "Limit message to 2000 characters",
                            "Break long messages into multiple parts"
                        ]
                    ),
                    ErrorCodeInfo(
                        code="RATE_LIMIT_EXCEEDED",
                        status_code=429,
                        message="Too many messages sent",
                        troubleshooting=[
                            "Wait before sending more messages",
                            "Reduce message frequency"
                        ]
                    )
                ],
                rate_limits={
                    "requests_per_minute": 60,
                    "requests_per_hour": 500
                },
                authentication_required=True,
                related_endpoints=["GET /api/v1/chat/sessions", "DELETE /api/v1/chat/sessions/{session_id}"]
            ),
            
            # Health check endpoints
            "GET /health": APIEndpointDoc(
                endpoint="/health",
                method="GET",
                summary="Health check",
                description="Basic application health check",
                tags=["health"],
                examples=[
                    APIExample(
                        name="Healthy system",
                        response_example={
                            "status": "healthy",
                            "timestamp": "2025-11-04T05:32:20Z",
                            "version": "1.0.0",
                            "uptime": "2d 15h 30m"
                        }
                    )
                ],
                authentication_required=False
            ),
            
            "GET /health/detailed": APIEndpointDoc(
                endpoint="/health/detailed",
                method="GET",
                summary="Detailed health check",
                description="Comprehensive health check with component status",
                tags=["health"],
                examples=[
                    APIExample(
                        name="Detailed health status",
                        response_example={
                            "status": "healthy",
                            "timestamp": "2025-11-04T05:32:20Z",
                            "components": {
                                "database": {
                                    "status": "healthy",
                                    "response_time": 0.05,
                                    "connections": 8,
                                    "max_connections": 20
                                },
                                "redis": {
                                    "status": "healthy",
                                    "response_time": 0.02,
                                    "memory_usage": "45MB",
                                    "max_memory": "512MB"
                                },
                                "application": {
                                    "status": "healthy",
                                    "version": "1.0.0",
                                    "environment": "production",
                                    "started_at": "2025-11-02T14:02:20Z"
                                }
                            }
                        }
                    )
                ],
                authentication_required=False
            )
        }
    
    def _load_error_codes(self) -> Dict[str, ErrorCodeInfo]:
        """Load comprehensive error code documentation."""
        return {
            # Authentication errors
            "INVALID_CREDENTIALS": ErrorCodeInfo(
                code="INVALID_CREDENTIALS",
                status_code=401,
                message="Invalid username or password",
                description="The provided authentication credentials are invalid or have expired",
                troubleshooting=[
                    "Verify your username and password are correct",
                    "Ensure your account is not locked",
                    "Try refreshing your access token if using OAuth"
                ]
            ),
            
            "TOKEN_EXPIRED": ErrorCodeInfo(
                code="TOKEN_EXPIRED",
                status_code=401,
                message="Access token has expired",
                description="Your authentication token has expired and needs to be refreshed",
                troubleshooting=[
                    "Use your refresh token to get a new access token",
                    "Re-authenticate if refresh token is also expired",
                    "Check token expiry time in your token payload"
                ]
            ),
            
            "INSUFFICIENT_PERMISSIONS": ErrorCodeInfo(
                code="INSUFFICIENT_PERMISSIONS",
                status_code=403,
                message="Insufficient permissions",
                description="Your user account does not have the required permissions to access this resource",
                troubleshooting=[
                    "Contact your administrator to request necessary permissions",
                    "Verify your user role has access to this endpoint",
                    "Check if you need to be in a specific group or have specific attributes"
                ]
            ),
            
            # Validation errors
            "VALIDATION_ERROR": ErrorCodeInfo(
                code="VALIDATION_ERROR",
                status_code=422,
                message="Request validation failed",
                description="The request data does not meet the required validation rules",
                troubleshooting=[
                    "Check the detailed validation errors in the response",
                    "Ensure all required fields are present",
                    "Verify data types match the expected schema",
                    "Check field constraints like length limits and patterns"
                ]
            ),
            
            # Rate limiting errors
            "RATE_LIMIT_EXCEEDED": ErrorCodeInfo(
                code="RATE_LIMIT_EXCEEDED",
                status_code=429,
                message="Rate limit exceeded",
                description="Too many requests have been made within the rate limit window",
                troubleshooting=[
                    "Wait before making more requests",
                    "Reduce the frequency of your requests",
                    "Check the rate limit headers in the response",
                    "Consider implementing exponential backoff"
                ]
            ),
            
            # Resource errors
            "RESOURCE_NOT_FOUND": ErrorCodeInfo(
                code="RESOURCE_NOT_FOUND",
                status_code=404,
                message="Resource not found",
                description="The requested resource could not be found",
                troubleshooting=[
                    "Verify the resource ID is correct",
                    "Check if the resource has been deleted",
                    "Ensure you have access to the resource",
                    "Verify the resource exists in the expected location"
                ]
            ),
            
            "RESOURCE_CONFLICT": ErrorCodeInfo(
                code="RESOURCE_CONFLICT",
                status_code=409,
                message="Resource conflict",
                description="The requested action conflicts with the current state of the resource",
                troubleshooting=[
                    "Check if the resource already exists",
                    "Verify the resource is in the expected state",
                    "Use optimistic concurrency control if available",
                    "Retry with updated data if appropriate"
                ]
            ),
            
            # Server errors
            "INTERNAL_SERVER_ERROR": ErrorCodeInfo(
                code="INTERNAL_SERVER_ERROR",
                status_code=500,
                message="Internal server error",
                description="An unexpected error occurred on the server",
                troubleshooting=[
                    "The error may be temporary - try again later",
                    "Check the server logs for more details",
                    "Contact support if the error persists",
                    "Include the correlation ID when contacting support"
                ]
            ),
            
            "SERVICE_UNAVAILABLE": ErrorCodeInfo(
                code="SERVICE_UNAVAILABLE",
                status_code=503,
                message="Service unavailable",
                description="The service is temporarily unavailable",
                troubleshooting=[
                    "The service may be undergoing maintenance",
                    "Try again later",
                    "Check status page for service announcements",
                    "Use exponential backoff for retries"
                ]
            )
        }
    
    def _load_api_versions(self) -> Dict[str, APIVersionInfo]:
        """Load API version information."""
        return {
            "1.0": APIVersionInfo(
                version="1.0",
                status="stable",
                release_date="2025-11-01",
                new_features=[
                    "User authentication and authorization",
                    "AI-powered chat functionality",
                    "File upload and processing",
                    "Comprehensive health checks",
                    "Rate limiting and security features"
                ],
                bug_fixes=[
                    "Fixed authentication token validation",
                    "Resolved memory leak in chat sessions",
                    "Improved error response formatting"
                ]
            ),
            "1.1": APIVersionInfo(
                version="1.1",
                status="beta",
                release_date="2025-11-15",
                new_features=[
                    "Enhanced business logic validation",
                    "Improved security scanning",
                    "Advanced rate limiting strategies",
                    "Comprehensive API documentation"
                ],
                breaking_changes=[
                    "Changed error response format",
                    "Updated rate limit headers",
                    "Modified authentication token structure"
                ]
            )
        }
    
    def _load_compatibility_info(self) -> APICompatibilityInfo:
        """Load API compatibility information."""
        return APICompatibilityInfo(
            backward_compatible=False,
            breaking_changes=[
                "Error response format has changed from v1.0",
                "Rate limit headers now use standardized format",
                "Authentication token structure updated"
            ],
            migration_guide="""To migrate from API v1.0 to v1.1:

1. **Error Response Format**: Update your code to handle the new error response structure with standardized fields
2. **Rate Limit Headers**: Update parsing logic to handle X-RateLimit-* headers
3. **Authentication**: Tokens now include additional claims and have different expiration handling

Example migration:
```python
# Old v1.0 error handling
try:
    response = requests.get(url)
    if response.status_code == 400:
        error = response.json()['detail']

# New v1.1 error handling  
try:
    response = requests.get(url)
    if response.status_code == 400:
        error_info = response.json()['error']
        error_code = error_info['type']
        error_detail = error_info['detail']
```""",
            version_support={
                "1.0": "supported until 2026-11-01",
                "1.1": "current stable version",
                "2.0": "planned for 2026-Q2"
            }
        )
    
    def generate_openapi_schema(self, app: FastAPI) -> Dict[str, Any]:
        """Generate enhanced OpenAPI schema."""
        # Get the default OpenAPI schema
        openapi_schema = get_openapi(
            title=settings.app_name,
            version=settings.app_version,
            description=f"{settings.app_name} API - Intelligent customer support system",
            routes=app.routes
        )
        
        # Add enhanced information
        openapi_schema["info"]["contact"] = {
            "name": "API Support",
            "email": "api-support@example.com",
            "url": "https://docs.example.com/support"
        }
        
        openapi_schema["info"]["license"] = {
            "name": "MIT",
            "url": "https://opensource.org/licenses/MIT"
        }
        
        # Add servers information
        openapi_schema["servers"] = [
            {
                "url": "https://api.example.com",
                "description": "Production server"
            },
            {
                "url": "https://staging-api.example.com", 
                "description": "Staging server"
            },
            {
                "url": "http://localhost:8000",
                "description": "Development server"
            }
        ]
        
        # Add security schemes
        openapi_schema["components"]["securitySchemes"] = {
            "BearerAuth": {
                "type": "http",
                "scheme": "bearer",
                "bearerFormat": "JWT",
                "description": "JWT access token authentication"
            },
            "ApiKeyAuth": {
                "type": "apiKey",
                "in": "header",
                "name": "X-API-Key",
                "description": "API key authentication"
            }
        }
        
        # Add enhanced path documentation
        for path, path_item in openapi_schema["paths"].items():
            for method, operation in path_item.items():
                endpoint_key = f"{method.upper()} {path}"
                
                if endpoint_key in self.endpoint_docs:
                    doc_info = self.endpoint_docs[endpoint_key]
                    
                    # Add comprehensive description
                    operation["description"] = doc_info.description
                    operation["summary"] = doc_info.summary
                    
                    # Add examples
                    if doc_info.examples:
                        operation["examples"] = {
                            f"example_{i+1}": {
                                "summary": example.name,
                                "description": example.description,
                                "value": example.response_example or example.request_example
                            }
                            for i, example in enumerate(doc_info.examples)
                        }
                    
                    # Add error responses
                    if doc_info.error_codes:
                        operation["responses"] = operation.get("responses", {})
                        for error_code in doc_info.error_codes:
                            status_code = error_code.status_code
                            if status_code not in operation["responses"]:
                                operation["responses"][str(status_code)] = {
                                    "description": f"Error: {error_code.message}",
                                    "content": {
                                        "application/json": {
                                            "schema": {
                                                "type": "object",
                                                "properties": {
                                                    "error": {
                                                        "type": "object",
                                                        "properties": {
                                                            "type": {"type": "string", "example": error_code.code},
                                                            "category": {"type": "string", "example": "authentication_error"},
                                                            "detail": {"type": "string", "example": error_code.message},
                                                            "suggestions": {
                                                                "type": "array",
                                                                "items": {"type": "string"},
                                                                "example": error_code.troubleshooting or []
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                    
                    # Add rate limiting information
                    if doc_info.rate_limits:
                        operation["x-rate-limits"] = doc_info.rate_limits
                    
                    # Add security requirements
                    if doc_info.authentication_required:
                        operation["security"] = [{"BearerAuth": []}]
        
        return openapi_schema
    
    def create_api_documentation_page(self) -> str:
        """Create comprehensive API documentation HTML page."""
        html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{settings.app_name} - API Documentation</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; text-align: center; }}
        .header h1 {{ margin: 0; font-size: 2.5em; }}
        .header p {{ margin: 10px 0 0 0; opacity: 0.9; font-size: 1.1em; }}
        .nav {{ padding: 20px; border-bottom: 1px solid #eee; }}
        .nav a {{ margin-right: 20px; text-decoration: none; color: #667eea; font-weight: 500; }}
        .content {{ padding: 40px; }}
        .section {{ margin-bottom: 40px; }}
        .section h2 {{ color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; }}
        .endpoint {{ background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 6px; margin: 20px 0; overflow: hidden; }}
        .endpoint-header {{ background: #667eea; color: white; padding: 15px 20px; font-weight: bold; }}
        .endpoint-method {{ display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 0.8em; margin-right: 10px; }}
        .method-GET {{ background: #28a745; }}
        .method-POST {{ background: #007bff; }}
        .method-PUT {{ background: #ffc107; color: #000; }}
        .method-DELETE {{ background: #dc3545; }}
        .endpoint-content {{ padding: 20px; }}
        .example {{ background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 4px; margin: 10px 0; font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace; font-size: 0.9em; overflow-x: auto; }}
        .curl-example {{ white-space: pre; }}
        .error-code {{ border-left: 4px solid #dc3545; padding: 10px 15px; margin: 10px 0; background: #f8f9fa; }}
        .rate-limit {{ border-left: 4px solid #ffc107; padding: 10px 15px; margin: 10px 0; background: #fff3cd; }}
        .table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        .table th, .table td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        .table th {{ background-color: #f8f9fa; font-weight: bold; }}
        .highlight {{ background: #fff3cd; padding: 15px; border-radius: 4px; border-left: 4px solid #ffc107; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{settings.app_name}</h1>
            <p>Comprehensive API Documentation v{settings.app_version}</p>
            <p>Intelligent customer support system with AI-powered responses</p>
        </div>
        
        <div class="nav">
            <a href="#overview">Overview</a>
            <a href="#authentication">Authentication</a>
            <a href="#endpoints">API Endpoints</a>
            <a href="#error-codes">Error Codes</a>
            <a href="#rate-limits">Rate Limits</a>
            <a href="#examples">Examples</a>
            <a href="#changelog">Changelog</a>
            <a href="/docs" target="_blank">Interactive Docs ↗</a>
        </div>
        
        <div class="content">
            <section id="overview" class="section">
                <h2>Overview</h2>
                <p>Welcome to the {settings.app_name} API documentation. This API provides comprehensive customer support functionality with AI-powered responses, file processing, and real-time chat capabilities.</p>
                
                <div class="highlight">
                    <strong>Base URL:</strong> <code>https://api.example.com</code><br>
                    <strong>API Version:</strong> v{settings.app_version}<br>
                    <strong>Authentication:</strong> JWT Bearer tokens or API keys<br>
                    <strong>Content Type:</strong> <code>application/json</code><br>
                    <strong>Rate Limits:</strong> Endpoint-specific limits with burst protection
                </div>
            </section>
            
            <section id="authentication" class="section">
                <h2>Authentication</h2>
                <p>The API supports multiple authentication methods:</p>
                
                <h3>JWT Bearer Token</h3>
                <div class="example">Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</div>
                
                <h3>API Key</h3>
                <div class="example">X-API-Key: your-api-key-here</div>
                
                <p>Most endpoints require authentication. Authentication endpoints are available without credentials.</p>
            </section>
            
            <section id="endpoints" class="section">
                <h2>API Endpoints</h2>
        """
        
        # Add endpoint documentation
        for endpoint_key, doc_info in self.endpoint_docs.items():
            method, path = endpoint_key.split(" ", 1)
            
            html_content += f"""
            <div class="endpoint">
                <div class="endpoint-header">
                    <span class="endpoint-method method-{method}">{method}</span>
                    <code>{path}</code>
                </div>
                <div class="endpoint-content">
                    <p><strong>{doc_info.summary}</strong></p>
                    <p>{doc_info.description}</p>
            """
            
            # Add examples
            if doc_info.examples:
                html_content += "<h4>Examples:</h4>"
                for i, example in enumerate(doc_info.examples, 1):
                    html_content += f"""
                    <h5>Example {i}: {example.name}</h5>
                    """
                    if example.description:
                        html_content += f"<p>{example.description}</p>"
                    
                    if example.request_example:
                        html_content += f"""
                        <h6>Request:</h6>
                        <div class="example">{json.dumps(example.request_example, indent=2)}</div>
                        """
                    
                    if example.response_example:
                        html_content += f"""
                        <h6>Response:</h6>
                        <div class="example">{json.dumps(example.response_example, indent=2)}</div>
                        """
                    
                    if example.curl_example:
                        html_content += f"""
                        <h6>cURL:</h6>
                        <div class="example curl-example">{example.curl_example}</div>
                        """
            
            # Add error codes
            if doc_info.error_codes:
                html_content += "<h4>Error Codes:</h4>"
                for error_code in doc_info.error_codes:
                    html_content += f"""
                    <div class="error-code">
                        <strong>{error_code.code}</strong> (HTTP {error_code.status_code})<br>
                        <em>{error_code.message}</em><br>
                        {error_code.description or ""}
                    </div>
                    """
            
            # Add rate limits
            if doc_info.rate_limits:
                limits = doc_info.rate_limits
                html_content += f"""
                <div class="rate-limit">
                    <strong>Rate Limits:</strong>
                    <ul>
                """
                for limit_type, value in limits.items():
                    html_content += f"<li><strong>{limit_type.replace('_', ' ').title()}:</strong> {value}</li>"
                html_content += """
                    </ul>
                </div>
                """
            
            html_content += """
                </div>
            </div>
            """
        
        # Add error codes section
        html_content += """
            </section>
            
            <section id="error-codes" class="section">
                <h2>Error Codes</h2>
                <p>All API errors follow a standardized format with the following structure:</p>
                
                <div class="example">{`{
  "error": {
    "type": "ErrorType",
    "category": "error_category", 
    "severity": "error_severity",
    "detail": "Human-readable error message",
    "status_code": 400,
    "correlation_id": "req_123456789",
    "timestamp": "2025-11-04T05:32:20Z",
    "suggestions": [
      "Suggestion 1",
      "Suggestion 2"
    ]
  }
}`}</div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Error Code</th>
                            <th>HTTP Status</th>
                            <th>Description</th>
                            <th>Troubleshooting</th>
                        </tr>
                    </thead>
                    <tbody>
        """
        
        for error_code, info in self.error_codes.items():
            troubleshooting = "<br>".join(info.troubleshooting) if info.troubleshooting else ""
            html_content += f"""
                        <tr>
                            <td><code>{error_code}</code></td>
                            <td>{info.status_code}</td>
                            <td>{info.description}</td>
                            <td>{troubleshooting}</td>
                        </tr>
            """
        
        html_content += """
                    </tbody>
                </table>
            </section>
            
            <section id="rate-limits" class="section">
                <h2>Rate Limits</h2>
                <p>The API implements rate limiting to ensure fair usage and system stability:</p>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Endpoint Category</th>
                            <th>Requests per Minute</th>
                            <th>Requests per Hour</th>
                            <th>Burst Size</th>
                            <th>Strategy</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Authentication</td>
                            <td>10</td>
                            <td>100</td>
                            <td>3</td>
                            <td>Token Bucket</td>
                        </tr>
                        <tr>
                            <td>Chat</td>
                            <td>60</td>
                            <td>500</td>
                            <td>10</td>
                            <td>Sliding Window</td>
                        </tr>
                        <tr>
                            <td>File Upload</td>
                            <td>20</td>
                            <td>100</td>
                            <td>5</td>
                            <td>Token Bucket</td>
                        </tr>
                        <tr>
                            <td>General API</td>
                            <td>1000</td>
                            <td>10000</td>
                            <td>100</td>
                            <td>Sliding Window</td>
                        </tr>
                    </tbody>
                </table>
                
                <p>Rate limit information is included in response headers:</p>
                <div class="example">X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
Retry-After: 60</div>
            </section>
            
            <section id="examples" class="section">
                <h2>Code Examples</h2>
                
                <h3>Python</h3>
                <div class="example">{`import requests

# Authentication
response = requests.post('https://api.example.com/api/v1/auth/login', json={
    'username': 'john_doe',
    'password': 'SecurePass123!'
})

if response.status_code == 200:
    token = response.json()['access_token']
    
    # Use token for API calls
    headers = {'Authorization': f'Bearer {token}'}
    
    # Send chat message
    chat_response = requests.post('https://api.example.com/api/v1/chat', 
                                json={'message': 'Hello!'},
                                headers=headers)
    
    print(chat_response.json())
else:
    print(f"Error: {response.json()}")`}</div>
                
                <h3>JavaScript</h3>
                <div class="example">{`// Authentication
const loginResponse = await fetch('https://api.example.com/api/v1/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        username: 'john_doe',
        password: 'SecurePass123!'
    })
});

if (loginResponse.ok) {
    const { access_token } = await loginResponse.json();
    
    // Send chat message
    const chatResponse = await fetch('https://api.example.com/api/v1/chat', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${access_token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: 'Hello!' })
    });
    
    const result = await chatResponse.json();
    console.log(result);
} else {
    console.error('Login failed', await loginResponse.json());
}`}</div>
            </section>
            
            <section id="changelog" class="section">
                <h2>Changelog</h2>
        """
        
        # Add version information
        for version, version_info in self.api_versions.items():
            status_badge = f'<span style="background: {"#28a745" if version_info.status == "stable" else "#ffc107" if version_info.status == "beta" else "#dc3545"}; color: white; padding: 2px 6px; border-radius: 3px; font-size: 0.8em;">{version_info.status.upper()}</span>'
            
            html_content += f"""
            <h3>Version {version} {status_badge}</h3>
            <p><strong>Released:</strong> {version_info.release_date}</p>
            """
            
            if version_info.new_features:
                html_content += "<h4>New Features:</h4><ul>"
                for feature in version_info.new_features:
                    html_content += f"<li>{feature}</li>"
                html_content += "</ul>"
            
            if version_info.breaking_changes:
                html_content += """
                <div class="highlight">
                    <strong>Breaking Changes:</strong><ul>
                """
                for change in version_info.breaking_changes:
                    html_content += f"<li>{change}</li>"
                html_content += """
                    </ul>
                </div>
                """
        
        html_content += """
            </section>
        </div>
    </div>
</body>
</html>
        """
        
        return html_content

def setup_enhanced_api_docs(app: FastAPI):
    """Setup enhanced API documentation."""
    doc_generator = EnhancedAPIDocumentation()
    
    # Override OpenAPI schema
    app.openapi = lambda: doc_generator.generate_openapi_schema(app)
    
    # Add custom documentation endpoint
    @app.get("/docs-enhanced", include_in_schema=False)
    async def enhanced_docs():
        """Enhanced API documentation page."""
        return HTMLResponse(doc_generator.create_api_documentation_page())
    
    logger.info("Enhanced API documentation configured")

class HTMLResponse:
    """Simple HTML response wrapper."""
    def __init__(self, html_content: str):
        self.html_content = html_content
    
    def __call__(self, scope, receive, send):
        """ASGI application callable."""
        body = self.html_content.encode('utf-8')
        
        send({
            "type": "http.response.start",
            "status": 200,
            "headers": [
                [b"content-type", b"text/html; charset=utf-8"],
                [b"content-length", str(len(body)).encode()],
            ],
        })
        
        send({
            "type": "http.response.body",
            "body": body,
        })