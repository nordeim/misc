"""
Main FastAPI application entry point.

This module initializes and configures the FastAPI application with
comprehensive middleware stack, lifecycle management, and routing.
"""

import sys
import asyncio
import signal
from contextlib import asynccontextmanager
from typing import Dict, Any
from datetime import datetime

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import structlog

# Import configuration and middleware
from app.config import settings
from app.database import init_db, AsyncSessionLocal

# Middleware imports
from app.middleware.cors import setup_cors_middleware
from app.middleware.security import (
    JWTAuthMiddleware,
    SecurityHeadersMiddleware,
    APIKeyAuthMiddleware,
    RequestValidationMiddleware
)
from app.middleware.logging import setup_logging_middleware
from app.middleware.rate_limiting import setup_rate_limiting_middleware
from app.middleware.error_handling import (
    setup_global_exception_handlers,
    ErrorHandlingMiddleware
)

# Enhanced validation imports
from app.validation import (
    RequestValidator,
    ValidationConfig,
    SchemaValidator,
    BusinessLogicValidator,
    SecurityValidator,
    validate_request,
    validate_response,
    validate_business_rules,
    sanitize_input
)

# Dependencies and utilities
from app.dependencies import (
    get_system_health,
    get_db_session,
    check_database_health,
    check_redis_health,
    get_cache,
    get_current_user,
    get_request_info
)

# Import existing monitoring
from app.monitoring import init_monitoring, shutdown_monitoring, metrics

# Import enhanced monitoring and documentation
from app.monitoring.enhanced_monitoring import (
    setup_api_monitoring,
    create_analytics_endpoints
)

# Import observability system
from app.utils.observability_setup import (
    initialize_global_observability,
    configure_production_observability,
    configure_development_observability,
    configure_test_observability,
    ObservabilitySetup
)
from app.docs.api_documentation import setup_enhanced_api_docs

# Import agent system
from app.agents import (
    agent_factory,
    agent_monitoring,
    initialize_agent_monitoring_integration,
    shutdown_agent_monitoring_integration
)

# Import streaming system
from app.streaming.routes import (
    initialize_streaming_system,
    shutdown_streaming_system
)
from app.streaming.middleware import setup_streaming_middleware
from app.streaming.managers import StreamManager

# Global streaming manager instance
stream_manager = None

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="ISO"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer() if settings.log_format == "json" else structlog.dev.ConsoleRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Global variables for application state
app_state = {
    "started_at": None,
    "shutdown_event": asyncio.Event(),
    "health_status": "starting"
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan management.
    
    Handles startup and shutdown events for the application.
    """
    # Startup
    logger.info("Starting up Customer Support AI Agent...")
    app_state["started_at"] = datetime.utcnow()
    
    try:
        # Validate configuration
        config_validation = settings.validate_configuration()
        if not config_validation["valid"]:
            logger.warning("Configuration validation failed", issues=config_validation["issues"])
        
        # Create necessary directories
        settings.create_directories()
        logger.info("Directories created")
        
        # Initialize database
        await init_db()
        logger.info("Database initialized")
        
        # Initialize Redis connection test
        try:
            from app.dependencies import get_redis_client
            async with get_redis_client() as redis_client:
                if redis_client:
                    await redis_client.ping()
                    logger.info("Redis connection established")
                else:
                    logger.warning("Redis not configured")
        except Exception as e:
            logger.warning("Redis connection failed", error=str(e))
        
        # Initialize monitoring system
        init_monitoring()
        logger.info("Monitoring system initialized")
        
        # Initialize comprehensive observability system
        try:
            observability_setup = await initialize_global_observability(app, settings.environment)
            logger.info("Comprehensive observability system initialized")
        except Exception as e:
            logger.error("Observability system initialization failed", error=str(e))
            # Continue without observability system for now
            logger.warning("Continuing without comprehensive observability")
        
        # Initialize streaming system
        try:
            await initialize_streaming_system()
            logger.info("Streaming system initialized")
        except Exception as e:
            logger.error("Streaming system initialization failed", error=str(e))
            # Continue without streaming system for now
            logger.warning("Continuing without streaming system")
        
        # Initialize WebSocket system
        try:
            from app.api.websocket import websocket_manager
            await websocket_manager.initialize()
            logger.info("WebSocket system initialized")
        except Exception as e:
            logger.error("WebSocket system initialization failed", error=str(e))
            # Continue without WebSocket system for now
        
        # Initialize agent system
        try:
            # Initialize agent monitoring integration
            await initialize_agent_monitoring_integration()
            
            # Create default agent pool for production use
            if settings.is_production:
                pool = await agent_factory.create_agent_pool(
                    pool_name="default",
                    min_size=2,
                    max_size=10,
                    configuration_name="production"
                )
                logger.info("Created default agent pool for production")
            else:
                # Create development agent
                agent = await agent_factory.create_agent(
                    configuration_name="development",
                    metadata={"environment": settings.environment}
                )
                logger.info(f"Created development agent: {agent.agent_id}")
            
            logger.info("Agent system initialized successfully")
            
        except Exception as e:
            logger.error("Agent system initialization failed", error=str(e))
            # Continue without agent system for now
            logger.warning("Continuing without agent system")
        
        # Initialize file upload system
        try:
            from app.api.routes.files import initialize_file_upload_system
            await initialize_file_upload_system()
            logger.info("File upload system initialized successfully")
        except Exception as e:
            logger.error("File upload system initialization failed", error=str(e))
            # Continue without file upload system for now
            logger.warning("Continuing without file upload system")
        
        # Start background tasks
        asyncio.create_task(background_cleanup_task())
        asyncio.create_task(health_monitor_task())
        
        # Update health status
        app_state["health_status"] = "healthy"
        logger.info("Application startup completed successfully",
                   version=settings.app_version,
                   environment=settings.environment)
        
        yield
        
    except Exception as e:
        logger.error("Application startup failed", error=str(e))
        app_state["health_status"] = "unhealthy"
        raise
    finally:
        # Shutdown
        logger.info("Shutting down Customer Support AI Agent...")
        app_state["health_status"] = "shutting_down"
        
        # Signal shutdown to background tasks
        app_state["shutdown_event"].set()
        
        # Shutdown monitoring
        shutdown_monitoring()
        logger.info("Monitoring system shutdown")
        
        # Shutdown streaming system
        try:
            await shutdown_streaming_system()
            logger.info("Streaming system shutdown")
        except Exception as e:
            logger.error("Streaming system shutdown error", error=str(e))
        
        # Shutdown WebSocket system
        try:
            from app.api.websocket import websocket_manager
            await websocket_manager.shutdown()
            logger.info("WebSocket system shutdown")
        except Exception as e:
            logger.error("WebSocket system shutdown error", error=str(e))
        
        # Shutdown agent system
        try:
            await shutdown_agent_monitoring_integration()
            await agent_factory.shutdown_all()
            logger.info("Agent system shutdown")
        except Exception as e:
            logger.error("Agent system shutdown error", error=str(e))
        
        # Close database connections
        if AsyncSessionLocal:
            await AsyncSessionLocal().close()
        
        # Additional cleanup
        logger.info("Application shutdown completed")

async def background_cleanup_task():
    """Background task for periodic cleanup."""
    while not app_state["shutdown_event"].is_set():
        try:
            # Sleep for 5 minutes
            await asyncio.wait_for(app_state["shutdown_event"].wait(), timeout=300)
            break
        except asyncio.TimeoutError:
            # Perform cleanup tasks
            logger.debug("Running background cleanup")
            
            # Clean up expired sessions, logs, etc.
            # This would integrate with your specific cleanup logic
            
            # Log system status
            logger.info("Background cleanup completed",
                       uptime=str(datetime.utcnow() - app_state["started_at"]) if app_state["started_at"] else "unknown")

async def health_monitor_task():
    """Background task for health monitoring."""
    while not app_state["shutdown_event"].is_set():
        try:
            # Sleep for 30 seconds
            await asyncio.wait_for(app_state["shutdown_event"].wait(), timeout=30)
            break
        except asyncio.TimeoutError:
            # Check system health
            try:
                health = await get_system_health()
                app_state["health_status"] = health["status"]
                
                if health["status"] == "unhealthy":
                    logger.warning("System health degraded", health=health)
                
            except Exception as e:
                logger.error("Health check failed", error=str(e))
                app_state["health_status"] = "unhealthy"

# Create FastAPI application
app = FastAPI(
    title=settings.app_name,
    description="Intelligent customer support system with AI-powered responses and comprehensive middleware pipeline",
    version=settings.app_version,
    debug=settings.app_debug,
    lifespan=lifespan,
    docs_url="/docs" if settings.is_development else None,
    redoc_url="/redoc" if settings.is_development else None,
    openapi_url="/openapi.json" if settings.is_development else None,
    openapi_tags=[
        {
            "name": "Authentication",
            "description": "User authentication and authorization"
        },
        {
            "name": "Chat",
            "description": "AI-powered chat functionality"
        },
        {
            "name": "Agent System",
            "description": "Customer Support Agent orchestration and management"
        },
        {
            "name": "Streaming",
            "description": "Real-time streaming capabilities for chat and agent responses"
        },
        {
            "name": "Health",
            "description": "Health checks and monitoring"
        },
        {
            "name": "Admin",
            "description": "Administrative functions"
        },
        {
            "name": "File Management",
            "description": "Comprehensive file upload, processing, and management"
        }
    ]
)

# ==============================================================================
# MIDDLEWARE CONFIGURATION
# ==============================================================================

def setup_middleware(app: FastAPI):
    """
    Configure comprehensive middleware stack.
    
    Order matters - middleware is applied in reverse order of declaration.
    """
    
    global stream_manager
    
    # 1. Security middleware (should be early)
    if settings.security_headers_enabled:
        app.add_middleware(SecurityHeadersMiddleware)
    
    # 2. Enhanced request validation middleware
    from app.validation.request_validator import setup_request_validation_middleware
    setup_request_validation_middleware(app)
    
    # 3. Original request validation middleware (legacy)
    app.add_middleware(RequestValidationMiddleware)
    
    # 4. Trusted host middleware (production security)
    if settings.trust_proxy_headers:
        trusted_hosts = ["localhost", "127.0.0.1", "*.example.com"] if settings.is_production else ["*"]
        app.add_middleware(
            TrustedHostMiddleware,
            allowed_hosts=trusted_hosts
        )
    
    # 5. CORS middleware
    setup_cors_middleware(app)
    
    # 6. Rate limiting middleware
    setup_rate_limiting_middleware(app)
    
    # 7. Streaming middleware
    if stream_manager:
        try:
            setup_streaming_middleware(
                app=app,
                stream_manager=stream_manager,
                enable_logging=True,
                enable_validation=True,
                enable_performance=True,
                enable_security=True,
                log_all_requests=False
            )
            logger.info("Streaming middleware configured")
        except Exception as e:
            logger.error("Failed to configure streaming middleware", error=str(e))
    
    # 8. Error handling middleware
    app.add_middleware(ErrorHandlingMiddleware)
    
    # 9. Enhanced API monitoring middleware
    setup_api_monitoring(app)
    
    # 10. Observability middleware (comprehensive request tracking)
    try:
        from app.utils.observability_setup import ObservabilityMiddleware
        app.add_middleware(ObservabilityMiddleware)
        logger.info("Observability middleware configured")
    except Exception as e:
        logger.error("Failed to configure observability middleware", error=str(e))
    
    # 11. Logging middleware (should be last for request/response logging)
    setup_logging_middleware(app)
    
    # 11. Authentication middleware (adds user context)
    jwt_whitelist_paths = [
        "/health",
        "/docs",
        "/redoc", 
        "/openapi.json",
        "/docs-enhanced",
        "/metrics",
        "/analytics/",
        "/observability/",
        "/api/v1/auth/login",
        "/api/v1/auth/register",
        "/api/v1/auth/refresh",
        "/streaming/sse",
        "/streaming/status"
    ]
    app.add_middleware(JWTAuthMiddleware, whitelist_paths=jwt_whitelist_paths)
    
    # 12. API Key middleware
    api_key_whitelist_paths = [
        "/health",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/docs-enhanced",
        "/analytics/",
        "/streaming/sse",
        "/streaming/status",
        "/metrics",
        "/observability/",
        "/health/detailed"
    ]
    app.add_middleware(APIKeyAuthMiddleware, whitelist_paths=api_key_whitelist_paths)
    
    logger.info("Comprehensive middleware stack configured successfully")

# Setup enhanced API documentation
setup_enhanced_api_docs(app)

# Setup analytics endpoints
create_analytics_endpoints(app)

# Setup all middleware
setup_middleware(app)

# ==============================================================================
# GLOBAL EXCEPTION HANDLERS
# ==============================================================================

setup_global_exception_handlers(app)

# ==============================================================================
# API ROUTES
# ==============================================================================

# Import and include API routers
try:
    from app.api.routes import api_router
    app.include_router(api_router, prefix="/api/v1")
    logger.info("API router included")
except ImportError as e:
    logger.warning("API router not available", error=str(e))

# Import and include authentication router
try:
    from app.api.routes.auth import router as auth_router
    app.include_router(auth_router)
    logger.info("Authentication router included")
except ImportError as e:
    logger.warning("Authentication router not available", error=str(e))

# Import and include streaming router
try:
    from app.streaming.routes import router as streaming_router
    app.include_router(streaming_router, prefix="/api/v1")
    logger.info("Streaming router included")
except ImportError as e:
    logger.warning("Streaming router not available", error=str(e))

# Import and include backup/restore router
try:
    from app.api.backup_restore import router as backup_restore_router
    app.include_router(backup_restore_router)
    logger.info("Backup/restore router included")
except ImportError as e:
    logger.warning("Backup/restore router not available", error=str(e))

# Health check endpoints
@app.get("/health", tags=["Health"])
async def health_check_endpoint():
    """Basic health check endpoint."""
    return await get_system_health()

# Agent system health check
@app.get("/health/agents", tags=["Health"])
async def agent_health_check():
    """Agent system health check endpoint."""
    try:
        from app.agents import agent_monitoring
        health_status = await agent_factory.get_health_status()
        return {
            "status": "healthy" if health_status["overall_health"] == "healthy" else "degraded",
            "timestamp": datetime.utcnow().isoformat(),
            "agent_system": health_status
        }
    except Exception as e:
        logger.error(f"Agent health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

# WebSocket system health check
@app.get("/health/websocket", tags=["Health"])
async def websocket_health_check():
    """WebSocket system health check endpoint."""
    try:
        from app.api.websocket import websocket_manager
        health_status = await websocket_manager.health_check()
        return health_status
    except Exception as e:
        logger.error(f"WebSocket health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "websocket_manager": {
                    "initialized": False,
                    "running": False
                },
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )

# WebSocket system stats endpoint (admin only)
@app.get("/stats/websocket", tags=["Statistics"])
async def websocket_stats():
    """Get WebSocket system statistics (admin only)."""
    try:
        from app.api.websocket import get_websocket_stats
        return await get_websocket_stats()
    except Exception as e:
        logger.error(f"WebSocket stats failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )

@app.get("/health/detailed", tags=["Health"])
async def detailed_health_check():
    """
    Comprehensive health check endpoint.
    
    Returns the current health status of the application and its dependencies.
    """
    health = await get_system_health()
    status_code = 200 if health["status"] == "healthy" else 503
    
    return JSONResponse(
        status_code=status_code,
        content=health
    )

@app.get("/health/detailed", tags=["Health"])
async def detailed_health_check():
    """
    Detailed health check with component-level diagnostics.
    
    Returns detailed information about each system component.
    """
    db_health = await check_database_health()
    redis_health = await check_redis_health()
    
    return {
        "status": "healthy" if all([
            db_health["status"] == "healthy",
            redis_health["status"] in ["healthy", "not_configured"]
        ]) else "unhealthy",
        "timestamp": datetime.utcnow().isoformat(),
        "components": {
            "database": db_health,
            "redis": redis_health,
            "application": {
                "status": "healthy",
                "version": settings.app_version,
                "environment": settings.environment,
                "debug_mode": settings.app_debug,
                "started_at": app_state["started_at"].isoformat() if app_state["started_at"] else None,
                "uptime_seconds": (datetime.utcnow() - app_state["started_at"]).total_seconds() if app_state["started_at"] else None
            }
        },
        "configuration": {
            "rate_limiting_enabled": settings.rate_limit_enabled,
            "security_headers_enabled": settings.security_headers_enabled,
            "ssl_enabled": settings.ssl_enabled,
            "cors_origins_count": len(settings.cors_origins),
            "log_level": settings.log_level
        }
    }

@app.get("/health/ready", tags=["Health"])
async def readiness_check():
    """
    Kubernetes-style readiness probe.
    
    Indicates if the application is ready to serve traffic.
    """
    try:
        # Check database readiness
        db_health = await check_database_health()
        
        if db_health["status"] != "healthy":
            raise HTTPException(
                status_code=503,
                detail="Database not ready"
            )
        
        return {"status": "ready", "timestamp": datetime.utcnow().isoformat()}
        
    except Exception as e:
        logger.error("Readiness check failed", error=str(e))
        raise HTTPException(
            status_code=503,
            detail="Application not ready"
        )

@app.get("/health/live", tags=["Health"])
async def liveness_check():
    """
    Kubernetes-style liveness probe.
    
    Indicates if the application is alive and responding.
    """
    return {"status": "alive", "timestamp": datetime.utcnow().isoformat()}

# Existing health endpoints
@app.get("/health/dependencies", tags=["Health"])
async def dependencies_health_check():
    """Health check for external dependencies."""
    # This would check external services like database, Redis, etc.
    return {
        "status": "healthy",
        "dependencies": {
            "database": "connected",
            "redis": "connected" if settings.redis_url else "not_configured",
            "external_apis": "available"
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health/metrics", tags=["Health"])
async def metrics_health_check():
    """Health check for metrics and monitoring."""
    return {
        "status": "healthy",
        "metrics": {
            "prometheus": "enabled",
            "structured_logging": "enabled",
            "performance_monitoring": "enabled"
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health/system", tags=["Health"])
async def system_health_check():
    """System-level health check."""
    import psutil
    
    return {
        "status": "healthy",
        "system": {
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "disk_usage_percent": psutil.disk_usage('/').percent,
            "load_average": psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health/version", tags=["Health"])
async def version_health_check():
    """Version information health check."""
    return {
        "status": "healthy",
        "version": {
            "app": settings.app_version,
            "environment": settings.environment,
            "debug_mode": settings.app_debug,
            "config_validation": settings.validate_configuration()
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health/config", tags=["Health"])
async def config_health_check():
    """Configuration health check."""
    config_status = settings.validate_configuration()
    
    return {
        "status": "healthy" if config_status["valid"] else "degraded",
        "configuration": config_status,
        "timestamp": datetime.utcnow().isoformat()
    }

# Security endpoints
@app.get("/security/headers", tags=["Security"])
async def security_headers_info():
    """Return information about security headers."""
    return {
        "security_headers": {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": f"max-age={settings.hsts_max_age}; includeSubDomains" if settings.ssl_enabled else None,
            "Content-Security-Policy": settings.content_security_policy,
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
        },
        "cors_enabled": True,
        "authentication_required": True,
        "rate_limiting_enabled": settings.rate_limit_enabled
    }

@app.get("/api/v1/security/audit", tags=["Security"])
async def security_audit(request: Request):
    """Security audit information (admin access only)."""
    # Mock admin check - implement proper authentication in production
    if not settings.is_development:
        # In production, check for admin permissions here
        pass
    
    return {
        "security_status": "enabled",
        "middleware_active": [
            "request_validation",
            "input_sanitization", 
            "ip_whitelist",
            "rate_limiting",
            "jwt_auth",
            "security_headers",
            "api_key_auth"
        ],
        "configurations": {
            "ssl_enabled": settings.ssl_enabled,
            "trust_proxy_headers": settings.trust_proxy_headers,
            "security_headers_enabled": settings.security_headers_enabled,
            "rate_limiting_enabled": settings.rate_limit_enabled,
            "cors_origins_count": len(settings.cors_origins),
            "jwt_expire_minutes": settings.jwt_expire_minutes,
            "max_file_upload_size": f"{settings.upload_max_file_size_mb}MB"
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/validate-input", tags=["Security"])
async def validate_input_test(data: Dict[str, Any]):
    """Test endpoint for input validation."""
    try:
        from app.security.security_validator import security_validator
        results = {}
        for key, value in data.items():
            result = security_validator.validate_and_sanitize_input(value)
            results[key] = {
                "is_valid": result.is_valid,
                "violations": result.violations,
                "sanitized_value": result.sanitized_value
            }
        return {"validation_results": results}
    except Exception as e:
        logger.error("Input validation test failed", error=str(e))
        return JSONResponse(
            status_code=500,
            content={"detail": "Validation service unavailable"}
        )

# Root endpoint
@app.get("/", tags=["General"])
async def root_endpoint(
    request_info: Dict[str, Any] = Depends(get_request_info)
):
    """
    Root endpoint with application information.
    
    Returns basic information about the API and the requesting client.
    """
    return {
        "message": f"Welcome to {settings.app_name} API",
        "version": settings.app_version,
        "environment": settings.environment,
        "docs_url": "/docs" if settings.is_development else "Documentation not available in production",
        "health_check": "/health",
        "health_endpoints": {
            "basic": "/health",
            "detailed": "/health/detailed",
            "readiness": "/health/ready",
            "liveness": "/health/live",
            "dependencies": "/health/dependencies",
            "metrics": "/health/metrics",
            "system": "/health/system",
            "version": "/health/version",
            "config": "/health/config"
        },
        "prometheus_metrics": "/metrics",
        "timestamp": datetime.utcnow().isoformat(),
        "request_info": {
            "correlation_id": request_info["correlation_id"],
            "client_ip": request_info["client_ip"],
            "user_agent": request_info["user_agent"]
        }
    }

# Metrics endpoint (existing)
@app.get("/metrics", tags=["Health"])
async def prometheus_metrics():
    """Prometheus metrics endpoint."""
    metrics_data = metrics.get_metrics()
    return PlainTextResponse(metrics_data, media_type="text/plain")

# WebSocket endpoint (existing)
try:
    from app.api.websocket import websocket_endpoint
    app.websocket("/ws")(websocket_endpoint)
    logger.info("WebSocket endpoint registered")
except ImportError as e:
    logger.warning("WebSocket endpoint not available", error=str(e))

# ==============================================================================
# APPLICATION UTILITIES
# ==============================================================================

@app.on_event("startup")
async def startup_event():
    """Startup event handler."""
    logger.info("Application startup event triggered")
    app_state["health_status"] = "healthy"

@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event handler."""
    logger.info("Application shutdown event triggered")
    app_state["health_status"] = "shutting_down"

# ==============================================================================
# SIGNAL HANDLERS
# ==============================================================================

def setup_signal_handlers():
    """Setup signal handlers for graceful shutdown."""
    def signal_handler(signum, frame):
        logger.info("Received shutdown signal", signal=signum)
        app_state["shutdown_event"].set()
        sys.exit(0)
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

# Setup signal handlers
setup_signal_handlers()

# ==============================================================================
# DEVELOPMENT SERVER ENTRY POINT
# ==============================================================================

if __name__ == "__main__":
    import uvicorn
    
    logger.info("Starting development server",
               host=settings.api_host,
               port=settings.api_port,
               reload=settings.hot_reload)
    
    uvicorn.run(
        "app.main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=settings.hot_reload,
        log_level=settings.log_level.lower(),
        access_log=True
    )