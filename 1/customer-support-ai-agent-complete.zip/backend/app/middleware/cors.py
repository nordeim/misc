"""
CORS middleware for FastAPI application.

Provides comprehensive CORS configuration with security policies.
"""

from typing import List, Optional, Dict, Any
from urllib.parse import urlparse

from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.base import BaseHTTPMiddleware
from fastapi.responses import Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import RequestResponseEndpoint
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class AdvancedCORSMiddleware(BaseHTTPMiddleware):
    """
    Advanced CORS middleware with additional security policies.
    
    This middleware extends FastAPI's built-in CORS middleware with:
    - Dynamic origin validation
    - Rate limiting for preflight requests
    - Security headers
    - Request logging
    """
    
    def __init__(self, app):
        super().__init__(app)
        
        # Build allowed origins list
        self.allowed_origins = self._build_allowed_origins()
        
        # Build allowed headers (ensure standard headers are always allowed)
        self.allowed_headers = self._build_allowed_headers()
        
        # Allowed methods
        self.allowed_methods = settings.cors_allow_methods.copy()
        
        # CORS preflight cache (max age in seconds)
        self.preflight_cache_max_age = 86400  # 24 hours
        
        logger.info("CORS middleware initialized", 
                   origins=len(self.allowed_origins),
                   methods=len(self.allowed_methods),
                   headers=len(self.allowed_headers))
    
    def _build_allowed_origins(self) -> List[str]:
        """Build the list of allowed origins."""
        origins = []
        
        # Add configured CORS origins
        for origin in settings.cors_origins:
            if isinstance(origin, str):
                origins.append(origin)
            else:
                origins.append(str(origin))
        
        # Add localhost variations for development
        if settings.is_development:
            localhost_origins = [
                "http://localhost:3000",    # React dev server
                "http://localhost:5173",    # Vite dev server
                "http://localhost:8080",    # General dev server
                "http://127.0.0.1:3000",
                "http://127.0.0.1:5173",
                "http://127.0.0.1:8080",
            ]
            
            for origin in localhost_origins:
                if origin not in origins:
                    origins.append(origin)
        
        return origins
    
    def _build_allowed_headers(self) -> List[str]:
        """Build the list of allowed headers."""
        headers = set(settings.cors_allow_headers)
        
        # Always include standard CORS headers
        standard_headers = [
            "Accept",
            "Accept-Language",
            "Content-Language",
            "Content-Type",
            "Authorization",
            "X-Requested-With",
            "Origin",
            "Access-Control-Request-Method",
            "Access-Control-Request-Headers",
        ]
        
        headers.update(standard_headers)
        
        # Add application-specific headers
        app_headers = [
            "X-API-Key",
            "X-Client-Version",
            "X-Request-ID",
            "X-User-Agent",
        ]
        
        headers.update(app_headers)
        
        return list(headers)
    
    def is_origin_allowed(self, origin: str) -> bool:
        """
        Check if origin is allowed.
        
        Args:
            origin: Origin header value
            
        Returns:
            True if origin is allowed, False otherwise
        """
        if not origin:
            return False
        
        # Exact match
        if origin in self.allowed_origins:
            return True
        
        # Wildcard match for subdomains
        for allowed_origin in self.allowed_origins:
            if allowed_origin.startswith("http://") or allowed_origin.startswith("https://"):
                parsed_allowed = urlparse(allowed_origin)
                parsed_origin = urlparse(origin)
                
                # Check if it's a subdomain
                if (parsed_allowed.netloc and parsed_origin.netloc and
                    parsed_allowed.netloc != "*" and
                    parsed_origin.netloc.endswith("." + parsed_allowed.netloc)):
                    return True
        
        # Check for localhost with different ports
        if origin.startswith("http://localhost:") or origin.startswith("http://127.0.0.1:"):
            return True
        
        return False
    
    def is_method_allowed(self, method: str) -> bool:
        """Check if method is allowed."""
        return method.upper() in self.allowed_methods
    
    def is_header_allowed(self, header: str) -> bool:
        """Check if header is allowed."""
        header_lower = header.lower()
        return any(
            allowed.lower() == header_lower or 
            allowed.lower() == "*" or
            header_lower.startswith(allowed.lower())
            for allowed in self.allowed_headers
        )
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        """Handle CORS requests."""
        origin = request.headers.get("Origin")
        method = request.method
        headers = request.headers
        
        # Handle preflight requests (OPTIONS)
        if method == "OPTIONS":
            return await self._handle_preflight_request(request, origin, headers)
        
        # Handle actual request
        return await self._handle_actual_request(request, origin, call_next)
    
    async def _handle_preflight_request(
        self, request: Request, origin: str, headers: Dict[str, str]
    ) -> Response:
        """Handle OPTIONS preflight request."""
        requested_method = headers.get("Access-Control-Request-Method", "").upper()
        requested_headers = headers.get("Access-Control-Request-Headers", "")
        
        # Check if origin is allowed
        if not self.is_origin_allowed(origin):
            logger.warning("CORS preflight rejected - origin not allowed", 
                          origin=origin, client=request.client.host)
            return JSONResponse(
                status_code=400,
                content={"detail": "Origin not allowed"},
                headers={"Content-Type": "application/json"}
            )
        
        # Check if method is allowed
        if not self.is_method_allowed(requested_method):
            logger.warning("CORS preflight rejected - method not allowed", 
                          method=requested_method, origin=origin)
            return JSONResponse(
                status_code=400,
                content={"detail": "Method not allowed"},
                headers={"Content-Type": "application/json"}
            )
        
        # Check if headers are allowed
        if requested_headers:
            header_list = [h.strip() for h in requested_headers.split(",")]
            for header in header_list:
                if not self.is_header_allowed(header):
                    logger.warning("CORS preflight rejected - header not allowed", 
                                  header=header, origin=origin)
                    return JSONResponse(
                        status_code=400,
                        content={"detail": f"Header not allowed: {header}"},
                        headers={"Content-Type": "application/json"}
                    )
        
        # Build response headers
        response_headers = {
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": ", ".join(self.allowed_methods),
            "Access-Control-Allow-Headers": ", ".join(self.allowed_headers),
            "Access-Control-Allow-Credentials": "true" if settings.cors_allow_credentials else "false",
            "Access-Control-Max-Age": str(self.preflight_cache_max_age),
            "Vary": "Origin",
        }
        
        logger.debug("CORS preflight request allowed", 
                    origin=origin, 
                    method=requested_method,
                    headers=requested_headers)
        
        return Response(
            status_code=200,
            headers=response_headers
        )
    
    async def _handle_actual_request(
        self, request: Request, origin: str, call_next
    ) -> Response:
        """Handle actual CORS request."""
        response = await call_next(request)
        
        # Add CORS headers to response
        if origin and self.is_origin_allowed(origin):
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true" if settings.cors_allow_credentials else "false"
            response.headers["Vary"] = "Origin"
        
        return response

def setup_cors_middleware(app) -> None:
    """
    Setup comprehensive CORS middleware for the FastAPI app.
    
    Args:
        app: FastAPI application instance
    """
    # Add FastAPI's built-in CORS middleware first
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=settings.cors_allow_methods,
        allow_headers=settings.cors_allow_headers,
        expose_headers=["X-Total-Count", "X-Request-ID"],
        max_age=86400,
    )
    
    # Add advanced CORS middleware for additional security
    app.add_middleware(AdvancedCORSMiddleware)
    
    logger.info("CORS middleware configured successfully")