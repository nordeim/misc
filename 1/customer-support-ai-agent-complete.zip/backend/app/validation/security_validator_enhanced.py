"""
Enhanced security validation system.

Provides comprehensive security validation including:
- Input sanitization and XSS protection
- SQL injection detection and prevention
- File security validation
- Content security policy validation
- Authentication and authorization validation
- Security pattern detection
"""

import re
import hashlib
import magic
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum
from urllib.parse import urlparse

from fastapi import HTTPException, status
import structlog

from app.config import settings

logger = structlog.get_logger(__name__)

class SecurityThreatLevel(Enum):
    """Security threat levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SecurityCheckType(Enum):
    """Types of security checks."""
    XSS = "xss"
    SQL_INJECTION = "sql_injection"
    COMMAND_INJECTION = "command_injection"
    PATH_TRAVERSAL = "path_traversal"
    FILE_UPLOAD = "file_upload"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    CSRF = "csrf"
    CONTENT_VALIDATION = "content_validation"

@dataclass
class SecurityIssue:
    """Represents a security issue."""
    check_type: SecurityCheckType
    threat_level: SecurityThreatLevel
    message: str
    field: Optional[str] = None
    detected_pattern: Optional[str] = None
    sanitized_value: Optional[str] = None
    recommendations: List[str] = None

@dataclass
class ValidationResult:
    """Security validation result."""
    is_safe: bool
    issues: List[SecurityIssue]
    sanitized_data: Optional[Dict[str, Any]] = None
    risk_score: int = 0  # 0-100, higher is more risky

class SecurityValidator:
    """Enhanced security validation system."""
    
    def __init__(self):
        self.threat_patterns = self._compile_threat_patterns()
        self.safe_domains = self._load_safe_domains()
        self.allowed_file_types = self._load_allowed_file_types()
        self.blocked_keywords = self._load_blocked_keywords()
        
        logger.info("Security validator initialized")
    
    def _compile_threat_patterns(self) -> Dict[SecurityCheckType, List[re.Pattern]]:
        """Compile security threat patterns."""
        return {
            SecurityCheckType.XSS: [
                re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL),
                re.compile(r'javascript:', re.IGNORECASE),
                re.compile(r'on\w+\s*=', re.IGNORECASE),
                re.compile(r'<iframe[^>]*>.*?</iframe>', re.IGNORECASE | re.DOTALL),
                re.compile(r'<object[^>]*>.*?</object>', re.IGNORECASE | re.DOTALL),
                re.compile(r'<embed[^>]*>.*?</embed>', re.IGNORECASE | re.DOTALL),
                re.compile(r'<link[^>]*>', re.IGNORECASE),
                re.compile(r'<style[^>]*>.*?</style>', re.IGNORECASE | re.DOTALL),
                re.compile(r'vbscript:', re.IGNORECASE),
                re.compile(r'data:text/html', re.IGNORECASE),
            ],
            SecurityCheckType.SQL_INJECTION: [
                re.compile(r'(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)', re.IGNORECASE),
                re.compile(r'(--|/\\*|\\*/|;)', re.IGNORECASE),
                re.compile(r'\bUNION\b.*\bSELECT\b', re.IGNORECASE),
                re.compile(r'[\'"]\s*OR\s*[\'"]?\s*\d+\s*=\s*\d+', re.IGNORECASE),
                re.compile(r'[\'"]\s*AND\s*[\'"]?\s*\d+\s*=\s*\d+', re.IGNORECASE),
                re.compile(r'\bOR\b.*\b1\b\s*=\s*\b1\b', re.IGNORECASE),
                re.compile(r'\bAND\b.*\b1\b\s*=\s*\b1\b', re.IGNORECASE),
            ],
            SecurityCheckType.COMMAND_INJECTION: [
                re.compile(r'[\;&|`$()]+\s*(cat|ls|rm|cp|mv|chmod|chown)', re.IGNORECASE),
                re.compile(r'&&\s*(wget|curl|nc|telnet|ssh)', re.IGNORECASE),
                re.compile(r'\|\|\s*(bash|sh|cmd|powershell)', re.IGNORECASE),
                re.compile(r'>\s*/etc/passwd', re.IGNORECASE),
                re.compile(r'<\s*/etc/shadow', re.IGNORECASE),
            ],
            SecurityCheckType.PATH_TRAVERSAL: [
                re.compile(r'\.\./', re.IGNORECASE),
                re.compile(r'\.\.\\', re.IGNORECASE),
                re.compile(r'%2e%2e%2f', re.IGNORECASE),
                re.compile(r'%2e%2e%5c', re.IGNORECASE),
                re.compile(r'\.\.%2f', re.IGNORECASE),
                re.compile(r'\.\.%5c', re.IGNORECASE),
            ],
        }
    
    def _load_safe_domains(self) -> List[str]:
        """Load list of safe domains."""
        return [
            'localhost',
            '127.0.0.1',
            'example.com',
            'example.org',
            'minimax.com',
            'minimaxi.com'
        ]
    
    def _load_allowed_file_types(self) -> Dict[str, str]:
        """Load allowed file types with MIME types."""
        return {
            '.txt': 'text/plain',
            '.pdf': 'application/pdf',
            '.doc': 'application/msword',
            '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            '.csv': 'text/csv',
            '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.json': 'application/json',
            '.xml': 'application/xml',
        }
    
    def _load_blocked_keywords(self) -> List[str]:
        """Load list of blocked keywords."""
        return [
            'admin',
            'root',
            'system',
            'password',
            'secret',
            'token',
            'key',
            'private',
            'confidential',
        ]
    
    def validate_input(
        self, 
        data: Any, 
        context: Dict[str, Any] = None
    ) -> ValidationResult:
        """
        Validate input for security threats.
        
        Args:
            data: Input data to validate
            context: Additional context for validation
            
        Returns:
            ValidationResult with security assessment
        """
        issues = []
        sanitized_data = {}
        risk_score = 0
        
        try:
            # Process different data types
            if isinstance(data, dict):
                for key, value in data.items():
                    validation_result = self._validate_field_value(key, value)
                    issues.extend(validation_result.issues)
                    sanitized_data[key] = validation_result.sanitized_value
                    risk_score += validation_result.risk_score
                    
            elif isinstance(data, str):
                validation_result = self._validate_field_value("input", data)
                issues.extend(validation_result.issues)
                sanitized_data["input"] = validation_result.sanitized_value
                risk_score += validation_result.risk_score
                
            else:
                # For other types, convert to string and validate
                str_data = str(data)
                validation_result = self._validate_field_value("input", str_data)
                issues.extend(validation_result.issues)
                sanitized_data["input"] = validation_result.sanitized_value
                risk_score += validation_result.risk_score
            
            # Determine if input is safe
            high_risk_issues = [issue for issue in issues if issue.threat_level == SecurityThreatLevel.HIGH]
            is_safe = len(high_risk_issues) == 0
            
            logger.info("Input security validation completed",
                       is_safe=is_safe,
                       issue_count=len(issues),
                       risk_score=risk_score)
            
            return ValidationResult(
                is_safe=is_safe,
                issues=issues,
                sanitized_data=sanitized_data if issues else None,
                risk_score=min(risk_score, 100)
            )
            
        except Exception as e:
            logger.error("Security validation error", error=str(e))
            return ValidationResult(
                is_safe=False,
                issues=[SecurityIssue(
                    check_type=SecurityCheckType.CONTENT_VALIDATION,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"Validation error: {str(e)}"
                )],
                risk_score=100
            )
    
    def _validate_field_value(
        self, 
        field_name: str, 
        value: Any
    ) -> ValidationResult:
        """Validate a single field value."""
        issues = []
        sanitized_value = value
        risk_score = 0
        
        # Convert to string for validation
        str_value = str(value) if value is not None else ""
        
        # XSS detection
        xss_issues = self._check_xss_patterns(str_value)
        for issue in xss_issues:
            issue.field = field_name
            issues.append(issue)
            risk_score += 25
        
        # SQL injection detection
        sql_issues = self._check_sql_injection_patterns(str_value)
        for issue in sql_issues:
            issue.field = field_name
            issues.append(issue)
            risk_score += 30
        
        # Command injection detection
        cmd_issues = self._check_command_injection_patterns(str_value)
        for issue in cmd_issues:
            issue.field = field_name
            issues.append(issue)
            risk_score += 35
        
        # Path traversal detection
        path_issues = self._check_path_traversal_patterns(str_value)
        for issue in path_issues:
            issue.field = field_name
            issues.append(issue)
            risk_score += 20
        
        # Sanitization
        if issues:
            sanitized_value = self._sanitize_value(str_value, issues)
        
        return ValidationResult(
            is_safe=len(issues) == 0,
            issues=issues,
            sanitized_value=sanitized_value,
            risk_score=risk_score
        )
    
    def _check_xss_patterns(self, value: str) -> List[SecurityIssue]:
        """Check for XSS patterns."""
        issues = []
        
        for pattern in self.threat_patterns[SecurityCheckType.XSS]:
            match = pattern.search(value)
            if match:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.XSS,
                    threat_level=SecurityThreatLevel.HIGH,
                    message="Potential XSS attack detected",
                    detected_pattern=match.group(),
                    recommendations=[
                        "Remove or sanitize script tags",
                        "Use proper output encoding",
                        "Implement Content Security Policy"
                    ]
                ))
        
        return issues
    
    def _check_sql_injection_patterns(self, value: str) -> List[SecurityIssue]:
        """Check for SQL injection patterns."""
        issues = []
        
        for pattern in self.threat_patterns[SecurityCheckType.SQL_INJECTION]:
            match = pattern.search(value)
            if match:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.SQL_INJECTION,
                    threat_level=SecurityThreatLevel.HIGH,
                    message="Potential SQL injection attack detected",
                    detected_pattern=match.group(),
                    recommendations=[
                        "Use parameterized queries",
                        "Validate and sanitize input",
                        "Implement proper escaping"
                    ]
                ))
        
        return issues
    
    def _check_command_injection_patterns(self, value: str) -> List[SecurityIssue]:
        """Check for command injection patterns."""
        issues = []
        
        for pattern in self.threat_patterns[SecurityCheckType.COMMAND_INJECTION]:
            match = pattern.search(value)
            if match:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.COMMAND_INJECTION,
                    threat_level=SecurityThreatLevel.CRITICAL,
                    message="Potential command injection attack detected",
                    detected_pattern=match.group(),
                    recommendations=[
                        "Never execute user input as commands",
                        "Use whitelisting for allowed commands",
                        "Implement proper input validation"
                    ]
                ))
        
        return issues
    
    def _check_path_traversal_patterns(self, value: str) -> List[SecurityIssue]:
        """Check for path traversal patterns."""
        issues = []
        
        for pattern in self.threat_patterns[SecurityCheckType.PATH_TRAVERSAL]:
            match = pattern.search(value)
            if match:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.PATH_TRAVERSAL,
                    threat_level=SecurityThreatLevel.HIGH,
                    message="Potential path traversal attack detected",
                    detected_pattern=match.group(),
                    recommendations=[
                        "Validate and normalize file paths",
                        "Use join() instead of string concatenation",
                        "Implement proper access controls"
                    ]
                ))
        
        return issues
    
    def _sanitize_value(self, value: str, issues: List[SecurityIssue]) -> str:
        """Sanitize a value based on detected issues."""
        sanitized = value
        
        # Remove XSS patterns
        xss_issues = [issue for issue in issues if issue.check_type == SecurityCheckType.XSS]
        for issue in xss_issues:
            sanitized = re.sub(r'<[^>]+>', '', sanitized)  # Remove HTML tags
            sanitized = re.sub(r'javascript:', '', sanitized, flags=re.IGNORECASE)
            sanitized = re.sub(r'on\w+\s*=', '', sanitized, flags=re.IGNORECASE)
        
        # Remove SQL injection patterns (basic sanitization)
        sql_issues = [issue for issue in issues if issue.check_type == SecurityCheckType.SQL_INJECTION]
        for issue in sql_issues:
            # Basic SQL keyword removal
            sql_keywords = ['select', 'insert', 'update', 'delete', 'drop', 'create', 'alter']
            for keyword in sql_keywords:
                pattern = r'\b' + keyword + r'\b'
                sanitized = re.sub(pattern, '', sanitized, flags=re.IGNORECASE)
        
        # Clean up path traversal
        path_issues = [issue for issue in issues if issue.check_type == SecurityCheckType.PATH_TRAVERSAL]
        for issue in path_issues:
            sanitized = sanitized.replace('../', '')
            sanitized = sanitized.replace('..\\', '')
        
        return sanitized
    
    def validate_file_upload(
        self, 
        filename: str, 
        content: bytes, 
        content_type: str,
        context: Dict[str, Any] = None
    ) -> ValidationResult:
        """
        Validate file upload for security threats.
        
        Args:
            filename: Name of the uploaded file
            content: File content as bytes
            content_type: MIME type of the file
            context: Additional context for validation
            
        Returns:
            ValidationResult with security assessment
        """
        issues = []
        risk_score = 0
        
        try:
            # Check file extension
            file_ext = Path(filename).suffix.lower()
            if file_ext not in self.allowed_file_types:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.FILE_UPLOAD,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"File type not allowed: {file_ext}",
                    field="filename",
                    recommendations=[f"Allowed types: {', '.join(self.allowed_file_types.keys())}"]
                ))
                risk_score += 40
            
            # Check MIME type consistency
            expected_mime = self.allowed_file_types.get(file_ext)
            if expected_mime and content_type != expected_mime:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.FILE_UPLOAD,
                    threat_level=SecurityThreatLevel.MEDIUM,
                    message=f"MIME type mismatch: expected {expected_mime}, got {content_type}",
                    field="content_type",
                    recommendations=["Verify file content matches extension"]
                ))
                risk_score += 20
            
            # Check file size
            max_size = 50 * 1024 * 1024  # 50MB
            if len(content) > max_size:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.FILE_UPLOAD,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"File too large: {len(content)} bytes (max: {max_size})",
                    field="content",
                    recommendations=[f"Reduce file size to {max_size // (1024*1024)}MB or less"]
                ))
                risk_score += 30
            
            # Check for executable files
            executable_extensions = {'.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js', '.jar'}
            if file_ext in executable_extensions:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.FILE_UPLOAD,
                    threat_level=SecurityThreatLevel.CRITICAL,
                    message=f"Executable file not allowed: {file_ext}",
                    field="filename",
                    recommendations=["Upload only document and image files"]
                ))
                risk_score += 50
            
            # Check file content for malicious patterns
            content_str = content.decode('utf-8', errors='ignore')
            
            # XSS in file content
            xss_issues = self._check_xss_patterns(content_str)
            for issue in xss_issues:
                issue.field = "content"
                issues.append(issue)
                risk_score += 25
            
            # Script injection in file content
            script_patterns = [
                re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL),
                re.compile(r'<\?php', re.IGNORECASE),
                re.compile(r'<%', re.IGNORECASE),
                re.compile(r'eval\s*\(', re.IGNORECASE),
            ]
            
            for pattern in script_patterns:
                if pattern.search(content_str):
                    issues.append(SecurityIssue(
                        check_type=SecurityCheckType.FILE_UPLOAD,
                        threat_level=SecurityThreatLevel.HIGH,
                        message="Potential script injection detected in file content",
                        field="content",
                        recommendations=["Remove script code from file"]
                    ))
                    risk_score += 35
            
            # Check for embedded files (zip bombs, etc.)
            if file_ext == '.zip':
                # Basic zip file validation would go here
                pass
            
            logger.info("File upload security validation completed",
                       filename=filename,
                       is_safe=len([i for i in issues if i.threat_level == SecurityThreatLevel.HIGH]) == 0,
                       issue_count=len(issues),
                       risk_score=risk_score)
            
            return ValidationResult(
                is_safe=len([i for i in issues if i.threat_level in [SecurityThreatLevel.HIGH, SecurityThreatLevel.CRITICAL]]) == 0,
                issues=issues,
                risk_score=min(risk_score, 100)
            )
            
        except Exception as e:
            logger.error("File upload validation error", error=str(e))
            return ValidationResult(
                is_safe=False,
                issues=[SecurityIssue(
                    check_type=SecurityCheckType.FILE_UPLOAD,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"File validation error: {str(e)}"
                )],
                risk_score=100
            )
    
    def validate_url(self, url: str) -> ValidationResult:
        """Validate URL for security threats."""
        issues = []
        risk_score = 0
        
        try:
            parsed = urlparse(url)
            
            # Check for dangerous protocols
            dangerous_protocols = ['javascript', 'data', 'file', 'ftp']
            if parsed.scheme.lower() in dangerous_protocols:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.XSS,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"Dangerous URL protocol: {parsed.scheme}",
                    detected_pattern=parsed.scheme,
                    recommendations=["Use only http or https protocols"]
                ))
                risk_score += 30
            
            # Check domain against whitelist/blacklist
            domain = parsed.netloc.lower()
            
            # Check for private IP ranges (if domain is IP)
            private_ip_patterns = [
                re.compile(r'^127\.', re.IGNORECASE),
                re.compile(r'^10\.', re.IGNORECASE),
                re.compile(r'^192\.168\.', re.IGNORECASE),
                re.compile(r'^172\.(1[6-9]|2[0-9]|3[0-1])\.', re.IGNORECASE),
            ]
            
            for pattern in private_ip_patterns:
                if pattern.match(domain):
                    issues.append(SecurityIssue(
                        check_type=SecurityCheckType.XSS,
                        threat_level=SecurityThreatLevel.MEDIUM,
                        message="URL points to private network",
                        detected_pattern=domain,
                        recommendations=["Use public URLs only"]
                    ))
                    risk_score += 20
            
            # Check for suspicious patterns
            suspicious_patterns = [
                r'%2e%2e%2f',  # ../
                r'%2e%2e%5c',  # ..\
                r'\.\./',      # ../
                r'<script',    # XSS
                r'javascript:', # JavaScript protocol
            ]
            
            for pattern in suspicious_patterns:
                if re.search(pattern, url, re.IGNORECASE):
                    issues.append(SecurityIssue(
                        check_type=SecurityCheckType.XSS,
                        threat_level=SecurityThreatLevel.HIGH,
                        message="Suspicious URL pattern detected",
                        detected_pattern=pattern,
                        recommendations=["Use only trusted URLs"]
                    ))
                    risk_score += 25
            
            return ValidationResult(
                is_safe=len([i for i in issues if i.threat_level == SecurityThreatLevel.HIGH]) == 0,
                issues=issues,
                risk_score=min(risk_score, 100)
            )
            
        except Exception as e:
            return ValidationResult(
                is_safe=False,
                issues=[SecurityIssue(
                    check_type=SecurityCheckType.XSS,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"URL validation error: {str(e)}"
                )],
                risk_score=100
            )
    
    def validate_authentication_context(self, context: Dict[str, Any]) -> ValidationResult:
        """Validate authentication context."""
        issues = []
        risk_score = 0
        
        try:
            # Check authentication method
            auth_method = context.get('method', 'unknown')
            if auth_method not in ['jwt', 'api_key', 'session', 'oauth']:
                issues.append(SecurityIssue(
                    check_type=SecurityCheckType.AUTHENTICATION,
                    threat_level=SecurityThreatLevel.MEDIUM,
                    message=f"Unknown authentication method: {auth_method}",
                    recommendations=["Use supported authentication methods"]
                ))
                risk_score += 15
            
            # Check token validity
            if auth_method in ['jwt', 'api_key']:
                token = context.get('token')
                if not token or len(token) < 10:
                    issues.append(SecurityIssue(
                        check_type=SecurityCheckType.AUTHENTICATION,
                        threat_level=SecurityThreatLevel.HIGH,
                        message="Invalid or missing authentication token",
                        recommendations=["Provide valid authentication credentials"]
                    ))
                    risk_score += 30
            
            return ValidationResult(
                is_safe=len(issues) == 0,
                issues=issues,
                risk_score=min(risk_score, 100)
            )
            
        except Exception as e:
            return ValidationResult(
                is_safe=False,
                issues=[SecurityIssue(
                    check_type=SecurityCheckType.AUTHENTICATION,
                    threat_level=SecurityThreatLevel.HIGH,
                    message=f"Authentication validation error: {str(e)}"
                )],
                risk_score=100
            )
    
    def get_security_summary(self, validation_results: List[ValidationResult]) -> Dict[str, Any]:
        """Get security summary from multiple validation results."""
        total_issues = sum(len(result.issues) for result in validation_results)
        critical_issues = sum(1 for result in validation_results 
                            for issue in result.issues 
                            if issue.threat_level == SecurityThreatLevel.CRITICAL)
        high_issues = sum(1 for result in validation_results 
                        for issue in result.issues 
                        if issue.threat_level == SecurityThreatLevel.HIGH)
        total_risk_score = sum(result.risk_score for result in validation_results)
        
        return {
            "total_issues": total_issues,
            "critical_issues": critical_issues,
            "high_issues": high_issues,
            "average_risk_score": total_risk_score / len(validation_results) if validation_results else 0,
            "is_safe": critical_issues == 0 and high_issues == 0,
            "threat_breakdown": {
                level.value: sum(1 for result in validation_results 
                               for issue in result.issues 
                               if issue.threat_level.value == level.value)
                for level in SecurityThreatLevel
            }
        }

# Utility functions
def sanitize_html(value: str) -> str:
    """Basic HTML sanitization."""
    import html
    # Remove script tags and their content
    value = re.sub(r'<script[^>]*>.*?</script>', '', value, flags=re.IGNORECASE | re.DOTALL)
    # Remove javascript: protocol
    value = re.sub(r'javascript:[^"\']*', '', value, flags=re.IGNORECASE)
    # Remove event handlers
    value = re.sub(r'on\w+\s*=', '', value, flags=re.IGNORECASE)
    # Escape HTML entities
    return html.escape(value, quote=True)

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe storage."""
    # Remove path traversal attempts
    filename = filename.replace('../', '').replace('..\\', '')
    
    # Remove dangerous characters
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove control characters
    filename = ''.join(char for char in filename if ord(char) >= 32)
    
    # Limit length
    if len(filename) > 255:
        name, ext = Path(filename).stem, Path(filename).suffix
        filename = f"{name[:250-len(ext)]}{ext}"
    
    return filename

def detect_malicious_content(content: str) -> Dict[str, bool]:
    """Detect various types of malicious content."""
    return {
        "has_xss": bool(re.search(r'<script|javascript:|on\w+\s*=', content, re.IGNORECASE)),
        "has_sql_injection": bool(re.search(r'\b(SELECT|INSERT|UPDATE|DELETE)\b|UNION\s+SELECT|--|;', content, re.IGNORECASE)),
        "has_command_injection": bool(re.search(r'[\;&|`$()]+|&&|\|\|', content)),
        "has_path_traversal": bool(re.search(r'\.\./|\.\.\\|%2e%2e%2f', content, re.IGNORECASE)),
    }