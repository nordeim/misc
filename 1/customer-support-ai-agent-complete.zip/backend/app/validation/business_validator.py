"""
Business logic validation system.

Provides comprehensive business rule validation including:
- Domain-specific validation rules
- Business process validation
- Data consistency checks
- Workflow validation
- Business constraint validation
"""

import re
import uuid
from typing import Any, Dict, List, Optional, Union, Callable, Type
from datetime import datetime, date, timedelta
from enum import Enum
from dataclasses import dataclass

from fastapi import HTTPException, status
import structlog

from app.config import settings
from app.database import get_db
from app.models.user import UserModel

logger = structlog.get_logger(__name__)

class BusinessRuleType(Enum):
    """Types of business rules."""
    CONSTRAINT = "constraint"
    VALIDATION = "validation"
    WORKFLOW = "workflow"
    PERMISSION = "permission"
    QUOTA = "quota"
    CONSISTENCY = "consistency"

class ValidationSeverity(Enum):
    """Validation severity levels."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"

@dataclass
class BusinessRule:
    """Represents a business rule."""
    name: str
    rule_type: BusinessRuleType
    severity: ValidationSeverity
    description: str
    validator_func: Callable
    parameters: Dict[str, Any]
    enabled: bool = True

@dataclass
class ValidationIssue:
    """Represents a validation issue."""
    rule_name: str
    severity: ValidationSeverity
    message: str
    field: Optional[str] = None
    code: Optional[str] = None
    suggestions: List[str] = None

class BusinessLogicValidator:
    """Comprehensive business logic validation system."""
    
    def __init__(self):
        self.rules = self._initialize_rules()
        self.validation_cache = {}
        self.cache_ttl = 300  # 5 minutes
        
        logger.info("Business logic validator initialized", 
                   rule_count=len(self.rules))
    
    def _initialize_rules(self) -> List[BusinessRule]:
        """Initialize business rules."""
        return [
            # User-related rules
            BusinessRule(
                name="username_uniqueness",
                rule_type=BusinessRuleType.CONSTRAINT,
                severity=ValidationSeverity.ERROR,
                description="Username must be unique across the system",
                validator_func=self._validate_username_uniqueness,
                parameters={}
            ),
            BusinessRule(
                name="email_format",
                rule_type=BusinessRuleType.VALIDATION,
                severity=ValidationSeverity.ERROR,
                description="Email must be in valid format and domain",
                validator_func=self._validate_email_format,
                parameters={"allowed_domains": settings.allowed_email_domains}
            ),
            BusinessRule(
                name="password_strength",
                rule_type=BusinessRuleType.VALIDATION,
                severity=ValidationSeverity.ERROR,
                description="Password must meet security requirements",
                validator_func=self._validate_password_strength,
                parameters={
                    "min_length": 8,
                    "require_uppercase": True,
                    "require_lowercase": True,
                    "require_digit": True,
                    "require_special": True
                }
            ),
            
            # Chat-related rules
            BusinessRule(
                name="message_length",
                rule_type=BusinessRuleType.VALIDATION,
                severity=ValidationSeverity.ERROR,
                description="Message length must be within acceptable limits",
                validator_func=self._validate_message_length,
                parameters={"max_length": 2000}
            ),
            BusinessRule(
                name="session_expiry",
                rule_type=BusinessRuleType.CONSTRAINT,
                severity=ValidationSeverity.ERROR,
                description="Session must not be expired",
                validator_func=self._validate_session_expiry,
                parameters={"max_age_hours": 24}
            ),
            BusinessRule(
                name="rate_limit_per_user",
                rule_type=BusinessRuleType.QUOTA,
                severity=ValidationSeverity.WARNING,
                description="User must not exceed message rate limits",
                validator_func=self._validate_user_rate_limit,
                parameters={"max_messages_per_hour": 100}
            ),
            
            # File-related rules
            BusinessRule(
                name="file_size_limit",
                rule_type=BusinessRuleType.CONSTRAINT,
                severity=ValidationSeverity.ERROR,
                description="File size must not exceed limits",
                validator_func=self._validate_file_size,
                parameters={"max_size_mb": 50}
            ),
            BusinessRule(
                name="file_type_restriction",
                rule_type=BusinessRuleType.CONSTRAINT,
                severity=ValidationSeverity.ERROR,
                description="File type must be allowed",
                validator_func=self._validate_file_type,
                parameters={"allowed_extensions": {".pdf", ".doc", ".docx", ".txt", ".jpg", ".png", ".csv"}}
            ),
            
            # Escalation-related rules
            BusinessRule(
                name="escalation_priority_valid",
                rule_type=BusinessRuleType.VALIDATION,
                severity=ValidationSeverity.ERROR,
                description="Escalation priority must be valid",
                validator_func=self._validate_escalation_priority,
                parameters={}
            ),
            BusinessRule(
                name="escalation_reason_required",
                rule_type=BusinessRuleType.VALIDATION,
                severity=ValidationSeverity.ERROR,
                description="Escalation must have valid reason",
                validator_func=self._validate_escalation_reason,
                parameters={}
            ),
            
            # Agent-related rules
            BusinessRule(
                name="agent_availability",
                rule_type=BusinessRuleType.CONSTRAINT,
                severity=ValidationSeverity.ERROR,
                description="Agent must be available for assignment",
                validator_func=self._validate_agent_availability,
                parameters={"max_concurrent_conversations": 10}
            ),
            
            # Security-related rules
            BusinessRule(
                name="suspicious_activity",
                rule_type=BusinessRuleType.SECURITY,
                severity=ValidationSeverity.WARNING,
                description="Detect suspicious user activity patterns",
                validator_func=self._validate_suspicious_activity,
                parameters={}
            ),
            BusinessRule(
                name="permission_check",
                rule_type=BusinessRuleType.PERMISSION,
                severity=ValidationSeverity.ERROR,
                description="User must have required permissions",
                validator_func=self._validate_permissions,
                parameters={}
            ),
        ]
    
    def validate_business_rules(
        self, 
        data: Any, 
        context: Dict[str, Any],
        rule_names: Optional[List[str]] = None
    ) -> List[ValidationIssue]:
        """
        Validate data against business rules.
        
        Args:
            data: Data to validate
            context: Business context (user info, session info, etc.)
            rule_names: Specific rules to validate (None for all enabled rules)
            
        Returns:
            List of validation issues
        """
        issues = []
        rules_to_check = self.rules
        
        if rule_names:
            rules_to_check = [rule for rule in self.rules if rule.name in rule_names]
        
        for rule in rules_to_check:
            if not rule.enabled:
                continue
            
            try:
                # Check cache first
                cache_key = f"{rule.name}:{hash(str(data))}:{hash(str(context))}"
                if cache_key in self.validation_cache:
                    cached_issues = self.validation_cache[cache_key]
                    issues.extend(cached_issues)
                    continue
                
                # Validate rule
                rule_issues = rule.validator_func(data, context, rule.parameters)
                
                # Add issues to list
                if isinstance(rule_issues, list):
                    issues.extend(rule_issues)
                elif rule_issues:
                    issues.append(rule_issues)
                
                # Cache result
                if len(issues) < 10:  # Only cache simple cases
                    self.validation_cache[cache_key] = issues
                
            except Exception as e:
                logger.error("Business rule validation error",
                           rule=rule.name,
                           error=str(e))
                issues.append(ValidationIssue(
                    rule_name=rule.name,
                    severity=ValidationSeverity.ERROR,
                    message=f"Validation rule error: {str(e)}"
                ))
        
        return issues
    
    def add_rule(self, rule: BusinessRule):
        """Add a new business rule."""
        self.rules.append(rule)
        logger.info("Business rule added", rule_name=rule.name)
    
    def remove_rule(self, rule_name: str):
        """Remove a business rule."""
        self.rules = [rule for rule in self.rules if rule.name != rule_name]
        logger.info("Business rule removed", rule_name=rule_name)
    
    def enable_rule(self, rule_name: str):
        """Enable a business rule."""
        for rule in self.rules:
            if rule.name == rule_name:
                rule.enabled = True
                break
        logger.info("Business rule enabled", rule_name=rule_name)
    
    def disable_rule(self, rule_name: str):
        """Disable a business rule."""
        for rule in self.rules:
            if rule.name == rule_name:
                rule.enabled = False
                break
        logger.info("Business rule disabled", rule_name=rule_name)
    
    # Rule implementations
    def _validate_username_uniqueness(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate username uniqueness."""
        if 'username' not in data:
            return []
        
        username = data['username']
        
        try:
            # Check if username already exists
            # This would typically query the database
            # For now, just check basic rules
            if len(username) < 3:
                return [ValidationIssue(
                    rule_name="username_uniqueness",
                    severity=ValidationSeverity.ERROR,
                    message="Username must be at least 3 characters long",
                    field="username"
                )]
            
            return []
        except Exception as e:
            return [ValidationIssue(
                rule_name="username_uniqueness",
                severity=ValidationSeverity.ERROR,
                message=f"Unable to verify username uniqueness: {str(e)}",
                field="username"
            )]
    
    def _validate_email_format(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate email format and domain."""
        if 'email' not in data:
            return []
        
        email = data['email']
        issues = []
        
        # Basic format validation
        email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        if not email_pattern.match(email):
            return [ValidationIssue(
                rule_name="email_format",
                severity=ValidationSeverity.ERROR,
                message="Invalid email format",
                field="email"
            )]
        
        # Domain validation
        allowed_domains = params.get('allowed_domains', [])
        if allowed_domains:
            domain = email.split('@')[1].lower()
            if domain not in allowed_domains:
                issues.append(ValidationIssue(
                    rule_name="email_format",
                    severity=ValidationSeverity.WARNING,
                    message=f"Email domain '{domain}' is not in the allowed list",
                    field="email",
                    suggestions=[f"Use an email from: {', '.join(allowed_domains)}"]
                ))
        
        return issues
    
    def _validate_password_strength(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate password strength."""
        if 'password' not in data:
            return []
        
        password = data['password']
        issues = []
        
        min_length = params.get('min_length', 8)
        if len(password) < min_length:
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message=f"Password must be at least {min_length} characters long",
                field="password"
            ))
        
        if params.get('require_uppercase') and not re.search(r'[A-Z]', password):
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message="Password must contain at least one uppercase letter",
                field="password"
            ))
        
        if params.get('require_lowercase') and not re.search(r'[a-z]', password):
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message="Password must contain at least one lowercase letter",
                field="password"
            ))
        
        if params.get('require_digit') and not re.search(r'\d', password):
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message="Password must contain at least one digit",
                field="password"
            ))
        
        if params.get('require_special') and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message="Password must contain at least one special character",
                field="password"
            ))
        
        # Check for common patterns
        common_patterns = ['password', '1234', 'qwerty', 'admin']
        if any(pattern in password.lower() for pattern in common_patterns):
            issues.append(ValidationIssue(
                rule_name="password_strength",
                severity=ValidationSeverity.ERROR,
                message="Password cannot contain common patterns",
                field="password"
            ))
        
        return issues
    
    def _validate_message_length(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate message length."""
        if 'message' not in data:
            return []
        
        message = data['message']
        max_length = params.get('max_length', 2000)
        
        if len(message) > max_length:
            return [ValidationIssue(
                rule_name="message_length",
                severity=ValidationSeverity.ERROR,
                message=f"Message too long. Maximum {max_length} characters allowed",
                field="message",
                suggestions=[f"Reduce message to {max_length} characters or less"]
            )]
        
        return []
    
    def _validate_session_expiry(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate session expiry."""
        session_info = context.get('session', {})
        if not session_info:
            return [ValidationIssue(
                rule_name="session_expiry",
                severity=ValidationSeverity.ERROR,
                message="Session information not provided",
                suggestions=["Provide valid session context"]
            )]
        
        session_created = session_info.get('created_at')
        if session_created:
            max_age_hours = params.get('max_age_hours', 24)
            session_age = (datetime.utcnow() - session_created).total_seconds() / 3600
            
            if session_age > max_age_hours:
                return [ValidationIssue(
                    rule_name="session_expiry",
                    severity=ValidationSeverity.ERROR,
                    message=f"Session expired. Age: {session_age:.1f} hours",
                    suggestions=["Create a new session"]
                )]
        
        return []
    
    def _validate_user_rate_limit(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate user rate limit."""
        user_info = context.get('user', {})
        if not user_info:
            return []
        
        # This would check actual rate limits from database/cache
        # For now, just return no issues
        return []
    
    def _validate_file_size(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate file size."""
        if 'size' in data:
            max_size_mb = params.get('max_size_mb', 50)
            max_size_bytes = max_size_mb * 1024 * 1024
            
            if data['size'] > max_size_bytes:
                return [ValidationIssue(
                    rule_name="file_size_limit",
                    severity=ValidationSeverity.ERROR,
                    message=f"File too large. Maximum size: {max_size_mb}MB",
                    field="size",
                    suggestions=[f"Reduce file size to {max_size_mb}MB or less"]
                )]
        
        return []
    
    def _validate_file_type(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate file type."""
        if 'filename' in data:
            filename = data['filename']
            allowed_extensions = params.get('allowed_extensions', set())
            
            import os
            file_ext = os.path.splitext(filename)[1].lower()
            
            if allowed_extensions and file_ext not in allowed_extensions:
                return [ValidationIssue(
                    rule_name="file_type_restriction",
                    severity=ValidationSeverity.ERROR,
                    message=f"File type '{file_ext}' not allowed",
                    field="filename",
                    suggestions=[f"Allowed types: {', '.join(allowed_extensions)}"]
                )]
        
        return []
    
    def _validate_escalation_priority(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate escalation priority."""
        if 'priority' in data:
            valid_priorities = {'low', 'medium', 'high', 'critical'}
            if data['priority'].lower() not in valid_priorities:
                return [ValidationIssue(
                    rule_name="escalation_priority_valid",
                    severity=ValidationSeverity.ERROR,
                    message="Invalid escalation priority",
                    field="priority",
                    suggestions=[f"Valid priorities: {', '.join(valid_priorities)}"]
                )]
        
        return []
    
    def _validate_escalation_reason(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate escalation reason."""
        if 'reason' not in data or not data['reason'].strip():
            return [ValidationIssue(
                rule_name="escalation_reason_required",
                severity=ValidationSeverity.ERROR,
                message="Escalation reason is required",
                field="reason",
                suggestions=["Provide a clear reason for escalation"]
            )]
        
        return []
    
    def _validate_agent_availability(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate agent availability."""
        agent_info = context.get('agent', {})
        if not agent_info:
            return []
        
        # Check if agent is available
        # This would typically check agent status, current load, etc.
        return []
    
    def _validate_suspicious_activity(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate suspicious activity."""
        issues = []
        user_info = context.get('user', {})
        
        # Check for rapid-fire requests
        if self._is_rapid_fire_activity(context):
            issues.append(ValidationIssue(
                rule_name="suspicious_activity",
                severity=ValidationSeverity.WARNING,
                message="Unusual request frequency detected",
                suggestions=["Slow down requests if you're a human user"]
            ))
        
        # Check for multiple failed attempts
        if self._has_multiple_failures(context):
            issues.append(ValidationIssue(
                rule_name="suspicious_activity",
                severity=ValidationSeverity.WARNING,
                message="Multiple failed attempts detected",
                suggestions=["Check your credentials and try again"]
            ))
        
        return issues
    
    def _validate_permissions(self, data: Dict[str, Any], context: Dict[str, Any], params: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate user permissions."""
        user_info = context.get('user', {})
        required_permission = context.get('required_permission')
        
        if required_permission and not self._has_permission(user_info, required_permission):
            return [ValidationIssue(
                rule_name="permission_check",
                severity=ValidationSeverity.ERROR,
                message="Insufficient permissions",
                suggestions=[f"Required permission: {required_permission}"]
            )]
        
        return []
    
    # Helper methods
    def _is_rapid_fire_activity(self, context: Dict[str, Any]) -> bool:
        """Check for rapid-fire request activity."""
        # This would analyze request timestamps and frequency
        return False
    
    def _has_multiple_failures(self, context: Dict[str, Any]) -> bool:
        """Check for multiple recent failures."""
        # This would check failure history
        return False
    
    def _has_permission(self, user_info: Dict[str, Any], permission: str) -> bool:
        """Check if user has specific permission."""
        # This would check user roles and permissions
        user_role = user_info.get('role', 'user')
        return user_role in ['admin', 'moderator']
    
    def validate_and_raise(self, data: Any, context: Dict[str, Any], rule_names: Optional[List[str]] = None):
        """Validate and raise HTTP exception if issues found."""
        issues = self.validate_business_rules(data, context, rule_names)
        
        if not issues:
            return
        
        # Group issues by severity
        errors = [issue for issue in issues if issue.severity == ValidationSeverity.ERROR]
        warnings = [issue for issue in issues if issue.severity == ValidationSeverity.WARNING]
        
        if errors:
            error_messages = [f"{issue.field or 'data'}: {issue.message}" for issue in errors]
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Business validation failed: {'; '.join(error_messages)}"
            )
        
        # Log warnings but don't fail
        for warning in warnings:
            logger.warning("Business validation warning",
                         rule=warning.rule_name,
                         message=warning.message)

# Context builders for common validation scenarios
def build_user_context(user_data: Dict[str, Any], request_context: Dict[str, Any] = None) -> Dict[str, Any]:
    """Build user context for validation."""
    return {
        "user": user_data,
        "request": request_context or {},
        "timestamp": datetime.utcnow()
    }

def build_session_context(session_data: Dict[str, Any], user_data: Dict[str, Any] = None) -> Dict[str, Any]:
    """Build session context for validation."""
    return {
        "session": session_data,
        "user": user_data or {},
        "timestamp": datetime.utcnow()
    }

def build_chat_context(message_data: Dict[str, Any], session_data: Dict[str, Any], user_data: Dict[str, Any]) -> Dict[str, Any]:
    """Build chat context for validation."""
    return {
        "message": message_data,
        "session": session_data,
        "user": user_data,
        "timestamp": datetime.utcnow()
    }