"""
Agent Factory and Management System.

This module provides factory patterns for creating and managing agent instances,
including configuration management, lifecycle control, and monitoring.
"""

import asyncio
import logging
import weakref
from typing import Dict, List, Optional, Any, Callable, Union
from datetime import datetime, timedelta
from dataclasses import asdict
from pathlib import Path
import json

from .chat_agent import (
    CustomerSupportAgent,
    AgentConfiguration,
    AgentContext,
    AgentMetrics,
    AgentState
)
from app.config import settings

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Registry for managing agent instances."""
    
    def __init__(self):
        self._agents: Dict[str, CustomerSupportAgent] = {}
        self._agent_metadata: Dict[str, Dict[str, Any]] = {}
        self._health_check_callbacks: List[Callable] = []
        self._metrics_callbacks: List[Callable] = []
        self._shutdown_callbacks: List[Callable] = []
    
    def register_agent(
        self, 
        agent: CustomerSupportAgent, 
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Register an agent instance."""
        if agent.agent_id in self._agents:
            logger.warning(f"Agent {agent.agent_id} already registered, updating metadata")
        
        self._agents[agent.agent_id] = agent
        self._agent_metadata[agent.agent_id] = metadata or {}
        
        logger.info(f"Registered agent {agent.agent_id}")
    
    def unregister_agent(self, agent_id: str):
        """Unregister an agent instance."""
        if agent_id in self._agents:
            del self._agents[agent_id]
            if agent_id in self._agent_metadata:
                del self._agent_metadata[agent_id]
            logger.info(f"Unregistered agent {agent_id}")
    
    def get_agent(self, agent_id: str) -> Optional[CustomerSupportAgent]:
        """Get an agent by ID."""
        return self._agents.get(agent_id)
    
    def get_all_agents(self) -> Dict[str, CustomerSupportAgent]:
        """Get all registered agents."""
        return self._agents.copy()
    
    def get_agents_by_state(self, state: AgentState) -> List[CustomerSupportAgent]:
        """Get agents by state."""
        return [agent for agent in self._agents.values() if agent.state == state]
    
    def add_health_check_callback(self, callback: Callable):
        """Add health check callback."""
        self._health_check_callbacks.append(callback)
    
    def add_metrics_callback(self, callback: Callable):
        """Add metrics callback."""
        self._metrics_callbacks.append(callback)
    
    def add_shutdown_callback(self, callback: Callable):
        """Add shutdown callback."""
        self._shutdown_callbacks.append(callback)


class AgentConfigurationManager:
    """Manager for agent configurations."""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or "./config/agent_configs.json"
        self._configurations: Dict[str, AgentConfiguration] = {}
        self._load_configurations()
    
    def _load_configurations(self):
        """Load agent configurations from file."""
        try:
            config_file = Path(self.config_path)
            if config_file.exists():
                with open(config_file, 'r') as f:
                    data = json.load(f)
                
                for name, config_data in data.items():
                    self._configurations[name] = AgentConfiguration(**config_data)
                
                logger.info(f"Loaded {len(self._configurations)} agent configurations")
            else:
                # Create default configurations
                self._create_default_configurations()
                
        except Exception as e:
            logger.error(f"Error loading agent configurations: {e}")
            self._create_default_configurations()
    
    def _create_default_configurations(self):
        """Create default agent configurations."""
        # Development configuration
        self._configurations["development"] = AgentConfiguration(
            max_history_length=50,
            max_processing_time=30.0,
            max_response_length=4000,
            confidence_threshold=0.7,
            escalation_threshold=0.8,
            enable_caching=True,
            cache_ttl=3600,
            enable_metrics=True,
            enable_tool_selection=True,
            tool_timeout=10.0,
            parallel_tool_execution=True,
            max_concurrent_tools=3,
            memory_optimization=True,
            response_streaming=True,
            auto_retry=True,
            max_retries=3,
            retry_delay=1.0,
            enable_conversation_cleanup=True,
            conversation_timeout_hours=24,
            enable_performance_monitoring=True
        )
        
        # Production configuration
        self._configurations["production"] = AgentConfiguration(
            max_history_length=100,
            max_processing_time=60.0,
            max_response_length=8000,
            confidence_threshold=0.8,
            escalation_threshold=0.9,
            enable_caching=True,
            cache_ttl=7200,
            enable_metrics=True,
            enable_tool_selection=True,
            tool_timeout=30.0,
            parallel_tool_execution=True,
            max_concurrent_tools=5,
            memory_optimization=True,
            response_streaming=False,  # Disable streaming in production for stability
            auto_retry=True,
            max_retries=5,
            retry_delay=2.0,
            enable_conversation_cleanup=True,
            conversation_timeout_hours=12,
            enable_performance_monitoring=True
        )
        
        # Testing configuration
        self._configurations["testing"] = AgentConfiguration(
            max_history_length=10,
            max_processing_time=5.0,
            max_response_length=1000,
            confidence_threshold=0.5,
            escalation_threshold=0.6,
            enable_caching=False,
            cache_ttl=300,
            enable_metrics=True,
            enable_tool_selection=True,
            tool_timeout=2.0,
            parallel_tool_execution=False,
            max_concurrent_tools=1,
            memory_optimization=False,
            response_streaming=False,
            auto_retry=False,
            max_retries=1,
            retry_delay=0.5,
            enable_conversation_cleanup=False,
            conversation_timeout_hours=1,
            enable_performance_monitoring=False
        )
        
        self._save_configurations()
        logger.info("Created default agent configurations")
    
    def _save_configurations(self):
        """Save agent configurations to file."""
        try:
            config_file = Path(self.config_path)
            config_file.parent.mkdir(parents=True, exist_ok=True)
            
            data = {}
            for name, config in self._configurations.items():
                data[name] = asdict(config)
            
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"Saved {len(self._configurations)} agent configurations")
            
        except Exception as e:
            logger.error(f"Error saving agent configurations: {e}")
    
    def get_configuration(self, name: str) -> Optional[AgentConfiguration]:
        """Get configuration by name."""
        return self._configurations.get(name)
    
    def set_configuration(self, name: str, configuration: AgentConfiguration):
        """Set or update configuration."""
        self._configurations[name] = configuration
        self._save_configurations()
        logger.info(f"Updated agent configuration: {name}")
    
    def get_all_configurations(self) -> Dict[str, AgentConfiguration]:
        """Get all configurations."""
        return self._configurations.copy()
    
    def get_configuration_for_environment(self, environment: str) -> AgentConfiguration:
        """Get configuration for specific environment."""
        config = self._configurations.get(environment)
        if config:
            return config
        
        # Fallback to development config
        config = self._configurations.get("development")
        if config:
            return config
        
        # Last resort: create new default
        return AgentConfiguration()


class AgentPool:
    """Pool of agent instances for load balancing."""
    
    def __init__(
        self, 
        min_size: int = 1, 
        max_size: int = 10,
        configuration: Optional[AgentConfiguration] = None
    ):
        self.min_size = min_size
        self.max_size = max_size
        self.configuration = configuration or AgentConfiguration()
        self._agents: List[CustomerSupportAgent] = []
        self._available_agents: List[CustomerSupportAgent] = []
        self._active_sessions: Dict[str, str] = {}  # session_id -> agent_id
        self._lock = asyncio.Lock()
        self._shutdown_event = asyncio.Event()
    
    async def initialize(self):
        """Initialize the agent pool."""
        logger.info(f"Initializing agent pool with {self.min_size} to {self.max_size} agents")
        
        # Create minimum number of agents
        for i in range(self.min_size):
            agent = await self._create_agent()
            await agent.start()
            self._agents.append(agent)
            self._available_agents.append(agent)
        
        logger.info(f"Agent pool initialized with {len(self._agents)} agents")
    
    async def _create_agent(self) -> CustomerSupportAgent:
        """Create a new agent instance."""
        agent = CustomerSupportAgent(config=self.configuration)
        return agent
    
    async def get_agent(self) -> Optional[CustomerSupportAgent]:
        """Get an available agent from the pool."""
        async with self._lock:
            if self._available_agents:
                agent = self._available_agents.pop(0)
                logger.debug(f"Allocated agent {agent.agent_id} from pool")
                return agent
            
            # Scale up if possible
            if len(self._agents) < self.max_size:
                agent = await self._create_agent()
                await agent.start()
                self._agents.append(agent)
                logger.info(f"Scaled up agent pool to {len(self._agents)} agents")
                return agent
            
            # No agents available
            logger.warning("No agents available in pool")
            return None
    
    async def return_agent(self, agent: CustomerSupportAgent):
        """Return an agent to the pool."""
        async with self._lock:
            if agent in self._agents and agent not in self._available_agents:
                self._available_agents.append(agent)
                logger.debug(f"Returned agent {agent.agent_id} to pool")
    
    async def shutdown(self):
        """Shutdown the agent pool."""
        logger.info("Shutting down agent pool")
        self._shutdown_event.set()
        
        for agent in self._agents:
            try:
                await agent.stop()
            except Exception as e:
                logger.error(f"Error stopping agent {agent.agent_id}: {e}")
        
        self._agents.clear()
        self._available_agents.clear()
        self._active_sessions.clear()
        
        logger.info("Agent pool shutdown complete")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get pool statistics."""
        return {
            "total_agents": len(self._agents),
            "available_agents": len(self._available_agents),
            "active_sessions": len(self._active_sessions),
            "pool_size": f"{len(self._agents)}/{self.max_size}",
            "utilization": len(self._active_sessions) / max(len(self._agents), 1) * 100
        }


class AgentFactory:
    """Factory for creating and managing agent instances."""
    
    def __init__(self):
        self.registry = AgentRegistry()
        self.config_manager = AgentConfigurationManager()
        self._pools: Dict[str, AgentPool] = {}
        self._shutdown_event = asyncio.Event()
    
    async def create_agent(
        self,
        configuration_name: Optional[str] = None,
        custom_config: Optional[AgentConfiguration] = None,
        metadata: Optional[Dict[str, Any]] = None,
        start_immediately: bool = True
    ) -> CustomerSupportAgent:
        """Create a new agent instance."""
        
        # Get configuration
        if custom_config:
            config = custom_config
        elif configuration_name:
            config = self.config_manager.get_configuration(configuration_name)
            if not config:
                raise ValueError(f"Configuration '{configuration_name}' not found")
        else:
            # Use environment-specific configuration
            env = getattr(settings, 'environment', 'development')
            config = self.config_manager.get_configuration_for_environment(env)
        
        # Create agent
        agent = CustomerSupportAgent(config=config)
        
        # Start agent if requested
        if start_immediately:
            await agent.start()
        
        # Register agent
        self.registry.register_agent(agent, metadata)
        
        logger.info(f"Created agent {agent.agent_id} with configuration: {configuration_name or 'default'}")
        return agent
    
    async def create_agent_pool(
        self,
        pool_name: str,
        min_size: int = 1,
        max_size: int = 10,
        configuration_name: Optional[str] = None,
        custom_config: Optional[AgentConfiguration] = None
    ) -> AgentPool:
        """Create an agent pool."""
        
        # Get configuration
        if custom_config:
            config = custom_config
        elif configuration_name:
            config = self.config_manager.get_configuration(configuration_name)
            if not config:
                raise ValueError(f"Configuration '{configuration_name}' not found")
        else:
            env = getattr(settings, 'environment', 'development')
            config = self.config_manager.get_configuration_for_environment(env)
        
        pool = AgentPool(min_size=min_size, max_size=max_size, configuration=config)
        await pool.initialize()
        
        self._pools[pool_name] = pool
        logger.info(f"Created agent pool '{pool_name}' with {min_size}-{max_size} agents")
        return pool
    
    def get_agent(self, agent_id: str) -> Optional[CustomerSupportAgent]:
        """Get an agent by ID."""
        return self.registry.get_agent(agent_id)
    
    def get_agent_pool(self, pool_name: str) -> Optional[AgentPool]:
        """Get an agent pool by name."""
        return self._pools.get(pool_name)
    
    def get_all_agents(self) -> Dict[str, CustomerSupportAgent]:
        """Get all registered agents."""
        return self.registry.get_all_agents()
    
    def get_all_pools(self) -> Dict[str, AgentPool]:
        """Get all agent pools."""
        return self._pools.copy()
    
    async def get_health_status(self) -> Dict[str, Any]:
        """Get comprehensive health status of all agents and pools."""
        status = {
            "timestamp": datetime.utcnow().isoformat(),
            "agents": {},
            "pools": {},
            "overall_health": "healthy"
        }
        
        issues = []
        
        # Check individual agents
        for agent_id, agent in self.registry.get_all_agents().items():
            try:
                agent_health = await agent.health_check()
                status["agents"][agent_id] = agent_health
                
                if not agent_health["healthy"]:
                    issues.extend(agent_health["issues"])
                    
            except Exception as e:
                status["agents"][agent_id] = {
                    "healthy": False,
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
                issues.append(f"Agent {agent_id} health check failed: {e}")
        
        # Check agent pools
        for pool_name, pool in self._pools.items():
            try:
                pool_stats = pool.get_stats()
                status["pools"][pool_name] = pool_stats
                
                if pool_stats["available_agents"] == 0:
                    issues.append(f"Agent pool '{pool_name}' has no available agents")
                    
            except Exception as e:
                status["pools"][pool_name] = {
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
                issues.append(f"Agent pool '{pool_name}' check failed: {e}")
        
        # Determine overall health
        if issues:
            status["overall_health"] = "degraded" if len(issues) < 3 else "unhealthy"
            status["issues"] = issues
        
        return status
    
    async def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary across all agents."""
        summary = {
            "timestamp": datetime.utcnow().isoformat(),
            "total_agents": len(self.registry.get_all_agents()),
            "total_pools": len(self._pools),
            "agents_by_state": {},
            "aggregated_metrics": {
                "total_conversations": 0,
                "total_messages_processed": 0,
                "total_escalations": 0,
                "average_response_time": 0.0,
                "success_rate": 0.0,
                "escalation_rate": 0.0
            },
            "pool_stats": {}
        }
        
        # Aggregate metrics from all agents
        total_response_time = 0.0
        total_successful = 0
        total_messages = 0
        total_escalations = 0
        
        for agent_id, agent in self.registry.get_all_agents().items():
            metrics = agent.get_metrics()
            
            # Count by state
            state = agent.state.value
            if state not in summary["agents_by_state"]:
                summary["agents_by_state"][state] = 0
            summary["agents_by_state"][state] += 1
            
            # Aggregate metrics
            summary["aggregated_metrics"]["total_conversations"] += metrics.total_conversations
            summary["aggregated_metrics"]["total_messages_processed"] += metrics.total_messages_processed
            summary["aggregated_metrics"]["total_escalations"] += metrics.total_escalations
            
            total_response_time += metrics.average_response_time * metrics.total_messages_processed
            total_successful += metrics.successful_responses
            total_messages += metrics.total_messages_processed
            total_escalations += metrics.total_escalations
        
        # Calculate overall averages
        if total_messages > 0:
            summary["aggregated_metrics"]["average_response_time"] = total_response_time / total_messages
            summary["aggregated_metrics"]["success_rate"] = (total_successful / total_messages) * 100
            summary["aggregated_metrics"]["escalation_rate"] = (total_escalations / total_messages) * 100
        
        # Pool statistics
        for pool_name, pool in self._pools.items():
            summary["pool_stats"][pool_name] = pool.get_stats()
        
        return summary
    
    async def cleanup_idle_agents(self, idle_threshold_hours: int = 2):
        """Cleanup idle agents to save resources."""
        cutoff_time = datetime.utcnow() - timedelta(hours=idle_threshold_hours)
        
        agents_to_remove = []
        for agent_id, agent in self.registry.get_all_agents().items():
            # Check if agent is idle and has no active sessions
            if (agent.state == AgentState.IDLE and 
                len(agent._active_sessions) == 0 and
                agent.metrics.last_activity < cutoff_time):
                agents_to_remove.append(agent_id)
        
        removed_count = 0
        for agent_id in agents_to_remove:
            try:
                agent = self.registry.get_agent(agent_id)
                if agent:
                    await agent.stop()
                    self.registry.unregister_agent(agent_id)
                    removed_count += 1
            except Exception as e:
                logger.error(f"Error cleaning up agent {agent_id}: {e}")
        
        if removed_count > 0:
            logger.info(f"Cleaned up {removed_count} idle agents")
        
        return removed_count
    
    async def shutdown_all(self):
        """Shutdown all agents and pools."""
        logger.info("Shutting down all agents and pools")
        
        # Shutdown pools first
        for pool_name, pool in list(self._pools.items()):
            try:
                await pool.shutdown()
                logger.info(f"Shutdown agent pool: {pool_name}")
            except Exception as e:
                logger.error(f"Error shutting down pool {pool_name}: {e}")
        
        self._pools.clear()
        
        # Shutdown individual agents
        for agent_id, agent in list(self.registry.get_all_agents().items()):
            try:
                await agent.stop()
                self.registry.unregister_agent(agent_id)
                logger.info(f"Shutdown agent: {agent_id}")
            except Exception as e:
                logger.error(f"Error shutting down agent {agent_id}: {e}")
        
        self._shutdown_event.set()
        logger.info("All agents and pools shutdown complete")


# Global agent factory instance
agent_factory = AgentFactory()


class AgentStateManager:
    """Manager for agent state and session lifecycle."""
    
    def __init__(self):
        self._session_mappings: Dict[str, str] = {}  # session_id -> agent_id
        self._session_contexts: Dict[str, AgentContext] = {}
        self._lock = asyncio.Lock()
    
    async def create_session(
        self, 
        session_id: str, 
        user_id: str, 
        agent: CustomerSupportAgent,
        metadata: Optional[Dict[str, Any]] = None
    ) -> AgentContext:
        """Create a new session mapped to an agent."""
        async with self._lock:
            context = await agent.create_session(session_id, user_id, metadata)
            
            self._session_mappings[session_id] = agent.agent_id
            self._session_contexts[session_id] = context
            
            logger.info(f"Created session {session_id} mapped to agent {agent.agent_id}")
            return context
    
    async def get_session_context(self, session_id: str) -> Optional[AgentContext]:
        """Get session context by session ID."""
        return self._session_contexts.get(session_id)
    
    async def get_agent_for_session(self, session_id: str) -> Optional[CustomerSupportAgent]:
        """Get agent for a session."""
        agent_id = self._session_mappings.get(session_id)
        if agent_id:
            return agent_factory.get_agent(agent_id)
        return None
    
    async def end_session(self, session_id: str):
        """End a session and cleanup."""
        async with self._lock:
            agent_id = self._session_mappings.get(session_id)
            if agent_id:
                agent = agent_factory.get_agent(agent_id)
                if agent:
                    await agent.end_session(session_id)
            
            self._session_mappings.pop(session_id, None)
            self._session_contexts.pop(session_id, None)
            
            logger.info(f"Ended session {session_id}")
    
    async def cleanup_expired_sessions(self, expiry_hours: int = 24):
        """Cleanup expired sessions."""
        cutoff_time = datetime.utcnow() - timedelta(hours=expiry_hours)
        
        expired_sessions = []
        for session_id, context in self._session_contexts.items():
            if context.last_activity < cutoff_time:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            await self.end_session(session_id)
        
        return len(expired_sessions)
    
    def get_active_sessions_count(self) -> int:
        """Get count of active sessions."""
        return len(self._session_contexts)
    
    def get_session_distribution(self) -> Dict[str, int]:
        """Get distribution of sessions across agents."""
        distribution = {}
        for session_id, agent_id in self._session_mappings.items():
            if agent_id not in distribution:
                distribution[agent_id] = 0
            distribution[agent_id] += 1
        return distribution


# Global session state manager
agent_state_manager = AgentStateManager()