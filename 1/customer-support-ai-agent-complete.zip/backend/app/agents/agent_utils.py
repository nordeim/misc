"""
Agent Utilities and Monitoring System.

This module provides utility functions, monitoring capabilities, and operational
tools for the Customer Support Agent system.
"""

import asyncio
import logging
import time
import psutil
import weakref
from typing import Dict, List, Optional, Any, Callable, Union, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import json
import traceback
from pathlib import Path
import threading
from contextlib import contextmanager
import statistics

from .chat_agent import CustomerSupportAgent, AgentContext, AgentMetrics, AgentState
from .agent_factory import agent_factory, AgentPool, AgentStateManager

logger = logging.getLogger(__name__)


class AlertSeverity(str, Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AgentAlert:
    """Agent alert notification."""
    id: str
    timestamp: datetime
    severity: AlertSeverity
    title: str
    description: str
    agent_id: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = None
    resolved: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "metadata": self.metadata or {},
            "resolved": self.resolved
        }


class AgentMonitor:
    """Real-time monitoring system for agents."""
    
    def __init__(self, check_interval: int = 30):
        self.check_interval = check_interval
        self._alerts: List[AgentAlert] = []
        self._alert_callbacks: List[Callable[[AgentAlert], None]] = []
        self._thresholds = {
            "response_time_warning": 5.0,
            "response_time_critical": 10.0,
            "memory_usage_warning": 80.0,
            "memory_usage_critical": 95.0,
            "active_sessions_warning": 100,
            "active_sessions_critical": 200,
            "error_rate_warning": 10.0,
            "error_rate_critical": 25.0
        }
        self._monitoring_active = False
        self._monitor_task: Optional[asyncio.Task] = None
    
    def set_threshold(self, metric: str, value: float):
        """Set monitoring threshold for a metric."""
        if metric in self._thresholds:
            self._thresholds[metric] = value
            logger.info(f"Updated threshold for {metric}: {value}")
    
    def add_alert_callback(self, callback: Callable[[AgentAlert], None]):
        """Add callback for alert notifications."""
        self._alert_callbacks.append(callback)
    
    async def start_monitoring(self):
        """Start monitoring agents."""
        if self._monitoring_active:
            return
        
        self._monitoring_active = True
        self._monitor_task = asyncio.create_task(self._monitoring_loop())
        logger.info("Started agent monitoring")
    
    async def stop_monitoring(self):
        """Stop monitoring agents."""
        self._monitoring_active = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("Stopped agent monitoring")
    
    async def _monitoring_loop(self):
        """Main monitoring loop."""
        while self._monitoring_active:
            try:
                await self._check_agent_health()
                await self._check_performance_metrics()
                await self._check_system_resources()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _check_agent_health(self):
        """Check health of all registered agents."""
        agents = agent_factory.get_all_agents()
        
        for agent_id, agent in agents.items():
            try:
                health = await agent.health_check()
                
                if not health["healthy"]:
                    alert = AgentAlert(
                        id=f"health_{agent_id}_{int(time.time())}",
                        timestamp=datetime.utcnow(),
                        severity=AlertSeverity.ERROR,
                        title=f"Agent Health Issue: {agent_id}",
                        description=f"Agent health check failed: {', '.join(health.get('issues', []))}",
                        agent_id=agent_id,
                        metadata=health
                    )
                    self._trigger_alert(alert)
                
                # Check for stale agents
                metrics = agent.get_metrics()
                if hasattr(metrics, 'last_activity'):
                    last_activity = datetime.fromisoformat(metrics.last_activity)
                    if datetime.utcnow() - last_activity > timedelta(hours=1):
                        alert = AgentAlert(
                            id=f"stale_{agent_id}_{int(time.time())}",
                            timestamp=datetime.utcnow(),
                            severity=AlertSeverity.WARNING,
                            title=f"Stale Agent: {agent_id}",
                            description=f"Agent has been inactive for over 1 hour",
                            agent_id=agent_id
                        )
                        self._trigger_alert(alert)
                
            except Exception as e:
                logger.error(f"Error checking health of agent {agent_id}: {e}")
    
    async def _check_performance_metrics(self):
        """Check performance metrics against thresholds."""
        try:
            metrics_summary = await agent_factory.get_metrics_summary()
            
            # Check response time
            avg_response_time = metrics_summary["aggregated_metrics"]["average_response_time"]
            if avg_response_time > self._thresholds["response_time_critical"]:
                severity = AlertSeverity.CRITICAL
            elif avg_response_time > self._thresholds["response_time_warning"]:
                severity = AlertSeverity.WARNING
            else:
                severity = None
            
            if severity:
                alert = AgentAlert(
                    id=f"response_time_{int(time.time())}",
                    timestamp=datetime.utcnow(),
                    severity=severity,
                    title="High Response Time",
                    description=f"Average response time: {avg_response_time:.2f}s",
                    metadata={"average_response_time": avg_response_time}
                )
                self._trigger_alert(alert)
            
            # Check error rate
            error_rate = 100 - metrics_summary["aggregated_metrics"]["success_rate"]
            if error_rate > self._thresholds["error_rate_critical"]:
                severity = AlertSeverity.CRITICAL
            elif error_rate > self._thresholds["error_rate_warning"]:
                severity = AlertSeverity.WARNING
            else:
                severity = None
            
            if severity:
                alert = AgentAlert(
                    id=f"error_rate_{int(time.time())}",
                    timestamp=datetime.utcnow(),
                    severity=severity,
                    title="High Error Rate",
                    description=f"Error rate: {error_rate:.1f}%",
                    metadata={"error_rate": error_rate}
                )
                self._trigger_alert(alert)
            
            # Check active sessions
            total_sessions = metrics_summary["aggregated_metrics"].get("total_active_sessions", 0)
            if total_sessions > self._thresholds["active_sessions_critical"]:
                severity = AlertSeverity.CRITICAL
            elif total_sessions > self._thresholds["active_sessions_warning"]:
                severity = AlertSeverity.WARNING
            else:
                severity = None
            
            if severity:
                alert = AgentAlert(
                    id=f"active_sessions_{int(time.time())}",
                    timestamp=datetime.utcnow(),
                    severity=severity,
                    title="High Active Sessions",
                    description=f"Active sessions: {total_sessions}",
                    metadata={"active_sessions": total_sessions}
                )
                self._trigger_alert(alert)
                
        except Exception as e:
            logger.error(f"Error checking performance metrics: {e}")
    
    async def _check_system_resources(self):
        """Check system resource usage."""
        try:
            # Check memory usage
            memory_percent = psutil.virtual_memory().percent
            if memory_percent > self._thresholds["memory_usage_critical"]:
                severity = AlertSeverity.CRITICAL
            elif memory_percent > self._thresholds["memory_usage_warning"]:
                severity = AlertSeverity.WARNING
            else:
                severity = None
            
            if severity:
                alert = AgentAlert(
                    id=f"memory_usage_{int(time.time())}",
                    timestamp=datetime.utcnow(),
                    severity=severity,
                    title="High Memory Usage",
                    description=f"System memory usage: {memory_percent:.1f}%",
                    metadata={"memory_usage_percent": memory_percent}
                )
                self._trigger_alert(alert)
            
            # Check CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            if cpu_percent > 90:
                alert = AgentAlert(
                    id=f"cpu_usage_{int(time.time())}",
                    timestamp=datetime.utcnow(),
                    severity=AlertSeverity.WARNING,
                    title="High CPU Usage",
                    description=f"System CPU usage: {cpu_percent:.1f}%",
                    metadata={"cpu_usage_percent": cpu_percent}
                )
                self._trigger_alert(alert)
                
        except Exception as e:
            logger.error(f"Error checking system resources: {e}")
    
    def _trigger_alert(self, alert: AgentAlert):
        """Trigger an alert notification."""
        self._alerts.append(alert)
        
        # Call alert callbacks
        for callback in self._alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Error in alert callback: {e}")
        
        logger.warning(f"Alert triggered: {alert.title} - {alert.description}")
    
    def get_recent_alerts(self, hours: int = 24) -> List[AgentAlert]:
        """Get recent alerts."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        return [alert for alert in self._alerts if alert.timestamp > cutoff_time]
    
    def get_alerts_by_severity(self, severity: AlertSeverity) -> List[AgentAlert]:
        """Get alerts by severity."""
        return [alert for alert in self._alerts if alert.severity == severity]
    
    def resolve_alert(self, alert_id: str) -> bool:
        """Resolve an alert."""
        for alert in self._alerts:
            if alert.id == alert_id:
                alert.resolved = True
                logger.info(f"Resolved alert: {alert_id}")
                return True
        return False
    
    def get_monitoring_stats(self) -> Dict[str, Any]:
        """Get monitoring statistics."""
        recent_alerts = self.get_recent_alerts()
        
        return {
            "monitoring_active": self._monitoring_active,
            "check_interval": self.check_interval,
            "total_alerts": len(self._alerts),
            "recent_alerts": len(recent_alerts),
            "alerts_by_severity": {
                severity.value: len([a for a in recent_alerts if a.severity == severity])
                for severity in AlertSeverity
            },
            "thresholds": self._thresholds.copy()
        }


class AgentPerformanceTracker:
    """Performance tracking and analytics for agents."""
    
    def __init__(self):
        self._performance_data: Dict[str, List[Dict[str, Any]]] = {}
        self._session_performance: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
    
    async def record_performance(
        self, 
        agent_id: str, 
        session_id: str, 
        metrics: Dict[str, Any]
    ):
        """Record performance metrics for an agent/session."""
        async with self._lock:
            timestamp = datetime.utcnow().isoformat()
            
            # Record agent performance
            if agent_id not in self._performance_data:
                self._performance_data[agent_id] = []
            
            self._performance_data[agent_id].append({
                "timestamp": timestamp,
                "session_id": session_id,
                "metrics": metrics
            })
            
            # Keep only last 1000 records per agent
            if len(self._performance_data[agent_id]) > 1000:
                self._performance_data[agent_id] = self._performance_data[agent_id][-1000:]
            
            # Record session performance
            if session_id not in self._session_performance:
                self._session_performance[session_id] = {
                    "agent_id": agent_id,
                    "start_time": timestamp,
                    "metrics_history": []
                }
            
            self._session_performance[session_id]["metrics_history"].append({
                "timestamp": timestamp,
                "metrics": metrics
            })
    
    async def get_agent_performance(
        self, 
        agent_id: str, 
        hours: int = 24
    ) -> Dict[str, Any]:
        """Get performance analytics for an agent."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        data = [
            record for record in self._performance_data.get(agent_id, [])
            if datetime.fromisoformat(record["timestamp"]) > cutoff_time
        ]
        
        if not data:
            return {"message": "No performance data available for the specified time period"}
        
        # Calculate statistics
        response_times = [r["metrics"].get("processing_time", 0) for r in data]
        success_rates = [r["metrics"].get("success", False) for r in data]
        
        return {
            "agent_id": agent_id,
            "time_period_hours": hours,
            "total_operations": len(data),
            "average_response_time": statistics.mean(response_times) if response_times else 0,
            "median_response_time": statistics.median(response_times) if response_times else 0,
            "min_response_time": min(response_times) if response_times else 0,
            "max_response_time": max(response_times) if response_times else 0,
            "success_rate": (sum(success_rates) / len(success_rates)) * 100 if success_rates else 0,
            "recent_operations": data[-10:] if len(data) > 10 else data
        }
    
    async def get_session_performance(self, session_id: str) -> Dict[str, Any]:
        """Get performance analytics for a session."""
        session_data = self._session_performance.get(session_id)
        if not session_data:
            return {"error": "Session not found"}
        
        metrics_history = session_data["metrics_history"]
        if not metrics_history:
            return {"message": "No metrics recorded for this session"}
        
        # Calculate session statistics
        processing_times = [m["metrics"].get("processing_time", 0) for m in metrics_history]
        
        return {
            "session_id": session_id,
            "agent_id": session_data["agent_id"],
            "start_time": session_data["start_time"],
            "duration_minutes": (
                datetime.utcnow() - datetime.fromisoformat(session_data["start_time"])
            ).total_seconds() / 60,
            "total_messages": len(metrics_history),
            "average_response_time": statistics.mean(processing_times) if processing_times else 0,
            "performance_trend": self._calculate_performance_trend(metrics_history)
        }
    
    def _calculate_performance_trend(self, metrics_history: List[Dict[str, Any]]) -> str:
        """Calculate performance trend direction."""
        if len(metrics_history) < 2:
            return "stable"
        
        first_half = metrics_history[:len(metrics_history)//2]
        second_half = metrics_history[len(metrics_history)//2:]
        
        first_avg = statistics.mean([m["metrics"].get("processing_time", 0) for m in first_half])
        second_avg = statistics.mean([m["metrics"].get("processing_time", 0) for m in second_half])
        
        if second_avg > first_avg * 1.1:
            return "degrading"
        elif second_avg < first_avg * 0.9:
            return "improving"
        else:
            return "stable"
    
    async def get_system_performance(self, hours: int = 24) -> Dict[str, Any]:
        """Get system-wide performance analytics."""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        all_data = []
        for agent_id, records in self._performance_data.items():
            agent_recent_data = [
                record for record in records
                if datetime.fromisoformat(record["timestamp"]) > cutoff_time
            ]
            all_data.extend(agent_recent_data)
        
        if not all_data:
            return {"message": "No system performance data available"}
        
        # Calculate system statistics
        response_times = [r["metrics"].get("processing_time", 0) for r in all_data]
        success_rates = [r["metrics"].get("success", False) for r in all_data]
        
        # Agent distribution
        agent_distribution = {}
        for record in all_data:
            agent_id = record["agent_id"]
            if agent_id not in agent_distribution:
                agent_distribution[agent_id] = 0
            agent_distribution[agent_id] += 1
        
        return {
            "time_period_hours": hours,
            "total_operations": len(all_data),
            "active_agents": len(agent_distribution),
            "average_response_time": statistics.mean(response_times) if response_times else 0,
            "median_response_time": statistics.median(response_times) if response_times else 0,
            "p95_response_time": statistics.quantiles(response_times, n=20)[18] if len(response_times) > 20 else max(response_times) if response_times else 0,
            "overall_success_rate": (sum(success_rates) / len(success_rates)) * 100 if success_rates else 0,
            "agent_distribution": agent_distribution,
            "peak_hour": self._find_peak_hour(all_data)
        }
    
    def _find_peak_hour(self, data: List[Dict[str, Any]]) -> Optional[str]:
        """Find the hour with highest activity."""
        if not data:
            return None
        
        hour_counts = {}
        for record in data:
            timestamp = datetime.fromisoformat(record["timestamp"])
            hour_key = timestamp.strftime("%Y-%m-%d %H:00")
            hour_counts[hour_key] = hour_counts.get(hour_key, 0) + 1
        
        return max(hour_counts.items(), key=lambda x: x[1])[0] if hour_counts else None


class AgentResourceManager:
    """Resource management for agents including cleanup and optimization."""
    
    def __init__(self):
        self._resource_limits = {
            "max_memory_mb": 1024,
            "max_active_sessions": 500,
            "max_concurrent_operations": 100,
            "cleanup_interval_minutes": 60
        }
        self._cleanup_task: Optional[asyncio.Task] = None
        self._cleanup_running = False
    
    def set_resource_limit(self, resource: str, value: Union[int, float]):
        """Set resource limits."""
        if resource in self._resource_limits:
            self._resource_limits[resource] = value
            logger.info(f"Updated resource limit for {resource}: {value}")
    
    async def start_resource_management(self):
        """Start background resource management."""
        if self._cleanup_running:
            return
        
        self._cleanup_running = True
        self._cleanup_task = asyncio.create_task(self._resource_cleanup_loop())
        logger.info("Started resource management")
    
    async def stop_resource_management(self):
        """Stop resource management."""
        self._cleanup_running = False
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        logger.info("Stopped resource management")
    
    async def _resource_cleanup_loop(self):
        """Resource cleanup loop."""
        while self._cleanup_running:
            try:
                await self._cleanup_expired_sessions()
                await self._cleanup_idle_agents()
                await self._check_memory_usage()
                await self._balance_agent_load()
                
                await asyncio.sleep(self._resource_limits["cleanup_interval_minutes"] * 60)
            except Exception as e:
                logger.error(f"Error in resource cleanup loop: {e}")
                await asyncio.sleep(60)
    
    async def _cleanup_expired_sessions(self):
        """Cleanup expired sessions."""
        try:
            from .agent_factory import agent_state_manager
            cleaned_count = await agent_state_manager.cleanup_expired_sessions()
            
            if cleaned_count > 0:
                logger.info(f"Cleaned up {cleaned_count} expired sessions")
                
        except Exception as e:
            logger.error(f"Error cleaning up expired sessions: {e}")
    
    async def _cleanup_idle_agents(self):
        """Cleanup idle agents."""
        try:
            cleaned_count = await agent_factory.cleanup_idle_agents(idle_threshold_hours=2)
            
            if cleaned_count > 0:
                logger.info(f"Cleaned up {cleaned_count} idle agents")
                
        except Exception as e:
            logger.error(f"Error cleaning up idle agents: {e}")
    
    async def _check_memory_usage(self):
        """Check and manage memory usage."""
        try:
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            
            if memory_mb > self._resource_limits["max_memory_mb"]:
                logger.warning(f"High memory usage detected: {memory_mb:.1f}MB")
                
                # Trigger garbage collection
                import gc
                gc.collect()
                
                # Log memory after cleanup
                new_memory_mb = process.memory_info().rss / 1024 / 1024
                logger.info(f"Memory usage after cleanup: {new_memory_mb:.1f}MB")
                
        except Exception as e:
            logger.error(f"Error checking memory usage: {e}")
    
    async def _balance_agent_load(self):
        """Balance load across agent pools."""
        try:
            for pool_name, pool in agent_factory.get_all_pools().items():
                stats = pool.get_stats()
                
                # If pool is heavily loaded, consider scaling up
                if stats["utilization"] > 80 and len(pool._agents) < pool.max_size:
                    logger.info(f"Pool {pool_name} utilization high ({stats['utilization']:.1f}%), may need scaling")
                
                # If pool is underutilized, consider scaling down
                elif stats["utilization"] < 20 and len(pool._agents) > pool.min_size:
                    logger.info(f"Pool {pool_name} utilization low ({stats['utilization']:.1f}%), may need scaling down")
                    
        except Exception as e:
            logger.error(f"Error balancing agent load: {e}")
    
    def get_resource_stats(self) -> Dict[str, Any]:
        """Get current resource usage statistics."""
        try:
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            
            return {
                "memory_usage_mb": memory_mb,
                "memory_limit_mb": self._resource_limits["max_memory_mb"],
                "memory_utilization_percent": (memory_mb / self._resource_limits["max_memory_mb"]) * 100,
                "cpu_percent": psutil.cpu_percent(),
                "active_agents": len(agent_factory.get_all_agents()),
                "active_pools": len(agent_factory.get_all_pools()),
                "resource_limits": self._resource_limits.copy()
            }
        except Exception as e:
            logger.error(f"Error getting resource stats: {e}")
            return {}


class AgentDiagnosticTool:
    """Diagnostic tools for agent troubleshooting."""
    
    async def run_full_diagnostic(self) -> Dict[str, Any]:
        """Run comprehensive diagnostic on the agent system."""
        diagnostic = {
            "timestamp": datetime.utcnow().isoformat(),
            "system_info": await self._get_system_info(),
            "agent_health": await self._diagnose_agents(),
            "pool_health": await self._diagnose_pools(),
            "resource_usage": await self._diagnose_resources(),
            "performance_issues": await self._diagnose_performance(),
            "recommendations": []
        }
        
        # Generate recommendations based on diagnostic results
        diagnostic["recommendations"] = self._generate_recommendations(diagnostic)
        
        return diagnostic
    
    async def _get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        try:
            return {
                "cpu_count": psutil.cpu_count(),
                "cpu_usage": psutil.cpu_percent(),
                "memory_total_gb": psutil.virtual_memory().total / 1024 / 1024 / 1024,
                "memory_usage_percent": psutil.virtual_memory().percent,
                "disk_usage_percent": psutil.disk_usage('/').percent,
                "python_version": "3.9+",  # Would get actual version
                "platform": "linux"  # Would get actual platform
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _diagnose_agents(self) -> Dict[str, Any]:
        """Diagnose agent health."""
        agents = agent_factory.get_all_agents()
        agent_diagnostics = {}
        
        for agent_id, agent in agents.items():
            try:
                health = await agent.health_check()
                agent_diagnostics[agent_id] = {
                    "state": agent.state.value,
                    "healthy": health["healthy"],
                    "active_sessions": len(agent._active_sessions),
                    "tools_available": len(agent._tool_registry),
                    "metrics": agent.get_metrics().__dict__
                }
            except Exception as e:
                agent_diagnostics[agent_id] = {"error": str(e)}
        
        return {
            "total_agents": len(agents),
            "healthy_agents": len([a for a in agent_diagnostics.values() if a.get("healthy", False)]),
            "agent_details": agent_diagnostics
        }
    
    async def _diagnose_pools(self) -> Dict[str, Any]:
        """ diagnose agent pools."""
        pools = agent_factory.get_all_pools()
        pool_diagnostics = {}
        
        for pool_name, pool in pools.items():
            try:
                stats = pool.get_stats()
                pool_diagnostics[pool_name] = {
                    "stats": stats,
                    "healthy": stats["available_agents"] > 0
                }
            except Exception as e:
                pool_diagnostics[pool_name] = {"error": str(e)}
        
        return {
            "total_pools": len(pools),
            "healthy_pools": len([p for p in pool_diagnostics.values() if p.get("healthy", False)]),
            "pool_details": pool_diagnostics
        }
    
    async def _diagnose_resources(self) -> Dict[str, Any]:
        """Diagnose resource usage."""
        return {
            "memory_usage_percent": psutil.virtual_memory().percent,
            "cpu_usage_percent": psutil.cpu_percent(),
            "disk_usage_percent": psutil.disk_usage('/').percent,
            "active_threads": threading.active_count()
        }
    
    async def _diagnose_performance(self) -> List[Dict[str, Any]]:
        """Diagnose performance issues."""
        issues = []
        
        try:
            metrics = await agent_factory.get_metrics_summary()
            
            if metrics["aggregated_metrics"]["average_response_time"] > 5.0:
                issues.append({
                    "type": "high_response_time",
                    "severity": "warning",
                    "description": f"Average response time is {metrics['aggregated_metrics']['average_response_time']:.2f}s"
                })
            
            if metrics["aggregated_metrics"]["success_rate"] < 90:
                issues.append({
                    "type": "low_success_rate",
                    "severity": "warning",
                    "description": f"Success rate is {metrics['aggregated_metrics']['success_rate']:.1f}%"
                })
                
        except Exception as e:
            issues.append({
                "type": "diagnostic_error",
                "severity": "error",
                "description": f"Failed to diagnose performance: {e}"
            })
        
        return issues
    
    def _generate_recommendations(self, diagnostic: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on diagnostic results."""
        recommendations = []
        
        # System resource recommendations
        system_info = diagnostic.get("system_info", {})
        if system_info.get("memory_usage_percent", 0) > 80:
            recommendations.append("Consider increasing system memory or optimizing agent memory usage")
        
        if system_info.get("cpu_usage_percent", 0) > 80:
            recommendations.append("High CPU usage detected - consider scaling out agents or optimizing workloads")
        
        # Agent health recommendations
        agent_health = diagnostic.get("agent_health", {})
        if agent_health.get("healthy_agents", 0) < agent_health.get("total_agents", 0):
            recommendations.append("Some agents are unhealthy - investigate and restart failed agents")
        
        # Performance recommendations
        performance_issues = diagnostic.get("performance_issues", [])
        for issue in performance_issues:
            if issue["type"] == "high_response_time":
                recommendations.append("High response time - consider optimizing RAG queries or increasing agent resources")
            elif issue["type"] == "low_success_rate":
                recommendations.append("Low success rate - review agent configuration and error handling")
        
        if not recommendations:
            recommendations.append("System appears to be operating normally")
        
        return recommendations


# Global monitoring instances
agent_monitor = AgentMonitor()
performance_tracker = AgentPerformanceTracker()
resource_manager = AgentResourceManager()
diagnostic_tool = AgentDiagnosticTool()


@contextmanager
def performance_timer(operation_name: str):
    """Context manager for timing operations."""
    start_time = time.time()
    try:
        yield
    finally:
        end_time = time.time()
        duration = end_time - start_time
        logger.debug(f"Operation '{operation_name}' took {duration:.3f} seconds")


async def initialize_agent_monitoring():
    """Initialize agent monitoring and resource management."""
    try:
        await agent_monitor.start_monitoring()
        await resource_manager.start_resource_management()
        logger.info("Agent monitoring and resource management initialized")
    except Exception as e:
        logger.error(f"Failed to initialize agent monitoring: {e}")


async def shutdown_agent_monitoring():
    """Shutdown agent monitoring and resource management."""
    try:
        await agent_monitor.stop_monitoring()
        await resource_manager.stop_resource_management()
        logger.info("Agent monitoring and resource management shutdown")
    except Exception as e:
        logger.error(f"Failed to shutdown agent monitoring: {e}")