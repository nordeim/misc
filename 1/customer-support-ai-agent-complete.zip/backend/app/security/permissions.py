"""
Role-Based Access Control (RBAC) System.

This module provides comprehensive authorization functionality including:
- Permission definitions and management
- Role-based access control
- User permission checking
- Authorization decorators and guards
- Resource-based permissions
"""

from enum import Enum, Flag, auto
from typing import List, Dict, Set, Optional, Callable, Any, Union
from functools import wraps
import logging

logger = logging.getLogger(__name__)


class Permission(Flag):
    """Permission flags for fine-grained access control."""
    
    # Basic permissions
    READ = auto()
    WRITE = auto()
    DELETE = auto()
    EXECUTE = auto()
    
    # Admin permissions
    ADMIN = auto()
    MANAGE_USERS = auto()
    MANAGE_ROLES = auto()
    MANAGE_PERMISSIONS = auto()
    
    # Content permissions
    UPLOAD_FILES = auto()
    DOWNLOAD_FILES = auto()
    MODERATE_CONTENT = auto()
    
    # System permissions
    VIEW_LOGS = auto()
    MANAGE_CONFIG = auto()
    MANAGE_BACKUP = auto()
    
    # Chat permissions
    START_CHAT = auto()
    MANAGE_CHAT = auto()
    VIEW_CHAT_HISTORY = auto()
    DELETE_CHAT = auto()
    
    # User permissions
    VIEW_PROFILE = auto()
    EDIT_PROFILE = auto()
    DELETE_ACCOUNT = auto()
    MANAGE_SESSIONS = auto()
    
    # Development permissions
    DEBUG_MODE = auto()
    PROFILING = auto()
    API_TESTING = auto()
    
    # Security permissions
    AUDIT_ACCESS = auto()
    SECURITY_SETTINGS = auto()
    MANAGE_TOKENS = auto()
    
    # System maintenance
    SYSTEM_RESTART = auto()
    DATABASE_ACCESS = auto()
    CACHE_MANAGEMENT = auto()
    
    @classmethod
    def from_list(cls, permissions: List[str]) -> Set['Permission']:
        """Convert list of permission names to Permission set."""
        result = set()
        for perm_name in permissions:
            try:
                perm = cls[perm_name.upper()]
                result.add(perm)
            except KeyError:
                logger.warning(f"Unknown permission: {perm_name}")
        return result
    
    @classmethod
    def to_list(cls, permissions: Set['Permission']) -> List[str]:
        """Convert Permission set to list of names."""
        return [perm.name for perm in permissions]


class Role(Enum):
    """User roles with associated permissions."""
    
    GUEST = "guest"
    USER = "user"
    PREMIUM_USER = "premium_user"
    MODERATOR = "moderator"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"
    SYSTEM = "system"
    
    def __init__(self, name: str):
        self.name = name
        self._permissions = self._get_role_permissions()
    
    def _get_role_permissions(self) -> Set[Permission]:
        """Get permissions for this role."""
        permissions_map = {
            self.GUEST: {
                Permission.READ,
                Permission.START_CHAT,
                Permission.VIEW_PROFILE,
            },
            self.USER: {
                Permission.READ,
                Permission.WRITE,
                Permission.START_CHAT,
                Permission.MANAGE_CHAT,
                Permission.VIEW_CHAT_HISTORY,
                Permission.VIEW_PROFILE,
                Permission.EDIT_PROFILE,
                Permission.UPLOAD_FILES,
                Permission.DOWNLOAD_FILES,
            },
            self.PREMIUM_USER: {
                Permission.READ,
                Permission.WRITE,
                Permission.DELETE,
                Permission.START_CHAT,
                Permission.MANAGE_CHAT,
                Permission.VIEW_CHAT_HISTORY,
                Permission.DELETE_CHAT,
                Permission.VIEW_PROFILE,
                Permission.EDIT_PROFILE,
                Permission.UPLOAD_FILES,
                Permission.DOWNLOAD_FILES,
                Permission.MODERATE_CONTENT,
            },
            self.MODERATOR: {
                Permission.READ,
                Permission.WRITE,
                Permission.DELETE,
                Permission.MODERATE_CONTENT,
                Permission.MANAGE_USERS,
                Permission.VIEW_LOGS,
                Permission.START_CHAT,
                Permission.MANAGE_CHAT,
                Permission.VIEW_CHAT_HISTORY,
                Permission.VIEW_PROFILE,
                Permission.EDIT_PROFILE,
                Permission.UPLOAD_FILES,
                Permission.DOWNLOAD_FILES,
            },
            self.ADMIN: {
                Permission.ADMIN,
                Permission.MANAGE_USERS,
                Permission.MANAGE_ROLES,
                Permission.MANAGE_PERMISSIONS,
                Permission.VIEW_LOGS,
                Permission.MANAGE_CONFIG,
                Permission.AUDIT_ACCESS,
                Permission.SECURITY_SETTINGS,
                Permission.READ,
                Permission.WRITE,
                Permission.DELETE,
                Permission.EXECUTE,
                Permission.START_CHAT,
                Permission.MANAGE_CHAT,
                Permission.VIEW_CHAT_HISTORY,
                Permission.MODERATE_CONTENT,
                Permission.VIEW_PROFILE,
                Permission.EDIT_PROFILE,
                Permission.UPLOAD_FILES,
                Permission.DOWNLOAD_FILES,
                Permission.DELETE_ACCOUNT,
                Permission.MANAGE_SESSIONS,
            },
            self.SUPER_ADMIN: {
                # All permissions
                Permission.READ,
                Permission.WRITE,
                Permission.DELETE,
                Permission.EXECUTE,
                Permission.ADMIN,
                Permission.MANAGE_USERS,
                Permission.MANAGE_ROLES,
                Permission.MANAGE_PERMISSIONS,
                Permission.UPLOAD_FILES,
                Permission.DOWNLOAD_FILES,
                Permission.MODERATE_CONTENT,
                Permission.VIEW_LOGS,
                Permission.MANAGE_CONFIG,
                Permission.MANAGE_BACKUP,
                Permission.START_CHAT,
                Permission.MANAGE_CHAT,
                Permission.VIEW_CHAT_HISTORY,
                Permission.DELETE_CHAT,
                Permission.VIEW_PROFILE,
                Permission.EDIT_PROFILE,
                Permission.DELETE_ACCOUNT,
                Permission.MANAGE_SESSIONS,
                Permission.DEBUG_MODE,
                Permission.PROFILING,
                Permission.API_TESTING,
                Permission.AUDIT_ACCESS,
                Permission.SECURITY_SETTINGS,
                Permission.MANAGE_TOKENS,
                Permission.SYSTEM_RESTART,
                Permission.DATABASE_ACCESS,
                Permission.CACHE_MANAGEMENT,
            },
            self.SYSTEM: {
                # System-level permissions
                Permission.ADMIN,
                Permission.MANAGE_USERS,
                Permission.MANAGE_ROLES,
                Permission.MANAGE_PERMISSIONS,
                Permission.SYSTEM_RESTART,
                Permission.DATABASE_ACCESS,
                Permission.CACHE_MANAGEMENT,
            }
        }
        return permissions_map.get(self, set())
    
    @property
    def permissions(self) -> Set[Permission]:
        """Get all permissions for this role."""
        return self._permissions
    
    def has_permission(self, permission: Permission) -> bool:
        """Check if role has specific permission."""
        return permission in self._permissions
    
    def has_any_permission(self, permissions: Set[Permission]) -> bool:
        """Check if role has any of the specified permissions."""
        return bool(self._permissions & permissions)
    
    def has_all_permissions(self, permissions: Set[Permission]) -> bool:
        """Check if role has all specified permissions."""
        return permissions.issubset(self._permissions)


class UserPermissions:
    """User permission manager."""
    
    def __init__(
        self,
        permissions: Union[List[str], Set[Permission], None] = None,
        role: Union[Role, str, None] = None
    ):
        self._role = self._normalize_role(role) if role else None
        self._custom_permissions = set()
        
        if permissions:
            if isinstance(permissions, list):
                # Convert string list to Permission set
                self._custom_permissions = Permission.from_list(permissions)
            elif isinstance(permissions, set) and all(isinstance(p, Permission) for p in permissions):
                # Already a Permission set
                self._custom_permissions = permissions
            else:
                raise ValueError("Permissions must be a list of strings or a set of Permission enums")
    
    @staticmethod
    def _normalize_role(role: Union[Role, str]) -> Role:
        """Normalize role input to Role enum."""
        if isinstance(role, Role):
            return role
        elif isinstance(role, str):
            return Role(role)
        else:
            raise ValueError("Role must be Role enum or string")
    
    @property
    def role(self) -> Optional[Role]:
        """Get user role."""
        return self._role
    
    @role.setter
    def role(self, role: Union[Role, str]):
        """Set user role."""
        self._role = self._normalize_role(role)
    
    def has_permission(self, permission: Union[Permission, str]) -> bool:
        """Check if user has specific permission."""
        # Check role permissions first
        if self._role and self._role.has_permission(permission):
            return True
        
        # Check custom permissions
        if isinstance(permission, str):
            try:
                permission = Permission[permission.upper()]
            except KeyError:
                logger.warning(f"Unknown permission: {permission}")
                return False
        
        return permission in self._custom_permissions
    
    def has_any_permission(self, permissions: Set[Permission]) -> bool:
        """Check if user has any of the specified permissions."""
        # Check role permissions
        if self._role and self._role.has_any_permission(permissions):
            return True
        
        # Check custom permissions
        return bool(self._custom_permissions & permissions)
    
    def has_all_permissions(self, permissions: Set[Permission]) -> bool:
        """Check if user has all specified permissions."""
        # Check role permissions
        if self._role and self._role.has_all_permissions(permissions):
            return True
        
        # Check custom permissions (user needs all permissions)
        return permissions.issubset(self._custom_permissions)
    
    def add_permission(self, permission: Union[Permission, str]):
        """Add a custom permission to user."""
        if isinstance(permission, str):
            try:
                permission = Permission[permission.upper()]
            except KeyError:
                logger.warning(f"Cannot add unknown permission: {permission}")
                return
        
        self._custom_permissions.add(permission)
    
    def remove_permission(self, permission: Union[Permission, str]):
        """Remove a custom permission from user."""
        if isinstance(permission, str):
            try:
                permission = Permission[permission.upper()]
            except KeyError:
                logger.warning(f"Cannot remove unknown permission: {permission}")
                return
        
        self._custom_permissions.discard(permission)
    
    def clear_custom_permissions(self):
        """Clear all custom permissions (keeps role permissions)."""
        self._custom_permissions.clear()
    
    @property
    def permissions(self) -> Set[Permission]:
        """Get all effective permissions (role + custom)."""
        permissions = set(self._custom_permissions)
        if self._role:
            permissions.update(self._role.permissions)
        return permissions
    
    @property
    def permissions_list(self) -> List[str]:
        """Get list of all effective permission names."""
        return [perm.name for perm in self.permissions]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "role": self._role.name if self._role else None,
            "permissions": self.permissions_list,
            "custom_permissions": [p.name for p in self._custom_permissions],
        }


# Permission checking functions

def check_permission(user_permissions: UserPermissions, permission: Permission) -> bool:
    """Check if user has specific permission."""
    return user_permissions.has_permission(permission)


def require_permission(permission: Permission):
    """Decorator to require specific permission for endpoint."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # This decorator needs to be used with FastAPI Depends
            # Actual implementation would check user permissions from request context
            # For now, this is a placeholder
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_role(role: Union[Role, str]):
    """Decorator to require specific role for endpoint."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # This decorator needs to be used with FastAPI Depends
            # Actual implementation would check user role from request context
            # For now, this is a placeholder
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_any_permission(permissions: Set[Permission]):
    """Decorator to require any of the specified permissions."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # This decorator needs to be used with FastAPI Depends
            # Actual implementation would check user permissions from request context
            # For now, this is a placeholder
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_all_permissions(permissions: Set[Permission]):
    """Decorator to require all of the specified permissions."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # This decorator needs to be used with FastAPI Depends
            # Actual implementation would check user permissions from request context
            # For now, this is a placeholder
            return await func(*args, **kwargs)
        return wrapper
    return decorator


# Resource-based permissions

class ResourcePermission:
    """Resource-based permission manager."""
    
    def __init__(self, resource_type: str, resource_id: str):
        self.resource_type = resource_type
        self.resource_id = resource_id
    
    def can_access(self, user_permissions: UserPermissions, action: str = "read") -> bool:
        """Check if user can access resource."""
        # Define resource access rules
        access_rules = {
            "chat": {
                "read": {Permission.READ, Permission.VIEW_CHAT_HISTORY},
                "write": {Permission.WRITE, Permission.MANAGE_CHAT},
                "delete": {Permission.DELETE, Permission.DELETE_CHAT},
            },
            "user": {
                "read": {Permission.READ, Permission.VIEW_PROFILE},
                "write": {Permission.WRITE, Permission.EDIT_PROFILE},
                "delete": {Permission.DELETE, Permission.DELETE_ACCOUNT},
                "manage": {Permission.ADMIN, Permission.MANAGE_USERS},
            },
            "file": {
                "read": {Permission.READ, Permission.DOWNLOAD_FILES},
                "write": {Permission.WRITE, Permission.UPLOAD_FILES},
                "delete": {Permission.DELETE},
                "manage": {Permission.ADMIN},
            },
            "system": {
                "read": {Permission.READ, Permission.VIEW_LOGS},
                "write": {Permission.WRITE, Permission.MANAGE_CONFIG},
                "admin": {Permission.ADMIN},
            }
        }
        
        resource_rules = access_rules.get(self.resource_type, {})
        required_permissions = resource_rules.get(action, set())
        
        if not required_permissions:
            return False
        
        return user_permissions.has_any_permission(required_permissions)


# Permission validation and utilities

def validate_user_permissions(user_permissions: UserPermissions) -> Dict[str, Any]:
    """Validate user permissions and return any issues."""
    issues = []
    
    if not user_permissions.role and not user_permissions.permissions:
        issues.append("User has no role or permissions assigned")
    
    # Check for duplicate permissions
    if user_permissions.role:
        role_perms = user_permissions.role.permissions
        custom_perms = user_permissions._custom_permissions
        overlap = role_perms & custom_perms
        if overlap:
            issues.append(f"User has duplicate permissions in role and custom: {[p.name for p in overlap]}")
    
    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "permissions_count": len(user_permissions.permissions),
        "role": user_permissions.role.name if user_permissions.role else None,
    }


def get_permission_matrix() -> Dict[str, Dict[str, bool]]:
    """Get permission matrix showing which roles have which permissions."""
    matrix = {}
    
    for role in Role:
        matrix[role.name] = {}
        for perm in Permission:
            matrix[role.name][perm.name] = role.has_permission(perm)
    
    return matrix


def compare_permissions(
    permissions1: UserPermissions,
    permissions2: UserPermissions
) -> Dict[str, Any]:
    """Compare two user permission sets."""
    perms1 = permissions1.permissions
    perms2 = permissions2.permissions
    
    common = perms1 & perms2
    only_in_1 = perms1 - perms2
    only_in_2 = perms2 - perms1
    
    return {
        "common_permissions": [p.name for p in common],
        "only_in_first": [p.name for p in only_in_1],
        "only_in_second": [p.name for p in only_in_2],
        "first_has_more": len(only_in_1) > len(only_in_2),
        "similarity_score": len(common) / max(len(perms1), len(perms2)) if (perms1 or perms2) else 0,
    }


def get_user_permission_summary(user_permissions: UserPermissions) -> Dict[str, Any]:
    """Get summary of user permissions."""
    return {
        "role": user_permissions.role.name if user_permissions.role else "no_role",
        "total_permissions": len(user_permissions.permissions),
        "permission_categories": {
            "basic": len({p for p in user_permissions.permissions if p in {
                Permission.READ, Permission.WRITE, Permission.DELETE, Permission.EXECUTE
            }}),
            "admin": len({p for p in user_permissions.permissions if p in {
                Permission.ADMIN, Permission.MANAGE_USERS, Permission.MANAGE_ROLES,
                Permission.MANAGE_PERMISSIONS
            }}),
            "content": len({p for p in user_permissions.permissions if p in {
                Permission.UPLOAD_FILES, Permission.DOWNLOAD_FILES, Permission.MODERATE_CONTENT
            }}),
            "system": len({p for p in user_permissions.permissions if p in {
                Permission.VIEW_LOGS, Permission.MANAGE_CONFIG, Permission.SYSTEM_RESTART
            }}),
        },
        "highest_permission": max(user_permissions.permissions, default=None),
    }
