"""
Encryption and Data Protection Utilities.

This module provides comprehensive encryption functionality including:
- Symmetric and asymmetric encryption
- Key generation and management
- Secure hashing and verification
- Data obfuscation and protection
- Cryptographic random number generation
"""

import os
import base64
import hashlib
import secrets
import hmac
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import logging

logger = logging.getLogger(__name__)


class EncryptionError(Exception):
    """Custom exception for encryption operations."""
    pass


class SecureHash:
    """Secure hashing utilities."""
    
    @staticmethod
    def sha256(data: Union[str, bytes], salt: Optional[bytes] = None) -> str:
        """
        Generate SHA-256 hash with optional salt.
        
        Args:
            data: Data to hash
            salt: Optional salt bytes
        
        Returns:
            Hex-encoded hash string
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        if salt:
            data = salt + data
        
        return hashlib.sha256(data).hexdigest()
    
    @staticmethod
    def sha512(data: Union[str, bytes], salt: Optional[bytes] = None) -> str:
        """
        Generate SHA-512 hash with optional salt.
        
        Args:
            data: Data to hash
            salt: Optional salt bytes
        
        Returns:
            Hex-encoded hash string
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        if salt:
            data = salt + data
        
        return hashlib.sha512(data).hexdigest()
    
    @staticmethod
    def blake2b(data: Union[str, bytes], digest_size: int = 32) -> str:
        """
        Generate BLAKE2b hash.
        
        Args:
            data: Data to hash
            digest_size: Hash digest size in bytes
        
        Returns:
            Hex-encoded hash string
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        return hashlib.blake2b(data, digest_size=digest_size).hexdigest()
    
    @staticmethod
    def hmac_sha256(key: Union[str, bytes], data: Union[str, bytes]) -> str:
        """
        Generate HMAC-SHA256 hash.
        
        Args:
            key: HMAC key
            data: Data to hash
        
        Returns:
            Hex-encoded HMAC hash string
        """
        if isinstance(key, str):
            key = key.encode('utf-8')
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        return hmac.new(key, data, hashlib.sha256).hexdigest()
    
    @staticmethod
    def verify_hmac(key: Union[str, bytes], data: Union[str, bytes], hash_to_verify: str) -> bool:
        """
        Verify HMAC hash.
        
        Args:
            key: HMAC key
            data: Original data
            hash_to_verify: Hash to verify against
        
        Returns:
            True if verification succeeds, False otherwise
        """
        expected_hash = SecureHash.hmac_sha256(key, data)
        return hmac.compare_digest(expected_hash, hash_to_verify)


class KeyManager:
    """Cryptographic key generation and management."""
    
    @staticmethod
    def generate_symmetric_key(key_length: int = 32) -> bytes:
        """
        Generate symmetric encryption key.
        
        Args:
            key_length: Key length in bytes (default: 32 for AES-256)
        
        Returns:
            Random symmetric key bytes
        """
        return secrets.token_bytes(key_length)
    
    @staticmethod
    def generate_salt(length: int = 16) -> bytes:
        """
        Generate cryptographically secure salt.
        
        Args:
            length: Salt length in bytes
        
        Returns:
            Random salt bytes
        """
        return secrets.token_bytes(length)
    
    @staticmethod
    def generate_iv(length: int = 16) -> bytes:
        """
        Generate initialization vector.
        
        Args:
            length: IV length in bytes
        
        Returns:
            Random IV bytes
        """
        return secrets.token_bytes(length)
    
    @staticmethod
    def derive_key_from_password(
        password: str,
        salt: bytes,
        key_length: int = 32,
        iterations: int = 100000
    ) -> bytes:
        """
        Derive encryption key from password using PBKDF2.
        
        Args:
            password: Password string
            salt: Salt bytes
            key_length: Derived key length
            iterations: PBKDF2 iteration count
        
        Returns:
            Derived key bytes
        """
        password_bytes = password.encode('utf-8')
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=key_length,
            salt=salt,
            iterations=iterations,
            backend=default_backend()
        )
        return kdf.derive(password_bytes)
    
    @staticmethod
    def generate_rsa_key_pair(key_size: int = 2048) -> tuple:
        """
        Generate RSA key pair.
        
        Args:
            key_size: RSA key size in bits
        
        Returns:
            Tuple of (private_key, public_key) as bytes
        """
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
            backend=default_backend()
        )
        
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_key = private_key.public_key()
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return private_pem, public_pem
    
    @staticmethod
    def generate_hkdf_key(
        master_key: bytes,
        salt: bytes,
        info: bytes,
        key_length: int = 32
    ) -> bytes:
        """
        Generate key using HKDF.
        
        Args:
            master_key: Master key bytes
            salt: Salt bytes
            info: Context-specific info bytes
            key_length: Output key length
        
        Returns:
            Derived key bytes
        """
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=key_length,
            salt=salt,
            info=info,
            backend=default_backend()
        )
        return hkdf.derive(master_key)


class Encryption:
    """Symmetric and asymmetric encryption utilities."""
    
    @staticmethod
    def encrypt_symmetric(
        data: Union[str, bytes],
        key: bytes
    ) -> Dict[str, str]:
        """
        Encrypt data using symmetric encryption (Fernet).
        
        Args:
            data: Data to encrypt
            key: Encryption key
        
        Returns:
            Dictionary with encrypted data, IV, and timestamp
        """
        try:
            if isinstance(data, str):
                data = data.encode('utf-8')
            
            # Generate IV
            iv = KeyManager.generate_iv()
            
            # Create Fernet instance with key
            fernet = Fernet(base64.urlsafe_b64encode(key))
            
            # Encrypt data
            encrypted_data = fernet.encrypt(data)
            
            # Encode for JSON serialization
            return {
                "encrypted_data": base64.b64encode(encrypted_data).decode('utf-8'),
                "iv": base64.b64encode(iv).decode('utf-8'),
                "timestamp": datetime.utcnow().isoformat(),
                "algorithm": "Fernet/AES-128"
            }
        except Exception as e:
            logger.error(f"Symmetric encryption failed: {e}")
            raise EncryptionError(f"Encryption failed: {e}")
    
    @staticmethod
    def decrypt_symmetric(
        encrypted_data: str,
        key: bytes,
        iv: str
    ) -> bytes:
        """
        Decrypt data using symmetric encryption.
        
        Args:
            encrypted_data: Base64-encoded encrypted data
            key: Encryption key
            iv: Base64-encoded IV
        
        Returns:
            Decrypted data as bytes
        """
        try:
            # Decode from base64
            encrypted_bytes = base64.b64decode(encrypted_data.encode('utf-8'))
            iv_bytes = base64.b64decode(iv.encode('utf-8'))
            
            # Create Fernet instance with key
            fernet = Fernet(base64.urlsafe_b64encode(key))
            
            # Decrypt data
            decrypted_data = fernet.decrypt(encrypted_bytes)
            
            return decrypted_data
        except Exception as e:
            logger.error(f"Symmetric decryption failed: {e}")
            raise EncryptionError(f"Decryption failed: {e}")
    
    @staticmethod
    def encrypt_asymmetric(data: bytes, public_key_pem: bytes) -> bytes:
        """
        Encrypt data using asymmetric encryption (RSA).
        
        Args:
            data: Data to encrypt
            public_key_pem: PEM-encoded public key
        
        Returns:
            Encrypted data bytes
        """
        try:
            # Load public key
            public_key = serialization.load_pem_public_key(
                public_key_pem,
                backend=default_backend()
            )
            
            # Encrypt data
            encrypted_data = public_key.encrypt(
                data,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            return encrypted_data
        except Exception as e:
            logger.error(f"Asymmetric encryption failed: {e}")
            raise EncryptionError(f"Asymmetric encryption failed: {e}")
    
    @staticmethod
    def decrypt_asymmetric(
        encrypted_data: bytes,
        private_key_pem: bytes
    ) -> bytes:
        """
        Decrypt data using asymmetric encryption (RSA).
        
        Args:
            encrypted_data: Encrypted data bytes
            private_key_pem: PEM-encoded private key
        
        Returns:
            Decrypted data bytes
        """
        try:
            # Load private key
            private_key = serialization.load_pem_private_key(
                private_key_pem,
                password=None,
                backend=default_backend()
            )
            
            # Decrypt data
            decrypted_data = private_key.decrypt(
                encrypted_data,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            
            return decrypted_data
        except Exception as e:
            logger.error(f"Asymmetric decryption failed: {e}")
            raise EncryptionError(f"Asymmetric decryption failed: {e}")


class DataProtector:
    """Data protection and obfuscation utilities."""
    
    @staticmethod
    def obfuscate_email(email: str, preserve_domain: bool = True) -> str:
        """
        Obfuscate email address.
        
        Args:
            email: Email address to obfuscate
            preserve_domain: Whether to preserve domain part
        
        Returns:
            Obfuscated email
        """
        try:
            local, domain = email.split('@', 1)
            
            # Obfuscate local part
            if len(local) <= 2:
                obfuscated_local = local[0] + '*'
            else:
                obfuscated_local = local[0] + '*' * (len(local) - 2) + local[-1]
            
            if preserve_domain:
                return f"{obfuscated_local}@{domain}"
            else:
                # Also obfuscate domain
                domain_parts = domain.split('.')
                obfuscated_domain = '*' * len(domain)
                return f"{obfuscated_local}@{obfuscated_domain}"
        except Exception:
            return "*@*.com"
    
    @staticmethod
    def obfuscate_phone(phone: str, preserve_last: int = 4) -> str:
        """
        Obfuscate phone number.
        
        Args:
            phone: Phone number to obfuscate
            preserve_last: Number of digits to preserve at the end
        
        Returns:
            Obfuscated phone number
        """
        # Remove all non-digit characters
        digits = ''.join(filter(str.isdigit, phone))
        
        if len(digits) <= preserve_last:
            return '*' * len(digits)
        
        # Replace middle digits with asterisks
        obscured_digits = '*' * (len(digits) - preserve_last) + digits[-preserve_last:]
        
        # Format back to original pattern
        result = ""
        digit_index = 0
        for char in phone:
            if char.isdigit():
                result += obscured_digits[digit_index]
                digit_index += 1
            else:
                result += char
        
        return result
    
    @staticmethod
    def mask_credit_card(card_number: str) -> str:
        """
        Mask credit card number showing only last 4 digits.
        
        Args:
            card_number: Credit card number
        
        Returns:
            Masked credit card number
        """
        # Remove all non-digit characters
        digits = ''.join(filter(str.isdigit, card_number))
        
        if len(digits) < 4:
            return '*' * len(digits)
        
        # Keep only last 4 digits
        masked = '*' * (len(digits) - 4) + digits[-4:]
        
        # Format back to original pattern
        result = ""
        digit_index = 0
        for char in card_number:
            if char.isdigit():
                result += masked[digit_index]
                digit_index += 1
            else:
                result += char
        
        return result
    
    @staticmethod
    def secure_compare(a: str, b: str) -> bool:
        """
        Constant-time string comparison to prevent timing attacks.
        
        Args:
            a: First string
            b: Second string
        
        Returns:
            True if strings are equal, False otherwise
        """
        return hmac.compare_digest(a, b)
    
    @staticmethod
    def create_data_fingerprint(data: Union[str, bytes]) -> str:
        """
        Create unique fingerprint for data.
        
        Args:
            data: Data to fingerprint
        
        Returns:
            Hex-encoded fingerprint
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        # Use SHA-256 with timestamp salt
        timestamp = datetime.utcnow().strftime('%Y%m%d').encode('utf-8')
        return hashlib.sha256(data + timestamp).hexdigest()[:16]


class SecureRandom:
    """Cryptographically secure random number generation."""
    
    @staticmethod
    def random_bytes(length: int) -> bytes:
        """Generate cryptographically secure random bytes."""
        return secrets.token_bytes(length)
    
    @staticmethod
    def random_string(length: int, charset: str = None) -> str:
        """Generate cryptographically secure random string."""
        if charset is None:
            charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        
        return ''.join(secrets.choice(charset) for _ in range(length))
    
    @staticmethod
    def random_hex(length: int) -> str:
        """Generate cryptographically secure random hex string."""
        return secrets.token_hex(length)
    
    @staticmethod
    def random_url_safe(length: int) -> str:
        """Generate cryptographically secure URL-safe random string."""
        return secrets.token_urlsafe(length)
    
    @staticmethod
    def choice(sequence: List[Any]) -> Any:
        """Choose random element from sequence."""
        return secrets.choice(sequence)
    
    @staticmethod
    def shuffle(sequence: List[Any]) -> List[Any]:
        """Shuffle sequence using cryptographically secure random."""
        result = sequence.copy()
        secrets.SystemRandom().shuffle(result)
        return result


# Convenience functions for common operations

def generate_key() -> bytes:
    """Generate a new encryption key."""
    return KeyManager.generate_symmetric_key()


def encrypt_data(data: Union[str, bytes], key: bytes) -> Dict[str, str]:
    """
    Encrypt data using symmetric encryption.
    
    Args:
        data: Data to encrypt
        key: Encryption key
    
    Returns:
        Dictionary with encrypted data and metadata
    """
    return Encryption.encrypt_symmetric(data, key)


def decrypt_data(encrypted_data: str, key: bytes, iv: str) -> bytes:
    """
    Decrypt data using symmetric encryption.
    
    Args:
        encrypted_data: Base64-encoded encrypted data
        key: Encryption key
        iv: Base64-encoded initialization vector
    
    Returns:
        Decrypted data as bytes
    """
    return Encryption.decrypt_symmetric(encrypted_data, key, iv)


def secure_hash(data: Union[str, bytes], salt: Optional[bytes] = None) -> str:
    """
    Generate secure hash of data.
    
    Args:
        data: Data to hash
        salt: Optional salt bytes
    
    Returns:
        Hex-encoded hash
    """
    return SecureHash.sha256(data, salt)


def verify_hash(data: Union[str, bytes], hash_to_verify: str, salt: Optional[bytes] = None) -> bool:
    """
    Verify data hash.
    
    Args:
        data: Original data
        hash_to_verify: Hash to verify against
        salt: Optional salt bytes
    
    Returns:
        True if hash matches, False otherwise
    """
    computed_hash = SecureHash.sha256(data, salt)
    return SecureRandom.secure_compare(computed_hash, hash_to_verify)
