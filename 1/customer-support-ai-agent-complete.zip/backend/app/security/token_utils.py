"""
JWT Token Utilities and Management.

This module provides comprehensive JWT token functionality including:
- Token pair creation (access + refresh)
- Token validation and verification
- Token revocation and blacklisting
- Token rotation and refresh logic
- Secure token storage and management
"""

from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from jose import JWTError, jwt
from fastapi import HTTPException, status
import secrets
import hashlib
import json
import logging

from app.config import settings

logger = logging.getLogger(__name__)


class TokenType:
    """Token type constants."""
    ACCESS = "access"
    REFRESH = "refresh"
    RESET = "reset"
    VERIFICATION = "verification"


class TokenStatus:
    """Token status constants."""
    VALID = "valid"
    EXPIRED = "expired"
    REVOKED = "revoked"
    BLACKLISTED = "blacklisted"


class TokenData:
    """Token payload data structure."""
    
    def __init__(
        self,
        sub: str,
        username: str,
        token_type: str,
        exp: datetime,
        iat: datetime,
        jti: Optional[str] = None,
        permissions: Optional[List[str]] = None,
        **kwargs
    ):
        self.sub = sub  # Subject (user ID)
        self.username = username
        self.token_type = token_type
        self.exp = exp  # Expiration time
        self.iat = iat  # Issued at time
        self.jti = jti or secrets.token_hex(16)  # JWT ID
        self.permissions = permissions or []
        self.extra = kwargs
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert token data to dictionary."""
        return {
            "sub": self.sub,
            "username": self.username,
            "type": self.token_type,
            "exp": self.exp,
            "iat": self.iat,
            "jti": self.jti,
            "permissions": self.permissions,
            **self.extra
        }
    
    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "TokenData":
        """Create TokenData from JWT payload."""
        return cls(
            sub=payload.get("sub"),
            username=payload.get("username"),
            token_type=payload.get("type"),
            exp=datetime.fromtimestamp(payload.get("exp")),
            iat=datetime.fromtimestamp(payload.get("iat")),
            jti=payload.get("jti"),
            permissions=payload.get("permissions", [])
        )


class TokenBlacklist:
    """Token blacklist for revoked tokens."""
    
    def __init__(self):
        self._blacklist: Dict[str, datetime] = {}
        self._max_size = 10000
    
    def blacklist_token(self, jti: str, expires_at: datetime):
        """Add token to blacklist."""
        # Remove expired entries first
        current_time = datetime.utcnow()
        expired_keys = [
            key for key, exp_time in self._blacklist.items()
            if exp_time < current_time
        ]
        for key in expired_keys:
            del self._blacklist[key]
        
        # Add new token to blacklist
        self._blacklist[jti] = expires_at
        
        # Limit blacklist size
        if len(self._blacklist) > self._max_size:
            # Remove oldest entries
            sorted_items = sorted(
                self._blacklist.items(),
                key=lambda x: x[1]
            )
            excess_count = len(self._blacklist) - self._max_size
            for i in range(excess_count):
                del self._blacklist[sorted_items[i][0]]
    
    def is_blacklisted(self, jti: str) -> bool:
        """Check if token is blacklisted."""
        if jti not in self._blacklist:
            return False
        
        # Check if token has expired
        if self._blacklist[jti] < datetime.utcnow():
            del self._blacklist[jti]
            return False
        
        return True
    
    def revoke_all_user_tokens(self, user_id: str):
        """Revoke all tokens for a user (logout all sessions)."""
        # This would need to be implemented based on your storage mechanism
        # For now, it's a placeholder
        logger.info(f"All tokens for user {user_id} would be revoked here")


# Global token blacklist instance
token_blacklist = TokenBlacklist()


def create_access_token(
    data: Dict[str, Any],
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Create JWT access token.
    
    Args:
        data: Data to encode in token
        expires_delta: Custom expiration time
    
    Returns:
        Encoded JWT token
    """
    to_encode = data.copy()
    
    # Set expiration
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + settings.jwt_expire_delta
    
    # Add standard claims
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": TokenType.ACCESS,
        "jti": secrets.token_hex(16)
    })
    
    try:
        encoded_jwt = jwt.encode(
            to_encode,
            settings.jwt_secret_key.get_secret_value(),
            algorithm=settings.jwt_algorithm
        )
        return encoded_jwt
    except Exception as e:
        logger.error(f"Access token creation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not create access token"
        )


def create_refresh_token(
    data: Dict[str, Any],
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Create JWT refresh token.
    
    Args:
        data: Data to encode in token
        expires_delta: Custom expiration time
    
    Returns:
        Encoded JWT refresh token
    """
    to_encode = data.copy()
    
    # Set longer expiration for refresh tokens
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + settings.jwt_refresh_expire_delta
    
    # Add standard claims
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": TokenType.REFRESH,
        "jti": secrets.token_hex(16)
    })
    
    try:
        encoded_jwt = jwt.encode(
            to_encode,
            settings.jwt_secret_key.get_secret_value(),
            algorithm=settings.jwt_algorithm
        )
        return encoded_jwt
    except Exception as e:
        logger.error(f"Refresh token creation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not create refresh token"
        )


def create_token_pair(user_data: Dict[str, Any]) -> Dict[str, str]:
    """
    Create both access and refresh tokens.
    
    Args:
        user_data: User data to include in tokens
    
    Returns:
        Dictionary with access_token and refresh_token
    """
    # Access token (short-lived)
    access_token = create_access_token(user_data)
    
    # Refresh token (long-lived)
    refresh_token = create_refresh_token(user_data)
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": int(settings.jwt_expire_delta.total_seconds())
    }


def verify_access_token(token: str) -> Optional[TokenData]:
    """
    Verify and decode access token.
    
    Args:
        token: JWT access token
    
    Returns:
        TokenData object if valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        # Check token type
        if payload.get("type") != TokenType.ACCESS:
            logger.warning(f"Invalid token type: {payload.get('type')}")
            return None
        
        # Check if token is blacklisted
        jti = payload.get("jti")
        if jti and token_blacklist.is_blacklisted(jti):
            logger.warning(f"Token is blacklisted: {jti}")
            return None
        
        return TokenData.from_payload(payload)
        
    except JWTError as e:
        logger.warning(f"Token verification failed: {e}")
        return None


def verify_refresh_token(token: str) -> Optional[TokenData]:
    """
    Verify and decode refresh token.
    
    Args:
        token: JWT refresh token
    
    Returns:
        TokenData object if valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        # Check token type
        if payload.get("type") != TokenType.REFRESH:
            logger.warning(f"Invalid token type: {payload.get('type')}")
            return None
        
        # Check if token is blacklisted
        jti = payload.get("jti")
        if jti and token_blacklist.is_blacklisted(jti):
            logger.warning(f"Refresh token is blacklisted: {jti}")
            return None
        
        return TokenData.from_payload(payload)
        
    except JWTError as e:
        logger.warning(f"Refresh token verification failed: {e}")
        return None


def decode_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Decode token without verification (for inspection only).
    
    Args:
        token: JWT token
    
    Returns:
        Decoded payload if token is valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm],
            options={"verify_exp": False}  # Don't verify expiration
        )
        return payload
    except JWTError:
        return None


def revoke_token(token: str, reason: str = "manual"):
    """
    Revoke a token by adding it to blacklist.
    
    Args:
        token: JWT token to revoke
        reason: Reason for revocation
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm],
            options={"verify_exp": False}  # Decode even if expired
        )
        
        jti = payload.get("jti")
        exp = datetime.fromtimestamp(payload.get("exp"))
        
        if jti:
            token_blacklist.blacklist_token(jti, exp)
            logger.info(f"Token revoked: {jti}, reason: {reason}")
        else:
            logger.warning("Cannot revoke token without JTI")
            
    except JWTError as e:
        logger.error(f"Failed to revoke token: {e}")


def is_token_revoked(token: str) -> bool:
    """
    Check if token is revoked.
    
    Args:
        token: JWT token
    
    Returns:
        True if token is revoked, False otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm],
            options={"verify_exp": False}
        )
        
        jti = payload.get("jti")
        return token_blacklist.is_blacklisted(jti) if jti else False
        
    except JWTError:
        return True  # Invalid tokens are considered revoked


def create_password_reset_token(user_id: str, email: str) -> str:
    """
    Create password reset token.
    
    Args:
        user_id: User ID
        email: User email
    
    Returns:
        Password reset token
    """
    expire = datetime.utcnow() + timedelta(hours=1)  # 1 hour expiration
    data = {
        "sub": user_id,
        "email": email,
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": TokenType.RESET,
        "jti": secrets.token_hex(16)
    }
    
    return jwt.encode(
        data,
        settings.jwt_secret_key.get_secret_value(),
        algorithm=settings.jwt_algorithm
    )


def verify_password_reset_token(token: str) -> Optional[Dict[str, str]]:
    """
    Verify password reset token.
    
    Args:
        token: Password reset token
    
    Returns:
        Dictionary with user_id and email if valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        if payload.get("type") != TokenType.RESET:
            return None
        
        return {
            "user_id": payload.get("sub"),
            "email": payload.get("email")
        }
        
    except JWTError:
        return None


def create_email_verification_token(user_id: str, email: str) -> str:
    """
    Create email verification token.
    
    Args:
        user_id: User ID
        email: User email
    
    Returns:
        Email verification token
    """
    expire = datetime.utcnow() + timedelta(days=7)  # 7 day expiration
    data = {
        "sub": user_id,
        "email": email,
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": TokenType.VERIFICATION,
        "jti": secrets.token_hex(16)
    }
    
    return jwt.encode(
        data,
        settings.jwt_secret_key.get_secret_value(),
        algorithm=settings.jwt_algorithm
    )


def verify_email_verification_token(token: str) -> Optional[Dict[str, str]]:
    """
    Verify email verification token.
    
    Args:
        token: Email verification token
    
    Returns:
        Dictionary with user_id and email if valid, None otherwise
    """
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        
        if payload.get("type") != TokenType.VERIFICATION:
            return None
        
        return {
            "user_id": payload.get("sub"),
            "email": payload.get("email")
        }
        
    except JWTError:
        return None


def get_token_info(token: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed information about a token without verifying it.
    
    Args:
        token: JWT token
    
    Returns:
        Dictionary with token information
    """
    payload = decode_token(token)
    if not payload:
        return None
    
    # Calculate time remaining
    exp = datetime.fromtimestamp(payload.get("exp", 0))
    now = datetime.utcnow()
    time_remaining = exp - now
    
    return {
        "token_type": payload.get("type"),
        "subject": payload.get("sub"),
        "username": payload.get("username"),
        "issued_at": datetime.fromtimestamp(payload.get("iat", 0)),
        "expires_at": exp,
        "jti": payload.get("jti"),
        "time_remaining_seconds": int(time_remaining.total_seconds()),
        "is_expired": time_remaining.total_seconds() < 0,
        "permissions": payload.get("permissions", [])
    }


def rotate_tokens(refresh_token: str, user_data: Dict[str, Any]) -> Dict[str, str]:
    """
    Rotate refresh token and create new token pair.
    
    Args:
        refresh_token: Current refresh token
        user_data: User data for new tokens
    
    Returns:
        New token pair
    """
    # Verify current refresh token
    token_data = verify_refresh_token(refresh_token)
    if not token_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    # Revoke old refresh token
    revoke_token(refresh_token, reason="rotation")
    
    # Create new token pair
    return create_token_pair(user_data)


def cleanup_expired_tokens():
    """Clean up expired tokens from blacklist."""
    current_time = datetime.utcnow()
    expired_keys = [
        key for key, exp_time in token_blacklist._blacklist.items()
        if exp_time < current_time
    ]
    
    for key in expired_keys:
        del token_blacklist._blacklist[key]
    
    if expired_keys:
        logger.info(f"Cleaned up {len(expired_keys)} expired tokens from blacklist")


def get_user_active_tokens(user_id: str) -> List[str]:
    """
    Get list of active tokens for a user.
    
    Args:
        user_id: User ID
    
    Returns:
        List of token JTI values (this is a mock implementation)
    """
    # In a real implementation, this would query your token storage
    # For now, return empty list
    return []


def revoke_all_user_tokens(user_id: str):
    """
    Revoke all tokens for a user.
    
    Args:
        user_id: User ID
    """
    token_blacklist.revoke_all_user_tokens(user_id)
    logger.info(f"All tokens revoked for user: {user_id}")
