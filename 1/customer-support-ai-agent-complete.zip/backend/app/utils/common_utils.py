"""
Common Utilities Module

This module provides comprehensive common utility functions including helper classes,
decorators, file system utilities, error handling, retry mechanisms, configuration
utilities, and data manipulation functions.
"""

import os
import sys
import json
import time
import hashlib
import logging
import functools
import tempfile
import shutil
import pickle
import gzip
import shutil
import re
from typing import Any, Dict, List, Optional, Union, Callable, Type, Generic, TypeVar, Iterator
from datetime import datetime, timedelta
from pathlib import Path
from contextlib import contextmanager, suppress
from functools import wraps, lru_cache, singledispatch
from dataclasses import dataclass, field
from collections import defaultdict, deque, Counter
from enum import Enum, auto
import threading
import asyncio
import functools
import inspect
import traceback
import uuid
import random
import string
import warnings

logger = logging.getLogger(__name__)

# Type variables for generic utilities
T = TypeVar('T')
K = TypeVar('K')
V = TypeVar('V')


class ErrorHandling:
    """Error handling utilities and decorators"""
    
    @staticmethod
    def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0,
              exceptions: tuple = (Exception,)):
        """Retry decorator with exponential backoff"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                attempt = 0
                current_delay = delay
                
                while attempt < max_attempts:
                    try:
                        return func(*args, **kwargs)
                    except exceptions as e:
                        attempt += 1
                        if attempt >= max_attempts:
                            logger.error(f"Function {func.__name__} failed after {max_attempts} attempts: {e}")
                            raise
                        
                        logger.warning(f"Attempt {attempt} failed: {e}. Retrying in {current_delay}s...")
                        time.sleep(current_delay)
                        current_delay *= backoff
                
            return wrapper
        return decorator
    
    @staticmethod
    def timeout(seconds: float):
        """Timeout decorator"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                result = [None]
                exception = [None]
                
                def target():
                    try:
                        result[0] = func(*args, **kwargs)
                    except Exception as e:
                        exception[0] = e
                
                thread = threading.Thread(target=target)
                thread.daemon = True
                thread.start()
                thread.join(seconds)
                
                if thread.is_alive():
                    raise TimeoutError(f"Function {func.__name__} timed out after {seconds} seconds")
                
                if exception[0]:
                    raise exception[0]
                
                return result[0]
            
            return wrapper
        return decorator
    
    @staticmethod
    def safe_execute(fallback_return=None, log_errors=True):
        """Safe execution decorator with fallback"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if log_errors:
                        logger.error(f"Error in {func.__name__}: {e}")
                        logger.debug(traceback.format_exc())
                    return fallback_return
            return wrapper
        return decorator


class PerformanceMonitor:
    """Performance monitoring utilities and decorators"""
    
    @staticmethod
    def measure_time(func):
        """Decorator to measure function execution time"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            execution_time = end_time - start_time
            logger.debug(f"Function {func.__name__} executed in {execution_time:.4f} seconds")
            return result
        return wrapper
    
    @staticmethod
    def profile_memory(func):
        """Decorator to profile memory usage"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            import psutil
            process = psutil.Process()
            start_memory = process.memory_info().rss / 1024 / 1024  # MB
            
            result = func(*args, **kwargs)
            
            end_memory = process.memory_info().rss / 1024 / 1024  # MB
            memory_diff = end_memory - start_memory
            
            logger.debug(f"Function {func.__name__} memory usage: {memory_diff:.2f} MB")
            return result
        return wrapper
    
    @staticmethod
    def count_calls(func):
        """Decorator to count function calls"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            wrapper.call_count += 1
            return func(*args, **kwargs)
        wrapper.call_count = 0
        return wrapper


class CachingDecorators:
    """Caching utility decorators"""
    
    @staticmethod
    def file_cache(cache_dir: str, max_age: int = 3600):
        """File-based cache decorator"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Create cache key
                cache_key = hashlib.md5(
                    f"{func.__name__}_{str(args)}_{str(kwargs)}".encode()
                ).hexdigest()
                
                cache_path = Path(cache_dir) / f"{cache_key}.cache"
                
                # Check if cached result exists and is fresh
                if cache_path.exists():
                    file_age = time.time() - cache_path.stat().st_mtime
                    if file_age < max_age:
                        try:
                            with open(cache_path, 'rb') as f:
                                return pickle.load(f)
                        except Exception as e:
                            logger.warning(f"Cache read failed: {e}")
                
                # Execute function and cache result
                result = func(*args, **kwargs)
                
                try:
                    cache_path.parent.mkdir(parents=True, exist_ok=True)
                    with open(cache_path, 'wb') as f:
                        pickle.dump(result, f)
                except Exception as e:
                    logger.warning(f"Cache write failed: {e}")
                
                return result
            return wrapper
        return decorator
    
    @staticmethod
    def memoize_ttl(ttl_seconds: int = 300):
        """Memoization with TTL decorator"""
        def decorator(func):
            cache = {}
            
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Create cache key
                key = str(args) + str(sorted(kwargs.items()))
                
                # Check cache
                if key in cache:
                    result, timestamp = cache[key]
                    if time.time() - timestamp < ttl_seconds:
                        return result
                
                # Execute function and cache result
                result = func(*args, **kwargs)
                cache[key] = (result, time.time())
                
                return result
            return wrapper
        return decorator


class FileSystemUtils:
    """File system utility functions"""
    
    @staticmethod
    def ensure_directory(path: Union[str, Path]) -> Path:
        """Ensure directory exists, create if necessary"""
        path_obj = Path(path)
        path_obj.mkdir(parents=True, exist_ok=True)
        return path_obj
    
    @staticmethod
    def safe_filename(filename: str, max_length: int = 255) -> str:
        """Generate safe filename"""
        # Remove or replace invalid characters
        safe_name = re.sub(r'[<>:"/\\|?*]', '_', filename)
        safe_name = re.sub(r'[\x00-\x1f]', '', safe_name)  # Control characters
        
        # Limit length
        if len(safe_name) > max_length:
            name, ext = os.path.splitext(safe_name)
            safe_name = name[:max_length - len(ext)] + ext
        
        return safe_name.strip()
    
    @staticmethod
    def get_file_hash(filepath: Union[str, Path], algorithm: str = 'md5') -> str:
        """Calculate file hash"""
        hash_func = hashlib.new(algorithm)
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_func.update(chunk)
        return hash_func.hexdigest()
    
    @staticmethod
    def find_files(directory: Union[str, Path], pattern: str = "*",
                   recursive: bool = True) -> List[Path]:
        """Find files matching pattern"""
        directory_path = Path(directory)
        if recursive:
            return list(directory_path.rglob(pattern))
        else:
            return list(directory_path.glob(pattern))
    
    @staticmethod
    def get_file_info(filepath: Union[str, Path]) -> Dict[str, Any]:
        """Get comprehensive file information"""
        path_obj = Path(filepath)
        
        if not path_obj.exists():
            return {}
        
        stat = path_obj.stat()
        return {
            'name': path_obj.name,
            'path': str(path_obj.absolute()),
            'size': stat.st_size,
            'created': datetime.fromtimestamp(stat.st_ctime),
            'modified': datetime.fromtimestamp(stat.st_mtime),
            'is_file': path_obj.is_file(),
            'is_dir': path_obj.is_dir(),
            'extension': path_obj.suffix.lower(),
            'hash_md5': FileSystemUtils.get_file_hash(path_obj, 'md5') if path_obj.is_file() else None
        }
    
    @staticmethod
    @contextmanager
    def temporary_file(suffix: str = '.tmp', prefix: str = 'tmp_', 
                      directory: Optional[Union[str, Path]] = None,
                      delete: bool = True):
        """Context manager for temporary files"""
        fd, temp_path = tempfile.mkstemp(suffix=suffix, prefix=prefix, dir=directory)
        
        try:
            os.close(fd)
            yield Path(temp_path)
        finally:
            if delete and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except Exception as e:
                    logger.warning(f"Failed to delete temporary file {temp_path}: {e}")
    
    @staticmethod
    def copy_with_progress(src: Union[str, Path], dst: Union[str, Path],
                          chunk_size: int = 8192) -> bool:
        """Copy file with progress tracking"""
        src_path = Path(src)
        dst_path = Path(dst)
        
        if not src_path.exists():
            raise FileNotFoundError(f"Source file not found: {src}")
        
        try:
            with open(src_path, 'rb') as src_file:
                FileSystemUtils.ensure_directory(dst_path.parent)
                with open(dst_path, 'wb') as dst_file:
                    while True:
                        chunk = src_file.read(chunk_size)
                        if not chunk:
                            break
                        dst_file.write(chunk)
                        logger.debug(f"Copied {dst_file.tell()} bytes")
            return True
        except Exception as e:
            logger.error(f"File copy failed: {e}")
            return False


class StringUtils:
    """String manipulation utilities"""
    
    @staticmethod
    def generate_random_string(length: int = 10, 
                              characters: str = string.ascii_letters + string.digits) -> str:
        """Generate random string"""
        return ''.join(random.choice(characters) for _ in range(length))
    
    @staticmethod
    def generate_uuid_string() -> str:
        """Generate UUID string"""
        return str(uuid.uuid4())
    
    @staticmethod
    def truncate_string(text: str, max_length: int = 100, 
                       suffix: str = "...") -> str:
        """Truncate string to specified length"""
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix
    
    @staticmethod
    def camel_to_snake(name: str) -> str:
        """Convert camelCase to snake_case"""
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()
    
    @staticmethod
    def snake_to_camel(name: str, capitalize_first: bool = False) -> str:
        """Convert snake_case to camelCase"""
        components = name.split('_')
        if capitalize_first:
            return ''.join(word.capitalize() for word in components)
        else:
            return components[0] + ''.join(word.capitalize() for word in components[1:])
    
    @staticmethod
    def pad_string(text: str, width: int, align: str = 'left', 
                  fill_char: str = ' ') -> str:
        """Pad string to specified width"""
        if align == 'left':
            return text.ljust(width, fill_char)
        elif align == 'right':
            return text.rjust(width, fill_char)
        elif align == 'center':
            return text.center(width, fill_char)
        else:
            return text
    
    @staticmethod
    def clean_whitespace(text: str, collapse: bool = True) -> str:
        """Clean whitespace in string"""
        # Replace various whitespace with space
        text = re.sub(r'\s+', ' ', text)
        if not collapse:
            # Keep single spaces
            return text.strip()
        return text.strip()
    
    @staticmethod
    def extract_initials(name: str) -> str:
        """Extract initials from name"""
        if not name:
            return ""
        
        words = name.split()
        return ''.join(word[0].upper() for word in words if word)
    
    @staticmethod
    def mask_sensitive_data(text: str, mask_char: str = '*', 
                           show_first: int = 2, show_last: int = 2) -> str:
        """Mask sensitive data in string"""
        if len(text) <= show_first + show_last:
            return mask_char * len(text)
        
        return text[:show_first] + mask_char * (len(text) - show_first - show_last) + text[-show_last:]


class DataUtils:
    """Data manipulation utilities"""
    
    @staticmethod
    def deep_merge(dict1: Dict[Any, Any], dict2: Dict[Any, Any]) -> Dict[Any, Any]:
        """Deep merge two dictionaries"""
        result = dict1.copy()
        
        for key, value in dict2.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = DataUtils.deep_merge(result[key], value)
            else:
                result[key] = value
        
        return result
    
    @staticmethod
    def flatten_dict(d: Dict[Any, Any], separator: str = '.', prefix: str = '') -> Dict[str, Any]:
        """Flatten nested dictionary"""
        result = {}
        
        for key, value in d.items():
            new_key = f"{prefix}{separator}{key}" if prefix else key
            
            if isinstance(value, dict):
                result.update(DataUtils.flatten_dict(value, separator, new_key))
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, dict):
                        result.update(DataUtils.flatten_dict(item, separator, f"{new_key}{separator}{i}"))
                    else:
                        result[f"{new_key}{separator}{i}"] = item
            else:
                result[new_key] = value
        
        return result
    
    @staticmethod
    def group_by(data: List[Dict], key: str) -> Dict[Any, List[Dict]]:
        """Group list of dictionaries by key"""
        result = defaultdict(list)
        for item in data:
            result[item.get(key)].append(item)
        return dict(result)
    
    @staticmethod
    def sort_by_multiple_keys(data: List[Dict], keys: List[str], 
                             reverse: bool = False) -> List[Dict]:
        """Sort list of dictionaries by multiple keys"""
        return sorted(data, key=lambda x: [x.get(k) for k in keys], reverse=reverse)
    
    @staticmethod
    def chunk_list(data: List[T], chunk_size: int) -> List[List[T]]:
        """Split list into chunks"""
        return [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    
    @staticmethod
    def batch_process(items: List[T], batch_size: int, processor: Callable[[List[T]], Any]):
        """Process items in batches"""
        for batch in DataUtils.chunk_list(items, batch_size):
            yield processor(batch)
    
    @staticmethod
    def remove_duplicates(data: List[T], key: Optional[Callable] = None) -> List[T]:
        """Remove duplicates from list"""
        if key is None:
            return list(dict.fromkeys(data))  # Preserves order
        
        seen = set()
        result = []
        for item in data:
            key_value = key(item)
            if key_value not in seen:
                seen.add(key_value)
                result.append(item)
        return result
    
    @staticmethod
    def get_nested_value(data: Dict, path: str, default: Any = None) -> Any:
        """Get value from nested dictionary using dot notation"""
        keys = path.split('.')
        current = data
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
        
        return current


class ConfigurationUtils:
    """Configuration utilities"""
    
    @staticmethod
    def load_json_config(config_path: Union[str, Path]) -> Dict[str, Any]:
        """Load JSON configuration file"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load config from {config_path}: {e}")
            return {}
    
    @staticmethod
    def save_json_config(config: Dict[str, Any], config_path: Union[str, Path]):
        """Save configuration to JSON file"""
        try:
            FileSystemUtils.ensure_directory(Path(config_path).parent)
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save config to {config_path}: {e}")
    
    @staticmethod
    def get_env_var(name: str, default: Any = None, cast_type: Type = str) -> Any:
        """Get environment variable with type casting"""
        value = os.getenv(name, default)
        if value is not None and cast_type != str:
            try:
                if cast_type == bool:
                    return value.lower() in ('true', '1', 'yes', 'on')
                return cast_type(value)
            except (ValueError, TypeError):
                logger.warning(f"Failed to cast env var {name} to {cast_type.__name__}")
                return default
        return value
    
    @staticmethod
    def validate_config(required_keys: List[str], config: Dict[str, Any]) -> List[str]:
        """Validate configuration has required keys"""
        missing_keys = []
        for key in required_keys:
            if key not in config or config[key] is None:
                missing_keys.append(key)
        return missing_keys


class AsyncUtils:
    """Asynchronous utility functions"""
    
    @staticmethod
    async def run_in_executor(func: Callable, *args):
        """Run synchronous function in executor"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, func, *args)
    
    @staticmethod
    @contextmanager
    async def timeout_context(seconds: float):
        """Async timeout context manager"""
        try:
            yield await asyncio.wait_for(asyncio.sleep(0), timeout=seconds)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Operation timed out after {seconds} seconds")


class ThreadingUtils:
    """Threading utility functions"""
    
    @staticmethod
    @contextmanager
    def thread_pool(max_workers: int = None):
        """Thread pool context manager"""
        from concurrent.futures import ThreadPoolExecutor
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            yield executor
    
    @staticmethod
    def execute_with_timeout(func: Callable, timeout: float, *args, **kwargs):
        """Execute function with timeout"""
        result = [None]
        exception = [None]
        
        def target():
            try:
                result[0] = func(*args, **kwargs)
            except Exception as e:
                exception[0] = e
        
        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        thread.join(timeout)
        
        if thread.is_alive():
            raise TimeoutError(f"Function execution timed out after {timeout} seconds")
        
        if exception[0]:
            raise exception[0]
        
        return result[0]


class LoggingUtils:
    """Logging utility functions"""
    
    @staticmethod
    def setup_logger(name: str, level: str = 'INFO', 
                    log_file: Optional[str] = None,
                    format_string: Optional[str] = None) -> logging.Logger:
        """Setup logger with specified configuration"""
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, level.upper()))
        
        # Remove existing handlers
        for handler in logger.handlers[:]:
            logger.removeHandler(handler)
        
        # Create formatter
        if format_string is None:
            format_string = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        
        formatter = logging.Formatter(format_string)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # File handler
        if log_file:
            FileSystemUtils.ensure_directory(Path(log_file).parent)
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        return logger
    
    @staticmethod
    def log_function_call(func: Callable):
        """Decorator to log function calls"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger.debug(f"Calling {func.__name__} with args: {args}, kwargs: {kwargs}")
            try:
                result = func(*args, **kwargs)
                logger.debug(f"Function {func.__name__} completed successfully")
                return result
            except Exception as e:
                logger.error(f"Function {func.__name__} failed: {e}")
                raise
        return wrapper


class ValidationDecorators:
    """Validation decorators for common use cases"""
    
    @staticmethod
    def validate_types(*types):
        """Decorator to validate argument types"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args):
                for i, (arg, expected_type) in enumerate(zip(args, types)):
                    if not isinstance(arg, expected_type):
                        raise TypeError(f"Argument {i} should be {expected_type.__name__}, got {type(arg).__name__}")
                return func(*args)
            return wrapper
        return decorator
    
    @staticmethod
    def validate_range(min_val=None, max_val=None):
        """Decorator to validate numeric ranges"""
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                for arg in args:
                    if isinstance(arg, (int, float)):
                        if min_val is not None and arg < min_val:
                            raise ValueError(f"Value {arg} is below minimum {min_val}")
                        if max_val is not None and arg > max_val:
                            raise ValueError(f"Value {arg} exceeds maximum {max_val}")
                return func(*args, **kwargs)
            return wrapper
        return decorator


class TestingUtils:
    """Testing utility functions"""
    
    @staticmethod
    def create_test_data(num_records: int, data_type: str = 'user') -> List[Dict[str, Any]]:
        """Create test data for testing purposes"""
        test_data = []
        
        for i in range(num_records):
            if data_type == 'user':
                record = {
                    'id': i + 1,
                    'name': f'User {i + 1}',
                    'email': f'user{i + 1}@example.com',
                    'age': random.randint(18, 80),
                    'active': random.choice([True, False]),
                    'created_at': datetime.now().isoformat()
                }
            elif data_type == 'product':
                record = {
                    'id': i + 1,
                    'name': f'Product {i + 1}',
                    'price': round(random.uniform(10.0, 1000.0), 2),
                    'category': random.choice(['electronics', 'clothing', 'books', 'food']),
                    'in_stock': random.choice([True, False]),
                    'created_at': datetime.now().isoformat()
                }
            else:
                record = {
                    'id': i + 1,
                    'data': f'Data {i + 1}',
                    'value': random.randint(1, 100)
                }
            
            test_data.append(record)
        
        return test_data
    
    @staticmethod
    def mock_response(status_code: int = 200, json_data: Any = None, 
                     text_data: str = None) -> 'MockResponse':
        """Create mock response for testing"""
        class MockResponse:
            def __init__(self, status, json_data, text_data):
                self.status_code = status
                self._json_data = json_data
                self._text_data = text_data
            
            def json(self):
                return self._json_data
            
            @property
            def text(self):
                return self._text_data or json.dumps(self._json_data)
            
            def raise_for_status(self):
                if self.status_code >= 400:
                    raise Exception(f"HTTP {self.status_code} error")
        
        return MockResponse(status_code, json_data, text_data)
    
    @staticmethod
    def assert_valid_json(json_string: str):
        """Assert that string is valid JSON"""
        try:
            json.loads(json_string)
        except json.JSONDecodeError as e:
            raise AssertionError(f"Invalid JSON: {e}")


# Advanced utility classes
class RateLimiter:
    """Rate limiter implementation"""
    
    def __init__(self, max_calls: int, time_window: int = 60):
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls = deque()
        self.lock = threading.Lock()
    
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            with self.lock:
                now = time.time()
                
                # Remove old calls outside time window
                while self.calls and now - self.calls[0] > self.time_window:
                    self.calls.popleft()
                
                # Check if limit exceeded
                if len(self.calls) >= self.max_calls:
                    raise Exception("Rate limit exceeded")
                
                # Add current call
                self.calls.append(now)
                
                return func(*args, **kwargs)
        return wrapper


class CircuitBreaker:
    """Circuit breaker implementation"""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
        self.lock = threading.Lock()
    
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            with self.lock:
                if self.state == 'OPEN':
                    if time.time() - self.last_failure_time > self.recovery_timeout:
                        self.state = 'HALF_OPEN'
                    else:
                        raise Exception("Circuit breaker is OPEN")
                
                try:
                    result = func(*args, **kwargs)
                    if self.state == 'HALF_OPEN':
                        self.state = 'CLOSED'
                        self.failure_count = 0
                    return result
                except Exception as e:
                    self.failure_count += 1
                    if self.failure_count >= self.failure_threshold:
                        self.state = 'OPEN'
                        self.last_failure_time = time.time()
                    raise
        return wrapper


# Export main utilities
__all__ = [
    'ErrorHandling',
    'PerformanceMonitor', 
    'CachingDecorators',
    'FileSystemUtils',
    'StringUtils',
    'DataUtils',
    'ConfigurationUtils',
    'AsyncUtils',
    'ThreadingUtils',
    'LoggingUtils',
    'ValidationDecorators',
    'TestingUtils',
    'RateLimiter',
    'CircuitBreaker'
]