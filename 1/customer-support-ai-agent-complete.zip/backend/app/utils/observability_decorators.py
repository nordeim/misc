"""
Observability Decorators and Utility Functions.

This module provides comprehensive decorators and utilities for automatic
observability integration throughout the application:
- Performance tracking decorators
- Business metrics decorators
- Security event tracking
- Database operation monitoring
- Cache operation tracking
- Custom metrics collection
- Timing and profiling utilities

Features:
- Automatic metrics collection
- Performance profiling
- Business logic monitoring
- Error tracking and reporting
- Context-aware instrumentation
"""

import asyncio
import functools
import time
import logging
import traceback
from typing import Dict, Any, Optional, Callable, Union, List
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime

from app.services.observability_service import get_observability_service

logger = logging.getLogger(__name__)

@dataclass
class MetricContext:
    """Context for metric collection."""
    operation_name: str
    component: str
    tags: Dict[str, str]
    custom_metrics: Dict[str, float]

class PerformanceProfiler:
    """Performance profiling utility for detailed timing analysis."""
    
    def __init__(self, sample_rate: float = 1.0):
        self.sample_rate = sample_rate
        self.profiles = {}
    
    def should_profile(self) -> bool:
        """Determine if this operation should be profiled."""
        import random
        return random.random() < self.sample_rate
    
    def profile_function(self, func: Callable, component: str = "general", tags: Dict[str, str] = None):
        """Decorator for function performance profiling."""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not self.should_profile():
                return func(*args, **kwargs)
            
            operation_name = f"{component}.{func.__name__}"
            
            with self.track_execution(operation_name, component, tags or {}):
                return func(*args, **kwargs)
        
        return wrapper
    
    def profile_async_function(self, func: Callable, component: str = "general", tags: Dict[str, str] = None):
        """Decorator for async function performance profiling."""
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if not self.should_profile():
                return await func(*args, **kwargs)
            
            operation_name = f"{component}.{func.__name__}"
            
            with self.track_execution(operation_name, component, tags or {}):
                return await func(*args, **kwargs)
        
        return wrapper
    
    @contextmanager
    def track_execution(self, operation_name: str, component: str, tags: Dict[str, str]):
        """Context manager for tracking execution."""
        start_time = time.time()
        start_memory = self._get_memory_usage()
        
        context = MetricContext(
            operation_name=operation_name,
            component=component,
            tags=tags.copy(),
            custom_metrics={}
        )
        
        try:
            yield context
            
        finally:
            duration = time.time() - start_time
            end_memory = self._get_memory_usage()
            memory_delta = end_memory - start_memory
            
            # Record metrics
            self._record_execution_metrics(context, duration, memory_delta)
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        import psutil
        return psutil.Process().memory_info().rss / (1024 * 1024)
    
    def _record_execution_metrics(self, context: MetricContext, duration: float, memory_delta: float):
        """Record execution metrics."""
        try:
            obs_service = get_observability_service()
            
            # Record performance context
            context.custom_metrics["execution_time"] = duration
            context.custom_metrics["memory_delta_mb"] = memory_delta
            
            # Add timing tags
            timing_tags = context.tags.copy()
            timing_tags.update({
                "operation": context.operation_name,
                "component": context.component
            })
            
            # Record to performance monitor
            obs_service.performance_monitor.record_metric(
                name=f"{context.operation_name}_execution_time",
                value=duration,
                unit="seconds",
                tags=timing_tags
            )
            
            # Record memory usage
            obs_service.performance_monitor.record_metric(
                name=f"{context.operation_name}_memory_usage",
                value=memory_delta,
                unit="MB",
                tags=timing_tags
            )
            
        except Exception as e:
            logger.error("Failed to record execution metrics", error=str(e))
    
    def get_profile_summary(self, operation_name: str, hours: int = 1) -> Dict[str, Any]:
        """Get profiling summary for an operation."""
        # This would typically query stored profile data
        return {
            "operation": operation_name,
            "profiles_captured": 0,
            "average_duration": 0.0,
            "average_memory_delta": 0.0,
            "p95_duration": 0.0
        }

# Global profiler instance
profiler = PerformanceProfiler()

def monitor_performance(component: str, operation_name: str = None, tags: Dict[str, str] = None):
    """Decorator for comprehensive performance monitoring."""
    def decorator(func):
        operation = operation_name or func.__name__
        
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                full_operation = f"{component}.{operation}"
                
                with obs_service.trace_operation(full_operation, tags):
                    start_time = time.time()
                    
                    try:
                        result = await func(*args, **kwargs)
                        duration = time.time() - start_time
                        
                        # Record success metrics
                        obs_service.record_agent_operation(
                            agent_type=component,
                            operation=operation,
                            status="success",
                            duration=duration
                        )
                        
                        return result
                        
                    except Exception as e:
                        duration = time.time() - start_time
                        
                        # Record error metrics
                        obs_service.record_agent_operation(
                            agent_type=component,
                            operation=operation,
                            status="error",
                            duration=duration
                        )
                        
                        # Log error with context
                        logger.error("Operation failed",
                                   operation=full_operation,
                                   component=component,
                                   duration=duration,
                                   error=str(e),
                                   traceback=traceback.format_exc())
                        
                        raise
                        
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                full_operation = f"{component}.{operation}"
                
                with obs_service.trace_operation(full_operation, tags):
                    start_time = time.time()
                    
                    try:
                        result = func(*args, **kwargs)
                        duration = time.time() - start_time
                        
                        # Record success metrics
                        obs_service.record_agent_operation(
                            agent_type=component,
                            operation=operation,
                            status="success",
                            duration=duration
                        )
                        
                        return result
                        
                    except Exception as e:
                        duration = time.time() - start_time
                        
                        # Record error metrics
                        obs_service.record_agent_operation(
                            agent_type=component,
                            operation=operation,
                            status="error",
                            duration=duration
                        )
                        
                        # Log error with context
                        logger.error("Operation failed",
                                   operation=full_operation,
                                   component=component,
                                   duration=duration,
                                   error=str(e),
                                   traceback=traceback.format_exc())
                        
                        raise
                        
            return sync_wrapper
    return decorator

def track_business_metric(metric_name: str, value_extractor: Callable = None, tags: Dict[str, str] = None):
    """Decorator for tracking business metrics."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Extract metric value
                metric_value = 1  # Default count
                if value_extractor:
                    try:
                        metric_value = value_extractor(result) if result else 0
                    except Exception:
                        metric_value = 1
                
                # Record business metric
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_metric(
                    name=f"business_{metric_name}",
                    value=metric_value,
                    unit="count",
                    tags=tags or {}
                )
                
                return result
                
            except Exception as e:
                logger.error("Business metric tracking failed",
                           metric=metric_name,
                           error=str(e))
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Extract metric value
                metric_value = 1  # Default count
                if value_extractor:
                    try:
                        metric_value = value_extractor(result) if result else 0
                    except Exception:
                        metric_value = 1
                
                # Record business metric
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_metric(
                    name=f"business_{metric_name}",
                    value=metric_value,
                    unit="count",
                    tags=tags or {}
                )
                
                return result
                
            except Exception as e:
                logger.error("Business metric tracking failed",
                           metric=metric_name,
                           error=str(e))
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator

def monitor_database_operation(operation: str, table: str = None):
    """Decorator for monitoring database operations."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record database metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_db_query(
                    operation=operation,
                    table=table or "unknown",
                    duration=duration
                )
                
                return result
                
            except Exception as e:
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_db_query(
                    operation=f"{operation}_error",
                    table=table or "unknown",
                    duration=duration
                )
                
                logger.error("Database operation failed",
                           operation=operation,
                           table=table,
                           duration=duration,
                           error=str(e))
                
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record database metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_db_query(
                    operation=operation,
                    table=table or "unknown",
                    duration=duration
                )
                
                return result
                
            except Exception as e:
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_db_query(
                    operation=f"{operation}_error",
                    table=table or "unknown",
                    duration=duration
                )
                
                logger.error("Database operation failed",
                           operation=operation,
                           table=table,
                           duration=duration,
                           error=str(e))
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator

def monitor_cache_operation(operation: str, cache_name: str = "default"):
    """Decorator for monitoring cache operations."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            status = "success"
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record cache metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_cache_operation(operation, status)
                
                return result
                
            except Exception as e:
                status = "error"
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_cache_operation(operation, status)
                
                logger.error("Cache operation failed",
                           operation=operation,
                           cache=cache_name,
                           duration=duration,
                           error=str(e))
                
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            status = "success"
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record cache metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_cache_operation(operation, status)
                
                return result
                
            except Exception as e:
                status = "error"
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_cache_operation(operation, status)
                
                logger.error("Cache operation failed",
                           operation=operation,
                           cache=cache_name,
                           duration=duration,
                           error=str(e))
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator

def track_security_event(event_type: str, severity: str = "info", tags: Dict[str, str] = None):
    """Decorator for tracking security events."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                result = func(*args, **kwargs)
                
                # Record security event on success
                obs_service = get_observability_service()
                obs_service.record_security_event(event_type, severity)
                
                return result
                
            except Exception as e:
                # Record security event on failure with error severity
                obs_service = get_observability_service()
                obs_service.record_security_event(event_type, "error")
                
                logger.error("Security event tracking failed",
                           event_type=event_type,
                           severity=severity,
                           error=str(e))
                
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            try:
                result = await func(*args, **kwargs)
                
                # Record security event on success
                obs_service = get_observability_service()
                obs_service.record_security_event(event_type, severity)
                
                return result
                
            except Exception as e:
                # Record security event on failure with error severity
                obs_service = get_observability_service()
                obs_service.record_security_event(event_type, "error")
                
                logger.error("Security event tracking failed",
                           event_type=event_type,
                           severity=severity,
                           error=str(e))
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator

def monitor_file_operation(operation: str, file_type: str = "unknown"):
    """Decorator for monitoring file operations."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            status = "success"
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record file operation metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_file_operation(operation, file_type, status)
                
                return result
                
            except Exception as e:
                status = "error"
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_file_operation(operation, file_type, status)
                
                logger.error("File operation failed",
                           operation=operation,
                           file_type=file_type,
                           duration=duration,
                           error=str(e))
                
                raise
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            status = "success"
            start_time = time.time()
            
            try:
                result = await func(*args, **kwargs)
                duration = time.time() - start_time
                
                # Record file operation metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_file_operation(operation, file_type, status)
                
                return result
                
            except Exception as e:
                status = "error"
                duration = time.time() - start_time
                
                # Record error metrics
                obs_service = get_observability_service()
                obs_service.custom_metrics.record_file_operation(operation, file_type, status)
                
                logger.error("File operation failed",
                           operation=operation,
                           file_type=file_type,
                           duration=duration,
                           error=str(e))
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else wrapper
    return decorator

@contextmanager
def observability_context(operation_name: str, component: str = "general", tags: Dict[str, str] = None):
    """Context manager for observability tracking."""
    obs_service = get_observability_service()
    
    with obs_service.trace_operation(operation_name, tags):
        start_time = time.time()
        
        try:
            yield
            duration = time.time() - start_time
            
            # Record successful operation
            obs_service.record_agent_operation(component, operation_name, "success", duration)
            
        except Exception as e:
            duration = time.time() - start_time
            
            # Record failed operation
            obs_service.record_agent_operation(component, operation_name, "error", duration)
            
            # Re-raise the exception
            raise

def create_timing_decorator(component: str, operation_name: str = None, include_args: bool = False):
    """Create a timing decorator for specific operations."""
    def decorator(func):
        operation = operation_name or func.__name__
        
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                full_operation = f"{component}.{operation}"
                
                # Prepare tags
                tags = {"component": component, "operation": operation}
                
                if include_args:
                    try:
                        # Add function arguments as tags (be careful with sensitive data)
                        if args:
                            tags["args_count"] = str(len(args))
                        if kwargs:
                            tags["kwargs_count"] = str(len(kwargs))
                    except Exception:
                        pass  # Ignore tagging errors
                
                try:
                    result = await func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Record timing
                    obs_service = get_observability_service()
                    obs_service.performance_monitor.record_metric(
                        name=f"{full_operation}_timing",
                        value=duration,
                        unit="seconds",
                        tags=tags
                    )
                    
                    return result
                    
                except Exception as e:
                    duration = time.time() - start_time
                    
                    # Record timing for failed operations
                    obs_service = get_observability_service()
                    obs_service.performance_monitor.record_metric(
                        name=f"{full_operation}_timing_error",
                        value=duration,
                        unit="seconds",
                        tags=tags
                    )
                    
                    raise
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                full_operation = f"{component}.{operation}"
                
                # Prepare tags
                tags = {"component": component, "operation": operation}
                
                if include_args:
                    try:
                        # Add function arguments as tags (be careful with sensitive data)
                        if args:
                            tags["args_count"] = str(len(args))
                        if kwargs:
                            tags["kwargs_count"] = str(len(kwargs))
                    except Exception:
                        pass  # Ignore tagging errors
                
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    
                    # Record timing
                    obs_service = get_observability_service()
                    obs_service.performance_monitor.record_metric(
                        name=f"{full_operation}_timing",
                        value=duration,
                        unit="seconds",
                        tags=tags
                    )
                    
                    return result
                    
                except Exception as e:
                    duration = time.time() - start_time
                    
                    # Record timing for failed operations
                    obs_service = get_observability_service()
                    obs_service.performance_monitor.record_metric(
                        name=f"{full_operation}_timing_error",
                        value=duration,
                        unit="seconds",
                        tags=tags
                    )
                    
                    raise
            
            return sync_wrapper
    return decorator

# Predefined decorators for common patterns
api_timing = create_timing_decorator("api")
agent_timing = create_timing_decorator("agent")
database_timing = create_timing_decorator("database")
cache_timing = create_timing_decorator("cache")
file_timing = create_timing_decorator("file")

# Export all decorators and utilities
__all__ = [
    'PerformanceProfiler',
    'MetricContext',
    'profiler',
    'monitor_performance',
    'track_business_metric',
    'monitor_database_operation',
    'monitor_cache_operation',
    'track_security_event',
    'monitor_file_operation',
    'observability_context',
    'create_timing_decorator',
    'api_timing',
    'agent_timing',
    'database_timing',
    'cache_timing',
    'file_timing'
]