"""
Cache Testing and Validation Utilities.

This module provides comprehensive testing utilities for cache operations,
including performance testing, validation, and diagnostics.
"""

import asyncio
import json
import logging
import time
import random
from typing import Any, Dict, List, Optional, Callable, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

from app.services.cache_service import get_cache_service, InMemoryFallbackCache
from app.utils.cache_decorators import cache_result, cache_method

logger = logging.getLogger(__name__)


@dataclass
class CacheTestResult:
    """Result of cache testing operations."""
    test_name: str
    passed: bool
    duration_ms: float
    operations_count: int
    hit_rate: float
    errors: List[str]
    details: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'test_name': self.test_name,
            'passed': self.passed,
            'duration_ms': self.duration_ms,
            'operations_count': self.operations_count,
            'hit_rate': self.hit_rate,
            'errors': self.errors,
            'details': self.details
        }


class CacheTestSuite:
    """Comprehensive cache testing suite."""
    
    def __init__(self):
        self.service = None
        self.test_results: List[CacheTestResult] = []
    
    async def initialize(self):
        """Initialize the test suite."""
        self.service = await get_cache_service()
    
    async def run_all_tests(self) -> List[CacheTestResult]:
        """Run all cache tests."""
        await self.initialize()
        
        tests = [
            self.test_basic_operations,
            self.test_ttl_expiration,
            self.test_fallback_mechanism,
            self.test_batch_operations,
            self.test_tag_invalidation,
            self.test_concurrent_access,
            self.test_serialization,
            self.test_pattern_operations,
            self.test_performance_benchmarks,
            self.test_memory_usage,
            self.test_health_check,
        ]
        
        for test_func in tests:
            try:
                result = await test_func()
                self.test_results.append(result)
                logger.info(f"Test {test_func.__name__}: {'PASSED' if result.passed else 'FAILED'}")
            except Exception as e:
                error_result = CacheTestResult(
                    test_name=test_func.__name__,
                    passed=False,
                    duration_ms=0,
                    operations_count=0,
                    hit_rate=0,
                    errors=[str(e)],
                    details={}
                )
                self.test_results.append(error_result)
                logger.error(f"Test {test_func.__name__} failed with exception: {e}")
        
        return self.test_results
    
    async def test_basic_operations(self) -> CacheTestResult:
        """Test basic cache operations (get, set, delete, exists)."""
        test_name = "basic_operations"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # Test set and get
            test_key = "test_basic_key"
            test_value = {"test": "data", "number": 42}
            
            set_result = await self.service.set(test_key, test_value, ttl=60)
            operations_count += 1
            
            if not set_result:
                errors.append("Set operation failed")
            
            get_result = await self.service.get(test_key)
            operations_count += 1
            
            if get_result != test_value:
                errors.append(f"Get result mismatch: expected {test_value}, got {get_result}")
            
            # Test exists
            exists_result = await self.service.exists(test_key)
            operations_count += 1
            
            if not exists_result:
                errors.append("Exists check failed")
            
            # Test delete
            delete_result = await self.service.delete(test_key)
            operations_count += 1
            
            if not delete_result:
                errors.append("Delete operation failed")
            
            # Verify deletion
            get_after_delete = await self.service.get(test_key)
            operations_count += 1
            
            if get_after_delete is not None:
                errors.append("Value still exists after deletion")
            
        except Exception as e:
            errors.append(f"Exception during basic operations test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'set_get': True, 'exists': True, 'delete': True}
        )
    
    async def test_ttl_expiration(self) -> CacheTestResult:
        """Test TTL expiration functionality."""
        test_name = "ttl_expiration"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # Set value with short TTL
            test_key = "test_ttl_key"
            test_value = "ttl_test_data"
            ttl_seconds = 1
            
            set_result = await self.service.set(test_key, test_value, ttl=ttl_seconds)
            operations_count += 1
            
            if not set_result:
                errors.append("TTL set operation failed")
            
            # Verify value exists immediately
            get_immediate = await self.service.get(test_key)
            operations_count += 1
            
            if get_immediate != test_value:
                errors.append(f"Immediate get failed: expected {test_value}, got {get_immediate}")
            
            # Wait for expiration
            await asyncio.sleep(ttl_seconds + 0.5)
            
            # Verify expiration
            get_after_expiry = await self.service.get(test_key)
            operations_count += 1
            
            if get_after_expiry is not None:
                errors.append(f"Value not expired after TTL: {get_after_expiry}")
            
        except Exception as e:
            errors.append(f"Exception during TTL test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'ttl_set': True, 'immediate_get': True, 'expiry_working': len(errors) == 0}
        )
    
    async def test_fallback_mechanism(self) -> CacheTestResult:
        """Test fallback to in-memory cache."""
        test_name = "fallback_mechanism"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # This test primarily ensures fallback cache works
            if self.service.fallback_cache:
                test_key = "test_fallback_key"
                test_value = {"fallback": "test"}
                
                # Set value (should go to fallback if Redis unavailable)
                set_result = await self.service.set(test_key, test_value, ttl=60)
                operations_count += 1
                
                # Get value
                get_result = await self.service.get(test_key)
                operations_count += 1
                
                if get_result != test_value:
                    errors.append(f"Fallback get failed: expected {test_value}, got {get_result}")
                
                # Cleanup
                await self.service.delete(test_key)
                operations_count += 1
            else:
                errors.append("No fallback cache configured")
            
        except Exception as e:
            errors.append(f"Exception during fallback test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'fallback_configured': self.service.fallback_cache is not None}
        )
    
    async def test_batch_operations(self) -> CacheTestResult:
        """Test batch cache operations."""
        test_name = "batch_operations"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # Prepare batch data
            batch_size = 100
            batch_data = {f"batch_key_{i}": f"batch_value_{i}" for i in range(batch_size)}
            
            # Test batch set
            set_result = await self.service.batch_set(batch_data, ttl=60)
            operations_count += 1
            
            if not set_result:
                errors.append("Batch set operation failed")
            
            # Test batch get
            keys = list(batch_data.keys())
            get_results = await self.service.batch_get(keys)
            operations_count += 1
            
            if len(get_results) != batch_size:
                errors.append(f"Batch get returned {len(get_results)} items, expected {batch_size}")
            
            # Verify all values
            for key, expected_value in batch_data.items():
                if key not in get_results:
                    errors.append(f"Missing key in batch get: {key}")
                elif get_results[key] != expected_value:
                    errors.append(f"Value mismatch for key {key}")
            
            # Cleanup
            for key in keys:
                await self.service.delete(key)
                operations_count += 1
            
        except Exception as e:
            errors.append(f"Exception during batch operations test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'batch_size': batch_size, 'all_keys_returned': len(errors) == 0}
        )
    
    async def test_tag_invalidation(self) -> CacheTestResult:
        """Test tag-based cache invalidation."""
        test_name = "tag_invalidation"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            if self.service.tag_manager:
                # Set values with tags
                tag = "test_tag"
                tagged_keys = []
                
                for i in range(5):
                    key = f"tagged_key_{i}"
                    value = f"tagged_value_{i}"
                    
                    await self.service.set(key, value, tags=[tag])
                    tagged_keys.append(key)
                    operations_count += 1
                
                # Verify values exist
                for key in tagged_keys:
                    result = await self.service.get(key)
                    operations_count += 1
                    if result is None:
                        errors.append(f"Tagged value not found: {key}")
                
                # Invalidate by tag
                invalidation_count = await self.service.invalidate_by_tag(tag)
                operations_count += 1
                
                if invalidation_count != len(tagged_keys):
                    errors.append(f"Invalidation count mismatch: {invalidationation_count} != {len(tagged_keys)}")
                
                # Verify all values are gone
                for key in tagged_keys:
                    result = await self.service.get(key)
                    operations_count += 1
                    if result is not None:
                        errors.append(f"Value not invalidated: {key}")
            else:
                errors.append("Tag manager not available")
            
        except Exception as e:
            errors.append(f"Exception during tag invalidation test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'tag_manager_available': self.service.tag_manager is not None}
        )
    
    async def test_concurrent_access(self) -> CacheTestResult:
        """Test concurrent cache access."""
        test_name = "concurrent_access"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        async def worker(worker_id: int):
            """Worker function for concurrent testing."""
            worker_errors = []
            worker_ops = 0
            
            for i in range(10):
                key = f"concurrent_key_{worker_id}_{i}"
                value = f"concurrent_value_{worker_id}_{i}"
                
                try:
                    # Set
                    await self.service.set(key, value)
                    worker_ops += 1
                    
                    # Get
                    result = await self.service.get(key)
                    worker_ops += 1
                    
                    if result != value:
                        worker_errors.append(f"Value mismatch in worker {worker_id}: {result} != {value}")
                    
                    # Delete
                    await self.service.delete(key)
                    worker_ops += 1
                    
                except Exception as e:
                    worker_errors.append(f"Worker {worker_id} error: {e}")
                    worker_ops += 1
            
            return worker_errors, worker_ops
        
        try:
            # Run multiple workers concurrently
            num_workers = 5
            tasks = [worker(i) for i in range(num_workers)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, Exception):
                    errors.append(f"Worker exception: {result}")
                else:
                    worker_errors, worker_ops = result
                    errors.extend(worker_errors)
                    operations_count += worker_ops
            
        except Exception as e:
            errors.append(f"Exception during concurrent test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'num_workers': num_workers, 'worker_errors': len([e for e in errors if 'Worker' in e])}
        )
    
    async def test_serialization(self) -> CacheTestResult:
        """Test different data serialization."""
        test_name = "serialization"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        test_cases = [
            ("string", "test string"),
            ("integer", 42),
            ("float", 3.14159),
            ("boolean", True),
            ("list", [1, 2, 3, "test"]),
            ("dict", {"key": "value", "number": 123}),
            ("none", None),
            ("nested", {"list": [1, 2], "dict": {"nested": True}}),
        ]
        
        try:
            for data_type, test_value in test_cases:
                key = f"serialization_test_{data_type}"
                
                # Set value
                set_result = await self.service.set(key, test_value)
                operations_count += 1
                
                if not set_result:
                    errors.append(f"Set failed for {data_type}")
                    continue
                
                # Get value
                get_result = await self.service.get(key)
                operations_count += 1
                
                if get_result != test_value:
                    errors.append(f"Serialization mismatch for {data_type}: {get_result} != {test_value}")
                
                # Cleanup
                await self.service.delete(key)
                operations_count += 1
            
        except Exception as e:
            errors.append(f"Exception during serialization test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'test_cases': len(test_cases), 'serialization_types': [case[0] for case in test_cases]}
        )
    
    async def test_pattern_operations(self) -> CacheTestResult:
        """Test pattern-based cache operations."""
        test_name = "pattern_operations"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # Set multiple values with pattern
            pattern = "pattern_test_*"
            num_keys = 10
            keys = []
            
            for i in range(num_keys):
                key = f"pattern_test_{i:03d}"
                value = f"pattern_value_{i:03d}"
                
                await self.service.set(key, value)
                keys.append(key)
                operations_count += 1
            
            # Get keys by pattern
            matched_keys = await self.service.get_keys_by_pattern(pattern)
            operations_count += 1
            
            if len(matched_keys) != num_keys:
                errors.append(f"Pattern match count mismatch: {len(matched_keys)} != {num_keys}")
            
            # Clear by pattern
            cleared_count = await self.service.clear_by_pattern(pattern)
            operations_count += 1
            
            if cleared_count != num_keys:
                errors.append(f"Pattern clear count mismatch: {cleared_count} != {num_keys}")
            
        except Exception as e:
            errors.append(f"Exception during pattern operations test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'pattern': pattern, 'num_keys': num_keys}
        )
    
    async def test_performance_benchmarks(self) -> CacheTestResult:
        """Run performance benchmarks."""
        test_name = "performance_benchmarks"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            # Performance test parameters
            num_operations = 1000
            batch_size = 100
            
            # Individual operations performance
            individual_times = []
            for i in range(100):
                key = f"perf_test_{i}"
                value = f"performance_test_data_{i}" * 10  # Larger value
                
                op_start = time.time()
                await self.service.set(key, value)
                await self.service.get(key)
                await self.service.delete(key)
                individual_times.append((time.time() - op_start) * 1000)
                operations_count += 3
            
            avg_individual_time = sum(individual_times) / len(individual_times)
            
            # Batch operations performance
            batch_data = {f"batch_perf_{i}": f"batch_perf_value_{i}" * 10 for i in range(batch_size)}
            
            batch_start = time.time()
            await self.service.batch_set(batch_data)
            get_results = await self.service.batch_get(list(batch_data.keys()))
            await self.service.clear_by_pattern("batch_perf_*")
            batch_duration = (time.time() - batch_start) * 1000
            operations_count += 1 + 1 + 1  # set + get + clear
            
            # Cleanup
            for key in batch_data.keys():
                if key not in get_results:
                    await self.service.delete(key)
                    operations_count += 1
            
        except Exception as e:
            errors.append(f"Exception during performance test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={
                'avg_individual_time_ms': avg_individual_time,
                'batch_duration_ms': batch_duration,
                'operations_per_second': (operations_count / (duration_ms / 1000)) if duration_ms > 0 else 0
            }
        )
    
    async def test_memory_usage(self) -> CacheTestResult:
        """Test memory usage and limits."""
        test_name = "memory_usage"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            if self.service.fallback_cache:
                initial_size = len(self.service.fallback_cache._cache)
                
                # Add items until we approach limit
                test_data = "x" * 1000  # 1KB per item
                added_items = 0
                
                while len(self.service.fallback_cache._cache) < self.service.fallback_cache.max_size * 0.9:
                    key = f"memory_test_{added_items}"
                    await self.service.set(key, test_data)
                    added_items += 1
                    operations_count += 1
                    
                    if added_items >= 100:  # Limit test to prevent infinite loop
                        break
                
                final_size = len(self.service.fallback_cache._cache)
                
                # Test eviction (should happen automatically)
                if final_size >= self.service.fallback_cache.max_size * 0.8:
                    # Add more items to trigger eviction
                    await self.service.set("memory_stress_key", test_data)
                    operations_count += 1
                    
                    final_size_after = len(self.service.fallback_cache._cache)
                    
                    if final_size_after > self.service.fallback_cache.max_size:
                        errors.append("Memory limit not enforced")
                
                # Cleanup
                await self.service.clear_by_pattern("memory_test_*")
                operations_count += 1
            else:
                errors.append("No fallback cache for memory testing")
            
        except Exception as e:
            errors.append(f"Exception during memory test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={
                'fallback_cache_available': self.service.fallback_cache is not None,
                'max_size': self.service.fallback_cache.max_size if self.service.fallback_cache else 0,
                'items_added': added_items if self.service.fallback_cache else 0
            }
        )
    
    async def test_health_check(self) -> CacheTestResult:
        """Test cache health check functionality."""
        test_name = "health_check"
        start_time = time.time()
        errors = []
        operations_count = 0
        
        try:
            health_result = await self.service.health_check()
            operations_count += 1
            
            if not isinstance(health_result, dict):
                errors.append("Health check should return dictionary")
            
            if 'status' not in health_result:
                errors.append("Health check should include status")
            
            if 'components' not in health_result:
                errors.append("Health check should include components")
            
            # Test stats collection
            stats = await self.service.get_stats()
            operations_count += 1
            
            if not hasattr(stats, 'hits') or not hasattr(stats, 'misses'):
                errors.append("Stats should include hits and misses")
            
        except Exception as e:
            errors.append(f"Exception during health check test: {e}")
        
        duration_ms = (time.time() - start_time) * 1000
        
        return CacheTestResult(
            test_name=test_name,
            passed=len(errors) == 0,
            duration_ms=duration_ms,
            operations_count=operations_count,
            hit_rate=1.0 if len(errors) == 0 else 0.0,
            errors=errors,
            details={'health_status': health_result.get('status', 'unknown') if 'health_result' in locals() else 'N/A'}
        )


async def run_cache_tests() -> Dict[str, Any]:
    """Run all cache tests and return results."""
    suite = CacheTestSuite()
    results = await suite.run_all_tests()
    
    # Generate summary
    total_tests = len(results)
    passed_tests = sum(1 for r in results if r.passed)
    failed_tests = total_tests - passed_tests
    
    summary = {
        'total_tests': total_tests,
        'passed_tests': passed_tests,
        'failed_tests': failed_tests,
        'success_rate': passed_tests / total_tests if total_tests > 0 else 0,
        'total_duration_ms': sum(r.duration_ms for r in results),
        'total_operations': sum(r.operations_count for r in results),
        'results': [r.to_dict() for r in results]
    }
    
    return summary


class CacheValidator:
    """Validate cache configuration and data integrity."""
    
    def __init__(self, service=None):
        self.service = service
    
    async def validate_configuration(self) -> Dict[str, Any]:
        """Validate cache service configuration."""
        if not self.service:
            self.service = await get_cache_service()
        
        validation_results = {
            'valid': True,
            'warnings': [],
            'errors': [],
            'configuration': {}
        }
        
        # Check if service is initialized
        if not self.service._initialized:
            validation_results['errors'].append("Cache service not initialized")
            validation_results['valid'] = False
        
        # Check Redis configuration
        if self.service.redis_client:
            validation_results['configuration']['redis_configured'] = True
            try:
                # Test Redis connection
                await self.service.redis_client.ping()
                validation_results['configuration']['redis_connected'] = True
            except Exception as e:
                validation_results['errors'].append(f"Redis connection failed: {e}")
                validation_results['valid'] = False
        else:
            validation_results['configuration']['redis_configured'] = False
            validation_results['warnings'].append("Redis not configured - using fallback only")
        
        # Check fallback configuration
        if self.service.fallback_cache:
            validation_results['configuration']['fallback_configured'] = True
            validation_results['configuration']['fallback_max_size'] = self.service.fallback_cache.max_size
        else:
            validation_results['warnings'].append("No fallback cache configured")
        
        return validation_results
    
    async def validate_data_integrity(self) -> Dict[str, Any]:
        """Validate cache data integrity."""
        integrity_results = {
            'valid': True,
            'corrupted_keys': [],
            'orphaned_keys': [],
            'statistics': {}
        }
        
        # This would involve checking keys for corruption, orphaned entries, etc.
        # Implementation depends on specific cache backend
        
        return integrity_results
    
    async def generate_validation_report(self) -> Dict[str, Any]:
        """Generate comprehensive validation report."""
        config_validation = await self.validate_configuration()
        data_validation = await self.validate_data_integrity()
        
        report = {
            'timestamp': time.time(),
            'overall_valid': config_validation['valid'] and data_validation['valid'],
            'configuration': config_validation,
            'data_integrity': data_validation,
            'recommendations': self._generate_recommendations(config_validation, data_validation)
        }
        
        return report
    
    def _generate_recommendations(self, config_validation: Dict, data_validation: Dict) -> List[str]:
        """Generate recommendations based on validation results."""
        recommendations = []
        
        if not config_validation['valid']:
            recommendations.append("Fix configuration errors before using cache service")
        
        if config_validation['warnings']:
            recommendations.append("Review configuration warnings")
        
        if data_validation['corrupted_keys']:
            recommendations.append("Investigate corrupted cache entries")
        
        return recommendations


# Export test classes and functions
__all__ = [
    'CacheTestResult',
    'CacheTestSuite',
    'CacheValidator',
    'run_cache_tests'
]
