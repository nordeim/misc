"""
Backend monitoring and metrics collection module.

This module provides comprehensive monitoring capabilities including:
- Prometheus metrics export
- Structured logging
- Performance tracking
- Health check integration
"""

import time
import psutil
import logging
from typing import Dict, Any, Optional
from contextlib import contextmanager
from prometheus_client import (
    Counter, 
    Histogram, 
    Gauge, 
    generate_latest,
    CollectorRegistry,
    CONTENT_TYPE_LATEST
)
import structlog

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Prometheus Metrics
class Metrics:
    """Prometheus metrics collection."""
    
    def __init__(self):
        self.registry = CollectorRegistry()
        self._setup_metrics()
    
    def _setup_metrics(self):
        """Initialize Prometheus metrics."""
        # HTTP Request Metrics
        self.http_requests_total = Counter(
            'http_requests_total',
            'Total number of HTTP requests',
            ['method', 'endpoint', 'status_code'],
            registry=self.registry
        )
        
        self.http_request_duration = Histogram(
            'http_request_duration_seconds',
            'HTTP request duration in seconds',
            ['method', 'endpoint'],
            registry=self.registry
        )
        
        self.http_requests_in_progress = Gauge(
            'http_requests_in_progress',
            'Number of HTTP requests in progress',
            ['method', 'endpoint'],
            registry=self.registry
        )
        
        # System Metrics
        self.cpu_usage_percent = Gauge(
            'cpu_usage_percent',
            'CPU usage percentage',
            registry=self.registry
        )
        
        self.memory_usage_percent = Gauge(
            'memory_usage_percent',
            'Memory usage percentage',
            registry=self.registry
        )
        
        self.disk_usage_percent = Gauge(
            'disk_usage_percent',
            'Disk usage percentage',
            registry=self.registry
        )
        
        # Database Metrics
        self.db_connections_active = Gauge(
            'db_connections_active',
            'Active database connections',
            registry=self.registry
        )
        
        self.db_query_duration = Histogram(
            'db_query_duration_seconds',
            'Database query duration in seconds',
            ['operation'],
            registry=self.registry
        )
        
        # Redis Metrics
        self.redis_connected = Gauge(
            'redis_connected',
            'Redis connection status (1=connected, 0=disconnected)',
            registry=self.registry
        )
        
        # ChromaDB Metrics
        self.chromadb_connected = Gauge(
            'chromadb_connected',
            'ChromaDB connection status (1=connected, 0=disconnected)',
            registry=self.registry
        )
        
        # LLM API Metrics
        self.llm_requests_total = Counter(
            'llm_requests_total',
            'Total LLM requests',
            ['provider', 'model', 'status'],
            registry=self.registry
        )
        
        self.llm_request_duration = Histogram(
            'llm_request_duration_seconds',
            'LLM request duration in seconds',
            ['provider', 'model'],
            registry=self.registry
        )
        
        # Health Check Metrics
        self.health_check_duration = Histogram(
            'health_check_duration_seconds',
            'Health check duration in seconds',
            ['check_type'],
            registry=self.registry
        )
        
        self.health_checks_total = Counter(
            'health_checks_total',
            'Total health checks',
            ['check_type', 'status'],
            registry=self.registry
        )
    
    def record_http_request(self, method: str, endpoint: str, status_code: int, duration: float):
        """Record HTTP request metrics."""
        self.http_requests_total.labels(
            method=method,
            endpoint=endpoint,
            status_code=status_code
        ).inc()
        
        self.http_request_duration.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)
    
    @contextmanager
    def track_http_request(self, method: str, endpoint: str):
        """Context manager to track HTTP request duration."""
        self.http_requests_in_progress.labels(
            method=method,
            endpoint=endpoint
        ).inc()
        
        start_time = time.time()
        try:
            yield
        finally:
            duration = time.time() - start_time
            self.record_http_request(method, endpoint, 200, duration)
            self.http_requests_in_progress.labels(
                method=method,
                endpoint=endpoint
            ).dec()
    
    def update_system_metrics(self):
        """Update system resource metrics."""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            self.cpu_usage_percent.set(cpu_percent)
            
            # Memory usage
            memory = psutil.virtual_memory()
            self.memory_usage_percent.set(memory.percent)
            
            # Disk usage
            disk = psutil.disk_usage('/')
            self.disk_usage_percent.set((disk.used / disk.total) * 100)
            
        except Exception as e:
            logger.error("Failed to update system metrics", error=str(e))
    
    def record_health_check(self, check_type: str, status: str, duration: float):
        """Record health check metrics."""
        self.health_checks_total.labels(
            check_type=check_type,
            status=status
        ).inc()
        
        self.health_check_duration.labels(
            check_type=check_type
        ).observe(duration)
    
    def record_db_query(self, operation: str, duration: float):
        """Record database query metrics."""
        self.db_query_duration.labels(operation=operation).observe(duration)
    
    def set_db_connections(self, count: int):
        """Set active database connections count."""
        self.db_connections_active.set(count)
    
    def set_redis_connected(self, connected: bool):
        """Set Redis connection status."""
        self.redis_connected.set(1 if connected else 0)
    
    def set_chromadb_connected(self, connected: bool):
        """Set ChromaDB connection status."""
        self.chromadb_connected.set(1 if connected else 0)
    
    def record_llm_request(self, provider: str, model: str, status: str, duration: float):
        """Record LLM request metrics."""
        self.llm_requests_total.labels(
            provider=provider,
            model=model,
            status=status
        ).inc()
        
        self.llm_request_duration.labels(
            provider=provider,
            model=model
        ).observe(duration)
    
    def get_metrics(self) -> str:
        """Get Prometheus metrics in text format."""
        return generate_latest(self.registry).decode('utf-8')

# Global metrics instance
metrics = Metrics()

# System Information
class SystemInfo:
    """System information collection."""
    
    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """Get comprehensive system information."""
        try:
            # Basic system info
            cpu_count = psutil.cpu_count()
            cpu_count_logical = psutil.cpu_count(logical=True)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Process info
            process = psutil.Process()
            process_memory = process.memory_info()
            process_cpu_percent = process.cpu_percent()
            
            return {
                "timestamp": time.time(),
                "system": {
                    "cpu_count": cpu_count,
                    "cpu_count_logical": cpu_count_logical,
                    "cpu_usage_percent": psutil.cpu_percent(interval=1),
                    "memory_total": memory.total,
                    "memory_available": memory.available,
                    "memory_percent": memory.percent,
                    "disk_total": disk.total,
                    "disk_used": disk.used,
                    "disk_free": disk.free,
                    "disk_percent": (disk.used / disk.total) * 100,
                },
                "process": {
                    "pid": process.pid,
                    "name": process.name(),
                    "status": process.status(),
                    "memory_rss": process_memory.rss,
                    "memory_vms": process_memory.vms,
                    "cpu_percent": process_cpu_percent,
                    "create_time": process.create_time(),
                    "num_threads": process.num_threads(),
                },
                "platform": {
                    "system": psutil.os.name,
                    "machine": psutil.uname().machine if hasattr(psutil, 'uname') else "unknown",
                    "processor": psutil.uname().processor if hasattr(psutil, 'uname') else "unknown",
                }
            }
        except Exception as e:
            logger.error("Failed to get system info", error=str(e))
            return {
                "timestamp": time.time(),
                "error": str(e)
            }

# Background system metrics updater
class MetricsUpdater:
    """Background updater for system metrics."""
    
    def __init__(self, interval: int = 30):
        self.interval = interval
        self._running = False
    
    def start(self):
        """Start the metrics updater."""
        import threading
        
        def update_loop():
            while self._running:
                try:
                    metrics.update_system_metrics()
                    time.sleep(self.interval)
                except Exception as e:
                    logger.error("Error in metrics updater", error=str(e))
                    time.sleep(5)  # Wait before retrying
        
        self._running = True
        thread = threading.Thread(target=update_loop, daemon=True)
        thread.start()
        logger.info("Metrics updater started")
    
    def stop(self):
        """Stop the metrics updater."""
        self._running = False

# Global metrics updater instance
metrics_updater = MetricsUpdater()

def init_monitoring():
    """Initialize monitoring system."""
    logger.info("Initializing monitoring system")
    metrics_updater.start()
    logger.info("Monitoring system initialized")

def shutdown_monitoring():
    """Shutdown monitoring system."""
    logger.info("Shutting down monitoring system")
    metrics_updater.stop()
    logger.info("Monitoring system shutdown complete")