"""
Core health checking utilities and base classes.

This module provides:
- Base health check implementations
- Health check result structures
- Health check orchestration
- Status aggregation utilities
"""

import time
import asyncio
import logging
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, asdict
from enum import Enum
import traceback
from app.monitoring.backend_monitoring import metrics, logger

class HealthStatus(Enum):
    """Health check status enumeration."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class HealthCheckResult:
    """Health check result data structure."""
    service: str
    status: HealthStatus
    message: str
    details: Optional[Dict[str, Any]] = None
    duration_ms: Optional[float] = None
    timestamp: Optional[float] = None
    error: Optional[str] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = asdict(self)
        result['status'] = self.status.value
        return result

class BaseHealthCheck:
    """Base class for health checks."""
    
    def __init__(self, name: str, timeout: float = 5.0):
        self.name = name
        self.timeout = timeout
        self.logger = logging.getLogger(f"healthcheck.{name}")
    
    async def check(self) -> HealthCheckResult:
        """Perform health check. Must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement check method")
    
    async def run_check(self) -> HealthCheckResult:
        """Run health check with timing and error handling."""
        start_time = time.time()
        try:
            self.logger.debug(f"Starting health check: {self.name}")
            result = await asyncio.wait_for(self.check(), timeout=self.timeout)
            duration_ms = (time.time() - start_time) * 1000
            result.duration_ms = duration_ms
            self.logger.debug(
                f"Health check completed: {self.name}",
                status=result.status.value,
                duration_ms=duration_ms
            )
            return result
        except asyncio.TimeoutError:
            duration_ms = (time.time() - start_time) * 1000
            error_msg = f"Health check timed out after {self.timeout}s"
            self.logger.error(error_msg, health_check=self.name)
            return HealthCheckResult(
                service=self.name,
                status=HealthStatus.UNHEALTHY,
                message=error_msg,
                duration_ms=duration_ms
            )
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            error_msg = f"Health check failed: {str(e)}"
            self.logger.error(
                error_msg,
                health_check=self.name,
                error=str(e),
                traceback=traceback.format_exc()
            )
            return HealthCheckResult(
                service=self.name,
                status=HealthStatus.UNHEALTHY,
                message=error_msg,
                duration_ms=duration_ms,
                error=str(e)
            )

class HealthCheckOrchestrator:
    """Orchestrates multiple health checks and aggregates results."""
    
    def __init__(self):
        self.checks: Dict[str, BaseHealthCheck] = {}
        self.logger = logging.getLogger("healthcheck.orchestrator")
    
    def register_check(self, check: BaseHealthCheck):
        """Register a health check."""
        self.checks[check.name] = check
        self.logger.debug(f"Registered health check: {check.name}")
    
    async def run_all_checks(self) -> Dict[str, HealthCheckResult]:
        """Run all registered health checks."""
        self.logger.info(f"Running {len(self.checks)} health checks")
        
        if not self.checks:
            self.logger.warning("No health checks registered")
            return {}
        
        # Run checks concurrently
        tasks = [check.run_check() for check in self.checks.values()]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        health_results = {}
        for i, (check_name, result) in enumerate(zip(self.checks.keys(), results)):
            if isinstance(result, Exception):
                self.logger.error(
                    f"Health check exception for {check_name}",
                    error=str(result),
                    traceback=traceback.format_exc()
                )
                health_results[check_name] = HealthCheckResult(
                    service=check_name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check exception: {str(result)}",
                    error=str(result)
                )
            else:
                health_results[check_name] = result
        
        # Record metrics for each check
        for check_name, result in health_results.items():
            metrics.record_health_check(
                check_type=check_name,
                status=result.status.value,
                duration=result.duration_ms / 1000 if result.duration_ms else 0
            )
        
        self.logger.info(
            f"Completed health checks",
            total_checks=len(health_results),
            healthy=sum(1 for r in health_results.values() if r.status == HealthStatus.HEALTHY),
            degraded=sum(1 for r in health_results.values() if r.status == HealthStatus.DEGRADED),
            unhealthy=sum(1 for r in health_results.values() if r.status == HealthStatus.UNHEALTHY)
        )
        
        return health_results
    
    async def run_specific_checks(self, check_names: List[str]) -> Dict[str, HealthCheckResult]:
        """Run specific health checks by name."""
        selected_checks = {name: check for name, check in self.checks.items() 
                          if name in check_names}
        
        if not selected_checks:
            self.logger.warning(f"No matching health checks found for: {check_names}")
            return {}
        
        self.logger.info(f"Running {len(selected_checks)} specific health checks: {check_names}")
        
        # Run checks concurrently
        tasks = [check.run_check() for check in selected_checks.values()]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        health_results = {}
        for i, (check_name, result) in enumerate(zip(selected_checks.keys(), results)):
            if isinstance(result, Exception):
                health_results[check_name] = HealthCheckResult(
                    service=check_name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Health check exception: {str(result)}",
                    error=str(result)
                )
            else:
                health_results[check_name] = result
        
        # Record metrics
        for check_name, result in health_results.items():
            metrics.record_health_check(
                check_type=check_name,
                status=result.status.value,
                duration=result.duration_ms / 1000 if result.duration_ms else 0
            )
        
        return health_results
    
    def get_overall_status(self, results: Dict[str, HealthCheckResult]) -> HealthStatus:
        """Determine overall health status from individual results."""
        if not results:
            return HealthStatus.UNKNOWN
        
        statuses = [result.status for result in results.values()]
        
        # If any check is unhealthy, overall is unhealthy
        if HealthStatus.UNHEALTHY in statuses:
            return HealthStatus.UNHEALTHY
        
        # If any check is degraded, overall is degraded
        if HealthStatus.DEGRADED in statuses:
            return HealthStatus.DEGRADED
        
        # If all checks are healthy, overall is healthy
        if all(status == HealthStatus.HEALTHY for status in statuses):
            return HealthStatus.HEALTHY
        
        # If we have unknown statuses and no unhealthy/degraded
        if HealthStatus.UNKNOWN in statuses:
            return HealthStatus.DEGRADED
        
        return HealthStatus.UNKNOWN
    
    def get_status_summary(self, results: Dict[str, HealthCheckResult]) -> Dict[str, Any]:
        """Get a summary of health check results."""
        if not results:
            return {
                "overall_status": HealthStatus.UNKNOWN.value,
                "total_checks": 0,
                "summary": {
                    "healthy": 0,
                    "degraded": 0,
                    "unhealthy": 0,
                    "unknown": 0
                }
            }
        
        status_counts = {
            "healthy": 0,
            "degraded": 0,
            "unhealthy": 0,
            "unknown": 0
        }
        
        for result in results.values():
            status_counts[result.status.value] += 1
        
        return {
            "overall_status": self.get_overall_status(results).value,
            "total_checks": len(results),
            "summary": status_counts,
            "checks": {name: result.to_dict() for name, result in results.items()}
        }

# Global orchestrator instance
health_orchestrator = HealthCheckOrchestrator()

def register_health_check(check: BaseHealthCheck):
    """Register a health check with the global orchestrator."""
    health_orchestrator.register_check(check)

async def run_health_checks(check_types: Optional[List[str]] = None) -> Dict[str, HealthCheckResult]:
    """Run health checks and return results."""
    if check_types:
        return await health_orchestrator.run_specific_checks(check_types)
    else:
        return await health_orchestrator.run_all_checks()

def get_health_summary(results: Dict[str, HealthCheckResult]) -> Dict[str, Any]:
    """Get health status summary."""
    return health_orchestrator.get_status_summary(results)