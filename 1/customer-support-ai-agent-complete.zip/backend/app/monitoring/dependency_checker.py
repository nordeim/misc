"""
Service dependency health checking implementations.

This module provides specific health checks for:
- Database connectivity
- Redis connectivity  
- ChromaDB connectivity
- OpenAI/Azure OpenAI connectivity
- File system access
"""

import asyncio
import time
import os
import sqlite3
import httpx
import redis.asyncio as aioredis
import chromadb
from typing import Dict, Any, Optional
from pathlib import Path
import logging

from .health_check import BaseHealthCheck, HealthCheckResult, HealthStatus
from .backend_monitoring import metrics, logger
from app.config import settings

# Configure logger
dependency_logger = logging.getLogger("dependency.checker")

class DatabaseHealthCheck(BaseHealthCheck):
    """Health check for database connectivity."""
    
    def __init__(self):
        super().__init__(name="database", timeout=10.0)
    
    async def check(self) -> HealthCheckResult:
        """Check database connectivity."""
        try:
            # For SQLite
            if "sqlite" in settings.database_url.lower():
                db_path = settings.database_url.replace("sqlite+aiosqlite:///", "")
                
                # Check if database file exists and is accessible
                if os.path.exists(db_path):
                    # Try to open connection and execute simple query
                    conn = sqlite3.connect(db_path, timeout=5.0)
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1")
                    cursor.fetchone()
                    conn.close()
                    
                    metrics.set_db_connections(1)  # Approximate count
                    
                    return HealthCheckResult(
                        service="database",
                        status=HealthStatus.HEALTHY,
                        message="Database connection successful",
                        details={
                            "database_type": "sqlite",
                            "database_path": db_path,
                            "file_size": os.path.getsize(db_path) if os.path.exists(db_path) else 0
                        }
                    )
                else:
                    return HealthCheckResult(
                        service="database",
                        status=HealthStatus.DEGRADED,
                        message="Database file does not exist",
                        details={"database_type": "sqlite", "database_path": db_path}
                    )
            
            # For PostgreSQL (if configured)
            else:
                # This would require asyncpg for proper async support
                # For now, return degraded status
                return HealthCheckResult(
                    service="database",
                    status=HealthStatus.DEGRADED,
                    message="PostgreSQL health check not implemented",
                    details={"database_type": "postgresql"}
                )
                
        except Exception as e:
            dependency_logger.error("Database health check failed", error=str(e))
            return HealthCheckResult(
                service="database",
                status=HealthStatus.UNHEALTHY,
                message=f"Database connection failed: {str(e)}",
                error=str(e)
            )

class RedisHealthCheck(BaseHealthCheck):
    """Health check for Redis connectivity."""
    
    def __init__(self):
        super().__init__(name="redis", timeout=5.0)
    
    async def check(self) -> HealthCheckResult:
        """Check Redis connectivity."""
        try:
            # Parse Redis URL
            redis_url = settings.redis_url
            
            # Create Redis connection
            redis_client = aioredis.from_url(
                redis_url,
                encoding="utf-8",
                decode_responses=True,
                socket_timeout=5.0,
                socket_connect_timeout=5.0
            )
            
            # Test connection with PING
            start_time = time.time()
            result = await redis_client.ping()
            duration_ms = (time.time() - start_time) * 1000
            
            # Get Redis info
            info = await redis_client.info()
            
            await redis_client.close()
            
            # Update metrics
            metrics.set_redis_connected(True)
            
            return HealthCheckResult(
                service="redis",
                status=HealthStatus.HEALTHY,
                message="Redis connection successful",
                details={
                    "redis_url": redis_url,
                    "ping_duration_ms": round(duration_ms, 2),
                    "redis_version": info.get("redis_version", "unknown"),
                    "connected_clients": info.get("connected_clients", 0),
                    "used_memory": info.get("used_memory", 0),
                    "used_memory_peak": info.get("used_memory_peak", 0)
                }
            )
            
        except Exception as e:
            dependency_logger.error("Redis health check failed", error=str(e))
            metrics.set_redis_connected(False)
            return HealthCheckResult(
                service="redis",
                status=HealthStatus.UNHEALTHY,
                message=f"Redis connection failed: {str(e)}",
                error=str(e)
            )

class ChromaDBHealthCheck(BaseHealthCheck):
    """Health check for ChromaDB connectivity."""
    
    def __init__(self):
        super().__init__(name="chromadb", timeout=10.0)
    
    async def check(self) -> HealthCheckResult:
        """Check ChromaDB connectivity."""
        try:
            # Check if ChromaDB is accessible
            chroma_client = chromadb.Client()
            
            # Try to list collections
            collections = chroma_client.list_collections()
            
            # Try to get or create a test collection
            test_collection_name = "health_check_test"
            try:
                test_collection = chroma_client.get_collection(test_collection_name)
            except:
                # Create test collection if it doesn't exist
                test_collection = chroma_client.create_collection(
                    name=test_collection_name,
                    metadata={"health_check": "true", "timestamp": time.time()}
                )
                
                # Clean up test collection
                try:
                    chroma_client.delete_collection(test_collection_name)
                except:
                    pass  # Ignore cleanup errors
            
            # Update metrics
            metrics.set_chromadb_connected(True)
            
            return HealthCheckResult(
                service="chromadb",
                status=HealthStatus.HEALTHY,
                message="ChromaDB connection successful",
                details={
                    "collections_count": len(collections),
                    "persist_directory": str(settings.chroma_persist_path),
                    "client_type": "persistent" if settings.chroma_persist_path.exists() else "in_memory"
                }
            )
            
        except Exception as e:
            dependency_logger.error("ChromaDB health check failed", error=str(e))
            metrics.set_chromadb_connected(False)
            return HealthCheckResult(
                service="chromadb",
                status=HealthStatus.UNHEALTHY,
                message=f"ChromaDB connection failed: {str(e)}",
                error=str(e)
            )

class OpenAIHealthCheck(BaseHealthCheck):
    """Health check for OpenAI connectivity."""
    
    def __init__(self):
        super().__init__(name="openai", timeout=15.0)
        self.client = None
    
    async def check(self) -> HealthCheckResult:
        """Check OpenAI API connectivity."""
        try:
            if not settings.openai_api_key:
                return HealthCheckResult(
                    service="openai",
                    status=HealthStatus.DEGRADED,
                    message="OpenAI API key not configured"
                )
            
            # Use httpx for direct API call to avoid dependency issues
            headers = {
                "Authorization": f"Bearer {settings.openai_api_key.get_secret_value()}",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient(timeout=15.0) as client:
                start_time = time.time()
                response = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers=headers,
                    json={
                        "model": settings.openai_model,
                        "messages": [{"role": "user", "content": "Hello"}],
                        "max_tokens": 5
                    }
                )
                duration_ms = (time.time() - start_time) * 1000
                
                # Update metrics
                metrics.record_llm_request(
                    provider="openai",
                    model=settings.openai_model,
                    status="success" if response.status_code == 200 else "error",
                    duration=duration_ms / 1000
                )
                
                if response.status_code == 200:
                    return HealthCheckResult(
                        service="openai",
                        status=HealthStatus.HEALTHY,
                        message="OpenAI API connection successful",
                        details={
                            "model": settings.openai_model,
                            "response_time_ms": round(duration_ms, 2),
                            "status_code": response.status_code
                        }
                    )
                else:
                    return HealthCheckResult(
                        service="openai",
                        status=HealthStatus.DEGRADED,
                        message=f"OpenAI API returned status {response.status_code}",
                        details={
                            "status_code": response.status_code,
                            "response_time_ms": round(duration_ms, 2)
                        }
                    )
                    
        except Exception as e:
            dependency_logger.error("OpenAI health check failed", error=str(e))
            metrics.record_llm_request(
                provider="openai",
                model=settings.openai_model or "unknown",
                status="error",
                duration=0
            )
            return HealthCheckResult(
                service="openai",
                status=HealthStatus.UNHEALTHY,
                message=f"OpenAI connection failed: {str(e)}",
                error=str(e)
            )

class AzureOpenAIHealthCheck(BaseHealthCheck):
    """Health check for Azure OpenAI connectivity."""
    
    def __init__(self):
        super().__init__(name="azure_openai", timeout=15.0)
    
    async def check(self) -> HealthCheckResult:
        """Check Azure OpenAI API connectivity."""
        try:
            if not all([settings.azure_openai_api_key, settings.azure_openai_endpoint, settings.azure_openai_deployment_name]):
                return HealthCheckResult(
                    service="azure_openai",
                    status=HealthStatus.DEGRADED,
                    message="Azure OpenAI configuration incomplete"
                )
            
            headers = {
                "api-key": settings.azure_openai_api_key.get_secret_value(),
                "Content-Type": "application/json"
            }
            
            endpoint = settings.azure_openai_endpoint
            deployment_name = settings.azure_openai_deployment_name
            api_version = settings.azure_openai_api_version
            
            url = f"{endpoint}/openai/deployments/{deployment_name}/chat/completions?api-version={api_version}"
            
            async with httpx.AsyncClient(timeout=15.0) as client:
                start_time = time.time()
                response = await client.post(
                    url,
                    headers=headers,
                    json={
                        "messages": [{"role": "user", "content": "Hello"}],
                        "max_tokens": 5
                    }
                )
                duration_ms = (time.time() - start_time) * 1000
                
                # Update metrics
                metrics.record_llm_request(
                    provider="azure_openai",
                    model=deployment_name,
                    status="success" if response.status_code == 200 else "error",
                    duration=duration_ms / 1000
                )
                
                if response.status_code == 200:
                    return HealthCheckResult(
                        service="azure_openai",
                        status=HealthStatus.HEALTHY,
                        message="Azure OpenAI API connection successful",
                        details={
                            "deployment": deployment_name,
                            "endpoint": endpoint,
                            "api_version": api_version,
                            "response_time_ms": round(duration_ms, 2),
                            "status_code": response.status_code
                        }
                    )
                else:
                    return HealthCheckResult(
                        service="azure_openai",
                        status=HealthStatus.DEGRADED,
                        message=f"Azure OpenAI API returned status {response.status_code}",
                        details={
                            "status_code": response.status_code,
                            "response_time_ms": round(duration_ms, 2)
                        }
                    )
                    
        except Exception as e:
            dependency_logger.error("Azure OpenAI health check failed", error=str(e))
            metrics.record_llm_request(
                provider="azure_openai",
                model=settings.azure_openai_deployment_name or "unknown",
                status="error",
                duration=0
            )
            return HealthCheckResult(
                service="azure_openai",
                status=HealthStatus.UNHEALTHY,
                message=f"Azure OpenAI connection failed: {str(e)}",
                error=str(e)
            )

class FileSystemHealthCheck(BaseHealthCheck):
    """Health check for file system access."""
    
    def __init__(self):
        super().__init__(name="filesystem", timeout=5.0)
    
    async def check(self) -> HealthCheckResult:
        """Check file system access and permissions."""
        try:
            issues = []
            details = {}
            
            # Check upload directories
            upload_dirs = [
                settings.upload_temp_path,
                settings.upload_permanent_path,
                settings.chroma_persist_path,
                settings.backup_path
            ]
            
            for upload_dir in upload_dirs:
                dir_path = Path(upload_dir)
                
                # Check if directory exists
                if not dir_path.exists():
                    issues.append(f"Directory does not exist: {upload_dir}")
                    continue
                
                # Check if directory is writable
                if not os.access(dir_path, os.W_OK):
                    issues.append(f"Directory is not writable: {upload_dir}")
                    continue
                
                # Check available space (if on same filesystem)
                try:
                    stat = os.statvfs(dir_path)
                    free_space = stat.f_bavail * stat.f_frsize
                    total_space = stat.f_blocks * stat.f_frsize
                    used_percent = ((total_space - free_space) / total_space) * 100
                    
                    details[upload_dir] = {
                        "exists": True,
                        "writable": True,
                        "free_space_bytes": free_space,
                        "total_space_bytes": total_space,
                        "used_percent": round(used_percent, 2)
                    }
                except (AttributeError, OSError):
                    # statvfs not available on all systems
                    details[upload_dir] = {
                        "exists": True,
                        "writable": True,
                        "free_space_bytes": "unknown",
                        "total_space_bytes": "unknown",
                        "used_percent": "unknown"
                    }
            
            # Determine status based on issues
            if issues:
                status = HealthStatus.DEGRADED if len(issues) == 1 else HealthStatus.UNHEALTHY
                message = "; ".join(issues)
            else:
                status = HealthStatus.HEALTHY
                message = "File system access successful"
            
            return HealthCheckResult(
                service="filesystem",
                status=status,
                message=message,
                details={
                    "checked_directories": len(upload_dirs),
                    "directories": details,
                    "issues": issues if issues else None
                }
            )
            
        except Exception as e:
            dependency_logger.error("File system health check failed", error=str(e))
            return HealthCheckResult(
                service="filesystem",
                status=HealthStatus.UNHEALTHY,
                message=f"File system check failed: {str(e)}",
                error=str(e)
            )

def register_dependency_checks():
    """Register all dependency health checks."""
    checks = [
        DatabaseHealthCheck(),
        RedisHealthCheck(),
        ChromaDBHealthCheck(),
        OpenAIHealthCheck(),
        AzureOpenAIHealthCheck(),
        FileSystemHealthCheck()
    ]
    
    for check in checks:
        from .health_check import register_health_check
        register_health_check(check)
        dependency_logger.info(f"Registered dependency check: {check.name}")

# Auto-register checks when module is imported
register_dependency_checks()