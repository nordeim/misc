"""
Comprehensive Escalation Tool for determining when conversations need human intervention.

Analyzes messages and context to decide if escalation to human support is needed,
provides intelligent routing, queue management, analytics, and human handoff procedures.
"""

import logging
import re
import asyncio
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict
import uuid
import json
import statistics

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func
from sqlalchemy.exc import SQLAlchemyError

from app.agents.chat_agent import AgentContext
from app.models.escalation import (
    EscalationORM, EscalationPolicyORM, EscalationQueueORM, EscalationAnalyticsORM,
    EscalationStatus, EscalationPriority, EscalationReason, EscalationType
)
from app.models.escalation_schemas import (
    EscalationCreate, EscalationRead, EscalationQueueCreate, EscalationQueueRead,
    EscalationPolicyCreate, EscalationPolicyRead, EscalationMetrics, QueuePerformance,
    EscalationDecision, EscalationContext, EscalationNotification, EscalationAnalyticsCreate
)

logger = logging.getLogger(__name__)

class EscalationTool:
    """
    Comprehensive Escalation Tool for intelligent human handoff.
    
    Provides sophisticated escalation decision-making, queue management,
    analytics, and human handoff procedures.
    """
    
    def __init__(self, db_session: Optional[Session] = None):
        """
        Initialize the escalation tool with patterns, thresholds, and database session.
        
        Args:
            db_session: SQLAlchemy database session for persistence
        """
        self.db_session = db_session
        
        # Enhanced escalation keywords with categories
        self.escalation_keywords = {
            'frustration': [
                "frustrated", "angry", "upset", "annoyed", "dissatisfied",
                "terrible", "awful", "horrible", "worst", "hate", "rage",
                "furious", "livid", "disgusted", "fed up"
            ],
            'urgency': [
                "urgent", "emergency", "asap", "immediately", "critical",
                "outage", "down", "can't access", "lost", "stolen", "crisis"
            ],
            'escalation_request': [
                "speak to manager", "talk to supervisor", "human agent",
                "escalate", "supervisor", "manager", "representative",
                "customer service", "real person", "human", "escalate to human"
            ],
            'financial_legal': [
                "refund", "chargeback", "lawsuit", "legal", "attorney",
                "fraud", "unauthorized", "dispute", "billing error",
                "credit card", "charge", "scam", "theft"
            ],
            'technical_complex': [
                "bug", "error", "crash", "system error", "technical issue",
                "debug", "programming", "code", "development", "api",
                "database", "server", "infrastructure"
            ],
            'compliance': [
                "policy", "terms of service", "violation", "complaint",
                "report", "terms", "compliance", "regulatory", "gdpr",
                "privacy", "data protection", "audit"
            ],
            'service_quality': [
                "poor service", "bad experience", "disappointed",
                "unacceptable", "refuse to use", "cancel", "terminate",
                "poor support", "inadequate", "unsatisfactory"
            ]
        }
        
        # Flatten keywords for backward compatibility
        self.all_keywords = [kw for category_kws in self.escalation_keywords.values() for kw in category_kws]
        
        # Enhanced thresholds and weights
        self.escalation_weights = {
            'sentiment': 0.25,
            'keywords': 0.20,
            'confidence': 0.20,
            'complexity': 0.15,
            'conversation_length': 0.10,
            'urgency': 0.10
        }
        
        self.confidence_thresholds = {
            'high': 0.8,
            'medium': 0.6,
            'low': 0.4,
            'critical': 0.9
        }
        
        # Conversation thresholds
        self.max_conversation_turns = 15
        self.critical_conversation_turns = 25
        
        # Priority mapping
        self.priority_mapping = {
            'urgent': EscalationPriority.URGENT,
            'high': EscalationPriority.HIGH,
            'medium': EscalationPriority.MEDIUM,
            'low': EscalationPriority.LOW
        }
        
        # Complexity indicators
        self.complexity_indicators = {
            'technical_depth': ['api', 'database', 'integration', 'custom', 'development'],
            'business_impact': ['revenue', 'profit', 'business', 'enterprise', 'contract'],
            'compliance_risk': ['legal', 'regulation', 'compliance', 'audit', 'violation'],
            'customer_tier': ['enterprise', 'premium', 'vip', 'strategic']
        }
        
        # Cache for performance
        self._queues_cache = None
        self._policies_cache = None
        self._cache_timestamp = None
        self._cache_ttl_seconds = 300  # 5 minutes
        
        logger.info("Enhanced escalation tool initialized with comprehensive features")
    
    async def initialize_default_policies_and_queues(self):
        """Initialize default escalation policies and queues."""
        if not self.db_session:
            logger.warning("No database session provided, skipping default initialization")
            return
            
        try:
            # Create default queues if they don't exist
            default_queues = [
                {
                    'name': 'General Support',
                    'department': 'Customer Service',
                    'description': 'General customer support queue',
                    'capacity': 20,
                    'max_wait_time_minutes': 30
                },
                {
                    'name': 'Technical Support',
                    'department': 'IT Support',
                    'description': 'Technical issues and bug reports',
                    'capacity': 15,
                    'max_wait_time_minutes': 15
                },
                {
                    'name': 'Billing Support',
                    'department': 'Finance',
                    'description': 'Billing, refunds, and payment issues',
                    'capacity': 10,
                    'max_wait_time_minutes': 45
                },
                {
                    'name': 'Escalation Management',
                    'department': 'Management',
                    'description': 'High priority escalations requiring management attention',
                    'capacity': 5,
                    'max_wait_time_minutes': 10
                }
            ]
            
            for queue_data in default_queues:
                existing_queue = self.db_session.query(EscalationQueueORM).filter(
                    EscalationQueueORM.name == queue_data['name']
                ).first()
                
                if not existing_queue:
                    queue = EscalationQueueORM(**queue_data)
                    self.db_session.add(queue)
            
            # Create default policies
            default_policies = [
                {
                    'name': 'Frustrated Customer Policy',
                    'policy_type': 'sentiment',
                    'description': 'Escalate when customer shows high frustration',
                    'rules': {'sentiment_threshold': 0.7, 'frustration_keywords': True},
                    'thresholds': {'score': 0.6},
                    'target_department': 'Customer Service',
                    'priority_score': 5
                },
                {
                    'name': 'Technical Complexity Policy',
                    'policy_type': 'complexity',
                    'description': 'Escalate complex technical issues',
                    'rules': {'technical_keywords': True, 'api_integration': True},
                    'thresholds': {'complexity_score': 0.7},
                    'target_department': 'IT Support',
                    'priority_score': 4
                },
                {
                    'name': 'Billing Dispute Policy',
                    'policy_type': 'financial',
                    'description': 'Escalate billing and financial disputes',
                    'rules': {'billing_keywords': True, 'refund_request': True},
                    'thresholds': {'score': 0.5},
                    'target_department': 'Finance',
                    'priority_score': 6
                },
                {
                    'name': 'Compliance Risk Policy',
                    'policy_type': 'compliance',
                    'description': 'Escalate potential compliance issues',
                    'rules': {'compliance_keywords': True, 'legal_risk': True},
                    'thresholds': {'risk_score': 0.4},
                    'target_department': 'Legal/Compliance',
                    'priority_score': 8
                }
            ]
            
            # Get queue IDs for policy assignment
            queues = {q.name: q for q in self.db_session.query(EscalationQueueORM).all()}
            
            for policy_data in default_policies:
                existing_policy = self.db_session.query(EscalationPolicyORM).filter(
                    EscalationPolicyORM.name == policy_data['name']
                ).first()
                
                if not existing_policy:
                    # Map policy to appropriate queue
                    queue_mapping = {
                        'Customer Service': queues.get('General Support'),
                        'IT Support': queues.get('Technical Support'),
                        'Finance': queues.get('Billing Support'),
                        'Legal/Compliance': queues.get('Escalation Management')
                    }
                    
                    target_queue = queue_mapping.get(policy_data['target_department'])
                    if target_queue:
                        policy_data['target_queue_id'] = target_queue.id
                        policy = EscalationPolicyORM(**policy_data)
                        self.db_session.add(policy)
            
            self.db_session.commit()
            logger.info("Default escalation policies and queues initialized")
            
        except Exception as e:
            logger.error(f"Error initializing default policies and queues: {str(e)}")
            self.db_session.rollback()
    
    async def get_escalation_decision(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> EscalationDecision:
        """
        Get comprehensive escalation decision with full analysis.
        
        Args:
            message: Current message content
            context: Conversation context
            rag_results: RAG search results
            
        Returns:
            EscalationDecision: Comprehensive escalation decision
        """
        # Build escalation context
        escalation_context = await self._build_escalation_context(message, context, rag_results)
        
        # Calculate scores
        scores = await self._calculate_escalation_scores(escalation_context)
        
        # Determine if escalation is needed
        should_escalate = scores['total_score'] >= self.confidence_thresholds['medium']
        
        # Determine priority
        priority_level = self._determine_priority(escalation_context, scores)
        
        # Get recommended queue
        recommended_queue_id = await self._get_recommended_queue(escalation_context, priority_level)
        
        # Generate alternative actions
        alternative_actions = self._generate_alternative_actions(escalation_context, scores)
        
        # Calculate complexity assessment
        complexity_assessment = await self._assess_complexity(escalation_context)
        
        return EscalationDecision(
            should_escalate=should_escalate,
            confidence_score=scores['confidence'],
            escalation_score=scores['total_score'],
            reasons=self._get_escalation_reasons(escalation_context, scores),
            recommended_queue_id=recommended_queue_id,
            priority_level=priority_level,
            urgency_score=scores.get('urgency', 0.0),
            complexity_assessment=complexity_assessment,
            alternative_actions=alternative_actions
        )
    
    async def check_escalation(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Check if a conversation should be escalated to a human agent.
        
        Args:
            message: The current message content
            context: Conversation context
            rag_results: Optional RAG search results
            
        Returns:
            True if escalation is recommended, False otherwise
        """
        decision = await self.get_escalation_decision(message, context, rag_results)
        return decision.should_escalate
    
    async def create_escalation_case(
        self,
        escalation_decision: EscalationDecision,
        escalation_context: EscalationContext,
        session_id: str,
        user_id: str
    ) -> Optional[EscalationORM]:
        """
        Create an escalation case in the database.
        
        Args:
            escalation_decision: The escalation decision
            escalation_context: The escalation context
            session_id: Session ID
            user_id: User ID
            
        Returns:
            EscalationORM: Created escalation case
        """
        if not self.db_session:
            logger.warning("No database session provided, cannot create escalation case")
            return None
            
        try:
            # Get recommended queue
            queue_id = escalation_decision.recommended_queue_id
            if not queue_id:
                queue = await self._get_best_available_queue(escalation_decision.priority_level)
                if not queue:
                    logger.error("No available queue for escalation")
                    return None
                queue_id = queue.id
            
            # Create escalation case
            escalation_data = {
                'session_id': session_id,
                'user_id': user_id,
                'queue_id': queue_id,
                'escalation_type': EscalationType.AUTOMATIC,
                'status': EscalationStatus.PENDING,
                'priority': escalation_decision.priority_level,
                'reasons': escalation_decision.reasons,
                'trigger_score': escalation_decision.escalation_score,
                'trigger_context': escalation_context.dict(),
                'complexity_score': escalation_decision.complexity_assessment.get('complexity_score', 0.0)
            }
            
            escalation = EscalationORM(**escalation_data)
            self.db_session.add(escalation)
            self.db_session.commit()
            self.db_session.refresh(escalation)
            
            # Create analytics record
            await self._create_analytics_record(escalation.id)
            
            # Log escalation creation
            logger.info(f"Escalation case created: {escalation.id} for session {session_id}")
            
            return escalation
            
        except Exception as e:
            logger.error(f"Error creating escalation case: {str(e)}")
            self.db_session.rollback()
            return None
    
    async def assign_escalation_to_agent(
        self,
        escalation_id: UUID,
        agent_id: str,
        agent_name: str
    ) -> bool:
        """
        Assign an escalation to a human agent.
        
        Args:
            escalation_id: Escalation case ID
            agent_id: Agent ID
            agent_name: Agent name
            
        Returns:
            bool: Success status
        """
        if not self.db_session:
            return False
            
        try:
            escalation = self.db_session.query(EscalationORM).filter(
                EscalationORM.id == escalation_id
            ).first()
            
            if not escalation:
                logger.error(f"Escalation case not found: {escalation_id}")
                return False
            
            # Update escalation status
            escalation.status = EscalationStatus.ROUTED
            escalation.assigned_agent_id = agent_id
            escalation.assigned_agent_name = agent_name
            escalation.assigned_at = datetime.utcnow()
            
            self.db_session.commit()
            
            logger.info(f"Escalation {escalation_id} assigned to agent {agent_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error assigning escalation: {str(e)}")
            self.db_session.rollback()
            return False
    
    async def resolve_escalation(
        self,
        escalation_id: UUID,
        resolution_notes: str,
        satisfaction_score: int,
        customer_feedback: Optional[str] = None
    ) -> bool:
        """
        Resolve an escalation case.
        
        Args:
            escalation_id: Escalation case ID
            resolution_notes: Resolution notes
            satisfaction_score: Customer satisfaction score (1-5)
            customer_feedback: Optional customer feedback
            
        Returns:
            bool: Success status
        """
        if not self.db_session:
            return False
            
        try:
            escalation = self.db_session.query(EscalationORM).filter(
                EscalationORM.id == escalation_id
            ).first()
            
            if not escalation:
                logger.error(f"Escalation case not found: {escalation_id}")
                return False
            
            # Calculate resolution time
            now = datetime.utcnow()
            if escalation.assigned_at:
                resolution_time = (now - escalation.assigned_at).total_seconds() / 60
            else:
                resolution_time = (now - escalation.created_at).total_seconds() / 60
            
            # Update escalation
            escalation.status = EscalationStatus.RESOLVED
            escalation.resolved_at = now
            escalation.resolution_time_minutes = resolution_time
            escalation.resolution_notes = resolution_notes
            escalation.customer_feedback = customer_feedback
            escalation.satisfaction_score = satisfaction_score
            
            # Update queue metrics
            await self._update_queue_metrics(escalation.queue_id, resolution_time, satisfaction_score)
            
            self.db_session.commit()
            
            logger.info(f"Escalation {escalation_id} resolved with satisfaction score {satisfaction_score}")
            return True
            
        except Exception as e:
            logger.error(f"Error resolving escalation: {str(e)}")
            self.db_session.rollback()
            return False
    
    # Helper methods for escalation analysis
    
    async def _build_escalation_context(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> EscalationContext:
        """Build comprehensive escalation context."""
        
        # Analyze message
        sentiment_score = await self._analyze_sentiment(message)
        
        # Get conversation length
        conversation_length = len(context.message_history)
        
        # Get RAG confidence
        rag_confidence = rag_results.get("confidence", 0.8) if rag_results else 0.8
        
        # Calculate technical complexity
        technical_complexity = await self._assess_technical_complexity(message)
        
        # Estimate business impact
        business_impact = await self._assess_business_impact(message, context)
        
        # Check compliance risk
        compliance_risk = await self._assess_compliance_risk(message)
        
        # Get previous escalation count
        previous_escalations = await self._get_previous_escalation_count(context.session_id)
        
        # Calculate time since last response (simplified)
        time_since_last_response = 0.0  # Would need message timestamps in real implementation
        
        # Determine customer tier (would be from user profile)
        customer_tier = None  # Would be fetched from user data
        
        return EscalationContext(
            message=message,
            conversation_length=conversation_length,
            user_sentiment=sentiment_score,
            rag_confidence=rag_confidence,
            technical_complexity=technical_complexity,
            business_impact=business_impact,
            compliance_risk=compliance_risk,
            previous_escalations=previous_escalations,
            time_since_last_response=time_since_last_response,
            customer_tier=customer_tier
        )
    
    async def _calculate_escalation_scores(
        self,
        escalation_context: EscalationContext
    ) -> Dict[str, float]:
        """Calculate comprehensive escalation scores."""
        
        scores = {}
        
        # Sentiment score
        scores['sentiment'] = escalation_context.user_sentiment
        
        # Keyword score
        scores['keywords'] = await self._analyze_enhanced_keywords(escalation_context.message)
        
        # Confidence score (inverted - lower confidence = higher escalation)
        scores['confidence'] = 1.0 - escalation_context.rag_confidence
        
        # Complexity score
        scores['complexity'] = max(
            escalation_context.technical_complexity,
            escalation_context.business_impact,
            escalation_context.compliance_risk
        )
        
        # Conversation length score
        scores['conversation_length'] = self._analyze_conversation_length_score(escalation_context.conversation_length)
        
        # Urgency score
        scores['urgency'] = await self._analyze_urgency(escalation_context)
        
        # Calculate weighted total score
        total_score = sum(
            scores[key] * weight
            for key, weight in self.escalation_weights.items()
            if key in scores
        )
        
        scores['total_score'] = total_score
        scores['confidence'] = max(scores.values()) if scores else 0.0
        
        return scores
    
    def _determine_priority(
        self,
        escalation_context: EscalationContext,
        scores: Dict[str, float]
    ) -> EscalationPriority:
        """Determine escalation priority level."""
        
        # Check for critical indicators
        if (escalation_context.compliance_risk > 0.8 or
            escalation_context.business_impact > 0.8 or
            escalation_context.previous_escalations > 2):
            return EscalationPriority.CRITICAL
        
        # Check for urgent indicators
        if (escalation_context.user_sentiment > 0.9 or
            scores.get('urgency', 0) > 0.8 or
            escalation_context.conversation_length > self.critical_conversation_turns):
            return EscalationPriority.URGENT
        
        # Check for high priority
        if (escalation_context.user_sentiment > 0.7 or
            escalation_context.technical_complexity > 0.7 or
            scores.get('total_score', 0) > 0.7):
            return EscalationPriority.HIGH
        
        # Check for medium priority
        if (escalation_context.user_sentiment > 0.5 or
            escalation_context.technical_complexity > 0.5 or
            scores.get('total_score', 0) > 0.5):
            return EscalationPriority.MEDIUM
        
        return EscalationPriority.LOW
    
    async def _get_recommended_queue(
        self,
        escalation_context: EscalationContext,
        priority: EscalationPriority
    ) -> Optional[UUID]:
        """Get recommended queue based on context and priority."""
        
        # Use cached queues if available
        await self._ensure_caches_valid()
        
        if not self._queues_cache:
            return None
        
        # Define queue routing rules
        queue_preferences = []
        
        # Compliance/legal issues
        if escalation_context.compliance_risk > 0.6:
            queue_preferences.append('Escalation Management')
        
        # Technical issues
        if escalation_context.technical_complexity > 0.6:
            queue_preferences.append('Technical Support')
        
        # Financial issues
        if any(keyword in escalation_context.message.lower() for keyword in 
               ['bill', 'refund', 'payment', 'charge', 'account']):
            queue_preferences.append('Billing Support')
        
        # Default to general support
        if not queue_preferences:
            queue_preferences.append('General Support')
        
        # Find best available queue
        for queue_name in queue_preferences:
            queue = next((q for q in self._queues_cache if q.name == queue_name), None)
            if queue and queue.is_active and queue.current_load < queue.capacity:
                return queue.id
        
        # Fallback to any available queue
        available_queues = [q for q in self._queues_cache 
                          if q.is_active and q.current_load < q.capacity]
        if available_queues:
            # Return queue with lowest load
            return min(available_queues, key=lambda q: q.current_load).id
        
        return None
    
    async def _get_best_available_queue(
        self,
        priority: EscalationPriority
    ) -> Optional[EscalationQueueORM]:
        """Get best available queue for given priority."""
        
        await self._ensure_caches_valid()
        
        if not self._queues_cache:
            return None
        
        # Filter by priority and availability
        available_queues = [q for q in self._queues_cache 
                          if q.is_active and q.current_load < q.capacity]
        
        if not available_queues:
            return None
        
        # Sort by priority and load
        if priority in [EscalationPriority.URGENT, EscalationPriority.CRITICAL]:
            # For high priority, prefer queues with shortest wait times
            return min(available_queues, key=lambda q: q.max_wait_time_minutes)
        else:
            # For normal priority, prefer least loaded queues
            return min(available_queues, key=lambda q: q.current_load)
    
    async def _ensure_caches_valid(self):
        """Ensure caches are valid and up-to-date."""
        if not self.db_session:
            return
        
        now = datetime.utcnow()
        if (self._cache_timestamp and 
            (now - self._cache_timestamp).total_seconds() < self._cache_ttl_seconds):
            return
        
        # Refresh caches
        self._queues_cache = self.db_session.query(EscalationQueueORM).filter(
            EscalationQueueORM.is_active == True
        ).all()
        
        self._policies_cache = self.db_session.query(EscalationPolicyORM).filter(
            EscalationPolicyORM.is_active == True
        ).all()
        
        self._cache_timestamp = now
    
    def _generate_alternative_actions(
        self,
        escalation_context: EscalationContext,
        scores: Dict[str, float]
    ) -> List[str]:
        """Generate alternative actions to escalation."""
        
        actions = []
        
        # Sentiment-based actions
        if escalation_context.user_sentiment > 0.6:
            actions.append("Send empathetic response acknowledging frustration")
            actions.append("Offer to schedule callback at customer's convenience")
        
        # Confidence-based actions
        if escalation_context.rag_confidence < 0.6:
            actions.append("Provide more detailed information or FAQ links")
            actions.append("Suggest alternative support channels")
        
        # Technical complexity actions
        if escalation_context.technical_complexity > 0.6:
            actions.append("Create technical support ticket")
            actions.append("Schedule technical consultation")
        
        # Conversation length actions
        if escalation_context.conversation_length > self.max_conversation_turns:
            actions.append("Offer to continue conversation via phone")
            actions.append("Provide summary of previous interactions")
        
        return actions[:5]  # Limit to top 5 actions
    
    async def _assess_complexity(self, escalation_context: EscalationContext) -> Dict[str, Any]:
        """Assess the complexity of the issue."""
        
        complexity_factors = {
            'technical_depth': escalation_context.technical_complexity,
            'business_impact': escalation_context.business_impact,
            'compliance_risk': escalation_context.compliance_risk,
            'resolution_difficulty': await self._estimate_resolution_difficulty(escalation_context)
        }
        
        overall_complexity = max(complexity_factors.values())
        
        complexity_level = "Low"
        if overall_complexity > 0.8:
            complexity_level = "Very High"
        elif overall_complexity > 0.6:
            complexity_level = "High"
        elif overall_complexity > 0.4:
            complexity_level = "Medium"
        
        return {
            'complexity_score': overall_complexity,
            'complexity_level': complexity_level,
            'factors': complexity_factors,
            'estimated_resolution_time': await self._estimate_resolution_time(overall_complexity)
        }
    
    def _get_escalation_reasons(
        self,
        escalation_context: EscalationContext,
        scores: Dict[str, float]
    ) -> List[EscalationReason]:
        """Get detailed reasons for escalation decision."""
        
        reasons = []
        
        if escalation_context.user_sentiment > 0.6:
            reasons.append(EscalationReason.SENTIMENT)
        
        if scores.get('keywords', 0) > 0.5:
            reasons.append(EscalationReason.KEYWORDS)
        
        if escalation_context.conversation_length > self.max_conversation_turns:
            reasons.append(EscalationReason.CONVERSATION_LENGTH)
        
        if escalation_context.rag_confidence < self.confidence_thresholds['high']:
            reasons.append(EscalationReason.CONFIDENCE)
        
        if escalation_context.technical_complexity > 0.6:
            reasons.append(EscalationReason.COMPLEXITY)
        
        if escalation_context.compliance_risk > 0.5:
            reasons.append(EscalationReason.POLICY_VIOLATION)
        
        # Check for explicit escalation requests
        message_lower = escalation_context.message.lower()
        if any(phrase in message_lower for phrase in ['escalate', 'human', 'manager', 'supervisor']):
            reasons.append(EscalationReason.MANUAL_REQUEST)
        
        return reasons
    
    # Enhanced analysis methods
    
    async def _analyze_enhanced_keywords(self, message: str) -> float:
        """Enhanced keyword analysis with categories and weights."""
        
        message_lower = message.lower()
        category_scores = {}
        
        for category, keywords in self.escalation_keywords.items():
            category_matches = sum(1 for keyword in keywords if keyword in message_lower)
            if category_matches > 0:
                # Weight different categories differently
                category_weights = {
                    'frustration': 1.0,
                    'urgency': 1.2,
                    'escalation_request': 1.5,
                    'financial_legal': 1.3,
                    'technical_complex': 1.1,
                    'compliance': 1.4,
                    'service_quality': 1.0
                }
                category_scores[category] = (category_matches / len(keywords)) * category_weights.get(category, 1.0)
        
        if not category_scores:
            return 0.0
        
        # Return weighted average of category scores
        total_weighted_score = sum(category_scores.values())
        total_weight = sum(1.0 for _ in category_scores)
        
        return min(1.0, total_weighted_score / total_weight)
    
    async def _assess_technical_complexity(self, message: str) -> float:
        """Assess technical complexity of the issue."""
        
        technical_indicators = [
            'api', 'integration', 'database', 'server', 'infrastructure',
            'development', 'programming', 'custom', 'configuration',
            'troubleshooting', 'debug', 'error', 'bug', 'system'
        ]
        
        message_lower = message.lower()
        technical_matches = sum(1 for indicator in technical_indicators if indicator in message_lower)
        
        return min(1.0, technical_matches / len(technical_indicators))
    
    async def _assess_business_impact(self, message: str, context: AgentContext) -> float:
        """Assess potential business impact."""
        
        business_indicators = [
            'revenue', 'profit', 'business', 'enterprise', 'contract',
            'client', 'customer', 'production', 'critical', 'downtime'
        ]
        
        message_lower = message.lower()
        business_matches = sum(1 for indicator in business_indicators if indicator in message_lower)
        
        # Adjust based on customer tier (would be from user profile)
        tier_multiplier = 1.5 if context.escalation_level > 0 else 1.0
        
        return min(1.0, (business_matches / len(business_indicators)) * tier_multiplier)
    
    async def _assess_compliance_risk(self, message: str) -> float:
        """Assess compliance and legal risk."""
        
        compliance_indicators = [
            'legal', 'regulation', 'compliance', 'audit', 'violation',
            'gdpr', 'privacy', 'data protection', 'law', 'attorney',
            'policy', 'terms of service'
        ]
        
        message_lower = message.lower()
        compliance_matches = sum(1 for indicator in compliance_indicators if indicator in message_lower)
        
        return min(1.0, compliance_matches / len(compliance_indicators))
    
    async def _analyze_urgency(self, escalation_context: EscalationContext) -> float:
        """Analyze urgency indicators."""
        
        urgency_score = 0.0
        
        # Time-based urgency
        if escalation_context.time_since_last_response > 60:  # 1 hour
            urgency_score += 0.3
        elif escalation_context.time_since_last_response > 30:  # 30 minutes
            urgency_score += 0.1
        
        # Previous escalation urgency
        if escalation_context.previous_escalations > 0:
            urgency_score += escalation_context.previous_escalations * 0.2
        
        # Message-based urgency
        urgent_keywords = ['urgent', 'emergency', 'asap', 'immediately', 'critical']
        if any(keyword in escalation_context.message.lower() for keyword in urgent_keywords):
            urgency_score += 0.5
        
        return min(1.0, urgency_score)
    
    def _analyze_conversation_length_score(self, conversation_length: int) -> float:
        """Analyze conversation length for escalation indicators."""
        
        if conversation_length > self.critical_conversation_turns:
            return 1.0
        elif conversation_length > self.max_conversation_turns:
            excess = conversation_length - self.max_conversation_turns
            return min(1.0, excess / (self.critical_conversation_turns - self.max_conversation_turns))
        else:
            return 0.0
    
    async def _get_previous_escalation_count(self, session_id: str) -> int:
        """Get count of previous escalations for session."""
        
        if not self.db_session:
            return 0
        
        try:
            count = self.db_session.query(EscalationORM).filter(
                EscalationORM.session_id == session_id
            ).count()
            return count
        except Exception as e:
            logger.error(f"Error getting previous escalation count: {str(e)}")
            return 0
    
    async def _estimate_resolution_difficulty(self, escalation_context: EscalationContext) -> float:
        """Estimate resolution difficulty."""
        
        difficulty_factors = {
            'technical_complexity': escalation_context.technical_complexity,
            'business_impact': escalation_context.business_impact,
            'compliance_risk': escalation_context.compliance_risk,
            'conversation_length': min(1.0, escalation_context.conversation_length / 20),
            'previous_escalations': min(1.0, escalation_context.previous_escalations / 3)
        }
        
        return max(difficulty_factors.values())
    
    async def _estimate_resolution_time(self, complexity_score: float) -> str:
        """Estimate resolution time based on complexity."""
        
        if complexity_score > 0.8:
            return "2-4 hours"
        elif complexity_score > 0.6:
            return "1-2 hours"
        elif complexity_score > 0.4:
            return "30-60 minutes"
        else:
            return "15-30 minutes"
    
    # Database helper methods
    
    async def _create_analytics_record(self, escalation_id: UUID):
        """Create analytics record for escalation."""
        
        if not self.db_session:
            return
        
        try:
            now = datetime.utcnow()
            analytics_data = {
                'escalation_id': escalation_id,
                'date': now,
                'hour': now.hour,
                'escalation_count': 1
            }
            
            analytics = EscalationAnalyticsORM(**analytics_data)
            self.db_session.add(analytics)
            
        except Exception as e:
            logger.error(f"Error creating analytics record: {str(e)}")
    
    async def _update_queue_metrics(self, queue_id: UUID, resolution_time: float, satisfaction_score: int):
        """Update queue performance metrics."""
        
        if not self.db_session:
            return
        
        try:
            queue = self.db_session.query(EscalationQueueORM).filter(
                EscalationQueueORM.id == queue_id
            ).first()
            
            if queue:
                # Update current load
                queue.current_load = max(0, queue.current_load - 1)
                
                # Update average resolution time
                if queue.avg_resolution_time_minutes == 0.0:
                    queue.avg_resolution_time_minutes = resolution_time
                else:
                    queue.avg_resolution_time_minutes = (queue.avg_resolution_time_minutes + resolution_time) / 2
                
                # Update customer satisfaction
                if queue.customer_satisfaction_score == 0.0:
                    queue.customer_satisfaction_score = satisfaction_score
                else:
                    queue.customer_satisfaction_score = (queue.customer_satisfaction_score + satisfaction_score) / 2
                
        except Exception as e:
            logger.error(f"Error updating queue metrics: {str(e)}")
    
    def _analyze_keywords(self, message: str) -> float:
        """Analyze message for escalation-related keywords (legacy compatibility)."""
        message_lower = message.lower()
        keyword_matches = 0
        
        # Use the flattened keywords list for backward compatibility
        for keyword in self.all_keywords:
            if keyword in message_lower:
                keyword_matches += 1
        
        # Calculate keyword density (matches per 100 characters)
        keyword_density = (keyword_matches / max(len(message), 1)) * 100
        
        # Normalize to [0, 1]
        return min(1.0, keyword_density / 10.0)
    
    def _analyze_conversation_length(self, context: AgentContext) -> float:
        """Analyze conversation length for escalation indicators."""
        conversation_turns = len(context.message_history)
        
        if conversation_turns > self.max_conversation_turns:
            # Penalty for very long conversations
            excess = conversation_turns - self.max_conversation_turns
            return min(1.0, excess / 20.0)  # Max penalty of 1.0
        
        return 0.0
    
    def _analyze_sentiment(self, message: str) -> float:
        """Analyze sentiment for escalation indicators."""
        # Simple sentiment analysis based on patterns
        negative_indicators = [
            # Strong negative words
            r'\b(frustrated|angry|upset|annoyed|dissatisfied)\b',
            r'\b(terrible|awful|horrible|worst|hate)\b',
            r'\b(not working|broken|useless|incompetent)\b',
            
            # Repetitive punctuation (indicating frustration)
            r'!{3,}',  # Multiple exclamation marks
            r'\?{3,}', # Multiple question marks
            r'[^a-zA-Z0-9\s]{3,}',  # Special characters
            
            # ALL CAPS words (shouting)
            r'\b[A-Z]{4,}\b',
            
            # Frustrated typing patterns
            r'\.{3,}',  # Ellipsis (frustration/delay)
            r'([a-z])\1{3,}',  # Repeated letters
        ]
        
        sentiment_score = 0.0
        
        for pattern in negative_indicators:
            if re.search(pattern, message, re.IGNORECASE):
                sentiment_score += 0.1
        
        return min(1.0, sentiment_score)
    
    async def get_escalation_reasons(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> List[str]:
        """
        Get detailed reasons for escalation decision.
        
        Args:
            message: Current message
            context: Conversation context
            rag_results: RAG search results
            
        Returns:
            List of escalation reasons
        """
        reasons = []
        
        # Keyword reasons
        message_lower = message.lower()
        matched_keywords = []
        for keyword in self.escalation_keywords:
            if keyword in message_lower:
                matched_keywords.append(keyword)
        
        if matched_keywords:
            reasons.append(f"Escalation keywords detected: {', '.join(matched_keywords[:5])}")
        
        # RAG confidence reasons
        if rag_results:
            confidence = rag_results.get("confidence", 1.0)
            if confidence < self.high_confidence_threshold:
                reasons.append(f"Low RAG confidence: {confidence:.2f}")
        
        # Conversation length reasons
        conversation_turns = len(context.message_history)
        if conversation_turns > self.max_conversation_turns:
            reasons.append(f"Long conversation: {conversation_turns} turns")
        
        # Sentiment reasons
        sentiment_score = self._analyze_sentiment(message)
        if sentiment_score > 0.5:
            reasons.append(f"Negative sentiment detected: score {sentiment_score:.2f}")
        
        # Escalation level reasons
        if context.escalation_level > 0:
            reasons.append(f"Previous escalation level: {context.escalation_level}")
        
        if not reasons:
            reasons.append("Escalation score below threshold")
        
        return reasons
    
    async def _calculate_escalation_score(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        Calculate escalation score (legacy method for backward compatibility).
        
        Args:
            message: Current message content
            context: Conversation context
            rag_results: RAG search results
            
        Returns:
            Escalation score between 0.0 and 1.0
        """
        decision = await self.get_escalation_decision(message, context, rag_results)
        return decision.escalation_score
    
    async def get_escalation_metrics(
        self,
        start_date: datetime,
        end_date: datetime,
        queue_id: Optional[UUID] = None
    ) -> EscalationMetrics:
        """
        Get comprehensive escalation metrics for analytics.
        
        Args:
            start_date: Start date for metrics
            end_date: End date for metrics
            queue_id: Optional queue ID to filter by
            
        Returns:
            EscalationMetrics: Comprehensive metrics
        """
        if not self.db_session:
            logger.warning("No database session provided for metrics")
            return self._get_empty_metrics()
        
        try:
            import statistics
            from collections import defaultdict
            
            # Build query conditions
            conditions = [
                EscalationORM.created_at >= start_date,
                EscalationORM.created_at <= end_date
            ]
            
            if queue_id:
                conditions.append(EscalationORM.queue_id == queue_id)
            
            # Get escalations in date range
            escalations = self.db_session.query(EscalationORM).filter(
                and_(*conditions)
            ).all()
            
            if not escalations:
                return self._get_empty_metrics()
            
            # Calculate metrics
            total_escalations = len(escalations)
            
            # Response time metrics
            response_times = [e.response_time_minutes for e in escalations if e.response_time_minutes]
            avg_response_time = statistics.mean(response_times) if response_times else 0.0
            
            # Resolution time metrics
            resolution_times = [e.resolution_time_minutes for e in escalations if e.resolution_time_minutes]
            avg_resolution_time = statistics.mean(resolution_times) if resolution_times else 0.0
            
            # Customer satisfaction
            satisfaction_scores = [e.satisfaction_score for e in escalations if e.satisfaction_score]
            customer_satisfaction = statistics.mean(satisfaction_scores) if satisfaction_scores else 0.0
            
            # Resolution rates
            resolved_escalations = [e for e in escalations if e.status == EscalationStatus.RESOLVED]
            resolution_rate = len(resolved_escalations) / total_escalations if total_escalations > 0 else 0.0
            
            # First contact resolution
            first_contact_resolutions = len([
                e for e in resolved_escalations 
                if e.resolution_time_minutes and e.resolution_time_minutes <= 30
            ])
            first_contact_rate = first_contact_resolutions / len(resolved_escalations) if resolved_escalations else 0.0
            
            # Abandonment rate
            cancelled_escalations = len([e for e in escalations if e.status == EscalationStatus.CANCELLED])
            abandonment_rate = cancelled_escalations / total_escalations if total_escalations > 0 else 0.0
            
            # Queue performance
            queue_performance = await self._get_queue_performance_metrics(start_date, end_date)
            
            return EscalationMetrics(
                date_range={'start': start_date, 'end': end_date},
                total_escalations=total_escalations,
                avg_response_time_minutes=avg_response_time,
                avg_resolution_time_minutes=avg_resolution_time,
                customer_satisfaction_avg=customer_satisfaction,
                escalation_rate=resolution_rate,
                first_contact_resolution_rate=first_contact_rate,
                abandoned_rate=abandonment_rate,
                queue_performance=queue_performance
            )
            
        except Exception as e:
            logger.error(f"Error calculating escalation metrics: {str(e)}")
            return self._get_empty_metrics()
    
    async def get_queue_performance(self) -> List[QueuePerformance]:
        """Get performance metrics for all queues."""
        
        if not self.db_session:
            return []
        
        try:
            import statistics
            from datetime import timedelta
            
            queues = self.db_session.query(EscalationQueueORM).all()
            performance_data = []
            
            for queue in queues:
                # Get recent escalations for this queue
                recent_escalations = self.db_session.query(EscalationORM).filter(
                    EscalationORM.queue_id == queue.id,
                    EscalationORM.created_at >= datetime.utcnow() - timedelta(days=30)
                ).all()
                
                if recent_escalations:
                    # Calculate metrics
                    resolved_escalations = [e for e in recent_escalations if e.status == EscalationStatus.RESOLVED]
                    
                    avg_response_time = statistics.mean([
                        e.response_time_minutes for e in resolved_escalations 
                        if e.response_time_minutes
                    ]) if resolved_escalations else 0.0
                    
                    avg_resolution_time = statistics.mean([
                        e.resolution_time_minutes for e in resolved_escalations 
                        if e.resolution_time_minutes
                    ]) if resolved_escalations else 0.0
                    
                    satisfaction_scores = [
                        e.satisfaction_score for e in resolved_escalations 
                        if e.satisfaction_score
                    ]
                    customer_satisfaction = statistics.mean(satisfaction_scores) if satisfaction_scores else 0.0
                    
                    utilization_rate = queue.current_load / queue.capacity if queue.capacity > 0 else 0.0
                    abandonment_rate = len([e for e in recent_escalations if e.status == EscalationStatus.CANCELLED]) / len(recent_escalations)
                    
                    # Simplified agent performance score
                    agent_performance_score = max(0.0, min(10.0, (
                        (5 - abandonment_rate * 5) +  # Lower abandonment = better
                        (satisfaction_score * 2 if satisfaction_scores else 0) +  # Higher satisfaction = better
                        (10 - avg_resolution_time / 6)  # Faster resolution = better
                    ) / 3))
                    
                    performance_data.append(QueuePerformance(
                        queue_id=queue.id,
                        queue_name=queue.name,
                        avg_response_time_minutes=avg_response_time,
                        avg_resolution_time_minutes=avg_resolution_time,
                        customer_satisfaction_score=customer_satisfaction,
                        utilization_rate=utilization_rate,
                        abandonment_rate=abandonment_rate,
                        agent_performance_score=agent_performance_score
                    ))
            
            return performance_data
            
        except Exception as e:
            logger.error(f"Error getting queue performance: {str(e)}")
            return []
    
    async def get_escalation_trends(
        self,
        days: int = 30
    ) -> Dict[str, Any]:
        """Get escalation trends and patterns."""
        
        if not self.db_session:
            return {}
        
        try:
            from datetime import timedelta
            from collections import defaultdict
            
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days)
            
            # Get escalations in period
            escalations = self.db_session.query(EscalationORM).filter(
                EscalationORM.created_at >= start_date,
                EscalationORM.created_at <= end_date
            ).all()
            
            if not escalations:
                return {}
            
            # Daily trends
            daily_trends = defaultdict(int)
            hourly_distribution = defaultdict(int)
            reason_distribution = defaultdict(int)
            priority_distribution = defaultdict(int)
            
            for escalation in escalations:
                # Daily trends
                date_key = escalation.created_at.date().isoformat()
                daily_trends[date_key] += 1
                
                # Hourly distribution
                hourly_distribution[escalation.created_at.hour] += 1
                
                # Reason distribution
                for reason in escalation.reasons:
                    reason_distribution[reason] += 1
                
                # Priority distribution
                priority_distribution[escalation.priority] += 1
            
            return {
                'daily_trends': [{'date': date, 'count': count} for date, count in sorted(daily_trends.items())],
                'hourly_distribution': dict(hourly_distribution),
                'reason_distribution': dict(reason_distribution),
                'priority_distribution': dict(priority_distribution),
                'total_escalations': len(escalations),
                'period_days': days
            }
            
        except Exception as e:
            logger.error(f"Error getting escalation trends: {str(e)}")
            return {}
    
    async def create_escalation_notification(
        self,
        escalation_id: UUID,
        notification_type: str,
        recipient_id: str,
        message: str,
        priority: EscalationPriority = EscalationPriority.MEDIUM
    ) -> bool:
        """
        Create escalation notification.
        
        Args:
            escalation_id: Escalation case ID
            notification_type: Type of notification
            recipient_id: Recipient ID
            message: Notification message
            priority: Notification priority
            
        Returns:
            bool: Success status
        """
        # This would integrate with your notification system
        # For now, we'll just log it
        logger.info(f"Escalation notification: {notification_type} for {recipient_id} - {message}")
        
        # In a real implementation, this would:
        # 1. Store notification in database
        # 2. Send via appropriate channel (email, SMS, Slack, etc.)
        # 3. Track delivery status
        
        return True
    
    async def should_escalate_with_reason(
        self,
        message: str,
        context: AgentContext,
        rag_results: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Get complete escalation decision with reasoning (legacy method).
        
        Args:
            message: Current message
            context: Conversation context
            rag_results: RAG search results
            
        Returns:
            Dictionary with escalation decision and details
        """
        decision = await self.get_escalation_decision(message, context, rag_results)
        
        return {
            "should_escalate": decision.should_escalate,
            "escalation_score": decision.escalation_score,
            "reasons": [reason.value for reason in decision.reasons],
            "recommended_queue_id": decision.recommended_queue_id,
            "priority_level": decision.priority_level.value,
            "urgency_score": decision.urgency_score,
            "confidence_score": decision.confidence_score,
            "complexity_assessment": decision.complexity_assessment,
            "alternative_actions": decision.alternative_actions,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    # Helper methods
    
    def _get_empty_metrics(self) -> EscalationMetrics:
        """Return empty metrics object."""
        return EscalationMetrics(
            date_range={'start': datetime.utcnow(), 'end': datetime.utcnow()},
            total_escalations=0,
            avg_response_time_minutes=0.0,
            avg_resolution_time_minutes=0.0,
            customer_satisfaction_avg=0.0,
            escalation_rate=0.0,
            first_contact_resolution_rate=0.0,
            abandoned_rate=0.0,
            queue_performance={}
        )
    
    async def _get_queue_performance_metrics(
        self,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Dict[str, float]]:
        """Get performance metrics by queue."""
        
        if not self.db_session:
            return {}
        
        try:
            import statistics
            
            # Get queues and their escalations
            queues = self.db_session.query(EscalationQueueORM).all()
            performance = {}
            
            for queue in queues:
                queue_escalations = self.db_session.query(EscalationORM).filter(
                    EscalationORM.queue_id == queue.id,
                    EscalationORM.created_at >= start_date,
                    EscalationORM.created_at <= end_date
                ).all()
                
                if queue_escalations:
                    resolved = [e for e in queue_escalations if e.status == EscalationStatus.RESOLVED]
                    avg_resolution_time = statistics.mean([
                        e.resolution_time_minutes for e in resolved if e.resolution_time_minutes
                    ]) if resolved else 0.0
                    
                    satisfaction_scores = [e.satisfaction_score for e in resolved if e.satisfaction_score]
                    avg_satisfaction = statistics.mean(satisfaction_scores) if satisfaction_scores else 0.0
                    
                    performance[queue.name] = {
                        'total_escalations': len(queue_escalations),
                        'resolved_escalations': len(resolved),
                        'avg_resolution_time_minutes': avg_resolution_time,
                        'customer_satisfaction_avg': avg_satisfaction,
                        'resolution_rate': len(resolved) / len(queue_escalations),
                        'current_load': queue.current_load,
                        'capacity': queue.capacity
                    }
            
            return performance
            
        except Exception as e:
            logger.error(f"Error getting queue performance metrics: {str(e)}")
            return {}