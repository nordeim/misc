"""
Tool utilities for factory patterns, validation, testing, and documentation.

Provides utility functions and classes for:
- Tool factory patterns and creation
- Tool validation and testing
- Tool documentation generation
- Tool performance optimization
"""

import asyncio
import logging
import inspect
import json
import time
from typing import (
    Any, Dict, List, Optional, Type, Union, Callable, 
    Tuple, Set, Protocol
)
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from abc import ABC, abstractmethod
from functools import wraps
import importlib
import pkgutil

from .base_tool import BaseTool, ToolMetadata, ToolError, ToolValidationError
from .registry import ToolRegistry, ToolRegistration
from .patterns import (
    RetryManager, AdvancedCircuitBreaker, MetricsCollector,
    VersionManager, RetryConfig, CircuitBreakerConfig
)


@dataclass
class ToolFactoryConfig:
    """Configuration for tool factory."""
    default_timeout: int = 300
    default_retries: int = 3
    circuit_breaker_enabled: bool = True
    metrics_enabled: bool = True
    auto_validation: bool = True
    pool_size: int = 10
    pre_warm: bool = False


@dataclass
class ToolValidationResult:
    """Result of tool validation."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    score: float = 0.0  # 0.0 to 1.0
    
    def add_error(self, message: str):
        """Add validation error."""
        self.errors.append(message)
        self.is_valid = False
    
    def add_warning(self, message: str):
        """Add validation warning."""
        self.warnings.append(message)
    
    def calculate_score(self):
        """Calculate validation score based on errors and warnings."""
        base_score = 1.0
        base_score -= len(self.errors) * 0.2  # Each error reduces score by 20%
        base_score -= len(self.warnings) * 0.05  # Each warning reduces score by 5%
        self.score = max(0.0, base_score)
        return self.score


@dataclass
class ToolTestResult:
    """Result of tool testing."""
    tool_name: str
    test_name: str
    passed: bool
    execution_time_ms: float
    error: Optional[str] = None
    output: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class ToolValidator(ABC):
    """Abstract base class for tool validators."""
    
    @abstractmethod
    async def validate(self, tool: BaseTool) -> ToolValidationResult:
        """Validate a tool instance."""
        pass


class ToolFactory:
    """Advanced tool factory with configuration and lifecycle management."""
    
    def __init__(self, config: Optional[ToolFactoryConfig] = None):
        self.config = config or ToolFactoryConfig()
        self.logger = logging.getLogger("tool.factory")
        self._tool_cache: Dict[str, BaseTool] = {}
        self._factories: Dict[str, Callable] = {}
        self._registrations: Dict[str, ToolRegistration] = {}
        
        # Pattern managers
        self.retry_manager = RetryManager()
        self.circuit_breaker = AdvancedCircuitBreaker()
        self.metrics_collector = MetricsCollector()
        self.version_manager = VersionManager()
    
    def register_factory(self, tool_name: str, factory: Callable[[], BaseTool]):
        """Register a tool factory function."""
        self._factories[tool_name] = factory
        self.logger.info(f"Registered factory for tool: {tool_name}")
    
    def create_tool(
        self,
        tool_name: str,
        config: Optional[Dict[str, Any]] = None,
        pre_warm: bool = None
    ) -> BaseTool:
        """
        Create a tool instance using registered factory or class.
        
        Args:
            tool_name: Name of the tool to create
            config: Tool configuration
            pre_warm: Whether to pre-warm the tool (initialize immediately)
            
        Returns:
            Created tool instance
        """
        # Check cache first
        cache_key = f"{tool_name}:{hash(json.dumps(config or {}, sort_keys=True))}"
        
        if cache_key in self._tool_cache and not pre_warm:
            return self._tool_cache[cache_key]
        
        # Get factory or create from class
        factory = self._factories.get(tool_name)
        if factory:
            tool = factory()
        else:
            raise ToolError(f"No factory registered for tool: {tool_name}")
        
        # Apply configuration
        if config:
            tool.update_config(config)
        
        # Pre-warm if requested
        if pre_warm if pre_warm is not None else self.config.pre_warm:
            try:
                # Run async initialization in sync context
                if hasattr(tool, 'initialize') and asyncio.iscoroutinefunction(tool.initialize):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        loop.run_until_complete(tool.initialize())
                    finally:
                        loop.close()
                elif hasattr(tool, 'initialize'):
                    tool.initialize()
            except Exception as e:
                self.logger.warning(f"Failed to pre-warm tool {tool_name}: {e}")
        
        # Cache the tool
        self._tool_cache[cache_key] = tool
        return tool
    
    def create_tool_pool(
        self,
        tool_name: str,
        size: int,
        config: Optional[Dict[str, Any]] = None
    ) -> List[BaseTool]:
        """Create a pool of tool instances."""
        pool = []
        for i in range(size):
            instance_config = config.copy() if config else {}
            instance_config['instance_id'] = f"{tool_name}-{i}"
            pool.append(self.create_tool(tool_name, instance_config))
        
        return pool
    
    def warm_tool(self, tool: BaseTool) -> bool:
        """Warm up a tool by initializing it."""
        try:
            if hasattr(tool, 'initialize'):
                if asyncio.iscoroutinefunction(tool.initialize):
                    # Run async initialization
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(tool.initialize())
                        return result
                    finally:
                        loop.close()
                else:
                    return tool.initialize()
            return True
        except Exception as e:
            self.logger.error(f"Failed to warm tool {tool.name}: {e}")
            return False
    
    def clear_cache(self):
        """Clear the tool cache."""
        self._tool_cache.clear()
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "cached_tools": len(self._tool_cache),
            "registered_factories": len(self._factories),
            "cache_keys": list(self._tool_cache.keys())
        }


class ToolValidatorRegistry:
    """Registry for tool validators."""
    
    def __init__(self):
        self._validators: Dict[str, ToolValidator] = {}
        self.logger = logging.getLogger("tool.validator")
    
    def register_validator(self, validation_type: str, validator: ToolValidator):
        """Register a validator for a specific validation type."""
        self._validators[validation_type] = validator
    
    async def validate_tool(self, tool: BaseTool, validation_types: Optional[List[str]] = None) -> ToolValidationResult:
        """Validate a tool using registered validators."""
        result = ToolValidationResult(is_valid=True)
        
        validation_types = validation_types or list(self._validators.keys())
        
        for validation_type in validation_types:
            if validation_type in self._validators:
                try:
                    validator_result = await self._validators[validation_type].validate(tool)
                    
                    # Merge results
                    if not validator_result.is_valid:
                        result.is_valid = False
                    
                    result.errors.extend(validator_result.errors)
                    result.warnings.extend(validator_result.warnings)
                    
                except Exception as e:
                    result.add_error(f"Validation error ({validation_type}): {str(e)}")
        
        result.calculate_score()
        return result
    
    def get_available_validators(self) -> List[str]:
        """Get list of available validator types."""
        return list(self._validators.keys())


class BasicToolValidator(ToolValidator):
    """Basic validator that checks tool structure and basic functionality."""
    
    async def validate(self, tool: BaseTool) -> ToolValidationResult:
        """Perform basic validation of a tool."""
        result = ToolValidationResult(is_valid=True)
        
        # Check required attributes
        if not hasattr(tool, 'name') or not tool.name:
            result.add_error("Tool must have a non-empty 'name' attribute")
        
        if not hasattr(tool, 'execute'):
            result.add_error("Tool must have an 'execute' method")
        
        # Check execute method signature
        if hasattr(tool, 'execute'):
            sig = inspect.signature(tool.execute)
            if len(sig.parameters) == 0:
                result.add_warning("Tool execute method should accept parameters")
        
        # Check metadata
        if hasattr(tool, 'metadata'):
            metadata = tool.metadata
            if not metadata.description:
                result.add_warning("Tool metadata should have a description")
        
        # Check initialization and health check
        try:
            if hasattr(tool, 'initialize'):
                if asyncio.iscoroutinefunction(tool.initialize):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        init_result = loop.run_until_complete(tool.initialize())
                        if not init_result:
                            result.add_warning("Tool initialization returned False")
                    finally:
                        loop.close()
                else:
                    init_result = tool.initialize()
                    if not init_result:
                        result.add_warning("Tool initialization returned False")
            
            if hasattr(tool, 'health_check'):
                if asyncio.iscoroutinefunction(tool.health_check):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        health_result = loop.run_until_complete(tool.health_check())
                        if not health_result:
                            result.add_warning("Tool health check returned False")
                    finally:
                        loop.close()
                else:
                    health_result = tool.health_check()
                    if not health_result:
                        result.add_warning("Tool health check returned False")
        
        except Exception as e:
            result.add_error(f"Basic validation failed: {str(e)}")
        
        result.calculate_score()
        return result


class PerformanceToolValidator(ToolValidator):
    """Validator that checks tool performance characteristics."""
    
    def __init__(self, max_execution_time_ms: float = 5000):
        self.max_execution_time_ms = max_execution_time_ms
    
    async def validate(self, tool: BaseTool) -> ToolValidationResult:
        """Validate tool performance."""
        result = ToolValidationResult(is_valid=True)
        
        try:
            # Test execution performance
            start_time = time.time()
            
            if hasattr(tool, 'execute'):
                if asyncio.iscoroutinefunction(tool.execute):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        await asyncio.wait_for(tool.execute(), timeout=10.0)
                    finally:
                        loop.close()
                else:
                    # For sync methods, run with timeout
                    import signal
                    signal.alarm(10)  # 10 second timeout
                    try:
                        tool.execute()
                    finally:
                        signal.alarm(0)
            
            execution_time = (time.time() - start_time) * 1000
            
            if execution_time > self.max_execution_time_ms:
                result.add_warning(f"Tool execution time {execution_time:.2f}ms exceeds threshold {self.max_execution_time_ms}ms")
            
            if execution_time > 10000:  # 10 seconds
                result.add_error(f"Tool execution time {execution_time:.2f}ms is too slow")
        
        except asyncio.TimeoutError:
            result.add_error("Tool execution timed out during performance validation")
        except Exception as e:
            result.add_error(f"Performance validation failed: {str(e)}")
        
        result.calculate_score()
        return result


class ToolTester:
    """Tool testing framework with multiple test types."""
    
    def __init__(self, factory: ToolFactory):
        self.factory = factory
        self.logger = logging.getLogger("tool.tester")
        self.test_results: List[ToolTestResult] = []
    
    async def run_basic_tests(self, tool: BaseTool) -> List[ToolTestResult]:
        """Run basic tests on a tool."""
        results = []
        
        # Test 1: Initialization
        result = await self._test_initialization(tool)
        results.append(result)
        
        # Test 2: Health check
        result = await self._test_health_check(tool)
        results.append(result)
        
        # Test 3: Basic execution
        result = await self._test_basic_execution(tool)
        results.append(result)
        
        self.test_results.extend(results)
        return results
    
    async def run_performance_tests(self, tool: BaseTool, iterations: int = 10) -> List[ToolTestResult]:
        """Run performance tests on a tool."""
        results = []
        
        start_time = time.time()
        
        for i in range(iterations):
            test_start = time.time()
            try:
                if hasattr(tool, 'execute'):
                    if asyncio.iscoroutinefunction(tool.execute):
                        await tool.execute()
                    else:
                        tool.execute()
                
                execution_time = (time.time() - test_start) * 1000
                
                result = ToolTestResult(
                    tool_name=tool.name,
                    test_name=f"performance_iteration_{i}",
                    passed=True,
                    execution_time_ms=execution_time,
                    output={"iteration": i, "execution_time_ms": execution_time}
                )
                
            except Exception as e:
                execution_time = (time.time() - test_start) * 1000
                
                result = ToolTestResult(
                    tool_name=tool.name,
                    test_name=f"performance_iteration_{i}",
                    passed=False,
                    execution_time_ms=execution_time,
                    error=str(e)
                )
            
            results.append(result)
        
        total_time = (time.time() - start_time) * 1000
        self.test_results.extend(results)
        return results
    
    async def run_resilience_tests(self, tool: BaseTool) -> List[ToolTestResult]:
        """Run resilience tests on a tool."""
        results = []
        
        # Test with invalid inputs
        test_cases = [
            ("empty_args", []),
            ("none_args", [None]),
            ("invalid_types", ["invalid", 123, {}]),
        ]
        
        for test_name, args in test_cases:
            test_start = time.time()
            
            try:
                if hasattr(tool, 'execute'):
                    if asyncio.iscoroutinefunction(tool.execute):
                        await tool.execute(*args)
                    else:
                        tool.execute(*args)
                
                execution_time = (time.time() - test_start) * 1000
                
                result = ToolTestResult(
                    tool_name=tool.name,
                    test_name=f"resilience_{test_name}",
                    passed=True,
                    execution_time_ms=execution_time,
                    output={"args": args}
                )
                
            except Exception as e:
                execution_time = (time.time() - test_start) * 1000
                
                # Some exceptions are expected for invalid inputs
                passed = isinstance(e, (ToolError, ValueError, TypeError, AttributeError))
                
                result = ToolTestResult(
                    tool_name=tool.name,
                    test_name=f"resilience_{test_name}",
                    passed=passed,
                    execution_time_ms=execution_time,
                    error=str(e),
                    metadata={"expected_failure": not passed}
                )
            
            results.append(result)
        
        self.test_results.extend(results)
        return results
    
    async def _test_initialization(self, tool: BaseTool) -> ToolTestResult:
        """Test tool initialization."""
        start_time = time.time()
        
        try:
            if hasattr(tool, 'initialize'):
                if asyncio.iscoroutinefunction(tool.initialize):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(tool.initialize())
                    finally:
                        loop.close()
                else:
                    result = tool.initialize()
                
                success = result is not False  # Accept True or None
                execution_time = (time.time() - start_time) * 1000
                
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="initialization",
                    passed=success,
                    execution_time_ms=execution_time,
                    output=result
                )
            else:
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="initialization",
                    passed=True,  # No initialize method is OK
                    execution_time_ms=(time.time() - start_time) * 1000,
                    output="No initialize method"
                )
        
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            
            return ToolTestResult(
                tool_name=tool.name,
                test_name="initialization",
                passed=False,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def _test_health_check(self, tool: BaseTool) -> ToolTestResult:
        """Test tool health check."""
        start_time = time.time()
        
        try:
            if hasattr(tool, 'health_check'):
                if asyncio.iscoroutinefunction(tool.health_check):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(tool.health_check())
                    finally:
                        loop.close()
                else:
                    result = tool.health_check()
                
                success = result is True
                execution_time = (time.time() - start_time) * 1000
                
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="health_check",
                    passed=success,
                    execution_time_ms=execution_time,
                    output=result
                )
            else:
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="health_check",
                    passed=True,  # No health_check method is OK
                    execution_time_ms=(time.time() - start_time) * 1000,
                    output="No health_check method"
                )
        
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            
            return ToolTestResult(
                tool_name=tool.name,
                test_name="health_check",
                passed=False,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    async def _test_basic_execution(self, tool: BaseTool) -> ToolTestResult:
        """Test basic tool execution."""
        start_time = time.time()
        
        try:
            if hasattr(tool, 'execute'):
                if asyncio.iscoroutinefunction(tool.execute):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(tool.execute())
                    finally:
                        loop.close()
                else:
                    result = tool.execute()
                
                execution_time = (time.time() - start_time) * 1000
                
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="basic_execution",
                    passed=True,
                    execution_time_ms=execution_time,
                    output=str(result)[:100]  # Truncate output for logging
                )
            else:
                return ToolTestResult(
                    tool_name=tool.name,
                    test_name="basic_execution",
                    passed=False,
                    execution_time_ms=(time.time() - start_time) * 1000,
                    error="No execute method found"
                )
        
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            
            return ToolTestResult(
                tool_name=tool.name,
                test_name="basic_execution",
                passed=False,
                execution_time_ms=execution_time,
                error=str(e)
            )
    
    def get_test_summary(self) -> Dict[str, Any]:
        """Get summary of all test results."""
        if not self.test_results:
            return {"message": "No tests run"}
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result.passed)
        failed_tests = total_tests - passed_tests
        
        avg_execution_time = sum(result.execution_time_ms for result in self.test_results) / total_tests
        
        by_tool = {}
        for result in self.test_results:
            if result.tool_name not in by_tool:
                by_tool[result.tool_name] = {"passed": 0, "failed": 0, "total": 0}
            
            by_tool[result.tool_name]["total"] += 1
            if result.passed:
                by_tool[result.tool_name]["passed"] += 1
            else:
                by_tool[result.tool_name]["failed"] += 1
        
        return {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "pass_rate": passed_tests / total_tests if total_tests > 0 else 0,
            "average_execution_time_ms": avg_execution_time,
            "by_tool": by_tool,
            "detailed_results": self.test_results
        }


class ToolDocumentationGenerator:
    """Generates documentation for tools."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.docs")
    
    def generate_tool_documentation(self, tool: BaseTool) -> Dict[str, Any]:
        """Generate comprehensive documentation for a tool."""
        
        # Get basic information
        doc = {
            "name": tool.name,
            "version": getattr(tool, 'version', '1.0.0'),
            "class": tool.__class__.__name__,
            "module": tool.__class__.__module__,
        }
        
        # Get metadata
        if hasattr(tool, 'metadata'):
            metadata = tool.metadata
            doc.update({
                "description": metadata.description,
                "category": metadata.category,
                "tags": metadata.tags,
                "dependencies": metadata.dependencies,
                "timeout_seconds": metadata.timeout_seconds,
                "max_retries": metadata.max_retries,
            })
        
        # Get execute method signature
        if hasattr(tool, 'execute'):
            execute_method = getattr(tool, 'execute')
            doc["execute_method"] = self._analyze_method(execute_method)
        
        # Get all public methods
        methods = {}
        for name in dir(tool):
            if not name.startswith('_') and callable(getattr(tool, name)):
                method = getattr(tool, name)
                methods[name] = self._analyze_method(method)
        
        doc["methods"] = methods
        
        # Get configuration schema
        if hasattr(tool, 'metadata') and tool.metadata.config_schema:
            doc["configuration_schema"] = tool.metadata.config_schema
        elif hasattr(tool, 'config'):
            doc["current_configuration"] = tool.config
        
        # Get metrics
        if hasattr(tool, 'metrics'):
            doc["metrics"] = tool.get_metrics()
        
        return doc
    
    def _analyze_method(self, method: Callable) -> Dict[str, Any]:
        """Analyze a method and extract documentation."""
        info = {
            "name": method.__name__,
            "docstring": inspect.getdoc(method) or "No documentation available",
            "signature": str(inspect.signature(method)),
        }
        
        # Check if async
        info["is_async"] = asyncio.iscoroutinefunction(method)
        
        # Get parameter information
        try:
            sig = inspect.signature(method)
            parameters = []
            
            for param_name, param in sig.parameters.items():
                param_info = {
                    "name": param_name,
                    "kind": str(param.kind),
                }
                
                if param.annotation != inspect.Parameter.empty:
                    param_info["annotation"] = str(param.annotation)
                
                if param.default != inspect.Parameter.empty:
                    param_info["default"] = str(param.default)
                
                parameters.append(param_info)
            
            info["parameters"] = parameters
            
            # Return type
            if sig.return_annotation != inspect.Signature.empty:
                info["return_type"] = str(sig.return_annotation)
        
        except Exception as e:
            info["parameter_analysis_error"] = str(e)
        
        return info
    
    def generate_api_documentation(self, tools: List[BaseTool]) -> Dict[str, Any]:
        """Generate API documentation for multiple tools."""
        doc = {
            "generated_at": datetime.utcnow().isoformat(),
            "total_tools": len(tools),
            "tools": []
        }
        
        for tool in tools:
            tool_doc = self.generate_tool_documentation(tool)
            doc["tools"].append(tool_doc)
        
        return doc
    
    def export_to_markdown(self, documentation: Dict[str, Any], output_path: Path) -> bool:
        """Export documentation to Markdown format."""
        try:
            markdown_lines = []
            
            # Header
            markdown_lines.append(f"# Tool API Documentation")
            markdown_lines.append("")
            markdown_lines.append(f"Generated: {documentation.get('generated_at', 'Unknown')}")
            markdown_lines.append(f"Total Tools: {documentation.get('total_tools', 0)}")
            markdown_lines.append("")
            
            # Tools
            for tool_doc in documentation.get('tools', []):
                markdown_lines.append(f"## {tool_doc['name']} (v{tool_doc['version']})")
                markdown_lines.append("")
                markdown_lines.append(f"**Class:** `{tool_doc['class']}`")
                markdown_lines.append("")
                
                if 'description' in tool_doc:
                    markdown_lines.append(f"**Description:** {tool_doc['description']}")
                    markdown_lines.append("")
                
                if 'category' in tool_doc:
                    markdown_lines.append(f"**Category:** {tool_doc['category']}")
                
                if tool_doc.get('tags'):
                    markdown_lines.append(f"**Tags:** {', '.join(tool_doc['tags'])}")
                
                markdown_lines.append("")
                
                # Execute method
                if 'execute_method' in tool_doc:
                    execute_method = tool_doc['execute_method']
                    markdown_lines.append("### Execute Method")
                    markdown_lines.append("")
                    markdown_lines.append(f"```python")
                    markdown_lines.append(f"async def execute{execute_method['signature']}")
                    markdown_lines.append(f"```")
                    markdown_lines.append("")
                    
                    if execute_method.get('docstring'):
                        markdown_lines.append(execute_method['docstring'])
                        markdown_lines.append("")
                
                # Configuration
                if 'configuration_schema' in tool_doc:
                    markdown_lines.append("### Configuration Schema")
                    markdown_lines.append("```json")
                    markdown_lines.append(json.dumps(tool_doc['configuration_schema'], indent=2))
                    markdown_lines.append("```")
                    markdown_lines.append("")
                
                # Other methods
                if tool_doc.get('methods'):
                    markdown_lines.append("### Other Methods")
                    markdown_lines.append("")
                    
                    for method_name, method_info in tool_doc['methods'].items():
                        if method_name == 'execute':
                            continue
                        
                        markdown_lines.append(f"#### {method_name}")
                        markdown_lines.append("")
                        markdown_lines.append(f"`{method_name}{method_info['signature']}`")
                        markdown_lines.append("")
                        
                        if method_info.get('docstring'):
                            markdown_lines.append(method_info['docstring'])
                            markdown_lines.append("")
                
                markdown_lines.append("---")
                markdown_lines.append("")
            
            # Write to file
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text("\n".join(markdown_lines), encoding='utf-8')
            
            return True
        
        except Exception as e:
            self.logger.error(f"Failed to export documentation to {output_path}: {e}")
            return False


class ToolOptimizer:
    """Optimizes tool performance and resource usage."""
    
    def __init__(self):
        self.logger = logging.getLogger("tool.optimizer")
    
    async def optimize_tool(self, tool: BaseTool) -> Dict[str, Any]:
        """Optimize a tool instance."""
        optimizations = []
        
        # Optimize configuration
        config_optimizations = await self._optimize_config(tool)
        optimizations.extend(config_optimizations)
        
        # Optimize initialization
        init_optimizations = await self._optimize_initialization(tool)
        optimizations.extend(init_optimizations)
        
        # Optimize execution patterns
        execution_optimizations = await self._optimize_execution(tool)
        optimizations.extend(execution_optimizations)
        
        return {
            "tool_name": tool.name,
            "optimizations_applied": len(optimizations),
            "optimizations": optimizations
        }
    
    async def _optimize_config(self, tool: BaseTool) -> List[str]:
        """Optimize tool configuration."""
        optimizations = []
        
        if hasattr(tool, 'metadata'):
            metadata = tool.metadata
            
            # Suggest timeout optimization
            if metadata.timeout_seconds > 300:  # > 5 minutes
                optimizations.append(
                    f"Consider reducing timeout from {metadata.timeout_seconds}s to 300s for better resource usage"
                )
            
            # Suggest retry optimization
            if metadata.max_retries > 5:
                optimizations.append(
                    f"Consider reducing retries from {metadata.max_retries} to 3-5 to avoid cascading failures"
                )
        
        return optimizations
    
    async def _optimize_initialization(self, tool: BaseTool) -> List[str]:
        """Optimize tool initialization."""
        optimizations = []
        
        # Check if tool can be pre-warmed
        if hasattr(tool, 'initialize'):
            optimizations.append("Enable pre-warming for this tool to reduce first-use latency")
        
        # Check if health checks are too frequent
        if hasattr(tool, 'metadata') and tool.metadata.health_check_interval_seconds < 60:
            optimizations.append("Consider increasing health check interval to reduce overhead")
        
        return optimizations
    
    async def _optimize_execution(self, tool: BaseTool) -> List[str]:
        """Optimize tool execution patterns."""
        optimizations = []
        
        # Check execution metrics if available
        if hasattr(tool, 'metrics'):
            metrics = tool.metrics
            
            # High error rate optimization
            if metrics.error_rate > 0.1:  # > 10% error rate
                optimizations.append("High error rate detected - review error handling and add retry logic")
            
            # Slow execution optimization
            if metrics.average_execution_time_ms > 5000:  # > 5 seconds
                optimizations.append("Slow execution detected - consider caching or async optimization")
        
        return optimizations
    
    def suggest_resource_limits(self, tool: BaseTool) -> Dict[str, Any]:
        """Suggest resource limits for a tool based on its characteristics."""
        limits = {}
        
        if hasattr(tool, 'metadata'):
            metadata = tool.metadata
            
            # Memory limits based on tool category
            if metadata.category in ['computation', 'ml', 'processing']:
                limits['memory_mb'] = 1024  # 1GB
            elif metadata.category in ['api', 'service']:
                limits['memory_mb'] = 512   # 512MB
            else:
                limits['memory_mb'] = 256   # 256MB
            
            # CPU limits based on expected workload
            if metadata.category in ['computation', 'ml', 'processing']:
                limits['cpu_percent'] = 80
            else:
                limits['cpu_percent'] = 50
        
        return limits


# Global instances
_global_factory = ToolFactory()
_global_validator_registry = ToolValidatorRegistry()
_global_tester = None  # Initialized per use case
_global_doc_generator = ToolDocumentationGenerator()
_global_optimizer = ToolOptimizer()


def get_global_utilities() -> Dict[str, Any]:
    """Get global utility instances."""
    return {
        "factory": _global_factory,
        "validator_registry": _global_validator_registry,
        "doc_generator": _global_doc_generator,
        "optimizer": _global_optimizer
    }


# Initialize default validators
_global_validator_registry.register_validator("basic", BasicToolValidator())
_global_validator_registry.register_validator("performance", PerformanceToolValidator())
