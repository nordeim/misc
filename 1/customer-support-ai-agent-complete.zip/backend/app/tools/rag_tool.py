"""
Retrieval-Augmented Generation (RAG) Tool with ChromaDB Integration.

This module provides comprehensive RAG functionality including:
- Document processing and chunking
- Embedding generation and caching
- Vector database operations
- Semantic and hybrid search
- Performance optimization

Key Components:
- DocumentProcessor: Handles document parsing and chunking
- EmbeddingService: Manages embedding generation and caching
- ChromaDBManager: Handles vector database operations
- SearchEngine: Provides semantic and hybrid search
- RAGTool: Main interface for RAG operations
"""

import asyncio
import hashlib
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union, Iterator
from dataclasses import dataclass, asdict
from functools import lru_cache
import uuid

import chromadb
from chromadb.config import Settings
from chromadb.api.models.Collection import Collection
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import tiktoken
from redis import asyncio as aioredis

from app.config import settings

# Configure logging
logger = logging.getLogger(__name__)

# Constants
MAX_BATCH_SIZE = 100
CACHE_TTL = 3600
EMBEDDING_CACHE_KEY = "embedding_cache"
SEARCH_CACHE_PREFIX = "search_cache"

# ==============================================================================
# DATA STRUCTURES
# ==============================================================================

@dataclass
class DocumentChunk:
    """Represents a document chunk with metadata."""
    id: str
    content: str
    metadata: Dict[str, Any]
    embedding: Optional[List[float]] = None
    chunk_index: int = 0
    start_char: int = 0
    end_char: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DocumentChunk':
        """Create from dictionary."""
        return cls(**data)


@dataclass
class SearchResult:
    """Represents a search result."""
    content: str
    metadata: Dict[str, Any]
    similarity_score: float
    vector_score: float = 0.0
    keyword_score: float = 0.0
    combined_score: float = 0.0
    rank: int = 0
    chunk_id: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class ProcessingStats:
    """Statistics for document processing."""
    total_documents: int = 0
    total_chunks: int = 0
    processing_time: float = 0.0
    average_chunk_size: float = 0.0
    embedding_time: float = 0.0
    storage_time: float = 0.0
    errors: List[str] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


# ==============================================================================
# DOCUMENT PROCESSOR
# ==============================================================================

class DocumentProcessor:
    """Handles document parsing, chunking, and preprocessing."""
    
    def __init__(self):
        self.chunk_size = settings.rag_chunk_size
        self.chunk_overlap = settings.rag_chunk_overlap
        self.supported_formats = settings.document_supported_formats
        
    def chunk_document(self, content: str, metadata: Dict[str, Any] = None) -> List[DocumentChunk]:
        """
        Split document into overlapping chunks.
        
        Args:
            content: Document content
            metadata: Document metadata
            
        Returns:
            List of document chunks
        """
        if metadata is None:
            metadata = {}
            
        chunks = []
        content_length = len(content)
        
        # Clean content
        content = self._clean_content(content)
        
        # Split into chunks
        start = 0
        chunk_index = 0
        
        while start < content_length:
            end = start + self.chunk_size
            
            # Try to break at sentence boundaries
            if end < content_length:
                # Look for sentence endings near the end
                sentence_end = self._find_sentence_boundary(content, start, end)
                if sentence_end > start + self.chunk_size * 0.5:  # Don't create too small chunks
                    end = sentence_end
            
            chunk_content = content[start:end].strip()
            
            if chunk_content:
                chunk_id = str(uuid.uuid4())
                chunk = DocumentChunk(
                    id=chunk_id,
                    content=chunk_content,
                    metadata=metadata.copy(),
                    chunk_index=chunk_index,
                    start_char=start,
                    end_char=end
                )
                chunks.append(chunk)
                
                # Move start position with overlap
                start = end - self.chunk_overlap
                chunk_index += 1
            else:
                break
        
        logger.info(f"Created {len(chunks)} chunks from document of {content_length} characters")
        return chunks
    
    def _clean_content(self, content: str) -> str:
        """Clean and preprocess document content."""
        # Remove excessive whitespace
        content = re.sub(r'\s+', ' ', content)
        
        # Remove control characters except newlines and tabs
        content = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', content)
        
        # Normalize line endings
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        
        return content.strip()
    
    def _find_sentence_boundary(self, content: str, start: int, end: int) -> int:
        """Find a good sentence boundary near the end position."""
        # Look for sentence endings in the last 20% of the chunk
        search_start = max(start, end - self.chunk_size // 5)
        search_region = content[search_start:end]
        
        # Try different sentence endings
        sentence_endings = ['.', '!', '?', '\n\n']
        
        for ending in sentence_endings:
            pos = search_region.rfind(ending)
            if pos != -1:
                return search_start + pos + len(ending)
        
        # Fallback to word boundary
        words = search_region.split()
        if len(words) > 1:
            return search_start + len(' '.join(words[:-1])) + 1
        
        return end
    
    def extract_metadata(self, content: str, source_path: str = None) -> Dict[str, Any]:
        """Extract metadata from document content and source."""
        metadata = {}
        
        if source_path:
            path_obj = Path(source_path)
            metadata.update({
                'source_file': path_obj.name,
                'source_path': str(path_obj),
                'file_extension': path_obj.suffix.lower().lstrip('.'),
                'file_size': path_obj.stat().st_size if path_obj.exists() else 0
            })
        
        # Extract additional metadata from content
        metadata.update({
            'content_length': len(content),
            'word_count': len(content.split()),
            'line_count': len(content.split('\n')),
            'processed_at': time.time()
        })
        
        return metadata
    
    def validate_document(self, content: str, source_path: str = None) -> Tuple[bool, str]:
        """Validate document for processing."""
        # Check content length
        if len(content) < 10:
            return False, "Document too short (minimum 10 characters)"
        
        # Check maximum size
        if len(content) > settings.document_max_size_bytes:
            return False, f"Document too large (maximum {settings.document_max_size_mb}MB)"
        
        # Check if mostly whitespace
        non_whitespace = len(re.sub(r'\s', '', content))
        if non_whitespace / len(content) < 0.1:
            return False, "Document contains too much whitespace"
        
        # Check file format if path provided
        if source_path:
            path_obj = Path(source_path)
            if path_obj.suffix.lower().lstrip('.') not in self.supported_formats:
                return False, f"Unsupported file format: {path_obj.suffix}"
        
        return True, "Valid"


# ==============================================================================
# EMBEDDING SERVICE
# ==============================================================================

class EmbeddingService:
    """Handles embedding generation with caching and optimization."""
    
    def __init__(self):
        self.model_name = settings.embedding_model
        self.batch_size = settings.embedding_batch_size
        self.model = None
        self.cache = {}
        self.redis_client = None
        
        # Initialize Redis if available
        try:
            if settings.redis_url:
                self.redis_client = aioredis.from_url(settings.redis_url)
        except Exception as e:
            logger.warning(f"Failed to initialize Redis for embedding cache: {e}")
    
    async def initialize(self):
        """Initialize the embedding model."""
        if self.model is None:
            logger.info(f"Loading embedding model: {self.model_name}")
            try:
                self.model = SentenceTransformer(self.model_name)
                logger.info(f"Embedding model loaded successfully")
            except Exception as e:
                logger.error(f"Failed to load embedding model: {e}")
                raise
    
    async def generate_embedding(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        # Check cache first
        cache_key = self._get_cache_key(text)
        
        # Check memory cache
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        # Check Redis cache
        if self.redis_client:
            try:
                cached = await self.redis_client.get(f"{EMBEDDING_CACHE_KEY}:{cache_key}")
                if cached:
                    embedding = json.loads(cached)
                    self.cache[cache_key] = embedding
                    return embedding
            except Exception as e:
                logger.warning(f"Redis cache lookup failed: {e}")
        
        # Generate embedding
        if self.model is None:
            await self.initialize()
        
        embedding = self.model.encode(text).tolist()
        
        # Cache the result
        self.cache[cache_key] = embedding
        if len(self.cache) > 1000:  # Limit memory cache size
            # Remove oldest entries
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
        
        if self.redis_client:
            try:
                await self.redis_client.setex(
                    f"{EMBEDDING_CACHE_KEY}:{cache_key}",
                    CACHE_TTL,
                    json.dumps(embedding)
                )
            except Exception as e:
                logger.warning(f"Redis cache storage failed: {e}")
        
        return embedding
    
    async def generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for multiple texts in batches."""
        if not texts:
            return []
        
        # Check cache for each text
        embeddings = []
        texts_to_process = []
        indices_to_process = []
        
        for i, text in enumerate(texts):
            cache_key = self._get_cache_key(text)
            
            # Check memory cache first
            if cache_key in self.cache:
                embeddings.append(self.cache[cache_key])
            else:
                # Check Redis cache asynchronously
                texts_to_process.append(text)
                indices_to_process.append(i)
                embeddings.append(None)  # Placeholder
        
        # Process uncached texts
        if texts_to_process:
            if self.model is None:
                await self.initialize()
            
            # Process in batches
            for i in range(0, len(texts_to_process), self.batch_size):
                batch = texts_to_process[i:i + self.batch_size]
                batch_embeddings = self.model.encode(batch).tolist()
                
                # Cache and fill results
                for j, embedding in enumerate(batch_embeddings):
                    original_index = indices_to_process[i + j]
                    embeddings[original_index] = embedding
                    
                    # Cache the embedding
                    cache_key = self._get_cache_key(batch[j])
                    self.cache[cache_key] = embedding
                    
                    if self.redis_client:
                        try:
                            await self.redis_client.setex(
                                f"{EMBEDDING_CACHE_KEY}:{cache_key}",
                                CACHE_TTL,
                                json.dumps(embedding)
                            )
                        except Exception as e:
                            logger.warning(f"Redis cache storage failed: {e}")
        
        return embeddings
    
    def _get_cache_key(self, text: str) -> str:
        """Generate cache key for text."""
        return hashlib.md5(text.encode()).hexdigest()
    
    async def close(self):
        """Cleanup resources."""
        if self.redis_client:
            await self.redis_client.close()


# ==============================================================================
# CHROMADB MANAGER
# ==============================================================================

class ChromaDBManager:
    """Manages ChromaDB operations and optimization."""
    
    def __init__(self):
        self.persist_directory = settings.chroma_persist_directory
        self.collection_name = settings.chroma_collection_name
        self.client = None
        self.collection = None
        
    async def initialize(self):
        """Initialize ChromaDB client and collection."""
        try:
            # Create persistent client
            self.client = chromadb.PersistentClient(path=str(self.persist_directory))
            
            # Get or create collection
            self.collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={
                    "description": "Customer support knowledge base with RAG",
                    "version": "2.0",
                    "created_at": time.time(),
                    "embedding_model": settings.embedding_model
                }
            )
            
            logger.info(f"ChromaDB initialized with collection: {self.collection_name}")
            
        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB: {e}")
            raise
    
    async def add_documents(self, chunks: List[DocumentChunk], embeddings: List[List[float]]) -> List[str]:
        """Add document chunks to the collection."""
        if not chunks or len(chunks) != len(embeddings):
            raise ValueError("Number of chunks and embeddings must match")
        
        # Prepare data for ChromaDB
        documents = [chunk.content for chunk in chunks]
        metadatas = [chunk.metadata for chunk in chunks]
        ids = [chunk.id for chunk in chunks]
        
        try:
            # Add to collection
            self.collection.add(
                documents=documents,
                metadatas=metadatas,
                embeddings=embeddings,
                ids=ids
            )
            
            logger.info(f"Added {len(chunks)} documents to ChromaDB")
            return ids
            
        except Exception as e:
            logger.error(f"Failed to add documents to ChromaDB: {e}")
            raise
    
    async def search(
        self,
        query_embedding: List[float],
        n_results: int = 5,
        filter_metadata: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Search for similar documents using vector similarity."""
        try:
            where_clause = None
            if filter_metadata:
                # Build where clause for metadata filtering
                where_clause = {}
                for key, value in filter_metadata.items():
                    where_clause[key] = {"$eq": value}
            
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                where=where_clause,
                include=["documents", "metadatas", "distances"]
            )
            
            return results
            
        except Exception as e:
            logger.error(f"ChromaDB search failed: {e}")
            raise
    
    async def get_collection_stats(self) -> Dict[str, Any]:
        """Get collection statistics."""
        try:
            count = self.collection.count()
            
            # Get sample documents for analysis
            sample_results = self.collection.peek(limit=min(count, 10))
            
            return {
                "total_documents": count,
                "collection_name": self.collection.name,
                "sample_documents": len(sample_results.get("documents", [])),
                "has_embeddings": "embeddings" in sample_results,
                "metadata_fields": list(sample_results.get("metadatas", [{}])[0].keys()) if sample_results.get("metadatas") else []
            }
            
        except Exception as e:
            logger.error(f"Failed to get collection stats: {e}")
            raise
    
    async def delete_collection(self):
        """Delete the entire collection."""
        try:
            self.client.delete_collection(self.collection_name)
            logger.info(f"Collection {self.collection_name} deleted")
            
        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            raise
    
    async def create_backup(self, backup_path: Path) -> bool:
        """Create a backup of the database."""
        try:
            if not backup_path.exists():
                backup_path.mkdir(parents=True, exist_ok=True)
            
            # Copy the entire database directory
            import shutil
            shutil.copytree(
                self.persist_directory,
                backup_path / "chromadb_backup",
                dirs_exist_ok=True
            )
            
            logger.info(f"ChromaDB backup created at {backup_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create ChromaDB backup: {e}")
            return False


# ==============================================================================
# SEARCH ENGINE
# ==============================================================================

class SearchEngine:
    """Provides semantic and hybrid search capabilities."""
    
    def __init__(self, chromadb_manager: ChromaDBManager, embedding_service: EmbeddingService):
        self.chromadb_manager = chromadb_manager
        self.embedding_service = embedding_service
        self.tfidf_vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
        self.redis_client = None
        
        # Initialize Redis if available
        try:
            if settings.redis_url:
                self.redis_client = aioredis.from_url(settings.redis_url)
        except Exception as e:
            logger.warning(f"Failed to initialize Redis for search cache: {e}")
    
    async def semantic_search(
        self,
        query: str,
        top_k: int = 5,
        filter_metadata: Dict[str, Any] = None
    ) -> List[SearchResult]:
        """Perform semantic search using vector similarity."""
        try:
            # Generate query embedding
            query_embedding = await self.embedding_service.generate_embedding(query)
            
            # Search in ChromaDB
            results = await self.chromadb_manager.search(
                query_embedding=query_embedding,
                n_results=top_k,
                filter_metadata=filter_metadata
            )
            
            # Convert to SearchResult objects
            search_results = []
            for i, doc in enumerate(results["documents"][0]):
                metadata = results["metadatas"][0][i]
                distance = results["distances"][0][i]
                similarity_score = 1.0 - distance
                
                search_result = SearchResult(
                    content=doc,
                    metadata=metadata,
                    similarity_score=similarity_score,
                    vector_score=similarity_score,
                    rank=i + 1
                )
                search_results.append(search_result)
            
            return search_results
            
        except Exception as e:
            logger.error(f"Semantic search failed: {e}")
            raise
    
    async def keyword_search(
        self,
        query: str,
        top_k: int = 5,
        filter_metadata: Dict[str, Any] = None
    ) -> List[SearchResult]:
        """Perform keyword-based search using TF-IDF."""
        try:
            # Get all documents from collection
            collection_stats = await self.chromadb_manager.get_collection_stats()
            count = collection_stats["total_documents"]
            
            if count == 0:
                return []
            
            # Fetch all documents (limit to avoid memory issues)
            all_docs = self.chromadb_manager.collection.peek(limit=min(count, 10000))
            
            if not all_docs.get("documents"):
                return []
            
            documents = all_docs["documents"]
            metadatas = all_docs["metadatas"]
            
            # Build corpus for TF-IDF
            corpus = documents
            
            # Fit TF-IDF vectorizer
            tfidf_matrix = self.tfidf_vectorizer.fit_transform(corpus)
            
            # Transform query
            query_vector = self.tfidf_vectorizer.transform([query])
            
            # Calculate cosine similarity
            similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
            
            # Get top results
            top_indices = similarities.argsort()[-top_k:][::-1]
            
            search_results = []
            for rank, idx in enumerate(top_indices):
                if similarities[idx] > 0:  # Only include non-zero similarities
                    search_result = SearchResult(
                        content=documents[idx],
                        metadata=metadatas[idx],
                        similarity_score=similarities[idx],
                        keyword_score=similarities[idx],
                        rank=rank + 1
                    )
                    search_results.append(search_result)
            
            return search_results
            
        except Exception as e:
            logger.error(f"Keyword search failed: {e}")
            raise
    
    async def hybrid_search(
        self,
        query: str,
        top_k: int = 5,
        vector_weight: float = 0.7,
        keyword_weight: float = 0.3,
        filter_metadata: Dict[str, Any] = None
    ) -> List[SearchResult]:
        """Perform hybrid search combining semantic and keyword search."""
        try:
            # Perform both searches
            semantic_results = await self.semantic_search(query, top_k * 2, filter_metadata)
            keyword_results = await self.keyword_search(query, top_k * 2, filter_metadata)
            
            # Combine results
            combined_results = {}
            
            # Add semantic results
            for result in semantic_results:
                if result.content not in combined_results:
                    combined_results[result.content] = result
                else:
                    # Update with better semantic score
                    if result.similarity_score > combined_results[result.content].similarity_score:
                        combined_results[result.content] = result
            
            # Add keyword results
            for result in keyword_results:
                if result.content in combined_results:
                    # Combine scores
                    existing = combined_results[result.content]
                    existing.keyword_score = result.keyword_score
                    existing.combined_score = (
                        vector_weight * existing.vector_score +
                        keyword_weight * existing.keyword_score
                    )
                else:
                    result.combined_score = keyword_weight * result.keyword_score
                    combined_results[result.content] = result
            
            # Sort by combined score and return top_k
            final_results = sorted(
                combined_results.values(),
                key=lambda x: x.combined_score,
                reverse=True
            )[:top_k]
            
            # Update ranks
            for i, result in enumerate(final_results):
                result.rank = i + 1
            
            return final_results
            
        except Exception as e:
            logger.error(f"Hybrid search failed: {e}")
            raise
    
    async def close(self):
        """Cleanup resources."""
        if self.redis_client:
            await self.redis_client.close()


# ==============================================================================
# MAIN RAG TOOL
# ==============================================================================

class RAGTool:
    """
    Enhanced RAG Tool with comprehensive ChromaDB integration.
    
    This is the main interface for all RAG operations, providing:
    - Document processing and chunking
    - Embedding generation with caching
    - Vector database management
    - Semantic and hybrid search
    - Performance monitoring
    """
    
    def __init__(self):
        """Initialize the RAG tool with all components."""
        self.document_processor = DocumentProcessor()
        self.embedding_service = EmbeddingService()
        self.chromadb_manager = ChromaDBManager()
        self.search_engine = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize all components of the RAG tool."""
        if self._initialized:
            return
        
        try:
            # Initialize ChromaDB
            await self.chromadb_manager.initialize()
            
            # Initialize embedding service
            await self.embedding_service.initialize()
            
            # Initialize search engine
            self.search_engine = SearchEngine(
                self.chromadb_manager,
                self.embedding_service
            )
            
            self._initialized = True
            logger.info("RAG tool initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize RAG tool: {e}")
            raise
    
    async def add_documents(
        self,
        documents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        source_paths: Optional[List[str]] = None
    ) -> ProcessingStats:
        """
        Add documents to the knowledge base with comprehensive processing.
        
        Args:
            documents: List of document contents
            metadatas: Optional list of metadata dictionaries
            source_paths: Optional list of source file paths
            
        Returns:
            Processing statistics
        """
        if not self._initialized:
            await self.initialize()
        
        start_time = time.time()
        stats = ProcessingStats()
        
        try:
            stats.total_documents = len(documents)
            
            # Process each document
            all_chunks = []
            
            for i, content in enumerate(documents):
                try:
                    # Validate document
                    is_valid, validation_msg = self.document_processor.validate_document(
                        content, source_paths[i] if source_paths else None
                    )
                    
                    if not is_valid:
                        stats.errors.append(f"Document {i}: {validation_msg}")
                        continue
                    
                    # Extract metadata
                    metadata = self.document_processor.extract_metadata(
                        content, source_paths[i] if source_paths else None
                    )
                    
                    # Merge with provided metadata
                    if metadatas and i < len(metadatas):
                        if isinstance(metadatas[i], dict):
                            metadata.update(metadatas[i])
                    
                    # Chunk document
                    chunks = self.document_processor.chunk_document(content, metadata)
                    all_chunks.extend(chunks)
                    
                except Exception as e:
                    error_msg = f"Error processing document {i}: {str(e)}"
                    stats.errors.append(error_msg)
                    logger.error(error_msg)
            
            stats.total_chunks = len(all_chunks)
            stats.processing_time = time.time() - start_time
            
            if not all_chunks:
                logger.warning("No valid chunks to process")
                return stats
            
            # Generate embeddings in batches
            embedding_start = time.time()
            texts = [chunk.content for chunk in all_chunks]
            embeddings = await self.embedding_service.generate_embeddings_batch(texts)
            stats.embedding_time = time.time() - embedding_start
            
            # Store in ChromaDB
            storage_start = time.time()
            await self.chromadb_manager.add_documents(all_chunks, embeddings)
            stats.storage_time = time.time() - storage_start
            
            # Calculate average chunk size
            if all_chunks:
                total_chars = sum(len(chunk.content) for chunk in all_chunks)
                stats.average_chunk_size = total_chars / len(all_chunks)
            
            logger.info(f"Successfully processed {stats.total_chunks} chunks from {stats.total_documents} documents")
            
        except Exception as e:
            error_msg = f"Failed to add documents: {str(e)}"
            stats.errors.append(error_msg)
            logger.error(error_msg)
            raise
        
        return stats
    
    async def search(
        self,
        query: str,
        search_type: str = "semantic",
        top_k: int = 5,
        filter_metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Search the knowledge base using specified search type.
        
        Args:
            query: Search query
            search_type: Type of search ("semantic", "keyword", "hybrid")
            top_k: Number of results to return
            filter_metadata: Optional metadata filters
            
        Returns:
            Dictionary with search results and metadata
        """
        if not self._initialized:
            await self.initialize()
        
        if not self.search_engine:
            raise RuntimeError("Search engine not initialized")
        
        try:
            start_time = time.time()
            
            # Perform search based on type
            if search_type == "semantic":
                results = await self.search_engine.semantic_search(query, top_k, filter_metadata)
            elif search_type == "keyword":
                results = await self.search_engine.keyword_search(query, top_k, filter_metadata)
            elif search_type == "hybrid":
                results = await self.search_engine.hybrid_search(query, top_k, filter_metadata)
            else:
                raise ValueError(f"Unknown search type: {search_type}")
            
            search_time = time.time() - start_time
            
            # Convert results to dictionary format
            sources = []
            for result in results:
                source = {
                    "content": result.content,
                    "metadata": result.metadata,
                    "similarity_score": result.similarity_score,
                    "vector_score": result.vector_score,
                    "keyword_score": result.keyword_score,
                    "combined_score": result.combined_score,
                    "rank": result.rank
                }
                sources.append(source)
            
            # Calculate confidence based on average relevance
            confidence = 0.0
            if sources:
                confidence = np.mean([source["similarity_score"] for source in sources])
            
            return {
                "query": query,
                "search_type": search_type,
                "sources": sources,
                "confidence": float(confidence),
                "total_results": len(sources),
                "search_time": search_time,
                "filter_metadata": filter_metadata
            }
            
        except Exception as e:
            logger.error(f"Search failed: {str(e)}")
            raise
    
    async def similarity_search(
        self,
        document: str,
        top_k: int = 5,
        filter_metadata: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Find documents similar to the given document.
        
        Args:
            document: Document text to compare
            top_k: Number of similar documents to return
            filter_metadata: Optional metadata filters
            
        Returns:
            List of similar documents with metadata
        """
        if not self._initialized:
            await self.initialize()
        
        try:
            # Generate embedding for the document
            doc_embedding = await self.embedding_service.generate_embedding(document)
            
            # Search for similar documents
            results = await self.chromadb_manager.search(
                query_embedding=doc_embedding,
                n_results=top_k,
                filter_metadata=filter_metadata
            )
            
            # Process results
            similar_docs = []
            for i, doc in enumerate(results["documents"][0]):
                similar_doc = {
                    "content": doc,
                    "metadata": results["metadatas"][0][i],
                    "similarity": 1.0 - results["distances"][0][i],
                    "distance": results["distances"][0][i]
                }
                similar_docs.append(similar_doc)
            
            return similar_docs
            
        except Exception as e:
            logger.error(f"Similarity search failed: {str(e)}")
            raise
    
    async def get_collection_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics about the knowledge base."""
        if not self._initialized:
            await self.initialize()
        
        try:
            stats = await self.chromadb_manager.get_collection_stats()
            
            # Add additional metrics
            stats.update({
                "embedding_model": settings.embedding_model,
                "chunk_size": settings.rag_chunk_size,
                "chunk_overlap": settings.rag_chunk_overlap,
                "last_updated": time.time()
            })
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get collection stats: {str(e)}")
            raise
    
    async def create_backup(self, backup_path: Optional[str] = None) -> bool:
        """
        Create a backup of the knowledge base.
        
        Args:
            backup_path: Optional custom backup path
            
        Returns:
            Success status
        """
        if not self._initialized:
            await self.initialize()
        
        try:
            if backup_path:
                path = Path(backup_path)
            else:
                # Create backup in default location
                backup_dir = settings.backup_path / "chromadb"
                backup_dir.mkdir(parents=True, exist_ok=True)
                path = backup_dir / f"backup_{int(time.time())}"
            
            success = await self.chromadb_manager.create_backup(path)
            
            if success:
                logger.info(f"Knowledge base backup created at {path}")
            else:
                logger.error(f"Failed to create knowledge base backup at {path}")
            
            return success
            
        except Exception as e:
            logger.error(f"Backup creation failed: {str(e)}")
            return False
    
    async def delete_collection(self):
        """Delete the entire knowledge base collection."""
        if not self._initialized:
            await self.initialize()
        
        try:
            await self.chromadb_manager.delete_collection()
            logger.info("Knowledge base collection deleted")
            
        except Exception as e:
            logger.error(f"Failed to delete collection: {str(e)}")
            raise
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on all RAG components."""
        health_status = {
            "overall_status": "healthy",
            "components": {},
            "errors": [],
            "timestamp": time.time()
        }
        
        try:
            # Check ChromaDB
            try:
                await self.chromadb_manager.initialize()
                health_status["components"]["chromadb"] = {
                    "status": "healthy",
                    "stats": await self.chromadb_manager.get_collection_stats()
                }
            except Exception as e:
                health_status["components"]["chromadb"] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
                health_status["errors"].append(f"ChromaDB: {str(e)}")
            
            # Check Embedding Service
            try:
                if not self.embedding_service.model:
                    await self.embedding_service.initialize()
                health_status["components"]["embedding_service"] = {
                    "status": "healthy",
                    "model": self.embedding_service.model_name
                }
            except Exception as e:
                health_status["components"]["embedding_service"] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
                health_status["errors"].append(f"Embedding Service: {str(e)}")
            
            # Set overall status
            if health_status["errors"]:
                health_status["overall_status"] = "degraded" if len(health_status["errors"]) < 2 else "unhealthy"
            
        except Exception as e:
            health_status["overall_status"] = "unhealthy"
            health_status["errors"].append(f"Health check failed: {str(e)}")
        
        return health_status
    
    async def close(self):
        """Cleanup all resources."""
        try:
            # Close embedding service
            await self.embedding_service.close()
            
            # Close search engine
            if self.search_engine:
                await self.search_engine.close()
            
            logger.info("RAG tool cleanup completed")
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")