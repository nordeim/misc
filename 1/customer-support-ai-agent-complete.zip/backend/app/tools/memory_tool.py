"""
Memory Tool for managing conversation history and context.

Handles persistent storage and retrieval of conversation memories with advanced features:
- Memory storage strategies and retrieval algorithms
- Memory indexing and search capabilities
- Memory lifecycle management and TTL
- Context tracking and importance scoring
- Memory compression and summarization
- Memory analytics and reporting
- Optimized database operations

Author: Customer Support AI Agent
Version: 2.0.0
"""

import logging
import asyncio
import hashlib
from typing import List, Dict, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import json
import re
from collections import defaultdict, Counter

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc, asc, func, text, not_, exists
from sqlalchemy.orm import selectinload
from sqlalchemy.dialects.postgresql import jsonb_path_query

from app.models.memory import MemoryORM, MemoryCreate, MemoryUpdate, MemoryRead, MemoryStats
from app.models.session import SessionORM
from app.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


class MemoryType(Enum):
    """Enumeration of memory types."""
    CONVERSATION = "conversation"
    CONTEXT = "context"
    USER_PREFERENCE = "user_preference"
    KNOWLEDGE = "knowledge"
    FACT = "fact"
    USER_INFO = "user_info"
    SUMMARY = "summary"
    POLICY = "policy"
    ERROR = "error"


class ImportanceLevel(Enum):
    """Memory importance levels."""
    CRITICAL = 1.0
    HIGH = 0.8
    MEDIUM = 0.6
    LOW = 0.4
    MINIMAL = 0.2


@dataclass
class MemoryQuery:
    """Memory query parameters."""
    session_id: str
    memory_types: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    keywords: Optional[List[str]] = None
    importance_min: Optional[float] = None
    since: Optional[datetime] = None
    until: Optional[datetime] = None
    limit: int = 50
    offset: int = 0
    sort_by: str = "importance_score"
    sort_order: str = "desc"


@dataclass
class MemoryAnalytics:
    """Memory analytics data structure."""
    session_id: str
    total_memories: int
    memories_by_type: Dict[str, int]
    importance_distribution: Dict[str, int]
    avg_importance_score: float
    memory_access_patterns: Dict[str, int]
    retention_stats: Dict[str, int]
    compression_ratio: Optional[float] = None


@dataclass
class MemorySearchResult:
    """Memory search result."""
    memory: MemoryORM
    relevance_score: float
    search_excerpt: str
    matched_keywords: List[str]


class MemoryCompressor:
    """Handles memory compression and summarization."""
    
    def __init__(self):
        self.max_conversation_length = 2000  # Characters
        self.summary_threshold = 1000  # Characters
        self.compression_ratio_threshold = 0.7
    
    def compress_conversation_memory(self, value: str) -> Tuple[str, bool]:
        """
        Compress conversation memory by summarizing long text.
        
        Args:
            value: Original memory value
            
        Returns:
            Tuple of (compressed_value, was_compressed)
        """
        if len(value) <= self.summary_threshold:
            return value, False
        
        # Simple extractive summarization (can be enhanced with NLP)
        sentences = value.split('.')
        if len(sentences) < 3:
            return value, False
        
        # Take first and last sentences plus middle ones with key information
        summary_sentences = [sentences[0]]
        
        # Find sentences with key information (keywords, numbers, etc.)
        key_sentences = []
        for sentence in sentences[1:-1]:
            if any(word in sentence.lower() for word in ['important', 'key', 'remember', 'note', 'user', 'preference']):
                key_sentences.append(sentence)
        
        summary_sentences.extend(key_sentences[:2])  # Max 2 key sentences
        summary_sentences.append(sentences[-1])
        
        compressed = '. '.join(summary_sentences).strip()
        compression_ratio = len(compressed) / len(value)
        
        logger.info(f"Memory compressed from {len(value)} to {len(compressed)} chars "
                   f"(ratio: {compression_ratio:.2f})")
        
        return compressed, compression_ratio < self.compression_ratio_threshold
    
    def extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords from text."""
        # Simple keyword extraction (can be enhanced with NLP)
        words = re.findall(r'\b\w+\b', text.lower())
        
        # Filter out common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those'}
        
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        # Return most common keywords
        word_freq = Counter(keywords)
        return [word for word, count in word_freq.most_common(10)]


class MemoryRelevanceScorer:
    """Calculate relevance scores for memories."""
    
    def __init__(self):
        self.recency_weight = 0.3
        self.importance_weight = 0.4
        self.access_weight = 0.2
        self.relevance_weight = 0.1
    
    def calculate_relevance_score(self, memory: MemoryORM, query: MemoryQuery, current_time: datetime) -> float:
        """
        Calculate relevance score for a memory based on various factors.
        
        Args:
            memory: Memory to score
            query: Query parameters
            current_time: Current timestamp
            
        Returns:
            Relevance score between 0.0 and 1.0
        """
        score = 0.0
        
        # Importance score (40% weight)
        score += memory.importance_score * self.importance_weight
        
        # Recency score (30% weight)
        hours_old = (current_time - memory.created_at).total_seconds() / 3600
        recency_score = max(0, 1 - (hours_old / 168))  # Decay over a week
        score += recency_score * self.recency_weight
        
        # Access frequency score (20% weight)
        access_score = min(1.0, memory.access_count / 10)  # Normalize to max 10 accesses
        score += access_score * self.access_weight
        
        # Keyword relevance score (10% weight)
        if query.keywords:
            keyword_score = self._calculate_keyword_relevance(memory.value, query.keywords)
            score += keyword_score * self.relevance_weight
        
        return min(1.0, score)
    
    def _calculate_keyword_relevance(self, text: str, keywords: List[str]) -> float:
        """Calculate keyword relevance in text."""
        text_lower = text.lower()
        matches = sum(1 for keyword in keywords if keyword.lower() in text_lower)
        return matches / len(keywords) if keywords else 0


class MemoryTool:
    """Enhanced tool for managing conversation memory and context."""
    
    def __init__(self):
        self.compressor = MemoryCompressor()
        self.relevance_scorer = MemoryRelevanceScorer()
        self.default_ttl_days = 30
        self.max_memories_per_session = 10000
        
        # Memory cleanup settings
        self.cleanup_batch_size = 1000
        self.cleanup_interval_hours = 24
        
        logger.info("MemoryTool initialized with enhanced features")
    
    async def store_memory(
        self,
        session_id: str,
        key: str,
        value: str,
        memory_type: str = MemoryType.CONVERSATION.value,
        importance_score: float = 0.5,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        ttl_days: Optional[int] = None,
        source_message_id: Optional[str] = None,
        auto_compress: bool = True
    ) -> str:
        """
        Store a memory in the database with advanced features.
        
        Args:
            session_id: Session identifier
            key: Memory key
            value: Memory value
            memory_type: Type of memory
            importance_score: Importance score (0.0 to 1.0)
            metadata: Optional metadata dictionary
            tags: Optional list of tags
            ttl_days: Time to live in days
            source_message_id: ID of source message
            auto_compress: Whether to auto-compress long memories
            
        Returns:
            Memory ID
        """
        async with AsyncSessionLocal() as db:
            try:
                # Check if memory key already exists
                existing_memory = await self._get_memory_by_key(db, session_id, key)
                if existing_memory:
                    # Update existing memory
                    return await self.update_memory(
                        session_id, key, value, memory_type, 
                        importance_score, metadata, tags, ttl_days, source_message_id
                    )
                
                # Auto-compress if enabled
                if auto_compress and memory_type == MemoryType.CONVERSATION.value:
                    value, was_compressed = self.compressor.compress_conversation_memory(value)
                    if was_compressed and metadata is None:
                        metadata = {}
                    if metadata and was_compressed:
                        metadata['was_compressed'] = True
                        metadata['original_length'] = len(value)
                
                # Calculate expiry time
                expires_at = None
                if ttl_days:
                    expires_at = datetime.utcnow() + timedelta(days=ttl_days)
                elif importance_score < 0.3:
                    # Low importance memories expire sooner
                    expires_at = datetime.utcnow() + timedelta(days=7)
                
                # Extract keywords
                keywords = self.compressor.extract_keywords(value)
                
                memory = MemoryORM(
                    session_id=session_id,
                    key=key,
                    value=value,
                    memory_type=memory_type,
                    importance_score=importance_score,
                    confidence_score=1.0,
                    expires_at=expires_at,
                    source_message_id=source_message_id,
                    tags=tags or [],
                    meta_data={
                        **(metadata or {}),
                        'keywords': keywords,
                        'created_by': 'memory_tool',
                        'version': '2.0'
                    }
                )
                
                db.add(memory)
                await db.flush()  # Get ID without committing
                
                # Check session memory limits
                await self._enforce_session_limits(db, session_id)
                
                await db.commit()
                
                logger.info(f"Stored memory '{key}' for session {session_id} "
                          f"(importance: {importance_score}, type: {memory_type})")
                return str(memory.id)
                
            except Exception as e:
                await db.rollback()
                logger.error(f"Failed to store memory '{key}' for session {session_id}: {e}")
                raise
    
    async def get_context(
        self,
        session_id: str,
        memory_types: Optional[List[str]] = None,
        limit: int = 20,
        since: Optional[datetime] = None,
        min_importance: float = 0.0,
        include_expired: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Retrieve conversation context for a session with advanced filtering.
        
        Args:
            session_id: Session identifier
            memory_types: Optional filter by memory types
            limit: Maximum number of memories to return
            since: Optional datetime to filter memories after
            min_importance: Minimum importance score
            include_expired: Whether to include expired memories
            
        Returns:
            List of memory dictionaries ordered by relevance
        """
        async with AsyncSessionLocal() as db:
            query = select(MemoryORM).where(
                MemoryORM.session_id == session_id,
                MemoryORM.importance_score >= min_importance
            )
            
            if memory_types:
                query = query.where(MemoryORM.memory_type.in_(memory_types))
            
            if since:
                query = query.where(MemoryORM.created_at >= since)
            
            if not include_expired:
                query = query.where(
                    or_(
                        MemoryORM.expires_at.is_(None),
                        MemoryORM.expires_at > datetime.utcnow()
                    )
                )
            
            query = query.order_by(desc(MemoryORM.importance_score), desc(MemoryORM.created_at)).limit(limit)
            
            result = await db.execute(query)
            memories = result.scalars().all()
            
            # Mark memories as accessed
            for memory in memories:
                memory.access()
            
            await db.commit()
            
            context = []
            for memory in memories:
                context.append({
                    "id": str(memory.id),
                    "key": memory.key,
                    "value": memory.value,
                    "memory_type": memory.memory_type,
                    "importance_score": memory.importance_score,
                    "confidence_score": memory.confidence_score,
                    "access_count": memory.access_count,
                    "last_accessed": memory.last_accessed.isoformat() if memory.last_accessed else None,
                    "expires_at": memory.expires_at.isoformat() if memory.expires_at else None,
                    "tags": memory.tags or [],
                    "metadata": memory.meta_data or {},
                    "created_at": memory.created_at.isoformat(),
                    "updated_at": memory.updated_at.isoformat()
                })
            
            return context
    
    async def search_memories(
        self,
        query: MemoryQuery
    ) -> List[MemorySearchResult]:
        """
        Advanced memory search with relevance scoring.
        
        Args:
            query: Memory query parameters
            
        Returns:
            List of search results with relevance scores
        """
        async with AsyncSessionLocal() as db:
            base_query = select(MemoryORM).where(
                MemoryORM.session_id == query.session_id
            )
            
            # Apply filters
            if query.memory_types:
                base_query = base_query.where(MemoryORM.memory_type.in_(query.memory_types))
            
            if query.tags:
                base_query = base_query.where(
                    func.jsonb_exists(MemoryORM.tags, query.tags)
                )
            
            if query.since:
                base_query = base_query.where(MemoryORM.created_at >= query.since)
            
            if query.until:
                base_query = base_query.where(MemoryORM.created_at <= query.until)
            
            if not query.memory_types or MemoryType.CONVERSATION.value in query.memory_types:
                # Exclude expired non-persistent memories by default
                base_query = base_query.where(
                    or_(
                        MemoryORM.expires_at.is_(None),
                        MemoryORM.expires_at > datetime.utcnow()
                    )
                )
            
            # Get all matching memories first
            result = await db.execute(base_query)
            memories = result.scalars().all()
            
            # Calculate relevance scores
            current_time = datetime.utcnow()
            scored_memories = []
            
            for memory in memories:
                relevance_score = self.relevance_scorer.calculate_relevance_score(memory, query, current_time)
                
                # Additional filtering based on importance
                if query.importance_min and memory.importance_score < query.importance_min:
                    continue
                
                scored_memories.append(MemorySearchResult(
                    memory=memory,
                    relevance_score=relevance_score,
                    search_excerpt=self._create_excerpt(memory.value, query.keywords),
                    matched_keywords=self._find_matched_keywords(memory.value, query.keywords or [])
                ))
            
            # Sort by relevance score
            scored_memories.sort(key=lambda x: x.relevance_score, reverse=True)
            
            # Apply limit and offset
            start = query.offset
            end = start + query.limit
            return scored_memories[start:end]
    
    async def get_memory(
        self,
        session_id: str,
        key: str
    ) -> Optional[Dict[str, Any]]:
        """Get a specific memory by key."""
        async with AsyncSessionLocal() as db:
            memory = await self._get_memory_by_key(db, session_id, key)
            
            if memory:
                # Mark as accessed
                memory.access()
                await db.commit()
                
                return {
                    "id": str(memory.id),
                    "key": memory.key,
                    "value": memory.value,
                    "memory_type": memory.memory_type,
                    "importance_score": memory.importance_score,
                    "confidence_score": memory.confidence_score,
                    "access_count": memory.access_count,
                    "last_accessed": memory.last_accessed.isoformat() if memory.last_accessed else None,
                    "expires_at": memory.expires_at.isoformat() if memory.expires_at else None,
                    "tags": memory.tags or [],
                    "metadata": memory.meta_data or {},
                    "created_at": memory.created_at.isoformat(),
                    "updated_at": memory.updated_at.isoformat()
                }
            
            return None
    
    async def update_memory(
        self,
        session_id: str,
        key: str,
        value: str,
        memory_type: str = MemoryType.CONVERSATION.value,
        importance_score: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        ttl_days: Optional[int] = None,
        source_message_id: Optional[str] = None
    ) -> Optional[str]:
        """Update an existing memory or create a new one."""
        async with AsyncSessionLocal() as db:
            memory = await self._get_memory_by_key(db, session_id, key)
            
            if memory:
                try:
                    # Update memory fields
                    memory.value = value
                    memory.memory_type = memory_type
                    
                    if importance_score is not None:
                        memory.importance_score = importance_score
                    
                    if metadata:
                        memory.meta_data = {**(memory.meta_data or {}), **metadata}
                    
                    if tags is not None:
                        memory.tags = tags
                    
                    if ttl_days is not None:
                        memory.expires_at = datetime.utcnow() + timedelta(days=ttl_days)
                    
                    if source_message_id:
                        memory.source_message_id = source_message_id
                    
                    memory.last_accessed = datetime.utcnow()
                    
                    await db.commit()
                    
                    logger.info(f"Updated memory '{key}' for session {session_id}")
                    return str(memory.id)
                    
                except Exception as e:
                    await db.rollback()
                    logger.error(f"Failed to update memory '{key}': {e}")
                    raise
            else:
                # Create new memory
                return await self.store_memory(
                    session_id, key, value, memory_type, 
                    importance_score or 0.5, metadata, tags, ttl_days, source_message_id
                )
    
    async def delete_memory(
        self,
        session_id: str,
        key: str
    ) -> bool:
        """Delete a specific memory."""
        async with AsyncSessionLocal() as db:
            memory = await self._get_memory_by_key(db, session_id, key)
            
            if memory:
                try:
                    await db.delete(memory)
                    await db.commit()
                    logger.info(f"Deleted memory '{key}' for session {session_id}")
                    return True
                except Exception as e:
                    await db.rollback()
                    logger.error(f"Failed to delete memory '{key}': {e}")
                    raise
            
            return False
    
    async def clear_session_memories(
        self,
        session_id: str,
        memory_type: Optional[str] = None,
        older_than_days: Optional[int] = None
    ) -> int:
        """Clear memories for a session with optional filtering."""
        async with AsyncSessionLocal() as db:
            query = select(MemoryORM).where(MemoryORM.session_id == session_id)
            
            if memory_type:
                query = query.where(MemoryORM.memory_type == memory_type)
            
            if older_than_days:
                cutoff_date = datetime.utcnow() - timedelta(days=older_than_days)
                query = query.where(MemoryORM.created_at < cutoff_date)
            
            result = await db.execute(query)
            memories = result.scalars().all()
            
            try:
                for memory in memories:
                    await db.delete(memory)
                
                await db.commit()
                
                deleted_count = len(memories)
                logger.info(f"Deleted {deleted_count} memories for session {session_id}")
                return deleted_count
                
            except Exception as e:
                await db.rollback()
                logger.error(f"Failed to delete memories for session {session_id}: {e}")
                raise
    
    async def get_recent_memories(
        self,
        session_id: str,
        hours: int = 24,
        memory_types: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Get memories from the last N hours."""
        since = datetime.utcnow() - timedelta(hours=hours)
        return await self.get_context(session_id, memory_types, since=since, limit=50)
    
    async def get_memories_by_importance(
        self,
        session_id: str,
        min_importance: float = 0.7,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """Get high-importance memories for a session."""
        return await self.get_context(
            session_id, 
            limit=limit, 
            min_importance=min_importance,
            include_expired=False
        )
    
    async def get_memory_analytics(
        self,
        session_id: str,
        days: int = 30
    ) -> MemoryAnalytics:
        """
        Generate comprehensive memory analytics for a session.
        
        Args:
            session_id: Session identifier
            days: Number of days to analyze
            
        Returns:
            MemoryAnalytics object with detailed statistics
        """
        async with AsyncSessionLocal() as db:
            since = datetime.utcnow() - timedelta(days=days)
            
            # Get all memories in the time period
            query = select(MemoryORM).where(
                MemoryORM.session_id == session_id,
                MemoryORM.created_at >= since
            )
            
            result = await db.execute(query)
            memories = result.scalars().all()
            
            # Calculate statistics
            total_memories = len(memories)
            
            # Memories by type
            memories_by_type = Counter(memory.memory_type for memory in memories)
            
            # Importance distribution
            importance_ranges = {
                'critical (0.9-1.0)': 0,
                'high (0.7-0.9)': 0,
                'medium (0.5-0.7)': 0,
                'low (0.3-0.5)': 0,
                'minimal (0.0-0.3)': 0
            }
            
            for memory in memories:
                score = memory.importance_score
                if score >= 0.9:
                    importance_ranges['critical (0.9-1.0)'] += 1
                elif score >= 0.7:
                    importance_ranges['high (0.7-0.9)'] += 1
                elif score >= 0.5:
                    importance_ranges['medium (0.5-0.7)'] += 1
                elif score >= 0.3:
                    importance_ranges['low (0.3-0.5)'] += 1
                else:
                    importance_ranges['minimal (0.0-0.3)'] += 1
            
            # Average importance score
            avg_importance = sum(memory.importance_score for memory in memories) / total_memories if total_memories > 0 else 0
            
            # Access patterns
            access_patterns = Counter()
            for memory in memories:
                days_since_created = (datetime.utcnow() - memory.created_at).days
                if days_since_created == 0:
                    access_patterns['today'] += memory.access_count
                elif days_since_created <= 7:
                    access_patterns['this_week'] += memory.access_count
                elif days_since_created <= 30:
                    access_patterns['this_month'] += memory.access_count
                else:
                    access_patterns['older'] += memory.access_count
            
            # Retention statistics
            expired_count = sum(1 for memory in memories if memory.is_expired())
            active_count = total_memories - expired_count
            
            retention_stats = {
                'active_memories': active_count,
                'expired_memories': expired_count,
                'retention_rate': (active_count / total_memories * 100) if total_memories > 0 else 0
            }
            
            # Compression ratio
            compressed_count = sum(1 for memory in memories 
                                 if memory.meta_data and memory.meta_data.get('was_compressed'))
            compression_ratio = (compressed_count / total_memories) if total_memories > 0 else 0
            
            return MemoryAnalytics(
                session_id=session_id,
                total_memories=total_memories,
                memories_by_type=dict(memories_by_type),
                importance_distribution=dict(importance_ranges),
                avg_importance_score=avg_importance,
                memory_access_patterns=dict(access_patterns),
                retention_stats=retention_stats,
                compression_ratio=compression_ratio
            )
    
    async def cleanup_expired_memories(
        self,
        session_id: Optional[str] = None
    ) -> int:
        """
        Clean up expired memories.
        
        Args:
            session_id: Optional session ID to limit cleanup
            
        Returns:
            Number of memories cleaned up
        """
        async with AsyncSessionLocal() as db:
            query = select(MemoryORM).where(
                MemoryORM.expires_at.isnot(None),
                MemoryORM.expires_at <= datetime.utcnow()
            )
            
            if session_id:
                query = query.where(MemoryORM.session_id == session_id)
            
            result = await db.execute(query)
            expired_memories = result.scalars().all()
            
            try:
                deleted_count = 0
                for i in range(0, len(expired_memories), self.cleanup_batch_size):
                    batch = expired_memories[i:i + self.cleanup_batch_size]
                    
                    for memory in batch:
                        await db.delete(memory)
                        deleted_count += 1
                    
                    await db.commit()
                
                logger.info(f"Cleaned up {deleted_count} expired memories "
                          f"{'for session ' + session_id if session_id else ''}")
                return deleted_count
                
            except Exception as e:
                await db.rollback()
                logger.error(f"Failed to cleanup expired memories: {e}")
                raise
    
    async def compress_old_memories(
        self,
        session_id: str,
        older_than_days: int = 7,
        min_importance: float = 0.3
    ) -> int:
        """
        Compress old, low-importance memories to save space.
        
        Args:
            session_id: Session identifier
            older_than_days: Compress memories older than this
            min_importance: Only compress memories below this importance
            
        Returns:
            Number of memories compressed
        """
        async with AsyncSessionLocal() as db:
            cutoff_date = datetime.utcnow() - timedelta(days=older_than_days)
            
            query = select(MemoryORM).where(
                MemoryORM.session_id == session_id,
                MemoryORM.created_at < cutoff_date,
                MemoryORM.importance_score < min_importance,
                MemoryORM.memory_type == MemoryType.CONVERSATION.value,
                MemoryORM.expires_at.is_(None)  # Don't compress persistent memories
            )
            
            result = await db.execute(query)
            old_memories = result.scalars().all()
            
            compressed_count = 0
            
            try:
                for memory in old_memories:
                    compressed_value, _ = self.compressor.compress_conversation_memory(memory.value)
                    
                    if len(compressed_value) < len(memory.value):
                        memory.update_value(compressed_value, source="auto_compression")
                        
                        # Update metadata
                        if memory.meta_data is None:
                            memory.meta_data = {}
                        memory.meta_data['compression_date'] = datetime.utcnow().isoformat()
                        memory.meta_data['original_length'] = len(memory.value)
                        
                        compressed_count += 1
                
                await db.commit()
                
                logger.info(f"Compressed {compressed_count} old memories for session {session_id}")
                return compressed_count
                
            except Exception as e:
                await db.rollback()
                logger.error(f"Failed to compress memories for session {session_id}: {e}")
                raise
    
    async def get_memory_summary(
        self,
        session_id: str,
        max_memories: int = 10
    ) -> Dict[str, Any]:
        """
        Get a summary of important memories for a session.
        
        Args:
            session_id: Session identifier
            max_memories: Maximum number of memories to include
            
        Returns:
            Summary dictionary with key memories and statistics
        """
        # Get high-importance memories
        important_memories = await self.get_memories_by_importance(
            session_id, min_importance=0.6, limit=max_memories
        )
        
        # Get recent memories
        recent_memories = await self.get_recent_memories(session_id, hours=24, limit=5)
        
        # Get analytics
        analytics = await self.get_memory_analytics(session_id, days=30)
        
        return {
            'session_id': session_id,
            'summary_date': datetime.utcnow().isoformat(),
            'important_memories': important_memories,
            'recent_memories': recent_memories,
            'analytics': {
                'total_memories': analytics.total_memories,
                'avg_importance': round(analytics.avg_importance_score, 2),
                'memories_by_type': analytics.memories_by_type,
                'top_tags': self._extract_top_tags(important_memories),
                'retention_rate': round(analytics.retention_stats['retention_rate'], 1)
            },
            'recommendations': self._generate_recommendations(analytics)
        }
    
    async def _get_memory_by_key(self, db: AsyncSession, session_id: str, key: str) -> Optional[MemoryORM]:
        """Get memory by session and key."""
        query = select(MemoryORM).where(
            MemoryORM.session_id == session_id,
            MemoryORM.key == key
        ).order_by(desc(MemoryORM.created_at)).limit(1)
        
        result = await db.execute(query)
        return result.scalar_one_or_none()
    
    async def _enforce_session_limits(self, db: AsyncSession, session_id: str):
        """Enforce memory limits per session."""
        # Count current memories
        count_query = select(func.count(MemoryORM.id)).where(
            MemoryORM.session_id == session_id
        )
        result = await db.execute(count_query)
        current_count = result.scalar() or 0
        
        if current_count > self.max_memories_per_session:
            # Delete oldest, lowest-importance memories
            excess = current_count - self.max_memories_per_session
            
            delete_query = select(MemoryORM).where(
                MemoryORM.session_id == session_id
            ).order_by(
                asc(MemoryORM.importance_score),
                asc(MemoryORM.created_at)
            ).limit(excess)
            
            result = await db.execute(delete_query)
            memories_to_delete = result.scalars().all()
            
            for memory in memories_to_delete:
                await db.delete(memory)
            
            logger.info(f"Deleted {excess} excess memories for session {session_id} "
                       f"to enforce limit of {self.max_memories_per_session}")
    
    def _create_excerpt(self, text: str, keywords: Optional[List[str]], max_length: int = 200) -> str:
        """Create an excerpt highlighting keywords."""
        if not keywords or not text:
            return text[:max_length] + "..." if len(text) > max_length else text
        
        # Find first keyword occurrence
        text_lower = text.lower()
        first_match = None
        
        for keyword in keywords:
            pos = text_lower.find(keyword.lower())
            if pos != -1:
                first_match = pos
                break
        
        if first_match is None:
            return text[:max_length] + "..." if len(text) > max_length else text
        
        # Create excerpt around keyword
        start = max(0, first_match - 50)
        end = min(len(text), start + max_length)
        
        excerpt = text[start:end]
        if start > 0:
            excerpt = "..." + excerpt
        if end < len(text):
            excerpt = excerpt + "..."
        
        return excerpt
    
    def _find_matched_keywords(self, text: str, keywords: List[str]) -> List[str]:
        """Find which keywords appear in the text."""
        text_lower = text.lower()
        return [keyword for keyword in keywords if keyword.lower() in text_lower]
    
    def _extract_top_tags(self, memories: List[Dict[str, Any]]) -> List[str]:
        """Extract top tags from memories."""
        all_tags = []
        for memory in memories:
            all_tags.extend(memory.get('tags', []))
        
        tag_counts = Counter(all_tags)
        return [tag for tag, count in tag_counts.most_common(5)]
    
    def _generate_recommendations(self, analytics: MemoryAnalytics) -> List[str]:
        """Generate recommendations based on analytics."""
        recommendations = []
        
        if analytics.avg_importance_score < 0.5:
            recommendations.append("Consider tagging more memories with higher importance scores")
        
        if analytics.retention_stats['retention_rate'] < 70:
            recommendations.append("Low retention rate - consider setting longer TTL for important memories")
        
        if analytics.compression_ratio and analytics.compression_ratio < 0.1:
            recommendations.append("Consider enabling memory compression for longer conversations")
        
        memories_by_type = analytics.memories_by_type
        if memories_by_type.get(MemoryType.CONVERSATION.value, 0) > 100:
            recommendations.append("High conversation memory count - consider summarization")
        
        return recommendations


# Global instance
memory_tool = MemoryTool()