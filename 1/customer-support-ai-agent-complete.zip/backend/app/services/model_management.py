"""
Advanced Model Management Module for Embedding Services.

This module provides comprehensive model management capabilities:
- Model download and caching with progress tracking
- Model versioning and update management
- Performance monitoring and optimization
- Memory management and resource optimization
- Model registry and discovery
- A/B testing and model comparison
- Model quality assessment and validation

Features:
- Automatic model downloading with fallback options
- Version control and update management
- Performance metrics collection and analysis
- Memory optimization and cleanup
- Model registry with metadata
- Quality assessment and benchmarking
- Error handling and recovery

Author: AI Agent System
Version: 2.0.0
"""

import asyncio
import hashlib
import json
import logging
import os
import shutil
import time
import warnings
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, Set
from urllib.parse import urlparse
import uuid

import numpy as np
from sentence_transformers import SentenceTransformer, CrossEncoder
try:
    from huggingface_hub import HfApi
    # Try to import the new API components
    try:
        from huggingface_hub import ModelFilter, ModelInfo
    except ImportError:
        # Create compatibility aliases for newer API
        class ModelFilter:
            def __init__(self, **kwargs):
                self.model_name = kwargs.get('model_name')
                self.author = kwargs.get('author')
                self.task = kwargs.get('task')
                self.language = kwargs.get('language')
                self.library = kwargs.get('library')
        
        class ModelInfo:
            def __init__(self, **kwargs):
                self.modelId = kwargs.get('modelId', '')
                self.author = kwargs.get('author', '')
                self.tags = kwargs.get('tags', [])
                self.id = kwargs.get('id', '')
                
    # Create compatibility wrapper for newer API
    import huggingface_hub
    if not hasattr(huggingface_hub, 'ModelFilter'):
        huggingface_hub.ModelFilter = ModelFilter
    if not hasattr(huggingface_hub, 'ModelInfo'):
        huggingface_hub.ModelInfo = ModelInfo
except ImportError:
    HfApi = None
    ModelFilter = None
    ModelInfo = None
    
import psutil
from packaging import version
import diskcache as dc

from app.config import settings

logger = logging.getLogger(__name__)

# ==============================================================================
# DATA STRUCTURES AND CONSTANTS
# ==============================================================================

@dataclass
class ModelVersion:
    """Information about a model version."""
    version: str
    model_id: str
    download_date: datetime
    file_size_mb: int
    checksum: str
    download_url: str
    changelog: str = ""
    is_compatible: bool = True
    performance_score: float = 0.0
    usage_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        data['download_date'] = self.download_date.isoformat()
        return data

@dataclass
class ModelMetadata:
    """Comprehensive metadata for a model."""
    model_id: str
    name: str
    description: str
    author: str
    language: str
    license: str
    tags: List[str]
    downloads: int
    likes: int
    pipeline_tag: str
    library_name: str
    model_type: str
    base_model: Optional[str] = None
    fine_tuned_from: Optional[str] = None
    training_data: Optional[str] = None
    training_parameters: Dict[str, Any] = None
    evaluation_metrics: Dict[str, float] = None
    inference_time_ms: float = 0.0
    memory_usage_mb: float = 0.0
    accuracy_score: float = 0.0
    
    def __post_init__(self):
        if self.training_parameters is None:
            self.training_parameters = {}
        if self.evaluation_metrics is None:
            self.evaluation_metrics = {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

@dataclass
class ModelPerformanceMetrics:
    """Performance metrics for a model."""
    model_id: str
    version: str
    load_time_seconds: float
    inference_time_ms: float
    memory_usage_mb: float
    throughput_docs_per_second: float
    accuracy_score: float
    cache_hit_rate: float
    error_rate: float
    last_updated: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        data['last_updated'] = self.last_updated.isoformat()
        return data

@dataclass
class ModelRegistryEntry:
    """Entry in the model registry."""
    model_id: str
    metadata: ModelMetadata
    current_version: str
    available_versions: List[ModelVersion]
    performance_metrics: ModelPerformanceMetrics
    status: str  # "active", "deprecated", "testing"
    priority: int  # 1-10, higher is better
    is_primary: bool = False
    is_fallback: bool = False
    last_used: Optional[datetime] = None
    usage_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

# Configuration constants
MODEL_CACHE_DIR = Path("./data/model_cache")
HF_CACHE_DIR = Path("./data/hf_cache")
METADATA_CACHE_TTL = 3600  # 1 hour
PERFORMANCE_CACHE_TTL = 300  # 5 minutes
MAX_MODELS_IN_MEMORY = 5
MAX_CACHE_SIZE_GB = 10
MIN_FREE_SPACE_GB = 1
MODEL_DOWNLOAD_TIMEOUT = 3600  # 1 hour

# ==============================================================================
# MODEL REGISTRY
# ==============================================================================

class ModelRegistry:
    """Registry for managing model information and metadata."""
    
    def __init__(self):
        self.registry: Dict[str, ModelRegistryEntry] = {}
        self.hf_api = HfApi()
        self.registry_lock = asyncio.Lock()
        
        # Initialize with default models
        self._initialize_default_models()
    
    def _initialize_default_models(self):
        """Initialize registry with default models."""
        default_models = [
            {
                "model_id": "sentence-transformers/all-MiniLM-L6-v2",
                "name": "all-MiniLM-L6-v2",
                "description": "Fast and efficient model for sentence embeddings",
                "author": "sentence-transformers",
                "language": "multilingual",
                "license": "Apache-2.0",
                "tags": ["feature-extraction", "sentence-transformers"],
                "pipeline_tag": "feature-extraction",
                "library_name": "sentence-transformers",
                "model_type": "transformers",
                "is_primary": True,
                "priority": 10
            },
            {
                "model_id": "sentence-transformers/all-mpnet-base-v2",
                "name": "all-mpnet-base-v2",
                "description": "High-quality model with better performance",
                "author": "sentence-transformers",
                "language": "multilingual",
                "license": "Apache-2.0",
                "tags": ["feature-extraction", "sentence-transformers"],
                "pipeline_tag": "feature-extraction",
                "library_name": "sentence-transformers",
                "model_type": "transformers",
                "is_fallback": True,
                "priority": 9
            }
        ]
        
        for model_config in default_models:
            self.register_model(**model_config)
    
    def register_model(
        self,
        model_id: str,
        name: str,
        description: str,
        author: str,
        language: str,
        license: str,
        tags: List[str],
        pipeline_tag: str,
        library_name: str,
        model_type: str,
        base_model: str = None,
        fine_tuned_from: str = None,
        training_data: str = None,
        is_primary: bool = False,
        is_fallback: bool = False,
        priority: int = 5
    ):
        """Register a model in the registry."""
        metadata = ModelMetadata(
            model_id=model_id,
            name=name,
            description=description,
            author=author,
            language=language,
            license=license,
            tags=tags,
            downloads=0,  # Will be updated from HF
            likes=0,  # Will be updated from HF
            pipeline_tag=pipeline_tag,
            library_name=library_name,
            model_type=model_type,
            base_model=base_model,
            fine_tuned_from=fine_tuned_from,
            training_data=training_data,
            training_parameters={},
            evaluation_metrics={}
        )
        
        # Create initial version
        current_version = ModelVersion(
            version="1.0.0",
            model_id=model_id,
            download_date=datetime.now(),
            file_size_mb=0,
            checksum="",
            download_url=f"https://huggingface.co/{model_id}",
            changelog="Initial version"
        )
        
        # Create performance metrics
        performance_metrics = ModelPerformanceMetrics(
            model_id=model_id,
            version="1.0.0",
            load_time_seconds=0.0,
            inference_time_ms=0.0,
            memory_usage_mb=0.0,
            throughput_docs_per_second=0.0,
            accuracy_score=0.0,
            cache_hit_rate=0.0,
            error_rate=0.0,
            last_updated=datetime.now()
        )
        
        entry = ModelRegistryEntry(
            model_id=model_id,
            metadata=metadata,
            current_version="1.0.0",
            available_versions=[current_version],
            performance_metrics=performance_metrics,
            status="active",
            priority=priority,
            is_primary=is_primary,
            is_fallback=is_fallback
        )
        
        with self.registry_lock:
            self.registry[model_id] = entry
        
        logger.info(f"Registered model: {model_id}")
    
    async def get_model_metadata(self, model_id: str) -> Optional[ModelMetadata]:
        """Get metadata for a model."""
        if model_id in self.registry:
            return self.registry[model_id].metadata
        
        # Try to fetch from HuggingFace
        try:
            model_info = await self._fetch_hf_model_info(model_id)
            if model_info:
                metadata = self._parse_hf_model_info(model_info)
                if model_id in self.registry:
                    self.registry[model_id].metadata = metadata
                return metadata
        except Exception as e:
            logger.warning(f"Failed to fetch metadata for {model_id}: {e}")
        
        return None
    
    async def _fetch_hf_model_info(self, model_id: str) -> Optional[ModelInfo]:
        """Fetch model info from HuggingFace."""
        try:
            return await asyncio.get_event_loop().run_in_executor(
                None,
                self.hf_api.model_info,
                model_id
            )
        except Exception:
            return None
    
    def _parse_hf_model_info(self, model_info: ModelInfo) -> ModelMetadata:
        """Parse HuggingFace model info into our metadata format."""
        return ModelMetadata(
            model_id=model_info.modelId,
            name=model_info.modelId.split("/")[-1] if "/" in model_info.modelId else model_info.modelId,
            description=model_info.description or "",
            author=model_info.author or "unknown",
            language="unknown",
            license=model_info.license or "unknown",
            tags=list(model_info.tags),
            downloads=model_info.downloads,
            likes=model_info.likes,
            pipeline_tag=getattr(model_info, 'pipeline_tag', 'unknown'),
            library_name=getattr(model_info, 'library_name', 'unknown'),
            model_type=getattr(model_info, 'model_type', 'unknown')
        )
    
    def update_model_performance(self, model_id: str, metrics: ModelPerformanceMetrics):
        """Update performance metrics for a model."""
        if model_id in self.registry:
            with self.registry_lock:
                self.registry[model_id].performance_metrics = metrics
                self.registry[model_id].last_used = datetime.now()
                self.registry[model_id].usage_count += 1
    
    def get_all_models(self) -> List[ModelRegistryEntry]:
        """Get all registered models."""
        with self.registry_lock:
            return list(self.registry.values())
    
    def get_primary_models(self) -> List[ModelRegistryEntry]:
        """Get primary models."""
        with self.registry_lock:
            return [entry for entry in self.registry.values() if entry.is_primary]
    
    def get_fallback_models(self) -> List[ModelRegistryEntry]:
        """Get fallback models."""
        with self.registry_lock:
            return [entry for entry in self.registry.values() if entry.is_fallback]
    
    def find_models_by_tags(self, tags: List[str]) -> List[ModelRegistryEntry]:
        """Find models by tags."""
        with self.registry_lock:
            results = []
            for entry in self.registry.values():
                if any(tag in entry.metadata.tags for tag in tags):
                    results.append(entry)
            return results
    
    def search_models(
        self,
        query: str = None,
        author: str = None,
        tags: List[str] = None,
        min_downloads: int = 0
    ) -> List[ModelRegistryEntry]:
        """Search for models based on criteria."""
        with self.registry_lock:
            results = []
            for entry in self.registry.values():
                # Text search
                if query:
                    searchable_text = f"{entry.metadata.name} {entry.metadata.description} {entry.model_id}".lower()
                    if query.lower() not in searchable_text:
                        continue
                
                # Author filter
                if author and entry.metadata.author.lower() != author.lower():
                    continue
                
                # Tags filter
                if tags:
                    if not any(tag in entry.metadata.tags for tag in tags):
                        continue
                
                # Downloads filter
                if entry.metadata.downloads < min_downloads:
                    continue
                
                results.append(entry)
            
            # Sort by priority and usage
            results.sort(key=lambda x: (x.priority, x.usage_count), reverse=True)
            return results

# ==============================================================================
# MODEL DOWNLOAD MANAGER
# ==============================================================================

class ModelDownloadManager:
    """Manages model downloading with progress tracking and caching."""
    
    def __init__(self):
        self.cache_dir = MODEL_CACHE_DIR
        self.hf_cache_dir = HF_CACHE_DIR
        self.download_progress: Dict[str, float] = {}
        self.download_lock = asyncio.Lock()
        
        # Initialize cache directories
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.hf_cache_dir.mkdir(parents=True, exist_ok=True)
    
    async def download_model(
        self,
        model_id: str,
        version: str = None,
        force_download: bool = False,
        progress_callback: Callable = None
    ) -> Optional[Path]:
        """
        Download a model with progress tracking.
        
        Args:
            model_id: Model identifier
            version: Specific version to download
            force_download: Force re-download even if cached
            progress_callback: Optional progress callback
            
        Returns:
            Path to downloaded model or None if failed
        """
        model_path = self.cache_dir / model_id.replace("/", "_")
        
        # Check if model already exists
        if model_path.exists() and not force_download:
            # Verify model integrity
            if await self._verify_model_integrity(model_path):
                logger.info(f"Using cached model: {model_id}")
                return model_path
            else:
                logger.warning(f"Model cache corrupted, re-downloading: {model_id}")
                shutil.rmtree(model_path, ignore_errors=True)
        
        # Download model
        try:
            logger.info(f"Downloading model: {model_id}")
            
            async with self.download_lock:
                self.download_progress[model_id] = 0.0
            
            # Download with progress tracking
            downloaded_path = await self._download_with_progress(
                model_id, model_path, progress_callback
            )
            
            if downloaded_path:
                logger.info(f"Successfully downloaded model: {model_id}")
                return downloaded_path
            else:
                logger.error(f"Failed to download model: {model_id}")
                return None
                
        except Exception as e:
            logger.error(f"Error downloading model {model_id}: {e}")
            return None
        
        finally:
            # Clean up progress tracking
            async with self.download_lock:
                self.download_progress.pop(model_id, None)
    
    async def _download_with_progress(
        self,
        model_id: str,
        output_path: Path,
        progress_callback: Callable = None
    ) -> Optional[Path]:
        """Download model with progress tracking."""
        try:
            # Download model using sentence-transformers
            def download_func():
                return SentenceTransformer(model_id)
            
            # Track progress
            start_time = time.time()
            
            # Run download in executor to avoid blocking
            model = await asyncio.get_event_loop().run_in_executor(
                None, download_func
            )
            
            # Save model to cache
            model.save(str(output_path))
            
            total_time = time.time() - start_time
            logger.info(f"Model {model_id} downloaded in {total_time:.2f} seconds")
            
            # Update progress to 100%
            async with self.download_lock:
                self.download_progress[model_id] = 100.0
            
            if progress_callback:
                progress_callback(100.0, "Download completed")
            
            return output_path
            
        except Exception as e:
            logger.error(f"Download failed for {model_id}: {e}")
            return None
    
    async def _verify_model_integrity(self, model_path: Path) -> bool:
        """Verify model integrity."""
        try:
            # Check if required files exist
            required_files = ["config.json", "pytorch_model.bin"]
            for file_name in required_files:
                if not (model_path / file_name).exists():
                    return False
            
            # Try to load model (lightweight check)
            def load_check():
                try:
                    model = SentenceTransformer(str(model_path))
                    return len(model.get_sentence_embedding_dimension()) > 0
                except:
                    return False
            
            return await asyncio.get_event_loop().run_in_executor(None, load_check)
            
        except Exception as e:
            logger.warning(f"Model integrity check failed: {e}")
            return False
    
    def get_download_progress(self, model_id: str) -> float:
        """Get download progress for a model."""
        return self.download_progress.get(model_id, 0.0)
    
    def clear_cache(self, older_than_days: int = 7):
        """Clear old cached models."""
        cutoff_time = datetime.now() - timedelta(days=older_than_days)
        
        removed_count = 0
        for model_dir in self.cache_dir.iterdir():
            try:
                if model_dir.is_dir():
                    # Check modification time
                    if datetime.fromtimestamp(model_dir.stat().st_mtime) < cutoff_time:
                        shutil.rmtree(model_dir, ignore_errors=True)
                        removed_count += 1
            except Exception as e:
                logger.warning(f"Failed to remove cached model {model_dir}: {e}")
        
        logger.info(f"Cleared {removed_count} cached models older than {older_than_days} days")
        return removed_count

# ==============================================================================
# MODEL PERFORMANCE MONITOR
# ==============================================================================

class ModelPerformanceMonitor:
    """Monitors and tracks model performance metrics."""
    
    def __init__(self):
        self.metrics_history: Dict[str, List[ModelPerformanceMetrics]] = defaultdict(list)
        self.current_metrics: Dict[str, ModelPerformanceMetrics] = {}
        self.monitoring_lock = asyncio.Lock()
        
        # Performance thresholds
        self.latency_threshold_ms = 100
        self.memory_threshold_mb = 1024
        self.accuracy_threshold = 0.8
        self.error_rate_threshold = 0.05
    
    async def record_inference(
        self,
        model_id: str,
        version: str,
        inference_time_ms: float,
        memory_usage_mb: float,
        success: bool
    ):
        """Record inference performance metrics."""
        async with self.monitoring_lock:
            # Update current metrics
            if model_id not in self.current_metrics:
                self.current_metrics[model_id] = ModelPerformanceMetrics(
                    model_id=model_id,
                    version=version,
                    load_time_seconds=0.0,
                    inference_time_ms=inference_time_ms,
                    memory_usage_mb=memory_usage_mb,
                    throughput_docs_per_second=0.0,
                    accuracy_score=0.0,
                    cache_hit_rate=0.0,
                    error_rate=1.0 if not success else 0.0,
                    last_updated=datetime.now()
                )
            else:
                metrics = self.current_metrics[model_id]
                # Update with exponential moving average
                alpha = 0.1  # Smoothing factor
                
                metrics.inference_time_ms = (
                    alpha * inference_time_ms + (1 - alpha) * metrics.inference_time_ms
                )
                
                metrics.memory_usage_mb = (
                    alpha * memory_usage_mb + (1 - alpha) * metrics.memory_usage_mb
                )
                
                # Update error rate
                total_inferences = len(self.metrics_history[model_id]) + 1
                error_count = sum(1 for m in self.metrics_history[model_id] if m.error_rate > 0.5)
                if not success:
                    error_count += 1
                metrics.error_rate = error_count / total_inferences
            
            metrics.last_updated = datetime.now()
            
            # Store in history (keep last 100 entries)
            self.metrics_history[model_id].append(self.current_metrics[model_id])
            if len(self.metrics_history[model_id]) > 100:
                self.metrics_history[model_id].pop(0)
    
    async def record_model_load(self, model_id: str, load_time_seconds: float):
        """Record model loading performance."""
        async with self.monitoring_lock:
            if model_id not in self.current_metrics:
                self.current_metrics[model_id] = ModelPerformanceMetrics(
                    model_id=model_id,
                    version="1.0.0",
                    load_time_seconds=load_time_seconds,
                    inference_time_ms=0.0,
                    memory_usage_mb=0.0,
                    throughput_docs_per_second=0.0,
                    accuracy_score=0.0,
                    cache_hit_rate=0.0,
                    error_rate=0.0,
                    last_updated=datetime.now()
                )
            else:
                self.current_metrics[model_id].load_time_seconds = load_time_seconds
                self.current_metrics[model_id].last_updated = datetime.now()
    
    def get_model_performance(self, model_id: str) -> Optional[ModelPerformanceMetrics]:
        """Get current performance metrics for a model."""
        return self.current_metrics.get(model_id)
    
    def get_performance_history(self, model_id: str, limit: int = 10) -> List[ModelPerformanceMetrics]:
        """Get performance history for a model."""
        history = self.metrics_history.get(model_id, [])
        return history[-limit:] if limit > 0 else history
    
    def get_performance_comparison(self, model_ids: List[str]) -> Dict[str, Dict[str, float]]:
        """Compare performance across multiple models."""
        comparison = {}
        
        for model_id in model_ids:
            metrics = self.current_metrics.get(model_id)
            if metrics:
                comparison[model_id] = {
                    "inference_time_ms": metrics.inference_time_ms,
                    "memory_usage_mb": metrics.memory_usage_mb,
                    "error_rate": metrics.error_rate,
                    "throughput_docs_per_second": metrics.throughput_docs_per_second,
                    "last_updated": metrics.last_updated.isoformat() if metrics.last_updated else None
                }
        
        return comparison
    
    def analyze_performance_trends(self, model_id: str, hours: int = 24) -> Dict[str, Any]:
        """Analyze performance trends over time."""
        if model_id not in self.metrics_history:
            return {"error": "No performance data available"}
        
        history = self.metrics_history[model_id]
        
        # Filter by time window
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_metrics = [
            m for m in history 
            if m.last_updated and m.last_updated >= cutoff_time
        ]
        
        if not recent_metrics:
            return {"error": "No recent performance data"}
        
        # Calculate trends
        inference_times = [m.inference_time_ms for m in recent_metrics]
        memory_usage = [m.memory_usage_mb for m in recent_metrics]
        error_rates = [m.error_rate for m in recent_metrics]
        
        return {
            "model_id": model_id,
            "time_window_hours": hours,
            "data_points": len(recent_metrics),
            "inference_time": {
                "mean": float(np.mean(inference_times)),
                "std": float(np.std(inference_times)),
                "min": float(np.min(inference_times)),
                "max": float(np.max(inference_times)),
                "trend": self._calculate_trend(inference_times)
            },
            "memory_usage": {
                "mean": float(np.mean(memory_usage)),
                "std": float(np.std(memory_usage)),
                "max": float(np.max(memory_usage)),
                "trend": self._calculate_trend(memory_usage)
            },
            "error_rate": {
                "mean": float(np.mean(error_rates)),
                "max": float(np.max(error_rates)),
                "trend": self._calculate_trend(error_rates)
            }
        }
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction for a series of values."""
        if len(values) < 2:
            return "stable"
        
        # Simple linear trend
        x = np.arange(len(values))
        slope = np.polyfit(x, values, 1)[0]
        
        if abs(slope) < 0.01:
            return "stable"
        elif slope > 0:
            return "increasing"
        else:
            return "decreasing"
    
    def detect_performance_issues(self, model_id: str) -> List[str]:
        """Detect performance issues for a model."""
        issues = []
        
        metrics = self.current_metrics.get(model_id)
        if not metrics:
            return ["No performance metrics available"]
        
        # Check latency
        if metrics.inference_time_ms > self.latency_threshold_ms:
            issues.append(f"High latency: {metrics.inference_time_ms:.1f}ms > {self.latency_threshold_ms}ms")
        
        # Check memory usage
        if metrics.memory_usage_mb > self.memory_threshold_mb:
            issues.append(f"High memory usage: {metrics.memory_usage_mb:.1f}MB > {self.memory_threshold_mb}MB")
        
        # Check error rate
        if metrics.error_rate > self.error_rate_threshold:
            issues.append(f"High error rate: {metrics.error_rate:.3f} > {self.error_rate_threshold}")
        
        # Check if no recent data
        if metrics.last_updated:
            time_since_update = datetime.now() - metrics.last_update
            if time_since_update > timedelta(hours=1):
                issues.append("No recent performance data")
        
        return issues
    
    async def cleanup_old_metrics(self, max_age_hours: int = 168):  # 1 week
        """Clean up old performance metrics."""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        cleaned_count = 0
        for model_id, history in self.metrics_history.items():
            original_length = len(history)
            # Remove old entries
            self.metrics_history[model_id] = [
                m for m in history 
                if not m.last_updated or m.last_updated >= cutoff_time
            ]
            cleaned_count += original_length - len(self.metrics_history[model_id])
        
        logger.info(f"Cleaned up {cleaned_count} old performance metrics")
        return cleaned_count

# ==============================================================================
# MEMORY OPTIMIZER
# ==============================================================================

class MemoryOptimizer:
    """Optimizes memory usage for model management."""
    
    def __init__(self, max_memory_mb: int = 2048):
        self.max_memory_mb = max_memory_mb
        self.loaded_models: OrderedDict[str, datetime] = OrderedDict()
        self.memory_lock = asyncio.Lock()
        self.cleanup_threshold = 0.8  # 80% of max memory
        
        # Get current process
        self.process = psutil.Process()
    
    async def check_memory_usage(self) -> Dict[str, float]:
        """Check current memory usage."""
        memory_info = self.process.memory_info()
        system_memory = psutil.virtual_memory()
        
        return {
            "rss_mb": memory_info.rss / 1024 / 1024,
            "vms_mb": memory_info.vms / 1024 / 1024,
            "percent": self.process.memory_percent(),
            "system_percent": system_memory.percent,
            "system_available_gb": system_memory.available / (1024**3)
        }
    
    async def optimize_memory(self) -> Dict[str, Any]:
        """Optimize memory usage by unloading unused models."""
        memory_status = await self.check_memory_usage()
        
        actions_taken = []
        
        # Check if memory usage is above threshold
        if memory_status["percent"] > (self.cleanup_threshold * 100):
            actions_taken.append("Memory optimization triggered")
            
            # Unload oldest models
            models_to_unload = []
            
            async with self.memory_lock:
                while (len(self.loaded_models) > 0 and 
                       memory_status["percent"] > (self.cleanup_threshold * 100)):
                    
                    # Get oldest model
                    oldest_model_id = next(iter(self.loaded_models))
                    models_to_unload.append(oldest_model_id)
                    
                    # Remove from loaded models
                    del self.loaded_models[oldest_model_id]
                    
                    # Simulate unloading (in real implementation, would call model's unload method)
                    logger.info(f"Unloading model from memory: {oldest_model_id}")
                    
                    # Re-check memory
                    memory_status = await self.check_memory_usage()
            
            actions_taken.append(f"Unloaded {len(models_to_unload)} models: {models_to_unload}")
        
        # Force garbage collection
        import gc
        gc.collect()
        
        final_memory = await self.check_memory_usage()
        
        return {
            "actions_taken": actions_taken,
            "memory_before": memory_status,
            "memory_after": final_memory,
            "optimization_needed": memory_status["percent"] > (self.cleanup_threshold * 100)
        }
    
    async def register_model_load(self, model_id: str):
        """Register that a model has been loaded."""
        async with self.memory_lock:
            # Move to end (most recently used)
            if model_id in self.loaded_models:
                del self.loaded_models[model_id]
            self.loaded_models[model_id] = datetime.now()
            
            # Keep only most recent models
            while len(self.loaded_models) > MAX_MODELS_IN_MEMORY:
                oldest_model = next(iter(self.loaded_models))
                del self.loaded_models[oldest_model]
                logger.info(f"Automatically unloaded model: {oldest_model}")
    
    async def register_model_unload(self, model_id: str):
        """Register that a model has been unloaded."""
        async with self.memory_lock:
            self.loaded_models.pop(model_id, None)
    
    def get_loaded_models(self) -> List[str]:
        """Get list of currently loaded models."""
        return list(self.loaded_models.keys())

# ==============================================================================
# MAIN MODEL MANAGER
# ==============================================================================

class ModelManager:
    """
    Comprehensive model management system.
    
    This class integrates all model management functionality:
    - Model registry and discovery
    - Model downloading and caching
    - Performance monitoring and optimization
    - Memory management and cleanup
    - Version management and updates
    """
    
    def __init__(self):
        self.registry = ModelRegistry()
        self.download_manager = ModelDownloadManager()
        self.performance_monitor = ModelPerformanceMonitor()
        self.memory_optimizer = MemoryOptimizer()
        
        self.loaded_models: Dict[str, SentenceTransformer] = {}
        self.model_locks: Dict[str, asyncio.Lock] = {}
        
        # Background tasks
        self.cleanup_task = None
        self.optimization_task = None
        
        logger.info("Model manager initialized")
    
    async def initialize(self):
        """Initialize the model manager."""
        logger.info("Initializing model manager...")
        
        # Start background tasks
        self.cleanup_task = asyncio.create_task(self._periodic_cleanup())
        self.optimization_task = asyncio.create_task(self._periodic_optimization())
        
        logger.info("Model manager initialized successfully")
    
    async def shutdown(self):
        """Shutdown the model manager."""
        logger.info("Shutting down model manager...")
        
        # Cancel background tasks
        if self.cleanup_task:
            self.cleanup_task.cancel()
            try:
                await self.cleanup_task
            except asyncio.CancelledError:
                pass
        
        if self.optimization_task:
            self.optimization_task.cancel()
            try:
                await self.optimization_task
            except asyncio.CancelledError:
                pass
        
        # Unload all models
        for model_id in list(self.loaded_models.keys()):
            await self.unload_model(model_id)
        
        logger.info("Model manager shutdown complete")
    
    async def load_model(
        self,
        model_id: str,
        version: str = None,
        force_reload: bool = False,
        progress_callback: Callable = None
    ) -> SentenceTransformer:
        """Load a model with caching and performance tracking."""
        model_lock = self.model_locks.setdefault(model_id, asyncio.Lock())
        
        async with model_lock:
            # Check if already loaded
            if not force_reload and model_id in self.loaded_models:
                await self.memory_optimizer.register_model_load(model_id)
                await self.performance_monitor.record_model_load(model_id, 0.0)
                return self.loaded_models[model_id]
            
            start_time = time.time()
            
            try:
                # Download model if not cached
                model_path = await self.download_manager.download_model(
                    model_id, version, progress_callback=progress_callback
                )
                
                if not model_path:
                    raise Exception(f"Failed to download model: {model_id}")
                
                # Load model
                def load_func():
                    return SentenceTransformer(str(model_path))
                
                model = await asyncio.get_event_loop().run_in_executor(None, load_func)
                
                # Store loaded model
                self.loaded_models[model_id] = model
                
                # Record performance
                load_time = time.time() - start_time
                await self.performance_monitor.record_model_load(model_id, load_time)
                await self.memory_optimizer.register_model_load(model_id)
                
                # Update registry
                await self.registry.update_model_performance(
                    model_id,
                    self.performance_monitor.get_model_performance(model_id)
                )
                
                logger.info(f"Loaded model {model_id} in {load_time:.2f} seconds")
                return model
                
            except Exception as e:
                logger.error(f"Failed to load model {model_id}: {e}")
                raise
    
    async def unload_model(self, model_id: str) -> bool:
        """Unload a model to free memory."""
        if model_id not in self.loaded_models:
            return False
        
        try:
            # Remove from loaded models
            del self.loaded_models[model_id]
            
            # Clean up lock
            self.model_locks.pop(model_id, None)
            
            # Register unload
            await self.memory_optimizer.register_model_unload(model_id)
            
            logger.info(f"Unloaded model: {model_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to unload model {model_id}: {e}")
            return False
    
    async def get_model(
        self,
        model_id: str = None,
        version: str = None,
        force_reload: bool = False,
        progress_callback: Callable = None
    ) -> SentenceTransformer:
        """Get a model with automatic fallback."""
        if model_id:
            try:
                return await self.load_model(model_id, version, force_reload, progress_callback)
            except Exception as e:
                logger.warning(f"Failed to load specified model {model_id}: {e}")
        
        # Try primary models first
        primary_models = self.registry.get_primary_models()
        for entry in sorted(primary_models, key=lambda x: x.priority, reverse=True):
            try:
                return await self.load_model(entry.model_id, version, force_reload, progress_callback)
            except Exception as e:
                logger.warning(f"Primary model {entry.model_id} failed: {e}")
                continue
        
        # Try fallback models
        fallback_models = self.registry.get_fallback_models()
        for entry in sorted(fallback_models, key=lambda x: x.priority, reverse=True):
            try:
                return await self.load_model(entry.model_id, version, force_reload, progress_callback)
            except Exception as e:
                logger.warning(f"Fallback model {entry.model_id} failed: {e}")
                continue
        
        raise Exception("All models failed to load")
    
    async def search_models(
        self,
        query: str = None,
        author: str = None,
        tags: List[str] = None,
        min_downloads: int = 0
    ) -> List[ModelRegistryEntry]:
        """Search for models in the registry."""
        return self.registry.search_models(
            query=query,
            author=author,
            tags=tags,
            min_downloads=min_downloads
        )
    
    async def get_model_performance(self, model_id: str) -> Optional[ModelPerformanceMetrics]:
        """Get performance metrics for a model."""
        return self.performance_monitor.get_model_performance(model_id)
    
    async def compare_models(self, model_ids: List[str]) -> Dict[str, Any]:
        """Compare performance across multiple models."""
        comparison = self.performance_monitor.get_performance_comparison(model_ids)
        
        # Add performance issues
        for model_id in model_ids:
            issues = self.performance_monitor.detect_performance_issues(model_id)
            if model_id in comparison:
                comparison[model_id]["issues"] = issues
        
        return {
            "models": comparison,
            "comparison_timestamp": datetime.now().isoformat()
        }
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status."""
        memory_status = await self.memory_optimizer.check_memory_usage()
        loaded_models = list(self.loaded_models.keys())
        
        # Get performance issues
        performance_issues = {}
        for model_id in loaded_models:
            issues = self.performance_monitor.detect_performance_issues(model_id)
            if issues:
                performance_issues[model_id] = issues
        
        return {
            "loaded_models": {
                "count": len(loaded_models),
                "model_ids": loaded_models,
                "memory_usage": memory_status
            },
            "registry": {
                "total_models": len(self.registry.get_all_models()),
                "primary_models": len(self.registry.get_primary_models()),
                "fallback_models": len(self.registry.get_fallback_models())
            },
            "performance": {
                "issues_detected": len(performance_issues),
                "model_issues": performance_issues
            },
            "system": {
                "status": "healthy" if len(performance_issues) == 0 else "degraded",
                "optimization_needed": memory_status["percent"] > 80
            }
        }
    
    async def _periodic_cleanup(self):
        """Periodic cleanup of old metrics and cache."""
        while True:
            try:
                await asyncio.sleep(3600)  # Every hour
                
                # Clean up old performance metrics
                await self.performance_monitor.cleanup_old_metrics()
                
                # Clear old cache
                self.download_manager.clear_cache(older_than_days=7)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Periodic cleanup error: {e}")
    
    async def _periodic_optimization(self):
        """Periodic memory optimization."""
        while True:
            try:
                await asyncio.sleep(1800)  # Every 30 minutes
                
                # Optimize memory
                optimization_result = await self.memory_optimizer.optimize_memory()
                
                if optimization_result["optimization_needed"]:
                    logger.info(f"Memory optimization performed: {optimization_result}")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Periodic optimization error: {e}")
    
    # Context manager support
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.shutdown()

# ==============================================================================
# FACTORY FUNCTION
# ==============================================================================

def create_model_manager() -> ModelManager:
    """Factory function to create and configure a model manager."""
    return ModelManager()

# ==============================================================================
# GLOBAL INSTANCE
# ==============================================================================

# Global model manager instance (singleton pattern)
_model_manager_instance = None

def get_global_model_manager() -> ModelManager:
    """Get or create global model manager instance."""
    global _model_manager_instance
    
    if _model_manager_instance is None:
        _model_manager_instance = create_model_manager()
    
    return _model_manager_instance