"""
Comprehensive Embedding Service with SentenceTransformers Integration.

This module provides a production-ready embedding service with:
- Advanced SentenceTransformers model integration
- Model management (download, caching, versioning, performance monitoring)
- Batch processing with parallel capabilities and progress tracking
- Embedding utilities (preprocessing, similarity, validation, analytics)
- Error handling and fallbacks
- Resource management and memory optimization

Key Features:
- Multi-model support with automatic fallback
- Intelligent caching strategies (memory + Redis)
- Batch processing with cancellation support
- Performance monitoring and analytics
- Model versioning and updates
- Text preprocessing optimization
- Embedding similarity calculations
- Validation and testing utilities

Author: AI Agent System
Version: 2.0.0
"""

# Set tiktoken cache directory to writable location
import os
import tempfile
tiktoken_cache_dir = os.path.join(tempfile.gettempdir(), 'tiktoken_cache')
os.environ['TIKTOKEN_CACHE_DIR'] = tiktoken_cache_dir

# Ensure cache directory exists
os.makedirs(tiktoken_cache_dir, exist_ok=True)

# Compatibility patch for huggingface_hub
# This must be done before importing sentence_transformers
try:
    from huggingface_hub import cached_download
except ImportError:
    # If cached_download is not available, create it
    from huggingface_hub import hf_hub_download as _hf_hub_download
    import warnings
    
    def cached_download(url, cache_dir=None, **kwargs):
        """
        Backward compatibility function for cached_download.
        Maps old parameters to new hf_hub_download function.
        """
        warnings.warn(
            "cached_download is deprecated. Use hf_hub_download instead.",
            DeprecationWarning,
            stacklevel=2
        )
        
        # Map old parameters to new ones
        if cache_dir:
            kwargs['local_dir'] = cache_dir
        
        if 'url' in kwargs:
            kwargs.pop('url')  # Remove old parameter
        
        return _hf_hub_download(repo_url=url, **kwargs)

# Add to huggingface_hub module to make it available for sentence_transformers
import huggingface_hub
if not hasattr(huggingface_hub, 'cached_download'):
    huggingface_hub.cached_download = cached_download

import asyncio
import hashlib
import json
import logging
import os
import psutil
import time
import weakref
from collections import OrderedDict, defaultdict
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from dataclasses import dataclass, asdict
from functools import lru_cache, wraps
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any, Callable, AsyncGenerator
from datetime import datetime, timedelta
import warnings

import numpy as np
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import tiktoken
import tiktoken_ext
from redis import asyncio as aioredis

from app.config import settings

# Configure logging
logger = logging.getLogger(__name__)

# ==============================================================================
# DATA STRUCTURES AND CONSTANTS
# ==============================================================================

@dataclass
class ModelInfo:
    """Information about an embedding model."""
    name: str
    version: str
    dimension: int
    description: str
    max_seq_length: int
    language: str = "en"
    size_mb: int = 0
    download_date: Optional[datetime] = None
    last_used: Optional[datetime] = None
    usage_count: int = 0
    performance_metrics: Optional[Dict[str, float]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        # Convert datetime objects to strings for JSON serialization
        if self.download_date:
            data['download_date'] = self.download_date.isoformat()
        if self.last_used:
            data['last_used'] = self.last_used.isoformat()
        return data

@dataclass
class EmbeddingResult:
    """Result of embedding generation."""
    embedding: List[float]
    text: str
    model_name: str
    dimension: int
    processing_time: float
    cache_hit: bool = False
    batch_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

@dataclass
class BatchProcessingResult:
    """Result of batch embedding processing."""
    batch_id: str
    total_texts: int
    successful: int
    failed: int
    results: List[EmbeddingResult]
    processing_time: float
    memory_usage_mb: float
    errors: List[str]
    cancelled: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        data['errors'] = self.errors
        return data

@dataclass
class PerformanceMetrics:
    """Performance metrics for embedding operations."""
    total_requests: int = 0
    total_processing_time: float = 0.0
    average_latency: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    cache_hit_rate: float = 0.0
    peak_memory_mb: float = 0.0
    model_load_time: float = 0.0
    batch_operations: int = 0
    error_count: int = 0
    error_rate: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

# Model configurations and fallback chain
EMBEDDING_MODELS = {
    "primary": {
        "name": "sentence-transformers/all-MiniLM-L6-v2",
        "dimension": 384,
        "max_seq_length": 256,
        "description": "Fast and efficient for general use",
        "language": "multilingual"
    },
    "fallback": [
        {
            "name": "all-MiniLM-L6-v2",
            "dimension": 384,
            "max_seq_length": 256,
            "description": "Alternative MiniLM model",
            "language": "en"
        },
        {
            "name": "sentence-transformers/all-mpnet-base-v2",
            "dimension": 768,
            "max_seq_length": 384,
            "description": "High-quality embeddings with better performance",
            "language": "multilingual"
        },
        {
            "name": "all-mpnet-base-v2",
            "dimension": 768,
            "max_seq_length": 384,
            "description": "Alternative MPNet model",
            "language": "en"
        }
    ]
}

# Processing constants
DEFAULT_BATCH_SIZE = 32
MAX_BATCH_SIZE = 100
CACHE_TTL = 3600  # 1 hour
EMBEDDING_CACHE_KEY = "embedding_cache"
MODEL_CACHE_KEY = "model_cache"
PERFORMANCE_CACHE_KEY = "performance_cache"

# Memory management
MAX_MEMORY_CACHE_SIZE = 1000
MAX_EMBEDDING_CACHE_SIZE = 5000
MEMORY_THRESHOLD_MB = 1024  # 1GB

# Performance thresholds
LATENCY_THRESHOLD_MS = 100
MEMORY_THRESHOLD_PERCENT = 80

# ==============================================================================
# EXCEPTION CLASSES
# ==============================================================================

class EmbeddingServiceError(Exception):
    """Base exception for embedding service errors."""
    pass

class ModelLoadError(EmbeddingServiceError):
    """Raised when model loading fails."""
    pass

class ModelNotFoundError(EmbeddingServiceError):
    """Raised when specified model is not found."""
    pass

class ProcessingError(EmbeddingServiceError):
    """Raised when text processing fails."""
    pass

class BatchProcessingError(EmbeddingServiceError):
    """Raised when batch processing fails."""
    pass

class ResourceLimitError(EmbeddingServiceError):
    """Raised when system resource limits are exceeded."""
    pass

# ==============================================================================
# UTILITY FUNCTIONS
# ==============================================================================

def measure_time(func: Callable) -> Callable:
    """Decorator to measure function execution time."""
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = await func(*args, **kwargs)
            return result
        finally:
            elapsed = time.time() - start_time
            logger.debug(f"{func.__name__} took {elapsed:.3f} seconds")
    return async_wrapper

def generate_cache_key(text: str, model_name: str) -> str:
    """Generate cache key for text and model combination."""
    content = f"{model_name}:{text}"
    return hashlib.sha256(content.encode()).hexdigest()

def truncate_text(text: str, max_length: int = 512) -> str:
    """Truncate text to max length while preserving word boundaries."""
    if len(text) <= max_length:
        return text
    
    # Try to truncate at word boundary
    truncated = text[:max_length]
    last_space = truncated.rfind(' ')
    
    if last_space > max_length * 0.8:  # Only if we don't lose too much content
        return truncated[:last_space] + "..."
    
    return truncated + "..."

def validate_embedding(embedding: List[float]) -> bool:
    """Validate that embedding is properly formed."""
    if not embedding:
        return False
    
    # Check for NaN or inf values
    embedding_array = np.array(embedding)
    if not np.all(np.isfinite(embedding_array)):
        return False
    
    # Check dimension is reasonable
    if len(embedding) < 100 or len(embedding) > 2000:
        return False
    
    return True

def get_text_statistics(texts: List[str]) -> Dict[str, Any]:
    """Get statistics about a list of texts."""
    if not texts:
        return {}
    
    lengths = [len(text) for text in texts]
    word_counts = [len(text.split()) for text in texts]
    
    return {
        "total_texts": len(texts),
        "total_characters": sum(lengths),
        "average_length": np.mean(lengths),
        "min_length": min(lengths),
        "max_length": max(lengths),
        "total_words": sum(word_counts),
        "average_words": np.mean(word_counts),
        "min_words": min(word_counts),
        "max_words": max(word_counts)
    }

# ==============================================================================
# MODEL MANAGER
# ==============================================================================

class ModelManager:
    """Manages embedding models with caching, versioning, and performance monitoring."""
    
    def __init__(self):
        self.models: Dict[str, SentenceTransformer] = {}
        self.model_info: Dict[str, ModelInfo] = {}
        self.load_times: Dict[str, float] = {}
        self.performance_metrics: Dict[str, PerformanceMetrics] = {}
        self._model_lock = asyncio.Lock()
        self._model_registry = self._initialize_model_registry()
        
        # Initialize Redis connection for model caching
        self.redis_client = None
        try:
            if settings.redis_url:
                self.redis_client = aioredis.from_url(settings.redis_url)
        except Exception as e:
            logger.warning(f"Failed to initialize Redis for model cache: {e}")
    
    def _initialize_model_registry(self) -> Dict[str, Dict[str, Any]]:
        """Initialize the model registry with configuration."""
        registry = {}
        
        # Add primary model
        primary_model = EMBEDDING_MODELS["primary"]
        registry[primary_model["name"]] = {
            **primary_model,
            "is_primary": True,
            "priority": 1
        }
        
        # Add fallback models
        for i, model in enumerate(EMBEDDING_MODELS["fallback"]):
            registry[model["name"]] = {
                **model,
                "is_primary": False,
                "priority": i + 2
            }
        
        return registry
    
    async def initialize(self):
        """Initialize the model manager."""
        logger.info("Initializing model manager...")
        
        # Pre-load primary model
        try:
            await self.load_model(EMBEDDING_MODELS["primary"]["name"])
            logger.info("Primary model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load primary model: {e}")
            raise
    
    async def load_model(self, model_name: str, force_reload: bool = False) -> SentenceTransformer:
        """Load a model with caching and performance tracking."""
        async with self._model_lock:
            if not force_reload and model_name in self.models:
                # Update usage statistics
                if model_name in self.model_info:
                    self.model_info[model_name].usage_count += 1
                    self.model_info[model_name].last_used = datetime.now()
                
                return self.models[model_name]
            
            # Check if model is in registry
            if model_name not in self._model_registry:
                raise ModelNotFoundError(f"Model {model_name} not found in registry")
            
            model_config = self._model_registry[model_name]
            load_start_time = time.time()
            
            try:
                # Load model with progress tracking
                logger.info(f"Loading model: {model_name}")
                model = SentenceTransformer(model_name)
                
                # Track loading time
                load_time = time.time() - load_start_time
                self.load_times[model_name] = load_time
                
                # Store model
                self.models[model_name] = model
                
                # Store model information
                self.model_info[model_name] = ModelInfo(
                    name=model_name,
                    version=getattr(model, '_model_card', 'unknown'),
                    dimension=model_config["dimension"],
                    description=model_config["description"],
                    max_seq_length=model_config["max_seq_length"],
                    language=model_config["language"],
                    download_date=datetime.now(),
                    last_used=datetime.now(),
                    usage_count=1,
                    performance_metrics={}
                )
                
                # Initialize performance metrics
                self.performance_metrics[model_name] = PerformanceMetrics()
                
                logger.info(f"Model {model_name} loaded successfully in {load_time:.2f} seconds")
                return model
                
            except Exception as e:
                logger.error(f"Failed to load model {model_name}: {e}")
                raise ModelLoadError(f"Failed to load model {model_name}: {e}")
    
    async def get_model(self, model_name: str = None) -> SentenceTransformer:
        """Get a model with automatic fallback."""
        if model_name:
            try:
                return await self.load_model(model_name)
            except Exception as e:
                logger.warning(f"Failed to load specified model {model_name}: {e}")
        
        # Try primary model first
        try:
            primary_model_name = EMBEDDING_MODELS["primary"]["name"]
            return await self.load_model(primary_model_name)
        except Exception as e:
            logger.warning(f"Primary model failed: {e}")
            
            # Try fallback models
            for fallback_model in EMBEDDING_MODELS["fallback"]:
                try:
                    fallback_name = fallback_model["name"]
                    return await self.load_model(fallback_name)
                except Exception as fallback_error:
                    logger.warning(f"Fallback model {fallback_name} failed: {fallback_error}")
                    continue
            
            raise ModelLoadError("All models failed to load")
    
    async def unload_model(self, model_name: str):
        """Unload a model to free memory."""
        async with self._model_lock:
            if model_name in self.models:
                del self.models[model_name]
                logger.info(f"Model {model_name} unloaded")
    
    def get_model_info(self, model_name: str) -> Optional[ModelInfo]:
        """Get information about a model."""
        return self.model_info.get(model_name)
    
    def get_all_models_info(self) -> List[ModelInfo]:
        """Get information about all loaded models."""
        return list(self.model_info.values())
    
    def get_performance_metrics(self, model_name: str = None) -> Dict[str, PerformanceMetrics]:
        """Get performance metrics for models."""
        if model_name:
            return {model_name: self.performance_metrics.get(model_name, PerformanceMetrics())}
        return self.performance_metrics.copy()
    
    async def get_system_stats(self) -> Dict[str, Any]:
        """Get system statistics and resource usage."""
        process = psutil.Process()
        memory_info = process.memory_info()
        system_memory = psutil.virtual_memory()
        
        return {
            "models_loaded": len(self.models),
            "memory_usage_mb": memory_info.rss / 1024 / 1024,
            "memory_percent": process.memory_percent(),
            "system_memory_percent": system_memory.percent,
            "cpu_percent": process.cpu_percent(),
            "available_models": list(self._model_registry.keys()),
            "model_load_times": self.load_times.copy(),
            "total_model_usage": sum(info.usage_count for info in self.model_info.values())
        }
    
    async def cleanup_unused_models(self, max_age_hours: int = 24, max_memory_mb: int = 2048):
        """Clean up unused models based on age and memory constraints."""
        current_time = datetime.now()
        
        # Get current memory usage
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        
        models_to_remove = []
        
        for model_name, model_info in self.model_info.items():
            # Check if model should be removed
            should_remove = False
            
            # Check age
            if model_info.last_used:
                age_hours = (current_time - model_info.last_used).total_seconds() / 3600
                if age_hours > max_age_hours:
                    should_remove = True
            
            # Check memory
            if memory_mb > max_memory_mb and not model_info.is_primary:
                should_remove = True
            
            if should_remove:
                models_to_remove.append(model_name)
        
        # Remove unused models
        for model_name in models_to_remove:
            await self.unload_model(model_name)
        
        if models_to_remove:
            logger.info(f"Cleaned up {len(models_to_remove)} unused models")
        
        return models_to_remove
    
    async def close(self):
        """Cleanup resources."""
        # Close Redis connection
        if self.redis_client:
            await self.redis_client.close()
        
        # Clear all models
        self.models.clear()
        logger.info("Model manager closed")

# ==============================================================================
# TEXT PREPROCESSOR
# ==============================================================================

class TextPreprocessor:
    """Handles text preprocessing and optimization for embeddings."""
    
    def __init__(self):
        self.encoding = tiktoken.get_encoding("cl100k_base")  # GPT-4 encoding
        
        # Load additional encoding if available
        try:
            self.extra_encoding = tiktoken.get_encoding("o200k_base")  # GPT-4o encoding
        except:
            self.extra_encoding = None
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        if not text:
            return ""
        
        # Basic cleaning
        text = text.strip()
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        # Remove excessive whitespace
        import re
        text = re.sub(r'\s+', ' ', text)
        
        # Remove control characters except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
        
        return text.strip()
    
    def truncate_for_model(self, text: str, max_length: int, model_max_length: int = 512) -> str:
        """Truncate text to fit model constraints."""
        # First, truncate to max_length if specified
        if len(text) > max_length:
            text = truncate_text(text, max_length)
        
        # Then ensure it fits model constraints
        if len(text) > model_max_length * 4:  # Approximate character limit
            return truncate_text(text, model_max_length * 4)
        
        return text
    
    def encode_length_estimate(self, text: str) -> int:
        """Estimate token length using tiktoken."""
        if self.extra_encoding:
            try:
                return len(self.extra_encoding.encode(text))
            except:
                pass
        
        try:
            return len(self.encoding.encode(text))
        except:
            # Fallback to approximate estimation
            return len(text.split()) * 1.3
    
    def preprocess_batch(self, texts: List[str], max_length: int = None) -> List[str]:
        """Preprocess a batch of texts."""
        if max_length is None:
            max_length = 512  # Default for most models
        
        processed_texts = []
        
        for text in texts:
            # Clean text
            clean_text = self.clean_text(text)
            
            # Check if text is too long
            if self.encode_length_estimate(clean_text) > max_length:
                clean_text = self.truncate_for_model(clean_text, max_length * 4)
            
            processed_texts.append(clean_text)
        
        return processed_texts
    
    def validate_batch(self, texts: List[str]) -> Tuple[List[str], List[str]]:
        """Validate a batch of texts and return valid and invalid separately."""
        valid_texts = []
        invalid_texts = []
        
        for text in texts:
            # Basic validation
            if not text or not text.strip():
                invalid_texts.append(text)
                continue
            
            # Check for minimum content
            if len(text.strip()) < 5:
                invalid_texts.append(text)
                continue
            
            # Check for excessive non-printable characters
            printable_ratio = sum(c.isprintable() or c.isspace() for c in text) / len(text)
            if printable_ratio < 0.8:
                invalid_texts.append(text)
                continue
            
            valid_texts.append(text)
        
        return valid_texts, invalid_texts

# ==============================================================================
# EMBEDDING CACHE
# ==============================================================================

class EmbeddingCache:
    """Multi-level caching system for embeddings (memory + Redis)."""
    
    def __init__(self, model_manager: ModelManager):
        self.model_manager = model_manager
        self.memory_cache = OrderedDict()  # LRU cache
        self.memory_cache_size = 0
        self.redis_client = None
        self.cache_stats = defaultdict(int)
        
        # Initialize Redis if available
        try:
            if settings.redis_url:
                self.redis_client = aioredis.from_url(settings.redis_url)
        except Exception as e:
            logger.warning(f"Failed to initialize Redis for embedding cache: {e}")
    
    def _get_cache_key(self, text: str, model_name: str) -> str:
        """Generate cache key."""
        return generate_cache_key(text, model_name)
    
    async def get(self, text: str, model_name: str) -> Optional[List[float]]:
        """Get embedding from cache."""
        cache_key = self._get_cache_key(text, model_name)
        
        # Check memory cache first
        if cache_key in self.memory_cache:
            # Move to end for LRU
            embedding = self.memory_cache.pop(cache_key)
            self.memory_cache[cache_key] = embedding
            self.cache_stats['memory_hits'] += 1
            return embedding
        
        # Check Redis cache
        if self.redis_client:
            try:
                cached = await self.redis_client.get(f"{EMBEDDING_CACHE_KEY}:{cache_key}")
                if cached:
                    embedding = json.loads(cached)
                    # Add to memory cache
                    self._add_to_memory_cache(cache_key, embedding)
                    self.cache_stats['redis_hits'] += 1
                    return embedding
            except Exception as e:
                logger.warning(f"Redis cache lookup failed: {e}")
        
        self.cache_stats['misses'] += 1
        return None
    
    def _add_to_memory_cache(self, cache_key: str, embedding: List[float]):
        """Add embedding to memory cache with LRU eviction."""
        # Remove if exists (will be re-added at end)
        if cache_key in self.memory_cache:
            self.memory_cache.pop(cache_key)
        
        # Add to end
        self.memory_cache[cache_key] = embedding
        self.memory_cache_size += 1
        
        # Evict if too large
        while len(self.memory_cache) > MAX_MEMORY_CACHE_SIZE:
            oldest_key = next(iter(self.memory_cache))
            del self.memory_cache[oldest_key]
            self.memory_cache_size -= 1
    
    async def set(self, text: str, model_name: str, embedding: List[float], ttl: int = CACHE_TTL):
        """Set embedding in cache."""
        cache_key = self._get_cache_key(text, model_name)
        
        # Add to memory cache
        self._add_to_memory_cache(cache_key, embedding)
        
        # Add to Redis cache
        if self.redis_client:
            try:
                await self.redis_client.setex(
                    f"{EMBEDDING_CACHE_KEY}:{cache_key}",
                    ttl,
                    json.dumps(embedding)
                )
            except Exception as e:
                logger.warning(f"Redis cache storage failed: {e}")
    
    async def clear(self):
        """Clear all caches."""
        self.memory_cache.clear()
        self.memory_cache_size = 0
        
        if self.redis_client:
            try:
                await self.redis_client.delete(f"{EMBEDDING_CACHE_KEY}:*")
            except Exception as e:
                logger.warning(f"Redis cache clear failed: {e}")
        
        self.cache_stats.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = (
            self.cache_stats['memory_hits'] + 
            self.cache_stats['redis_hits'] + 
            self.cache_stats['misses']
        )
        
        hit_rate = 0
        if total_requests > 0:
            hit_rate = (self.cache_stats['memory_hits'] + self.cache_stats['redis_hits']) / total_requests
        
        return {
            "memory_cache_size": len(self.memory_cache),
            "memory_cache_max_size": MAX_MEMORY_CACHE_SIZE,
            "memory_hits": self.cache_stats['memory_hits'],
            "redis_hits": self.cache_stats['redis_hits'],
            "misses": self.cache_stats['misses'],
            "hit_rate": hit_rate,
            "total_requests": total_requests,
            "redis_available": self.redis_client is not None
        }

# ==============================================================================
# MAIN EMBEDDING SERVICE
# ==============================================================================

class EmbeddingService:
    """
    Comprehensive Embedding Service with advanced features.
    
    This service provides:
    - Multi-model support with automatic fallback
    - Intelligent batch processing with cancellation
    - Multi-level caching (memory + Redis)
    - Performance monitoring and analytics
    - Text preprocessing optimization
    - Embedding similarity calculations
    - Resource management and optimization
    """
    
    def __init__(self):
        self.model_manager = ModelManager()
        self.preprocessor = TextPreprocessor()
        self.cache = None  # Will be initialized after model_manager
        self.batch_processors: Dict[str, asyncio.Task] = {}
        self.batch_queue = asyncio.Queue()
        self.active_batches = set()
        self._shutdown_event = asyncio.Event()
        
        # Performance tracking
        self.global_metrics = PerformanceMetrics()
        self.start_time = time.time()
        
        # Resource monitoring
        self.resource_monitor_task = None
        
        logger.info("Embedding service initialized")
    
    async def initialize(self):
        """Initialize the embedding service and all components."""
        logger.info("Initializing embedding service...")
        
        # Initialize model manager
        await self.model_manager.initialize()
        
        # Initialize cache
        self.cache = EmbeddingCache(self.model_manager)
        
        # Start resource monitoring
        self.resource_monitor_task = asyncio.create_task(self._resource_monitor())
        
        logger.info("Embedding service initialized successfully")
    
    async def shutdown(self):
        """Shutdown the embedding service gracefully."""
        logger.info("Shutting down embedding service...")
        
        # Signal shutdown
        self._shutdown_event.set()
        
        # Cancel active batches
        for batch_id in list(self.active_batches):
            await self.cancel_batch(batch_id)
        
        # Wait for resource monitor to stop
        if self.resource_monitor_task:
            self.resource_monitor_task.cancel()
            try:
                await self.resource_monitor_task
            except asyncio.CancelledError:
                pass
        
        # Close model manager
        await self.model_manager.close()
        
        logger.info("Embedding service shutdown complete")
    
    async def generate_embedding(
        self, 
        text: str, 
        model_name: str = None,
        use_cache: bool = True,
        preprocess: bool = True
    ) -> EmbeddingResult:
        """
        Generate embedding for a single text with caching and optimization.
        
        Args:
            text: Input text
            model_name: Model name (uses primary if None)
            use_cache: Whether to use caching
            preprocess: Whether to preprocess text
            
        Returns:
            EmbeddingResult with embedding and metadata
        """
        start_time = time.time()
        
        # Get model
        model = await self.model_manager.get_model(model_name)
        actual_model_name = model_name or EMBEDDING_MODELS["primary"]["name"]
        
        # Check cache if enabled
        cache_hit = False
        if use_cache:
            cached_embedding = await self.cache.get(text, actual_model_name)
            if cached_embedding:
                processing_time = time.time() - start_time
                cache_hit = True
                
                # Update metrics
                self.global_metrics.cache_hits += 1
                self.global_metrics.total_requests += 1
                self.global_metrics.total_processing_time += processing_time
                
                return EmbeddingResult(
                    embedding=cached_embedding,
                    text=text,
                    model_name=actual_model_name,
                    dimension=len(cached_embedding),
                    processing_time=processing_time,
                    cache_hit=True
                )
        
        # Preprocess text if enabled
        if preprocess:
            text = self.preprocessor.clean_text(text)
        
        try:
            # Generate embedding
            embedding = model.encode(text).tolist()
            
            processing_time = time.time() - start_time
            
            # Validate embedding
            if not validate_embedding(embedding):
                raise ProcessingError("Generated embedding is invalid")
            
            # Cache if enabled
            if use_cache:
                await self.cache.set(text, actual_model_name, embedding)
            
            # Update metrics
            self.global_metrics.cache_misses += 1
            self.global_metrics.total_requests += 1
            self.global_metrics.total_processing_time += processing_time
            
            # Update model-specific metrics
            if actual_model_name in self.model_manager.performance_metrics:
                metrics = self.model_manager.performance_metrics[actual_model_name]
                metrics.total_requests += 1
                metrics.total_processing_time += processing_time
                metrics.average_latency = metrics.total_processing_time / metrics.total_requests
            
            return EmbeddingResult(
                embedding=embedding,
                text=text,
                model_name=actual_model_name,
                dimension=len(embedding),
                processing_time=processing_time,
                cache_hit=False
            )
            
        except Exception as e:
            self.global_metrics.error_count += 1
            self.global_metrics.error_rate = self.global_metrics.error_count / self.global_metrics.total_requests
            logger.error(f"Failed to generate embedding: {e}")
            raise ProcessingError(f"Embedding generation failed: {e}")
    
    async def generate_embeddings_batch(
        self,
        texts: List[str],
        model_name: str = None,
        batch_size: int = None,
        use_cache: bool = True,
        preprocess: bool = True,
        show_progress: bool = False,
        cancellation_token: asyncio.Event = None
    ) -> BatchProcessingResult:
        """
        Generate embeddings for multiple texts with batch processing and progress tracking.
        
        Args:
            texts: List of input texts
            model_name: Model name (uses primary if None)
            batch_size: Batch size (uses default if None)
            use_cache: Whether to use caching
            preprocess: Whether to preprocess texts
            show_progress: Whether to show progress updates
            cancellation_token: Cancellation token for stopping batch processing
            
        Returns:
            BatchProcessingResult with results and statistics
        """
        if not texts:
            return BatchProcessingResult(
                batch_id="",
                total_texts=0,
                successful=0,
                failed=0,
                results=[],
                processing_time=0.0,
                memory_usage_mb=0.0,
                errors=[]
            )
        
        start_time = time.time()
        batch_id = f"batch_{int(time.time())}_{len(texts)}"
        self.active_batches.add(batch_id)
        
        # Generate results list
        results = []
        errors = []
        
        # Get model
        model = await self.model_manager.get_model(model_name)
        actual_model_name = model_name or EMBEDDING_MODELS["primary"]["name"]
        
        # Set batch size
        if batch_size is None:
            batch_size = min(DEFAULT_BATCH_SIZE, len(texts))
        batch_size = min(batch_size, MAX_BATCH_SIZE, len(texts))
        
        # Preprocess texts if enabled
        if preprocess:
            texts = self.preprocessor.preprocess_batch(texts)
        
        # Validate texts
        valid_texts, invalid_texts = self.preprocessor.validate_batch(texts)
        
        for invalid_text in invalid_texts:
            errors.append(f"Invalid text: {invalid_text}")
        
        try:
            # Process texts in batches
            for i in range(0, len(valid_texts), batch_size):
                # Check for cancellation
                if cancellation_token and cancellation_token.is_set():
                    raise asyncio.CancelledError("Batch processing cancelled")
                
                batch = valid_texts[i:i + batch_size]
                batch_start_time = time.time()
                
                # Check cache for each text in batch
                cached_embeddings = []
                texts_to_process = []
                
                if use_cache:
                    for j, text in enumerate(batch):
                        cached_embedding = await self.cache.get(text, actual_model_name)
                        if cached_embedding:
                            cached_embeddings.append({
                                'text': text,
                                'embedding': cached_embedding,
                                'index': j
                            })
                        else:
                            texts_to_process.append(text)
                else:
                    texts_to_process = batch
                
                # Generate embeddings for uncached texts
                if texts_to_process:
                    try:
                        new_embeddings = model.encode(texts_to_process).tolist()
                        
                        # Cache new embeddings
                        if use_cache:
                            for k, (text, embedding) in enumerate(zip(texts_to_process, new_embeddings)):
                                await self.cache.set(text, actual_model_name, embedding)
                    
                    except Exception as e:
                        logger.error(f"Batch encoding failed: {e}")
                        for text in texts_to_process:
                            errors.append(f"Failed to encode: {text}")
                        new_embeddings = []
                
                # Combine cached and new embeddings
                batch_results = []
                
                # Add cached embeddings
                for cached_item in cached_embeddings:
                    result = EmbeddingResult(
                        embedding=cached_item['embedding'],
                        text=cached_item['text'],
                        model_name=actual_model_name,
                        dimension=len(cached_item['embedding']),
                        processing_time=0.0,
                        cache_hit=True,
                        batch_id=batch_id
                    )
                    batch_results.append((cached_item['index'], result))
                
                # Add new embeddings
                new_index = len(cached_embeddings)
                for text, embedding in zip(texts_to_process, new_embeddings):
                    if validate_embedding(embedding):
                        result = EmbeddingResult(
                            embedding=embedding,
                            text=text,
                            model_name=actual_model_name,
                            dimension=len(embedding),
                            processing_time=time.time() - batch_start_time,
                            cache_hit=False,
                            batch_id=batch_id
                        )
                        batch_results.append((new_index, result))
                        new_index += 1
                    else:
                        errors.append(f"Invalid embedding for: {text}")
                
                # Sort results by original index and add to overall results
                batch_results.sort(key=lambda x: x[0])
                for _, result in batch_results:
                    results.append(result)
                
                # Update progress
                if show_progress:
                    progress = min((i + len(batch)) / len(valid_texts) * 100, 100)
                    logger.info(f"Batch progress: {progress:.1f}% ({i + len(batch)}/{len(valid_texts)})")
                
                # Add small delay to prevent overwhelming the system
                await asyncio.sleep(0.01)
            
            processing_time = time.time() - start_time
            
            # Get memory usage
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            
            # Update global metrics
            self.global_metrics.batch_operations += 1
            self.global_metrics.total_processing_time += processing_time
            
            return BatchProcessingResult(
                batch_id=batch_id,
                total_texts=len(texts),
                successful=len(results),
                failed=len(errors),
                results=results,
                processing_time=processing_time,
                memory_usage_mb=memory_mb,
                errors=errors
            )
            
        except asyncio.CancelledError:
            logger.info(f"Batch processing cancelled: {batch_id}")
            processing_time = time.time() - start_time
            
            return BatchProcessingResult(
                batch_id=batch_id,
                total_texts=len(texts),
                successful=len(results),
                failed=len(errors),
                results=results,
                processing_time=processing_time,
                memory_usage_mb=0.0,
                errors=errors + ["Batch processing cancelled"],
                cancelled=True
            )
            
        except Exception as e:
            logger.error(f"Batch processing failed: {e}")
            processing_time = time.time() - start_time
            
            return BatchProcessingResult(
                batch_id=batch_id,
                total_texts=len(texts),
                successful=len(results),
                failed=len(errors) + 1,
                results=results,
                processing_time=processing_time,
                memory_usage_mb=0.0,
                errors=errors + [str(e)]
            )
        
        finally:
            self.active_batches.discard(batch_id)
    
    async def cancel_batch(self, batch_id: str) -> bool:
        """Cancel a running batch operation."""
        if batch_id not in self.active_batches:
            return False
        
        # Note: This is a simplified cancellation approach
        # In a more sophisticated implementation, you would use
        # proper task cancellation with asyncio.Task
        self.active_batches.discard(batch_id)
        logger.info(f"Batch {batch_id} marked for cancellation")
        return True
    
    async def get_batch_status(self, batch_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a batch operation."""
        if batch_id not in self.active_batches:
            return None
        
        return {
            "batch_id": batch_id,
            "status": "running",
            "active": True
        }
    
    def calculate_similarity(
        self, 
        embedding1: List[float], 
        embedding2: List[float], 
        metric: str = "cosine"
    ) -> float:
        """
        Calculate similarity between two embeddings.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
            metric: Similarity metric ("cosine", "euclidean", "dot_product")
            
        Returns:
            Similarity score (0-1 for cosine, higher is more similar)
        """
        if len(embedding1) != len(embedding2):
            raise ValueError("Embeddings must have the same dimension")
        
        vec1 = np.array(embedding1).reshape(1, -1)
        vec2 = np.array(embedding2).reshape(1, -1)
        
        if metric == "cosine":
            similarity = cosine_similarity(vec1, vec2)[0, 0]
        elif metric == "euclidean":
            distance = np.linalg.norm(vec1 - vec2)
            similarity = 1.0 / (1.0 + distance)  # Convert distance to similarity
        elif metric == "dot_product":
            similarity = np.dot(vec1.flatten(), vec2.flatten())
        else:
            raise ValueError(f"Unknown similarity metric: {metric}")
        
        return float(similarity)
    
    def find_similar_embeddings(
        self,
        query_embedding: List[float],
        candidate_embeddings: List[Tuple[str, List[float]]],
        top_k: int = 5,
        metric: str = "cosine"
    ) -> List[Tuple[str, float]]:
        """
        Find most similar embeddings to a query embedding.
        
        Args:
            query_embedding: Query embedding
            candidate_embeddings: List of (id, embedding) tuples
            top_k: Number of top results to return
            metric: Similarity metric
            
        Returns:
            List of (id, similarity_score) tuples sorted by similarity
        """
        if not candidate_embeddings:
            return []
        
        similarities = []
        for doc_id, candidate_embedding in candidate_embeddings:
            similarity = self.calculate_similarity(query_embedding, candidate_embedding, metric)
            similarities.append((doc_id, similarity))
        
        # Sort by similarity (descending for cosine, ascending for euclidean distance)
        if metric == "euclidean":
            similarities.sort(key=lambda x: x[1], reverse=False)
        else:
            similarities.sort(key=lambda x: x[1], reverse=True)
        
        return similarities[:top_k]
    
    def cluster_embeddings(
        self,
        embeddings: List[Tuple[str, List[float]]],
        n_clusters: int = 5,
        algorithm: str = "kmeans"
    ) -> Dict[int, List[Tuple[str, float]]]:
        """
        Cluster embeddings using various algorithms.
        
        Args:
            embeddings: List of (id, embedding) tuples
            n_clusters: Number of clusters
            algorithm: Clustering algorithm ("kmeans")
            
        Returns:
            Dictionary mapping cluster_id to list of (id, embedding) tuples
        """
        if len(embeddings) < n_clusters:
            n_clusters = max(1, len(embeddings))
        
        # Extract embedding vectors
        embedding_matrix = np.array([emb[1] for emb in embeddings])
        
        if algorithm == "kmeans":
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(embedding_matrix)
        else:
            raise ValueError(f"Unknown clustering algorithm: {algorithm}")
        
        # Group embeddings by cluster
        clusters = defaultdict(list)
        for i, (doc_id, embedding) in enumerate(embeddings):
            cluster_id = int(cluster_labels[i])
            clusters[cluster_id].append((doc_id, embedding))
        
        return dict(clusters)
    
    def reduce_dimensions(
        self,
        embeddings: List[List[float]],
        target_dim: int = 2,
        method: str = "pca"
    ) -> List[List[float]]:
        """
        Reduce dimensionality of embeddings using various methods.
        
        Args:
            embeddings: List of embedding vectors
            target_dim: Target dimensionality
            method: Reduction method ("pca")
            
        Returns:
            List of reduced-dimensional embeddings
        """
        if len(embeddings) == 0:
            return []
        
        embedding_matrix = np.array(embeddings)
        original_dim = embedding_matrix.shape[1]
        
        if target_dim >= original_dim:
            return embeddings  # No reduction needed
        
        if method == "pca":
            pca = PCA(n_components=target_dim)
            reduced = pca.fit_transform(embedding_matrix)
            return reduced.tolist()
        else:
            raise ValueError(f"Unknown dimensionality reduction method: {method}")
    
    async def validate_embeddings(
        self,
        embeddings: List[List[float]],
        threshold_min: float = -1.0,
        threshold_max: float = 1.0
    ) -> Dict[str, Any]:
        """
        Validate a list of embeddings for quality and consistency.
        
        Args:
            embeddings: List of embedding vectors
            threshold_min: Minimum value threshold
            threshold_max: Maximum value threshold
            
        Returns:
            Validation report with statistics and issues
        """
        if not embeddings:
            return {"valid": False, "error": "No embeddings provided"}
        
        issues = []
        stats = {
            "total_embeddings": len(embeddings),
            "dimension": len(embeddings[0]) if embeddings else 0,
            "min_value": float('inf'),
            "max_value": float('-inf'),
            "mean_value": 0.0,
            "std_value": 0.0,
            "nan_count": 0,
            "inf_count": 0,
            "out_of_range_count": 0
        }
        
        # Convert to numpy array for analysis
        try:
            embedding_array = np.array(embeddings)
        except Exception as e:
            return {"valid": False, "error": f"Invalid embedding format: {e}"}
        
        # Check dimensions
        dimensions = [len(emb) for emb in embeddings]
        if len(set(dimensions)) > 1:
            issues.append(f"Inconsistent dimensions: {set(dimensions)}")
        
        # Calculate statistics
        stats["min_value"] = float(np.min(embedding_array))
        stats["max_value"] = float(np.max(embedding_array))
        stats["mean_value"] = float(np.mean(embedding_array))
        stats["std_value"] = float(np.std(embedding_array))
        
        # Check for NaN and inf values
        stats["nan_count"] = int(np.sum(np.isnan(embedding_array)))
        stats["inf_count"] = int(np.sum(np.isinf(embedding_array)))
        
        if stats["nan_count"] > 0:
            issues.append(f"Found {stats['nan_count']} NaN values")
        
        if stats["inf_count"] > 0:
            issues.append(f"Found {stats['inf_count']} infinite values")
        
        # Check value ranges
        out_of_range = np.sum(
            (embedding_array < threshold_min) | (embedding_array > threshold_max)
        )
        stats["out_of_range_count"] = int(out_of_range)
        
        if stats["out_of_range_count"] > 0:
            issues.append(f"Found {stats['out_of_range_count']} values outside [{threshold_min}, {threshold_max}]")
        
        # Calculate embedding norms (for quality assessment)
        norms = np.linalg.norm(embedding_array, axis=1)
        stats["mean_norm"] = float(np.mean(norms))
        stats["std_norm"] = float(np.std(norms))
        
        # Check for zero vectors
        zero_vectors = int(np.sum(norms == 0))
        if zero_vectors > 0:
            issues.append(f"Found {zero_vectors} zero vectors")
        
        is_valid = len(issues) == 0
        
        return {
            "valid": is_valid,
            "issues": issues,
            "statistics": stats
        }
    
    async def get_analytics(
        self,
        time_range_hours: int = 24
    ) -> Dict[str, Any]:
        """Get comprehensive analytics and insights about embedding operations."""
        
        # Calculate global statistics
        uptime_seconds = time.time() - self.start_time
        
        # Calculate derived metrics
        cache_hit_rate = 0
        if (self.global_metrics.cache_hits + self.global_metrics.cache_misses) > 0:
            cache_hit_rate = self.global_metrics.cache_hits / (
                self.global_metrics.cache_hits + self.global_metrics.cache_misses
            )
        
        average_latency = 0
        if self.global_metrics.total_requests > 0:
            average_latency = self.global_metrics.total_processing_time / self.global_metrics.total_requests
        
        error_rate = 0
        if self.global_metrics.total_requests > 0:
            error_rate = self.global_metrics.error_count / self.global_metrics.total_requests
        
        # Get system statistics
        system_stats = await self.model_manager.get_system_stats()
        cache_stats = self.cache.get_stats()
        model_metrics = self.model_manager.get_performance_metrics()
        
        # Calculate model performance comparison
        model_performance = {}
        for model_name, metrics in model_metrics.items():
            if metrics.total_requests > 0:
                model_performance[model_name] = {
                    "requests": metrics.total_requests,
                    "average_latency": metrics.total_processing_time / metrics.total_requests,
                    "error_rate": metrics.error_count / metrics.total_requests if metrics.total_requests > 0 else 0
                }
        
        return {
            "service_info": {
                "uptime_seconds": uptime_seconds,
                "uptime_hours": uptime_seconds / 3600,
                "service_version": "2.0.0"
            },
            "global_metrics": {
                "total_requests": self.global_metrics.total_requests,
                "cache_hit_rate": cache_hit_rate,
                "average_latency_ms": average_latency * 1000,
                "error_rate": error_rate,
                "batch_operations": self.global_metrics.batch_operations,
                "memory_usage_mb": system_stats["memory_usage_mb"]
            },
            "model_performance": model_performance,
            "cache_performance": cache_stats,
            "system_resources": system_stats,
            "active_batches": len(self.active_batches),
            "models_loaded": system_stats["models_loaded"]
        }
    
    async def _resource_monitor(self):
        """Monitor system resources and take corrective action if needed."""
        while not self._shutdown_event.is_set():
            try:
                # Get current memory usage
                process = psutil.Process()
                memory_mb = process.memory_info().rss / 1024 / 1024
                memory_percent = process.memory_percent()
                
                # Check if memory usage is too high
                if memory_percent > MEMORY_THRESHOLD_PERCENT:
                    logger.warning(f"High memory usage detected: {memory_percent:.1f}%")
                    
                    # Clean up unused models
                    await self.model_manager.cleanup_unused_models(max_age_hours=1, max_memory_mb=512)
                    
                    # Clear cache if still high
                    if memory_percent > 90:
                        await self.cache.clear()
                        logger.info("Cache cleared due to high memory usage")
                
                # Update peak memory
                if memory_mb > self.global_metrics.peak_memory_mb:
                    self.global_metrics.peak_memory_mb = memory_mb
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Resource monitoring error: {e}")
                await asyncio.sleep(30)
    
    # Context manager support
    async def __aenter__(self):
        """Async context manager entry."""
        await self.initialize()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.shutdown()

# ==============================================================================
# FACTORY FUNCTION
# ==============================================================================

def create_embedding_service() -> EmbeddingService:
    """Factory function to create and configure an embedding service."""
    return EmbeddingService()

# ==============================================================================
# GLOBAL INSTANCE
# ==============================================================================

# Create global instance for use throughout the application
embedding_service = create_embedding_service()