"""
Message Security Service for comprehensive security operations.
"""

import logging
import re
import hashlib
import json
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import binascii
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

# Graceful import of bleach with fallback
try:
    import bleach
except ImportError:
    # Fallback implementation if bleach is not available
    import re
    
    class BleachFallback:
        @staticmethod
        def clean(text, tags=None, attributes=None, protocols=None, strip=True):
            # Basic HTML tag removal as fallback
            if not text:
                return text
            # Remove script tags
            text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.IGNORECASE | re.DOTALL)
            # Remove HTML tags
            text = re.sub(r'<[^>]+>', '', text)
            return text
    
    bleach = BleachFallback()
    logger = logging.getLogger(__name__)
    logger.warning("bleach not available, using fallback HTML cleaning")

from fastapi import UploadFile

logger = logging.getLogger(__name__)


class MessageSecurityService:
    """Comprehensive message security and content protection service."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)
        
        # PII detection patterns
        self.pii_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(?:\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
            "ip_address": r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
            "url": r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w)*)?)?',
            "date_of_birth": r'\b\d{1,2}[/-]\d{1,2}[/-]\d{4}\b',
            "address": r'\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct)\b',
            "postal_code": r'\b\d{5}(?:-\d{4})?\b'
        }
        
        # Security level mapping
        self.security_levels = {
            "public": 0,
            "internal": 1,
            "confidential": 2,
            "restricted": 3,
            "top_secret": 4
        }
        
        # Content moderation patterns
        self.moderation_patterns = {
            "profanity": [
                # Add profanity patterns here
                r'\b(badword1|badword2)\b',
            ],
            "harassment": [
                # Add harassment patterns here
                r'\b(hate speech patterns)\b',
            ],
            "spam": [
                # Add spam patterns here
                r'\b(spam patterns)\b',
            ],
            "malicious": [
                # Add malicious content patterns here
                r'\b(malicious patterns)\b',
            ]
        }
    
    # ============================================================================
    # CONTENT VALIDATION AND SANITIZATION
    # ============================================================================
    
    async def sanitize_content(
        self, 
        content: str, 
        allowed_tags: Optional[List[str]] = None,
        allowed_attributes: Optional[List[str]] = None
    ) -> str:
        """
        Sanitize content to remove potentially harmful elements.
        
        Args:
            content: Content to sanitize
            allowed_tags: Optional list of allowed HTML tags
            allowed_attributes: Optional list of allowed HTML attributes
            
        Returns:
            Sanitized content
        """
        try:
            if not content:
                return content
            
            # Default allowed tags for chat content
            default_tags = ['b', 'i', 'em', 'strong', 'code', 'pre', 'a']
            default_attributes = ['href', 'title']
            
            tags = allowed_tags or default_tags
            attributes = allowed_attributes or default_attributes
            
            # Use bleach for HTML sanitization
            sanitized = bleach.clean(
                content,
                tags=tags,
                attributes=attributes,
                protocols=['http', 'https', 'mailto'],
                strip=True
            )
            
            # Additional sanitization steps
            sanitized = self._remove_script_tags(sanitized)
            sanitized = self._remove_javascript_urls(sanitized)
            sanitized = self._normalize_whitespace(sanitized)
            
            self.logger.info(f"Content sanitized: {len(content)} -> {len(sanitized)} chars")
            
            return sanitized
            
        except Exception as e:
            self.logger.error(f"Error sanitizing content: {str(e)}")
            return content  # Return original content if sanitization fails
    
    async def comprehensive_content_validation(
        self, 
        content: str, 
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive validation and security analysis of message content.
        
        Args:
            content: Content to validate
            metadata: Optional metadata to consider in validation
            
        Returns:
            Comprehensive validation results
        """
        try:
            validation_result = {
                "content_length": len(content),
                "is_valid": True,
                "security_issues": [],
                "content_issues": [],
                "recommendations": [],
                "validation_timestamp": datetime.utcnow().isoformat()
            }
            
            # Length validation
            if len(content) > 10000:
                validation_result["content_issues"].append("Content too long (max 10,000 characters)")
                validation_result["recommendations"].append("Consider splitting into multiple messages")
            
            if len(content.strip()) < 1:
                validation_result["content_issues"].append("Content is empty or whitespace only")
                validation_result["is_valid"] = False
            
            # Security validation
            security_analysis = await self._analyze_security_threats(content)
            validation_result.update(security_analysis)
            
            # PII detection
            pii_result = await self.detect_pii(content)
            validation_result["pii_analysis"] = pii_result
            
            if pii_result["detected"]:
                validation_result["security_issues"].append("Personal Information Detected")
                validation_result["recommendations"].append("Consider masking or removing PII")
            
            # Content moderation check
            moderation_result = await self._check_content_moderation(content)
            validation_result["moderation_analysis"] = moderation_result
            
            if not moderation_result["approved"]:
                validation_result["security_issues"].extend(moderation_result["issues"])
                validation_result["is_valid"] = False
            
            # HTML/script injection check
            injection_check = await self._check_injection_attempts(content)
            validation_result["injection_check"] = injection_check
            
            if injection_check["detected"]:
                validation_result["security_issues"].append("Potential injection attempt detected")
                validation_result["is_valid"] = False
            
            # Final validation decision
            validation_result["final_decision"] = "approved" if validation_result["is_valid"] else "rejected"
            
            return validation_result
            
        except Exception as e:
            self.logger.error(f"Error in comprehensive content validation: {str(e)}")
            return {
                "error": str(e),
                "is_valid": False,
                "validation_timestamp": datetime.utcnow().isoformat()
            }
    
    # ============================================================================
    # PII DETECTION AND PROTECTION
    # ============================================================================
    
    async def detect_pii(
        self, 
        content: str,
        detection_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Detect personally identifiable information in content.
        
        Args:
            content: Content to analyze for PII
            detection_config: Optional detection configuration
            
        Returns:
            PII detection results
        """
        try:
            config = detection_config or {}
            detected_pii = []
            confidence_scores = {}
            
            # Apply each PII pattern
            for pii_type, pattern in self.pii_patterns.items():
                if pii_type not in config.get("enabled_types", list(self.pii_patterns.keys())):
                    continue
                
                matches = re.finditer(pattern, content, re.IGNORECASE)
                for match in matches:
                    detected_pii.append({
                        "type": pii_type,
                        "value": match.group(),
                        "start_position": match.start(),
                        "end_position": match.end(),
                        "confidence": self._calculate_pii_confidence(pii_type, match.group())
                    })
                
                if matches:
                    confidence_scores[pii_type] = self._calculate_type_confidence(content, pattern)
            
            # Additional PII detection using context analysis
            context_pii = await self._detect_contextual_pii(content)
            detected_pii.extend(context_pii)
            
            return {
                "detected": len(detected_pii) > 0,
                "pii_items": detected_pii,
                "pii_types_found": list(set(item["type"] for item in detected_pii)),
                "confidence_scores": confidence_scores,
                "total_pii_count": len(detected_pii),
                "risk_level": self._assess_pii_risk_level(detected_pii),
                "recommendations": self._generate_pii_recommendations(detected_pii),
                "detection_timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error detecting PII: {str(e)}")
            return {
                "detected": False,
                "pii_items": [],
                "error": str(e),
                "detection_timestamp": datetime.utcnow().isoformat()
            }
    
    async def detect_pii_with_config(
        self,
        content: str,
        detection_config: Dict[str, Any],
        return_masked: bool = True
    ) -> Dict[str, Any]:
        """
        Detect PII with custom configuration.
        
        Args:
            content: Content to analyze
            detection_config: Custom detection configuration
            return_masked: Whether to return masked version of content
            
        Returns:
            Enhanced PII detection results
        """
        try:
            pii_result = await self.detect_pii(content, detection_config)
            
            if return_masked and pii_result["detected"]:
                masked_content = await self.mask_detected_pii(content, pii_result["pii_items"])
                pii_result["masked_content"] = masked_content
                pii_result["masking_applied"] = True
            else:
                pii_result["masking_applied"] = False
            
            # Additional analysis based on config
            if detection_config.get("deep_analysis", False):
                pii_result["deep_analysis"] = await self._deep_pii_analysis(content, pii_result)
            
            if detection_config.get("context_analysis", False):
                pii_result["context_analysis"] = await self._analyze_pii_context(content, pii_result)
            
            return pii_result
            
        except Exception as e:
            self.logger.error(f"Error in enhanced PII detection: {str(e)}")
            return {"error": str(e)}
    
    async def mask_detected_pii(
        self, 
        content: str, 
        pii_items: List[Dict[str, Any]]
    ) -> str:
        """
        Mask detected PII in content.
        
        Args:
            content: Original content
            pii_items: List of detected PII items
            
        Returns:
            Content with PII masked
        """
        try:
            masked_content = content
            # Sort by start position in descending order to maintain indices
            sorted_items = sorted(pii_items, key=lambda x: x["start_position"], reverse=True)
            
            for item in sorted_items:
                start = item["start_position"]
                end = item["end_position"]
                pii_type = item["type"]
                
                # Create appropriate mask based on PII type
                mask = self._get_pii_mask(pii_type, item["value"])
                
                # Replace the PII with mask
                masked_content = masked_content[:start] + mask + masked_content[end:]
            
            return masked_content
            
        except Exception as e:
            self.logger.error(f"Error masking PII: {str(e)}")
            return content
    
    # ============================================================================
    # ENCRYPTION AND SECURITY
    # ============================================================================
    
    async def encrypt_content(
        self, 
        content: str, 
        encryption_config: Dict[str, Any],
        user_id: str
    ) -> Dict[str, Any]:
        """
        Encrypt sensitive content.
        
        Args:
            content: Content to encrypt
            encryption_config: Encryption configuration
            user_id: User ID for key derivation
            
        Returns:
            Encryption result with encrypted data and metadata
        """
        try:
            # Generate user-specific key if configured
            if encryption_config.get("user_specific_key", True):
                key = self._derive_user_key(user_id, encryption_config.get("salt", b"default_salt"))
                cipher = Fernet(key)
            else:
                cipher = self.cipher_suite
            
            # Encrypt content
            content_bytes = content.encode('utf-8')
            encrypted_bytes = cipher.encrypt(content_bytes)
            encrypted_content = base64.b64encode(encrypted_bytes).decode('utf-8')
            
            # Generate encryption metadata
            encryption_metadata = {
                "encryption_method": "AES-256",
                "user_specific_key": encryption_config.get("user_specific_key", True),
                "salt_used": encryption_config.get("salt", "default").decode('utf-8') if isinstance(encryption_config.get("salt"), bytes) else encryption_config.get("salt", "default"),
                "encrypted_at": datetime.utcnow().isoformat(),
                "content_hash": hashlib.sha256(content_bytes).hexdigest(),
                "content_length": len(content),
                "encryption_version": "1.0"
            }
            
            return {
                "encrypted_content": encrypted_content,
                "encryption_metadata": encryption_metadata,
                "decryption_instructions": "Use the corresponding decrypt method with user credentials",
                "security_level": self._determine_encryption_security_level(encryption_config)
            }
            
        except Exception as e:
            self.logger.error(f"Error encrypting content: {str(e)}")
            return {"error": str(e)}
    
    async def decrypt_content(
        self, 
        encrypted_data: Dict[str, Any], 
        user_id: str
    ) -> Dict[str, Any]:
        """
        Decrypt encrypted content.
        
        Args:
            encrypted_data: Encrypted data and metadata
            user_id: User ID for key derivation
            
        Returns:
            Decryption result with original content
        """
        try:
            encrypted_content = encrypted_data.get("encrypted_content")
            metadata = encrypted_data.get("encryption_metadata", {})
            
            if not encrypted_content:
                raise ValueError("No encrypted content provided")
            
            # Determine key to use
            if metadata.get("user_specific_key", True):
                salt = metadata.get("salt_used", "default").encode('utf-8') if isinstance(metadata.get("salt_used"), str) else metadata.get("salt_used", b"default_salt")
                key = self._derive_user_key(user_id, salt)
                cipher = Fernet(key)
            else:
                cipher = self.cipher_suite
            
            # Decrypt content
            encrypted_bytes = base64.b64decode(encrypted_content.encode('utf-8'))
            decrypted_bytes = cipher.decrypt(encrypted_bytes)
            decrypted_content = decrypted_bytes.decode('utf-8')
            
            # Verify content integrity
            content_hash = hashlib.sha256(decrypted_bytes).hexdigest()
            expected_hash = metadata.get("content_hash")
            
            integrity_check = content_hash == expected_hash if expected_hash else None
            
            return {
                "decrypted_content": decrypted_content,
                "decryption_metadata": {
                    "decrypted_at": datetime.utcnow().isoformat(),
                    "integrity_verified": integrity_check,
                    "content_length": len(decrypted_content),
                    "encryption_method": metadata.get("encryption_method"),
                    "encryption_version": metadata.get("encryption_version")
                },
                "success": True
            }
            
        except Exception as e:
            self.logger.error(f"Error decrypting content: {str(e)}")
            return {
                "error": str(e),
                "success": False,
                "decrypted_content": None
            }
    
    # ============================================================================
    # CONTENT MODERATION
    # ============================================================================
    
    async def moderate_content(
        self,
        content: str,
        moderation_config: Dict[str, Any],
        user_id: str
    ) -> Dict[str, Any]:
        """
        Moderate content for policy compliance.
        
        Args:
            content: Content to moderate
            moderation_config: Moderation configuration
            user_id: User ID for context
            
        Returns:
            Moderation results and recommendations
        """
        try:
            moderation_result = {
                "content": content,
                "moderation_decision": "pending",
                "confidence_score": 0.0,
                "flagged_categories": [],
                "specific_issues": [],
                "recommendations": [],
                "processing_details": {},
                "moderation_timestamp": datetime.utcnow().isoformat()
            }
            
            # Check against moderation patterns
            for category, patterns in self.moderation_patterns.items():
                if category in moderation_config.get("enabled_categories", list(self.moderation_patterns.keys())):
                    category_result = await self._check_category_patterns(content, patterns, category)
                    moderation_result["processing_details"][category] = category_result
                    
                    if category_result["flagged"]:
                        moderation_result["flagged_categories"].append(category)
                        moderation_result["specific_issues"].extend(category_result["issues"])
            
            # Calculate overall moderation decision
            flagged_count = len(moderation_result["flagged_categories"])
            total_categories = len(moderation_config.get("enabled_categories", list(self.moderation_patterns.keys())))
            
            if flagged_count == 0:
                moderation_result["moderation_decision"] = "approved"
                moderation_result["confidence_score"] = 1.0
            elif flagged_count <= total_categories * 0.2:  # Less than 20% flagged
                moderation_result["moderation_decision"] = "flagged"
                moderation_result["confidence_score"] = 0.7
                moderation_result["recommendations"].append("Manual review recommended")
            else:
                moderation_result["moderation_decision"] = "rejected"
                moderation_result["confidence_score"] = 0.9
                moderation_result["recommendations"].append("Content violates policy guidelines")
            
            # Generate action recommendations
            moderation_result["recommended_actions"] = self._generate_moderation_actions(
                moderation_result["flagged_categories"], 
                moderation_result["specific_issues"]
            )
            
            return moderation_result
            
        except Exception as e:
            self.logger.error(f"Error moderating content: {str(e)}")
            return {
                "error": str(e),
                "moderation_decision": "error",
                "moderation_timestamp": datetime.utcnow().isoformat()
            }
    
    # ============================================================================
    # FILE SECURITY SCANNING
    # ============================================================================
    
    async def scan_file(self, file: UploadFile) -> Dict[str, Any]:
        """
        Scan uploaded file for security threats.
        
        Args:
            file: File to scan
            
        Returns:
            File security scan results
        """
        try:
            scan_result = {
                "filename": file.filename,
                "content_type": file.content_type,
                "safe": True,
                "scan_timestamp": datetime.utcnow().isoformat(),
                "threats_detected": [],
                "file_characteristics": {},
                "recommendations": []
            }
            
            # Read file content for analysis
            content = await file.read()
            file_size = len(content)
            
            # Basic file characteristics
            scan_result["file_characteristics"] = {
                "size_bytes": file_size,
                "size_mb": round(file_size / (1024 * 1024), 2),
                "md5_hash": hashlib.md5(content).hexdigest(),
                "sha256_hash": hashlib.sha256(content).hexdigest()
            }
            
            # Size limits
            max_size_mb = 50  # Configure as needed
            if file_size > max_size_mb * 1024 * 1024:
                scan_result["threats_detected"].append(f"File too large (max {max_size_mb}MB)")
                scan_result["safe"] = False
            
            # Content type validation
            allowed_types = ["image/jpeg", "image/png", "image/gif", "text/plain", "application/pdf"]
            if file.content_type not in allowed_types:
                scan_result["threats_detected"].append(f"Unsupported file type: {file.content_type}")
                scan_result["safe"] = False
            
            # Extension validation
            allowed_extensions = [".jpg", ".jpeg", ".png", ".gif", ".txt", ".pdf"]
            file_ext = Path(file.filename).suffix.lower()
            if file_ext not in allowed_extensions:
                scan_result["threats_detected"].append(f"Unsupported file extension: {file_ext}")
                scan_result["safe"] = False
            
            # Malicious pattern detection
            malicious_patterns = [b"<script", b"javascript:", b"eval(", b"base64,"]
            content_lower = content.lower()
            for pattern in malicious_patterns:
                if pattern in content_lower:
                    scan_result["threats_detected"].append("Malicious pattern detected")
                    scan_result["safe"] = False
                    break
            
            # Generate recommendations
            if not scan_result["safe"]:
                scan_result["recommendations"].append("File rejected due to security concerns")
            elif file_size > 10 * 1024 * 1024:  # 10MB
                scan_result["recommendations"].append("Large file - consider compression")
            
            return scan_result
            
        except Exception as e:
            self.logger.error(f"Error scanning file: {str(e)}")
            return {
                "filename": file.filename,
                "safe": False,
                "error": str(e),
                "scan_timestamp": datetime.utcnow().isoformat()
            }
    
    # ============================================================================
    # SECURITY LEVEL ASSESSMENT
    # ============================================================================
    
    async def get_security_level(
        self, 
        content: str, 
        pii_result: Dict[str, Any]
    ) -> str:
        """
        Determine security level for content.
        
        Args:
            content: Content to assess
            pii_result: PII detection results
            
        Returns:
            Security level string
        """
        try:
            risk_score = 0
            
            # PII risk
            if pii_result.get("detected"):
                risk_score += pii_result.get("total_pii_count", 0) * 2
                high_risk_types = ["ssn", "credit_card", "password"]
                for item in pii_result.get("pii_items", []):
                    if item["type"] in high_risk_types:
                        risk_score += 5
            
            # Content length risk (very long content might indicate spam)
            if len(content) > 5000:
                risk_score += 1
            elif len(content) > 10000:
                risk_score += 2
            
            # URL risk
            url_pattern = r'https?://[^\s]+'
            urls = re.findall(url_pattern, content)
            if len(urls) > 5:
                risk_score += 2
            
            # Determine security level based on risk score
            if risk_score == 0:
                return "public"
            elif risk_score <= 2:
                return "internal"
            elif risk_score <= 5:
                return "confidential"
            elif risk_score <= 10:
                return "restricted"
            else:
                return "top_secret"
                
        except Exception as e:
            self.logger.error(f"Error determining security level: {str(e)}")
            return "internal"  # Default to internal security
    
    async def sanitize_with_custom_rules(
        self,
        content: str,
        custom_rules: Dict[str, Any],
        preserve_formatting: bool = False
    ) -> Dict[str, Any]:
        """
        Sanitize content with custom rules.
        
        Args:
            content: Content to sanitize
            custom_rules: Custom sanitization rules
            preserve_formatting: Whether to preserve formatting
            
        Returns:
            Sanitization results
        """
        try:
            sanitized_content = content
            changes_made = []
            
            # Custom replacement rules
            for pattern, replacement in custom_rules.get("replacements", {}).items():
                if pattern in content:
                    sanitized_content = sanitized_content.replace(pattern, replacement)
                    changes_made.append(f"Replaced '{pattern}' with '{replacement}'")
            
            # Custom filtering rules
            for filter_rule in custom_rules.get("filters", []):
                # Apply custom filter logic here
                pass
            
            # PII masking if enabled
            if custom_rules.get("mask_pii", True):
                pii_result = await self.detect_pii(sanitized_content)
                if pii_result["detected"]:
                    sanitized_content = await self.mask_detected_pii(
                        sanitized_content, 
                        pii_result["pii_items"]
                    )
                    changes_made.append("Masked detected PII")
            
            return {
                "original_content": content,
                "sanitized_content": sanitized_content,
                "changes_made": changes_made,
                "sanitization_rules_applied": list(custom_rules.keys()),
                "content_preserved": content == sanitized_content,
                "sanitization_timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Error in custom sanitization: {str(e)}")
            return {
                "error": str(e),
                "original_content": content,
                "sanitized_content": content
            }
    
    # ============================================================================
    # PRIVATE HELPER METHODS
    # ============================================================================
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key."""
        try:
            key_file = Path("./data/encryption.key")
            if key_file.exists():
                return key_file.read_bytes()
            else:
                key = Fernet.generate_key()
                key_file.parent.mkdir(parents=True, exist_ok=True)
                key_file.write_bytes(key)
                return key
        except Exception:
            return Fernet.generate_key()
    
    def _derive_user_key(self, user_id: str, salt: bytes) -> bytes:
        """Derive user-specific encryption key."""
        try:
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(user_id.encode()))
            return key
        except Exception:
            return Fernet.generate_key()
    
    def _remove_script_tags(self, content: str) -> str:
        """Remove script tags and JavaScript."""
        # Remove script tags
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.IGNORECASE | re.DOTALL)
        # Remove javascript: URLs
        content = re.sub(r'javascript:[^"\']*', '', content, flags=re.IGNORECASE)
        return content
    
    def _remove_javascript_urls(self, content: str) -> str:
        """Remove JavaScript URLs."""
        # Remove javascript: and data: URLs except for safe data URLs
        content = re.sub(r'javascript:[^"\']*', '[removed]', content, flags=re.IGNORECASE)
        content = re.sub(r'data:[^"\']*', '[removed]', content, flags=re.IGNORECASE)
        return content
    
    def _normalize_whitespace(self, content: str) -> str:
        """Normalize whitespace."""
        # Remove excessive whitespace
        content = re.sub(r'\s+', ' ', content)
        # Trim edges
        content = content.strip()
        return content
    
    def _calculate_pii_confidence(self, pii_type: str, match_value: str) -> float:
        """Calculate confidence score for PII detection."""
        # This would implement sophisticated confidence calculation
        return 0.8  # Placeholder
    
    def _calculate_type_confidence(self, content: str, pattern: str) -> float:
        """Calculate confidence for PII type detection."""
        matches = len(re.findall(pattern, content, re.IGNORECASE))
        if matches == 0:
            return 0.0
        elif matches == 1:
            return 0.7
        else:
            return 0.9
    
    def _assess_pii_risk_level(self, pii_items: List[Dict[str, Any]]) -> str:
        """Assess overall PII risk level."""
        high_risk_types = {"ssn", "credit_card", "password", "bank_account"}
        medium_risk_types = {"email", "phone", "address", "date_of_birth"}
        
        high_risk_count = sum(1 for item in pii_items if item["type"] in high_risk_types)
        medium_risk_count = sum(1 for item in pii_items if item["type"] in medium_risk_types)
        
        if high_risk_count > 0:
            return "high"
        elif medium_risk_count > 2:
            return "medium"
        elif medium_risk_count > 0:
            return "low"
        else:
            return "minimal"
    
    def _generate_pii_recommendations(self, pii_items: List[Dict[str, Any]]) -> List[str]:
        """Generate recommendations for PII handling."""
        recommendations = []
        
        high_risk_types = {"ssn", "credit_card", "password", "bank_account"}
        has_high_risk = any(item["type"] in high_risk_types for item in pii_items)
        
        if has_high_risk:
            recommendations.append("High-risk PII detected - consider not storing this information")
            recommendations.append("Implement additional access controls for this content")
        
        if len(pii_items) > 3:
            recommendations.append("Multiple PII items detected - review content necessity")
        
        recommendations.append("Consider implementing PII masking for user protection")
        
        return recommendations
    
    def _get_pii_mask(self, pii_type: str, original_value: str) -> str:
        """Get appropriate mask for PII type."""
        masks = {
            "email": "[EMAIL_MASKED]",
            "phone": "[PHONE_MASKED]",
            "ssn": "[SSN_MASKED]",
            "credit_card": "[CREDIT_CARD_MASKED]",
            "address": "[ADDRESS_MASKED]",
            "date_of_birth": "[DOB_MASKED]",
            "ip_address": "[IP_MASKED]",
            "url": "[URL_MASKED]",
            "postal_code": "[POSTAL_CODE_MASKED]"
        }
        
        return masks.get(pii_type, "[PII_MASKED]")
    
    def _determine_encryption_security_level(self, config: Dict[str, Any]) -> str:
        """Determine encryption security level."""
        if config.get("user_specific_key", True):
            return "high"
        else:
            return "medium"
    
    def _generate_moderation_actions(self, flagged_categories: List[str], issues: List[str]) -> List[str]:
        """Generate recommended moderation actions."""
        actions = []
        
        if "malicious" in flagged_categories:
            actions.append("Block content immediately")
        
        if "harassment" in flagged_categories:
            actions.append("Flag for human review")
            actions.append("Send warning to user")
        
        if "profanity" in flagged_categories:
            actions.append("Censor inappropriate language")
        
        if "spam" in flagged_categories:
            actions.append("Rate limit user")
            actions.append("Flag as potential spam")
        
        if not actions:
            actions.append("Content approved - no action needed")
        
        return actions
    
    # Additional placeholder methods for complex analysis
    async def _analyze_security_threats(self, content: str) -> Dict[str, Any]:
        """Analyze security threats in content."""
        return {"security_score": 0.8, "threats_detected": []}
    
    async def _check_content_moderation(self, content: str) -> Dict[str, Any]:
        """Check content against moderation policies."""
        return {"approved": True, "issues": []}
    
    async def _check_injection_attempts(self, content: str) -> Dict[str, Any]:
        """Check for injection attempts."""
        return {"detected": False, "injection_types": []}
    
    async def _detect_contextual_pii(self, content: str) -> List[Dict[str, Any]]:
        """Detect PII using contextual analysis."""
        return []
    
    async def _deep_pii_analysis(self, content: str, pii_result: Dict[str, Any]) -> Dict[str, Any]:
        """Perform deep PII analysis."""
        return {"deep_analysis": "placeholder"}
    
    async def _analyze_pii_context(self, content: str, pii_result: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze context around PII."""
        return {"context_analysis": "placeholder"}
    
    async def _check_category_patterns(self, content: str, patterns: List[str], category: str) -> Dict[str, Any]:
        """Check content against category patterns."""
        return {"flagged": False, "issues": []}