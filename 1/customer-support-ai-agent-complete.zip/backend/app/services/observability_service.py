"""
Comprehensive Observability Service for Customer Support System.

This module provides complete observability infrastructure including:
- Prometheus metrics collection and export
- Custom application metrics 
- Performance tracking and analysis
- Distributed tracing support
- Structured logging integration
- Health check orchestration
- Alerting and notification system
- Performance dashboards and analytics
- Monitoring utilities and decorators

Features:
- Real-time metrics collection
- Historical data analysis
- Automated alerting
- Performance optimization insights
- System health monitoring
- Cross-service tracing
"""

import asyncio
import json
import time
import uuid
import logging
from typing import Dict, List, Optional, Any, Union, Callable
from contextlib import contextmanager, asynccontextmanager
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict, deque
from enum import Enum
import traceback
import threading
import functools

# Third-party imports
import structlog
from prometheus_client import (
    Counter, Histogram, Gauge, Summary, 
    generate_latest, CollectorRegistry,
    CONTENT_TYPE_LATEST, exposition
)
import psutil

# Local imports
from app.config import settings
from app.monitoring.health_check import (
    HealthCheckOrchestrator, HealthCheckResult, HealthStatus,
    BaseHealthCheck, register_health_check
)
from app.monitoring.backend_monitoring import metrics as prometheus_metrics, SystemInfo
from app.utils.performance_monitor import (
    PerformanceMonitor, QueryMetrics, SystemMetrics,
    PerformanceContext, performance_monitor
)
from config.monitoring import monitoring_config

# Simple enums to replace missing imports
class MetricType(Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"

class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

# Configure structured logging
logger = structlog.get_logger(__name__)

class ObservabilityLevel(Enum):
    """Observability levels."""
    MINIMAL = "minimal"        # Basic health checks and error rates
    STANDARD = "standard"      # Standard metrics and performance tracking
    COMPREHENSIVE = "comprehensive"  # Full observability with tracing
    DEBUG = "debug"           # Detailed debugging information

class AlertChannel(Enum):
    """Alert notification channels."""
    CONSOLE = "console"
    EMAIL = "email"
    SLACK = "slack"
    WEBHOOK = "webhook"
    PAGERDUTY = "pagerduty"

@dataclass
class ObservabilityConfig:
    """Observability service configuration."""
    level: ObservabilityLevel = ObservabilityLevel.STANDARD
    prometheus_enabled: bool = True
    tracing_enabled: bool = False
    alerts_enabled: bool = True
    performance_tracking: bool = True
    custom_metrics: bool = True
    distributed_tracing: bool = False
    metrics_retention_hours: int = 24
    alert_cooldown_minutes: int = 5
    performance_sample_rate: float = 1.0

@dataclass
class ServiceMetrics:
    """Service-specific metrics."""
    service_name: str
    uptime_seconds: float
    total_requests: int
    error_count: int
    avg_response_time: float
    throughput_per_minute: float
    cpu_usage: float
    memory_usage: float
    active_connections: int
    timestamp: datetime = field(default_factory=datetime.utcnow)

@dataclass
class TraceContext:
    """Distributed tracing context."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    baggage: Dict[str, Any] = field(default_factory=dict)

class CustomMetricsCollector:
    """Custom application metrics collection."""
    
    def __init__(self, prefix: str = "app"):
        self.prefix = prefix
        self.registry = CollectorRegistry()
        self._setup_custom_metrics()
        logger.info("Custom metrics collector initialized", prefix=prefix)
    
    def _setup_custom_metrics(self):
        """Setup custom application metrics."""
        # Business metrics
        self.active_users = Gauge(
            f'{self.prefix}_active_users',
            'Number of active users',
            registry=self.registry
        )
        
        self.session_duration = Histogram(
            f'{self.prefix}_session_duration_seconds',
            'Session duration in seconds',
            ['user_type'],
            registry=self.registry
        )
        
        self.llm_tokens_used = Counter(
            f'{self.prefix}_llm_tokens_used_total',
            'Total LLM tokens used',
            ['provider', 'model'],
            registry=self.registry
        )
        
        # Database operation metrics
        self.db_query_count = Counter(
            f'{self.prefix}_db_queries_total',
            'Total database queries',
            ['operation', 'table'],
            registry=self.registry
        )
        
        self.cache_operations = Counter(
            f'{self.prefix}_cache_operations_total',
            'Cache operations',
            ['operation', 'status'],
            registry=self.registry
        )
        
        # Agent operation metrics
        self.agent_operations = Counter(
            f'{self.prefix}_agent_operations_total',
            'Agent operations',
            ['agent_type', 'operation', 'status'],
            registry=self.registry
        )
        
        self.agent_execution_time = Histogram(
            f'{self.prefix}_agent_execution_seconds',
            'Agent execution time',
            ['agent_type', 'operation'],
            registry=self.registry
        )
        
        # Message processing metrics
        self.messages_processed = Counter(
            f'{self.prefix}_messages_processed_total',
            'Messages processed',
            ['message_type', 'channel'],
            registry=self.registry
        )
        
        self.message_processing_time = Histogram(
            f'{self.prefix}_message_processing_seconds',
            'Message processing time',
            ['message_type', 'priority'],
            registry=self.registry
        )
        
        # Security metrics
        self.security_events = Counter(
            f'{self.prefix}_security_events_total',
            'Security events',
            ['event_type', 'severity'],
            registry=self.registry
        )
        
        # File operation metrics
        self.file_operations = Counter(
            f'{self.prefix}_file_operations_total',
            'File operations',
            ['operation', 'file_type', 'status'],
            registry=self.registry
        )
    
    def record_user_activity(self, active_users: int):
        """Record active user count."""
        self.active_users.set(active_users)
    
    def record_session_duration(self, duration: float, user_type: str = "standard"):
        """Record session duration."""
        self.session_duration.labels(user_type=user_type).observe(duration)
    
    def record_llm_usage(self, provider: str, model: str, tokens_used: int):
        """Record LLM token usage."""
        self.llm_tokens_used.labels(provider=provider, model=model).inc(tokens_used)
    
    def record_db_query(self, operation: str, table: str, duration: float):
        """Record database query metrics."""
        self.db_query_count.labels(operation=operation, table=table).inc()
        # Also record to the main monitoring system
        prometheus_metrics.record_db_query(operation, duration)
    
    def record_cache_operation(self, operation: str, status: str):
        """Record cache operation."""
        self.cache_operations.labels(operation=operation, status=status).inc()
    
    def record_agent_operation(self, agent_type: str, operation: str, status: str, duration: float = 0):
        """Record agent operation metrics."""
        self.agent_operations.labels(
            agent_type=agent_type,
            operation=operation,
            status=status
        ).inc()
        
        if duration > 0:
            self.agent_execution_time.labels(
                agent_type=agent_type,
                operation=operation
            ).observe(duration)
    
    def record_message_processing(self, message_type: str, channel: str, processing_time: float, priority: str = "normal"):
        """Record message processing metrics."""
        self.messages_processed.labels(message_type=message_type, channel=channel).inc()
        self.message_processing_time.labels(message_type=message_type, priority=priority).observe(processing_time)
    
    def record_security_event(self, event_type: str, severity: str = "info"):
        """Record security event."""
        self.security_events.labels(event_type=event_type, severity=severity).inc()
    
    def record_file_operation(self, operation: str, file_type: str, status: str):
        """Record file operation."""
        self.file_operations.labels(operation=operation, file_type=file_type, status=status).inc()
    
    def get_metrics(self) -> str:
        """Get all custom metrics in Prometheus format."""
        return generate_latest(self.registry).decode('utf-8')

class DistributedTracing:
    """Distributed tracing implementation."""
    
    def __init__(self, service_name: str):
        self.service_name = service_name
        self.trace_context: Optional[TraceContext] = None
        self.spans: List[Dict[str, Any]] = []
        self._active_spans = {}
        logger.info("Distributed tracing initialized", service_name=service_name)
    
    def create_trace_context(self) -> TraceContext:
        """Create a new trace context."""
        trace_id = str(uuid.uuid4())
        span_id = str(uuid.uuid4())
        
        context = TraceContext(
            trace_id=trace_id,
            span_id=span_id
        )
        
        logger.debug("Trace context created", trace_id=trace_id, span_id=span_id)
        return context
    
    def start_span(self, operation_name: str, context: Optional[TraceContext] = None) -> TraceContext:
        """Start a new span."""
        if context is None:
            context = self.create_trace_context()
        
        span = {
            'trace_id': context.trace_id,
            'span_id': str(uuid.uuid4()),
            'parent_span_id': context.span_id,
            'operation_name': operation_name,
            'start_time': time.time(),
            'service_name': self.service_name,
            'tags': {},
            'logs': []
        }
        
        self._active_spans[span['span_id']] = span
        
        # Update context for child spans
        context.span_id = span['span_id']
        context.parent_span_id = span['parent_span_id']
        
        logger.debug("Span started", 
                    trace_id=context.trace_id, 
                    span_id=span['span_id'],
                    operation=operation_name)
        
        return context
    
    def finish_span(self, span_id: str, status: str = "ok", error: Optional[Exception] = None):
        """Finish a span."""
        if span_id not in self._active_spans:
            logger.warning("Attempting to finish non-existent span", span_id=span_id)
            return
        
        span = self._active_spans[span_id]
        span['duration'] = time.time() - span['start_time']
        span['status'] = status
        
        if error:
            span['error'] = {
                'message': str(error),
                'type': type(error).__name__,
                'traceback': traceback.format_exc()
            }
        
        # Move from active to completed spans
        self.spans.append(span)
        del self._active_spans[span_id]
        
        logger.debug("Span finished", 
                    trace_id=span['trace_id'],
                    span_id=span_id,
                    duration=span['duration'],
                    status=status)
    
    def add_span_tag(self, span_id: str, key: str, value: Any):
        """Add a tag to a span."""
        if span_id in self._active_spans:
            self._active_spans[span_id]['tags'][key] = value
    
    def add_span_log(self, span_id: str, message: str, **kwargs):
        """Add a log event to a span."""
        if span_id in self._active_spans:
            self._active_spans[span_id]['logs'].append({
                'timestamp': time.time(),
                'message': message,
                'fields': kwargs
            })
    
    def get_trace(self, trace_id: str) -> List[Dict[str, Any]]:
        """Get all spans for a trace."""
        return [span for span in self.spans if span['trace_id'] == trace_id]
    
    def get_traces_summary(self, limit: int = 100) -> Dict[str, Any]:
        """Get traces summary."""
        recent_spans = [s for s in self.spans if time.time() - s['start_time'] < 3600]  # Last hour
        
        trace_summary = defaultdict(lambda: {
            'spans': 0,
            'total_duration': 0,
            'error_count': 0
        })
        
        for span in recent_spans[-limit:]:
            trace_id = span['trace_id']
            trace_summary[trace_id]['spans'] += 1
            trace_summary[trace_id]['total_duration'] += span.get('duration', 0)
            if span.get('status') != 'ok':
                trace_summary[trace_id]['error_count'] += 1
        
        return {
            'total_traces': len(trace_summary),
            'total_spans': len(recent_spans),
            'error_traces': sum(1 for t in trace_summary.values() if t['error_count'] > 0),
            'average_duration': sum(t['total_duration'] for t in trace_summary.values()) / len(trace_summary) if trace_summary else 0,
            'traces': dict(trace_summary)
        }

class AlertManager:
    """Advanced alerting and notification system."""
    
    def __init__(self, config: ObservabilityConfig):
        self.config = config
        self.alert_rules = self._load_alert_rules()
        self.notification_channels = {}
        self.alert_history = deque(maxlen=1000)
        self.active_alerts = {}
        self.cooldowns = {}
        logger.info("Alert manager initialized")
    
    def _load_alert_rules(self) -> Dict[str, Dict[str, Any]]:
        """Load alert rules and thresholds."""
        return {
            # High error rate
            "high_error_rate": {
                "threshold": 0.05,  # 5%
                "duration": 300,  # 5 minutes
                "severity": AlertSeverity.WARNING,
                "cooldown": self.config.alert_cooldown_minutes * 60,
                "channels": [AlertChannel.CONSOLE],
                "message": "High error rate detected: {rate:.2%}"
            },
            
            # High response time
            "high_response_time": {
                "threshold": 5.0,  # 5 seconds
                "duration": 180,  # 3 minutes
                "severity": AlertSeverity.WARNING,
                "cooldown": self.config.alert_cooldown_minutes * 60,
                "channels": [AlertChannel.CONSOLE],
                "message": "High response time detected: {time:.2f}s"
            },
            
            # High CPU usage
            "high_cpu_usage": {
                "threshold": 80.0,  # 80%
                "duration": 300,  # 5 minutes
                "severity": AlertSeverity.WARNING,
                "cooldown": self.config.alert_cooldown_minutes * 60,
                "channels": [AlertChannel.CONSOLE],
                "message": "High CPU usage detected: {usage:.1f}%"
            },
            
            # High memory usage
            "high_memory_usage": {
                "threshold": 85.0,  # 85%
                "duration": 300,  # 5 minutes
                "severity": AlertSeverity.ERROR,
                "cooldown": self.config.alert_cooldown_minutes * 60,
                "channels": [AlertChannel.CONSOLE],
                "message": "High memory usage detected: {usage:.1f}%"
            },
            
            # Database connection issues
            "db_connection_issues": {
                "threshold": 1,
                "duration": 60,  # 1 minute
                "severity": AlertSeverity.ERROR,
                "cooldown": self.config.alert_cooldown_minutes * 60,
                "channels": [AlertChannel.CONSOLE],
                "message": "Database connection issues detected"
            },
            
            # Service downtime
            "service_down": {
                "threshold": 1,
                "duration": 30,  # 30 seconds
                "severity": AlertSeverity.CRITICAL,
                "cooldown": 300,  # 5 minutes
                "channels": [AlertChannel.CONSOLE, AlertChannel.WEBHOOK],
                "message": "Service appears to be down"
            }
        }
    
    def add_channel(self, channel_type: AlertChannel, config: Dict[str, Any]):
        """Add a notification channel."""
        self.notification_channels[channel_type] = config
        logger.info("Notification channel added", channel=channel_type.value)
    
    def check_alerts(self, metrics: ServiceMetrics, system_info: Dict[str, Any]):
        """Check metrics against alert rules."""
        if not self.config.alerts_enabled:
            return
        
        current_time = time.time()
        
        for alert_name, rule in self.alert_rules.items():
            # Check cooldown period
            if self._is_in_cooldown(alert_name, current_time):
                continue
            
            # Evaluate alert condition
            should_alert = False
            alert_data = {}
            
            if alert_name == "high_error_rate" and metrics.total_requests > 0:
                error_rate = metrics.error_count / metrics.total_requests
                if error_rate >= rule["threshold"]:
                    should_alert = True
                    alert_data = {"rate": error_rate}
            
            elif alert_name == "high_response_time":
                if metrics.avg_response_time >= rule["threshold"]:
                    should_alert = True
                    alert_data = {"time": metrics.avg_response_time}
            
            elif alert_name == "high_cpu_usage":
                if system_info.get('cpu_percent', 0) >= rule["threshold"]:
                    should_alert = True
                    alert_data = {"usage": system_info['cpu_percent']}
            
            elif alert_name == "high_memory_usage":
                if system_info.get('memory_percent', 0) >= rule["threshold"]:
                    should_alert = True
                    alert_data = {"usage": system_info['memory_percent']}
            
            elif alert_name == "db_connection_issues":
                # This would be based on actual health check data
                if hasattr(self, '_db_health_failed') and self._db_health_failed:
                    should_alert = True
            
            elif alert_name == "service_down":
                # This would be based on actual health check data
                if hasattr(self, '_service_down') and self._service_down:
                    should_alert = True
            
            if should_alert:
                self._trigger_alert(alert_name, rule, alert_data)
    
    def _is_in_cooldown(self, alert_name: str, current_time: float) -> bool:
        """Check if alert is in cooldown period."""
        cooldown_end = self.cooldowns.get(alert_name, 0)
        return current_time < cooldown_end
    
    def _trigger_alert(self, alert_name: str, rule: Dict[str, Any], data: Dict[str, Any]):
        """Trigger an alert."""
        alert_id = f"{alert_name}_{int(time.time())}"
        
        alert = {
            "id": alert_id,
            "name": alert_name,
            "severity": rule["severity"],
            "message": rule["message"].format(**data),
            "data": data,
            "timestamp": time.time(),
            "status": "active"
        }
        
        # Store alert
        self.active_alerts[alert_id] = alert
        self.alert_history.append(alert)
        
        # Set cooldown
        self.cooldowns[alert_name] = time.time() + rule["cooldown"]
        
        # Send notifications
        for channel in rule["channels"]:
            self._send_notification(channel, alert)
        
        logger.warning("Alert triggered",
                      alert_id=alert_id,
                      name=alert_name,
                      severity=rule["severity"].value,
                      message=alert["message"])
    
    def _send_notification(self, channel: AlertChannel, alert: Dict[str, Any]):
        """Send alert notification."""
        if channel not in self.notification_channels:
            return
        
        channel_config = self.notification_channels[channel]
        
        try:
            if channel == AlertChannel.CONSOLE:
                print(f"[ALERT] {alert['severity'].value.upper()}: {alert['message']}")
            
            elif channel == AlertChannel.WEBHOOK:
                self._send_webhook_notification(channel_config, alert)
            
            elif channel == AlertChannel.EMAIL:
                self._send_email_notification(channel_config, alert)
            
            elif channel == AlertChannel.SLACK:
                self._send_slack_notification(channel_config, alert)
            
        except Exception as e:
            logger.error("Failed to send alert notification",
                        channel=channel.value,
                        alert_id=alert["id"],
                        error=str(e))
    
    def _send_webhook_notification(self, config: Dict[str, Any], alert: Dict[str, Any]):
        """Send webhook notification."""
        import requests
        
        payload = {
            "alert": alert,
            "service": settings.project_name,
            "environment": settings.environment
        }
        
        response = requests.post(
            config["url"],
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        response.raise_for_status()
    
    def _send_email_notification(self, config: Dict[str, Any], alert: Dict[str, Any]):
        """Send email notification."""
        # Implementation would use email library
        logger.info("Email notification would be sent", alert_id=alert["id"])
    
    def _send_slack_notification(self, config: Dict[str, Any], alert: Dict[str, Any]):
        """Send Slack notification."""
        # Implementation would use Slack API
        logger.info("Slack notification would be sent", alert_id=alert["id"])
    
    def resolve_alert(self, alert_id: str):
        """Mark alert as resolved."""
        if alert_id in self.active_alerts:
            self.active_alerts[alert_id]["status"] = "resolved"
            self.active_alerts[alert_id]["resolved_at"] = time.time()
            logger.info("Alert resolved", alert_id=alert_id)
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Get list of active alerts."""
        return [alert for alert in self.active_alerts.values() if alert["status"] == "active"]
    
    def get_alert_summary(self) -> Dict[str, Any]:
        """Get alert summary."""
        active_alerts = self.get_active_alerts()
        
        severity_counts = defaultdict(int)
        for alert in active_alerts:
            severity_counts[alert["severity"]] += 1
        
        return {
            "total_active": len(active_alerts),
            "severity_breakdown": dict(severity_counts),
            "recent_alerts": len([a for a in self.alert_history if time.time() - a["timestamp"] < 3600])
        }

class ObservabilityService:
    """Main observability service orchestrator."""
    
    def __init__(self, config: ObservabilityConfig = None):
        self.config = config or ObservabilityConfig()
        self.start_time = time.time()
        
        # Core components
        self.prometheus_metrics = prometheus_metrics
        self.custom_metrics = CustomMetricsCollector()
        self.tracing = DistributedTracing(settings.project_name)
        self.alert_manager = AlertManager(self.config)
        self.performance_monitor = performance_monitor
        
        # Health checks
        self.health_orchestrator = HealthCheckOrchestrator()
        
        # Background tasks
        self._background_tasks = []
        self._running = False
        
        # Service state
        self._service_metrics = ServiceMetrics(
            service_name=settings.project_name,
            uptime_seconds=0,
            total_requests=0,
            error_count=0,
            avg_response_time=0,
            throughput_per_minute=0,
            cpu_usage=0,
            memory_usage=0,
            active_connections=0
        )
        
        # Register default health checks
        self._register_default_health_checks()
        
        logger.info("Observability service initialized",
                   level=self.config.level.value,
                   prometheus_enabled=self.config.prometheus_enabled,
                   tracing_enabled=self.config.tracing_enabled)
    
    def _register_default_health_checks(self):
        """Register default health checks."""
        # Database health check
        @register_health_check
        class DatabaseHealthCheck(BaseHealthCheck):
            def __init__(self):
                super().__init__("database", timeout=5.0)
            
            async def check(self) -> HealthCheckResult:
                try:
                    # This would check actual database connectivity
                    await asyncio.sleep(0.1)  # Simulated check
                    return HealthCheckResult(
                        service="database",
                        status=HealthStatus.HEALTHY,
                        message="Database connection healthy"
                    )
                except Exception as e:
                    return HealthCheckResult(
                        service="database",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Database connection failed: {str(e)}",
                        error=str(e)
                    )
        
        # Redis health check
        @register_health_check
        class RedisHealthCheck(BaseHealthCheck):
            def __init__(self):
                super().__init__("redis", timeout=3.0)
            
            async def check(self) -> HealthCheckResult:
                try:
                    # This would check actual Redis connectivity
                    await asyncio.sleep(0.05)  # Simulated check
                    return HealthCheckResult(
                        service="redis",
                        status=HealthStatus.HEALTHY,
                        message="Redis connection healthy"
                    )
                except Exception as e:
                    return HealthCheckResult(
                        service="redis",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Redis connection failed: {str(e)}",
                        error=str(e)
                    )
        
        # Application health check
        @register_health_check
        class ApplicationHealthCheck(BaseHealthCheck):
            def __init__(self, observability_service):
                super().__init__("application", timeout=2.0)
                self.obs_service = observability_service
            
            async def check(self) -> HealthCheckResult:
                try:
                    uptime = time.time() - self.obs_service.start_time
                    if uptime < 0:
                        raise ValueError("Invalid uptime")
                    
                    return HealthCheckResult(
                        service="application",
                        status=HealthStatus.HEALTHY,
                        message=f"Application healthy (uptime: {uptime:.0f}s)",
                        details={"uptime_seconds": uptime}
                    )
                except Exception as e:
                    return HealthCheckResult(
                        service="application",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Application health check failed: {str(e)}",
                        error=str(e)
                    )
        
        # Register the application health check with reference to self
        self.application_health_check = ApplicationHealthCheck(self)
        self.health_orchestrator.register_check(self.application_health_check)
    
    async def start(self):
        """Start the observability service."""
        if self._running:
            logger.warning("Observability service already running")
            return
        
        self._running = True
        
        # Start background monitoring tasks
        self._start_background_tasks()
        
        logger.info("Observability service started")
    
    async def stop(self):
        """Stop the observability service."""
        if not self._running:
            return
        
        self._running = False
        
        # Cancel background tasks
        for task in self._background_tasks:
            if not task.done():
                task.cancel()
        
        # Wait for tasks to complete
        if self._background_tasks:
            await asyncio.gather(*self._background_tasks, return_exceptions=True)
        
        logger.info("Observability service stopped")
    
    def _start_background_tasks(self):
        """Start background monitoring tasks."""
        # Service metrics collection
        task = asyncio.create_task(self._collect_service_metrics())
        self._background_tasks.append(task)
        
        # Health check execution
        if self.config.level != ObservabilityLevel.MINIMAL:
            task = asyncio.create_task(self._run_periodic_health_checks())
            self._background_tasks.append(task)
        
        # Performance monitoring
        if self.config.performance_tracking:
            task = asyncio.create_task(self._monitor_performance())
            self._background_tasks.append(task)
        
        # Alert checking
        if self.config.alerts_enabled:
            task = asyncio.create_task(self._check_alerts())
            self._background_tasks.append(task)
    
    async def _collect_service_metrics(self):
        """Continuously collect service metrics."""
        while self._running:
            try:
                current_time = time.time()
                uptime = current_time - self.start_time
                
                # Get system info
                system_info = SystemInfo.get_system_info()
                
                # Update service metrics
                self._service_metrics.uptime_seconds = uptime
                self._service_metrics.cpu_usage = system_info.get('system', {}).get('cpu_usage_percent', 0)
                self._service_metrics.memory_usage = system_info.get('process', {}).get('memory_percent', 0)
                self._service_metrics.active_connections = system_info.get('system', {}).get('active_connections', 0)
                
                # Update Prometheus metrics
                self.prometheus_metrics.update_system_metrics()
                
                await asyncio.sleep(30)  # Collect every 30 seconds
                
            except Exception as e:
                logger.error("Error collecting service metrics", error=str(e))
                await asyncio.sleep(30)
    
    async def _run_periodic_health_checks(self):
        """Run periodic health checks."""
        while self._running:
            try:
                results = await self.health_orchestrator.run_all_checks()
                
                # Update health-related metrics
                for check_name, result in results.items():
                    self.prometheus_metrics.record_health_check(
                        check_type=check_name,
                        status=result.status.value,
                        duration=result.duration_ms / 1000 if result.duration_ms else 0
                    )
                
                await asyncio.sleep(monitoring_config.health_check_interval)
                
            except Exception as e:
                logger.error("Error running health checks", error=str(e))
                await asyncio.sleep(30)
    
    async def _monitor_performance(self):
        """Monitor performance metrics."""
        while self._running:
            try:
                if not self.performance_monitor._monitoring_active:
                    self.performance_monitor.start_monitoring()
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                logger.error("Error monitoring performance", error=str(e))
                await asyncio.sleep(30)
    
    async def _check_alerts(self):
        """Check for alert conditions."""
        while self._running:
            try:
                system_info = SystemInfo.get_system_info()
                self.alert_manager.check_alerts(self._service_metrics, system_info)
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error("Error checking alerts", error=str(e))
                await asyncio.sleep(30)
    
    # Context managers and decorators
    @contextmanager
    def trace_operation(self, operation_name: str, tags: Dict[str, str] = None):
        """Context manager for tracing operations."""
        context = self.tracing.start_span(operation_name)
        
        if tags:
            for key, value in tags.items():
                self.tracing.add_span_tag(context.span_id, key, value)
        
        try:
            yield context
            self.tracing.finish_span(context.span_id, "ok")
        except Exception as e:
            self.tracing.finish_span(context.span_id, "error", e)
            raise
    
    def track_performance(self, operation_name: str, tags: Dict[str, str] = None):
        """Decorator for performance tracking."""
        def decorator(func):
            if asyncio.iscoroutinefunction(func):
                @functools.wraps(func)
                async def async_wrapper(*args, **kwargs):
                    with self.trace_operation(operation_name, tags):
                        with PerformanceContext(self.performance_monitor, operation_name, tags):
                            return await func(*args, **kwargs)
                return async_wrapper
            else:
                @functools.wraps(func)
                def sync_wrapper(*args, **kwargs):
                    with self.trace_operation(operation_name, tags):
                        with PerformanceContext(self.performance_monitor, operation_name, tags):
                            return func(*args, **kwargs)
                return sync_wrapper
        return decorator
    
    # Metrics recording methods
    def record_request(self, method: str, endpoint: str, status_code: int, response_time: float):
        """Record HTTP request metrics."""
        self._service_metrics.total_requests += 1
        
        if status_code >= 400:
            self._service_metrics.error_count += 1
        
        # Update average response time (rolling average)
        total_requests = self._service_metrics.total_requests
        self._service_metrics.avg_response_time = (
            (self._service_metrics.avg_response_time * (total_requests - 1) + response_time) / total_requests
        )
        
        # Calculate throughput (requests per minute)
        uptime_minutes = self._service_metrics.uptime_seconds / 60
        if uptime_minutes > 0:
            self._service_metrics.throughput_per_minute = self._service_metrics.total_requests / uptime_minutes
        
        # Record to Prometheus
        self.prometheus_metrics.record_http_request(method, endpoint, status_code, response_time)
    
    def record_agent_operation(self, agent_type: str, operation: str, status: str, duration: float = 0):
        """Record agent operation metrics."""
        self.custom_metrics.record_agent_operation(agent_type, operation, status, duration)
    
    def record_message_processing(self, message_type: str, channel: str, processing_time: float, priority: str = "normal"):
        """Record message processing metrics."""
        self.custom_metrics.record_message_processing(message_type, channel, processing_time, priority)
    
    def record_security_event(self, event_type: str, severity: str = "info"):
        """Record security event."""
        self.custom_metrics.record_security_event(event_type, severity)
    
    # API endpoints
    def get_metrics(self) -> str:
        """Get Prometheus metrics."""
        if not self.config.prometheus_enabled:
            return ""
        
        # Combine Prometheus and custom metrics
        prometheus_metrics_text = self.prometheus_metrics.get_metrics()
        custom_metrics_text = self.custom_metrics.get_metrics()
        
        return f"{prometheus_metrics_text}\n{custom_metrics_text}"
    
    async def get_health_status(self) -> Dict[str, Any]:
        """Get comprehensive health status."""
        try:
            health_results = await self.health_orchestrator.run_all_checks()
            health_summary = self.health_orchestrator.get_status_summary(health_results)
            
            return {
                "status": health_summary["overall_status"],
                "timestamp": datetime.utcnow().isoformat(),
                "uptime_seconds": time.time() - self.start_time,
                "service_metrics": asdict(self._service_metrics),
                "health_checks": health_summary,
                "active_alerts": self.alert_manager.get_alert_summary(),
                "performance_summary": self.performance_monitor.get_performance_summary(hours=1) if self.config.performance_tracking else None
            }
            
        except Exception as e:
            logger.error("Error getting health status", error=str(e))
            return {
                "status": "unknown",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
    
    def get_performance_summary(self, hours: int = 24) -> Dict[str, Any]:
        """Get performance summary."""
        if not self.config.performance_tracking:
            return {"message": "Performance tracking disabled"}
        
        return self.performance_monitor.get_performance_summary(hours)
    
    def get_trace_summary(self, limit: int = 100) -> Dict[str, Any]:
        """Get distributed tracing summary."""
        if not self.config.tracing_enabled:
            return {"message": "Distributed tracing disabled"}
        
        return self.tracing.get_traces_summary(limit)
    
    def get_alert_summary(self) -> Dict[str, Any]:
        """Get alert summary."""
        return self.alert_manager.get_alert_summary()
    
    def export_observability_data(self, filepath: str, hours: int = 24) -> bool:
        """Export observability data to file."""
        try:
            export_data = {
                "export_timestamp": datetime.utcnow().isoformat(),
                "service_info": {
                    "name": settings.project_name,
                    "version": settings.version,
                    "uptime_seconds": time.time() - self.start_time
                },
                "service_metrics": asdict(self._service_metrics),
                "health_status": asyncio.run(self.get_health_status()),
                "performance_summary": self.get_performance_summary(hours),
                "alert_summary": self.get_alert_summary(),
                "trace_summary": self.get_trace_summary() if self.config.tracing_enabled else None,
                "system_info": SystemInfo.get_system_info()
            }
            
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            logger.info("Observability data exported", filepath=filepath)
            return True
            
        except Exception as e:
            logger.error("Failed to export observability data", error=str(e))
            return False

# Utility functions and decorators
def observability_decorator(operation_name: str, track_performance: bool = True):
    """Decorator for automatic observability tracking."""
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                
                with obs_service.trace_operation(operation_name):
                    if track_performance:
                        with PerformanceContext(obs_service.performance_monitor, operation_name):
                            result = await func(*args, **kwargs)
                    else:
                        result = await func(*args, **kwargs)
                
                return result
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                
                with obs_service.trace_operation(operation_name):
                    if track_performance:
                        with PerformanceContext(obs_service.performance_monitor, operation_name):
                            result = func(*args, **kwargs)
                    else:
                        result = func(*args, **kwargs)
                
                return result
            return sync_wrapper
    return decorator

def track_agent_operation(agent_type: str, operation: str):
    """Decorator to track agent operations."""
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                obs_service = get_observability_service()
                
                try:
                    result = await func(*args, **kwargs)
                    duration = time.time() - start_time
                    obs_service.record_agent_operation(agent_type, operation, "success", duration)
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    obs_service.record_agent_operation(agent_type, operation, "error", duration)
                    raise
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                obs_service = get_observability_service()
                
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    obs_service.record_agent_operation(agent_type, operation, "success", duration)
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    obs_service.record_agent_operation(agent_type, operation, "error", duration)
                    raise
            return sync_wrapper
    return decorator

def track_message_processing(message_type: str, channel: str, priority: str = "normal"):
    """Decorator to track message processing."""
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                obs_service = get_observability_service()
                
                try:
                    result = await func(*args, **kwargs)
                    duration = time.time() - start_time
                    obs_service.record_message_processing(message_type, channel, duration, priority)
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    obs_service.record_message_processing(message_type, channel, duration, priority)
                    raise
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.time()
                obs_service = get_observability_service()
                
                try:
                    result = func(*args, **kwargs)
                    duration = time.time() - start_time
                    obs_service.record_message_processing(message_type, channel, duration, priority)
                    return result
                except Exception as e:
                    duration = time.time() - start_time
                    obs_service.record_message_processing(message_type, channel, duration, priority)
                    raise
            return sync_wrapper
    return decorator

def track_security_event(event_type: str, severity: str = "info"):
    """Decorator to track security events."""
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                
                try:
                    result = await func(*args, **kwargs)
                    obs_service.record_security_event(event_type, severity)
                    return result
                except Exception as e:
                    obs_service.record_security_event(event_type, "error")
                    raise
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                obs_service = get_observability_service()
                
                try:
                    result = func(*args, **kwargs)
                    obs_service.record_security_event(event_type, severity)
                    return result
                except Exception as e:
                    obs_service.record_security_event(event_type, "error")
                    raise
            return sync_wrapper
    return decorator

# Global service instance
_observability_service: Optional[ObservabilityService] = None

def get_observability_service() -> ObservabilityService:
    """Get the global observability service instance."""
    global _observability_service
    if _observability_service is None:
        config = ObservabilityConfig(
            level=ObservabilityLevel(monitoring_config.monitoring_level.lower()),
            prometheus_enabled=monitoring_config.prometheus_enabled,
            tracing_enabled=monitoring_config.tracing_enabled,
            alerts_enabled=monitoring_config.alerting_enabled,
            performance_tracking=monitoring_config.performance_monitoring_enabled
        )
        _observability_service = ObservabilityService(config)
    return _observability_service

async def initialize_observability():
    """Initialize the global observability service."""
    service = get_observability_service()
    await service.start()
    return service

async def shutdown_observability():
    """Shutdown the global observability service."""
    global _observability_service
    if _observability_service:
        await _observability_service.stop()
        _observability_service = None

# Export main components
__all__ = [
    'ObservabilityService',
    'ObservabilityConfig',
    'ObservabilityLevel',
    'CustomMetricsCollector',
    'DistributedTracing',
    'AlertManager',
    'ServiceMetrics',
    'TraceContext',
    'AlertChannel',
    'observability_decorator',
    'track_agent_operation',
    'track_message_processing',
    'track_security_event',
    'get_observability_service',
    'initialize_observability',
    'shutdown_observability'
]