"""
Redis Caching Service with Fallback Mechanisms.

This module provides a comprehensive Redis caching service with:
- Redis connection and management
- Cache operations (get, set, delete, exists)
- Cache expiration and TTL management
- Cache serialization and deserialization
- Fallback mechanisms (in-memory cache for development)
- Cache misses handling
- Graceful degradation when Redis unavailable
- Cache invalidation strategies
- Tag-based invalidation
- Automatic cleanup and optimization
- Cache warming and preloading
- Distributed caching support
- Cache partitioning and sharding
- Cache analytics and monitoring
- Cache performance optimization
- Cache decorators and utilities
- Cache testing and validation
- Cache migration and backup
- Cache configuration management

Features:
- Multi-level caching (Redis + In-memory fallback)
- Automatic failover and graceful degradation
- Comprehensive cache statistics and analytics
- Tag-based cache invalidation
- Cache warming and preloading
- Distributed caching with sharding
- Thread-safe operations
- Health monitoring and diagnostics
"""

import asyncio
import json
import logging
import pickle
import time
import hashlib
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union, Callable, Set, Tuple
from functools import wraps
from dataclasses import dataclass, asdict
from collections import OrderedDict
from datetime import datetime, timedelta
import weakref

try:
    import redis.asyncio as aioredis
    from redis.asyncio import Redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    aioredis = None
    Redis = None

# Import configuration and existing caching utilities
from app.config import settings
from config.redis import RedisConfig, redis_config
from app.utils.caching import (
    CacheBackend,
    MemoryCache,
    RedisCache,
    MultiLevelCache,
    CacheManager,
    CacheStats as BaseCacheStats,
)

logger = logging.getLogger(__name__)


@dataclass
class CacheMetrics:
    """Cache performance metrics."""
    total_operations: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    hit_rate: float = 0.0
    avg_response_time: float = 0.0
    total_response_time: float = 0.0
    last_access: Optional[float] = None
    last_update: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)
    
    def update_hit_rate(self):
        """Update hit rate calculation."""
        total = self.cache_hits + self.cache_misses
        if total > 0:
            self.hit_rate = self.cache_hits / total
    
    def add_operation(self, is_hit: bool, response_time: float):
        """Add operation to metrics."""
        self.total_operations += 1
        self.total_response_time += response_time
        self.avg_response_time = self.total_response_time / self.total_operations
        
        if is_hit:
            self.cache_hits += 1
        else:
            self.cache_misses += 1
        
        self.update_hit_rate()
        self.last_access = time.time()


@dataclass
class CacheEntry:
    """Cache entry with metadata."""
    key: str
    value: Any
    ttl: Optional[int]
    created_at: float
    last_accessed: float
    access_count: int
    size_bytes: int
    tags: Set[str]
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class SerializationManager:
    """Manages cache serialization and deserialization."""
    
    @staticmethod
    def serialize(value: Any) -> Tuple[bytes, str]:
        """
        Serialize a value with automatic format selection.
        
        Returns:
            Tuple of (serialized_bytes, format_type)
        """
        # Try JSON first for simple types
        try:
            if isinstance(value, (str, int, float, bool, list, dict, type(None))):
                json_str = json.dumps(value, ensure_ascii=False)
                return json_str.encode('utf-8'), 'json'
        except (TypeError, ValueError):
            pass
        
        # Fall back to pickle for complex objects
        try:
            pickle_bytes = pickle.dumps(value)
            return pickle_bytes, 'pickle'
        except Exception as e:
            logger.error(f"Failed to serialize value: {e}")
            # Last resort: convert to string
            return str(value).encode('utf-8'), 'string'
    
    @staticmethod
    def deserialize(data: bytes, format_type: str) -> Any:
        """Deserialize bytes based on format type."""
        try:
            if format_type == 'json':
                return json.loads(data.decode('utf-8'))
            elif format_type == 'pickle':
                return pickle.loads(data)
            elif format_type == 'string':
                return data.decode('utf-8')
            else:
                # Try JSON first, then pickle
                try:
                    return json.loads(data.decode('utf-8'))
                except:
                    return pickle.loads(data)
        except Exception as e:
            logger.error(f"Failed to deserialize data: {e}")
            return None


class CacheTagManager:
    """Manages tag-based cache invalidation."""
    
    def __init__(self, redis_client: Optional[Redis] = None):
        self.redis_client = redis_client
        self.tag_key_prefix = "cache:tag:"
        self.tag_index_key = "cache:tags"
    
    def _get_tag_key(self, tag: str) -> str:
        """Get Redis key for a tag."""
        return f"{self.tag_key_prefix}{tag}"
    
    async def add_tags_to_key(self, key: str, tags: List[str]):
        """Add tags to a cache key."""
        if not self.redis_client:
            return
        
        try:
            # Add tags to each tag's set
            pipe = self.redis_client.pipeline()
            for tag in tags:
                tag_key = self._get_tag_key(tag)
                pipe.sadd(tag_key, key)
            
            # Add tags to global tag index
            pipe.sadd(self.tag_index_key, *tags)
            await pipe.execute()
        except Exception as e:
            logger.error(f"Failed to add tags to key {key}: {e}")
    
    async def get_keys_by_tag(self, tag: str) -> List[str]:
        """Get all keys associated with a tag."""
        if not self.redis_client:
            return []
        
        try:
            tag_key = self._get_tag_key(tag)
            keys = await self.redis_client.smembers(tag_key)
            return [key.decode('utf-8') if isinstance(key, bytes) else key for key in keys]
        except Exception as e:
            logger.error(f"Failed to get keys by tag {tag}: {e}")
            return []
    
    async def invalidate_by_tag(self, tag: str) -> int:
        """Invalidate all cache entries with a specific tag."""
        if not self.redis_client:
            return 0
        
        try:
            keys = await self.get_keys_by_tag(tag)
            if keys:
                deleted_count = await self.redis_client.delete(*keys)
                # Clean up tag set
                await self.redis_client.delete(self._get_tag_key(tag))
                # Remove from global index
                await self.redis_client.srem(self.tag_index_key, tag)
                return deleted_count
            return 0
        except Exception as e:
            logger.error(f"Failed to invalidate by tag {tag}: {e}")
            return 0
    
    async def invalidate_by_tags(self, tags: List[str]) -> Dict[str, int]:
        """Invalidate cache entries by multiple tags."""
        results = {}
        for tag in tags:
            results[tag] = await self.invalidate_by_tag(tag)
        return results
    
    async def get_all_tags(self) -> List[str]:
        """Get all existing tags."""
        if not self.redis_client:
            return []
        
        try:
            tags = await self.redis_client.smembers(self.tag_index_key)
            return [tag.decode('utf-8') if isinstance(tag, bytes) else tag for tag in tags]
        except Exception as e:
            logger.error(f"Failed to get all tags: {e}")
            return []
    
    async def clear_all_tags(self) -> int:
        """Clear all tag associations."""
        if not self.redis_client:
            return 0
        
        try:
            tags = await self.get_all_tags()
            deleted_count = 0
            
            # Delete all tag sets
            for tag in tags:
                tag_key = self._get_tag_key(tag)
                deleted_count += await self.redis_client.delete(tag_key)
            
            # Clear tag index
            await self.redis_client.delete(self.tag_index_key)
            
            return deleted_count
        except Exception as e:
            logger.error(f"Failed to clear all tags: {e}")
            return 0


class CachePartitioner:
    """Handles cache partitioning and sharding."""
    
    def __init__(self, num_partitions: int = 16):
        self.num_partitions = num_partitions
    
    def get_partition(self, key: str) -> int:
        """Get partition number for a key."""
        key_hash = int(hashlib.md5(key.encode()).hexdigest(), 16)
        return key_hash % self.num_partitions
    
    def get_partition_keys(self, key: str) -> Tuple[str, int]:
        """Get (partition_key, partition_number) for a key."""
        partition = self.get_partition(key)
        partition_key = f"{partition:02d}:{key}"
        return partition_key, partition
    
    async def get_keys_by_partition(self, redis_client: Redis, partition: int) -> List[str]:
        """Get all keys in a specific partition."""
        try:
            pattern = f"{partition:02d}:*"
            keys = await redis_client.keys(pattern)
            # Remove partition prefix
            return [key.decode('utf-8')[3:] if isinstance(key, bytes) else key[3:] 
                   for key in keys]
        except Exception as e:
            logger.error(f"Failed to get keys by partition {partition}: {e}")
            return []
    
    async def clear_partition(self, redis_client: Redis, partition: int) -> int:
        """Clear all keys in a specific partition."""
        try:
            keys = await self.get_keys_by_partition(redis_client, partition)
            if keys:
                return await redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Failed to clear partition {partition}: {e}")
            return 0


class CacheWarmer:
    """Handles cache warming and preloading."""
    
    def __init__(self, cache_service: 'RedisCacheService'):
        self.cache_service = cache_service
    
    async def warm_cache(
        self,
        items: List[Tuple[str, Any, Optional[int], Optional[List[str]]]],
        batch_size: int = 100
    ):
        """
        Warm cache with predefined items.
        
        Args:
            items: List of (key, value, ttl, tags) tuples
            batch_size: Number of items to process per batch
        """
        logger.info(f"Starting cache warming with {len(items)} items")
        
        for i in range(0, len(items), batch_size):
            batch = items[i:i + batch_size]
            tasks = []
            
            for key, value, ttl, tags in batch:
                task = self.cache_service.set(
                    key=key,
                    value=value,
                    ttl=ttl,
                    tags=tags,
                    skip_metrics=True
                )
                tasks.append(task)
            
            # Process batch
            await asyncio.gather(*tasks, return_exceptions=True)
            
            logger.info(f"Warmed cache batch {i//batch_size + 1}/{(len(items) + batch_size - 1)//batch_size}")
        
        logger.info("Cache warming completed")
    
    async def preload_by_pattern(self, pattern: str, generator_func: Callable[[str], Any]):
        """
        Preload cache by pattern using a generator function.
        
        Args:
            pattern: Key pattern to match
            generator_func: Function to generate values for keys
        """
        logger.info(f"Starting cache preloading for pattern: {pattern}")
        
        try:
            # Get matching keys
            keys = await self.cache_service.get_keys_by_pattern(pattern)
            
            if not keys:
                logger.info("No keys found matching pattern")
                return
            
            # Generate and cache values
            for key in keys:
                try:
                    value = generator_func(key)
                    if value is not None:
                        await self.cache_service.set(key, value, skip_metrics=True)
                except Exception as e:
                    logger.error(f"Failed to preload key {key}: {e}")
            
            logger.info(f"Cache preloading completed for {len(keys)} keys")
            
        except Exception as e:
            logger.error(f"Cache preloading failed: {e}")


class CacheAnalytics:
    """Provides cache analytics and monitoring."""
    
    def __init__(self, cache_service: 'RedisCacheService'):
        self.cache_service = cache_service
        self.metrics_history: List[CacheMetrics] = []
        self.max_history_size = 1000
    
    async def collect_metrics(self) -> CacheMetrics:
        """Collect comprehensive cache metrics."""
        try:
            # Get Redis info
            redis_info = {}
            if self.cache_service.redis_client:
                redis_info = await self.cache_service.redis_client.info()
            
            # Get cache stats
            cache_stats = self.cache_service.get_stats()
            
            # Combine metrics
            metrics = CacheMetrics(
                total_operations=cache_stats.hits + cache_stats.misses,
                cache_hits=cache_stats.hits,
                cache_misses=cache_stats.misses,
                hit_rate=cache_stats.hit_rate,
            )
            
            # Add Redis-specific metrics
            if redis_info:
                metrics.update({
                    'redis_memory_usage': redis_info.get('used_memory_human'),
                    'redis_connected_clients': redis_info.get('connected_clients'),
                    'redis_keyspace_hits': redis_info.get('keyspace_hits', 0),
                    'redis_keyspace_misses': redis_info.get('keyspace_misses', 0),
                    'redis_total_commands_processed': redis_info.get('total_commands_processed', 0),
                    'redis_instantaneous_ops_per_sec': redis_info.get('instantaneous_ops_per_sec', 0),
                    'redis_hit_rate': self._calculate_redis_hit_rate(redis_info),
                })
            
            # Store in history
            self._store_metrics(metrics)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Failed to collect metrics: {e}")
            return CacheMetrics()
    
    async def get_cache_top_keys(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top accessed keys."""
        try:
            # This would require custom tracking or Redis key access patterns
            # For now, return placeholder structure
            return []
        except Exception as e:
            logger.error(f"Failed to get top keys: {e}")
            return []
    
    async def get_cache_size_by_pattern(self, pattern: str) -> Dict[str, int]:
        """Get cache size breakdown by pattern."""
        try:
            if not self.cache_service.redis_client:
                return {}
            
            keys = await self.cache_service.redis_client.keys(pattern)
            size_breakdown = {}
            
            for key in keys:
                key_str = key.decode('utf-8') if isinstance(key, bytes) else key
                size = await self.cache_service.redis_client.memory_usage(key_str)
                if size:
                    # Categorize by pattern or prefix
                    category = self._categorize_key(key_str)
                    size_breakdown[category] = size_breakdown.get(category, 0) + size
            
            return size_breakdown
            
        except Exception as e:
            logger.error(f"Failed to get size by pattern: {e}")
            return {}
    
    async def generate_cache_report(self) -> Dict[str, Any]:
        """Generate comprehensive cache report."""
        metrics = await self.collect_metrics()
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'metrics': metrics.to_dict(),
            'health_status': self._get_health_status(metrics),
            'recommendations': self._generate_recommendations(metrics),
            'historical_trend': self._get_historical_trend(),
        }
        
        # Add Redis-specific info if available
        if self.cache_service.redis_client:
            try:
                redis_info = await self.cache_service.redis_client.info()
                report['redis_info'] = {
                    'version': redis_info.get('redis_version'),
                    'uptime': redis_info.get('uptime_in_seconds'),
                    'memory': redis_info.get('used_memory_human'),
                    'cpu': redis_info.get('used_cpu_sys'),
                }
            except Exception as e:
                logger.error(f"Failed to get Redis info: {e}")
        
        return report
    
    def _store_metrics(self, metrics: CacheMetrics):
        """Store metrics in history."""
        self.metrics_history.append(metrics)
        if len(self.metrics_history) > self.max_history_size:
            self.metrics_history = self.metrics_history[-self.max_history_size:]
    
    def _calculate_redis_hit_rate(self, redis_info: Dict[str, Any]) -> float:
        """Calculate Redis hit rate from info."""
        hits = redis_info.get('keyspace_hits', 0)
        misses = redis_info.get('keyspace_misses', 0)
        total = hits + misses
        return hits / total if total > 0 else 0.0
    
    def _categorize_key(self, key: str) -> str:
        """Categorize a key for reporting."""
        if ':' in key:
            return key.split(':')[0]
        return 'default'
    
    def _get_health_status(self, metrics: CacheMetrics) -> str:
        """Get overall health status based on metrics."""
        hit_rate = metrics.hit_rate
        total_ops = metrics.total_operations
        
        if total_ops == 0:
            return 'unknown'
        elif hit_rate >= 0.8:
            return 'excellent'
        elif hit_rate >= 0.6:
            return 'good'
        elif hit_rate >= 0.4:
            return 'fair'
        else:
            return 'poor'
    
    def _generate_recommendations(self, metrics: CacheMetrics) -> List[str]:
        """Generate recommendations based on metrics."""
        recommendations = []
        
        hit_rate = metrics.hit_rate
        if hit_rate < 0.5:
            recommendations.append("Low cache hit rate - consider reviewing cache strategy")
        
        if metrics.avg_response_time > 100:  # ms
            recommendations.append("High response time - consider optimizing cache operations")
        
        total_ops = metrics.total_operations
        if total_ops == 0:
            recommendations.append("No cache operations detected - verify cache usage")
        
        return recommendations
    
    def _get_historical_trend(self) -> Dict[str, Any]:
        """Get historical performance trend."""
        if len(self.metrics_history) < 2:
            return {'trend': 'insufficient_data'}
        
        recent_metrics = self.metrics_history[-10:]  # Last 10 entries
        recent_hit_rates = [m.hit_rate for m in recent_metrics]
        
        # Simple trend calculation
        if len(recent_hit_rates) >= 2:
            first_half = recent_hit_rates[:len(recent_hit_rates)//2]
            second_half = recent_hit_rates[len(recent_hit_rates)//2:]
            
            first_avg = sum(first_half) / len(first_half)
            second_avg = sum(second_half) / len(second_half)
            
            if second_avg > first_avg + 0.05:
                trend = 'improving'
            elif second_avg < first_avg - 0.05:
                trend = 'declining'
            else:
                trend = 'stable'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'data_points': len(self.metrics_history),
            'recent_hit_rate': recent_hit_rates[-1] if recent_hit_rates else 0.0,
            'avg_hit_rate': sum(recent_hit_rates) / len(recent_hit_rates) if recent_hit_rates else 0.0,
        }


class InMemoryFallbackCache:
    """In-memory fallback cache for development and Redis unavailability."""
    
    def __init__(self, max_size: int = 10000, default_ttl: int = 3600):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: Dict[str, CacheEntry] = {}
        self._expiry_heap: List[Tuple[float, str]] = []
        self._metrics = CacheMetrics()
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        async with self._lock:
            current_time = time.time()
            
            if key not in self._cache:
                self._metrics.add_operation(False, 0)
                return None
            
            entry = self._cache[key]
            
            # Check expiry
            if entry.ttl and current_time > entry.created_at + entry.ttl:
                await self.delete(key)
                self._metrics.add_operation(False, 0)
                return None
            
            # Update access info
            entry.last_accessed = current_time
            entry.access_count += 1
            self._metrics.add_operation(True, 0)
            
            return entry.value
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
        tags: Optional[List[str]] = None
    ) -> bool:
        """Set value in cache."""
        async with self._lock:
            ttl = ttl or self.default_ttl
            current_time = time.time()
            
            # Calculate size
            size_bytes = self._calculate_size(value)
            
            # Create entry
            entry = CacheEntry(
                key=key,
                value=value,
                ttl=ttl,
                created_at=current_time,
                last_accessed=current_time,
                access_count=1,
                size_bytes=size_bytes,
                tags=set(tags or []),
                metadata={}
            )
            
            # Remove old entry if exists
            if key in self._cache:
                await self.delete(key)
            
            # Evict if at capacity
            while len(self._cache) >= self.max_size:
                await self._evict_lru()
            
            # Add new entry
            self._cache[key] = entry
            self._metrics.last_update = current_time
            
            return True
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        async with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        async with self._lock:
            if key not in self._cache:
                return False
            
            current_time = time.time()
            entry = self._cache[key]
            
            # Check expiry
            if entry.ttl and current_time > entry.created_at + entry.ttl:
                await self.delete(key)
                return False
            
            return True
    
    async def clear(self) -> bool:
        """Clear all cache entries."""
        async with self._lock:
            self._cache.clear()
            self._expiry_heap.clear()
            self._metrics = CacheMetrics()
            return True
    
    async def get_stats(self) -> BaseCacheStats:
        """Get cache statistics."""
        async with self._lock:
            total_size = sum(entry.size_bytes for entry in self._cache.values())
            
            return BaseCacheStats(
                hits=self._metrics.cache_hits,
                misses=self._metrics.cache_misses,
                evictions=0,  # Would need tracking
                size=len(self._cache),
                max_size=self.max_size,
                hit_rate=self._metrics.hit_rate
            )
    
    def _calculate_size(self, value: Any) -> int:
        """Calculate approximate size of value in bytes."""
        try:
            serialized, _ = SerializationManager.serialize(value)
            return len(serialized)
        except:
            return 0
    
    async def _evict_lru(self):
        """Evict least recently used item."""
        if not self._cache:
            return
        
        # Find LRU item
        lru_key = min(self._cache.keys(), key=lambda k: self._cache[k].last_accessed)
        del self._cache[lru_key]


class RedisCacheService:
    """
    Comprehensive Redis caching service with fallback mechanisms.
    
    Features:
    - Redis connection management with connection pooling
    - Automatic fallback to in-memory cache when Redis unavailable
    - Comprehensive cache operations with TTL support
    - Tag-based cache invalidation
    - Cache analytics and monitoring
    - Cache warming and preloading
    - Distributed caching with sharding
    - Performance optimization
    """
    
    def __init__(
        self,
        config: Optional[RedisConfig] = None,
        enable_fallback: bool = True,
        fallback_max_size: int = 10000,
        default_ttl: int = 3600
    ):
        self.config = config or redis_config
        self.enable_fallback = enable_fallback
        self.fallback_max_size = fallback_max_size
        self.default_ttl = default_ttl
        
        self.redis_client: Optional[Redis] = None
        self.fallback_cache: Optional[InMemoryFallbackCache] = None
        self.tag_manager: Optional[CacheTagManager] = None
        self.partitioner: Optional[CachePartitioner] = None
        self.warmer: Optional[CacheWarmer] = None
        self.analytics: Optional[CacheAnalytics] = None
        
        self._metrics = CacheMetrics()
        self._initialized = False
        self._connection_lock = asyncio.Lock()
    
    async def initialize(self):
        """Initialize the cache service."""
        if self._initialized:
            return
        
        async with self._connection_lock:
            if self._initialized:
                return
            
            try:
                # Initialize fallback cache
                if self.enable_fallback:
                    self.fallback_cache = InMemoryFallbackCache(
                        max_size=self.fallback_max_size,
                        default_ttl=self.default_ttl
                    )
                
                # Initialize Redis connection
                if REDIS_AVAILABLE:
                    try:
                        if self.config.is_cluster_mode:
                            import redis.asyncio as aioredis
                            self.redis_client = aioredis.RedisCluster(**self.config.get_cluster_kwargs())
                        elif self.config.is_sentinel_mode:
                            import redis.asyncio as aioredis
                            sentinels = aioredis.Sentinel(**self.config.get_sentinel_kwargs())
                            self.redis_client = sentinels.master_for(self.config.redis_sentinel_master_name)
                        else:
                            import redis.asyncio as aioredis
                            self.redis_client = aioredis.from_url(
                                self.config.connection_url,
                                **self.config.get_connection_kwargs()
                            )
                        
                        # Test connection
                        await self.redis_client.ping()
                        logger.info("Redis cache connected successfully")
                        
                    except Exception as e:
                        logger.warning(f"Redis connection failed, using fallback: {e}")
                        self.redis_client = None
                
                # Initialize managers
                if self.redis_client:
                    self.tag_manager = CacheTagManager(self.redis_client)
                    self.partitioner = CachePartitioner()
                
                self.warmer = CacheWarmer(self)
                self.analytics = CacheAnalytics(self)
                
                self._initialized = True
                logger.info("Cache service initialized successfully")
                
            except Exception as e:
                logger.error(f"Failed to initialize cache service: {e}")
                # Even if initialization fails, we should still be usable with fallback
                if not self.fallback_cache:
                    self.fallback_cache = InMemoryFallbackCache()
                self._initialized = True
    
    async def get(
        self,
        key: str,
        default: Any = None,
        serializer: Optional[str] = None
    ) -> Optional[Any]:
        """Get value from cache with fallback support."""
        start_time = time.time()
        
        try:
            # Try Redis first
            if self.redis_client:
                try:
                    data = await self.redis_client.get(key)
                    if data is not None:
                        # Deserialize
                        if serializer:
                            value = SerializationManager.deserialize(data, serializer)
                        else:
                            # Auto-detect format
                            try:
                                json_str = data.decode('utf-8')
                                if json_str.startswith('json:') or json_str.startswith('{'):
                                    value = json.loads(json_str)
                                else:
                                    value = data
                            except:
                                value = pickle.loads(data)
                        
                        self._metrics.add_operation(True, time.time() - start_time)
                        return value
                except Exception as e:
                    logger.warning(f"Redis get failed for key {key}: {e}")
            
            # Try fallback cache
            if self.fallback_cache:
                value = await self.fallback_cache.get(key)
                if value is not None:
                    if default is not None and value == default:
                        return default
                    self._metrics.add_operation(True, time.time() - start_time)
                    return value
            
            # Cache miss
            self._metrics.add_operation(False, time.time() - start_time)
            return default
            
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {e}")
            self._metrics.add_operation(False, time.time() - start_time)
            return default
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
        tags: Optional[List[str]] = None,
        serializer: Optional[str] = None,
        skip_metrics: bool = False
    ) -> bool:
        """Set value in cache with fallback support."""
        ttl = ttl or self.default_ttl
        
        try:
            # Serialize value
            serialized_data, format_type = SerializationManager.serialize(value)
            
            # Try Redis first
            if self.redis_client:
                try:
                    # Add format prefix for auto-detection
                    prefixed_data = f"{format_type}:{serialized_data.decode('utf-8')}".encode('utf-8')
                    await self.redis_client.setex(key, ttl, prefixed_data)
                    
                    # Add tags if provided
                    if tags and self.tag_manager:
                        await self.tag_manager.add_tags_to_key(key, tags)
                    
                    if not skip_metrics:
                        self._metrics.add_operation(True, 0)
                    
                    return True
                    
                except Exception as e:
                    logger.warning(f"Redis set failed for key {key}: {e}")
            
            # Try fallback cache
            if self.fallback_cache:
                success = await self.fallback_cache.set(key, value, ttl, tags)
                if not skip_metrics:
                    self._metrics.add_operation(success, 0)
                return success
            
            return False
            
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        try:
            # Delete from Redis
            if self.redis_client:
                try:
                    await self.redis_client.delete(key)
                except Exception as e:
                    logger.warning(f"Redis delete failed for key {key}: {e}")
            
            # Delete from fallback
            if self.fallback_cache:
                await self.fallback_cache.delete(key)
            
            return True
            
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        try:
            # Check Redis first
            if self.redis_client:
                try:
                    exists = await self.redis_client.exists(key)
                    if exists:
                        return True
                except Exception as e:
                    logger.warning(f"Redis exists check failed for key {key}: {e}")
            
            # Check fallback
            if self.fallback_cache:
                return await self.fallback_cache.exists(key)
            
            return False
            
        except Exception as e:
            logger.error(f"Cache exists error for key {key}: {e}")
            return False
    
    async def get_ttl(self, key: str) -> int:
        """Get TTL for a key."""
        try:
            if self.redis_client:
                ttl = await self.redis_client.ttl(key)
                if ttl >= 0:
                    return ttl
            
            if self.fallback_cache:
                # Fallback cache doesn't have direct TTL access
                pass
            
            return 0
            
        except Exception as e:
            logger.error(f"Get TTL error for key {key}: {e}")
            return 0
    
    async def expire(self, key: str, ttl: int) -> bool:
        """Set TTL for a key."""
        try:
            if self.redis_client:
                await self.redis_client.expire(key, ttl)
            return True
        except Exception as e:
            logger.error(f"Expire error for key {key}: {e}")
            return False
    
    async def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment a numeric value."""
        try:
            if self.redis_client:
                return await self.redis_client.incrby(key, amount)
            return None
        except Exception as e:
            logger.error(f"Increment error for key {key}: {e}")
            return None
    
    async def decrement(self, key: str, amount: int = 1) -> Optional[int]:
        """Decrement a numeric value."""
        try:
            if self.redis_client:
                return await self.redis_client.decr(key, amount)
            return None
        except Exception as e:
            logger.error(f"Decrement error for key {key}: {e}")
            return None
    
    async def get_or_set(
        self,
        key: str,
        factory_func: Callable,
        ttl: Optional[int] = None,
        tags: Optional[List[str]] = None
    ) -> Any:
        """Get value or set it using factory function."""
        # Try to get existing value
        value = await self.get(key)
        if value is not None:
            return value
        
        # Generate value using factory
        try:
            if asyncio.iscoroutinefunction(factory_func):
                value = await factory_func()
            else:
                value = factory_func()
        except Exception as e:
            logger.error(f"Factory function failed for key {key}: {e}")
            return None
        
        # Set the generated value
        await self.set(key, value, ttl, tags)
        return value
    
    async def batch_get(self, keys: List[str]) -> Dict[str, Any]:
        """Get multiple values in batch."""
        results = {}
        
        if not keys:
            return results
        
        try:
            # Redis batch get
            if self.redis_client:
                try:
                    redis_results = await self.redis_client.mget(keys)
                    for key, value in zip(keys, redis_results):
                        if value is not None:
                            try:
                                # Auto-deserialize
                                value_str = value.decode('utf-8')
                                if value_str.startswith('json:'):
                                    results[key] = json.loads(value_str[5:])
                                elif value_str.startswith('{'):
                                    results[key] = json.loads(value_str)
                                else:
                                    results[key] = value
                            except:
                                results[key] = value
                except Exception as e:
                    logger.warning(f"Redis batch get failed: {e}")
            
            # Fill missing from fallback
            if self.fallback_cache:
                for key in keys:
                    if key not in results:
                        value = await self.fallback_cache.get(key)
                        if value is not None:
                            results[key] = value
            
            return results
            
        except Exception as e:
            logger.error(f"Batch get error: {e}")
            return results
    
    async def batch_set(
        self,
        items: Dict[str, Any],
        ttl: Optional[int] = None,
        tags_by_key: Optional[Dict[str, List[str]]] = None
    ) -> bool:
        """Set multiple values in batch."""
        try:
            ttl = ttl or self.default_ttl
            success = True
            
            # Redis batch set
            if self.redis_client:
                try:
                    pipe = self.redis_client.pipeline()
                    for key, value in items.items():
                        serialized_data, format_type = SerializationManager.serialize(value)
                        prefixed_data = f"{format_type}:{serialized_data.decode('utf-8')}".encode('utf-8')
                        pipe.setex(key, ttl, prefixed_data)
                        
                        # Add tags if provided
                        if tags_by_key and key in tags_by_key and self.tag_manager:
                            tags = tags_by_key[key]
                            for tag in tags:
                                tag_key = self.tag_manager._get_tag_key(tag)
                                pipe.sadd(tag_key, key)
                            pipe.sadd(self.tag_manager.tag_index_key, *tags)
                    
                    await pipe.execute()
                except Exception as e:
                    logger.warning(f"Redis batch set failed: {e}")
                    success = False
            
            # Fallback: individual sets
            if self.fallback_cache:
                for key, value in items.items():
                    tags = tags_by_key.get(key) if tags_by_key else None
                    await self.fallback_cache.set(key, value, ttl, tags)
            
            return success
            
        except Exception as e:
            logger.error(f"Batch set error: {e}")
            return False
    
    async def get_keys_by_pattern(self, pattern: str) -> List[str]:
        """Get keys matching a pattern."""
        keys = []
        
        try:
            if self.redis_client:
                redis_keys = await self.redis_client.keys(pattern)
                keys = [k.decode('utf-8') if isinstance(k, bytes) else k for k in redis_keys]
        except Exception as e:
            logger.warning(f"Pattern search in Redis failed: {e}")
        
        return keys
    
    async def clear_by_pattern(self, pattern: str) -> int:
        """Clear all keys matching a pattern."""
        try:
            keys = await self.get_keys_by_pattern(pattern)
            if keys:
                deleted_count = 0
                
                # Delete from Redis
                if self.redis_client:
                    deleted_count += await self.redis_client.delete(*keys)
                
                # Delete from fallback
                if self.fallback_cache:
                    for key in keys:
                        await self.fallback_cache.delete(key)
                
                return deleted_count
            
            return 0
        except Exception as e:
            logger.error(f"Clear by pattern error: {e}")
            return 0
    
    async def invalidate_by_tag(self, tag: str) -> int:
        """Invalidate cache entries by tag."""
        if not self.tag_manager:
            return 0
        
        try:
            return await self.tag_manager.invalidate_by_tag(tag)
        except Exception as e:
            logger.error(f"Invalidate by tag error: {e}")
            return 0
    
    async def invalidate_by_tags(self, tags: List[str]) -> Dict[str, int]:
        """Invalidate cache entries by multiple tags."""
        if not self.tag_manager:
            return {}
        
        try:
            return await self.tag_manager.invalidate_by_tags(tags)
        except Exception as e:
            logger.error(f"Invalidate by tags error: {e}")
            return {}
    
    async def get_all_tags(self) -> List[str]:
        """Get all existing tags."""
        if not self.tag_manager:
            return []
        
        try:
            return await self.tag_manager.get_all_tags()
        except Exception as e:
            logger.error(f"Get all tags error: {e}")
            return []
    
    async def warm_cache(
        self,
        items: List[Tuple[str, Any, Optional[int], Optional[List[str]]]],
        batch_size: int = 100
    ):
        """Warm cache with predefined items."""
        if self.warmer:
            await self.warmer.warm_cache(items, batch_size)
    
    async def preload_by_pattern(self, pattern: str, generator_func: Callable[[str], Any]):
        """Preload cache by pattern."""
        if self.warmer:
            await self.warmer.preload_by_pattern(pattern, generator_func)
    
    def get_cache_decorator(
        self,
        ttl: Optional[int] = None,
        key_func: Optional[Callable] = None,
        tags: Optional[List[str]] = None
    ):
        """
        Get a cache decorator for functions.
        
        Args:
            ttl: Cache TTL in seconds
            key_func: Function to generate cache key from function arguments
            tags: Tags to associate with cached values
        """
        def decorator(func):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # Generate cache key
                if key_func:
                    cache_key = key_func(*args, **kwargs)
                else:
                    # Default key generation
                    key_data = {
                        'func': func.__name__,
                        'args': args,
                        'kwargs': sorted(kwargs.items())
                    }
                    key_str = json.dumps(key_data, sort_keys=True, default=str)
                    cache_key = hashlib.md5(key_str.encode()).hexdigest()
                
                # Try to get from cache
                cached_value = await self.get(cache_key)
                if cached_value is not None:
                    logger.debug(f"Cache hit for {func.__name__}")
                    return cached_value
                
                # Execute function
                logger.debug(f"Cache miss for {func.__name__}")
                if asyncio.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)
                
                # Cache the result
                if result is not None:
                    await self.set(cache_key, result, ttl, tags)
                
                return result
            
            return wrapper
        return decorator
    
    async def get_stats(self) -> BaseCacheStats:
        """Get comprehensive cache statistics."""
        try:
            # Combine metrics from all sources
            total_hits = self._metrics.cache_hits
            total_misses = self._metrics.cache_misses
            total_ops = total_hits + total_misses
            
            # Add Redis stats if available
            if self.redis_client:
                try:
                    info = await self.redis_client.info('stats')
                    total_hits += info.get('keyspace_hits', 0)
                    total_misses += info.get('keyspace_misses', 0)
                except Exception as e:
                    logger.warning(f"Failed to get Redis stats: {e}")
            
            # Add fallback stats
            if self.fallback_cache:
                fallback_stats = await self.fallback_cache.get_stats()
                total_hits += fallback_stats.hits
                total_misses += fallback_stats.misses
            
            total_size = 0
            max_size = 0
            
            if self.fallback_cache:
                fallback_stats = await self.fallback_cache.get_stats()
                total_size += fallback_stats.size
                max_size = max(max_size, fallback_stats.max_size)
            
            hit_rate = total_hits / (total_hits + total_misses) if (total_hits + total_misses) > 0 else 0.0
            
            return BaseCacheStats(
                hits=total_hits,
                misses=total_misses,
                evictions=0,
                size=total_size,
                max_size=max_size,
                hit_rate=hit_rate
            )
        except Exception as e:
            logger.error(f"Failed to get cache stats: {e}")
            return BaseCacheStats()
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on cache service."""
        health = {
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'components': {}
        }
        
        # Check Redis
        if self.redis_client:
            try:
                start_time = time.time()
                await self.redis_client.ping()
                latency = (time.time() - start_time) * 1000
                
                health['components']['redis'] = {
                    'status': 'healthy',
                    'latency_ms': round(latency, 2)
                }
            except Exception as e:
                health['components']['redis'] = {
                    'status': 'unhealthy',
                    'error': str(e)
                }
                health['status'] = 'degraded'
        else:
            health['components']['redis'] = {
                'status': 'not_configured'
            }
        
        # Check fallback cache
        if self.fallback_cache:
            health['components']['fallback_cache'] = {
                'status': 'healthy',
                'max_size': self.fallback_cache.max_size,
                'current_size': len(self.fallback_cache._cache)
            }
        else:
            health['components']['fallback_cache'] = {
                'status': 'not_configured'
            }
        
        # Overall status
        if health['status'] == 'healthy':
            if any(comp['status'] == 'unhealthy' for comp in health['components'].values()):
                health['status'] = 'degraded'
        
        return health
    
    async def close(self):
        """Close cache service and cleanup resources."""
        try:
            if self.redis_client:
                await self.redis_client.close()
            
            logger.info("Cache service closed")
        except Exception as e:
            logger.error(f"Error closing cache service: {e}")


# Global cache service instance
cache_service = None


async def get_cache_service() -> RedisCacheService:
    """Get or create global cache service instance."""
    global cache_service
    if cache_service is None:
        cache_service = RedisCacheService()
        await cache_service.initialize()
    return cache_service


# Convenience decorators and utilities

def cached(
    ttl: Optional[int] = None,
    key_func: Optional[Callable] = None,
    tags: Optional[List[str]] = None
):
    """
    Decorator for caching function results.
    
    Usage:
        @cached(ttl=300, tags=['user_data'])
        async def get_user_data(user_id: int):
            # Expensive operation
            return data
    """
    async def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            service = await get_cache_service()
            
            # Generate cache key
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                key_data = {
                    'func': func.__name__,
                    'args': args,
                    'kwargs': sorted(kwargs.items())
                }
                key_str = json.dumps(key_data, sort_keys=True, default=str)
                cache_key = hashlib.md5(key_str.encode()).hexdigest()
            
            # Try to get from cache
            cached_value = await service.get(cache_key)
            if cached_value is not None:
                return cached_value
            
            # Execute function
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Cache the result
            if result is not None:
                await service.set(cache_key, result, ttl, tags)
            
            return result
        
        return wrapper
    return decorator


# Export main classes and functions
__all__ = [
    'RedisCacheService',
    'CacheMetrics',
    'CacheEntry',
    'SerializationManager',
    'CacheTagManager',
    'CachePartitioner',
    'CacheWarmer',
    'CacheAnalytics',
    'InMemoryFallbackCache',
    'cache_service',
    'get_cache_service',
    'cached'
]
