"""
Streaming Models for comprehensive streaming response system.
"""

from enum import Enum
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
from pydantic import BaseModel, Field
import uuid


class StreamState(str, Enum):
    """Stream state enumeration."""
    CONNECTED = "connected"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ERROR = "error"
    TIMEOUT = "timeout"


class StreamEventType(str, Enum):
    """Stream event types."""
    CONNECT = "connect"
    DISCONNECT = "disconnect"
    DATA = "data"
    PROGRESS = "progress"
    COMPLETE = "complete"
    ERROR = "error"
    HEARTBEAT = "heartbeat"
    META = "meta"
    CANCEL = "cancel"
    RESUME = "resume"


class StreamEvent(BaseModel):
    """Base stream event model."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: StreamEventType
    session_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    data: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    
    class Config:
        use_enum_values = True


class StreamMetadata(BaseModel):
    """Stream metadata model."""
    session_id: str
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: Optional[datetime] = None
    total_events: int = 0
    bytes_sent: int = 0
    tokens_sent: int = 0
    buffer_size: int = 0
    max_buffer_size: int = 1000
    stream_type: str = "chat"
    priority: int = 1
    
    class Config:
        use_enum_values = True


class StreamConfig(BaseModel):
    """Stream configuration model."""
    chunk_size: int = Field(default=50, ge=1, le=1000)
    buffer_size: int = Field(default=100, ge=10, le=10000)
    timeout: int = Field(default=300, ge=10, le=3600)
    max_concurrent_streams: int = Field(default=100, ge=1, le=1000)
    heartbeat_interval: int = Field(default=30, ge=5, le=300)
    retry_attempts: int = Field(default=3, ge=0, le=10)
    compression_enabled: bool = True
    encryption_enabled: bool = False
    rate_limit: Optional[int] = Field(default=None, ge=1, le=1000)
    
    class Config:
        use_enum_values = True


class StreamMetrics(BaseModel):
    """Stream metrics model."""
    active_streams: int = 0
    total_streams: int = 0
    completed_streams: int = 0
    cancelled_streams: int = 0
    error_streams: int = 0
    average_duration: float = 0.0
    total_bytes_sent: int = 0
    total_tokens_sent: int = 0
    average_tokens_per_second: float = 0.0
    peak_concurrent_streams: int = 0
    buffer_overflow_events: int = 0
    timeout_events: int = 0
    
    class Config:
        use_enum_values = True


class ProgressUpdate(BaseModel):
    """Progress update model."""
    session_id: str
    operation_id: str
    progress_percentage: float = Field(ge=0.0, le=100.0)
    current_step: str
    total_steps: int
    estimated_completion: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        use_enum_values = True


class StreamContext(BaseModel):
    """Stream context model."""
    session_id: str
    user_id: str
    request_id: str
    stream_type: str
    config: StreamConfig
    callbacks: Optional[Dict[str, Callable]] = None
    custom_data: Optional[Dict[str, Any]] = None
    
    class Config:
        use_enum_values = True


class TokenChunk(BaseModel):
    """Token chunk model for streaming."""
    content: str
    token_count: int
    chunk_index: int
    is_final: bool = False
    metadata: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class StreamError(BaseModel):
    """Stream error model."""
    error_code: str
    error_message: str
    error_type: str
    recoverable: bool = True
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Optional[Dict[str, Any]] = None