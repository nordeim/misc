"""
Server-Sent Events (SSE) implementation for real-time streaming.

This module provides comprehensive SSE capabilities including:
- SSE endpoint implementation
- Event formatting and structure
- Connection management for SSE
- SSE authentication and security
"""

import asyncio
import json
import time
from typing import Dict, Any, Optional, List, Callable, AsyncIterator
from datetime import datetime
from urllib.parse import parse_qs
import uuid

from fastapi import Request, Response, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse, JSONResponse
from starlette.responses import Response as StarletteResponse

from .models import (
    StreamEvent, StreamEventType, StreamConfig,
    StreamContext, StreamState, StreamError
)
from .managers import StreamManager, StreamConnection, StreamSession
import structlog

logger = structlog.get_logger(__name__)


class SSEEventFormatter:
    """Format events for SSE protocol."""
    
    @staticmethod
    def format_event(event: StreamEvent) -> str:
        """Format a stream event as SSE data."""
        lines = []
        
        # Event type (for event listeners)
        if event.type != StreamEventType.DATA:
            lines.append(f"event: {event.type.value}")
        
        # Unique event ID for resumption
        lines.append(f"id: {event.id}")
        
        # Event data
        data = {
            "type": event.type.value if hasattr(event.type, 'value') else str(event.type),
            "session_id": event.session_id,
            "timestamp": event.timestamp.isoformat(),
            "data": event.data or {}
        }
        
        if event.metadata:
            data["metadata"] = event.metadata
        
        lines.append(f"data: {json.dumps(data, ensure_ascii=False)}")
        
        # End with double newline
        lines.append("")
        
        return "\n".join(lines)
    
    @staticmethod
    def format_heartbeat() -> str:
        """Format a heartbeat event."""
        return f"event: heartbeat\nid: {uuid.uuid4()}\ndata: {{\"timestamp\": \"{datetime.utcnow().isoformat()}\"}}\n\n"
    
    @staticmethod
    def format_error(error: StreamError) -> str:
        """Format an error event."""
        event = StreamEvent(
            type=StreamEventType.ERROR,
            session_id="system",
            data=error.dict(),
            metadata={"timestamp": error.timestamp.isoformat()}
        )
        return SSEEventFormatter.format_event(event)


class SSEConnectionManager:
    """Manage SSE connections with proper lifecycle handling."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.active_connections: Dict[str, Dict[str, Any]] = {}
        self.heartbeat_interval = 30  # seconds
    
    async def create_sse_connection(
        self,
        session_id: str,
        request: Request,
        connection_id: Optional[str] = None
    ) -> StreamConnection:
        """Create a new SSE connection."""
        
        conn_id = connection_id or str(uuid.uuid4())
        
        # Get session
        session = await self.stream_manager.get_session(session_id)
        if not session:
            # Create new session if doesn't exist
            context = StreamContext(
                session_id=session_id,
                user_id="anonymous",  # Would be from auth in production
                request_id=str(uuid.uuid4()),
                stream_type="sse",
                config=StreamConfig()
            )
            session = await self.stream_manager.create_session(context)
        
        # Create connection
        connection = await self.stream_manager.create_connection(session_id, conn_id)
        if not connection:
            raise RuntimeError("Failed to create SSE connection")
        
        # Store connection info
        self.active_connections[conn_id] = {
            "session_id": session_id,
            "connection": connection,
            "created_at": datetime.utcnow(),
            "last_heartbeat": datetime.utcnow(),
            "client_ip": request.client.host if request.client else "unknown"
        }
        
        logger.info("Created SSE connection",
                   connection_id=conn_id,
                   session_id=session_id)
        
        return connection
    
    async def close_connection(self, connection_id: str):
        """Close an SSE connection."""
        if connection_id in self.active_connections:
            conn_info = self.active_connections[connection_id]
            connection = conn_info["connection"]
            
            # Cancel any ongoing streams
            await connection.cancel("SSE connection closed")
            
            # Remove from manager
            del self.active_connections[connection_id]
            
            logger.info("Closed SSE connection", connection_id=connection_id)
    
    async def broadcast_to_connection(self, connection_id: str, event: StreamEvent):
        """Broadcast event to specific connection."""
        if connection_id in self.active_connections:
            conn_info = self.active_connections[connection_id]
            connection = conn_info["connection"]
            await connection.send_event(event)
    
    async def broadcast_to_session(self, session_id: str, event: StreamEvent):
        """Broadcast event to all connections in a session."""
        for conn_id, conn_info in self.active_connections.items():
            if conn_info["session_id"] == session_id:
                connection = conn_info["connection"]
                await connection.send_event(event)
    
    def get_connection_metrics(self, connection_id: str) -> Optional[Dict[str, Any]]:
        """Get metrics for a connection."""
        if connection_id not in self.active_connections:
            return None
        
        conn_info = self.active_connections[connection_id]
        connection = conn_info["connection"]
        
        return {
            "connection_id": connection_id,
            "session_id": conn_info["session_id"],
            "created_at": conn_info["created_at"].isoformat(),
            "client_ip": conn_info["client_ip"],
            "connection_state": connection.state.value,
            "total_events": connection.metadata.total_events,
            "last_heartbeat": conn_info["last_heartbeat"].isoformat()
        }
    
    def get_active_connections_count(self) -> int:
        """Get count of active connections."""
        return len(self.active_connections)
    
    async def cleanup_expired_connections(self, timeout_seconds: int = 300):
        """Clean up expired connections."""
        current_time = datetime.utcnow()
        expired_connections = []
        
        for conn_id, conn_info in self.active_connections.items():
            connection = conn_info["connection"]
            
            # Check if connection is expired
            if (current_time - conn_info["last_heartbeat"]).total_seconds() > timeout_seconds:
                expired_connections.append(conn_id)
        
        # Remove expired connections
        for conn_id in expired_connections:
            await self.close_connection(conn_id)
        
        if expired_connections:
            logger.info("Cleaned up expired SSE connections", count=len(expired_connections))


class SSEEndpoint:
    """SSE endpoint handler with authentication and security."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.connection_manager = SSEConnectionManager(stream_manager)
        self.formatter = SSEEventFormatter()
    
    async def sse_endpoint(
        self,
        request: Request,
        session_id: str,
        stream_type: str = "chat"
    ) -> StreamingResponse:
        """Main SSE endpoint for streaming responses."""
        
        try:
            # Authenticate and validate request
            await self._validate_sse_request(request, session_id)
            
            # Create SSE connection
            connection = await self.connection_manager.create_sse_connection(
                session_id, request
            )
            
            # Start SSE stream
            return StreamingResponse(
                self._sse_stream_generator(connection, request),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",  # Disable nginx buffering
                    "Access-Control-Allow-Origin": "*",  # CORS
                    "Access-Control-Allow-Headers": "Cache-Control, X-Auth-Token",
                }
            )
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error("SSE endpoint error", error=str(e))
            raise HTTPException(status_code=500, detail="SSE endpoint failed")
    
    async def sse_status_endpoint(
        self,
        request: Request
    ) -> JSONResponse:
        """Get SSE connection status."""
        try:
            query_params = parse_qs(request.query_params._dict)
            connection_id = query_params.get("connection_id", [None])[0]
            
            if connection_id:
                metrics = self.connection_manager.get_connection_metrics(connection_id)
                if not metrics:
                    return JSONResponse(
                        status_code=404,
                        content={"detail": "Connection not found"}
                    )
            else:
                metrics = {
                    "active_connections": self.connection_manager.get_active_connections_count(),
                    "total_sessions": len(self.stream_manager.sessions),
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            return JSONResponse(content=metrics)
            
        except Exception as e:
            logger.error("SSE status endpoint error", error=str(e))
            return JSONResponse(
                status_code=500,
                content={"detail": "Failed to get status"}
            )
    
    async def sse_cancel_endpoint(
        self,
        request: Request,
        connection_id: str
    ) -> JSONResponse:
        """Cancel an SSE stream."""
        try:
            await self.connection_manager.close_connection(connection_id)
            
            return JSONResponse(content={
                "message": "Stream cancelled successfully",
                "connection_id": connection_id
            })
            
        except Exception as e:
            logger.error("SSE cancel endpoint error", error=str(e))
            return JSONResponse(
                status_code=500,
                content={"detail": "Failed to cancel stream"}
            )
    
    async def _validate_sse_request(self, request: Request, session_id: str):
        """Validate SSE request with authentication."""
        
        # Check if session_id is valid
        if not session_id or len(session_id) < 1:
            raise HTTPException(status_code=400, detail="Invalid session_id")
        
        # Check request headers
        if "text/event-stream" not in request.headers.get("accept", ""):
            raise HTTPException(
                status_code=400, 
                detail="This endpoint requires text/event-stream Accept header"
            )
        
        # Rate limiting could be added here
        
        # Authentication check (simplified - would integrate with auth system)
        auth_header = request.headers.get("authorization")
        if auth_header:
            # Validate auth token here
            pass
        
        logger.debug("SSE request validated",
                    session_id=session_id,
                    client_ip=request.client.host if request.client else "unknown")
    
    async def _sse_stream_generator(
        self,
        connection: StreamConnection,
        request: Request
    ) -> AsyncIterator[str]:
        """Generate SSE events for streaming response."""
        
        try:
            # Send initial connection event
            initial_event = StreamEvent(
                type=StreamEventType.CONNECT,
                session_id=connection.session_id,
                data={
                    "message": "SSE connection established",
                    "connection_id": connection.connection_id,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
            
            yield self.formatter.format_event(initial_event)
            
            # Main event streaming loop
            last_heartbeat = time.time()
            
            while not request.is_disconnected():
                try:
                    # Check for events from connection
                    event = await asyncio.wait_for(
                        connection.receive_event(timeout=1.0),
                        timeout=1.0
                    )
                    
                    if event:
                        # Format and send event
                        sse_data = self.formatter.format_event(event)
                        yield sse_data
                    
                    # Send heartbeat periodically
                    current_time = time.time()
                    if current_time - last_heartbeat >= self.connection_manager.heartbeat_interval:
                        yield self.formatter.format_heartbeat()
                        last_heartbeat = current_time
                        
                        # Update connection heartbeat
                        if connection.connection_id in self.connection_manager.active_connections:
                            self.connection_manager.active_connections[connection.connection_id]["last_heartbeat"] = datetime.utcnow()
                    
                except asyncio.TimeoutError:
                    # Timeout is normal - continue loop
                    continue
                except Exception as e:
                    logger.error("Error in SSE stream loop",
                               connection_id=connection.connection_id,
                               error=str(e))
                    
                    # Send error event
                    error_event = StreamEvent(
                        type=StreamEventType.ERROR,
                        session_id=connection.session_id,
                        data={
                            "error_code": "stream_error",
                            "error_message": "Stream processing error"
                        }
                    )
                    yield self.formatter.format_event(error_event)
                    break
            
            # Connection disconnected - send final event
            disconnect_event = StreamEvent(
                type=StreamEventType.DISCONNECT,
                session_id=connection.session_id,
                data={"reason": "Client disconnected"}
            )
            yield self.formatter.format_event(disconnect_event)
            
        except asyncio.CancelledError:
            logger.info("SSE stream cancelled", connection_id=connection.connection_id)
        except Exception as e:
            logger.error("SSE stream error", connection_id=connection.connection_id, error=str(e))
        finally:
            # Cleanup connection
            await self.connection_manager.close_connection(connection.connection_id)


class SSEMiddleware:
    """Middleware for SSE connection management and monitoring."""
    
    def __init__(self, stream_manager: StreamManager):
        self.stream_manager = stream_manager
        self.connection_manager = SSEConnectionManager(stream_manager)
        self.active_tasks: Dict[str, asyncio.Task] = {}
    
    async def __call__(self, request: Request, call_next):
        """Process request with SSE middleware."""
        
        # Check if this is an SSE request
        if self._is_sse_request(request):
            # Start background tasks for SSE management
            await self._start_sse_background_tasks()
        
        # Process request
        response = await call_next(request)
        
        return response
    
    def _is_sse_request(self, request: Request) -> bool:
        """Check if request is an SSE request."""
        return (
            "/sse/" in request.url.path or
            "text/event-stream" in request.headers.get("accept", "")
        )
    
    async def _start_sse_background_tasks(self):
        """Start background tasks for SSE management."""
        
        if "cleanup_task" not in self.active_tasks:
            self.active_tasks["cleanup_task"] = asyncio.create_task(
                self._cleanup_expired_sse_connections()
            )
    
    async def _cleanup_expired_sse_connections(self):
        """Background task to cleanup expired SSE connections."""
        while True:
            try:
                await asyncio.sleep(60)  # Run every minute
                await self.connection_manager.cleanup_expired_connections()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in SSE cleanup task", error=str(e))
    
    async def stop(self):
        """Stop SSE middleware background tasks."""
        for task_name, task in self.active_tasks.items():
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        self.active_tasks.clear()