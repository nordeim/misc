"""
Streaming API Routes for comprehensive streaming functionality.

This module provides REST API endpoints for:
- Server-Sent Events (SSE) streaming
- Token-by-token streaming for chat and agent responses
- Progress tracking and real-time status updates
- Stream management and monitoring
"""

import asyncio
import json
import uuid
from typing import Dict, Any, Optional, List, AsyncIterator
from datetime import datetime

from fastapi import APIRouter, Request, HTTPException, Depends, Query, BackgroundTasks
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from app.streaming.models import (
    StreamConfig, StreamContext, StreamEventType,
    ProgressUpdate, StreamEvent, StreamState
)
from app.streaming.managers import StreamManager, StreamConnection
from app.streaming.handlers import (
    ChatStreamHandler, AgentStreamHandler, 
    ProgressTracker, StreamingChatSimulator, StreamingAgentSimulator
)
from app.streaming.sse import SSEEndpoint, SSEEventFormatter
from app.streaming.utils import (
    StreamMonitor, StreamAnalytics, StreamRecovery, BufferManager
)
from app.dependencies import get_current_user, get_db
import structlog

logger = structlog.get_logger(__name__)

# Initialize streaming components
stream_manager = StreamManager()
sse_endpoint = SSEEndpoint(stream_manager)
chat_handler = ChatStreamHandler(stream_manager)
agent_handler = AgentStreamHandler(stream_manager)
monitor = StreamMonitor(stream_manager)
analytics = StreamAnalytics(stream_manager)
recovery = StreamRecovery(stream_manager)

# Simulators for testing
chat_simulator = StreamingChatSimulator()
agent_simulator = StreamingAgentSimulator()

router = APIRouter(prefix="/streaming", tags=["Streaming"])


# ==============================================================================
# Pydantic Models for API
# ==============================================================================

class StreamingRequest(BaseModel):
    """Request model for streaming operations."""
    session_id: str = Field(..., min_length=1, max_length=100)
    message: Optional[str] = Field(None, max_length=10000)
    stream_type: str = Field(default="chat", regex="^(chat|agent|progress|status)$")
    enable_token_streaming: bool = True
    config: Optional[StreamConfig] = None
    metadata: Optional[Dict[str, Any]] = None


class ProgressRequest(BaseModel):
    """Request model for progress updates."""
    session_id: str
    operation_id: str
    current_step: str
    total_steps: int
    progress_percentage: float = Field(ge=0.0, le=100.0)
    metadata: Optional[Dict[str, Any]] = None


class StreamConfigRequest(BaseModel):
    """Request model for stream configuration."""
    chunk_size: int = Field(default=50, ge=1, le=1000)
    buffer_size: int = Field(default=100, ge=10, le=10000)
    timeout: int = Field(default=300, ge=10, le=3600)
    heartbeat_interval: int = Field(default=30, ge=5, le=300)


# ==============================================================================
# SSE Endpoints
# ==============================================================================

@router.get("/sse/{session_id}")
async def sse_stream_endpoint(
    request: Request,
    session_id: str,
    stream_type: str = Query("chat", regex="^(chat|agent|progress|status)$"),
    user = Depends(get_current_user)
):
    """
    Server-Sent Events endpoint for streaming responses.
    
    Returns a streaming response that sends events as they occur.
    """
    try:
        return await sse_endpoint.sse_endpoint(request, session_id, stream_type)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("SSE endpoint error", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="SSE endpoint failed")


@router.get("/sse/status")
async def sse_status_endpoint(request: Request):
    """Get SSE connection status."""
    return await sse_endpoint.sse_status_endpoint(request)


@router.delete("/sse/cancel/{connection_id}")
async def sse_cancel_endpoint(
    connection_id: str,
    user = Depends(get_current_user)
):
    """Cancel an SSE stream."""
    return await sse_endpoint.sse_cancel_endpoint(request, connection_id)


# ==============================================================================
# Chat Streaming Endpoints
# ==============================================================================

@router.post("/chat/start")
async def start_chat_stream(
    request: StreamingRequest,
    user = Depends(get_current_user)
):
    """
    Start a streaming chat response.
    
    Returns a connection object that can be used for token-by-token streaming.
    """
    try:
        # Create streaming context
        context = StreamContext(
            session_id=request.session_id,
            user_id=user.id if user else "anonymous",
            request_id=str(uuid.uuid4()),
            stream_type=request.stream_type,
            config=request.config or StreamConfig(),
            custom_data=request.metadata
        )
        
        # Start streaming session
        connection = await chat_handler.start_stream(
            context=context,
            message=request.message or "",
            connection_id=f"chat_{request.session_id}"
        )
        
        return {
            "session_id": request.session_id,
            "connection_id": connection.connection_id,
            "stream_type": "chat",
            "status": "started",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to start chat stream", error=str(e), session_id=request.session_id)
        raise HTTPException(status_code=500, detail="Failed to start chat stream")


@router.post("/chat/stream/{session_id}")
async def stream_chat_response(
    session_id: str,
    request: StreamingRequest,
    background_tasks: BackgroundTasks,
    user = Depends(get_current_user)
):
    """
    Stream a chat response token by token.
    
    This endpoint starts the streaming process and returns immediately.
    The actual token streaming happens through the SSE endpoint.
    """
    try:
        # Validate session
        if session_id != request.session_id:
            raise HTTPException(status_code=400, detail="Session ID mismatch")
        
        # Create streaming generator
        async def response_generator():
            async for token in chat_simulator.generate_streaming_response(
                message=request.message or "",
                delay=0.2
            ):
                yield token
        
        # Start background streaming task
        background_tasks.add_task(
            chat_handler.stream_response,
            session_id=session_id,
            response_generator=response_generator()
        )
        
        return {
            "session_id": session_id,
            "status": "streaming_started",
            "message": "Response streaming has begun",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to start chat streaming", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to start chat streaming")


@router.post("/chat/cancel/{session_id}")
async def cancel_chat_stream(
    session_id: str,
    reason: str = Query("User cancelled"),
    user = Depends(get_current_user)
):
    """Cancel a streaming chat session."""
    try:
        await chat_handler.cancel_stream(session_id, reason)
        
        return {
            "session_id": session_id,
            "status": "cancelled",
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to cancel chat stream", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to cancel chat stream")


# ==============================================================================
# Agent Streaming Endpoints
# ==============================================================================

@router.post("/agent/start")
async def start_agent_stream(
    request: StreamingRequest,
    user = Depends(get_current_user)
):
    """
    Start a streaming agent response.
    
    Returns a connection object for agent response streaming.
    """
    try:
        # Create streaming context
        context = StreamContext(
            session_id=request.session_id,
            user_id=user.id if user else "anonymous",
            request_id=str(uuid.uuid4()),
            stream_type=request.stream_type,
            config=request.config or StreamConfig(),
            custom_data=request.metadata
        )
        
        # Create agent response generator
        async def agent_response_generator():
            async for response in agent_simulator.generate_agent_response(
                query=request.message or "",
                context={"user_id": user.id if user else "anonymous"}
            ):
                yield response
        
        # Start streaming session
        connection = await agent_handler.start_agent_stream(
            context=context,
            agent_response_generator=agent_response_generator(),
            connection_id=f"agent_{request.session_id}"
        )
        
        return {
            "session_id": request.session_id,
            "connection_id": connection.connection_id,
            "stream_type": "agent",
            "status": "started",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to start agent stream", error=str(e), session_id=request.session_id)
        raise HTTPException(status_code=500, detail="Failed to start agent stream")


@router.post("/agent/stream/{session_id}")
async def stream_agent_response(
    session_id: str,
    request: StreamingRequest,
    background_tasks: BackgroundTasks,
    user = Depends(get_current_user)
):
    """Stream agent response token by token."""
    try:
        if session_id != request.session_id:
            raise HTTPException(status_code=400, detail="Session ID mismatch")
        
        # Start background streaming task
        background_tasks.add_task(
            agent_handler.stream_agent_response,
            session_id=session_id,
            metadata=request.metadata
        )
        
        return {
            "session_id": session_id,
            "status": "agent_streaming_started",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to start agent streaming", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to start agent streaming")


@router.post("/agent/cancel/{session_id}")
async def cancel_agent_stream(
    session_id: str,
    reason: str = Query("Agent stream cancelled"),
    user = Depends(get_current_user)
):
    """Cancel agent streaming session."""
    try:
        await agent_handler.cancel_agent_stream(session_id, reason)
        
        return {
            "session_id": session_id,
            "status": "agent_cancelled",
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to cancel agent stream", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to cancel agent stream")


# ==============================================================================
# Progress Tracking Endpoints
# ==============================================================================

@router.post("/progress/start")
async def start_progress_tracking(
    request: ProgressRequest,
    user = Depends(get_current_user)
):
    """Start tracking progress for a long-running operation."""
    try:
        # Create progress tracker
        progress_tracker = ProgressTracker(
            session_id=request.session_id,
            operation_id=request.operation_id,
            total_steps=request.total_steps
        )
        
        # Store tracker reference (in production, use proper storage)
        progress_tracker_id = f"{request.session_id}_{request.operation_id}"
        
        # Initialize progress
        await progress_tracker.update_step("Operation started")
        
        return {
            "session_id": request.session_id,
            "operation_id": request.operation_id,
            "tracker_id": progress_tracker_id,
            "total_steps": request.total_steps,
            "status": "tracking_started",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to start progress tracking", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to start progress tracking")


@router.post("/progress/update")
async def update_progress(
    request: ProgressRequest,
    user = Depends(get_current_user)
):
    """Update progress for an operation."""
    try:
        # Create progress update
        progress_update = ProgressUpdate(
            session_id=request.session_id,
            operation_id=request.operation_id,
            progress_percentage=request.progress_percentage,
            current_step=request.current_step,
            total_steps=request.total_steps,
            metadata=request.metadata
        )
        
        # Send progress update through chat handler
        await chat_handler.send_progress(request.session_id, progress_update)
        
        return {
            "session_id": request.session_id,
            "operation_id": request.operation_id,
            "progress_percentage": request.progress_percentage,
            "status": "progress_updated",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to update progress", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to update progress")


@router.post("/progress/complete")
async def complete_progress(
    session_id: str,
    operation_id: str,
    user = Depends(get_current_user)
):
    """Mark progress tracking as complete."""
    try:
        # Create completion update
        completion_update = ProgressUpdate(
            session_id=session_id,
            operation_id=operation_id,
            progress_percentage=100.0,
            current_step="Operation completed",
            total_steps=100
        )
        
        await chat_handler.send_progress(session_id, completion_update)
        
        return {
            "session_id": session_id,
            "operation_id": operation_id,
            "status": "completed",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to complete progress", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to complete progress")


# ==============================================================================
# Stream Management Endpoints
# ==============================================================================

@router.get("/streams")
async def list_active_streams(
    user = Depends(get_current_user)
):
    """List all active streaming sessions."""
    try:
        stream_list = []
        
        for session_id, session in stream_manager.sessions.items():
            if session.is_alive():
                active_connections = session.get_active_connections()
                stream_list.append({
                    "session_id": session_id,
                    "stream_type": session.context.stream_type,
                    "active_connections": len(active_connections),
                    "state": session.state.value,
                    "created_at": session.created_at.isoformat(),
                    "user_id": session.context.user_id
                })
        
        return {
            "active_streams": len(stream_list),
            "streams": stream_list,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to list streams", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to list streams")


@router.get("/streams/{session_id}")
async def get_stream_details(
    session_id: str,
    user = Depends(get_current_user)
):
    """Get detailed information about a streaming session."""
    try:
        session = await stream_manager.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Stream not found")
        
        metrics = await stream_manager.get_stream_metrics()
        connection_details = []
        
        for connection_id, connection in session.connections.items():
            connection_details.append({
                "connection_id": connection_id,
                "state": connection.state.value,
                "connected_at": connection.connected_at.isoformat(),
                "total_events": connection.metadata.total_events,
                "tokens_sent": connection.metadata.tokens_sent
            })
        
        return {
            "session_id": session_id,
            "session_details": session.get_metrics(),
            "connection_details": connection_details,
            "system_metrics": metrics,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get stream details", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to get stream details")


@router.delete("/streams/{session_id}")
async def terminate_stream(
    session_id: str,
    reason: str = Query("Stream terminated by user"),
    user = Depends(get_current_user)
):
    """Terminate a streaming session."""
    try:
        session = await stream_manager.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Stream not found")
        
        # Cancel all connections
        for connection in session.get_active_connections():
            await connection.cancel(reason)
        
        return {
            "session_id": session_id,
            "status": "terminated",
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to terminate stream", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to terminate stream")


# ==============================================================================
# Monitoring and Analytics Endpoints
# ==============================================================================

@router.get("/monitoring/performance")
async def get_performance_metrics(
    session_id: Optional[str] = None,
    user = Depends(get_current_user)
):
    """Get streaming performance metrics."""
    try:
        report = await monitor.get_performance_report(session_id)
        return report
        
    except Exception as e:
        logger.error("Failed to get performance metrics", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get performance metrics")


@router.get("/monitoring/analytics")
async def get_streaming_analytics(
    session_id: Optional[str] = None,
    user = Depends(get_current_user)
):
    """Get streaming analytics data."""
    try:
        analytics_data = await analytics.get_analytics_summary(session_id)
        return analytics_data
        
    except Exception as e:
        logger.error("Failed to get analytics", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get analytics")


@router.get("/monitoring/health")
async def get_streaming_health(
    user = Depends(get_current_user)
):
    """Get overall streaming system health."""
    try:
        stream_metrics = await stream_manager.get_stream_metrics()
        performance_stats = monitor.get_performance_stats()
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": "healthy",  # Would be calculated based on metrics
            "stream_metrics": stream_metrics,
            "performance_stats": performance_stats,
            "recovery_stats": recovery.get_recovery_stats()
        }
        
    except Exception as e:
        logger.error("Failed to get streaming health", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to get streaming health")


# ==============================================================================
# Configuration Endpoints
# ==============================================================================

@router.post("/config/validate")
async def validate_stream_config(
    config: StreamConfigRequest,
    user = Depends(get_current_user)
):
    """Validate streaming configuration."""
    try:
        stream_config = StreamConfig(
            chunk_size=config.chunk_size,
            buffer_size=config.buffer_size,
            timeout=config.timeout,
            heartbeat_interval=config.heartbeat_interval
        )
        
        validation_result = stream_config.dict()
        validation_result["valid"] = True
        validation_result["validated_at"] = datetime.utcnow().isoformat()
        
        return validation_result
        
    except Exception as e:
        logger.error("Failed to validate stream config", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to validate stream config")


# ==============================================================================
# Recovery and Resumption Endpoints
# ==============================================================================

@router.post("/recovery/create")
async def create_recovery_point(
    session_id: str,
    stream_data: Dict[str, Any],
    user = Depends(get_current_user)
):
    """Create a recovery point for a stream."""
    try:
        await recovery.create_recovery_point(session_id, stream_data)
        
        return {
            "session_id": session_id,
            "status": "recovery_point_created",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to create recovery point", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to create recovery point")


@router.post("/recovery/{session_id}")
async def recover_stream(
    session_id: str,
    user = Depends(get_current_user)
):
    """Recover a stream from recovery point."""
    try:
        recovery_data = await recovery.recover_stream(session_id)
        if not recovery_data:
            raise HTTPException(status_code=404, detail="No recovery point found")
        
        return {
            "session_id": session_id,
            "recovery_data": recovery_data,
            "status": "recovered",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to recover stream", error=str(e), session_id=session_id)
        raise HTTPException(status_code=500, detail="Failed to recover stream")


@router.post("/recovery/cleanup")
async def cleanup_recovery_points(
    max_age_hours: int = Query(24, ge=1, le=168),
    user = Depends(get_current_user)
):
    """Clean up old recovery points."""
    try:
        await recovery.cleanup_old_recovery_points(max_age_hours)
        recovery_stats = recovery.get_recovery_stats()
        
        return {
            "status": "cleanup_completed",
            "max_age_hours": max_age_hours,
            "recovery_stats": recovery_stats,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error("Failed to cleanup recovery points", error=str(e))
        raise HTTPException(status_code=500, detail="Failed to cleanup recovery points")


# ==============================================================================
# System Integration Functions
# ==============================================================================

async def initialize_streaming_system():
    """Initialize the streaming system components."""
    try:
        await stream_manager.start()
        await monitor.start_monitoring()
        logger.info("Streaming system initialized successfully")
        
    except Exception as e:
        logger.error("Failed to initialize streaming system", error=str(e))
        raise


async def shutdown_streaming_system():
    """Shutdown the streaming system components."""
    try:
        await stream_manager.stop()
        await monitor.stop_monitoring()
        logger.info("Streaming system shutdown completed")
        
    except Exception as e:
        logger.error("Failed to shutdown streaming system", error=str(e))
        raise