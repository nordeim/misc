"""
Test script for comprehensive observability and metrics collection system.

This script validates:
1. Observability service initialization
2. Metrics collection functionality
3. Health check aggregation
4. Alert system functionality
5. Performance tracking
6. Distributed tracing
7. Health dashboard data
8. Integration with existing monitoring

Run with: python test_observability_system.py
"""

import asyncio
import json
import time
from datetime import datetime
import sys
import os

# Add the backend directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

from app.services.observability_service import (
    initialize_observability, get_observability_service,
    ObservabilityConfig, ObservabilityLevel
)
from app.utils.health_check_aggregator import health_aggregator, initialize_common_health_checks
from app.utils.observability_decorators import (
    monitor_performance, track_business_metric, 
    monitor_database_operation, observability_context
)
from app.utils.observability_setup import (
    configure_production_observability, ObservabilitySetup
)

class ObservabilityTester:
    """Test suite for observability system."""
    
    def __init__(self):
        self.observability_service = None
        self.test_results = []
    
    async def run_all_tests(self):
        """Run all observability tests."""
        print("🧪 Starting Observability System Tests")
        print("=" * 50)
        
        try:
            # Test 1: Basic initialization
            await self.test_observability_initialization()
            
            # Test 2: Metrics collection
            await self.test_metrics_collection()
            
            # Test 3: Health check aggregation
            await self.test_health_check_aggregation()
            
            # Test 4: Performance tracking
            await self.test_performance_tracking()
            
            # Test 5: Distributed tracing
            await self.test_distributed_tracing()
            
            # Test 6: Alert system
            await self.test_alert_system()
            
            # Test 7: Health dashboard data
            await self.test_health_dashboard()
            
            # Test 8: Decorators and utilities
            await self.test_decorators()
            
            # Test 9: Integration endpoints
            await self.test_integration_endpoints()
            
            # Test 10: Export functionality
            await self.test_export_functionality()
            
        except Exception as e:
            print(f"❌ Test suite failed with error: {e}")
            return False
        finally:
            await self.cleanup()
        
        # Print summary
        self.print_test_summary()
        return True
    
    async def test_observability_initialization(self):
        """Test observability service initialization."""
        print("\n📊 Testing Observability Initialization...")
        
        try:
            # Test default configuration
            config = ObservabilityConfig(
                level=ObservabilityLevel.STANDARD,
                prometheus_enabled=True,
                performance_tracking=True
            )
            
            self.observability_service = get_observability_service()
            await self.observability_service.start()
            
            print("✅ Observability service initialized successfully")
            self.test_results.append(("Initialization", True, "Service initialized"))
            
        except Exception as e:
            print(f"❌ Initialization failed: {e}")
            self.test_results.append(("Initialization", False, str(e)))
    
    async def test_metrics_collection(self):
        """Test metrics collection functionality."""
        print("\n📈 Testing Metrics Collection...")
        
        try:
            # Test request metrics
            self.observability_service.record_request(
                method="GET",
                endpoint="/test",
                status_code=200,
                response_time=0.125
            )
            
            # Test agent operation metrics
            self.observability_service.record_agent_operation(
                agent_type="chat",
                operation="process_message",
                status="success",
                duration=0.25
            )
            
            # Test message processing metrics
            self.observability_service.record_message_processing(
                message_type="chat",
                channel="web",
                processing_time=0.15,
                priority="normal"
            )
            
            # Test security event tracking
            self.observability_service.record_security_event(
                event_type="user_login",
                severity="info"
            )
            
            # Test metrics retrieval
            metrics_data = self.observability_service.get_metrics()
            
            print("✅ Metrics collection working")
            self.test_results.append(("Metrics Collection", True, "All metrics recorded successfully"))
            
        except Exception as e:
            print(f"❌ Metrics collection failed: {e}")
            self.test_results.append(("Metrics Collection", False, str(e)))
    
    async def test_health_check_aggregation(self):
        """Test health check aggregation system."""
        print("\n🏥 Testing Health Check Aggregation...")
        
        try:
            # Initialize common health checks
            initialize_common_health_checks()
            
            # Register test service health checks
            health_aggregator.register_service_health_check("test_service", ["database"])
            
            # Run health aggregation
            health_result = await health_aggregator.aggregate_health()
            
            # Validate health result structure
            assert hasattr(health_result, 'overall_status')
            assert hasattr(health_result, 'overall_score')
            assert hasattr(health_result, 'component_health')
            assert hasattr(health_result, 'health_trend')
            
            print(f"✅ Health aggregation working - Status: {health_result.overall_status.value}")
            self.test_results.append(("Health Aggregation", True, f"Overall status: {health_result.overall_status.value}"))
            
        except Exception as e:
            print(f"❌ Health aggregation failed: {e}")
            self.test_results.append(("Health Aggregation", False, str(e)))
    
    async def test_performance_tracking(self):
        """Test performance tracking functionality."""
        print("\n⚡ Testing Performance Tracking...")
        
        try:
            # Test performance context manager
            with observability_context("test_operation", "test_component"):
                await asyncio.sleep(0.1)  # Simulate work
            
            # Test performance monitor
            performance_summary = self.observability_service.get_performance_summary(hours=1)
            
            print("✅ Performance tracking working")
            self.test_results.append(("Performance Tracking", True, "Performance context manager functional"))
            
        except Exception as e:
            print(f"❌ Performance tracking failed: {e}")
            self.test_results.append(("Performance Tracking", False, str(e)))
    
    async def test_distributed_tracing(self):
        """Test distributed tracing functionality."""
        print("\n🔍 Testing Distributed Tracing...")
        
        try:
            # Create trace context
            context = self.observability_service.tracing.create_trace_context()
            
            # Start span
            span_context = self.observability_service.tracing.start_span("test_operation", context)
            
            # Simulate some work
            await asyncio.sleep(0.05)
            
            # Finish span
            self.observability_service.tracing.finish_span(span_context.span_id, "ok")
            
            # Get trace summary
            trace_summary = self.observability_service.get_trace_summary()
            
            print("✅ Distributed tracing working")
            self.test_results.append(("Distributed Tracing", True, "Trace context and spans functional"))
            
        except Exception as e:
            print(f"❌ Distributed tracing failed: {e}")
            self.test_results.append(("Distributed Tracing", False, str(e)))
    
    async def test_alert_system(self):
        """Test alert system functionality."""
        print("\n🚨 Testing Alert System...")
        
        try:
            # Get alert summary (initial state)
            initial_summary = self.observability_service.get_alert_summary()
            
            # Trigger a test alert by simulating high error rate
            from app.services.observability_service import ServiceMetrics
            
            test_metrics = ServiceMetrics(
                service_name="test",
                uptime_seconds=100,
                total_requests=100,
                error_count=10,  # 10% error rate
                avg_response_time=0.5,
                throughput_per_minute=10,
                cpu_usage=50,
                memory_usage=60,
                active_connections=5
            )
            
            system_info = {
                "cpu_percent": 50,
                "memory_percent": 60
            }
            
            # This should potentially trigger alerts
            self.observability_service.alert_manager.check_alerts(test_metrics, system_info)
            
            # Get updated alert summary
            updated_summary = self.observability_service.get_alert_summary()
            
            print("✅ Alert system working")
            self.test_results.append(("Alert System", True, "Alert checking functional"))
            
        except Exception as e:
            print(f"❌ Alert system failed: {e}")
            self.test_results.append(("Alert System", False, str(e)))
    
    async def test_health_dashboard(self):
        """Test health dashboard data generation."""
        print("\n📊 Testing Health Dashboard Data...")
        
        try:
            # Get dashboard data
            dashboard_data = health_aggregator.get_health_dashboard_data()
            
            # Validate dashboard structure
            required_keys = [
                'overall_status', 'overall_score', 'component_health', 
                'system_metrics', 'health_trend', 'critical_issues', 
                'recommendations', 'timestamp'
            ]
            
            for key in required_keys:
                assert key in dashboard_data, f"Missing dashboard key: {key}"
            
            print("✅ Health dashboard data generation working")
            self.test_results.append(("Health Dashboard", True, "Dashboard data structure valid"))
            
        except Exception as e:
            print(f"❌ Health dashboard failed: {e}")
            self.test_results.append(("Health Dashboard", False, str(e)))
    
    async def test_decorators(self):
        """Test observability decorators."""
        print("\n🎨 Testing Observability Decorators...")
        
        try:
            # Test performance decorator
            @monitor_performance(component="test", operation_name="decorated_function")
            async def test_function():
                await asyncio.sleep(0.01)
                return "success"
            
            result = await test_function()
            assert result == "success"
            
            # Test business metric decorator
            @track_business_metric("test_metric")
            async def test_business_function():
                return {"count": 5}
            
            result = await test_business_function()
            assert result == {"count": 5}
            
            print("✅ Observability decorators working")
            self.test_results.append(("Decorators", True, "All decorators functional"))
            
        except Exception as e:
            print(f"❌ Decorators failed: {e}")
            self.test_results.append(("Decorators", False, str(e)))
    
    async def test_integration_endpoints(self):
        """Test integration endpoints (simulated)."""
        print("\n🔗 Testing Integration Endpoints...")
        
        try:
            # Test health endpoint simulation
            health_status = await self.observability_service.get_health_status()
            assert 'status' in health_status
            assert 'timestamp' in health_status
            
            # Test metrics endpoint simulation
            metrics_text = self.observability_service.get_metrics()
            assert isinstance(metrics_text, str)
            assert len(metrics_text) > 0
            
            # Test performance endpoint simulation
            performance_data = self.observability_service.get_performance_summary()
            assert isinstance(performance_data, dict)
            
            print("✅ Integration endpoints working")
            self.test_results.append(("Integration Endpoints", True, "All endpoint simulations successful"))
            
        except Exception as e:
            print(f"❌ Integration endpoints failed: {e}")
            self.test_results.append(("Integration Endpoints", False, str(e)))
    
    async def test_export_functionality(self):
        """Test observability data export."""
        print("\n💾 Testing Export Functionality...")
        
        try:
            # Test observability data export
            export_path = "./data/test_export.json"
            success = self.observability_service.export_observability_data(export_path, hours=1)
            
            assert success == True
            
            # Check if file was created
            if os.path.exists(export_path):
                with open(export_path, 'r') as f:
                    export_data = json.load(f)
                
                assert 'export_timestamp' in export_data
                assert 'service_metrics' in export_data
                
                # Clean up
                os.remove(export_path)
            
            print("✅ Export functionality working")
            self.test_results.append(("Export Functionality", True, "Data export successful"))
            
        except Exception as e:
            print(f"❌ Export functionality failed: {e}")
            self.test_results.append(("Export Functionality", False, str(e)))
    
    async def cleanup(self):
        """Cleanup test resources."""
        try:
            if self.observability_service:
                await self.observability_service.stop()
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")
    
    def print_test_summary(self):
        """Print comprehensive test summary."""
        print("\n" + "=" * 50)
        print("🎯 OBSERVABILITY TEST SUMMARY")
        print("=" * 50)
        
        passed = sum(1 for _, success, _ in self.test_results if success)
        total = len(self.test_results)
        
        print(f"✅ Tests Passed: {passed}/{total}")
        print(f"❌ Tests Failed: {total - passed}/{total}")
        print(f"📊 Success Rate: {(passed/total)*100:.1f}%")
        
        print("\n📋 Detailed Results:")
        for test_name, success, message in self.test_results:
            status = "✅ PASS" if success else "❌ FAIL"
            print(f"  {status} {test_name}: {message}")
        
        if passed == total:
            print("\n🎉 ALL TESTS PASSED! Observability system is fully functional.")
        else:
            print(f"\n⚠️  {total - passed} tests failed. Please check the implementation.")
        
        print("\n" + "=" * 50)

async def main():
    """Main test execution."""
    tester = ObservabilityTester()
    success = await tester.run_all_tests()
    
    if success:
        print("\n🚀 Observability system is ready for production!")
    else:
        print("\n💥 Observability system needs attention!")
    
    return success

if __name__ == "__main__":
    # Run the tests
    asyncio.run(main())
