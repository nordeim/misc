#!/usr/bin/env python3
"""
Direct test of health check functionality without starting the full FastAPI server.
"""

import sys
import os
import json
from datetime import datetime
from pathlib import Path

# Add the backend directory to Python path
sys.path.insert(0, '/workspace/backend')

def test_imports():
    """Test importing health check modules."""
    print("Testing imports...")
    try:
        # Test importing monitoring modules
        from app.monitoring.health_check import HealthChecker
        from app.monitoring.dependency_checker import DependencyChecker
        from app.monitoring.backend_monitoring import SystemMetrics
        print("✓ Successfully imported monitoring modules")
        return True
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False

def test_health_checker():
    """Test the health checker functionality."""
    print("\nTesting HealthChecker...")
    try:
        from app.monitoring.health_check import HealthChecker
        
        # Create a simple health checker
        checker = HealthChecker()
        
        # Test basic functionality
        result = checker.get_summary()
        print(f"Health check result: {json.dumps(result, indent=2, default=str)}")
        
        print("✓ HealthChecker working")
        return True
    except Exception as e:
        print(f"✗ HealthChecker error: {e}")
        return False

def test_dependency_methods():
    """Test dependency checker methods exist."""
    print("\nTesting DependencyChecker methods...")
    try:
        from app.monitoring.dependency_checker import DependencyChecker
        
        checker = DependencyChecker()
        
        # Test that methods exist
        deps_to_test = [
            "check_database",
            "check_redis", 
            "check_chromadb",
            "check_openai",
            "check_azure_openai",
            "check_filesystem"
        ]
        
        for method in deps_to_test:
            if hasattr(checker, method):
                print(f"✓ {method} method exists")
            else:
                print(f"✗ {method} method not found")
        
        return True
    except Exception as e:
        print(f"✗ DependencyChecker error: {e}")
        return False

def test_health_endpoints_structure():
    """Test that health endpoints are properly structured."""
    print("\nTesting health endpoint structure...")
    try:
        from app.api.routes.health import router
        
        # Get all routes
        routes = [route.path for route in router.routes]
        print(f"Health routes found: {routes}")
        
        expected_routes = [
            "/health",
            "/health/ready", 
            "/health/live",
            "/health/dependencies",
            "/health/metrics",
            "/health/system",
            "/health/version",
            "/health/config"
        ]
        
        for expected in expected_routes:
            if expected in routes:
                print(f"✓ {expected} route exists")
            else:
                print(f"✗ {expected} route missing")
        
        return True
    except Exception as e:
        print(f"✗ Health endpoints error: {e}")
        return False

def test_system_metrics():
    """Test system metrics functionality."""
    print("\nTesting SystemMetrics...")
    try:
        from app.monitoring.backend_monitoring import SystemMetrics
        
        metrics = SystemMetrics()
        
        # Test getting system info
        system_info = metrics.get_system_info()
        print(f"System info: {json.dumps(system_info, indent=2, default=str)}")
        
        print("✓ SystemMetrics working")
        return True
    except Exception as e:
        print(f"✗ SystemMetrics error: {e}")
        return False

def simulate_health_responses():
    """Simulate the health endpoint responses."""
    print("\nSimulating comprehensive health endpoint responses...")
    
    endpoints_data = {
        "/api/v1/health/health": {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0.0",
            "environment": "development",
            "message": "Service is running normally"
        },
        "/api/v1/health/ready": {
            "status": "ready",
            "timestamp": datetime.utcnow().isoformat(),
            "dependencies": {
                "database": {"status": "healthy", "latency": "5ms"},
                "redis": {"status": "healthy", "latency": "2ms"},
                "chromadb": {"status": "healthy", "latency": "10ms"},
                "filesystem": {"status": "healthy", "latency": "1ms"}
            },
            "overall": "All dependencies ready"
        },
        "/api/v1/health/live": {
            "status": "alive", 
            "timestamp": datetime.utcnow().isoformat(),
            "uptime": "running",
            "memory_usage": "45MB",
            "cpu_usage": "2%"
        },
        "/api/v1/health/dependencies": {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "dependencies": {
                "database": {
                    "status": "healthy",
                    "latency": 5,
                    "message": "Connected successfully",
                    "version": "PostgreSQL 15.0"
                },
                "redis": {
                    "status": "healthy",
                    "latency": 2,
                    "message": "Connected successfully",
                    "version": "Redis 7.0"
                },
                "chromadb": {
                    "status": "healthy", 
                    "latency": 10,
                    "message": "Connected successfully",
                    "version": "ChromaDB 0.4.18"
                }
            }
        },
        "/api/v1/health/metrics": {
            "status": "metrics_ready",
            "message": "Prometheus metrics available",
            "format": "text/plain",
            "endpoint": "/health/metrics"
        },
        "/api/v1/health/system": {
            "status": "system_info",
            "timestamp": datetime.utcnow().isoformat(),
            "system": {
                "platform": "Linux",
                "python_version": "3.12.5",
                "cpu_count": 4,
                "memory_total": "16.0GB",
                "disk_usage": "45.2%",
                "load_average": [0.1, 0.2, 0.3]
            }
        },
        "/api/v1/health/version": {
            "status": "version_info",
            "version": "1.0.0",
            "build_date": "2025-01-01T00:00:00Z",
            "environment": "development",
            "git_commit": "abc1234"
        },
        "/api/v1/health/config": {
            "status": "config_info",
            "environment": "development",
            "debug": False,
            "database_url": "***REDACTED***",
            "redis_url": "***REDACTED***",
            "openai_api_key": "***REDACTED***"
        }
    }
    
    print("\nSimulated Health Endpoint Responses:")
    print("=" * 50)
    
    for endpoint, response in endpoints_data.items():
        print(f"Endpoint: {endpoint}")
        print(f"Response: {json.dumps(response, indent=2)}")
        print("-" * 50)
    
    return True

def main():
    """Run all tests."""
    print("Health Check System Direct Test")
    print("=" * 50)
    
    tests_passed = 0
    total_tests = 7
    
    # Run tests
    if test_imports():
        tests_passed += 1
    
    if test_health_checker():
        tests_passed += 1
    
    if test_dependency_methods():
        tests_passed += 1
    
    if test_system_metrics():
        tests_passed += 1
    
    if test_health_endpoints_structure():
        tests_passed += 1
    
    if simulate_health_responses():
        tests_passed += 1
    
    print(f"\n{'=' * 50}")
    print(f"Test Results: {tests_passed}/{total_tests} tests passed")
    
    if tests_passed == total_tests:
        print("✓ All tests passed! Health check system is functional.")
        print("\nHealth Check System Features:")
        print("• Basic health check endpoint (/health)")
        print("• Readiness probe (/health/ready)")
        print("• Liveness probe (/health/live)")
        print("• Detailed dependency status (/health/dependencies)")
        print("• Prometheus metrics (/health/metrics)")
        print("• System information (/health/system)")
        print("• Version information (/health/version)")
        print("• Configuration info (/health/config)")
        return 0
    else:
        print("✗ Some tests failed. Check the output above.")
        return 1

if __name__ == "__main__":
    exit(main())