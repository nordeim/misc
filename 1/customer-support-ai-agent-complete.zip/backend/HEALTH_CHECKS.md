# Health Check Endpoints Documentation

## Overview

The Customer Support AI Agent provides comprehensive health check and monitoring endpoints to support container orchestration, load balancing, and system monitoring.

## Available Endpoints

### Basic Health Check
- **Endpoint:** `GET /health`
- **Description:** Basic health check for load balancers
- **Response:**
  ```json
  {
    "status": "healthy|degraded|unhealthy",
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 150.25,
    "version": "1.0.0",
    "environment": "development",
    "checks": {
      "database": {
        "status": "healthy",
        "message": "Database connection successful",
        "duration_ms": 25.5
      }
    }
  }
  ```

### Readiness Probe
- **Endpoint:** `GET /health/ready`
- **Description:** Check if application is ready to receive traffic
- **Response Code:** 200 if ready, 503 if not ready
- **Response:**
  ```json
  {
    "status": "ready|not_ready",
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 250.75,
    "checks": {
      "database": { ... },
      "redis": { ... },
      "chromadb": { ... },
      "openai": { ... },
      "azure_openai": { ... },
      "filesystem": { ... }
    },
    "critical_services": {
      "database": { ... },
      "redis": { ... },
      "filesystem": { ... }
    },
    "summary": {
      "healthy": 6,
      "degraded": 0,
      "unhealthy": 0,
      "unknown": 0
    }
  }
  ```

### Liveness Probe
- **Endpoint:** `GET /health/live`
- **Description:** Simple liveness check for Kubernetes
- **Response Code:** 200 if alive, 503 if dead
- **Response:**
  ```json
  {
    "status": "alive",
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 10.25,
    "process": {
      "pid": 12345,
      "status": "running",
      "create_time": "2023-11-04T04:45:30Z",
      "memory_percent": 45.2,
      "cpu_percent": 12.8
    }
  }
  ```

### Dependency Status
- **Endpoint:** `GET /health/dependencies`
- **Description:** Detailed status of all service dependencies
- **Response:**
  ```json
  {
    "overall_status": "healthy",
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 500.0,
    "total_checks": 6,
    "summary": {
      "healthy": 6,
      "degraded": 0,
      "unhealthy": 0,
      "unknown": 0
    },
    "dependencies": {
      "database": {
        "database": { ... }
      },
      "cache": {
        "redis": { ... }
      },
      "vector_store": {
        "chromadb": { ... }
      },
      "ai_services": {
        "openai": { ... },
        "azure_openai": { ... }
      },
      "storage": {
        "filesystem": { ... }
      }
    }
  }
  ```

### System Metrics
- **Endpoint:** `GET /health/metrics`
- **Description:** System metrics and performance information
- **Response:**
  ```json
  {
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 125.5,
    "system": {
      "cpu_count": 8,
      "cpu_usage_percent": 25.5,
      "memory_total": 16777216000,
      "memory_available": 8388608000,
      "memory_percent": 50.0,
      "disk_total": 500000000000,
      "disk_used": 250000000000,
      "disk_free": 250000000000,
      "disk_percent": 50.0
    },
    "application": {
      "name": "Customer Support AI Agent",
      "version": "1.0.0",
      "environment": "development",
      "uptime_seconds": 3600
    },
    "configuration": {
      "database_type": "sqlite",
      "redis_enabled": true,
      "prometheus_enabled": true,
      "health_checks_enabled": true
    }
  }
  ```

### System Information
- **Endpoint:** `GET /health/system`
- **Description:** Detailed system and process information
- **Response:**
  ```json
  {
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 100.25,
    "system": { ... },
    "process": { ... },
    "platform": { ... },
    "additional": {
      "load_average": [1.5, 1.2, 1.0],
      "network_io": {
        "bytes_sent": 1024000,
        "bytes_recv": 2048000,
        "packets_sent": 1000,
        "packets_recv": 2000
      },
      "disk_io": {
        "read_count": 500,
        "write_count": 300,
        "read_bytes": 10240000,
        "write_bytes": 5120000
      }
    }
  }
  ```

### Version Information
- **Endpoint:** `GET /health/version`
- **Description:** Application version and build information
- **Response:**
  ```json
  {
    "application": {
      "name": "Customer Support AI Agent",
      "version": "1.0.0",
      "environment": "development",
      "debug_mode": true
    },
    "runtime": {
      "process_id": 12345,
      "start_time": "2023-11-04T04:45:30Z",
      "uptime_seconds": 3600
    },
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 5.25
  }
  ```

### Configuration Information
- **Endpoint:** `GET /health/config`
- **Description:** Non-sensitive configuration information
- **Response:**
  ```json
  {
    "application": { ... },
    "server": { ... },
    "database": { ... },
    "redis": { ... },
    "chromadb": { ... },
    "ai": { ... },
    "monitoring": { ... },
    "features": { ... },
    "validation": { ... },
    "timestamp": "2023-11-04T05:01:46Z",
    "response_time_ms": 25.0
  }
  ```

## Prometheus Metrics

### Metrics Endpoint
- **Endpoint:** `GET /metrics`
- **Description:** Prometheus-formatted metrics for monitoring systems

### Available Metrics

#### HTTP Metrics
- `http_requests_total{method,endpoint,status_code}`: Total HTTP requests
- `http_request_duration_seconds{method,endpoint}`: Request duration histogram
- `http_requests_in_progress{method,endpoint}`: Active requests gauge

#### System Metrics
- `cpu_usage_percent`: CPU usage percentage
- `memory_usage_percent`: Memory usage percentage
- `disk_usage_percent`: Disk usage percentage

#### Database Metrics
- `db_connections_active`: Active database connections
- `db_query_duration_seconds{operation}`: Query duration histogram

#### Service Metrics
- `redis_connected`: Redis connection status (0/1)
- `chromadb_connected`: ChromaDB connection status (0/1)
- `llm_requests_total{provider,model,status}`: LLM request counts
- `llm_request_duration_seconds{provider,model}`: LLM request duration

#### Health Check Metrics
- `health_checks_total{check_type,status}`: Health check counts
- `health_check_duration_seconds{check_type}`: Health check duration

## Health Status Levels

- **HEALTHY** (✅): Service is functioning normally
- **DEGRADED** (⚠️): Service is functioning but with limitations
- **UNHEALTHY** (❌): Service is not functioning correctly
- **UNKNOWN** (❓): Service status cannot be determined

## Monitoring Integration

### Kubernetes Health Checks

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: customer-support-agent
spec:
  containers:
  - name: agent
    image: customer-support-agent:latest
    livenessProbe:
      httpGet:
        path: /health/live
        port: 8000
      initialDelaySeconds: 30
      periodSeconds: 10
    readinessProbe:
      httpGet:
        path: /health/ready
        port: 8000
      initialDelaySeconds: 5
      periodSeconds: 5
```

### Docker Health Check

```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:8000/health/ready || exit 1
```

### Load Balancer Configuration

```nginx
upstream backend {
    server 127.0.0.1:8000;
}

server {
    location /health {
        proxy_pass http://backend/health;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Monitoring Best Practices

1. **Use appropriate endpoints:**
   - Liveness probe for Kubernetes liveness checks
   - Readiness probe for Kubernetes readiness checks
   - Basic health for load balancer health checks

2. **Monitor response times:**
   - All health endpoints include response time metrics
   - Set alerts for slow response times (> 1 second)

3. **Track dependency health:**
   - Use `/health/dependencies` for detailed monitoring
   - Set up alerts for unhealthy dependencies

4. **Prometheus integration:**
   - Scrape `/metrics` endpoint for metrics collection
   - Set up Grafana dashboards for visualization

5. **Log monitoring:**
   - Health checks are logged with structured logging
   - Monitor logs for health check failures

## Testing Health Checks

Use the provided test script:

```bash
cd backend
python test_health_checks.py
```

This will test all health check functionality and report results.