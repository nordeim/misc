"""
Test script for comprehensive streaming functionality.

This script tests:
1. Server-Sent Events (SSE) streaming
2. Chat response streaming
3. Agent response streaming
4. Progress tracking
5. Stream management
6. Performance monitoring
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime


class StreamingTester:
    """Comprehensive streaming functionality tester."""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = None
        self.test_results = {}
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()
    
    async def test_sse_connection(self, session_id: str = "test_session_sse"):
        """Test SSE connection endpoint."""
        print(f"\n🔌 Testing SSE connection...")
        
        try:
            url = f"{self.base_url}/api/v1/streaming/sse/{session_id}?stream_type=chat"
            
            # Test with headers that support SSE
            headers = {
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive"
            }
            
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    print(f"✅ SSE connection established successfully")
                    
                    # Read some SSE events
                    events_received = 0
                    async for line in response.content:
                        if line:
                            line = line.decode('utf-8').strip()
                            if line.startswith('data: '):
                                events_received += 1
                                if events_received <= 3:  # Show first 3 events
                                    print(f"   📨 Received event {events_received}: {line[:100]}...")
                                
                                if events_received >= 5:  # Stop after 5 events
                                    break
                    
                    print(f"✅ Received {events_received} SSE events")
                    self.test_results["sse_connection"] = {"status": "passed", "events": events_received}
                else:
                    print(f"❌ SSE connection failed with status {response.status}")
                    self.test_results["sse_connection"] = {"status": "failed", "error": response.status}
        
        except Exception as e:
            print(f"❌ SSE connection error: {str(e)}")
            self.test_results["sse_connection"] = {"status": "failed", "error": str(e)}
    
    async def test_chat_streaming(self, session_id: str = "test_chat_stream"):
        """Test chat response streaming."""
        print(f"\n💬 Testing chat streaming...")
        
        try:
            # Start chat stream
            start_url = f"{self.base_url}/api/v1/streaming/chat/start"
            start_data = {
                "session_id": session_id,
                "message": "Hello, can you help me with my question?",
                "stream_type": "chat",
                "enable_token_streaming": True
            }
            
            async with self.session.post(start_url, json=start_data) as response:
                if response.status == 200:
                    result = await response.json()
                    print(f"✅ Chat stream started: {result}")
                    
                    # Stream response
                    stream_url = f"{self.base_url}/api/v1/streaming/chat/stream/{session_id}"
                    stream_data = start_data.copy()
                    
                    async with self.session.post(stream_url, json=stream_data) as stream_response:
                        if stream_response.status == 200:
                            stream_result = await stream_response.json()
                            print(f"✅ Chat streaming initiated: {stream_result}")
                            
                            # Wait a bit for streaming to complete
                            await asyncio.sleep(5)
                            
                            self.test_results["chat_streaming"] = {
                                "status": "passed",
                                "start_result": result,
                                "stream_result": stream_result
                            }
                        else:
                            print(f"❌ Chat streaming failed: {stream_response.status}")
                            self.test_results["chat_streaming"] = {"status": "failed", "error": stream_response.status}
                else:
                    print(f"❌ Chat stream start failed: {response.status}")
                    self.test_results["chat_streaming"] = {"status": "failed", "error": response.status}
        
        except Exception as e:
            print(f"❌ Chat streaming error: {str(e)}")
            self.test_results["chat_streaming"] = {"status": "failed", "error": str(e)}
    
    async def test_agent_streaming(self, session_id: str = "test_agent_stream"):
        """Test agent response streaming."""
        print(f"\n🤖 Testing agent streaming...")
        
        try:
            # Start agent stream
            start_url = f"{self.base_url}/api/v1/streaming/agent/start"
            start_data = {
                "session_id": session_id,
                "message": "Process this request with the agent",
                "stream_type": "agent",
                "enable_token_streaming": True
            }
            
            async with self.session.post(start_url, json=start_data) as response:
                if response.status == 200:
                    result = await response.json()
                    print(f"✅ Agent stream started: {result}")
                    
                    # Stream agent response
                    stream_url = f"{self.base_url}/api/v1/streaming/agent/stream/{session_id}"
                    stream_data = start_data.copy()
                    
                    async with self.session.post(stream_url, json=stream_data) as stream_response:
                        if stream_response.status == 200:
                            stream_result = await stream_response.json()
                            print(f"✅ Agent streaming initiated: {stream_result}")
                            
                            # Wait for streaming to complete
                            await asyncio.sleep(5)
                            
                            self.test_results["agent_streaming"] = {
                                "status": "passed",
                                "start_result": result,
                                "stream_result": stream_result
                            }
                        else:
                            print(f"❌ Agent streaming failed: {stream_response.status}")
                            self.test_results["agent_streaming"] = {"status": "failed", "error": stream_response.status}
                else:
                    print(f"❌ Agent stream start failed: {response.status}")
                    self.test_results["agent_streaming"] = {"status": "failed", "error": response.status}
        
        except Exception as e:
            print(f"❌ Agent streaming error: {str(e)}")
            self.test_results["agent_streaming"] = {"status": "failed", "error": str(e)}
    
    async def test_progress_tracking(self, session_id: str = "test_progress"):
        """Test progress tracking functionality."""
        print(f"\n📊 Testing progress tracking...")
        
        try:
            # Start progress tracking
            progress_url = f"{self.base_url}/api/v1/streaming/progress/start"
            progress_data = {
                "session_id": session_id,
                "operation_id": "test_operation",
                "current_step": "Starting operation",
                "total_steps": 5,
                "progress_percentage": 0.0
            }
            
            async with self.session.post(progress_url, json=progress_data) as response:
                if response.status == 200:
                    result = await response.json()
                    print(f"✅ Progress tracking started: {result}")
                    
                    # Send progress updates
                    for i in range(1, 6):
                        progress_data["current_step"] = f"Step {i} completed"
                        progress_data["progress_percentage"] = (i / 5) * 100
                        
                        update_url = f"{self.base_url}/api/v1/streaming/progress/update"
                        async with self.session.post(update_url, json=progress_data) as update_response:
                            if update_response.status == 200:
                                update_result = await update_response.json()
                                print(f"   📈 Progress update {i}: {update_result['progress_percentage']}%")
                            else:
                                print(f"   ❌ Progress update {i} failed: {update_response.status}")
                        
                        await asyncio.sleep(1)  # Delay between updates
                    
                    # Complete progress
                    complete_url = f"{self.base_url}/api/v1/streaming/progress/complete"
                    complete_params = f"session_id={session_id}&operation_id=test_operation"
                    async with self.session.post(f"{complete_url}?{complete_params}") as complete_response:
                        if complete_response.status == 200:
                            complete_result = await complete_response.json()
                            print(f"✅ Progress tracking completed: {complete_result}")
                        
                    self.test_results["progress_tracking"] = {"status": "passed"}
                else:
                    print(f"❌ Progress tracking start failed: {response.status}")
                    self.test_results["progress_tracking"] = {"status": "failed", "error": response.status}
        
        except Exception as e:
            print(f"❌ Progress tracking error: {str(e)}")
            self.test_results["progress_tracking"] = {"status": "failed", "error": str(e)}
    
    async def test_stream_management(self):
        """Test stream management endpoints."""
        print(f"\n📋 Testing stream management...")
        
        try:
            # List active streams
            list_url = f"{self.base_url}/api/v1/streaming/streams"
            async with self.session.get(list_url) as response:
                if response.status == 200:
                    streams_result = await response.json()
                    print(f"✅ Active streams retrieved: {streams_result['active_streams']} streams")
                    
                    # Get stream details if any exist
                    if streams_result["streams"]:
                        first_stream = streams_result["streams"][0]
                        session_id = first_stream["session_id"]
                        
                        detail_url = f"{self.base_url}/api/v1/streaming/streams/{session_id}"
                        async with self.session.get(detail_url) as detail_response:
                            if detail_response.status == 200:
                                detail_result = await detail_response.json()
                                print(f"✅ Stream details retrieved for {session_id}")
                            else:
                                print(f"❌ Stream details failed: {detail_response.status}")
                    
                    self.test_results["stream_management"] = {"status": "passed", "active_streams": streams_result["active_streams"]}
                else:
                    print(f"❌ Stream management failed: {response.status}")
                    self.test_results["stream_management"] = {"status": "failed", "error": response.status}
        
        except Exception as e:
            print(f"❌ Stream management error: {str(e)}")
            self.test_results["stream_management"] = {"status": "failed", "error": str(e)}
    
    async def test_monitoring_analytics(self):
        """Test monitoring and analytics endpoints."""
        print(f"\n📈 Testing monitoring and analytics...")
        
        try:
            # Performance metrics
            perf_url = f"{self.base_url}/api/v1/streaming/monitoring/performance"
            async with self.session.get(perf_url) as response:
                if response.status == 200:
                    perf_result = await response.json()
                    print(f"✅ Performance metrics retrieved")
                    print(f"   📊 Health status: {perf_result.get('health_status', 'unknown')}")
                    
            # Analytics
            analytics_url = f"{self.base_url}/api/v1/streaming/monitoring/analytics"
            async with self.session.get(analytics_url) as response:
                if response.status == 200:
                    analytics_result = await response.json()
                    print(f"✅ Analytics data retrieved")
                    print(f"   📊 Total sessions: {analytics_result.get('analytics', {}).get('total_sessions', 0)}")
            
            # Health check
            health_url = f"{self.base_url}/api/v1/streaming/monitoring/health"
            async with self.session.get(health_url) as response:
                if response.status == 200:
                    health_result = await response.json()
                    print(f"✅ Streaming health check passed")
                    print(f"   🏥 Overall status: {health_result.get('overall_status', 'unknown')}")
            
            self.test_results["monitoring_analytics"] = {"status": "passed"}
        
        except Exception as e:
            print(f"❌ Monitoring and analytics error: {str(e)}")
            self.test_results["monitoring_analytics"] = {"status": "failed", "error": str(e)}
    
    async def run_comprehensive_test(self):
        """Run all streaming tests."""
        print(f"🚀 Starting comprehensive streaming functionality test...")
        print(f"📍 Base URL: {self.base_url}")
        print(f"⏰ Start time: {datetime.now().isoformat()}")
        
        start_time = time.time()
        
        # Test basic health
        try:
            health_url = f"{self.base_url}/health"
            async with self.session.get(health_url) as response:
                if response.status == 200:
                    print(f"✅ Application health check passed")
                else:
                    print(f"❌ Application health check failed: {response.status}")
                    return
        except Exception as e:
            print(f"❌ Cannot connect to application: {str(e)}")
            return
        
        # Run all tests
        await self.test_sse_connection()
        await self.test_chat_streaming()
        await self.test_agent_streaming()
        await self.test_progress_tracking()
        await self.test_stream_management()
        await self.test_monitoring_analytics()
        
        # Summary
        end_time = time.time()
        total_time = end_time - start_time
        
        print(f"\n" + "="*60)
        print(f"📋 STREAMING TEST SUMMARY")
        print(f"="*60)
        print(f"⏱️  Total test time: {total_time:.2f} seconds")
        print(f"📊 Tests run: {len(self.test_results)}")
        
        passed_tests = sum(1 for result in self.test_results.values() if result.get("status") == "passed")
        failed_tests = len(self.test_results) - passed_tests
        
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"📈 Success rate: {(passed_tests/len(self.test_results)*100):.1f}%")
        
        print(f"\n📋 Detailed Results:")
        for test_name, result in self.test_results.items():
            status_emoji = "✅" if result.get("status") == "passed" else "❌"
            print(f"   {status_emoji} {test_name.replace('_', ' ').title()}: {result.get('status', 'unknown')}")
        
        print(f"\n🎯 Test completed at: {datetime.now().isoformat()}")
        
        return self.test_results


async def main():
    """Main test function."""
    base_url = "http://localhost:8000"  # Change this if your app runs on different port
    
    async with StreamingTester(base_url) as tester:
        results = await tester.run_comprehensive_test()
        
        # Save results to file
        with open("streaming_test_results.json", "w") as f:
            json.dump(results, f, indent=2, default=str)
        
        print(f"\n💾 Test results saved to: streaming_test_results.json")


if __name__ == "__main__":
    print("🎯 Streaming Functionality Test Suite")
    print("=" * 50)
    print("This test suite validates the comprehensive streaming system including:")
    print("• Server-Sent Events (SSE) streaming")
    print("• Chat response token-by-token streaming")
    print("• Agent response streaming")
    print("• Progress tracking for long operations")
    print("• Stream management and monitoring")
    print("• Performance analytics")
    print()
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")
    except Exception as e:
        print(f"\n💥 Test failed with error: {str(e)}")