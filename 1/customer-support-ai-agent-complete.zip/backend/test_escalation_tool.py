#!/usr/bin/env python3
"""
Test script for the Enhanced Escalation Tool.

This script demonstrates the key functionality of the escalation tool
including escalation decisions, queue management, and analytics.
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, Any
import json

# Add backend to path for imports
sys.path.append('/workspace/backend')

from app.tools.escalation_tool import EscalationTool
from app.agents.chat_agent import AgentContext
from app.models.escalation_schemas import EscalationContext, EscalationPriority, EscalationReason

async def test_basic_escalation_decision():
    """Test basic escalation decision functionality."""
    print("=" * 60)
    print("Testing Basic Escalation Decision")
    print("=" * 60)
    
    # Create escalation tool without database session for basic testing
    escalation_tool = EscalationTool()
    
    # Test case 1: Frustrated customer
    print("\n1. Testing frustrated customer scenario...")
    context = AgentContext(
        session_id="test_session_1",
        user_id="test_user_1",
        message_history=[
            {"role": "user", "content": "Hello, I need help with my account"},
            {"role": "assistant", "content": "I'd be happy to help you with your account."},
            {"role": "user", "content": "This is terrible service! I've been waiting for hours!"}
        ],
        current_file_attachments=[]
    )
    
    decision = await escalation_tool.get_escalation_decision(
        message="This is terrible service! I've been waiting for hours!",
        context=context,
        rag_results={"confidence": 0.7}
    )
    
    print(f"  Should escalate: {decision.should_escalate}")
    print(f"  Priority: {decision.priority_level}")
    print(f"  Confidence: {decision.confidence_score:.2f}")
    print(f"  Escalation score: {decision.escalation_score:.2f}")
    print(f"  Reasons: {[r.value for r in decision.reasons]}")
    print(f"  Alternative actions: {decision.alternative_actions}")
    
    # Test case 2: Technical issue
    print("\n2. Testing complex technical issue...")
    context2 = AgentContext(
        session_id="test_session_2",
        user_id="test_user_2",
        message_history=[
            {"role": "user", "content": "I'm having API integration issues"},
            {"role": "assistant", "content": "I can help with API integration issues."},
            {"role": "user", "content": "The webhook is failing and our database connections are timing out"}
        ],
        current_file_attachments=[]
    )
    
    decision2 = await escalation_tool.get_escalation_decision(
        message="The webhook is failing and our database connections are timing out. This is affecting our production system.",
        context=context2,
        rag_results={"confidence": 0.5}
    )
    
    print(f"  Should escalate: {decision2.should_escalate}")
    print(f"  Priority: {decision2.priority_level}")
    print(f"  Confidence: {decision2.confidence_score:.2f}")
    print(f"  Escalation score: {decision2.escalation_score:.2f}")
    print(f"  Reasons: {[r.value for r in decision2.reasons]}")
    print(f"  Complexity level: {decision2.complexity_assessment['complexity_level']}")
    
    # Test case 3: Billing issue
    print("\n3. Testing billing dispute...")
    context3 = AgentContext(
        session_id="test_session_3",
        user_id="test_user_3",
        message_history=[
            {"role": "user", "content": "I need to dispute a charge"},
            {"role": "assistant", "content": "I can help you with billing disputes."},
            {"role": "user", "content": "There was an unauthorized charge on my credit card for $200"}
        ],
        current_file_attachments=[]
    )
    
    decision3 = await escalation_tool.get_escalation_decision(
        message="There was an unauthorized charge on my credit card for $200. I want a refund immediately!",
        context=context3,
        rag_results={"confidence": 0.6}
    )
    
    print(f"  Should escalate: {decision3.should_escalate}")
    print(f"  Priority: {decision3.priority_level}")
    print(f"  Confidence: {decision3.confidence_score:.2f}")
    print(f"  Escalation score: {decision3.escalation_score:.2f}")
    print(f"  Reasons: {[r.value for r in decision3.reasons]}")
    
    # Test case 4: Normal conversation (no escalation needed)
    print("\n4. Testing normal conversation...")
    context4 = AgentContext(
        session_id="test_session_4",
        user_id="test_user_4",
        message_history=[
            {"role": "user", "content": "What are your business hours?"},
            {"role": "assistant", "content": "Our business hours are 9 AM to 5 PM EST, Monday through Friday."}
        ],
        current_file_attachments=[]
    )
    
    decision4 = await escalation_tool.get_escalation_decision(
        message="Thank you for the information. That answers my question.",
        context=context4,
        rag_results={"confidence": 0.9}
    )
    
    print(f"  Should escalate: {decision4.should_escalate}")
    print(f"  Priority: {decision4.priority_level}")
    print(f"  Confidence: {decision4.confidence_score:.2f}")
    print(f"  Escalation score: {decision4.escalation_score:.2f}")


async def test_legacy_compatibility():
    """Test backward compatibility with legacy methods."""
    print("\n" + "=" * 60)
    print("Testing Legacy Compatibility")
    print("=" * 60)
    
    escalation_tool = EscalationTool()
    
    context = AgentContext(
        session_id="legacy_test_session",
        user_id="legacy_test_user",
        message_history=[
            {"role": "user", "content": "I want to speak to a manager immediately!"}
        ],
        current_file_attachments=[]
    )
    
    # Test legacy method
    should_escalate = await escalation_tool.check_escalation(
        message="I want to speak to a manager immediately!",
        context=context,
        rag_results={"confidence": 0.8}
    )
    
    print(f"Legacy check_escalate result: {should_escalate}")
    
    # Test legacy with reasons
    result = await escalation_tool.should_escalate_with_reason(
        message="I want to speak to a manager immediately!",
        context=context,
        rag_results={"confidence": 0.8}
    )
    
    print("Legacy should_escalate_with_reason result:")
    print(json.dumps(result, indent=2, default=str))


async def test_sentiment_analysis():
    """Test sentiment analysis functionality."""
    print("\n" + "=" * 60)
    print("Testing Sentiment Analysis")
    print("=" * 60)
    
    escalation_tool = EscalationTool()
    
    test_messages = [
        "Hello, I need some help please.",
        "This is really frustrating!",
        "I'm angry about this terrible service!",
        "URGENT!!! I need help RIGHT NOW!!!",
        "Thank you for your help, this solved my problem.",
        "The system is broken and nothing works properly!!!"
    ]
    
    for i, message in enumerate(test_messages, 1):
        sentiment_score = escalation_tool._analyze_sentiment(message)
        keyword_score = asyncio.run(escalation_tool._analyze_enhanced_keywords(message))
        
        print(f"{i}. Message: '{message}'")
        print(f"   Sentiment score: {sentiment_score:.2f}")
        print(f"   Keyword score: {keyword_score:.2f}")
        print()


async def test_keyword_analysis():
    """Test keyword analysis by categories."""
    print("\n" + "=" * 60)
    print("Testing Keyword Analysis")
    print("=" * 60)
    
    escalation_tool = EscalationTool()
    
    test_cases = [
        {
            "name": "Frustration",
            "message": "I'm so frustrated with this broken system. This is terrible!",
            "expected_categories": ["frustration", "service_quality"]
        },
        {
            "name": "Urgency",
            "message": "This is urgent and critical! I need help immediately!",
            "expected_categories": ["urgency"]
        },
        {
            "name": "Escalation Request",
            "message": "I want to speak to a manager or supervisor right now.",
            "expected_categories": ["escalation_request"]
        },
        {
            "name": "Technical",
            "message": "There's a bug in the API integration and the database is down.",
            "expected_categories": ["technical_complex"]
        },
        {
            "name": "Financial",
            "message": "I want a refund for this unauthorized charge on my credit card.",
            "expected_categories": ["financial_legal"]
        },
        {
            "name": "Compliance",
            "message": "This violates GDPR privacy policy and terms of service.",
            "expected_categories": ["compliance"]
        }
    ]
    
    for test_case in test_cases:
        message = test_case["message"]
        expected = test_case["expected_categories"]
        
        # Count keyword matches by category
        message_lower = message.lower()
        matched_categories = []
        
        for category, keywords in escalation_tool.escalation_keywords.items():
            if any(keyword in message_lower for keyword in keywords):
                matched_categories.append(category)
        
        keyword_score = asyncio.run(escalation_tool._analyze_enhanced_keywords(message))
        
        print(f"Test: {test_case['name']}")
        print(f"  Message: '{message}'")
        print(f"  Expected categories: {expected}")
        print(f"  Matched categories: {matched_categories}")
        print(f"  Keyword score: {keyword_score:.2f}")
        print(f"  Match: {'✓' if set(matched_categories) == set(expected) else '✗'}")
        print()


async def test_conversation_analysis():
    """Test conversation length and context analysis."""
    print("\n" + "=" * 60)
    print("Testing Conversation Analysis")
    print("=" * 60)
    
    escalation_tool = EscalationTool()
    
    # Test different conversation lengths
    conversation_scenarios = [
        {"name": "Short conversation", "turns": 3},
        {"name": "Medium conversation", "turns": 12},
        {"name": "Long conversation", "turns": 18},
        {"name": "Very long conversation", "turns": 30}
    ]
    
    for scenario in conversation_scenarios:
        # Create context with different conversation lengths
        message_history = [
            {"role": "user", "content": f"Message {i//2 + 1}"}
            for i in range(scenario["turns"])
        ]
        
        context = AgentContext(
            session_id=f"conv_test_{scenario['turns']}",
            user_id="conv_test_user",
            message_history=message_history,
            current_file_attachments=[]
        )
        
        conversation_score = escalation_tool._analyze_conversation_length_score(
            scenario["turns"]
        )
        
        print(f"{scenario['name']} ({scenario['turns']} turns):")
        print(f"  Conversation length score: {conversation_score:.2f}")
        
        # Test escalation decision
        decision = asyncio.run(escalation_tool.get_escalation_decision(
            message="This conversation is taking too long, I need help now!",
            context=context,
            rag_results={"confidence": 0.8}
        ))
        
        print(f"  Should escalate: {decision.should_escalate}")
        print(f"  Escalation score: {decision.escalation_score:.2f}")
        print()


async def test_complexity_assessment():
    """Test issue complexity assessment."""
    print("\n" + "=" * 60)
    print("Testing Complexity Assessment")
    print("=" * 60)
    
    escalation_tool = EscalationTool()
    
    complexity_scenarios = [
        {
            "name": "Simple question",
            "message": "What are your business hours?",
            "context": {"technical_complexity": 0.1, "business_impact": 0.1, "compliance_risk": 0.0}
        },
        {
            "name": "Technical integration",
            "message": "I need help integrating your API with our custom database schema and webhooks.",
            "context": {"technical_complexity": 0.8, "business_impact": 0.6, "compliance_risk": 0.2}
        },
        {
            "name": "Enterprise issue",
            "message": "Our production system is down and this is affecting our revenue. We need immediate support.",
            "context": {"technical_complexity": 0.7, "business_impact": 0.9, "compliance_risk": 0.3}
        },
        {
            "name": "Legal compliance",
            "message": "We need to discuss GDPR compliance and data protection requirements for our contract.",
            "context": {"technical_complexity": 0.3, "business_impact": 0.7, "compliance_risk": 0.9}
        }
    ]
    
    for scenario in complexity_scenarios:
        # Create escalation context manually for testing
        escalation_context = EscalationContext(
            message=scenario["message"],
            conversation_length=5,
            user_sentiment=0.5,
            rag_confidence=0.7,
            technical_complexity=scenario["context"]["technical_complexity"],
            business_impact=scenario["context"]["business_impact"],
            compliance_risk=scenario["context"]["compliance_risk"],
            previous_escalations=0,
            time_since_last_response=0.0,
            customer_tier=None
        )
        
        complexity_assessment = await escalation_tool._assess_complexity(escalation_context)
        
        print(f"{scenario['name']}:")
        print(f"  Message: '{scenario['message']}'")
        print(f"  Complexity level: {complexity_assessment['complexity_level']}")
        print(f"  Complexity score: {complexity_assessment['complexity_score']:.2f}")
        print(f"  Estimated resolution time: {complexity_assessment['estimated_resolution_time']}")
        print(f"  Factors: {complexity_assessment['factors']}")
        print()


async def main():
    """Run all tests."""
    print("Enhanced Escalation Tool Test Suite")
    print("=" * 60)
    
    try:
        await test_basic_escalation_decision()
        await test_legacy_compatibility()
        await test_sentiment_analysis()
        await test_keyword_analysis()
        await test_conversation_analysis()
        await test_complexity_assessment()
        
        print("\n" + "=" * 60)
        print("All tests completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nError during testing: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())