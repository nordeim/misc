#!/usr/bin/env python3
"""
Test script for health check endpoints.

This script tests the health check functionality by importing
the monitoring modules and running sample health checks.
"""

import asyncio
import sys
import os

# Add the backend directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from app.monitoring import (
    run_health_checks,
    get_health_summary,
    init_monitoring,
    shutdown_monitoring,
    HealthStatus
)

async def test_health_checks():
    """Test health check functionality."""
    print("🧪 Testing Health Check System")
    print("=" * 50)
    
    try:
        # Initialize monitoring
        print("📊 Initializing monitoring system...")
        init_monitoring()
        print("✅ Monitoring system initialized")
        
        print("\n🔍 Running health checks...")
        
        # Run individual health checks
        checks = await run_health_checks()
        
        print(f"\n📋 Health Check Results:")
        print("-" * 30)
        
        for service_name, result in checks.items():
            status_emoji = {
                HealthStatus.HEALTHY: "✅",
                HealthStatus.DEGRADED: "⚠️",
                HealthStatus.UNHEALTHY: "❌",
                HealthStatus.UNKNOWN: "❓"
            }.get(result.status, "❓")
            
            print(f"{status_emoji} {service_name.upper()}: {result.status.value}")
            print(f"   Message: {result.message}")
            if result.duration_ms:
                print(f"   Duration: {result.duration_ms:.2f}ms")
            print()
        
        # Get summary
        print("📊 Health Summary:")
        print("-" * 20)
        summary = get_health_summary(checks)
        print(f"Overall Status: {summary['overall_status']}")
        print(f"Total Checks: {summary['total_checks']}")
        
        for status, count in summary['summary'].items():
            if count > 0:
                print(f"{status.title()}: {count}")
        
        print("\n🎯 Health Check Test Completed Successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Health Check Test Failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        print("\n🧹 Shutting down monitoring system...")
        shutdown_monitoring()
        print("✅ Monitoring system shutdown complete")

async def test_specific_checks():
    """Test specific health checks."""
    print("\n🎯 Testing Specific Health Checks")
    print("=" * 50)
    
    try:
        init_monitoring()
        
        # Test database check
        print("🗄️ Testing Database Health Check...")
        db_checks = await run_health_checks(["database"])
        db_result = db_checks["database"]
        print(f"Database Status: {db_result.status.value}")
        print(f"Database Message: {db_result.message}")
        
        # Test Redis check
        print("\n🔴 Testing Redis Health Check...")
        redis_checks = await run_health_checks(["redis"])
        redis_result = redis_checks["redis"]
        print(f"Redis Status: {redis_result.status.value}")
        print(f"Redis Message: {redis_result.message}")
        
        # Test file system check
        print("\n📁 Testing File System Health Check...")
        fs_checks = await run_health_checks(["filesystem"])
        fs_result = fs_checks["filesystem"]
        print(f"File System Status: {fs_result.status.value}")
        print(f"File System Message: {fs_result.message}")
        
        print("\n✅ Specific Health Check Tests Completed!")
        
    except Exception as e:
        print(f"\n❌ Specific Health Check Tests Failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        shutdown_monitoring()

def main():
    """Main test function."""
    print("🚀 Starting Health Check System Tests\n")
    
    async def run_tests():
        success = await test_health_checks()
        await test_specific_checks()
        return success
    
    # Run async tests
    try:
        success = asyncio.run(run_tests())
        if success:
            print("\n🎉 All tests passed! Health check system is working correctly.")
            sys.exit(0)
        else:
            print("\n💥 Some tests failed. Check the output above for details.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⏹️ Tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()