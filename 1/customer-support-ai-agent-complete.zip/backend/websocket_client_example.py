#!/usr/bin/env python3
"""
WebSocket Client Integration Example

This example demonstrates how to integrate with the WebSocket system
for real-time chat communication with the Customer Support AI Agent.

Features demonstrated:
- WebSocket connection and authentication
- Real-time chat messaging
- Room management
- Typing indicators
- Error handling
- Reconnection logic
"""

import asyncio
import json
import logging
import websockets
from datetime import datetime
from typing import Optional, Dict, Any, Callable

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ChatClient:
    """WebSocket chat client for Customer Support AI Agent."""
    
    def __init__(self, base_url: str = "ws://localhost:8000"):
        self.base_url = base_url
        self.websocket: Optional[websockets.WebSocketServerProtocol] = None
        self.client_id = f"client_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.session_id = None
        self.auth_token = None
        self.is_connected = False
        self.current_room = None
        self.message_handlers: Dict[str, Callable] = {}
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        
    def set_authentication(self, auth_token: str):
        """Set JWT authentication token."""
        self.auth_token = auth_token
        
    def set_session_id(self, session_id: str):
        """Set session identifier."""
        self.session_id = session_id or self.client_id
        
    def register_message_handler(self, message_type: str, handler: Callable):
        """Register a handler for specific message types."""
        self.message_handlers[message_type] = handler
        
    async def connect(self) -> bool:
        """Connect to the WebSocket server."""
        try:
            # Prepare connection headers
            extra_headers = {}
            if self.auth_token:
                extra_headers["Authorization"] = f"Bearer {self.auth_token}"
                
            # Connect to WebSocket
            uri = f"{self.base_url}/ws"
            self.websocket = await websockets.connect(uri, extra_headers=extra_headers)
            self.is_connected = True
            self.reconnect_attempts = 0
            
            logger.info(f"Connected to {uri}")
            
            # Send connection data
            connection_data = {
                "client_id": self.client_id,
                "session_id": self.session_id or self.client_id,
                "rooms": [self.current_room] if self.current_room else []
            }
            
            await self.send_message("connection", connection_data)
            
            # Start message listening
            asyncio.create_task(self._message_listener())
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect: {str(e)}")
            return False
    
    async def disconnect(self):
        """Disconnect from the WebSocket server."""
        if self.websocket:
            await self.websocket.close()
            self.websocket = None
            self.is_connected = False
            logger.info("Disconnected from server")
    
    async def send_message(self, message_type: str, data: Dict[str, Any]):
        """Send a message to the server."""
        if not self.websocket:
            logger.error("Not connected to server")
            return
            
        message = {
            "type": message_type,
            **data
        }
        
        try:
            await self.websocket.send(json.dumps(message))
            logger.debug(f"Sent message: {message_type}")
            
        except Exception as e:
            logger.error(f"Failed to send message: {str(e)}")
            await self.disconnect()
    
    async def send_chat_message(self, content: str, room: Optional[str] = None):
        """Send a chat message."""
        if not content.strip():
            logger.warning("Cannot send empty message")
            return
            
        data = {
            "content": content,
            "session_id": self.session_id or self.client_id
        }
        
        if room:
            data["room"] = room
            
        await self.send_message("chat_message", data)
    
    async def join_room(self, room: str):
        """Join a chat room."""
        self.current_room = room
        await self.send_message("join_room", {"room": room})
        
    async def leave_room(self, room: str):
        """Leave a chat room."""
        if self.current_room == room:
            self.current_room = None
        await self.send_message("leave_room", {"room": room})
        
    async def send_typing_indicator(self, is_typing: bool):
        """Send typing indicator."""
        await self.send_message("typing_indicator", {
            "is_typing": is_typing,
            "session_id": self.session_id or self.client_id
        })
    
    async def send_ping(self):
        """Send ping to check connection."""
        await self.send_message("ping", {})
    
    async def _message_listener(self):
        """Listen for incoming messages."""
        try:
            while self.is_connected and self.websocket:
                # Receive message with timeout
                try:
                    message = await asyncio.wait_for(
                        self.websocket.recv(), 
                        timeout=30.0
                    )
                    
                    data = json.loads(message)
                    await self._handle_message(data)
                    
                except asyncio.TimeoutError:
                    # Send ping to check connection
                    await self.send_ping()
                    continue
                    
                except json.JSONDecodeError:
                    logger.error("Invalid JSON message received")
                    continue
                    
        except websockets.exceptions.ConnectionClosed:
            logger.info("Connection closed")
            self.is_connected = False
            
            # Attempt reconnection
            if self.reconnect_attempts < self.max_reconnect_attempts:
                await self._reconnect()
                
        except Exception as e:
            logger.error(f"Message listener error: {str(e)}")
            self.is_connected = False
    
    async def _handle_message(self, data: Dict[str, Any]):
        """Handle incoming messages."""
        message_type = data.get("type")
        
        # Call registered handler if available
        if message_type in self.message_handlers:
            try:
                await self.message_handlers[message_type](data)
            except Exception as e:
                logger.error(f"Handler error for {message_type}: {str(e)}")
            return
        
        # Default message handlers
        if message_type == "connection":
            await self._handle_connection_response(data)
        elif message_type == "chat_response":
            await self._handle_chat_response(data)
        elif message_type == "typing_indicator":
            await self._handle_typing_indicator(data)
        elif message_type == "error":
            await self._handle_error(data)
        elif message_type == "pong":
            logger.debug("Received pong")
        elif message_type == "heartbeat":
            logger.debug("Received heartbeat")
        else:
            logger.info(f"Received unhandled message type: {message_type}")
    
    async def _handle_connection_response(self, data: Dict[str, Any]):
        """Handle connection response."""
        if data.get("status") == "connected":
            logger.info("Successfully connected to chat server")
        else:
            logger.warning(f"Connection failed: {data}")
    
    async def _handle_chat_response(self, data: Dict[str, Any]):
        """Handle chat response from agent."""
        response_data = data.get("response", {})
        content = response_data.get("content", "")
        processing_time = response_data.get("processing_time", 0)
        
        logger.info(f"Agent response ({processing_time:.3f}s): {content}")
        
        # You can implement UI updates here
        # For example: update_chat_display(content, response_data)
    
    async def _handle_typing_indicator(self, data: Dict[str, Any]):
        """Handle typing indicator from other users."""
        client_id = data.get("client_id", "unknown")
        is_typing = data.get("is_typing", False)
        
        if is_typing:
            logger.info(f"{client_id} is typing...")
        else:
            logger.info(f"{client_id} stopped typing")
    
    async def _handle_error(self, data: Dict[str, Any]):
        """Handle error messages."""
        error_code = data.get("error_code", "UNKNOWN_ERROR")
        message = data.get("message", "Unknown error")
        
        logger.error(f"Server error ({error_code}): {message}")
    
    async def _reconnect(self):
        """Attempt to reconnect to the server."""
        self.reconnect_attempts += 1
        delay = min(2 ** self.reconnect_attempts, 30)  # Exponential backoff
        
        logger.info(f"Attempting to reconnect in {delay} seconds... ({self.reconnect_attempts}/{self.max_reconnect_attempts})")
        
        await asyncio.sleep(delay)
        
        if await self.connect():
            logger.info("Successfully reconnected")
        else:
            logger.error(f"Reconnection attempt {self.reconnect_attempts} failed")

# Example usage and demonstration
async def example_basic_chat():
    """Example of basic chat functionality."""
    logger.info("Starting basic chat example...")
    
    client = ChatClient()
    client.set_session_id("example_session")
    
    # Register message handlers
    def on_chat_response(data):
        response = data.get("response", {})
        print(f"Agent: {response.get('content', 'No content')}")
    
    client.register_message_handler("chat_response", on_chat_response)
    
    # Connect
    if await client.connect():
        # Wait for connection
        await asyncio.sleep(1)
        
        # Send a chat message
        await client.send_chat_message("Hello! I need help with my account.")
        
        # Wait for response
        await asyncio.sleep(5)
        
        # Send another message
        await client.send_chat_message("Can you help me reset my password?")
        
        # Wait for response
        await asyncio.sleep(5)
        
        # Disconnect
        await client.disconnect()
    else:
        logger.error("Failed to connect to server")

async def example_room_chat():
    """Example of room-based chat."""
    logger.info("Starting room chat example...")
    
    client = ChatClient()
    client.set_session_id("room_session")
    
    if await client.connect():
        # Join a room
        await client.join_room("support_room")
        await asyncio.sleep(1)
        
        # Send message to room
        await client.send_chat_message("Hello everyone in the support room!")
        
        # Simulate typing
        await client.send_typing_indicator(True)
        await asyncio.sleep(2)
        await client.send_typing_indicator(False)
        
        # Wait and then leave room
        await asyncio.sleep(3)
        await client.leave_room("support_room")
        
        await client.disconnect()

async def example_authenticated_chat():
    """Example of authenticated chat."""
    logger.info("Starting authenticated chat example...")
    
    # In a real application, you would get this from your authentication system
    auth_token = "your_jwt_token_here"  # Replace with actual token
    
    client = ChatClient()
    client.set_authentication(auth_token)
    client.set_session_id("auth_session")
    
    if await client.connect():
        # Send chat message (with authentication, you might have access to more features)
        await client.send_chat_message("Hello! I'm logged in and need support.")
        
        # Wait for response
        await asyncio.sleep(5)
        
        # Try admin features if authenticated as admin
        await client.send_message("get_stats", {})
        
        await asyncio.sleep(2)
        await client.disconnect()

async def interactive_chat():
    """Interactive chat session."""
    logger.info("Starting interactive chat...")
    
    client = ChatClient()
    client.set_session_id("interactive_session")
    
    # Register handlers
    def on_chat_response(data):
        response = data.get("response", {})
        print(f"\n🤖 Agent: {response.get('content', 'No content')}")
        print("💬 You: ", end="", flush=True)
    
    def on_typing_indicator(data):
        client_id = data.get("client_id", "unknown")
        is_typing = data.get("is_typing", False)
        if is_typing:
            print(f"\n⏳ {client_id} is typing...")
            print("💬 You: ", end="", flush=True)
    
    client.register_message_handler("chat_response", on_chat_response)
    client.register_message_handler("typing_indicator", on_typing_indicator)
    
    if await client.connect():
        print("\n🎉 Connected to Customer Support AI!")
        print("Type your messages below (type 'quit' to exit):")
        print("💬 You: ", end="", flush=True)
        
        try:
            while True:
                # Get user input
                message = await asyncio.get_event_loop().run_in_executor(
                    None, input
                )
                
                if message.lower() in ['quit', 'exit', 'q']:
                    break
                
                if message.strip():
                    # Send typing indicator
                    await client.send_typing_indicator(True)
                    await asyncio.sleep(0.5)
                    
                    # Send message
                    await client.send_chat_message(message)
                    
                    # Stop typing indicator
                    await client.send_typing_indicator(False)
                
                print("💬 You: ", end="", flush=True)
                
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
        
        await client.disconnect()

async def main():
    """Main function to run examples."""
    logger.info("WebSocket Chat Client Examples")
    logger.info("Make sure the backend server is running on http://localhost:8000")
    
    # Wait for server to be ready
    await asyncio.sleep(1)
    
    print("\nAvailable examples:")
    print("1. Basic chat")
    print("2. Room-based chat")
    print("3. Authenticated chat")
    print("4. Interactive chat")
    
    try:
        choice = input("\nSelect an example (1-4) or 'q' to quit: ").strip()
        
        if choice == '1':
            await example_basic_chat()
        elif choice == '2':
            await example_room_chat()
        elif choice == '3':
            await example_authenticated_chat()
        elif choice == '4':
            await interactive_chat()
        elif choice.lower() in ['q', 'quit', 'exit']:
            return
        else:
            print("Invalid choice. Running basic chat example...")
            await example_basic_chat()
            
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        logger.error(f"Example failed: {str(e)}")
