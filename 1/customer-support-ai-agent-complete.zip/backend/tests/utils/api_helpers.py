"""
API testing utilities for HTTP requests, response validation, and testing patterns.

This module provides utilities for testing REST APIs, validating responses,
and common API testing patterns.
"""

import json
import asyncio
from typing import Dict, Any, List, Optional, Union, Callable
from datetime import datetime, timedelta
import httpx
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import ValidationError
import jsonschema
from jsonschema import validate, ValidationError as JSONSchemaValidationError


class APIHelpers:
    """
    Helper class for API testing utilities.
    """
    
    def __init__(self, base_url: str = "http://testserver"):
        """
        Initialize API helpers.
        
        Args:
            base_url: Base URL for API requests
        """
        self.base_url = base_url
        self.client = None
        self.response_history = []
        self.request_history = []
    
    def setup_client(self, app: FastAPI) -> TestClient:
        """Setup test client for FastAPI app."""
        self.client = TestClient(app)
        return self.client
    
    async def setup_async_client(self) -> httpx.AsyncClient:
        """Setup async HTTP client."""
        self.client = httpx.AsyncClient(base_url=self.base_url, timeout=30.0)
        return self.client
    
    async def cleanup(self):
        """Cleanup client resources."""
        if self.client:
            if hasattr(self.client, 'close'):
                await self.client.close()
            elif hasattr(self.client, 'aclose'):
                await self.client.aclose()
    
    # ==============================================================================
    # HTTP REQUEST HELPERS
    # ==============================================================================
    
    def get(self, url: str, headers: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Perform GET request."""
        return self._make_request("GET", url, headers=headers, **kwargs)
    
    def post(self, url: str, data: Optional[Dict] = None, json_data: Optional[Dict] = None, 
            headers: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Perform POST request."""
        return self._make_request("POST", url, data=data, json_data=json_data, 
                                headers=headers, **kwargs)
    
    def put(self, url: str, data: Optional[Dict] = None, json_data: Optional[Dict] = None,
            headers: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Perform PUT request."""
        return self._make_request("PUT", url, data=data, json_data=json_data, 
                                headers=headers, **kwargs)
    
    def patch(self, url: str, data: Optional[Dict] = None, json_data: Optional[Dict] = None,
             headers: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Perform PATCH request."""
        return self._make_request("PATCH", url, data=data, json_data=json_data, 
                                headers=headers, **kwargs)
    
    def delete(self, url: str, headers: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Perform DELETE request."""
        return self._make_request("DELETE", url, headers=headers, **kwargs)
    
    def _make_request(self, method: str, url: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request and capture response."""
        if not self.client:
            raise RuntimeError("Client not initialized. Call setup_client first.")
        
        # Ensure URL is relative to base URL
        if url.startswith('http'):
            full_url = url
        else:
            full_url = f"{self.base_url}{url}"
        
        try:
            # Perform request
            if hasattr(self.client, method.lower()):
                response = getattr(self.client, method.lower())(full_url, **kwargs)
            else:
                # For async client
                response = asyncio.run(getattr(self, f"_{method.lower()}_async")(full_url, **kwargs))
            
            # Capture request/response for history
            request_info = {
                "method": method,
                "url": full_url,
                "timestamp": datetime.utcnow(),
                "kwargs": kwargs
            }
            
            response_info = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "json": response.json() if response.headers.get('content-type', '').startswith('application/json') else None,
                "text": response.text,
                "timestamp": datetime.utcnow()
            }
            
            self.request_history.append(request_info)
            self.response_history.append(response_info)
            
            return {
                "success": 200 <= response.status_code < 300,
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "json": response.json() if response.headers.get('content-type', '').startswith('application/json') else None,
                "text": response.text,
                "response": response
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.utcnow()
            }
    
    async def _get_async(self, url: str, **kwargs) -> httpx.Response:
        """Async GET request."""
        return await self.client.get(url, **kwargs)
    
    async def _post_async(self, url: str, **kwargs) -> httpx.Response:
        """Async POST request."""
        return await self.client.post(url, **kwargs)
    
    async def _put_async(self, url: str, **kwargs) -> httpx.Response:
        """Async PUT request."""
        return await self.client.put(url, **kwargs)
    
    async def _patch_async(self, url: str, **kwargs) -> httpx.Response:
        """Async PATCH request."""
        return await self.client.patch(url, **kwargs)
    
    async def _delete_async(self, url: str, **kwargs) -> httpx.Response:
        """Async DELETE request."""
        return await self.client.delete(url, **kwargs)
    
    # ==============================================================================
    # RESPONSE VALIDATION
    # ==============================================================================
    
    def validate_status_code(self, response: Dict[str, Any], expected_codes: Union[int, List[int]]) -> bool:
        """Validate response status code."""
        actual_code = response.get("status_code")
        if isinstance(expected_codes, int):
            expected_codes = [expected_codes]
        return actual_code in expected_codes
    
    def validate_json_schema(self, response: Dict[str, Any], schema: Dict[str, Any]) -> Dict[str, Any]:
        """Validate JSON response against schema."""
        result = {
            "valid": True,
            "errors": [],
            "data": response.get("json")
        }
        
        if not response.get("json"):
            result["valid"] = False
            result["errors"].append("Response is not JSON")
            return result
        
        try:
            validate(instance=response["json"], schema=schema)
        except JSONSchemaValidationError as e:
            result["valid"] = False
            result["errors"].append(str(e))
        
        return result
    
    def validate_response_structure(self, response: Dict[str, Any], required_fields: List[str]) -> Dict[str, Any]:
        """Validate that response contains required fields."""
        result = {
            "valid": True,
            "missing_fields": [],
            "data": response.get("json")
        }
        
        if not response.get("json"):
            result["valid"] = False
            result["missing_fields"].append("No JSON data in response")
            return result
        
        json_data = response["json"]
        missing_fields = []
        
        for field in required_fields:
            if field not in json_data:
                missing_fields.append(field)
        
        if missing_fields:
            result["valid"] = False
            result["missing_fields"] = missing_fields
        
        return result
    
    def validate_pagination(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Validate paginated response structure."""
        result = {
            "valid": True,
            "errors": [],
            "data": response.get("json")
        }
        
        if not response.get("json"):
            result["valid"] = False
            result["errors"].append("Response is not JSON")
            return result
        
        json_data = response["json"]
        required_pagination_fields = ["items", "total", "page", "per_page"]
        
        for field in required_pagination_fields:
            if field not in json_data:
                result["errors"].append(f"Missing pagination field: {field}")
                result["valid"] = False
        
        # Validate pagination logic
        if "items" in json_data and "total" in json_data and "per_page" in json_data:
            items_count = len(json_data["items"])
            total = json_data["total"]
            per_page = json_data["per_page"]
            
            if items_count > per_page:
                result["errors"].append("Items count exceeds per_page limit")
                result["valid"] = False
        
        return result
    
    def validate_error_response(self, response: Dict[str, Any], expected_error_type: str = None) -> Dict[str, Any]:
        """Validate error response structure."""
        result = {
            "valid": True,
            "errors": [],
            "data": response.get("json")
        }
        
        if not response.get("json"):
            result["valid"] = False
            result["errors"].append("Response is not JSON")
            return result
        
        json_data = response["json"]
        
        # Check for common error fields
        if "error" not in json_data and "message" not in json_data:
            result["errors"].append("Missing error or message field")
            result["valid"] = False
        
        if expected_error_type and "error" in json_data:
            if json_data["error"].get("type") != expected_error_type:
                result["errors"].append(f"Expected error type '{expected_error_type}', got '{json_data['error'].get('type')}'")
                result["valid"] = False
        
        return result
    
    # ==============================================================================
    # COMMON API TEST PATTERNS
    # ==============================================================================
    
    def test_crud_operations(self, base_url: str, entity_name: str, 
                           create_data: Dict[str, Any], 
                           update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Test CRUD operations for an entity."""
        results = {
            "create": {},
            "read": {},
            "update": {},
            "delete": {},
            "errors": []
        }
        
        try:
            # CREATE
            create_response = self.post(base_url, json_data=create_data)
            results["create"] = create_response
            
            if not create_response["success"]:
                results["errors"].append("CREATE operation failed")
                return results
            
            entity_id = create_response["json"].get("id")
            if not entity_id:
                results["errors"].append("Created entity has no ID")
                return results
            
            # READ (single entity)
            read_response = self.get(f"{base_url}/{entity_id}")
            results["read"]["single"] = read_response
            
            # READ (list)
            list_response = self.get(base_url)
            results["read"]["list"] = list_response
            
            # UPDATE
            update_response = self.put(f"{base_url}/{entity_id}", json_data=update_data)
            results["update"] = update_response
            
            # Verify update
            verify_response = self.get(f"{base_url}/{entity_id}")
            results["update"]["verification"] = verify_response
            
            # DELETE
            delete_response = self.delete(f"{base_url}/{entity_id}")
            results["delete"] = delete_response
            
            # Verify deletion
            verify_delete_response = self.get(f"{base_url}/{entity_id}")
            results["delete"]["verification"] = verify_delete_response
            
        except Exception as e:
            results["errors"].append(f"CRUD test error: {str(e)}")
        
        return results
    
    def test_authentication_flow(self, auth_endpoints: Dict[str, str], 
                               user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Test authentication flow."""
        results = {
            "register": {},
            "login": {},
            "refresh": {},
            "logout": {},
            "errors": []
        }
        
        try:
            # REGISTER
            register_data = {
                "username": user_data.get("username"),
                "email": user_data.get("email"),
                "password": user_data.get("password")
            }
            register_response = self.post(auth_endpoints["register"], json_data=register_data)
            results["register"] = register_response
            
            if not register_response["success"]:
                results["errors"].append("Registration failed")
                return results
            
            # LOGIN
            login_data = {
                "username": user_data.get("username"),
                "password": user_data.get("password")
            }
            login_response = self.post(auth_endpoints["login"], json_data=login_data)
            results["login"] = login_response
            
            if not login_response["success"]:
                results["errors"].append("Login failed")
                return results
            
            access_token = login_response["json"].get("access_token")
            refresh_token = login_response["json"].get("refresh_token")
            
            if not access_token:
                results["errors"].append("No access token in login response")
                return results
            
            # REFRESH
            if refresh_token:
                refresh_data = {"refresh_token": refresh_token}
                refresh_response = self.post(auth_endpoints["refresh"], json_data=refresh_data)
                results["refresh"] = refresh_response
            
            # LOGOUT
            headers = {"Authorization": f"Bearer {access_token}"}
            logout_response = self.post(auth_endpoints["logout"], headers=headers)
            results["logout"] = logout_response
            
        except Exception as e:
            results["errors"].append(f"Authentication flow error: {str(e)}")
        
        return results
    
    def test_endpoint_validation(self, url: str, validation_cases: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Test endpoint input validation with various cases."""
        results = {
            "valid_cases": [],
            "invalid_cases": [],
            "errors": []
        }
        
        for case in validation_cases:
            try:
                request_data = case.get("data", {})
                expected_status = case.get("expected_status", 200)
                description = case.get("description", "Test case")
                
                response = self.post(url, json_data=request_data)
                
                case_result = {
                    "description": description,
                    "request_data": request_data,
                    "status_code": response["status_code"],
                    "success": response["success"],
                    "response": response
                }
                
                if self.validate_status_code(response, expected_status):
                    results["valid_cases"].append(case_result)
                else:
                    results["invalid_cases"].append(case_result)
                
            except Exception as e:
                results["errors"].append(f"Validation case error: {str(e)}")
        
        return results
    
    def test_rate_limiting(self, url: str, num_requests: int = 10, 
                         request_interval: float = 0.1) -> Dict[str, Any]:
        """Test rate limiting behavior."""
        results = {
            "requests": [],
            "rate_limited_count": 0,
            "success_count": 0,
            "errors": []
        }
        
        for i in range(num_requests):
            try:
                start_time = datetime.utcnow()
                response = self.get(url)
                end_time = datetime.utcnow()
                
                request_info = {
                    "request_number": i + 1,
                    "timestamp": start_time,
                    "duration_ms": (end_time - start_time).total_seconds() * 1000,
                    "status_code": response["status_code"],
                    "success": response["success"]
                }
                
                results["requests"].append(request_info)
                
                if response["status_code"] == 429:  # Too Many Requests
                    results["rate_limited_count"] += 1
                elif response["success"]:
                    results["success_count"] += 1
                
                # Wait before next request
                if i < num_requests - 1:
                    asyncio.sleep(request_interval)
                
            except Exception as e:
                results["errors"].append(f"Request {i + 1} error: {str(e)}")
        
        return results
    
    # ==============================================================================
    # PERFORMANCE AND LOAD TESTING
    # ==============================================================================
    
    def test_concurrent_requests(self, url: str, num_concurrent: int = 10, 
                               num_requests_per_concurrent: int = 5) -> Dict[str, Any]:
        """Test concurrent requests to endpoint."""
        results = {
            "total_requests": num_concurrent * num_requests_per_concurrent,
            "successful_requests": 0,
            "failed_requests": 0,
            "response_times": [],
            "errors": []
        }
        
        async def make_requests():
            for _ in range(num_requests_per_concurrent):
                try:
                    start_time = datetime.utcnow()
                    response = self.get(url)
                    end_time = datetime.utcnow()
                    
                    response_time = (end_time - start_time).total_seconds()
                    results["response_times"].append(response_time)
                    
                    if response["success"]:
                        results["successful_requests"] += 1
                    else:
                        results["failed_requests"] += 1
                
                except Exception as e:
                    results["failed_requests"] += 1
                    results["errors"].append(str(e))
        
        # Run concurrent requests
        tasks = [make_requests() for _ in range(num_concurrent)]
        asyncio.run(asyncio.gather(*tasks))
        
        # Calculate statistics
        if results["response_times"]:
            results["avg_response_time"] = sum(results["response_times"]) / len(results["response_times"])
            results["min_response_time"] = min(results["response_times"])
            results["max_response_time"] = max(results["response_times"])
        
        return results
    
    # ==============================================================================
    # UTILITY METHODS
    # ==============================================================================
    
    def get_response_history(self) -> List[Dict[str, Any]]:
        """Get history of all responses."""
        return self.response_history.copy()
    
    def get_request_history(self) -> List[Dict[str, Any]]:
        """Get history of all requests."""
        return self.request_history.copy()
    
    def clear_history(self):
        """Clear request and response history."""
        self.response_history.clear()
        self.request_history.clear()
    
    def generate_test_data(self, template: Dict[str, Any]) -> Dict[str, Any]:
        """Generate test data based on template."""
        # Simple template expansion for testing
        test_data = template.copy()
        
        # Replace common placeholders
        for key, value in test_data.items():
            if isinstance(value, str):
                if value == "{{timestamp}}":
                    test_data[key] = datetime.utcnow().isoformat()
                elif value == "{{uuid}}":
                    test_data[key] = str(uuid4())
                elif value.startswith("{{random_"):
                    # Handle random data placeholders
                    test_data[key] = self._generate_random_value(value)
        
        return test_data
    
    def _generate_random_value(self, template: str) -> str:
        """Generate random value based on template."""
        import random
        import string
        
        if "int}}" in template:
            return str(random.randint(1, 1000))
        elif "str}}" in template:
            length = 10
            return ''.join(random.choices(string.ascii_letters, k=length))
        elif "email}}" in template:
            return f"test_{random.randint(1000, 9999)}@example.com"
        else:
            return "test_value"


# ==============================================================================
# RESPONSE MOCKS AND FACTORIES
# ==============================================================================

class ResponseFactory:
    """Factory for creating mock API responses."""
    
    @staticmethod
    def success_response(data: Any = None, message: str = "Success") -> Dict[str, Any]:
        """Create successful API response."""
        response = {
            "success": True,
            "message": message,
            "timestamp": datetime.utcnow().isoformat()
        }
        if data is not None:
            response["data"] = data
        return response
    
    @staticmethod
    def error_response(message: str, error_type: str = "GeneralError", 
                      status_code: int = 400, details: Any = None) -> Dict[str, Any]:
        """Create error API response."""
        response = {
            "success": False,
            "error": {
                "type": error_type,
                "message": message,
                "timestamp": datetime.utcnow().isoformat()
            },
            "status_code": status_code
        }
        if details:
            response["error"]["details"] = details
        return response
    
    @staticmethod
    def paginated_response(items: List[Any], page: int = 1, 
                          per_page: int = 10, total: int = None) -> Dict[str, Any]:
        """Create paginated API response."""
        if total is None:
            total = len(items)
        
        return {
            "success": True,
            "data": {
                "items": items,
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": total,
                    "pages": (total + per_page - 1) // per_page
                }
            }
        }