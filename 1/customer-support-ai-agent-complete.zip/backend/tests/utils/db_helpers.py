"""
Database testing utilities for setup, teardown, and data management.

This module provides utilities for creating test databases, managing test data,
and performing database operations during testing.
"""

import asyncio
from typing import Any, Dict, List, Optional, AsyncGenerator, Type
from datetime import datetime, timedelta
from pathlib import Path
import tempfile
import shutil
from sqlalchemy import text, MetaData, Table, Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.asyncio import AsyncSession, AsyncEngine, create_async_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.engine import Engine, create_engine
import json
import csv
from uuid import uuid4


class DatabaseHelpers:
    """
    Helper class for database testing operations.
    """
    
    def __init__(self, test_db_url: str = "sqlite:///./test_backend.db"):
        """
        Initialize database helpers.
        
        Args:
            test_db_url: Database URL for testing
        """
        self.test_db_url = test_db_url
        self.engine = None
        self.async_engine = None
        self.session_factory = None
        self.async_session_factory = None
        self.temp_db_path = None
    
    # ==============================================================================
    # DATABASE SETUP AND TEARDOWN
    # ==============================================================================
    
    async def setup_test_database(self, create_tables: bool = True) -> AsyncEngine:
        """
        Setup a test database.
        
        Args:
            create_tables: Whether to create tables
            
        Returns:
            Async engine instance
        """
        # Use temporary database for isolation
        self.temp_db_path = Path(tempfile.mktemp(suffix=".db"))
        
        # Create async engine for testing
        self.async_engine = create_async_engine(
            f"sqlite+aiosqlite:///{self.temp_db_path}",
            echo=False,
            future=True
        )
        
        self.async_session_factory = async_sessionmaker(
            self.async_engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        if create_tables:
            await self.create_all_tables()
        
        return self.async_engine
    
    async def cleanup_test_database(self):
        """Cleanup test database and connections."""
        if self.async_engine:
            await self.async_engine.dispose()
        
        if self.temp_db_path and self.temp_db_path.exists():
            self.temp_db_path.unlink()
            self.temp_db_path = None
        
        self.async_engine = None
        self.async_session_factory = None
    
    async def create_all_tables(self):
        """Create all database tables."""
        async with self.async_engine.begin() as conn:
            # Import your models here to ensure they're loaded
            try:
                from app.database import Base
                await conn.run_sync(Base.metadata.create_all)
            except ImportError:
                # If models not available, create basic tables
                await self._create_basic_tables()
    
    async def drop_all_tables(self):
        """Drop all database tables."""
        async with self.async_engine.begin() as conn:
            try:
                from app.database import Base
                await conn.run_sync(Base.metadata.drop_all)
            except ImportError:
                await self._drop_basic_tables()
    
    async def _create_basic_tables(self):
        """Create basic tables if models not available."""
        # This would create minimal tables for testing
        pass
    
    async def _drop_basic_tables(self):
        """Drop basic tables."""
        # This would drop minimal tables
        pass
    
    # ==============================================================================
    # SESSION MANAGEMENT
    # ==============================================================================
    
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get a test database session."""
        if not self.async_session_factory:
            raise RuntimeError("Test database not setup. Call setup_test_database first.")
        
        async with self.async_session_factory() as session:
            yield session
    
    async def create_test_session(self) -> AsyncSession:
        """Create a new test session."""
        if not self.async_session_factory:
            await self.setup_test_database()
        
        return self.async_session_factory()
    
    # ==============================================================================
    # DATA MANAGEMENT
    # ==============================================================================
    
    async def clear_all_tables(self):
        """Clear all data from tables (truncate)."""
        async with self.async_engine.begin() as conn:
            # Get all table names
            result = await conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            )
            table_names = [row[0] for row in result.fetchall()]
            
            # Disable foreign key checks temporarily
            await conn.execute(text("PRAGMA foreign_keys = OFF"))
            
            # Truncate tables in reverse dependency order
            for table_name in reversed(table_names):
                try:
                    await conn.execute(text(f"DELETE FROM {table_name}"))
                except Exception as e:
                    print(f"Warning: Could not clear table {table_name}: {e}")
            
            # Re-enable foreign key checks
            await conn.execute(text("PRAGMA foreign_keys = ON"))
    
    async def seed_test_data(self, data: Dict[str, List[Dict[str, Any]]]):
        """
        Seed database with test data.
        
        Args:
            data: Dictionary mapping table names to list of records
        """
        async with self.async_session_factory() as session:
            for table_name, records in data.items():
                for record in records:
                    # Simple insert based on table name
                    await self._insert_record(session, table_name, record)
            
            await session.commit()
    
    async def _insert_record(self, session: AsyncSession, table_name: str, record: Dict[str, Any]):
        """Insert a record into a table."""
        try:
            columns = ", ".join(record.keys())
            placeholders = ", ".join([f":{key}" for key in record.keys()])
            query = text(f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})")
            
            await session.execute(query, record)
        except Exception as e:
            print(f"Warning: Could not insert record into {table_name}: {e}")
    
    # ==============================================================================
    # DATA VERIFICATION
    # ==============================================================================
    
    async def verify_table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the database."""
        async with self.async_engine.begin() as conn:
            result = await conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table' AND name = :table_name"),
                {"table_name": table_name}
            )
            return result.fetchone() is not None
    
    async def verify_table_empty(self, table_name: str) -> bool:
        """Check if a table is empty."""
        async with self.async_engine.begin() as conn:
            result = await conn.execute(
                text(f"SELECT COUNT(*) as count FROM {table_name}")
            )
            return result.fetchone()[0] == 0
    
    async def verify_record_exists(self, table_name: str, conditions: Dict[str, Any]) -> bool:
        """Check if a record exists in a table matching conditions."""
        async with self.async_engine.begin() as conn:
            where_clause = " AND ".join([f"{key} = :{key}" for key in conditions.keys()])
            query = text(f"SELECT COUNT(*) as count FROM {table_name} WHERE {where_clause}")
            
            result = await conn.execute(query, conditions)
            return result.fetchone()[0] > 0
    
    async def get_table_count(self, table_name: str) -> int:
        """Get the number of records in a table."""
        async with self.async_engine.begin() as conn:
            result = await conn.execute(
                text(f"SELECT COUNT(*) as count FROM {table_name}")
            )
            return result.fetchone()[0]
    
    # ==============================================================================
    # DATA EXPORT AND IMPORT
    # ==============================================================================
    
    async def export_table_data(self, table_name: str) -> List[Dict[str, Any]]:
        """Export all data from a table."""
        async with self.async_engine.begin() as conn:
            query = text(f"SELECT * FROM {table_name}")
            result = await conn.execute(query)
            return [dict(row) for row in result.fetchall()]
    
    async def export_all_data(self) -> Dict[str, List[Dict[str, Any]]]:
        """Export all data from all tables."""
        async with self.async_engine.begin() as conn:
            # Get table names
            result = await conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            )
            table_names = [row[0] for row in result.fetchall()]
            
            data = {}
            for table_name in table_names:
                try:
                    query = text(f"SELECT * FROM {table_name}")
                    result = await conn.execute(query)
                    data[table_name] = [dict(row) for row in result.fetchall()]
                except Exception as e:
                    print(f"Warning: Could not export data from {table_name}: {e}")
                    data[table_name] = []
            
            return data
    
    def export_data_to_json(self, data: Dict[str, List[Dict[str, Any]]], file_path: str):
        """Export data to JSON file."""
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2, default=str)
    
    def export_data_to_csv(self, data: Dict[str, List[Dict[str, Any]]], directory: str):
        """Export data to CSV files."""
        Path(directory).mkdir(parents=True, exist_ok=True)
        
        for table_name, records in data.items():
            if not records:
                continue
            
            file_path = Path(directory) / f"{table_name}.csv"
            with open(file_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=records[0].keys())
                writer.writeheader()
                writer.writerows(records)
    
    # ==============================================================================
    # TEST DATA FACTORY
    # ==============================================================================
    
    async def create_test_user(self, session: AsyncSession, **overrides) -> Dict[str, Any]:
        """Create a test user record in database."""
        user_data = {
            "id": str(uuid4()),
            "username": overrides.get("username", f"testuser_{uuid4().hex[:8]}"),
            "email": overrides.get("email", f"test_{uuid4().hex[:8]}@example.com"),
            "password_hash": overrides.get("password_hash", "hashed_password"),
            "is_active": overrides.get("is_active", True),
            "is_verified": overrides.get("is_verified", True),
            "is_admin": overrides.get("is_admin", False),
            "created_at": overrides.get("created_at", datetime.utcnow()),
            "updated_at": overrides.get("updated_at", datetime.utcnow())
        }
        
        await session.execute(
            text("""INSERT INTO users (id, username, email, password_hash, is_active, 
                                  is_verified, is_admin, created_at, updated_at) 
                       VALUES (:id, :username, :email, :password_hash, :is_active, 
                               :is_verified, :is_admin, :created_at, :updated_at)"""),
            user_data
        )
        
        return user_data
    
    async def create_test_session(self, session: AsyncSession, **overrides) -> Dict[str, Any]:
        """Create a test session record in database."""
        session_data = {
            "id": str(uuid4()),
            "user_id": overrides.get("user_id", str(uuid4())),
            "title": overrides.get("title", "Test Session"),
            "status": overrides.get("status", "active"),
            "priority": overrides.get("priority", "medium"),
            "category": overrides.get("category", "general"),
            "created_at": overrides.get("created_at", datetime.utcnow()),
            "updated_at": overrides.get("updated_at", datetime.utcnow())
        }
        
        await session.execute(
            text("""INSERT INTO sessions (id, user_id, title, status, priority, 
                                      category, created_at, updated_at) 
                       VALUES (:id, :user_id, :title, :status, :priority, 
                               :category, :created_at, :updated_at)"""),
            session_data
        )
        
        return session_data
    
    async def create_test_message(self, session: AsyncSession, **overrides) -> Dict[str, Any]:
        """Create a test message record in database."""
        message_data = {
            "id": str(uuid4()),
            "session_id": overrides.get("session_id", str(uuid4())),
            "message_type": overrides.get("message_type", "user"),
            "content": overrides.get("content", "Test message"),
            "sender_id": overrides.get("sender_id", str(uuid4())),
            "sender_type": overrides.get("sender_type", "user"),
            "created_at": overrides.get("created_at", datetime.utcnow()),
            "updated_at": overrides.get("updated_at", datetime.utcnow())
        }
        
        await session.execute(
            text("""INSERT INTO messages (id, session_id, message_type, content, sender_id, 
                                       sender_type, created_at, updated_at) 
                       VALUES (:id, :session_id, :message_type, :content, :sender_id, 
                               :sender_type, :created_at, :updated_at)"""),
            message_data
        )
        
        return message_data
    
    # ==============================================================================
    # SCHEMA VALIDATION
    # ==============================================================================
    
    async def validate_schema(self, table_name: str, expected_columns: List[str]) -> Dict[str, Any]:
        """Validate table schema."""
        async with self.async_engine.begin() as conn:
            # Get table info
            result = await conn.execute(
                text("PRAGMA table_info(:table_name)"),
                {"table_name": table_name}
            )
            
            actual_columns = [row[1] for row in result.fetchall()]  # Column name is at index 1
            
            return {
                "table_name": table_name,
                "expected_columns": expected_columns,
                "actual_columns": actual_columns,
                "columns_match": set(expected_columns) == set(actual_columns),
                "missing_columns": list(set(expected_columns) - set(actual_columns)),
                "extra_columns": list(set(actual_columns) - set(expected_columns))
            }
    
    async def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        """Get table schema information."""
        async with self.async_engine.begin() as conn:
            result = await conn.execute(
                text("PRAGMA table_info(:table_name)"),
                {"table_name": table_name}
            )
            
            schema = []
            for row in result.fetchall():
                schema.append({
                    "name": row[1],
                    "type": row[2],
                    "nullable": not row[3],
                    "default": row[4],
                    "primary_key": bool(row[5])
                })
            
            return schema
    
    # ==============================================================================
    # PERFORMANCE TESTING
    # ==============================================================================
    
    async def benchmark_query(self, query: str, params: Optional[Dict] = None, 
                            iterations: int = 100) -> Dict[str, Any]:
        """Benchmark a database query."""
        async with self.async_engine.begin() as conn:
            times = []
            
            for _ in range(iterations):
                start_time = datetime.utcnow()
                
                if params:
                    await conn.execute(text(query), params)
                else:
                    await conn.execute(text(query))
                
                end_time = datetime.utcnow()
                times.append((end_time - start_time).total_seconds())
            
            return {
                "query": query,
                "iterations": iterations,
                "average_time": sum(times) / len(times),
                "min_time": min(times),
                "max_time": max(times),
                "total_time": sum(times)
            }
    
    # ==============================================================================
    # MIGRATION TESTING
    # ==============================================================================
    
    async def check_migration_applied(self, migration_name: str) -> bool:
        """Check if a specific migration has been applied."""
        async with self.async_engine.begin() as conn:
            # Create alembic_version table if it doesn't exist
            try:
                await conn.execute(text("""CREATE TABLE IF NOT EXISTS alembic_version (
                    version_num VARCHAR(32) NOT NULL
                )"""))
            except Exception:
                pass
            
            # Check if migration is in version table
            result = await conn.execute(
                text("SELECT version_num FROM alembic_version WHERE version_num = :migration"),
                {"migration": migration_name}
            )
            
            return result.fetchone() is not None
    
    async def get_migration_history(self) -> List[str]:
        """Get list of applied migrations."""
        async with self.async_engine.begin() as conn:
            try:
                result = await conn.execute(text("SELECT version_num FROM alembic_version ORDER BY version_num"))
                return [row[0] for row in result.fetchall()]
            except Exception:
                return []
    
    # ==============================================================================
    # UTILITY METHODS
    # ==============================================================================
    
    async def reset_database(self):
        """Reset database to clean state."""
        await self.drop_all_tables()
        await self.create_all_tables()
    
    async def get_database_info(self) -> Dict[str, Any]:
        """Get information about the test database."""
        async with self.async_engine.begin() as conn:
            # Get database file size
            db_size = self.temp_db_path.stat().st_size if self.temp_db_path else 0
            
            # Get table information
            result = await conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            )
            tables = [row[0] for row in result.fetchall()]
            
            table_info = {}
            for table in tables:
                count_result = await conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                count = count_result.fetchone()[0]
                table_info[table] = {"record_count": count}
            
            return {
                "database_url": str(self.temp_db_path) if self.temp_db_path else "in-memory",
                "database_size_bytes": db_size,
                "tables": table_info,
                "table_count": len(tables)
            }
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.setup_test_database()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.cleanup_test_database()