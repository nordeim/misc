"""
Performance testing utilities for load testing and performance analysis.

This module provides utilities for measuring application performance, load testing,
and generating performance reports.
"""

import asyncio
import time
import psutil
import statistics
from typing import Dict, Any, List, Optional, Callable, AsyncGenerator
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import concurrent.futures
import threading
import json
import csv
from pathlib import Path


class LoadTestType(Enum):
    """Types of load tests."""
    CONCURRENT_USERS = "concurrent_users"
    SUSTAINED_LOAD = "sustained_load"
    GRADUAL_RAMP_UP = "gradual_ramp_up"
    BURST_TEST = "burst_test"
    STRESS_TEST = "stress_test"
    ENDURANCE_TEST = "endurance_test"


@dataclass
class PerformanceMetric:
    """Performance metric container."""
    name: str
    value: float
    unit: str
    timestamp: datetime
    metadata: Dict[str, Any] = None


@dataclass
class LoadTestResult:
    """Load test result container."""
    test_name: str
    test_type: LoadTestType
    start_time: datetime
    end_time: datetime
    duration_seconds: float
    metrics: List[PerformanceMetric]
    errors: List[str]
    summary: Dict[str, Any]


class PerformanceTestUtils:
    """
    Performance testing utilities for comprehensive load and performance testing.
    """
    
    def __init__(self, base_url: str = "http://testserver"):
        """
        Initialize performance test utilities.
        
        Args:
            base_url: Base URL for API testing
        """
        self.base_url = base_url
        self.test_results = []
        self.monitoring_active = False
        self.system_metrics = []
        
    # ==============================================================================
    # LOAD TESTING
    # ==============================================================================
    
    async def test_concurrent_users(self, endpoint: str, num_users: int, 
                                  duration_seconds: int, 
                                  request_func: Callable = None,
                                  **request_kwargs) -> LoadTestResult:
        """
        Test application with concurrent users.
        
        Args:
            endpoint: API endpoint to test
            num_users: Number of concurrent users
            duration_seconds: Test duration
            request_func: Custom request function
            **request_kwargs: Additional request parameters
            
        Returns:
            Load test results
        """
        test_name = f"Concurrent Users Test - {num_users} users"
        start_time = datetime.utcnow()
        
        results = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "response_times": [],
            "status_codes": [],
            "errors": []
        }
        
        # Use custom request function or default HTTP client
        if not request_func:
            request_func = self._default_http_request
        
        async def user_session(user_id: int):
            """Simulate a user session."""
            session_results = {
                "requests_made": 0,
                "errors": []
            }
            
            session_start = time.time()
            while time.time() - session_start < duration_seconds:
                try:
                    request_start = time.time()
                    
                    # Make request
                    response = await request_func(endpoint, **request_kwargs)
                    
                    request_end = time.time()
                    response_time = (request_end - request_start) * 1000  # ms
                    
                    # Record result
                    results["total_requests"] += 1
                    results["response_times"].append(response_time)
                    results["status_codes"].append(response.get("status_code", 0))
                    
                    if response.get("success", False):
                        results["successful_requests"] += 1
                    else:
                        results["failed_requests"] += 1
                    
                    session_results["requests_made"] += 1
                    
                    # Small delay between requests
                    await asyncio.sleep(0.1)
                    
                except Exception as e:
                    results["failed_requests"] += 1
                    error_msg = f"User {user_id} error: {str(e)}"
                    results["errors"].append(error_msg)
                    session_results["errors"].append(error_msg)
            
            return session_results
        
        # Run concurrent user sessions
        tasks = [user_session(i) for i in range(num_users)]
        user_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        for result in user_results:
            if isinstance(result, Exception):
                results["errors"].append(str(result))
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        # Create performance metrics
        metrics = self._create_performance_metrics(results, num_users, duration)
        
        # Create test result
        test_result = LoadTestResult(
            test_name=test_name,
            test_type=LoadTestType.CONCURRENT_USERS,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            metrics=metrics,
            errors=results["errors"],
            summary=self._create_test_summary(results, num_users, duration)
        )
        
        self.test_results.append(test_result)
        return test_result
    
    async def test_sustained_load(self, endpoint: str, requests_per_second: float,
                                duration_seconds: int,
                                request_func: Callable = None,
                                **request_kwargs) -> LoadTestResult:
        """
        Test application with sustained load.
        
        Args:
            endpoint: API endpoint to test
            requests_per_second: Request rate
            duration_seconds: Test duration
            request_func: Custom request function
            **request_kwargs: Additional request parameters
            
        Returns:
            Load test results
        """
        test_name = f"Sustained Load Test - {requests_per_second} RPS for {duration_seconds}s"
        start_time = datetime.utcnow()
        
        results = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "response_times": [],
            "status_codes": [],
            "errors": [],
            "request_intervals": []
        }
        
        # Use custom request function or default
        if not request_func:
            request_func = self._default_http_request
        
        interval = 1.0 / requests_per_second
        end_time = start_time + timedelta(seconds=duration_seconds)
        
        while datetime.utcnow() < end_time:
            request_start = time.time()
            
            try:
                response = await request_func(endpoint, **request_kwargs)
                request_end = time.time()
                
                # Record metrics
                results["total_requests"] += 1
                results["response_times"].append((request_end - request_start) * 1000)
                results["status_codes"].append(response.get("status_code", 0))
                
                if response.get("success", False):
                    results["successful_requests"] += 1
                else:
                    results["failed_requests"] += 1
                
                # Calculate sleep time to maintain rate
                elapsed = time.time() - request_start
                sleep_time = max(0, interval - elapsed)
                await asyncio.sleep(sleep_time)
                
                # Track request interval
                if len(results["request_intervals"]) > 0:
                    results["request_intervals"].append(elapsed)
                
            except Exception as e:
                results["failed_requests"] += 1
                results["errors"].append(str(e))
        
        actual_duration = (datetime.utcnow() - start_time).total_seconds()
        
        # Create metrics
        metrics = self._create_performance_metrics(results, requests_per_second, actual_duration)
        
        test_result = LoadTestResult(
            test_name=test_name,
            test_type=LoadTestType.SUSTAINED_LOAD,
            start_time=start_time,
            end_time=datetime.utcnow(),
            duration_seconds=actual_duration,
            metrics=metrics,
            errors=results["errors"],
            summary=self._create_test_summary(results, requests_per_second, actual_duration)
        )
        
        self.test_results.append(test_result)
        return test_result
    
    async def test_gradual_ramp_up(self, endpoint: str, max_users: int,
                                 ramp_duration_seconds: int,
                                 test_duration_seconds: int,
                                 request_func: Callable = None,
                                 **request_kwargs) -> LoadTestResult:
        """
        Test with gradual user ramp-up.
        
        Args:
            endpoint: API endpoint to test
            max_users: Maximum concurrent users
            ramp_duration_seconds: Time to reach max users
            test_duration_seconds: Duration at max load
            request_func: Custom request function
            **request_kwargs: Additional request parameters
            
        Returns:
            Load test results
        """
        test_name = f"Gradual Ramp-up - {max_users} users over {ramp_duration_seconds}s"
        start_time = datetime.utcnow()
        
        results = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "response_times": [],
            "user_progression": [],
            "errors": []
        }
        
        if not request_func:
            request_func = self._default_http_request
        
        # Calculate ramp-up rate
        ramp_up_rate = max_users / ramp_duration_seconds
        ramp_end_time = start_time + timedelta(seconds=ramp_duration_seconds)
        test_end_time = ramp_end_time + timedelta(seconds=test_duration_seconds)
        
        active_sessions = []
        
        while datetime.utcnow() < test_end_time:
            current_time = datetime.utcnow()
            
            # Add users during ramp-up phase
            if current_time < ramp_end_time:
                users_to_add = min(
                    int((current_time - start_time).total_seconds() * ramp_up_rate) - len(active_sessions),
                    max(100)  # Limit concurrent sessions for testing
                )
                
                for _ in range(users_to_add):
                    session_task = asyncio.create_task(
                        self._sustained_user_session(endpoint, test_end_time, request_func, **request_kwargs)
                    )
                    active_sessions.append(session_task)
                    results["user_progression"].append({
                        "timestamp": current_time,
                        "total_users": len(active_sessions)
                    })
            
            # Check for completed sessions
            active_sessions = [task for task in active_sessions if not task.done()]
            
            # Wait a bit before checking again
            await asyncio.sleep(1.0)
        
        # Wait for remaining sessions to complete
        if active_sessions:
            session_results = await asyncio.gather(*active_sessions, return_exceptions=True)
            
            for result in session_results:
                if isinstance(result, Exception):
                    results["errors"].append(str(result))
                else:
                    results["total_requests"] += result.get("requests_made", 0)
                    results["successful_requests"] += result.get("successful_requests", 0)
                    results["failed_requests"] += result.get("failed_requests", 0)
                    results["response_times"].extend(result.get("response_times", []))
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        # Create metrics
        metrics = self._create_performance_metrics(results, max_users, duration)
        
        test_result = LoadTestResult(
            test_name=test_name,
            test_type=LoadTestType.GRADUAL_RAMP_UP,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            metrics=metrics,
            errors=results["errors"],
            summary=self._create_test_summary(results, max_users, duration)
        )
        
        self.test_results.append(test_result)
        return test_result
    
    async def _sustained_user_session(self, endpoint: str, end_time: datetime,
                                    request_func: Callable, **request_kwargs):
        """Run a sustained user session."""
        session_results = {
            "requests_made": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "response_times": []
        }
        
        while datetime.utcnow() < end_time:
            try:
                request_start = time.time()
                
                response = await request_func(endpoint, **request_kwargs)
                request_end = time.time()
                
                session_results["requests_made"] += 1
                session_results["response_times"].append((request_end - request_start) * 1000)
                
                if response.get("success", False):
                    session_results["successful_requests"] += 1
                else:
                    session_results["failed_requests"] += 1
                
                # Random delay between requests
                await asyncio.sleep(0.5 + (time.time() % 1.0))
                
            except Exception:
                session_results["failed_requests"] += 1
        
        return session_results
    
    async def test_burst_load(self, endpoint: str, burst_size: int,
                            cooldown_seconds: int,
                            num_bursts: int,
                            request_func: Callable = None,
                            **request_kwargs) -> LoadTestResult:
        """
        Test application with burst load patterns.
        
        Args:
            endpoint: API endpoint to test
            burst_size: Number of requests in each burst
            cooldown_seconds: Time between bursts
            num_bursts: Number of bursts to perform
            request_func: Custom request function
            **request_kwargs: Additional request parameters
            
        Returns:
            Load test results
        """
        test_name = f"Burst Load Test - {burst_size} requests, {num_bursts} bursts"
        start_time = datetime.utcnow()
        
        results = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "burst_results": [],
            "errors": []
        }
        
        if not request_func:
            request_func = self._default_http_request
        
        for burst_num in range(num_bursts):
            burst_start = time.time()
            burst_results = {
                "burst_number": burst_num + 1,
                "requests": [],
                "start_time": burst_start
            }
            
            # Execute burst
            burst_tasks = []
            for _ in range(burst_size):
                task = asyncio.create_task(request_func(endpoint, **request_kwargs))
                burst_tasks.append(task)
            
            burst_responses = await asyncio.gather(*burst_tasks, return_exceptions=True)
            
            burst_end = time.time()
            burst_duration = burst_end - burst_start
            
            # Process burst results
            for i, response in enumerate(burst_responses):
                request_result = {
                    "request_number": i + 1,
                    "duration_ms": (burst_end - burst_start) * 1000,
                    "success": not isinstance(response, Exception),
                    "error": str(response) if isinstance(response, Exception) else None
                }
                
                burst_results["requests"].append(request_result)
                
                results["total_requests"] += 1
                
                if isinstance(response, Exception):
                    results["failed_requests"] += 1
                    results["errors"].append(f"Burst {burst_num + 1}, Request {i + 1}: {str(response)}")
                else:
                    if response.get("success", False):
                        results["successful_requests"] += 1
                    else:
                        results["failed_requests"] += 1
            
            burst_results["burst_duration"] = burst_duration
            burst_results["success_rate"] = (
                sum(1 for r in burst_results["requests"] if r["success"]) / burst_size * 100
            )
            
            results["burst_results"].append(burst_results)
            
            # Cooldown period
            if burst_num < num_bursts - 1:
                await asyncio.sleep(cooldown_seconds)
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        # Create metrics
        metrics = self._create_performance_metrics(results, burst_size * num_bursts, duration)
        
        test_result = LoadTestResult(
            test_name=test_name,
            test_type=LoadTestType.BURST_TEST,
            start_time=start_time,
            end_time=end_time,
            duration_seconds=duration,
            metrics=metrics,
            errors=results["errors"],
            summary=self._create_test_summary(results, burst_size * num_bursts, duration)
        )
        
        self.test_results.append(test_result)
        return test_result
    
    # ==============================================================================
    # SYSTEM MONITORING
    # ==============================================================================
    
    async def start_system_monitoring(self, interval_seconds: float = 1.0):
        """Start monitoring system resources during tests."""
        self.monitoring_active = True
        
        while self.monitoring_active:
            try:
                # Collect system metrics
                cpu_percent = psutil.cpu_percent(interval=0.1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                metric = PerformanceMetric(
                    name="system_metrics",
                    value=cpu_percent,  # Primary metric (CPU)
                    unit="percent",
                    timestamp=datetime.utcnow(),
                    metadata={
                        "cpu_percent": cpu_percent,
                        "memory_percent": memory.percent,
                        "memory_used_gb": memory.used / (1024**3),
                        "memory_available_gb": memory.available / (1024**3),
                        "disk_percent": (disk.used / disk.total) * 100,
                        "disk_free_gb": disk.free / (1024**3)
                    }
                )
                
                self.system_metrics.append(metric)
                
                # Keep only recent metrics to prevent memory bloat
                if len(self.system_metrics) > 10000:
                    self.system_metrics = self.system_metrics[-5000:]
                
                await asyncio.sleep(interval_seconds)
                
            except Exception as e:
                print(f"System monitoring error: {e}")
                await asyncio.sleep(interval_seconds)
    
    def stop_system_monitoring(self):
        """Stop system monitoring."""
        self.monitoring_active = False
    
    def get_system_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of system metrics collected during testing."""
        if not self.system_metrics:
            return {"message": "No system metrics collected"}
        
        cpu_values = [m.metadata["cpu_percent"] for m in self.system_metrics if m.metadata]
        memory_values = [m.metadata["memory_percent"] for m in self.system_metrics if m.metadata]
        
        return {
            "total_samples": len(self.system_metrics),
            "duration_seconds": (
                self.system_metrics[-1].timestamp - self.system_metrics[0].timestamp
            ).total_seconds(),
            "cpu_stats": {
                "average": statistics.mean(cpu_values) if cpu_values else 0,
                "min": min(cpu_values) if cpu_values else 0,
                "max": max(cpu_values) if cpu_values else 0,
                "stdev": statistics.stdev(cpu_values) if len(cpu_values) > 1 else 0
            },
            "memory_stats": {
                "average": statistics.mean(memory_values) if memory_values else 0,
                "min": min(memory_values) if memory_values else 0,
                "max": max(memory_values) if memory_values else 0
            }
        }
    
    # ==============================================================================
    # REPORTING
    # ==============================================================================
    
    def generate_performance_report(self, output_format: str = "json") -> Dict[str, Any]:
        """
        Generate comprehensive performance report.
        
        Args:
            output_format: Output format (json, csv)
            
        Returns:
            Performance report
        """
        if not self.test_results:
            return {"message": "No test results available"}
        
        report = {
            "generated_at": datetime.utcnow().isoformat(),
            "total_tests": len(self.test_results),
            "test_results": [],
            "overall_summary": {},
            "system_metrics_summary": self.get_system_metrics_summary()
        }
        
        # Process each test result
        total_requests = 0
        total_successful = 0
        total_errors = 0
        all_response_times = []
        
        for test_result in self.test_results:
            test_report = {
                "test_name": test_result.test_name,
                "test_type": test_result.test_type.value,
                "duration_seconds": test_result.duration_seconds,
                "start_time": test_result.start_time.isoformat(),
                "end_time": test_result.end_time.isoformat(),
                "summary": test_result.summary,
                "error_count": len(test_result.errors)
            }
            
            # Add metrics to report
            metrics_data = {}
            for metric in test_result.metrics:
                metrics_data[metric.name] = {
                    "value": metric.value,
                    "unit": metric.unit
                }
            test_report["metrics"] = metrics_data
            
            # Add errors if any
            if test_result.errors:
                test_report["errors"] = test_result.errors[:10]  # Limit to first 10 errors
            
            report["test_results"].append(test_report)
            
            # Accumulate totals
            summary = test_result.summary
            total_requests += summary.get("total_requests", 0)
            total_successful += summary.get("successful_requests", 0)
            total_errors += summary.get("failed_requests", 0)
            
            # Collect response times
            response_times = summary.get("response_times", [])
            if response_times:
                all_response_times.extend(response_times)
        
        # Overall summary
        report["overall_summary"] = {
            "total_requests": total_requests,
            "total_successful": total_successful,
            "total_errors": total_errors,
            "overall_success_rate": (total_successful / total_requests * 100) if total_requests > 0 else 0,
            "total_tests_run": len(self.test_results),
            "average_response_time_ms": statistics.mean(all_response_times) if all_response_times else 0,
            "p95_response_time_ms": self._percentile(all_response_times, 95) if all_response_times else 0,
            "p99_response_time_ms": self._percentile(all_response_times, 99) if all_response_times else 0
        }
        
        return report
    
    def export_report_to_file(self, filepath: str, format_type: str = "json"):
        """
        Export performance report to file.
        
        Args:
            filepath: Output file path
            format_type: Export format (json, csv)
        """
        report = self.generate_performance_report(format_type)
        
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        if format_type.lower() == "json":
            with open(filepath, 'w') as f:
                json.dump(report, f, indent=2, default=str)
        
        elif format_type.lower() == "csv":
            # Export summary metrics to CSV
            with open(filepath, 'w', newline='') as f:
                writer = csv.writer(f)
                
                # Header
                writer.writerow([
                    "Test Name", "Test Type", "Duration (s)", "Total Requests",
                    "Successful Requests", "Failed Requests", "Success Rate (%)",
                    "Avg Response Time (ms)", "Min Response Time (ms)", "Max Response Time (ms)",
                    "Error Count"
                ])
                
                # Data rows
                for test_result in self.test_results:
                    summary = test_result.summary
                    response_times = summary.get("response_times", [])
                    
                    writer.writerow([
                        test_result.test_name,
                        test_result.test_type.value,
                        test_result.duration_seconds,
                        summary.get("total_requests", 0),
                        summary.get("successful_requests", 0),
                        summary.get("failed_requests", 0),
                        summary.get("success_rate", 0),
                        statistics.mean(response_times) if response_times else 0,
                        min(response_times) if response_times else 0,
                        max(response_times) if response_times else 0,
                        len(test_result.errors)
                    ])
    
    # ==============================================================================
    # HELPER METHODS
    # ==============================================================================
    
    async def _default_http_request(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Default HTTP request function for testing."""
        # This would be replaced with actual HTTP client implementation
        # For now, simulate a request with random latency
        import random
        
        # Simulate network latency
        await asyncio.sleep(random.uniform(0.01, 0.1))
        
        # Simulate occasional failures
        if random.random() < 0.05:  # 5% failure rate
            return {
                "success": False,
                "status_code": 500,
                "error": "Simulated server error"
            }
        
        return {
            "success": True,
            "status_code": 200,
            "json": {"message": "Success"}
        }
    
    def _create_performance_metrics(self, results: Dict[str, Any], load_factor: float, 
                                  duration: float) -> List[PerformanceMetric]:
        """Create performance metrics from test results."""
        metrics = []
        
        # Response time metrics
        response_times = results.get("response_times", [])
        if response_times:
            metrics.extend([
                PerformanceMetric("avg_response_time_ms", statistics.mean(response_times), "ms", datetime.utcnow()),
                PerformanceMetric("min_response_time_ms", min(response_times), "ms", datetime.utcnow()),
                PerformanceMetric("max_response_time_ms", max(response_times), "ms", datetime.utcnow()),
                PerformanceMetric("median_response_time_ms", statistics.median(response_times), "ms", datetime.utcnow())
            ])
            
            if len(response_times) > 1:
                metrics.append(PerformanceMetric(
                    "response_time_stdev_ms", statistics.stdev(response_times), "ms", datetime.utcnow()
                ))
        
        # Throughput metrics
        total_requests = results.get("total_requests", 0)
        successful_requests = results.get("successful_requests", 0)
        
        metrics.extend([
            PerformanceMetric("total_requests", total_requests, "count", datetime.utcnow()),
            PerformanceMetric("successful_requests", successful_requests, "count", datetime.utcnow()),
            PerformanceMetric("failed_requests", results.get("failed_requests", 0), "count", datetime.utcnow()),
            PerformanceMetric("success_rate", (successful_requests / total_requests * 100) if total_requests > 0 else 0, "percent", datetime.utcnow()),
            PerformanceMetric("requests_per_second", total_requests / duration if duration > 0 else 0, "rps", datetime.utcnow())
        ])
        
        # Load-specific metrics
        if isinstance(load_factor, int):
            metrics.append(PerformanceMetric("concurrent_users", load_factor, "users", datetime.utcnow()))
        else:
            metrics.append(PerformanceMetric("target_rps", load_factor, "rps", datetime.utcnow()))
        
        return metrics
    
    def _create_test_summary(self, results: Dict[str, Any], load_factor: float, 
                           duration: float) -> Dict[str, Any]:
        """Create test summary from results."""
        total_requests = results.get("total_requests", 0)
        successful_requests = results.get("successful_requests", 0)
        failed_requests = results.get("failed_requests", 0)
        response_times = results.get("response_times", [])
        
        summary = {
            "total_requests": total_requests,
            "successful_requests": successful_requests,
            "failed_requests": failed_requests,
            "success_rate": (successful_requests / total_requests * 100) if total_requests > 0 else 0,
            "response_times": response_times,
            "duration_seconds": duration,
            "throughput_rps": total_requests / duration if duration > 0 else 0
        }
        
        # Add load-specific information
        if isinstance(load_factor, int):
            summary["concurrent_users"] = load_factor
            summary["requests_per_user"] = total_requests / load_factor if load_factor > 0 else 0
        else:
            summary["target_rps"] = load_factor
            summary["actual_vs_target_rps"] = (total_requests / duration) / load_factor if load_factor > 0 else 0
        
        return summary
    
    def _percentile(self, data: List[float], percentile: int) -> float:
        """Calculate percentile from data."""
        if not data:
            return 0.0
        
        sorted_data = sorted(data)
        index = (percentile / 100) * (len(sorted_data) - 1)
        
        if index.is_integer():
            return sorted_data[int(index)]
        else:
            lower_index = int(index)
            upper_index = min(lower_index + 1, len(sorted_data) - 1)
            weight = index - lower_index
            return sorted_data[lower_index] * (1 - weight) + sorted_data[upper_index] * weight
    
    def clear_results(self):
        """Clear all test results and metrics."""
        self.test_results.clear()
        self.system_metrics.clear()
    
    def get_test_result_summary(self) -> Dict[str, Any]:
        """Get summary of all test results."""
        if not self.test_results:
            return {"message": "No test results available"}
        
        return {
            "total_tests": len(self.test_results),
            "test_types": list(set(test.test_type.value for test in self.test_results)),
            "total_duration_seconds": sum(test.duration_seconds for test in self.test_results),
            "latest_test": max(self.test_results, key=lambda t: t.end_time).test_name if self.test_results else None,
            "average_success_rate": statistics.mean([
                test.summary.get("success_rate", 0) for test in self.test_results
            ])
        }