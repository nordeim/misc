"""
Test Suite for RAG Tool with ChromaDB Integration.

This module contains comprehensive tests for the RAG tool components including:
- Document processing and chunking
- Embedding service
- ChromaDB operations
- Search functionality
- Performance monitoring
- Cache management
"""

import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from typing import List, Dict, Any

import pytest
import numpy as np

# Import RAG tool components
from app.tools.rag_tool import (
    RAGTool,
    DocumentProcessor,
    EmbeddingService,
    ChromaDBManager,
    SearchEngine,
    DocumentChunk,
    SearchResult,
    ProcessingStats
)

# Import utilities
from app.utils.document_processor import DocumentParser, BatchDocumentProcessor
from app.utils.caching import cache_manager, EmbeddingCache, SearchResultCache
from app.utils.performance_monitor import (
    PerformanceMonitor,
    QueryMetrics,
    performance_monitor
)

# Test configuration
TEST_DATA_DIR = Path(__file__).parent / "test_data"
TEST_DOCUMENTS_DIR = TEST_DATA_DIR / "documents"
TEST_BACKUP_DIR = TEST_DATA_DIR / "backups"

# Create test directories
TEST_DATA_DIR.mkdir(exist_ok=True)
TEST_DOCUMENTS_DIR.mkdir(exist_ok=True)
TEST_BACKUP_DIR.mkdir(exist_ok=True)


class TestDocumentProcessor:
    """Test cases for DocumentProcessor."""
    
    def setup_method(self):
        """Setup test environment."""
        self.processor = DocumentProcessor()
    
    def test_chunk_document_basic(self):
        """Test basic document chunking."""
        content = "This is a long document. " * 100  # Create long content
        chunks = self.processor.chunk_document(content)
        
        assert len(chunks) > 1
        assert all(isinstance(chunk, DocumentChunk) for chunk in chunks)
        assert all(chunk.content for chunk in chunks)
        
        # Check overlap
        for i in range(len(chunks) - 1):
            assert chunks[i].end_char > chunks[i + 1].start_char
    
    def test_chunk_document_short(self):
        """Test chunking of short documents."""
        content = "Short document."
        chunks = self.processor.chunk_document(content)
        
        assert len(chunks) == 1
        assert chunks[0].content == content.strip()
    
    def test_extract_metadata(self):
        """Test metadata extraction."""
        content = "Test document content"
        metadata = self.processor.extract_metadata(content, "/path/to/test.txt")
        
        assert "source_file" in metadata
        assert "content_length" in metadata
        assert "word_count" in metadata
        assert metadata["content_length"] == len(content)
    
    def test_validate_document_valid(self):
        """Test document validation with valid content."""
        content = "This is a valid document with sufficient content."
        is_valid, message = self.processor.validate_document(content)
        
        assert is_valid
        assert message == "Valid"
    
    def test_validate_document_invalid(self):
        """Test document validation with invalid content."""
        # Too short
        content = "Short"
        is_valid, message = self.processor.validate_document(content)
        assert not is_valid
        assert "too short" in message.lower()
        
        # Too much whitespace
        content = "   \n\t   \n   " * 10
        is_valid, message = self.processor.validate_document(content)
        assert not is_valid
        assert "whitespace" in message.lower()


class TestEmbeddingService:
    """Test cases for EmbeddingService."""
    
    def setup_method(self):
        """Setup test environment."""
        self.embedding_service = EmbeddingService()
    
    @pytest.mark.asyncio
    async def test_generate_embedding(self):
        """Test embedding generation."""
        text = "This is a test sentence for embedding generation."
        
        embedding = await self.embedding_service.generate_embedding(text)
        
        assert isinstance(embedding, list)
        assert len(embedding) > 0
        assert all(isinstance(x, float) for x in embedding)
        assert len(embedding) == 384  # Default MiniLM model dimension
    
    @pytest.mark.asyncio
    async def test_generate_embeddings_batch(self):
        """Test batch embedding generation."""
        texts = [
            "First test sentence.",
            "Second test sentence.",
            "Third test sentence."
        ]
        
        embeddings = await self.embedding_service.generate_embeddings_batch(texts)
        
        assert len(embeddings) == len(texts)
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(len(emb) == 384 for emb in embeddings)
    
    @pytest.mark.asyncio
    async def test_embedding_caching(self):
        """Test embedding caching."""
        text = "Cached embedding test."
        
        # First call
        embedding1 = await self.embedding_service.generate_embedding(text)
        
        # Second call should use cache
        embedding2 = await self.embedding_service.generate_embedding(text)
        
        assert embedding1 == embedding2
    
    @pytest.mark.asyncio
    async def test_close(self):
        """Test service cleanup."""
        await self.embedding_service.close()
        # No specific assertion needed, just ensure no errors


class TestChromaDBManager:
    """Test cases for ChromaDBManager."""
    
    def setup_method(self):
        """Setup test environment."""
        self.manager = ChromaDBManager()
        self.test_db_path = TEST_DATA_DIR / "test_chromadb"
    
    @pytest.mark.asyncio
    async def test_initialize(self):
        """Test ChromaDB initialization."""
        # Use test directory
        original_path = self.manager.persist_directory
        self.manager.persist_directory = self.test_db_path
        
        try:
            await self.manager.initialize()
            
            assert self.manager.client is not None
            assert self.manager.collection is not None
            assert self.manager.collection.name == "customer_support_docs"
            
        finally:
            # Restore original path
            self.manager.persist_directory = original_path
    
    @pytest.mark.asyncio
    async def test_add_and_search_documents(self):
        """Test adding and searching documents."""
        # Setup
        original_path = self.manager.persist_directory
        self.manager.persist_directory = self.test_db_path
        
        try:
            await self.manager.initialize()
            
            # Create test chunks
            chunks = [
                DocumentChunk(
                    id="test1",
                    content="This is test document 1",
                    metadata={"type": "test", "doc_id": 1}
                ),
                DocumentChunk(
                    id="test2",
                    content="This is test document 2",
                    metadata={"type": "test", "doc_id": 2}
                )
            ]
            
            # Generate embeddings
            embeddings_service = EmbeddingService()
            await embeddings_service.initialize()
            embeddings = await embeddings_service.generate_embeddings_batch(
                [chunk.content for chunk in chunks]
            )
            
            # Add documents
            ids = await self.manager.add_documents(chunks, embeddings)
            assert len(ids) == 2
            
            # Search
            query_embedding = embeddings[0]
            results = await self.manager.search(query_embedding, n_results=2)
            
            assert "documents" in results
            assert len(results["documents"][0]) > 0
            
        finally:
            # Cleanup
            await self.manager.delete_collection()
            self.manager.persist_directory = original_path


class TestSearchEngine:
    """Test cases for SearchEngine."""
    
    def setup_method(self):
        """Setup test environment."""
        self.chroma_manager = ChromaDBManager()
        self.embedding_service = EmbeddingService()
        self.search_engine = None
    
    @pytest.mark.asyncio
    async def test_semantic_search(self):
        """Test semantic search functionality."""
        # Setup
        self.chroma_manager.persist_directory = TEST_DATA_DIR / "test_search_chromadb"
        await self.chroma_manager.initialize()
        await self.embedding_service.initialize()
        
        self.search_engine = SearchEngine(self.chroma_manager, self.embedding_service)
        
        # Add test document
        test_content = "Python is a programming language used for data science and web development."
        embedding = await self.embedding_service.generate_embedding(test_content)
        
        chunk = DocumentChunk(
            id="test_search",
            content=test_content,
            metadata={"category": "programming"}
        )
        
        await self.chroma_manager.add_documents([chunk], [embedding])
        
        # Test search
        results = await self.search_engine.semantic_search("Python programming", top_k=1)
        
        assert len(results) > 0
        assert isinstance(results[0], SearchResult)
        assert results[0].content == test_content
        assert results[0].similarity_score > 0
        
        # Cleanup
        await self.chroma_manager.delete_collection()
    
    @pytest.mark.asyncio
    async def test_keyword_search(self):
        """Test keyword search functionality."""
        # Setup
        self.chroma_manager.persist_directory = TEST_DATA_DIR / "test_keyword_chromadb"
        await self.chroma_manager.initialize()
        await self.embedding_service.initialize()
        
        self.search_engine = SearchEngine(self.chroma_manager, self.embedding_service)
        
        # Add test documents
        test_docs = [
            "Machine learning algorithms for predictive analytics",
            "Deep learning neural networks and artificial intelligence",
            "Natural language processing for text analysis"
        ]
        
        for i, content in enumerate(test_docs):
            embedding = await self.embedding_service.generate_embedding(content)
            chunk = DocumentChunk(
                id=f"test_doc_{i}",
                content=content,
                metadata={"doc_id": i}
            )
            await self.chroma_manager.add_documents([chunk], [embedding])
        
        # Test keyword search
        results = await self.search_engine.keyword_search("learning algorithms", top_k=2)
        
        assert len(results) > 0
        assert all(isinstance(r, SearchResult) for r in results)
        
        # Cleanup
        await self.chroma_manager.delete_collection()
    
    @pytest.mark.asyncio
    async def test_hybrid_search(self):
        """Test hybrid search functionality."""
        # Setup
        self.chroma_manager.persist_directory = TEST_DATA_DIR / "test_hybrid_chromadb"
        await self.chroma_manager.initialize()
        await self.embedding_service.initialize()
        
        self.search_engine = SearchEngine(self.chroma_manager, self.embedding_service)
        
        # Add test document
        test_content = "Artificial intelligence and machine learning are related fields."
        embedding = await self.embedding_service.generate_embedding(test_content)
        
        chunk = DocumentChunk(
            id="test_hybrid",
            content=test_content,
            metadata={"category": "AI"}
        )
        
        await self.chroma_manager.add_documents([chunk], [embedding])
        
        # Test hybrid search
        results = await self.search_engine.hybrid_search("AI and ML", top_k=1)
        
        assert len(results) > 0
        assert isinstance(results[0], SearchResult)
        assert results[0].combined_score > 0
        
        # Cleanup
        await self.chroma_manager.delete_collection()


class TestRAGTool:
    """Test cases for main RAGTool class."""
    
    def setup_method(self):
        """Setup test environment."""
        self.rag_tool = RAGTool()
        self.test_docs_dir = TEST_DATA_DIR / "rag_test"
        self.test_docs_dir.mkdir(exist_ok=True)
    
    @pytest.mark.asyncio
    async def test_initialize(self):
        """Test RAG tool initialization."""
        await self.rag_tool.initialize()
        
        assert self.rag_tool._initialized
        assert self.rag_tool.document_processor is not None
        assert self.rag_tool.embedding_service is not None
        assert self.rag_tool.chromadb_manager is not None
        assert self.rag_tool.search_engine is not None
    
    @pytest.mark.asyncio
    async def test_add_documents(self):
        """Test adding documents to the knowledge base."""
        await self.rag_tool.initialize()
        
        # Create test documents
        documents = [
            "Python is a high-level programming language.",
            "Machine learning uses algorithms to learn from data.",
            "Natural language processing helps computers understand text."
        ]
        
        # Add documents
        stats = await self.rag_tool.add_documents(documents)
        
        assert isinstance(stats, ProcessingStats)
        assert stats.total_documents == len(documents)
        assert stats.total_chunks > 0
        assert len(stats.errors) == 0  # No errors expected
    
    @pytest.mark.asyncio
    async def test_search(self):
        """Test search functionality."""
        await self.rag_tool.initialize()
        
        # Add test documents
        documents = [
            "Python programming language for data science.",
            "Machine learning algorithms and neural networks.",
            "Deep learning is a subset of machine learning."
        ]
        
        await self.rag_tool.add_documents(documents)
        
        # Test semantic search
        results = await self.rag_tool.search("Python programming", search_type="semantic", top_k=2)
        
        assert "query" in results
        assert "sources" in results
        assert "confidence" in results
        assert len(results["sources"]) > 0
        assert 0 <= results["confidence"] <= 1
    
    @pytest.mark.asyncio
    async def test_similarity_search(self):
        """Test similarity search functionality."""
        await self.rag_tool.initialize()
        
        # Add test document
        await self.rag_tool.add_documents(["Test document for similarity search"])
        
        # Test similarity search
        similar_docs = await self.rag_tool.similarity_search(
            "This is a similar document",
            top_k=1
        )
        
        assert len(similar_docs) > 0
        assert "content" in similar_docs[0]
        assert "similarity" in similar_docs[0]
        assert 0 <= similar_docs[0]["similarity"] <= 1
    
    @pytest.mark.asyncio
    async def test_collection_stats(self):
        """Test collection statistics."""
        await self.rag_tool.initialize()
        
        stats = await self.rag_tool.get_collection_stats()
        
        assert "total_documents" in stats
        assert "collection_name" in stats
        assert isinstance(stats["total_documents"], int)
    
    @pytest.mark.asyncio
    async def test_health_check(self):
        """Test health check functionality."""
        await self.rag_tool.initialize()
        
        health = await self.rag_tool.health_check()
        
        assert "overall_status" in health
        assert "components" in health
        assert "timestamp" in health
        assert health["overall_status"] in ["healthy", "degraded", "unhealthy"]
    
    @pytest.mark.asyncio
    async def test_backup_creation(self):
        """Test backup creation."""
        await self.rag_tool.initialize()
        
        # Add some test data
        await self.rag_tool.add_documents(["Test document for backup"])
        
        # Create backup
        backup_path = TEST_BACKUP_DIR / "test_backup"
        success = await self.rag_tool.create_backup(str(backup_path))
        
        assert success
        assert backup_path.exists()
    
    @pytest.mark.asyncio
    async def test_close(self):
        """Test cleanup functionality."""
        await self.rag_tool.initialize()
        
        # Should not raise any errors
        await self.rag_tool.close()


class TestDocumentProcessor:
    """Test cases for document processing utilities."""
    
    def setup_method(self):
        """Setup test environment."""
        self.parser = DocumentParser()
    
    def test_validate_file_txt(self):
        """Test TXT file validation."""
        # Create temporary TXT file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("This is test content for validation.")
            temp_path = f.name
        
        try:
            status, errors = self.parser._validate_file(Path(temp_path))
            assert status == "valid"
            assert len(errors) == 0
        finally:
            os.unlink(temp_path)
    
    def test_extract_txt_content(self):
        """Test TXT content extraction."""
        content = "Line 1\nLine 2\nLine 3"
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(content)
            temp_path = f.name
        
        try:
            extracted = asyncio.run(self.parser._extract_content(Path(temp_path)))
            assert content in extracted[0]  # Check content is in extracted text
        finally:
            os.unlink(temp_path)
    
    def test_clean_content(self):
        """Test content cleaning functionality."""
        dirty_content = "   This   has    excessive    whitespace   \n\n\n   "
        clean_content = self.parser._clean_content(dirty_content)
        
        assert "  " not in clean_content  # No double spaces
        assert clean_content.strip()  # No leading/trailing whitespace


class TestCaching:
    """Test cases for caching utilities."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_cache_manager = cache_manager
    
    @pytest.mark.asyncio
    async def test_cache_manager_initialize(self):
        """Test cache manager initialization."""
        await self.test_cache_manager.initialize()
        assert self.test_cache_manager._initialized
    
    @pytest.mark.asyncio
    async def test_cache_operations(self):
        """Test basic cache operations."""
        await self.test_cache_manager.initialize()
        cache = self.test_cache_manager.cache
        
        # Test set and get
        await cache.set("test_key", "test_value")
        value = await cache.get("test_key")
        assert value == "test_value"
        
        # Test exists
        assert await cache.exists("test_key")
        
        # Test delete
        await cache.delete("test_key")
        assert not await cache.exists("test_key")
    
    @pytest.mark.asyncio
    async def test_cached_decorator(self):
        """Test cached decorator functionality."""
        await self.test_cache_manager.initialize()
        
        call_count = 0
        
        @self.test_cache_manager.cached(ttl=60)
        async def expensive_function(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2
        
        # First call
        result1 = await expensive_function(5)
        assert result1 == 10
        assert call_count == 1
        
        # Second call should use cache
        result2 = await expensive_function(5)
        assert result2 == 10
        assert call_count == 1  # Should not increase


class TestPerformanceMonitor:
    """Test cases for performance monitoring."""
    
    def setup_method(self):
        """Setup test environment."""
        self.monitor = PerformanceMonitor(max_history=100)
    
    def test_record_metric(self):
        """Test metric recording."""
        self.monitor.record_metric("test_metric", 42.0, "units", {"tag": "value"})
        
        assert "test_metric" in self.monitor._metrics_history
        assert len(self.monitor._metrics_history["test_metric"]) == 1
    
    @pytest.mark.asyncio
    async def test_record_query(self):
        """Test query metrics recording."""
        metrics = QueryMetrics(
            query="test query",
            search_type="semantic",
            execution_time=1.5,
            top_k=5,
            results_count=5,
            confidence_score=0.85,
            memory_usage_mb=100.0,
            embedding_time=0.5,
            search_time=0.8,
            processing_time=0.2,
            timestamp=time.time(),
            success=True
        )
        
        self.monitor.record_query(metrics)
        
        assert len(self.monitor._query_metrics) == 1
        assert self.monitor._stats['total_queries'] == 1
        assert self.monitor._stats['successful_queries'] == 1
    
    def test_get_performance_summary(self):
        """Test performance summary generation."""
        # Add some test data
        self.monitor.record_metric("cpu_usage", 50.0, "percent")
        self.monitor.record_metric("memory_usage", 1024.0, "MB")
        
        summary = self.monitor.get_performance_summary()
        
        assert "timestamp" in summary
        assert "overall_statistics" in summary
        assert "query_performance" in summary
        assert "system_performance" in summary
        assert "recommendations" in summary


# Integration tests
class TestRAGIntegration:
    """Integration tests for complete RAG workflow."""
    
    def setup_method(self):
        """Setup test environment."""
        self.rag_tool = RAGTool()
    
    @pytest.mark.asyncio
    async def test_complete_workflow(self):
        """Test complete RAG workflow from document addition to search."""
        # Initialize
        await self.rag_tool.initialize()
        
        # Add documents
        documents = [
            "Python is a versatile programming language used for web development.",
            "Machine learning algorithms can automatically learn from data.",
            "Natural language processing helps computers understand human language.",
            "Deep learning uses neural networks with multiple layers.",
            "Data science combines statistics, programming, and domain expertise."
        ]
        
        # Process documents
        stats = await self.rag_tool.add_documents(documents)
        assert stats.total_chunks > 0
        
        # Perform different types of searches
        queries = [
            "Python programming",
            "machine learning algorithms",
            "neural networks deep learning",
            "data science and statistics"
        ]
        
        for query in queries:
            # Semantic search
            semantic_results = await self.rag_tool.search(
                query, search_type="semantic", top_k=3
            )
            assert len(semantic_results["sources"]) > 0
            assert semantic_results["confidence"] >= 0
            
            # Hybrid search
            hybrid_results = await self.rag_tool.search(
                query, search_type="hybrid", top_k=3
            )
            assert len(hybrid_results["sources"]) > 0
            assert hybrid_results["confidence"] >= 0
        
        # Get collection statistics
        collection_stats = await self.rag_tool.get_collection_stats()
        assert collection_stats["total_documents"] > 0
        
        # Test health check
        health = await self.rag_tool.health_check()
        assert health["overall_status"] in ["healthy", "degraded"]
        
        # Create backup
        backup_success = await self.rag_tool.create_backup(str(TEST_BACKUP_DIR / "integration_test"))
        assert backup_success
        
        # Cleanup
        await self.rag_tool.delete_collection()


# Test utilities
def create_test_document(content: str, filename: str) -> Path:
    """Create a test document file."""
    file_path = TEST_DOCUMENTS_DIR / filename
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return file_path


def cleanup_test_data():
    """Clean up test data directories."""
    import shutil
    
    if TEST_DATA_DIR.exists():
        shutil.rmtree(TEST_DATA_DIR)
    
    TEST_DATA_DIR.mkdir(exist_ok=True)
    TEST_DOCUMENTS_DIR.mkdir(exist_ok=True)
    TEST_BACKUP_DIR.mkdir(exist_ok=True)


# Fixtures
@pytest.fixture
async def rag_tool():
    """Fixture for RAG tool."""
    tool = RAGTool()
    await tool.initialize()
    yield tool
    await tool.close()


@pytest.fixture
async def cache_manager_fixture():
    """Fixture for cache manager."""
    manager = cache_manager
    await manager.initialize()
    yield manager
    await manager.close()


@pytest.fixture
async def performance_monitor_fixture():
    """Fixture for performance monitor."""
    monitor = PerformanceMonitor()
    monitor.start_monitoring()
    yield monitor
    monitor.stop_monitoring()


# Test execution
if __name__ == "__main__":
    # Run basic tests
    pytest.main([__file__, "-v", "--tb=short"])