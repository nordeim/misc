"""
Comprehensive unit tests for all tools in the backend.

This test module covers:
- Base Tool (abstract base class, lifecycle management, error handling)
- Attachment Tool (file attachment handling, upload/download)
- Enhanced Memory Tool (enhanced memory operations, metadata)
- Escalation Tool (escalation workflows, routing, notifications)
- File Analytics (file analysis, metadata extraction, security scanning)
- File Storage (file storage operations, cloud integration, versioning)
- File Utils (file utilities, validation, processing)
- Memory Tool (basic memory operations, caching)
- RAG Tool (retrieval augmented generation, vector search, chunking)
- Registry (tool registry, discovery, management)
- Utils (general utilities, helpers, validators)
- Patterns (design patterns, observers, decorators)
- Config (configuration management, validation)

Uses pytest fixtures from conftest.py and test utilities from utils package.
"""

import pytest
import asyncio
import json
import time
import tempfile
import os
import hashlib
import mimetypes
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch, MagicMock, call
from pathlib import Path, PosixPath
from typing import Dict, Any, Optional, List, Union
from io import BytesIO
import numpy as np

# Import all tools to test
from app.tools.base_tool import (
    BaseTool,
    ToolStatus,
    ToolPriority,
    ToolError,
    ToolValidationError,
    ToolExecutionError,
    ToolTimeoutError,
    ToolResourceError,
    ToolMetadata,
    ToolResult,
    ToolContext,
    ToolExecutionReport,
    ToolLifecycleManager,
    ToolExecutor,
    ToolMonitor,
    ToolRegistry
)
from app.tools.attachment_tool import (
    AttachmentTool,
    AttachmentHandler,
    FileAttachment,
    AttachmentConfig,
    UploadHandler,
    DownloadHandler
)
from app.tools.enhanced_memory_tool import (
    EnhancedMemoryTool,
    MemoryEntry,
    MemoryMetadata,
    MemoryIndex,
    SearchResult,
    MemoryStore
)
from app.tools.escalation_tool import (
    EscalationTool,
    EscalationRule,
    EscalationLevel,
    EscalationAction,
    EscalationManager,
    NotificationHandler,
    RoutingHandler
)
from app.tools.file_analytics import (
    FileAnalytics,
    FileAnalyzer,
    MetadataExtractor,
    SecurityScanner,
    ContentAnalyzer,
    AnalyticsReport
)
from app.tools.file_storage import (
    FileStorage,
    StorageProvider,
    LocalStorageProvider,
    CloudStorageProvider,
    StorageConfig,
    FileVersion,
    StorageMetrics
)
from app.tools.file_utils import (
    FileUtils,
    FileValidator,
    FileProcessor,
    FileConverter,
    FileWatcher,
    FileBackup
)
from app.tools.memory_tool import (
    MemoryTool,
    MemoryCache,
    MemoryEntry as BasicMemoryEntry,
    MemoryManager
)
from app.tools.rag_tool import (
    RAGTool,
    DocumentChunker,
    VectorStore,
    EmbeddingProvider,
    RetrievalConfig,
    SearchEngine,
    RAGIndex
)
from app.tools.registry import (
    ToolRegistry,
    RegistryEntry,
    RegistryManager,
    DiscoveryService,
    LoadBalancer,
    HealthChecker
)
from app.tools.utils import (
    ToolUtils,
    ValidationUtils,
    CryptoUtils,
    TimeUtils,
    JsonUtils,
    PathUtils,
    TypeUtils
)
from app.tools.patterns import (
    ObserverPattern,
    DecoratorPattern,
    FactoryPattern,
    StrategyPattern,
    EventBus,
    CommandPattern
)
from app.tools.config import (
    ToolConfig,
    ConfigManager,
    ConfigValidator,
    EnvironmentConfig,
    ConfigSource,
    ConfigParser
)

# Import test utilities
from tests.utils.test_data_generator import TestDataGenerator
from tests.utils.auth_helpers import AuthTestHelper
from tests.utils.performance_testing import PerformanceProfiler


# =============================================================================
# BASE TOOL TESTS
# =============================================================================

class TestBaseTool:
    """Test BaseTool abstract class and functionality."""
    
    @pytest.fixture
    def concrete_tool(self):
        """Create a concrete implementation of BaseTool for testing."""
        class TestTool(BaseTool):
            def __init__(self):
                super().__init__(
                    name="test_tool",
                    description="Test tool implementation",
                    version="1.0.0"
                )
                self.execution_count = 0
            
            async def execute(self, **kwargs) -> ToolResult:
                self.execution_count += 1
                return ToolResult(
                    success=True,
                    data={"message": "Test execution completed", "count": self.execution_count}
                )
            
            async def validate(self, **kwargs) -> bool:
                return "test_param" in kwargs
            
            def get_metadata(self) -> ToolMetadata:
                return ToolMetadata(
                    name=self.name,
                    version=self.version,
                    description=self.description,
                    category="test"
                )
        
        return TestTool()
    
    @pytest.mark.asyncio
    async def test_tool_initialization(self, concrete_tool):
        """Test tool initialization and basic properties."""
        assert concrete_tool.name == "test_tool"
        assert concrete_tool.version == "1.0.0"
        assert concrete_tool.description == "Test tool implementation"
        assert concrete_tool.status == ToolStatus.IDLE
        assert concrete_tool.execution_count == 0
    
    @pytest.mark.asyncio
    async def test_tool_execution(self, concrete_tool):
        """Test tool execution functionality."""
        # Valid execution
        result = await concrete_tool.execute(test_param="value")
        
        assert isinstance(result, ToolResult)
        assert result.success is True
        assert "message" in result.data
        assert result.data["count"] == 1
        assert concrete_tool.execution_count == 1
        
        # Second execution
        result = await concrete_tool.execute(test_param="value")
        assert result.data["count"] == 2
    
    @pytest.mark.asyncio
    async def test_tool_validation(self, concrete_tool):
        """Test tool input validation."""
        # Valid input
        is_valid = await concrete_tool.validate(test_param="value")
        assert is_valid is True
        
        # Invalid input
        is_valid = await concrete_tool.validate(invalid_param="value")
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_tool_error_handling(self):
        """Test tool error handling."""
        class ErrorTool(BaseTool):
            def __init__(self):
                super().__init__(name="error_tool", description="Error tool")
            
            async def execute(self, **kwargs):
                raise ValueError("Test error")
        
        tool = ErrorTool()
        
        with pytest.raises(ToolExecutionError):
            await tool.execute()
    
    @pytest.mark.asyncio
    async def test_tool_timeout(self, concrete_tool):
        """Test tool timeout handling."""
        class SlowTool(BaseTool):
            def __init__(self):
                super().__init__(name="slow_tool", description="Slow tool")
            
            async def execute(self, **kwargs):
                await asyncio.sleep(10)  # Simulate long operation
                return ToolResult(success=True, data={})
        
        tool = SlowTool()
        
        with pytest.raises(ToolTimeoutError):
            await tool.execute(timeout=1.0)
    
    def test_tool_status_enum(self):
        """Test tool status enumeration."""
        assert ToolStatus.IDLE.value == "idle"
        assert ToolStatus.RUNNING.value == "running"
        assert ToolStatus.SUCCESS.value == "success"
        assert ToolStatus.FAILED.value == "failed"
        assert ToolStatus.TIMEOUT.value == "timeout"
        assert ToolStatus.CANCELLED.value == "cancelled"
    
    def test_tool_priority_enum(self):
        """Test tool priority enumeration."""
        assert ToolPriority.CRITICAL.value == 1
        assert ToolPriority.HIGH.value == 2
        assert ToolPriority.NORMAL.value == 3
        assert ToolPriority.LOW.value == 4
        assert ToolPriority.BACKGROUND.value == 5
    
    def test_tool_metadata(self):
        """Test tool metadata structure."""
        metadata = ToolMetadata(
            name="test_tool",
            version="1.0.0",
            description="Test tool description",
            category="testing",
            tags=["test", "debug"],
            dependencies=["dependency1", "dependency2"],
            supported_formats=["json", "xml"]
        )
        
        assert metadata.name == "test_tool"
        assert metadata.version == "1.0.0"
        assert metadata.category == "testing"
        assert "test" in metadata.tags
        assert "dependency1" in metadata.dependencies
        assert "json" in metadata.supported_formats
    
    @pytest.mark.asyncio
    async def test_tool_lifecycle_manager(self):
        """Test tool lifecycle management."""
        lifecycle_manager = ToolLifecycleManager()
        
        # Test tool registration
        tool = Mock()
        tool.name = "test_tool"
        lifecycle_manager.register_tool(tool)
        
        assert "test_tool" in lifecycle_manager.tools
        assert lifecycle_manager.tools["test_tool"] == tool
        
        # Test tool lifecycle operations
        await lifecycle_manager.initialize_tool("test_tool")
        await lifecycle_manager.start_tool("test_tool")
        await lifecycle_manager.stop_tool("test_tool")
        await lifecycle_manager.cleanup_tool("test_tool")
    
    @pytest.mark.asyncio
    async def test_tool_executor(self):
        """Test tool executor functionality."""
        executor = ToolExecutor(max_concurrent=2)
        
        # Create test tools
        tools = [Mock() for _ in range(3)]
        for i, tool in enumerate(tools):
            tool.execute = AsyncMock(return_value=ToolResult(success=True, data={"id": i}))
        
        # Test parallel execution
        results = await executor.execute_parallel(tools, timeout=5.0)
        
        assert len(results) == 3
        assert all(result.success for result in results)
        assert all("id" in result.data for result in results)
    
    @pytest.mark.asyncio
    async def test_tool_monitor(self):
        """Test tool monitoring functionality."""
        monitor = ToolMonitor()
        
        # Create test tool
        tool = Mock()
        tool.name = "test_tool"
        tool.status = ToolStatus.IDLE
        
        # Test monitoring
        metrics = await monitor.collect_metrics(tool)
        
        assert isinstance(metrics, dict)
        assert "status" in metrics
        assert "execution_count" in metrics
        assert "last_execution_time" in metrics


# =============================================================================
# ATTACHMENT TOOL TESTS
# =============================================================================

class TestAttachmentTool:
    """Test attachment tool functionality."""
    
    @pytest.fixture
    def attachment_tool(self):
        """Create attachment tool instance."""
        config = AttachmentConfig(
            max_file_size=10 * 1024 * 1024,  # 10MB
            allowed_extensions=[".txt", ".pdf", ".png", ".jpg"],
            storage_path="/tmp/test_attachments"
        )
        return AttachmentTool(config=config)
    
    @pytest.fixture
    def sample_file(self):
        """Create a sample file for testing."""
        content = b"This is a test file content"
        return BytesIO(content)
    
    @pytest.mark.asyncio
    async def test_attachment_initialization(self, attachment_tool):
        """Test attachment tool initialization."""
        assert attachment_tool.config.max_file_size == 10 * 1024 * 1024
        assert ".txt" in attachment_tool.config.allowed_extensions
        assert attachment_tool.storage_path == "/tmp/test_attachments"
    
    @pytest.mark.asyncio
    async def test_file_upload(self, attachment_tool, sample_file):
        """Test file upload functionality."""
        # Mock storage operations
        with patch.object(attachment_tool, '_save_file') as mock_save:
            mock_save.return_value = AsyncMock(return_value="attachment_id_123")
            
            attachment = FileAttachment(
                filename="test.txt",
                content_type="text/plain",
                size=len(sample_file.getvalue())
            )
            
            result = await attachment_tool.upload(attachment, sample_file)
            
            assert result.success is True
            assert result.attachment_id == "attachment_id_123"
            mock_save.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_file_download(self, attachment_tool):
        """Test file download functionality."""
        # Mock storage retrieval
        with patch.object(attachment_tool, '_retrieve_file') as mock_retrieve:
            mock_content = BytesIO(b"Downloaded content")
            mock_retrieve.return_value = AsyncMock(return_value=mock_content)
            
            result = await attachment_tool.download("attachment_id_123")
            
            assert result.success is True
            assert result.content is not None
            mock_retrieve.assert_called_once_with("attachment_id_123")
    
    @pytest.mark.asyncio
    async def test_file_validation(self, attachment_tool, sample_file):
        """Test file validation."""
        # Test valid file
        attachment = FileAttachment(
            filename="test.txt",
            content_type="text/plain",
            size=len(sample_file.getvalue())
        )
        
        is_valid = await attachment_tool.validate_file(attachment, sample_file)
        assert is_valid is True
        
        # Test invalid extension
        invalid_attachment = FileAttachment(
            filename="test.exe",
            content_type="application/octet-stream",
            size=1024
        )
        
        is_valid = await attachment_tool.validate_file(invalid_attachment, sample_file)
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_attachment_deletion(self, attachment_tool):
        """Test attachment deletion."""
        with patch.object(attachment_tool, '_delete_file') as mock_delete:
            mock_delete.return_value = AsyncMock(return_value=True)
            
            result = await attachment_tool.delete("attachment_id_123")
            
            assert result.success is True
            mock_delete.assert_called_once_with("attachment_id_123")
    
    @pytest.mark.asyncio
    async def test_attachment_listing(self, attachment_tool):
        """Test attachment listing."""
        # Mock storage listing
        mock_attachments = [
            FileAttachment(
                attachment_id="id1",
                filename="file1.txt",
                content_type="text/plain",
                size=1024,
                created_at=datetime.now()
            ),
            FileAttachment(
                attachment_id="id2", 
                filename="file2.pdf",
                content_type="application/pdf",
                size=2048,
                created_at=datetime.now()
            )
        ]
        
        with patch.object(attachment_tool, '_list_attachments') as mock_list:
            mock_list.return_value = AsyncMock(return_value=mock_attachments)
            
            attachments = await attachment_tool.list()
            
            assert len(attachments) == 2
            assert attachments[0].filename == "file1.txt"
            assert attachments[1].filename == "file2.pdf"


# =============================================================================
# ENHANCED MEMORY TOOL TESTS
# =============================================================================

class TestEnhancedMemoryTool:
    """Test enhanced memory tool functionality."""
    
    @pytest.fixture
    def memory_tool(self):
        """Create enhanced memory tool instance."""
        return EnhancedMemoryTool()
    
    @pytest.mark.asyncio
    async def test_memory_entry_creation(self, memory_tool):
        """Test memory entry creation and storage."""
        metadata = MemoryMetadata(
            key="test_key",
            value="test_value",
            tags=["test", "memory"],
            ttl=3600,
            metadata={"source": "test"}
        )
        
        entry = await memory_tool.create_entry(metadata)
        
        assert entry.key == "test_key"
        assert entry.value == "test_value"
        assert "test" in entry.metadata.tags
        assert entry.metadata.ttl == 3600
    
    @pytest.mark.asyncio
    async def test_memory_search(self, memory_tool):
        """Test memory search functionality."""
        # Create test entries
        entries = [
            MemoryEntry(
                key="key1",
                value="value1",
                metadata=MemoryMetadata(key="key1", value="value1", tags=["tag1"])
            ),
            MemoryEntry(
                key="key2",
                value="value2", 
                metadata=MemoryMetadata(key="key2", value="value2", tags=["tag2"])
            )
        ]
        
        # Mock search operations
        with patch.object(memory_tool._index, 'search') as mock_search:
            mock_search.return_value = [
                SearchResult(entry=entries[0], score=0.9, highlights=["value1"]),
                SearchResult(entry=entries[1], score=0.8, highlights=["value2"])
            ]
            
            results = await memory_tool.search("value", tags=["tag1", "tag2"])
            
            assert len(results) == 2
            assert results[0].score > results[1].score
    
    @pytest.mark.asyncio
    async def test_memory_indexing(self, memory_tool):
        """Test memory indexing functionality."""
        entry = MemoryEntry(
            key="index_test",
            value="This is a test entry for indexing",
            metadata=MemoryMetadata(
                key="index_test",
                value="This is a test entry for indexing",
                tags=["indexing", "test"]
            )
        )
        
        # Mock indexing operations
        with patch.object(memory_tool._index, 'add_entry') as mock_add:
            mock_add.return_value = AsyncMock(return_value=True)
            
            result = await memory_tool.index_entry(entry)
            
            assert result is True
            mock_add.assert_called_once_with(entry)
    
    @pytest.mark.asyncio
    async def test_memory_cleanup(self, memory_tool):
        """Test memory cleanup for expired entries."""
        # Mock expired entries
        expired_entries = ["expired1", "expired2"]
        
        with patch.object(memory_tool._store, 'get_expired_keys') as mock_expired:
            mock_expired.return_value = AsyncMock(return_value=expired_entries)
            
            with patch.object(memory_tool._store, 'delete_entries') as mock_delete:
                mock_delete.return_value = AsyncMock(return_value=2)
                
                deleted_count = await memory_tool.cleanup_expired()
                
                assert deleted_count == 2
                mock_expired.assert_called_once()
                mock_delete.assert_called_once_with(expired_entries)
    
    @pytest.mark.asyncio
    async def test_memory_export_import(self, memory_tool):
        """Test memory export and import functionality."""
        # Create test entries
        test_entries = [
            MemoryEntry(
                key="export1",
                value="export_value1",
                metadata=MemoryMetadata(key="export1", value="export_value1", tags=["export"])
            )
        ]
        
        # Test export
        with patch.object(memory_tool._store, 'get_all_entries') as mock_get_all:
            mock_get_all.return_value = AsyncMock(return_value=test_entries)
            
            export_data = await memory_tool.export_memory(format="json")
            
            assert "entries" in export_data
            assert len(export_data["entries"]) == 1
            assert export_data["entries"][0]["key"] == "export1"
        
        # Test import
        import_data = {
            "entries": [
                {
                    "key": "import1",
                    "value": "import_value1",
                    "metadata": {
                        "key": "import1",
                        "value": "import_value1",
                        "tags": ["import"]
                    }
                }
            ]
        }
        
        with patch.object(memory_tool._store, 'import_entries') as mock_import:
            mock_import.return_value = AsyncMock(return_value=1)
            
            result = await memory_tool.import_memory(import_data)
            
            assert result.imported_count == 1
            mock_import.assert_called_once()


# =============================================================================
# ESCALATION TOOL TESTS
# =============================================================================

class TestEscalationTool:
    """Test escalation tool functionality."""
    
    @pytest.fixture
    def escalation_tool(self):
        """Create escalation tool instance."""
        return EscalationTool()
    
    @pytest.mark.asyncio
    async def test_escalation_rule_creation(self, escalation_tool):
        """Test escalation rule creation."""
        rule = EscalationRule(
            name="high_priority_rule",
            conditions={"priority": "high", "category": "technical"},
            actions=[EscalationAction.NOTIFY_MANAGER, EsCallationAction.CREATE_TICKET],
            escalation_level=EscalationLevel.HIGH,
            timeout=3600
        )
        
        assert rule.name == "high_priority_rule"
        assert rule.conditions["priority"] == "high"
        assert EscalationAction.NOTIFY_MANAGER in rule.actions
        assert rule.escalation_level == EscalationLevel.HIGH
    
    @pytest.mark.asyncio
    async def test_escalation_evaluation(self, escalation_tool):
        """Test escalation rule evaluation."""
        rule = EscalationRule(
            name="test_rule",
            conditions={"priority": "high", "count": {"gte": 3}},
            actions=[EscalationAction.NOTIFY_TEAM],
            escalation_level=EscalationLevel.MEDIUM
        )
        
        # Test matching conditions
        context = {"priority": "high", "count": 5, "user": "test_user"}
        matches = await escalation_tool.evaluate_rule(rule, context)
        
        assert matches is True
        
        # Test non-matching conditions
        context = {"priority": "low", "count": 1, "user": "test_user"}
        matches = await escalation_tool.evaluate_rule(rule, context)
        
        assert matches is False
    
    @pytest.mark.asyncio
    async def test_escalation_execution(self, escalation_tool):
        """Test escalation action execution."""
        rule = EscalationRule(
            name="test_rule",
            conditions={"always": True},
            actions=[EscalationAction.NOTIFY_MANAGER],
            escalation_level=EscalationLevel.HIGH
        )
        
        context = {"user": "test_user", "issue": "test_issue"}
        
        # Mock escalation actions
        with patch.object(escalation_tool._notification_handler, 'notify') as mock_notify:
            mock_notify.return_value = AsyncMock(return_value=True)
            
            result = await escalation_tool.execute_escalation(rule, context)
            
            assert result.success is True
            assert result.actions_executed == [EscalationAction.NOTIFY_MANAGER]
            mock_notify.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_escalation_workflow(self, escalation_tool):
        """Test complete escalation workflow."""
        rules = [
            EscalationRule(
                name="rule1",
                conditions={"priority": "high"},
                actions=[EscalationAction.NOTIFY_TEAM],
                escalation_level=EscalationLevel.LOW
            ),
            EscalationRule(
                name="rule2", 
                conditions={"priority": "critical"},
                actions=[EscalationAction.ESCALATE_MANAGER],
                escalation_level=EscalationLevel.HIGH
            )
        ]
        
        context = {"priority": "high", "user": "test_user"}
        
        # Mock escalation execution
        with patch.object(escalation_tool, 'execute_escalation') as mock_execute:
            mock_execute.return_value = AsyncMock(return_value=Mock(success=True))
            
            results = await escalation_tool.process_escalation(rules, context)
            
            assert len(results) == 1
            mock_execute.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_escalation_manager(self):
        """Test escalation manager functionality."""
        manager = EscalationManager()
        
        # Test rule registration
        rule = EscalationRule(
            name="registered_rule",
            conditions={"test": True},
            actions=[EscalationAction.NOTIFY_TEAM],
            escalation_level=EscalationLevel.LOW
        )
        
        await manager.register_rule(rule)
        assert "registered_rule" in manager.rules
        
        # Test rule retrieval
        retrieved_rule = await manager.get_rule("registered_rule")
        assert retrieved_rule.name == "registered_rule"


# =============================================================================
# FILE ANALYTICS TESTS
# =============================================================================

class TestFileAnalytics:
    """Test file analytics functionality."""
    
    @pytest.fixture
    def file_analytics(self):
        """Create file analytics instance."""
        return FileAnalytics()
    
    @pytest.fixture
    def sample_text_file(self):
        """Create sample text file for testing."""
        content = b"This is a sample text file.\nIt has multiple lines.\nAnd some content for analysis."
        return BytesIO(content)
    
    @pytest.mark.asyncio
    async def test_file_metadata_extraction(self, file_analytics, sample_text_file):
        """Test file metadata extraction."""
        # Mock file analysis
        with patch.object(file_analytics._metadata_extractor, 'extract') as mock_extract:
            mock_metadata = {
                "size": len(sample_text_file.getvalue()),
                "mime_type": "text/plain",
                "encoding": "utf-8",
                "lines": 3,
                "words": 15,
                "characters": 89
            }
            mock_extract.return_value = AsyncMock(return_value=mock_metadata)
            
            result = await file_analytics.analyze_metadata(sample_text_file)
            
            assert result.size == len(sample_text_file.getvalue())
            assert result.mime_type == "text/plain"
            assert result.lines == 3
            assert result.words == 15
    
    @pytest.mark.asyncio
    async def test_security_scanning(self, file_analytics, sample_text_file):
        """Test security scanning functionality."""
        # Test clean file
        with patch.object(file_analytics._security_scanner, 'scan') as mock_scan:
            mock_scan.return_value = AsyncMock(return_value={
                "is_safe": True,
                "threats": [],
                "confidence": 1.0
            })
            
            result = await file_analytics.scan_security(sample_text_file)
            
            assert result.is_safe is True
            assert len(result.threats) == 0
            assert result.confidence == 1.0
        
        # Test file with potential threats
        malicious_content = b"<script>alert('xss')</script>"
        malicious_file = BytesIO(malicious_content)
        
        with patch.object(file_analytics._security_scanner, 'scan') as mock_scan:
            mock_scan.return_value = AsyncMock(return_value={
                "is_safe": False,
                "threats": ["XSS_POTENTIAL"],
                "confidence": 0.8
            })
            
            result = await file_analytics.scan_security(malicious_file)
            
            assert result.is_safe is False
            assert "XSS_POTENTIAL" in result.threats
    
    @pytest.mark.asyncio
    async def test_content_analysis(self, file_analytics, sample_text_file):
        """Test content analysis functionality."""
        with patch.object(file_analytics._content_analyzer, 'analyze') as mock_analyze:
            mock_analysis = {
                "language": "en",
                "sentiment": "neutral",
                "complexity": "medium",
                "readability_score": 65.5,
                "key_topics": ["sample", "text", "file"]
            }
            mock_analyze.return_value = AsyncMock(return_value=mock_analysis)
            
            result = await file_analytics.analyze_content(sample_text_file)
            
            assert result.language == "en"
            assert result.sentiment == "neutral"
            assert result.complexity == "medium"
            assert result.readability_score == 65.5
            assert "sample" in result.key_topics
    
    @pytest.mark.asyncio
    async def test_analytics_report_generation(self, file_analytics, sample_text_file):
        """Test comprehensive analytics report generation."""
        with patch.multiple(
            file_analytics,
            analyze_metadata=AsyncMock(return_value=Mock(size=100, mime_type="text/plain")),
            scan_security=AsyncMock(return_value=Mock(is_safe=True, threats=[])),
            analyze_content=AsyncMock(return_value=Mock(language="en", sentiment="neutral"))
        ):
            report = await file_analytics.generate_full_report(sample_text_file)
            
            assert isinstance(report, AnalyticsReport)
            assert report.metadata is not None
            assert report.security_scan is not None
            assert report.content_analysis is not None
            assert report.timestamp is not None
    
    @pytest.mark.asyncio
    async def test_batch_analysis(self, file_analytics):
        """Test batch file analysis."""
        files = [BytesIO(b"File 1 content"), BytesIO(b"File 2 content"), BytesIO(b"File 3 content")]
        
        with patch.object(file_analytics, 'generate_full_report') as mock_report:
            mock_report.side_effect = [
                AsyncMock(return_value=Mock(file_id="file1", summary="Analysis 1")),
                AsyncMock(return_value=Mock(file_id="file2", summary="Analysis 2")),
                AsyncMock(return_value=Mock(file_id="file3", summary="Analysis 3"))
            ]
            
            results = await file_analytics.batch_analyze(files)
            
            assert len(results) == 3
            assert results[0].file_id == "file1"
            assert results[1].file_id == "file2"
            assert results[2].file_id == "file3"


# =============================================================================
# FILE STORAGE TESTS
# =============================================================================

class TestFileStorage:
    """Test file storage functionality."""
    
    @pytest.fixture
    def storage_config(self):
        """Create storage configuration."""
        return StorageConfig(
            provider="local",
            base_path="/tmp/test_storage",
            max_file_size=100 * 1024 * 1024,  # 100MB
            enable_versioning=True,
            backup_enabled=True
        )
    
    @pytest.fixture
    def file_storage(self, storage_config):
        """Create file storage instance."""
        return FileStorage(config=storage_config)
    
    @pytest.mark.asyncio
    async def test_storage_initialization(self, file_storage, storage_config):
        """Test storage initialization."""
        assert file_storage.config.provider == "local"
        assert file_storage.config.max_file_size == 100 * 1024 * 1024
        assert file_storage.config.enable_versioning is True
        assert file_storage.config.backup_enabled is True
    
    @pytest.mark.asyncio
    async def test_file_upload(self, file_storage):
        """Test file upload functionality."""
        content = b"Test file content for upload"
        file_obj = BytesIO(content)
        filename = "test_file.txt"
        
        # Mock storage provider
        with patch.object(file_storage._provider, 'upload') as mock_upload:
            mock_upload.return_value = AsyncMock(return_value="file_id_123")
            
            result = await file_storage.upload_file(file_obj, filename)
            
            assert result.success is True
            assert result.file_id == "file_id_123"
            mock_upload.assert_called_once_with(file_obj, filename)
    
    @pytest.mark.asyncio
    async def test_file_download(self, file_storage):
        """Test file download functionality."""
        # Mock storage provider
        with patch.object(file_storage._provider, 'download') as mock_download:
            mock_content = BytesIO(b"Downloaded file content")
            mock_download.return_value = AsyncMock(return_value=mock_content)
            
            result = await file_storage.download_file("file_id_123")
            
            assert result.success is True
            assert result.content is not None
            mock_download.assert_called_once_with("file_id_123")
    
    @pytest.mark.asyncio
    async def test_file_deletion(self, file_storage):
        """Test file deletion."""
        with patch.object(file_storage._provider, 'delete') as mock_delete:
            mock_delete.return_value = AsyncMock(return_value=True)
            
            result = await file_storage.delete_file("file_id_123")
            
            assert result.success is True
            mock_delete.assert_called_once_with("file_id_123")
    
    @pytest.mark.asyncio
    async def test_file_versioning(self, file_storage):
        """Test file versioning functionality."""
        file_id = "test_file"
        
        # Mock versioning operations
        with patch.object(file_storage._version_manager, 'create_version') as mock_create:
            mock_create.return_value = AsyncMock(return_value=FileVersion(
                version_id="v1",
                file_id=file_id,
                created_at=datetime.now(),
                size=len(b"version content")
            ))
            
            version = await file_storage.create_version(file_id, BytesIO(b"version content"))
            
            assert version.version_id == "v1"
            assert version.file_id == file_id
            mock_create.assert_called_once()
        
        # Test version listing
        with patch.object(file_storage._version_manager, 'list_versions') as mock_list:
            mock_list.return_value = AsyncMock(return_value=[
                FileVersion(version_id="v1", file_id=file_id, created_at=datetime.now(), size=100),
                FileVersion(version_id="v2", file_id=file_id, created_at=datetime.now(), size=200)
            ])
            
            versions = await file_storage.list_versions(file_id)
            
            assert len(versions) == 2
            assert versions[0].version_id == "v1"
            assert versions[1].version_id == "v2"
    
    @pytest.mark.asyncio
    async def test_storage_metrics(self, file_storage):
        """Test storage metrics collection."""
        with patch.object(file_storage._metrics_collector, 'collect') as mock_collect:
            mock_metrics = StorageMetrics(
                total_files=150,
                total_size=1024 * 1024 * 50,  # 50MB
                available_space=1024 * 1024 * 500,  # 500MB
                version_count=300,
                backup_count=150
            )
            mock_collect.return_value = AsyncMock(return_value=mock_metrics)
            
            metrics = await file_storage.get_metrics()
            
            assert metrics.total_files == 150
            assert metrics.total_size == 1024 * 1024 * 50
            assert metrics.available_space == 1024 * 1024 * 500
            assert metrics.version_count == 300
            assert metrics.backup_count == 150
    
    @pytest.mark.asyncio
    async def test_storage_backup(self, file_storage):
        """Test storage backup functionality."""
        with patch.object(file_storage._backup_manager, 'create_backup') as mock_backup:
            mock_backup.return_value = AsyncMock(return_value="backup_id_123")
            
            result = await file_storage.create_backup("full")
            
            assert result.success is True
            assert result.backup_id == "backup_id_123"
            mock_backup.assert_called_once_with("full")


# =============================================================================
# FILE UTILS TESTS
# =============================================================================

class TestFileUtils:
    """Test file utilities functionality."""
    
    @pytest.fixture
    def file_utils(self):
        """Create file utils instance."""
        return FileUtils()
    
    @pytest.mark.asyncio
    async def test_file_validation(self, file_utils):
        """Test file validation functionality."""
        # Test valid file
        valid_file = BytesIO(b"Valid file content")
        is_valid = await file_utils.validate_file(valid_file, max_size=1024)
        assert is_valid is True
        
        # Test file too large
        large_content = b"x" * 2048  # 2KB
        large_file = BytesIO(large_content)
        is_valid = await file_utils.validate_file(large_file, max_size=1024)
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_file_processing(self, file_utils):
        """Test file processing functionality."""
        content = b"Line 1\nLine 2\nLine 3\n"
        file_obj = BytesIO(content)
        
        # Test text processing
        processed = await file_utils.process_text(file_obj, encoding="utf-8")
        assert processed == content.decode("utf-8")
        assert len(processed.splitlines()) == 3
    
    @pytest.mark.asyncio
    async def test_file_conversion(self, file_utils):
        """Test file format conversion."""
        # Test JSON to XML conversion
        json_data = {"key": "value", "number": 42}
        xml_result = await file_utils.convert_format(json_data, "json", "xml")
        
        assert "<key>value</key>" in xml_result
        assert "<number>42</number>" in xml_result
        
        # Test XML to JSON conversion
        xml_data = "<root><key>value</key><number>42</number></root>"
        json_result = await file_utils.convert_format(xml_data, "xml", "json")
        
        parsed_json = json.loads(json_result)
        assert parsed_json["key"] == "value"
        assert parsed_json["number"] == 42
    
    @pytest.mark.asyncio
    async def test_file_watcher(self, file_utils):
        """Test file watching functionality."""
        # Mock file system events
        with patch('watchdog.observers.Observer') as mock_observer:
            mock_file_event_handler = Mock()
            mock_observer.return_value = Mock()
            
            watcher = await file_utils.create_file_watcher("/tmp/test", [".txt"])
            
            assert watcher is not None
            # Additional assertions would depend on specific watchdog implementation
    
    @pytest.mark.asyncio
    async def test_file_backup(self, file_utils):
        """Test file backup functionality."""
        source_content = b"Source file content"
        source_file = BytesIO(source_content)
        
        with patch('tempfile.NamedTemporaryFile') as mock_temp:
            mock_temp.return_value.__enter__.return_value.name = "/tmp/backup_file"
            mock_temp.return_value.__enter__.return_value.write.return_value = None
            
            backup_path = await file_utils.create_backup(source_file)
            
            assert backup_path.startswith("/tmp/backup_file")
            mock_temp.assert_called_once()


# =============================================================================
# MEMORY TOOL TESTS
# =============================================================================

class TestMemoryTool:
    """Test basic memory tool functionality."""
    
    @pytest.fixture
    def memory_tool(self):
        """Create memory tool instance."""
        return MemoryTool()
    
    @pytest.mark.asyncio
    async def test_memory_storage(self, memory_tool):
        """Test basic memory storage."""
        entry = BasicMemoryEntry(
            key="test_memory",
            value="test_value",
            ttl=3600
        )
        
        result = await memory_tool.store(entry)
        assert result.success is True
    
    @pytest.mark.asyncio
    async def test_memory_retrieval(self, memory_tool):
        """Test memory retrieval."""
        # Store a memory entry
        entry = BasicMemoryEntry(key="retrieve_test", value="retrieve_value", ttl=3600)
        await memory_tool.store(entry)
        
        # Retrieve the memory
        retrieved = await memory_tool.retrieve("retrieve_test")
        assert retrieved is not None
        assert retrieved.key == "retrieve_test"
        assert retrieved.value == "retrieve_value"
    
    @pytest.mark.asyncio
    async def test_memory_deletion(self, memory_tool):
        """Test memory deletion."""
        # Store a memory entry
        entry = BasicMemoryEntry(key="delete_test", value="delete_value", ttl=3600)
        await memory_tool.store(entry)
        
        # Delete the memory
        result = await memory_tool.delete("delete_test")
        assert result.success is True
        
        # Verify deletion
        retrieved = await memory_tool.retrieve("delete_test")
        assert retrieved is None
    
    @pytest.mark.asyncio
    async def test_memory_cache(self, memory_tool):
        """Test memory caching functionality."""
        # Test cache operations
        await memory_tool.cache.set("cached_key", "cached_value", ttl=300)
        
        cached_value = await memory_tool.cache.get("cached_key")
        assert cached_value == "cached_value"
        
        # Test cache invalidation
        await memory_tool.cache.delete("cached_key")
        cached_value = await memory_tool.cache.get("cached_key")
        assert cached_value is None
    
    @pytest.mark.asyncio
    async def test_memory_manager(self, memory_tool):
        """Test memory manager operations."""
        # Test memory listing
        entries = await memory_tool.list_memories(limit=10)
        assert isinstance(entries, list)
        
        # Test memory cleanup
        cleaned_count = await memory_tool.cleanup_expired()
        assert isinstance(cleaned_count, int)
        assert cleaned_count >= 0


# =============================================================================
# RAG TOOL TESTS
# =============================================================================

class TestRAGTool:
    """Test RAG (Retrieval Augmented Generation) tool functionality."""
    
    @pytest.fixture
    def rag_tool(self):
        """Create RAG tool instance."""
        config = RetrievalConfig(
            chunk_size=500,
            chunk_overlap=50,
            top_k_results=5,
            similarity_threshold=0.7
        )
        return RAGTool(config=config)
    
    @pytest.fixture
    def sample_documents(self):
        """Create sample documents for testing."""
        return [
            "This is the first document about machine learning.",
            "Here we have information about artificial intelligence.",
            "Deep learning is a subset of machine learning."
        ]
    
    @pytest.mark.asyncio
    async def test_document_chunking(self, rag_tool, sample_documents):
        """Test document chunking functionality."""
        chunks = await rag_tool._chunker.chunk_documents(sample_documents)
        
        assert len(chunks) > 0
        assert all(len(chunk.text) <= 500 for chunk in chunks)  # Respect chunk size
        
        # Check for overlap
        for i in range(1, len(chunks)):
            prev_chunk = chunks[i-1].text
            curr_chunk = chunks[i].text
            # Overlap should be present (though implementation may vary)
    
    @pytest.mark.asyncio
    async def test_vector_store_operations(self, rag_tool, sample_documents):
        """Test vector store operations."""
        # Test embedding generation and storage
        with patch.object(rag_tool._embedding_provider, 'embed_documents') as mock_embed:
            mock_embed.return_value = np.random.rand(len(sample_documents), 384).tolist()
            
            await rag_tool._vector_store.add_documents(sample_documents)
            
            mock_embed.assert_called_once_with(sample_documents)
        
        # Test similarity search
        with patch.object(rag_tool._vector_store, 'similarity_search') as mock_search:
            mock_search.return_value = [
                {"text": "Relevant document", "score": 0.9, "metadata": {}},
                {"text": "Another relevant doc", "score": 0.8, "metadata": {}}
            ]
            
            results = await rag_tool.search("machine learning", top_k=2)
            
            assert len(results) == 2
            assert results[0]["score"] >= results[1]["score"]
    
    @pytest.mark.asyncio
    async def test_rag_retrieval(self, rag_tool):
        """Test RAG retrieval functionality."""
        query = "What is machine learning?"
        
        # Mock vector search
        with patch.object(rag_tool._vector_store, 'similarity_search') as mock_search:
            mock_search.return_value = [
                {
                    "text": "Machine learning is a subset of AI.",
                    "score": 0.9,
                    "metadata": {"source": "doc1"}
                }
            ]
            
            # Mock context preparation
            with patch.object(rag_tool, '_prepare_context') as mock_prepare:
                mock_prepare.return_value = "Machine learning is a subset of AI."
                
                context = await rag_tool.retrieve(query)
                
                assert context is not None
                assert "Machine learning is a subset of AI." in context
    
    @pytest.mark.asyncio
    async def test_rag_index_management(self, rag_tool, sample_documents):
        """Test RAG index management."""
        # Test index creation
        index = RAGIndex(
            id="test_index",
            created_at=datetime.now(),
            document_count=len(sample_documents),
            vector_dimension=384,
            status="active"
        )
        
        assert index.id == "test_index"
        assert index.document_count == len(sample_documents)
        assert index.status == "active"
        
        # Test index listing
        with patch.object(rag_tool._index_manager, 'list_indices') as mock_list:
            mock_list.return_value = AsyncMock(return_value=[index])
            
            indices = await rag_tool.list_indices()
            
            assert len(indices) == 1
            assert indices[0].id == "test_index"
    
    @pytest.mark.asyncio
    async def test_search_engine(self, rag_tool):
        """Test search engine functionality."""
        search_engine = SearchEngine(rag_tool._vector_store)
        
        # Test search with filters
        with patch.object(rag_tool._vector_store, 'similarity_search') as mock_search:
            mock_search.return_value = [
                {
                    "text": "Filtered result",
                    "score": 0.85,
                    "metadata": {"category": "ml"}
                }
            ]
            
            results = await search_engine.search(
                query="machine learning",
                filters={"category": "ml"},
                top_k=3
            )
            
            assert len(results) == 1
            assert results[0]["metadata"]["category"] == "ml"


# =============================================================================
# REGISTRY TESTS
# =============================================================================

class TestToolRegistry:
    """Test tool registry functionality."""
    
    @pytest.fixture
    def registry(self):
        """Create tool registry instance."""
        return ToolRegistry()
    
    @pytest.fixture
    def mock_tool(self):
        """Create mock tool for testing."""
        tool = Mock()
        tool.name = "test_tool"
        tool.version = "1.0.0"
        tool.get_metadata.return_value = ToolMetadata(
            name="test_tool",
            version="1.0.0",
            description="Test tool",
            category="testing"
        )
        return tool
    
    @pytest.mark.asyncio
    async def test_tool_registration(self, registry, mock_tool):
        """Test tool registration functionality."""
        # Register tool
        result = await registry.register_tool(mock_tool)
        
        assert result.success is True
        assert "test_tool" in registry._tools
        assert registry._tools["test_tool"].tool == mock_tool
    
    @pytest.mark.asyncio
    async def test_tool_discovery(self, registry, mock_tool):
        """Test tool discovery functionality."""
        # Register tool first
        await registry.register_tool(mock_tool)
        
        # Discover tool
        discovered = await registry.discover_tool("test_tool")
        assert discovered is not None
        assert discovered.tool == mock_tool
    
    @pytest.mark.asyncio
    async def test_tool_search(self, registry):
        """Test tool search functionality."""
        # Create and register multiple mock tools
        tools = []
        for i in range(5):
            tool = Mock()
            tool.name = f"tool_{i}"
            tool.get_metadata.return_value = ToolMetadata(
                name=f"tool_{i}",
                version="1.0.0",
                description=f"Tool number {i}",
                category="testing" if i % 2 == 0 else "utility"
            )
            tools.append(tool)
            await registry.register_tool(tool)
        
        # Test search by category
        testing_tools = await registry.search_tools(category="testing")
        assert len(testing_tools) == 3  # tools 0, 2, 4
        
        # Test search by name pattern
        numbered_tools = await registry.search_tools(pattern="tool_\\d")
        assert len(numbered_tools) == 5
        
        # Test search by tags
        tool = tools[0]
        tool.get_metadata.return_value = ToolMetadata(
            name="tagged_tool",
            version="1.0.0",
            description="Tool with tags",
            category="testing",
            tags=["ai", "ml", "nlp"]
        )
        await registry.register_tool(tool)
        
        ai_tools = await registry.search_tools(tags=["ai"])
        assert len(ai_tools) == 1
        assert ai_tools[0].tool.name == "tagged_tool"
    
    @pytest.mark.asyncio
    async def test_registry_manager(self, registry):
        """Test registry manager functionality."""
        manager = RegistryManager(registry)
        
        # Test health check
        with patch.object(registry, 'health_check') as mock_health:
            mock_health.return_value = {"status": "healthy", "tools_count": 10}
            
            health = await manager.health_check()
            
            assert health["status"] == "healthy"
            assert health["tools_count"] == 10
        
        # Test cleanup
        with patch.object(registry, 'cleanup_stale_entries') as mock_cleanup:
            mock_cleanup.return_value = AsyncMock(return_value=2)
            
            cleaned = await manager.cleanup_stale_entries()
            
            assert cleaned == 2
    
    @pytest.mark.asyncio
    async def test_load_balancer(self, registry):
        """Test tool load balancing."""
        # Create multiple instances of the same tool
        tool_name = "load_balanced_tool"
        instances = []
        
        for i in range(3):
            tool = Mock()
            tool.name = tool_name
            instances.append(tool)
            await registry.register_tool(tool, instance_id=f"instance_{i}")
        
        load_balancer = LoadBalancer(registry)
        
        # Test round-robin selection
        selected = await load_balancer.select_instance(tool_name)
        assert selected is not None
        
        # Test selection with availability check
        instances[0].is_available.return_value = False
        selected = await load_balancer.select_instance(tool_name, check_availability=True)
        assert selected.instance_id != "instance_0"  # Should skip unavailable instance


# =============================================================================
# TOOL UTILS TESTS
# =============================================================================

class TestToolUtils:
    """Test tool utilities functionality."""
    
    @pytest.fixture
    def tool_utils(self):
        """Create tool utils instance."""
        return ToolUtils()
    
    def test_validation_utils(self, tool_utils):
        """Test validation utilities."""
        validator = ValidationUtils()
        
        # Test email validation
        assert validator.is_valid_email("test@example.com") is True
        assert validator.is_valid_email("invalid-email") is False
        
        # Test URL validation
        assert validator.is_valid_url("https://example.com") is True
        assert validator.is_valid_url("not-a-url") is False
        
        # Test JSON validation
        assert validator.is_valid_json('{"key": "value"}') is True
        assert validator.is_valid_json("invalid json") is False
    
    def test_crypto_utils(self, tool_utils):
        """Test cryptographic utilities."""
        crypto = CryptoUtils()
        
        # Test hashing
        data = "test data for hashing"
        hash1 = crypto.hash_data(data)
        hash2 = crypto.hash_data(data)
        
        assert hash1 == hash2
        assert len(hash1) > 0
        
        # Test encryption/decryption
        encrypted = crypto.encrypt_data(data, "test_key")
        decrypted = crypto.decrypt_data(encrypted, "test_key")
        
        assert decrypted == data
        assert encrypted != data
    
    def test_time_utils(self, tool_utils):
        """Test time utilities."""
        time_utils = TimeUtils()
        
        # Test timestamp conversion
        timestamp = time_utils.get_current_timestamp()
        assert isinstance(timestamp, (int, float))
        
        # Test duration parsing
        duration = time_utils.parse_duration("1h30m")
        assert duration == 5400  # 1 hour 30 minutes in seconds
        
        # Test time ago calculation
        past_time = datetime.now() - timedelta(hours=1)
        time_ago = time_utils.time_ago(past_time)
        assert "hour" in time_ago.lower()
    
    def test_json_utils(self, tool_utils):
        """Test JSON utilities."""
        json_utils = JsonUtils()
        
        # Test safe JSON parsing
        json_str = '{"key": "value", "number": 42}'
        data = json_utils.safe_json_loads(json_str)
        
        assert data["key"] == "value"
        assert data["number"] == 42
        
        # Test with invalid JSON
        invalid_data = json_utils.safe_json_loads("invalid json", default={})
        assert invalid_data == {}
        
        # Test JSON path extraction
        data = {"user": {"profile": {"name": "John"}}}
        name = json_utils.get_json_path(data, "user.profile.name")
        assert name == "John"
    
    def test_path_utils(self, tool_utils):
        """Test path utilities."""
        path_utils = PathUtils()
        
        # Test path normalization
        raw_path = "../test/../data/files/file.txt"
        normalized = path_utils.normalize_path(raw_path)
        assert ".." not in normalized
        
        # Test file extension handling
        assert path_utils.get_file_extension("document.pdf") == ".pdf"
        assert path_utils.get_file_name_without_ext("document.pdf") == "document"
        
        # Test path validation
        assert path_utils.is_safe_path("/safe/path/file.txt") is True
        assert path_utils.is_safe_path("../../../etc/passwd") is False
    
    def test_type_utils(self, tool_utils):
        """Test type utilities."""
        type_utils = TypeUtils()
        
        # Test type checking
        assert type_utils.is_string("test") is True
        assert type_utils.is_string(123) is False
        
        assert type_utils.is_number(123) is True
        assert type_utils.is_number("123") is False
        
        assert type_utils.is_list([1, 2, 3]) is True
        assert type_utils.is_list("not a list") is False
        
        # Test type conversion
        assert type_utils.safe_int("42") == 42
        assert type_utils.safe_int("invalid", default=0) == 0
        
        assert type_utils.safe_float("3.14") == 3.14
        assert type_utils.safe_float("invalid", default=0.0) == 0.0


# =============================================================================
# PATTERNS TESTS
# =============================================================================

class TestToolPatterns:
    """Test design patterns implementation."""
    
    def test_observer_pattern(self):
        """Test observer pattern implementation."""
        event_bus = EventBus()
        
        # Create observer
        observer = Mock()
        observer.update = Mock()
        
        # Register observer
        event_bus.subscribe("test_event", observer)
        
        # Publish event
        event_bus.publish("test_event", {"data": "test_value"})
        
        # Verify observer was notified
        observer.update.assert_called_once_with({"data": "test_value"})
        
        # Test unsubscribe
        event_bus.unsubscribe("test_event", observer)
        event_bus.publish("test_event", {"data": "test_value2"})
        
        # Observer should not be called again
        assert observer.update.call_count == 1
    
    def test_decorator_pattern(self):
        """Test decorator pattern implementation."""
        @DecoratorPattern
        class BasicService:
            def operation(self):
                return "basic operation"
        
        @DecoratorPattern
        class LoggingDecorator:
            def operation(self):
                return f"logging: {self._wrapped.operation()}"
        
        @DecoratorPattern
        class CachingDecorator:
            def __init__(self):
                self._cache = {}
            
            def operation(self):
                return self._wrapped.operation()
        
        # Test decorator application
        service = BasicService()
        logged_service = LoggingDecorator(service)
        cached_service = CachingDecorator(logged_service)
        
        result = cached_service.operation()
        assert "logging:" in result
        assert "basic operation" in result
    
    def test_factory_pattern(self):
        """Test factory pattern implementation."""
        factory = FactoryPattern()
        
        # Register factory methods
        def create_tool_a():
            return Mock(name="tool_a")
        
        def create_tool_b():
            return Mock(name="tool_b")
        
        factory.register("tool_a", create_tool_a)
        factory.register("tool_b", create_tool_b)
        
        # Test creation
        tool_a = factory.create("tool_a")
        tool_b = factory.create("tool_b")
        
        assert tool_a.name == "tool_a"
        assert tool_b.name == "tool_b"
        
        # Test unknown type
        with pytest.raises(ValueError):
            factory.create("unknown_tool")
    
    def test_strategy_pattern(self):
        """Test strategy pattern implementation."""
        strategy = StrategyPattern()
        
        # Register strategies
        def strategy_a(context):
            return f"strategy_a: {context}"
        
        def strategy_b(context):
            return f"strategy_b: {context}"
        
        strategy.register("a", strategy_a)
        strategy.register("b", strategy_b)
        
        # Test strategy execution
        result_a = strategy.execute("a", "test_context")
        result_b = strategy.execute("b", "test_context")
        
        assert result_a == "strategy_a: test_context"
        assert result_b == "strategy_b: test_context"
        
        # Test unknown strategy
        with pytest.raises(ValueError):
            strategy.execute("unknown", "test_context")
    
    def test_command_pattern(self):
        """Test command pattern implementation."""
        command_bus = CommandPattern()
        
        # Create and register command
        class TestCommand:
            def __init__(self, data):
                self.data = data
            
            def execute(self):
                return f"executed: {self.data}"
        
        command_bus.register("test", TestCommand)
        
        # Execute command
        result = command_bus.execute("test", "test_data")
        assert result == "executed: test_data"


# =============================================================================
# CONFIG TESTS
# =============================================================================

class TestToolConfig:
    """Test configuration management functionality."""
    
    @pytest.fixture
    def config_manager(self):
        """Create configuration manager."""
        return ConfigManager()
    
    def test_config_creation(self, config_manager):
        """Test configuration creation."""
        config = ToolConfig(
            name="test_tool",
            version="1.0.0",
            settings={
                "max_retries": 3,
                "timeout": 30,
                "debug": False
            }
        )
        
        assert config.name == "test_tool"
        assert config.version == "1.0.0"
        assert config.settings["max_retries"] == 3
        assert config.settings["timeout"] == 30
        assert config.settings["debug"] is False
    
    @pytest.mark.asyncio
    async def test_config_loading(self, config_manager):
        """Test configuration loading."""
        # Mock configuration source
        config_data = {
            "name": "loaded_tool",
            "version": "2.0.0",
            "settings": {
                "enabled": True,
                "port": 8080
            }
        }
        
        with patch.object(config_manager, 'load_from_source') as mock_load:
            mock_load.return_value = AsyncMock(return_value=config_data)
            
            config = await config_manager.load_config("test_config")
            
            assert config.name == "loaded_tool"
            assert config.version == "2.0.0"
            assert config.settings["enabled"] is True
            assert config.settings["port"] == 8080
    
    def test_config_validation(self, config_manager):
        """Test configuration validation."""
        validator = ConfigValidator()
        
        # Valid configuration
        valid_config = {
            "name": "valid_tool",
            "version": "1.0.0",
            "required_field": "value",
            "numeric_field": 42
        }
        
        rules = {
            "name": {"required": True, "type": str},
            "version": {"required": True, "pattern": r"^\d+\.\d+\.\d+$"},
            "required_field": {"required": True},
            "numeric_field": {"type": int, "min": 0, "max": 100}
        }
        
        is_valid, errors = validator.validate(valid_config, rules)
        assert is_valid is True
        assert len(errors) == 0
        
        # Invalid configuration
        invalid_config = {
            "name": "",  # Empty name
            "version": "invalid",  # Invalid version pattern
            "numeric_field": 150  # Above max
        }
        
        is_valid, errors = validator.validate(invalid_config, rules)
        assert is_valid is False
        assert len(errors) > 0
    
    @pytest.mark.asyncio
    async def test_environment_config(self, config_manager):
        """Test environment configuration."""
        # Mock environment variables
        with patch.dict(os.environ, {
            "TOOL_NAME": "env_tool",
            "TOOL_VERSION": "1.5.0",
            "TOOL_DEBUG": "true",
            "TOOL_PORT": "9000"
        }):
            env_config = await config_manager.load_environment_config("TOOL_")
            
            assert env_config["name"] == "env_tool"
            assert env_config["version"] == "1.5.0"
            assert env_config["debug"] is True
            assert env_config["port"] == 9000
    
    def test_config_source(self, config_manager):
        """Test configuration sources."""
        # Test file source
        file_source = ConfigSource.FILE
        assert file_source.value == "file"
        
        # Test environment source
        env_source = ConfigSource.ENVIRONMENT
        assert env_source.value == "environment"
        
        # Test database source
        db_source = ConfigSource.DATABASE
        assert db_source.value == "database"
    
    def test_config_parser(self, config_manager):
        """Test configuration parsing."""
        parser = ConfigParser()
        
        # Test JSON parsing
        json_config = '{"name": "json_tool", "version": "1.0.0"}'
        parsed = parser.parse(json_config, "json")
        
        assert parsed["name"] == "json_tool"
        assert parsed["version"] == "1.0.0"
        
        # Test YAML parsing
        yaml_config = """
        name: yaml_tool
        version: 2.0.0
        settings:
          enabled: true
        """
        parsed = parser.parse(yaml_config, "yaml")
        
        assert parsed["name"] == "yaml_tool"
        assert parsed["version"] == "2.0.0"
        assert parsed["settings"]["enabled"] is True
        
        # Test unsupported format
        with pytest.raises(ValueError):
            parser.parse("test content", "unsupported_format")


# =============================================================================
# INTEGRATION TESTS
# =============================================================================

class TestToolIntegration:
    """Test integration between different tools."""
    
    @pytest.mark.asyncio
    async def test_memory_and_rag_integration(self):
        """Test integration between memory and RAG tools."""
        memory_tool = MemoryTool()
        rag_tool = RAGTool()
        
        # Store document in memory for RAG
        document = "Sample document for RAG processing"
        memory_entry = BasicMemoryEntry(key="rag_doc", value=document, ttl=3600)
        await memory_tool.store(memory_entry)
        
        # Retrieve and process with RAG
        retrieved_doc = await memory_tool.retrieve("rag_doc")
        assert retrieved_doc.value == document
        
        # Note: Actual RAG processing would require vector store setup
        # This test demonstrates the integration pattern
    
    @pytest.mark.asyncio
    async def test_file_storage_and_analytics_integration(self):
        """Test integration between file storage and analytics."""
        storage_config = StorageConfig(provider="local", base_path="/tmp/test")
        file_storage = FileStorage(config=storage_config)
        file_analytics = FileAnalytics()
        
        # Upload file to storage
        content = b"Test file content for analytics"
        file_obj = BytesIO(content)
        
        with patch.object(file_storage._provider, 'upload') as mock_upload:
            mock_upload.return_value = AsyncMock(return_value="file_id_123")
            
            upload_result = await file_storage.upload_file(file_obj, "test.txt")
            file_id = upload_result.file_id
        
        # Analyze stored file
        with patch.object(file_storage._provider, 'download') as mock_download:
            mock_download.return_value = AsyncMock(return_value=BytesIO(content))
            
            download_result = await file_storage.download_file(file_id)
            
            # Analyze the downloaded content
            with patch.object(file_analytics._metadata_extractor, 'extract') as mock_extract:
                mock_extract.return_value = AsyncMock(return_value={
                    "size": len(content),
                    "mime_type": "text/plain"
                })
                
                analytics_result = await file_analytics.analyze_metadata(BytesIO(content))
                
                assert analytics_result.size == len(content)
                assert analytics_result.mime_type == "text/plain"
    
    @pytest.mark.asyncio
    async def test_registry_and_executor_integration(self):
        """Test integration between registry and executor."""
        registry = ToolRegistry()
        
        # Create mock tools
        tools = []
        for i in range(3):
            tool = Mock()
            tool.name = f"integration_tool_{i}"
            tool.execute = AsyncMock(return_value=ToolResult(success=True, data={"id": i}))
            tools.append(tool)
            await registry.register_tool(tool)
        
        # Execute tools through registry
        executor = ToolExecutor(max_concurrent=3)
        
        results = await executor.execute_parallel(tools, timeout=10.0)
        
        assert len(results) == 3
        assert all(result.success for result in results)
        assert all("id" in result.data for result in results)


# =============================================================================
# PERFORMANCE AND STRESS TESTS
# =============================================================================

class TestToolPerformance:
    """Performance tests for tools."""
    
    @pytest.mark.asyncio
    async def test_memory_tool_performance(self):
        """Test memory tool performance under load."""
        memory_tool = MemoryTool()
        
        # Performance test parameters
        num_operations = 1000
        start_time = time.time()
        
        # Execute memory operations
        for i in range(num_operations):
            entry = BasicMemoryEntry(key=f"perf_key_{i}", value=f"perf_value_{i}", ttl=3600)
            await memory_tool.store(entry)
        
        # Retrieve operations
        for i in range(num_operations):
            await memory_tool.retrieve(f"perf_key_{i}")
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Performance assertions
        ops_per_second = (num_operations * 2) / duration  # Store + retrieve
        assert ops_per_second > 100  # At least 100 ops/second
    
    @pytest.mark.asyncio
    async def test_registry_performance(self):
        """Test registry performance under load."""
        registry = ToolRegistry()
        
        # Register many tools
        num_tools = 500
        start_time = time.time()
        
        for i in range(num_tools):
            tool = Mock()
            tool.name = f"perf_tool_{i}"
            await registry.register_tool(tool)
        
        registration_time = time.time() - start_time
        
        # Search operations
        start_time = time.time()
        
        for i in range(100):
            await registry.discover_tool(f"perf_tool_{i}")
        
        search_time = time.time() - start_time
        
        # Performance assertions
        assert registration_time < 30  # Should register 500 tools in < 30 seconds
        assert search_time < 10  # Should complete 100 searches in < 10 seconds
    
    @pytest.mark.asyncio
    async def test_file_analytics_performance(self):
        """Test file analytics performance."""
        file_analytics = FileAnalytics()
        
        # Create large test file
        large_content = b"Large file content for performance testing. " * 10000  # ~500KB
        large_file = BytesIO(large_content)
        
        start_time = time.time()
        
        # Perform analytics
        with patch.object(file_analytics._metadata_extractor, 'extract') as mock_extract:
            mock_extract.return_value = AsyncMock(return_value={
                "size": len(large_content),
                "lines": 10000,
                "words": 50000
            })
            
            result = await file_analytics.analyze_metadata(large_file)
        
        analysis_time = time.time() - start_time
        
        # Performance assertions
        assert analysis_time < 5  # Should analyze file in < 5 seconds
        assert result.size == len(large_content)


# =============================================================================
# ERROR HANDLING AND RESILIENCE TESTS
# =============================================================================

class TestToolResilience:
    """Test error handling and resilience of tools."""
    
    @pytest.mark.asyncio
    async def test_memory_tool_error_recovery(self):
        """Test memory tool error recovery."""
        memory_tool = MemoryTool()
        
        # Test with invalid entry
        with pytest.raises((ValueError, TypeError)):
            await memory_tool.store("invalid_entry")
    
    @pytest.mark.asyncio
    async def test_file_storage_graceful_degradation(self):
        """Test file storage graceful degradation."""
        storage_config = StorageConfig(provider="local", base_path="/nonexistent/path")
        file_storage = FileStorage(config=storage_config)
        
        # Test with unreachable storage
        content = b"test content"
        file_obj = BytesIO(content)
        
        # Should handle error gracefully
        result = await file_storage.upload_file(file_obj, "test.txt")
        # Implementation should return appropriate error or fallback
    
    @pytest.mark.asyncio
    async def test_registry_health_monitoring(self):
        """Test registry health monitoring."""
        registry = ToolRegistry()
        
        # Test health check with empty registry
        health = await registry.health_check()
        
        assert "status" in health
        assert "tools_count" in health
        assert health["tools_count"] == 0
        
        # Test health check with registered tools
        tool = Mock()
        tool.name = "health_test_tool"
        await registry.register_tool(tool)
        
        health = await registry.health_check()
        assert health["tools_count"] == 1
    
    @pytest.mark.asyncio
    async def test_rag_tool_error_handling(self):
        """Test RAG tool error handling."""
        config = RetrievalConfig(chunk_size=100, chunk_overlap=10)
        rag_tool = RAGTool(config=config)
        
        # Test with empty documents
        results = await rag_tool.search("nonexistent query")
        assert isinstance(results, list)  # Should return empty list, not error
        
        # Test with invalid configuration
        invalid_config = RetrievalConfig(chunk_size=0)  # Invalid chunk size
        with pytest.raises((ValueError, ToolValidationError)):
            RAGTool(config=invalid_config)


# =============================================================================
# TEST DATA AND UTILITIES
# =============================================================================

@pytest.fixture
def sample_tools():
    """Provide sample tools for testing."""
    return [
        {
            "name": "memory_tool",
            "version": "1.0.0",
            "description": "Basic memory management tool",
            "category": "storage"
        },
        {
            "name": "rag_tool",
            "version": "2.0.0",
            "description": "Retrieval augmented generation tool",
            "category": "ai"
        },
        {
            "name": "file_tool",
            "version": "1.5.0",
            "description": "File processing tool",
            "category": "file_operations"
        }
    ]


@pytest.fixture
def test_file_content():
    """Provide test file content for various formats."""
    return {
        "text": b"This is a text file.\nWith multiple lines.\nFor testing purposes.",
        "json": b'{"name": "test", "version": "1.0", "features": ["test1", "test2"]}',
        "xml": b'<root><item name="test">value</item></root>',
        "binary": b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    }


@pytest.fixture
def memory_test_data():
    """Provide test data for memory operations."""
    return {
        "simple_entries": [
            {"key": "key1", "value": "value1", "ttl": 3600},
            {"key": "key2", "value": "value2", "ttl": 3600},
            {"key": "key3", "value": "value3", "ttl": 3600}
        ],
        "complex_entries": [
            {
                "key": "complex1",
                "value": {"nested": {"data": "complex_value"}, "list": [1, 2, 3]},
                "ttl": 3600,
                "metadata": {"source": "test", "tags": ["complex", "data"]}
            }
        ]
    }


@pytest.fixture
def rag_test_documents():
    """Provide test documents for RAG testing."""
    return [
        "Machine learning is a subset of artificial intelligence.",
        "Deep learning uses neural networks with multiple layers.",
        "Natural language processing helps computers understand human language.",
        "Computer vision enables machines to interpret visual information.",
        "Reinforcement learning trains agents through reward and punishment."
    ]


# =============================================================================
# MARKERS CONFIGURATION
# =============================================================================

pytest.mark.unit = pytest.mark.unit
pytest.mark.integration = pytest.mark.integration
pytest.mark.slow = pytest.mark.slow
pytest.mark.performance = pytest.mark.performance
pytest.mark.resilience = pytest.mark.resilience


# =============================================================================
# TEST SUITE CONFIGURATION
# =============================================================================

def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line("markers", "unit: Unit tests for individual tools")
    config.addinivalue_line("markers", "integration: Integration tests for tool interactions")
    config.addinivalue_line("markers", "slow: Slow running tool tests")
    config.addinivalue_line("markers", "performance: Performance tests for tools")
    config.addinivalue_line("markers", "resilience: Error handling and resilience tests")


def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on test names."""
    for item in items:
        # Add performance marker to performance tests
        if "performance" in item.name.lower():
            item.add_marker(pytest.mark.performance)
        
        # Add resilience marker to resilience tests
        if "resilience" in item.name.lower() or "error" in item.name.lower():
            item.add_marker(pytest.mark.resilience)
        
        # Add slow marker to batch operations
        if any(keyword in item.name.lower() for keyword in ["batch", "load", "large"]):
            item.add_marker(pytest.mark.slow)