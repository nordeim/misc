"""
Comprehensive tests for the MemoryTool functionality.

Tests cover all major features:
- Basic memory operations
- Advanced search and retrieval
- Memory compression and optimization
- Analytics and reporting
- Context management

Author: Customer Support AI Agent
Version: 2.0.0
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any
import logging

from app.tools.memory_tool import (
    MemoryTool, MemoryType, MemoryQuery, MemoryAnalytics,
    MemorySearchResult, ImportanceLevel
)
from app.services.memory_service import (
    ConversationMemoryManager, MemoryOptimizationService,
    get_conversation_memory_manager, get_memory_optimization_service
)

# Configure logging for tests
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestMemoryTool:
    """Test suite for MemoryTool functionality."""
    
    @pytest.fixture
    def memory_tool(self):
        """Create a MemoryTool instance for testing."""
        return MemoryTool()
    
    @pytest.fixture
    def test_session_id(self):
        """Generate a test session ID."""
        return f"test_session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    
    @pytest.mark.asyncio
    async def test_basic_memory_operations(self, memory_tool, test_session_id):
        """Test basic CRUD operations for memories."""
        # Store a memory
        memory_id = await memory_tool.store_memory(
            session_id=test_session_id,
            key="test_key",
            value="test value",
            memory_type=MemoryType.CONVERSATION.value,
            importance_score=0.8,
            metadata={"test": True}
        )
        
        assert memory_id is not None
        
        # Retrieve the memory
        retrieved = await memory_tool.get_memory(test_session_id, "test_key")
        assert retrieved is not None
        assert retrieved["key"] == "test_key"
        assert retrieved["value"] == "test value"
        assert retrieved["importance_score"] == 0.8
        assert retrieved["metadata"]["test"] is True
        
        # Update the memory
        updated_id = await memory_tool.update_memory(
            test_session_id, "test_key", "updated value", 
            importance_score=0.9
        )
        assert updated_id == memory_id
        
        # Verify update
        updated = await memory_tool.get_memory(test_session_id, "test_key")
        assert updated["value"] == "updated value"
        assert updated["importance_score"] == 0.9
        
        # Delete the memory
        deleted = await memory_tool.delete_memory(test_session_id, "test_key")
        assert deleted is True
        
        # Verify deletion
        deleted_memory = await memory_tool.get_memory(test_session_id, "test_key")
        assert deleted_memory is None
    
    @pytest.mark.asyncio
    async def test_memory_types_and_importance(self, memory_tool, test_session_id):
        """Test memory types and importance scoring."""
        # Store memories with different types and importance levels
        memories_to_store = [
            ("conversation_1", "Regular conversation", MemoryType.CONVERSATION.value, 0.5),
            ("preference_1", "User prefers email support", MemoryType.USER_PREFERENCE.value, 0.8),
            ("fact_1", "User's name is John", MemoryType.FACT.value, 0.9),
            ("knowledge_1", "Technical knowledge", MemoryType.KNOWLEDGE.value, 0.7),
            ("context_1", "Current context", MemoryType.CONTEXT.value, 0.6),
        ]
        
        stored_ids = []
        for key, value, mem_type, importance in memories_to_store:
            memory_id = await memory_tool.store_memory(
                session_id=test_session_id,
                key=key,
                value=value,
                memory_type=mem_type,
                importance_score=importance
            )
            stored_ids.append(memory_id)
        
        assert len(stored_ids) == 5
        
        # Test filtering by memory type
        conversation_memories = await memory_tool.get_context(
            test_session_id, 
            memory_types=[MemoryType.CONVERSATION.value],
            limit=10
        )
        assert len(conversation_memories) == 1
        assert conversation_memories[0]["memory_type"] == MemoryType.CONVERSATION.value
        
        # Test filtering by importance
        high_importance = await memory_tool.get_memories_by_importance(
            test_session_id, min_importance=0.8, limit=10
        )
        assert len(high_importance) == 2  # preference_1 and fact_1
        assert all(mem["importance_score"] >= 0.8 for mem in high_importance)
    
    @pytest.mark.asyncio
    async def test_memory_search(self, memory_tool, test_session_id):
        """Test advanced memory search functionality."""
        # Store test memories with keywords
        test_memories = [
            ("keyword_test_1", "Python programming language is popular"),
            ("keyword_test_2", "JavaScript web development framework"),
            ("keyword_test_3", "Machine learning artificial intelligence"),
        ]
        
        for key, value in test_memories:
            await memory_tool.store_memory(
                session_id=test_session_id,
                key=key,
                value=value,
                memory_type=MemoryType.KNOWLEDGE.value,
                importance_score=0.7
            )
        
        # Search for memories containing "programming"
        search_query = MemoryQuery(
            session_id=test_session_id,
            keywords=["programming"],
            limit=10
        )
        
        results = await memory_tool.search_memories(search_query)
        assert len(results) >= 1
        assert any("programming" in result.memory.value for result in results)
        
        # Search with multiple keywords
        search_query = MemoryQuery(
            session_id=test_session_id,
            keywords=["machine", "learning"],
            limit=10
        )
        
        results = await memory_tool.search_memories(search_query)
        assert len(results) >= 1
        assert any("machine learning" in result.memory.value for result in results)
    
    @pytest.mark.asyncio
    async def test_memory_compression(self, memory_tool, test_session_id):
        """Test memory compression functionality."""
        # Store a long conversation memory
        long_conversation = "This is a very long conversation that should be compressed. " * 50
        
        memory_id = await memory_tool.store_memory(
            session_id=test_session_id,
            key="long_conversation",
            value=long_conversation,
            memory_type=MemoryType.CONVERSATION.value,
            importance_score=0.4,  # Low importance, good candidate for compression
            auto_compress=True
        )
        
        assert memory_id is not None
        
        # Retrieve and verify compression
        stored_memory = await memory_tool.get_memory(test_session_id, "long_conversation")
        assert stored_memory is not None
        
        # Check if memory was compressed (will be shorter than original)
        stored_value = stored_memory["value"]
        assert len(stored_value) <= len(long_conversation)
        
        # Verify metadata indicates compression
        metadata = stored_memory.get("metadata", {})
        if metadata.get("was_compressed"):
            assert "original_length" in metadata
            assert metadata["original_length"] == len(long_conversation)
    
    @pytest.mark.asyncio
    async def test_memory_ttl_and_expiry(self, memory_tool, test_session_id):
        """Test memory TTL and expiration handling."""
        # Store a memory with short TTL
        short_ttl_memory_id = await memory_tool.store_memory(
            session_id=test_session_id,
            key="short_ttl_memory",
            value="This memory expires soon",
            memory_type=MemoryType.CONVERSATION.value,
            ttl_days=1,  # 1 day TTL
            importance_score=0.3
        )
        
        # Store a memory with no TTL (persistent)
        persistent_memory_id = await memory_tool.store_memory(
            session_id=test_session_id,
            key="persistent_memory",
            value="This memory never expires",
            memory_type=MemoryType.CONVERSATION.value,
            importance_score=0.8
        )
        
        # Initially both should be retrievable
        short_ttl = await memory_tool.get_memory(test_session_id, "short_ttl_memory")
        persistent = await memory_tool.get_memory(test_session_id, "persistent_memory")
        
        assert short_ttl is not None
        assert persistent is not None
        
        # Test cleanup of expired memories (manually set expiry for testing)
        # Note: In real scenario, expiry would be based on actual time
        async with memory_tool.cleanup_expired_memories(test_session_id) as cleaned_count:
            # The actual cleanup would happen when memories actually expire
            pass
    
    @pytest.mark.asyncio
    async def test_memory_analytics(self, memory_tool, test_session_id):
        """Test memory analytics and reporting."""
        # Store diverse memories for analytics
        analytics_test_memories = [
            ("analytics_1", "Conversation about weather", MemoryType.CONVERSATION.value, 0.5),
            ("analytics_2", "User prefers dark theme", MemoryType.USER_PREFERENCE.value, 0.8),
            ("analytics_3", "Python is a programming language", MemoryType.KNOWLEDGE.value, 0.7),
            ("analytics_4", "Technical error occurred", MemoryType.ERROR.value, 0.9),
            ("analytics_5", "User's email is user@example.com", MemoryType.FACT.value, 0.9),
        ]
        
        for key, value, mem_type, importance in analytics_test_memories:
            await memory_tool.store_memory(
                session_id=test_session_id,
                key=key,
                value=value,
                memory_type=mem_type,
                importance_score=importance
            )
        
        # Generate analytics
        analytics = await memory_tool.get_memory_analytics(test_session_id, days=30)
        
        assert analytics.session_id == test_session_id
        assert analytics.total_memories >= 5
        assert analytics.memories_by_type is not None
        assert len(analytics.importance_distribution) > 0
        assert 0 <= analytics.avg_importance_score <= 1
        assert analytics.retention_stats is not None
        assert 0 <= analytics.compression_ratio <= 1 if analytics.compression_ratio else True
    
    @pytest.mark.asyncio
    async def test_memory_optimization(self, memory_tool, test_session_id):
        """Test memory optimization features."""
        # Store multiple memories to trigger optimization
        for i in range(20):
            await memory_tool.store_memory(
                session_id=test_session_id,
                key=f"optimization_test_{i}",
                value=f"Test memory number {i} with some content to make it longer",
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.3 + (i * 0.02),  # Varying importance
                auto_compress=True
            )
        
        # Test compression of old memories
        compressed_count = await memory_tool.compress_old_memories(
            session_id=test_session_id,
            older_than_days=7,
            min_importance=0.3
        )
        
        # Should have compressed some memories (if any were old enough)
        assert isinstance(compressed_count, int)
        assert compressed_count >= 0
        
        # Test cleanup
        cleaned_count = await memory_tool.cleanup_expired_memories(test_session_id)
        assert isinstance(cleaned_count, int)
        assert cleaned_count >= 0
    
    @pytest.mark.asyncio
    async def test_memory_summary(self, memory_tool, test_session_id):
        """Test memory summary generation."""
        # Store test memories for summary
        summary_test_memories = [
            ("summary_1", "User mentioned they prefer email support"),
            ("summary_2", "Asked about Python programming"),
            ("summary_3", "Reported a technical issue"),
            ("summary_4", "Expressed satisfaction with service"),
        ]
        
        for key, value in summary_test_memories:
            await memory_tool.store_memory(
                session_id=test_session_id,
                key=key,
                value=value,
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.6
            )
        
        # Generate summary
        summary = await memory_tool.get_memory_summary(test_session_id, max_memories=5)
        
        assert summary["session_id"] == test_session_id
        assert "summary_date" in summary
        assert "important_memories" in summary
        assert "recent_memories" in summary
        assert "analytics" in summary
        assert "recommendations" in summary
        assert len(summary["recommendations"]) > 0
    
    @pytest.mark.asyncio
    async def test_session_memory_limits(self, memory_tool):
        """Test session memory limits enforcement."""
        session_id = f"limit_test_session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        
        # Store more memories than the default limit (10000)
        # For testing, we'll use a smaller limit by temporarily changing it
        original_limit = memory_tool.max_memories_per_session
        memory_tool.max_memories_per_session = 5
        
        try:
            # Store 10 memories (more than the limit)
            stored_ids = []
            for i in range(10):
                memory_id = await memory_tool.store_memory(
                    session_id=session_id,
                    key=f"limit_test_{i}",
                    value=f"Test memory number {i}",
                    memory_type=MemoryType.CONVERSATION.value,
                    importance_score=0.5 + (i * 0.05)  # Varying importance
                )
                stored_ids.append(memory_id)
            
            # Should have enforced the limit (kept only highest importance memories)
            all_memories = await memory_tool.get_context(session_id, limit=100)
            
            # Should have at most 5 memories due to limit enforcement
            assert len(all_memories) <= 5
            
            # Should have kept the highest importance memories
            if len(all_memories) > 0:
                importance_scores = [mem["importance_score"] for mem in all_memories]
                assert importance_scores == sorted(importance_scores, reverse=True)
        
        finally:
            # Restore original limit
            memory_tool.max_memories_per_session = original_limit


class TestConversationMemoryManager:
    """Test suite for ConversationMemoryManager functionality."""
    
    @pytest.fixture
    def conv_memory_manager(self):
        """Create a ConversationMemoryManager instance for testing."""
        memory_tool = MemoryTool()
        return ConversationMemoryManager(memory_tool)
    
    @pytest.fixture
    def test_session_id(self):
        """Generate a test session ID."""
        return f"conv_test_session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    
    @pytest.mark.asyncio
    async def test_conversation_turn_storage(self, conv_memory_manager, test_session_id):
        """Test storing conversation turns."""
        user_message = "Hello, I need help with Python programming"
        assistant_response = "I'd be happy to help you with Python! What specific area would you like assistance with?"
        
        user_id, assistant_id = await conv_memory_manager.store_conversation_turn(
            session_id=test_session_id,
            turn_number=1,
            user_message=user_message,
            assistant_response=assistant_response,
            context_tags=["greeting", "programming"]
        )
        
        assert user_id is not None
        assert assistant_id is not None
        assert user_id != assistant_id
        
        # Verify both memories were stored
        user_memory = await conv_memory_manager.memory_tool.get_memory(test_session_id, "turn_1_user")
        assistant_memory = await conv_memory_manager.memory_tool.get_memory(test_session_id, "turn_1_assistant")
        
        assert user_memory is not None
        assert assistant_memory is not None
        assert user_memory["value"] == user_message
        assert assistant_memory["value"] == assistant_response
        assert user_memory["metadata"]["role"] == "user"
        assert assistant_memory["metadata"]["role"] == "assistant"
    
    @pytest.mark.asyncio
    async def test_conversation_context_retrieval(self, conv_memory_manager, test_session_id):
        """Test retrieving conversation context."""
        # Store multiple conversation turns
        conversations = [
            ("Hi there", "Hello! How can I help you today?"),
            ("I need Python help", "Python is great! What do you need help with?"),
            ("How do I install packages?", "You can use pip to install packages...")
        ]
        
        for i, (user_msg, assistant_msg) in enumerate(conversations, 1):
            await conv_memory_manager.store_conversation_turn(
                session_id=test_session_id,
                turn_number=i,
                user_message=user_msg,
                assistant_response=assistant_msg
            )
        
        # Retrieve context
        context = await conv_memory_manager.get_conversation_context(
            session_id=test_session_id,
            recent_turns=2
        )
        
        assert len(context) >= 0  # May be 0 if no relevant context found
        # Context should be ordered chronologically
        if len(context) > 1:
            for i in range(len(context) - 1):
                assert context[i]["created_at"] <= context[i + 1]["created_at"]
    
    @pytest.mark.asyncio
    async def test_user_preference_tracking(self, conv_memory_manager, test_session_id):
        """Test tracking user preferences."""
        user_message = "I prefer email support and I like the dark theme"
        
        extracted_preferences = {
            "support_method": "email",
            "theme": "dark",
            "communication_style": "email"
        }
        
        stored_prefs = await conv_memory_manager.track_user_preferences(
            session_id=test_session_id,
            user_message=user_message,
            extracted_preferences=extracted_preferences
        )
        
        assert len(stored_prefs) == 3
        assert "support_method" in stored_prefs
        assert "theme" in stored_prefs
        assert "communication_style" in stored_prefs
        
        # Verify preferences were stored correctly
        support_pref = await conv_memory_manager.memory_tool.get_memory(
            test_session_id, "user_preference_support_method"
        )
        assert support_pref is not None
        assert support_pref["value"] == "email"
        assert support_pref["memory_type"] == MemoryType.USER_PREFERENCE.value
    
    @pytest.mark.asyncio
    async def test_fact_identification(self, conv_memory_manager, test_session_id):
        """Test identifying important facts from messages."""
        messages = [
            "My name is John Smith",
            "I need help with programming",
            "My email is john@example.com",
            "I prefer Java over Python",
            "How do I install packages?"
        ]
        
        identified_facts = await conv_memory_manager.identify_important_facts(
            session_id=test_session_id,
            messages=messages
        )
        
        # Should have identified some facts (personal info and preferences)
        assert isinstance(identified_facts, list)
        
        # Verify facts were stored
        fact_memories = await conv_memory_manager.memory_tool.get_context(
            session_id=test_session_id,
            memory_types=[MemoryType.FACT.value],
            limit=10
        )
        
        assert len(fact_memories) >= 0  # May be 0 if no facts met importance threshold


class TestMemoryOptimizationService:
    """Test suite for MemoryOptimizationService functionality."""
    
    @pytest.fixture
    def optimization_service(self):
        """Create a MemoryOptimizationService instance for testing."""
        memory_tool = MemoryTool()
        return MemoryOptimizationService(memory_tool)
    
    @pytest.fixture
    def test_session_id(self):
        """Generate a test session ID."""
        return f"opt_test_session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    
    @pytest.mark.asyncio
    async def test_session_optimization(self, optimization_service, test_session_id):
        """Test session memory optimization."""
        # Store test memories for optimization
        for i in range(15):
            await optimization_service.memory_tool.store_memory(
                session_id=test_session_id,
                key=f"opt_test_{i}",
                value=f"Test memory {i} with some content for optimization testing",
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.3 + (i * 0.03),
                ttl_days=1 if i < 5 else None  # Some will expire
            )
        
        # Run optimization
        results = await optimization_service.optimize_session_memories(
            session_id=test_session_id,
            force=True  # Force optimization
        )
        
        assert "expired_cleaned" in results
        assert "compressed" in results
        assert "summaries_created" in results
        assert "total_optimized" in results
        
        assert isinstance(results["expired_cleaned"], int)
        assert isinstance(results["compressed"], int)
        assert isinstance(results["summaries_created"], int)
        assert isinstance(results["total_optimized"], int)
    
    @pytest.mark.asyncio
    async def test_memory_pattern_analysis(self, optimization_service, test_session_id):
        """Test memory pattern analysis."""
        # Store memories that will trigger patterns
        for i in range(50):  # High usage pattern
            await optimization_service.memory_tool.store_memory(
                session_id=test_session_id,
                key=f"pattern_test_{i}",
                value=f"Test memory {i} for pattern analysis",
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.9 if i < 20 else 0.4  # High importance concentration
            )
        
        # Analyze patterns
        patterns = await optimization_service.analyze_memory_patterns(test_session_id)
        
        assert isinstance(patterns, list)
        
        # Should have detected at least one pattern
        if len(patterns) > 0:
            pattern = patterns[0]
            assert hasattr(pattern, 'pattern_type')
            assert hasattr(pattern, 'frequency')
            assert hasattr(pattern, 'importance')
            assert hasattr(pattern, 'recommendations')
            assert isinstance(pattern.recommendations, list)


def run_memory_tool_tests():
    """Run all memory tool tests manually."""
    logger.info("Starting MemoryTool test suite...")
    
    async def run_all_tests():
        # Test MemoryTool
        memory_tool = MemoryTool()
        test_session_id = f"manual_test_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        
        try:
            # Basic operations test
            logger.info("Testing basic memory operations...")
            memory_id = await memory_tool.store_memory(
                session_id=test_session_id,
                key="test_basic",
                value="Basic test value",
                memory_type=MemoryType.CONVERSATION.value,
                importance_score=0.8
            )
            
            retrieved = await memory_tool.get_memory(test_session_id, "test_basic")
            assert retrieved is not None
            logger.info("✓ Basic operations test passed")
            
            # Search test
            logger.info("Testing memory search...")
            search_query = MemoryQuery(
                session_id=test_session_id,
                keywords=["test"],
                limit=10
            )
            
            results = await memory_tool.search_memories(search_query)
            assert len(results) >= 0
            logger.info("✓ Search test passed")
            
            # Analytics test
            logger.info("Testing memory analytics...")
            analytics = await memory_tool.get_memory_analytics(test_session_id, days=30)
            assert analytics.session_id == test_session_id
            logger.info("✓ Analytics test passed")
            
            logger.info("All MemoryTool tests completed successfully!")
            
        except Exception as e:
            logger.error(f"MemoryTool test failed: {e}")
            raise
        
        finally:
            # Cleanup
            try:
                await memory_tool.clear_session_memories(test_session_id)
                logger.info("Test cleanup completed")
            except Exception as e:
                logger.warning(f"Test cleanup failed: {e}")
    
    # Run the async tests
    asyncio.run(run_all_tests())


if __name__ == "__main__":
    # Run tests when script is executed directly
    run_memory_tool_tests()
