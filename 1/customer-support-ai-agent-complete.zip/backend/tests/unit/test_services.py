"""
Comprehensive unit tests for all services in the backend.

This test module covers:
- Cache Service (Redis caching with fallback)
- Embedding Service (SentenceTransformers integration)
- Message Service (Message handling operations)
- Memory Service (Memory management)
- Message Analytics Service (Analytics and metrics)
- Message Security Service (Security validation)
- Message Utilities Service (Utility operations)
- Model Management Service (Model lifecycle)
- Observability Service (Monitoring and observability)
- Batch Processing Service (Batch operations)
- Embedding Utils (Utility functions)
- HuggingFace Compatibility (Compatibility layer)

Uses pytest fixtures from conftest.py and test utilities from utils package.
"""

import pytest
import asyncio
import json
import time
import hashlib
import tempfile
import os
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from pathlib import Path
from typing import List, Dict, Any, Optional
import numpy as np

# Import all services to test
from app.services.cache_service import (
    RedisCacheService,
    CacheMetrics,
    CacheEntry,
    SerializationManager,
    CacheTagManager,
    CachePartitioner,
    CacheWarmer,
    CacheAnalytics,
    InMemoryFallbackCache,
    get_cache_service,
    cached
)
from app.services.embedding_service import (
    EmbeddingService,
    EmbeddingModel,
    EmbeddingCache,
    ModelManager,
    BatchProcessor,
    EmbeddingUtils,
    EmbeddingAnalytics,
    EmbeddingValidator,
    EmbeddingConfig
)
from app.services.message_service import MessageService
from app.services.memory_service import MemoryService
from app.services.message_analytics_service import MessageAnalyticsService
from app.services.message_security_service import MessageSecurityService
from app.services.message_utilities_service import MessageUtilitiesService
from app.services.model_management import ModelManagementService
from app.services.observability_service import ObservabilityService
from app.services.batch_processing import BatchProcessingService
from app.services.embedding_utils import EmbeddingUtils as EmbeddingUtilsClass
from app.services.huggingface_compat import HuggingFaceCompatibility

# Import test utilities
from tests.utils.test_data_generator import TestDataGenerator
from tests.utils.mock_services import MockRedisClient, MockAIService, MockEmbeddingService
from tests.utils.auth_helpers import AuthTestHelper
from tests.utils.db_helpers import DatabaseTestHelper
from tests.utils.performance_testing import PerformanceProfiler


class TestCacheService:
    """Test RedisCacheService and related components."""
    
    @pytest.mark.asyncio
    async def test_cache_service_initialization(self, test_app):
        """Test cache service initialization with different configurations."""
        # Test with fallback enabled
        cache_service = RedisCacheService(enable_fallback=True)
        await cache_service.initialize()
        
        assert cache_service._initialized is True
        assert cache_service.fallback_cache is not None
        assert cache_service.warmer is not None
        assert cache_service.analytics is not None
    
    @pytest.mark.asyncio
    async def test_cache_service_get_set_operations(self, test_app, mock_redis_client):
        """Test basic cache get/set operations."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        # Test set operation
        success = await cache_service.set("test_key", "test_value", ttl=300)
        assert success is True
        
        # Test get operation
        value = await cache_service.get("test_key")
        assert value == "test_value"
        
        # Test get with default
        value = await cache_service.get("nonexistent_key", default="default_value")
        assert value == "default_value"
    
    @pytest.mark.asyncio
    async def test_cache_service_batch_operations(self, test_app, mock_redis_client):
        """Test batch get/set operations."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        # Batch set
        items = {"key1": "value1", "key2": "value2", "key3": "value3"}
        success = await cache_service.batch_set(items, ttl=300)
        assert success is True
        
        # Batch get
        keys = ["key1", "key2", "key3"]
        results = await cache_service.batch_get(keys)
        
        assert "key1" in results
        assert "key2" in results
        assert "key3" in results
        assert results["key1"] == "value1"
        assert results["key2"] == "value2"
        assert results["key3"] == "value3"
    
    @pytest.mark.asyncio
    async def test_cache_serialization_manager(self):
        """Test cache serialization and deserialization."""
        # Test JSON serialization
        test_data = {"key": "value", "number": 42, "list": [1, 2, 3]}
        serialized_data, format_type = SerializationManager.serialize(test_data)
        
        assert format_type == "json"
        deserialized = SerializationManager.deserialize(serialized_data, format_type)
        assert deserialized == test_data
        
        # Test pickle serialization
        complex_data = {"datetime": datetime.now(), "numpy_array": np.array([1, 2, 3])}
        serialized_data, format_type = SerializationManager.serialize(complex_data)
        
        assert format_type == "pickle"
        deserialized = SerializationManager.deserialize(serialized_data, format_type)
        assert isinstance(deserialized["numpy_array"], np.ndarray)
        assert len(deserialized["numpy_array"]) == 3
    
    @pytest.mark.asyncio
    async def test_cache_tag_manager(self, mock_redis_client):
        """Test tag-based cache invalidation."""
        tag_manager = CacheTagManager(mock_redis_client)
        
        # Add tags to key
        await tag_manager.add_tags_to_key("test_key", ["tag1", "tag2"])
        
        # Get keys by tag
        keys = await tag_manager.get_keys_by_tag("tag1")
        assert "test_key" in keys
        
        # Invalidate by tag
        deleted_count = await tag_manager.invalidate_by_tag("tag1")
        assert deleted_count >= 1
    
    @pytest.mark.asyncio
    async def test_cache_partitioner(self):
        """Test cache partitioning and sharding."""
        partitioner = CachePartitioner(num_partitions=8)
        
        # Test partition calculation
        partition1 = partitioner.get_partition("test_key_1")
        partition2 = partitioner.get_partition("test_key_2")
        
        assert 0 <= partition1 < 8
        assert 0 <= partition2 < 8
        
        # Test partition key generation
        partition_key, partition = partitioner.get_partition_keys("test_key")
        assert partition_key.startswith(f"{partition:02d}:")
    
    @pytest.mark.asyncio
    async def test_cache_warmer(self, mock_redis_client):
        """Test cache warming functionality."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        
        warmer = CacheWarmer(cache_service)
        
        # Test cache warming
        items = [
            ("key1", "value1", 300, ["tag1"]),
            ("key2", "value2", 300, ["tag2"]),
            ("key3", "value3", 300, ["tag3"])
        ]
        
        await warmer.warm_cache(items, batch_size=2)
        
        # Verify values were set
        value1 = await cache_service.get("key1")
        value2 = await cache_service.get("key2")
        value3 = await cache_service.get("key3")
        
        assert value1 == "value1"
        assert value2 == "value2"
        assert value3 == "value3"
    
    @pytest.mark.asyncio
    async def test_cache_analytics(self, mock_redis_client):
        """Test cache analytics and metrics."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        
        analytics = CacheAnalytics(cache_service)
        
        # Perform some cache operations
        await cache_service.set("key1", "value1")
        await cache_service.get("key1")  # Hit
        await cache_service.get("key2")  # Miss
        
        # Collect metrics
        metrics = await analytics.collect_metrics()
        
        assert metrics.total_operations > 0
        assert metrics.cache_hits >= 0
        assert metrics.cache_misses >= 0
        assert 0 <= metrics.hit_rate <= 1
    
    @pytest.mark.asyncio
    async def test_cache_decorator(self, mock_redis_client):
        """Test cache decorator functionality."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        call_count = 0
        
        @cache_service.get_cache_decorator(ttl=300, tags=["test"])
        async def expensive_function(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2
        
        # First call - should execute function
        result1 = await expensive_function(5)
        assert result1 == 10
        assert call_count == 1
        
        # Second call with same argument - should use cache
        result2 = await expensive_function(5)
        assert result2 == 10
        assert call_count == 1  # Still 1, function not called again
        
        # Call with different argument - should execute function
        result3 = await expensive_function(6)
        assert result3 == 12
        assert call_count == 2
    
    @pytest.mark.asyncio
    async def test_cache_health_check(self, mock_redis_client):
        """Test cache health check functionality."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        
        health = await cache_service.health_check()
        
        assert "status" in health
        assert "timestamp" in health
        assert "components" in health
        assert "redis" in health["components"]
        assert "fallback_cache" in health["components"]


class TestEmbeddingService:
    """Test EmbeddingService and related components."""
    
    @pytest.fixture
    def mock_embedding_service(self):
        """Create mock embedding service."""
        service = Mock()
        service.generate_embeddings.return_value = AsyncMock(return_value=[[0.1, 0.2, 0.3]])
        service.generate_batch_embeddings.return_value = AsyncMock(return_value=[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
        return service
    
    @pytest.mark.asyncio
    async def test_embedding_service_initialization(self):
        """Test embedding service initialization."""
        # Mock the SentenceTransformer to avoid actual model loading
        with patch('app.services.embedding_service.SentenceTransformer'):
            with patch('app.services.embedding_service.aioredis.from_url'):
                service = EmbeddingService()
                await service.initialize()
                
                assert service._initialized is True
    
    @pytest.mark.asyncio
    async def test_embedding_generation(self, mock_embedding_service):
        """Test embedding generation."""
        service = EmbeddingService()
        service.model = Mock()
        service.model.encode.return_value = np.array([[0.1, 0.2, 0.3]])
        
        texts = ["Hello world", "This is a test"]
        embeddings = await service.generate_embeddings(texts)
        
        assert len(embeddings) == 1
        assert len(embeddings[0]) == 3
        assert all(isinstance(emb, float) for emb in embeddings[0])
    
    @pytest.mark.asyncio
    async def test_batch_embedding_processing(self, mock_embedding_service):
        """Test batch embedding processing."""
        service = EmbeddingService()
        service.model = Mock()
        service.model.encode.return_value = np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
        
        texts = ["Text 1", "Text 2", "Text 3", "Text 4"]
        embeddings = await service.generate_batch_embeddings(texts, batch_size=2)
        
        assert len(embeddings) == 4
        for embedding in embeddings:
            assert len(embedding) == 3
    
    @pytest.mark.asyncio
    async def test_embedding_similarity_calculation(self):
        """Test embedding similarity calculations."""
        service = EmbeddingService()
        
        # Create test embeddings
        embedding1 = np.array([0.1, 0.2, 0.3])
        embedding2 = np.array([0.1, 0.2, 0.3])  # Identical
        embedding3 = np.array([0.9, 0.8, 0.7])  # Different
        
        # Test cosine similarity
        similarity_same = service.calculate_similarity(embedding1, embedding2)
        similarity_different = service.calculate_similarity(embedding1, embedding3)
        
        assert similarity_same > similarity_different
        assert 0 <= similarity_same <= 1
        assert 0 <= similarity_different <= 1
    
    @pytest.mark.asyncio
    async def test_embedding_cache_operations(self, mock_redis_client):
        """Test embedding caching operations."""
        service = EmbeddingService()
        service.cache = Mock()
        service.cache.get.return_value = AsyncMock(return_value=None)  # Cache miss
        service.cache.set.return_value = AsyncMock(return_value=True)
        
        text = "Test text"
        embedding = np.array([0.1, 0.2, 0.3])
        
        # Test cache miss and set
        cached_embedding = await service.get_cached_embedding(text)
        assert cached_embedding is None
        
        await service.cache_embedding(text, embedding)
        service.cache.set.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_embedding_validation(self):
        """Test embedding validation."""
        service = EmbeddingService()
        validator = EmbeddingValidator()
        
        # Test valid embedding
        valid_embedding = np.array([0.1, 0.2, 0.3])
        is_valid = validator.validate_embedding(valid_embedding)
        assert is_valid is True
        
        # Test invalid embedding (wrong shape)
        invalid_embedding = np.array([[0.1, 0.2]])  # Wrong shape
        is_valid = validator.validate_embedding(invalid_embedding)
        assert is_valid is False
        
        # Test invalid embedding (NaN values)
        invalid_embedding = np.array([0.1, np.nan, 0.3])
        is_valid = validator.validate_embedding(invalid_embedding)
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_model_management(self):
        """Test model management functionality."""
        model_manager = ModelManager()
        
        # Test model loading
        with patch('app.services.embedding_service.SentenceTransformer'):
            model = await model_manager.load_model("test-model")
            assert model is not None
        
        # Test model caching
        model_manager._loaded_models["test-model"] = Mock()
        cached_model = await model_manager.get_model("test-model")
        assert cached_model is not None
        
        # Test model cleanup
        await model_manager.unload_model("test-model")
        assert "test-model" not in model_manager._loaded_models


class TestMessageService:
    """Test MessageService operations."""
    
    @pytest.fixture
    def message_service(self):
        """Create message service instance."""
        return MessageService()
    
    @pytest.mark.asyncio
    async def test_get_message_by_id(self, message_service, test_db, test_user):
        """Test getting message by ID."""
        # Create test message
        message_data = {
            "id": "test-msg-1",
            "session_id": "test-session",
            "user_id": test_user.id,
            "content": "Test message content",
            "role": "user"
        }
        
        # Mock the database response
        with patch.object(message_service, 'get_message_by_id') as mock_get:
            mock_get.return_value = AsyncMock(return_value=Mock(**message_data))
            
            result = await message_service.get_message_by_id("test-msg-1", test_db)
            assert result is not None
            assert result.content == "Test message content"
    
    @pytest.mark.asyncio
    async def test_message_sequence_number(self, message_service, test_db):
        """Test sequence number generation."""
        with patch.object(message_service, 'get_next_sequence_number') as mock_seq:
            mock_seq.return_value = AsyncMock(return_value=1)
            
            seq_num = await message_service.get_next_sequence_number("test-session", test_db)
            assert seq_num == 1
    
    @pytest.mark.asyncio
    async def test_batch_message_operations(self, message_service, test_db):
        """Test batch message operations."""
        # Mock batch operations
        with patch.object(message_service, 'batch_get_messages') as mock_batch:
            mock_batch.return_value = AsyncMock(return_value=[])
            
            messages = await message_service.batch_get_messages(["msg1", "msg2"], test_db)
            assert isinstance(messages, list)
    
    @pytest.mark.asyncio
    async def test_message_analytics(self, message_service, test_db):
        """Test message analytics."""
        # Mock analytics operations
        with patch.object(message_service, 'get_message_analytics') as mock_analytics:
            mock_analytics.return_value = AsyncMock(return_value={"total_messages": 10})
            
            analytics = await message_service.get_message_analytics("test-session", test_db)
            assert "total_messages" in analytics


class TestMemoryService:
    """Test MemoryService operations."""
    
    @pytest.mark.asyncio
    async def test_memory_operations(self):
        """Test basic memory operations."""
        # Mock Redis client
        mock_redis = Mock()
        mock_redis.get.return_value = AsyncMock(return_value=None)
        mock_redis.set.return_value = AsyncMock(return_value=True)
        
        service = MemoryService()
        service.redis_client = mock_redis
        
        # Test memory storage
        result = await service.store_memory("key1", "value1", ttl=3600)
        assert result is True
        
        # Test memory retrieval
        value = await service.get_memory("key1")
        assert value is None  # Mock returns None
        
        # Test memory deletion
        result = await service.delete_memory("key1")
        assert result is True
    
    @pytest.mark.asyncio
    async def test_memory_search(self):
        """Test memory search functionality."""
        mock_redis = Mock()
        mock_redis.keys.return_value = AsyncMock(return_value=[b"memory:key1", b"memory:key2"])
        
        service = MemoryService()
        service.redis_client = mock_redis
        
        # Test search by pattern
        keys = await service.search_memories("pattern:*")
        assert isinstance(keys, list)
    
    @pytest.mark.asyncio
    async def test_memory_cleanup(self):
        """Test memory cleanup operations."""
        mock_redis = Mock()
        mock_redis.flushdb.return_value = AsyncMock(return_value=True)
        
        service = MemoryService()
        service.redis_client = mock_redis
        
        # Test cleanup
        result = await service.cleanup_expired_memories()
        assert result is True


class TestMessageAnalyticsService:
    """Test MessageAnalyticsService operations."""
    
    @pytest.mark.asyncio
    async def test_analytics_calculations(self):
        """Test analytics calculation methods."""
        service = MessageAnalyticsService()
        
        # Mock database session
        mock_db = Mock()
        mock_db.execute.return_value = AsyncMock()
        mock_db.execute.return_value.scalar.return_value = 10
        
        # Test message count calculation
        count = await service.calculate_message_count(mock_db, "test-session")
        assert count == 10
    
    @pytest.mark.asyncio
    async def test_engagement_metrics(self):
        """Test engagement metrics calculation."""
        service = MessageAnalyticsService()
        
        # Mock engagement data
        mock_db = Mock()
        mock_db.execute.return_value = AsyncMock()
        mock_db.execute.return_value.all.return_value = [
            {"response_time": 1.5, "user_satisfaction": 4.2},
            {"response_time": 2.1, "user_satisfaction": 4.8}
        ]
        
        metrics = await service.calculate_engagement_metrics(mock_db, "test-session")
        assert isinstance(metrics, dict)
    
    @pytest.mark.asyncio
    async def test_performance_metrics(self):
        """Test performance metrics calculation."""
        service = MessageAnalyticsService()
        
        # Mock performance data
        mock_db = Mock()
        mock_db.execute.return_value = AsyncMock()
        mock_db.execute.return_value.all.return_value = [
            {"processing_time": 0.5, "tokens_generated": 100},
            {"processing_time": 0.8, "tokens_generated": 150}
        ]
        
        metrics = await service.calculate_performance_metrics(mock_db, "test-session")
        assert isinstance(metrics, dict)


class TestMessageSecurityService:
    """Test MessageSecurityService operations."""
    
    @pytest.mark.asyncio
    async def test_content_validation(self):
        """Test message content validation."""
        service = MessageSecurityService()
        
        # Test valid content
        valid_content = "This is a normal message content."
        is_valid = await service.validate_content(valid_content)
        assert is_valid is True
        
        # Test invalid content (potentially harmful)
        invalid_content = "<script>alert('xss')</script>"
        is_valid = await service.validate_content(invalid_content)
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_pii_detection(self):
        """Test PII detection in messages."""
        service = MessageSecurityService()
        
        # Test content with potential PII
        content_with_pii = "My email is user@example.com and phone is 123-456-7890"
        pii_found = await service.detect_pii(content_with_pii)
        
        assert isinstance(pii_found, list)
        # Should detect email and phone number
    
    @pytest.mark.asyncio
    async def test_spam_detection(self):
        """Test spam detection functionality."""
        service = MessageSecurityService()
        
        # Test normal message
        normal_message = "Hello, how are you today?"
        is_spam = await service.detect_spam(normal_message)
        assert is_spam is False
        
        # Test potential spam
        spam_message = "CLICK HERE!!! WIN MONEY NOW!!!"
        is_spam = await service.detect_spam(spam_message)
        # Result depends on spam detection algorithm
        assert isinstance(is_spam, bool)


class TestMessageUtilitiesService:
    """Test MessageUtilitiesService operations."""
    
    @pytest.mark.asyncio
    async def test_text_processing(self):
        """Test text processing utilities."""
        service = MessageUtilitiesService()
        
        # Test text cleaning
        dirty_text = "  This has   extra spaces  and \n newlines  "
        clean_text = await service.clean_text(dirty_text)
        assert "extra spaces" in clean_text
        assert "\n" not in clean_text
        
        # Test text normalization
        text_with_accents = "Café résumé naïve"
        normalized = await service.normalize_text(text_with_accents)
        assert "café" in normalized.lower()
    
    @pytest.mark.asyncio
    async def test_language_detection(self):
        """Test language detection."""
        service = MessageUtilitiesService()
        
        # Test English text
        english_text = "Hello, this is an English message."
        language = await service.detect_language(english_text)
        assert language in ["en", "english"]
        
        # Test Spanish text
        spanish_text = "Hola, este es un mensaje en español."
        language = await service.detect_language(spanish_text)
        assert language in ["es", "spanish"]
    
    @pytest.mark.asyncio
    async def test_sentiment_analysis(self):
        """Test sentiment analysis."""
        service = MessageUtilitiesService()
        
        # Test positive sentiment
        positive_text = "I love this product! It's amazing!"
        sentiment = await service.analyze_sentiment(positive_text)
        assert sentiment["polarity"] == "positive"
        
        # Test negative sentiment
        negative_text = "I hate this! It's terrible!"
        sentiment = await service.analyze_sentiment(negative_text)
        assert sentiment["polarity"] == "negative"


class TestModelManagementService:
    """Test ModelManagementService operations."""
    
    @pytest.mark.asyncio
    async def test_model_loading(self):
        """Test model loading functionality."""
        service = ModelManagementService()
        
        # Mock model loading
        with patch('app.services.model_management.SentenceTransformer'):
            model = await service.load_model("test-model", "test-revision")
            assert model is not None
    
    @pytest.mark.asyncio
    async def test_model_versioning(self):
        """Test model versioning."""
        service = ModelManagementService()
        
        # Test version listing
        versions = await service.list_model_versions("test-model")
        assert isinstance(versions, list)
        
        # Test version switching
        result = await service.switch_model_version("test-model", "v2.0")
        assert isinstance(result, bool)
    
    @pytest.mark.asyncio
    async def test_model_metrics(self):
        """Test model performance metrics."""
        service = ModelManagementService()
        
        # Mock model performance data
        metrics = await service.get_model_metrics("test-model")
        assert isinstance(metrics, dict)
        assert "accuracy" in metrics or "latency" in metrics


class TestObservabilityService:
    """Test ObservabilityService operations."""
    
    @pytest.mark.asyncio
    async def test_metrics_collection(self):
        """Test metrics collection."""
        service = ObservabilityService()
        
        # Test custom metrics
        await service.record_metric("test_counter", 1, "counter")
        await service.record_metric("test_gauge", 42, "gauge")
        
        # Test metrics retrieval
        metrics = await service.get_metrics("test_counter")
        assert isinstance(metrics, list)
    
    @pytest.mark.asyncio
    async def test_tracing(self):
        """Test distributed tracing."""
        service = ObservabilityService()
        
        # Test span creation
        with service.trace_operation("test_operation") as span:
            span.set_attribute("test.attr", "test_value")
        
        assert span is not None
    
    @pytest.mark.asyncio
    async def test_logging(self):
        """Test structured logging."""
        service = ObservabilityService()
        
        # Test structured logging
        await service.log_structured(
            "info",
            "Test message",
            extra_fields={"key": "value"}
        )
        
        # Test error logging
        try:
            raise ValueError("Test error")
        except ValueError as e:
            await service.log_error(e, context={"test": True})


class TestBatchProcessingService:
    """Test BatchProcessingService operations."""
    
    @pytest.mark.asyncio
    async def test_batch_job_creation(self):
        """Test batch job creation."""
        service = BatchProcessingService()
        
        # Test job creation
        job = await service.create_batch_job(
            job_type="embedding_generation",
            items=[{"text": "test1"}, {"text": "test2"}],
            config={"batch_size": 10}
        )
        
        assert job["job_id"] is not None
        assert job["status"] == "pending"
    
    @pytest.mark.asyncio
    async def test_batch_job_execution(self):
        """Test batch job execution."""
        service = BatchProcessingService()
        
        # Create and execute batch job
        job_id = "test-job-123"
        
        # Mock job execution
        with patch.object(service, '_execute_batch_job') as mock_execute:
            mock_execute.return_value = AsyncMock(return_value={"status": "completed"})
            
            result = await service.execute_batch_job(job_id)
            assert result["status"] == "completed"
    
    @pytest.mark.asyncio
    async def test_batch_progress_tracking(self):
        """Test batch progress tracking."""
        service = BatchProcessingService()
        
        # Test progress updates
        await service.update_job_progress("test-job", 50, "Processing item 50/100")
        
        # Test progress retrieval
        progress = await service.get_job_progress("test-job")
        assert progress["percentage"] == 50


class TestEmbeddingUtils:
    """Test EmbeddingUtils functions."""
    
    @pytest.mark.asyncio
    async def test_text_preprocessing(self):
        """Test text preprocessing utilities."""
        utils = EmbeddingUtilsClass()
        
        # Test text cleaning
        dirty_text = "  This is a test!  \n  "
        clean_text = utils.preprocess_text(dirty_text)
        assert "This is a test!" in clean_text
        assert clean_text.strip() == clean_text
        
        # Test text tokenization
        tokens = utils.tokenize_text("Hello world!")
        assert isinstance(tokens, list)
        assert len(tokens) > 0
    
    @pytest.mark.asyncio
    async def test_similarity_calculations(self):
        """Test similarity calculation functions."""
        utils = EmbeddingUtilsClass()
        
        # Test cosine similarity
        vec1 = np.array([1.0, 0.0, 0.0])
        vec2 = np.array([1.0, 0.0, 0.0])
        similarity = utils.cosine_similarity(vec1, vec2)
        assert abs(similarity - 1.0) < 1e-6
        
        # Test Euclidean distance
        distance = utils.euclidean_distance(vec1, vec2)
        assert abs(distance - 0.0) < 1e-6
    
    @pytest.mark.asyncio
    async def test_clustering_operations(self):
        """Test clustering operations."""
        utils = EmbeddingUtilsClass()
        
        # Create test embeddings
        embeddings = np.array([
            [1.0, 0.0, 0.0],
            [0.9, 0.1, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.9, 0.1]
        ])
        
        # Test clustering
        clusters = utils.cluster_embeddings(embeddings, n_clusters=2)
        assert isinstance(clusters, np.ndarray)
        assert len(clusters) == len(embeddings)
    
    @pytest.mark.asyncio
    async def test_dimension_reduction(self):
        """Test dimensionality reduction."""
        utils = EmbeddingUtilsClass()
        
        # Create high-dimensional embeddings
        embeddings = np.random.rand(100, 50)
        
        # Test PCA reduction
        reduced = utils.reduce_dimensions(embeddings, n_components=10, method="pca")
        assert reduced.shape[1] == 10
        assert reduced.shape[0] == 100


class TestHuggingFaceCompatibility:
    """Test HuggingFace compatibility layer."""
    
    @pytest.mark.asyncio
    async def test_model_download_compatibility(self):
        """Test model download with compatibility layer."""
        compat = HuggingFaceCompatibility()
        
        # Mock the download process
        with patch('app.services.huggingface_compat.cached_download') as mock_download:
            mock_download.return_value = "/fake/model/path"
            
            model_path = await compat.download_model(
                model_name="test-model",
                cache_dir="/tmp/test_cache"
            )
            
            assert model_path == "/fake/model/path"
            mock_download.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_model_loading_compatibility(self):
        """Test model loading with compatibility layer."""
        compat = HuggingFaceCompatibility()
        
        # Mock model loading
        with patch('app.services.huggingface_compat.SentenceTransformer') as mock_st:
            mock_model = Mock()
            mock_st.return_value = mock_model
            
            model = await compat.load_model("test-model")
            assert model is not None
    
    @pytest.mark.asyncio
    async def test_cache_management(self):
        """Test cache management operations."""
        compat = HuggingFaceCompatibility()
        
        # Test cache size calculation
        size = await compat.get_cache_size()
        assert isinstance(size, int)
        assert size >= 0
        
        # Test cache cleanup
        result = await compat.cleanup_cache(max_age_days=30)
        assert isinstance(result, bool)


# =============================================================================
# INTEGRATION TESTS FOR SERVICE INTERACTIONS
# =============================================================================

class TestServiceIntegration:
    """Test interactions between different services."""
    
    @pytest.mark.asyncio
    async def test_cache_embedding_integration(self, mock_redis_client):
        """Test integration between cache and embedding services."""
        # Setup cache service
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        # Setup embedding service with caching
        with patch('app.services.embedding_service.SentenceTransformer'):
            embedding_service = EmbeddingService()
            embedding_service.cache = cache_service
            embedding_service.model = Mock()
            embedding_service.model.encode.return_value = np.array([[0.1, 0.2, 0.3]])
            await embedding_service.initialize()
        
        # Test cached embedding generation
        text = "Hello world"
        embedding1 = await embedding_service.get_or_generate_embedding(text)
        embedding2 = await embedding_service.get_or_generate_embedding(text)
        
        assert len(embedding1) == 3
        assert np.array_equal(embedding1, embedding2)
    
    @pytest.mark.asyncio
    async def test_message_analytics_integration(self):
        """Test integration between message service and analytics."""
        # Setup services
        message_service = MessageService()
        analytics_service = MessageAnalyticsService()
        
        # Mock message data
        messages = [
            {"content": "Hello", "timestamp": datetime.now()},
            {"content": "Hi there!", "timestamp": datetime.now()}
        ]
        
        # Test analytics calculation
        metrics = await analytics_service.analyze_messages(messages)
        
        assert isinstance(metrics, dict)
        assert "total_messages" in metrics
        assert metrics["total_messages"] == len(messages)
    
    @pytest.mark.asyncio
    async def test_security_analytics_integration(self):
        """Test integration between security and analytics services."""
        # Setup services
        security_service = MessageSecurityService()
        analytics_service = MessageAnalyticsService()
        
        # Test security-enhanced analytics
        messages = [
            {"content": "Normal message", "security_score": 1.0},
            {"content": "Suspicious message", "security_score": 0.3}
        ]
        
        metrics = await analytics_service.calculate_security_metrics(messages)
        
        assert isinstance(metrics, dict)
        assert "security_score_avg" in metrics


# =============================================================================
# PERFORMANCE AND STRESS TESTS
# =============================================================================

class TestServicePerformance:
    """Performance tests for services."""
    
    @pytest.mark.asyncio
    async def test_cache_performance(self, mock_redis_client):
        """Test cache service performance under load."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = mock_redis_client
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        # Performance test parameters
        num_operations = 1000
        start_time = time.time()
        
        # Execute batch operations
        for i in range(num_operations):
            await cache_service.set(f"perf_key_{i}", f"perf_value_{i}")
        
        # Measure performance
        end_time = time.time()
        duration = end_time - start_time
        ops_per_second = num_operations / duration
        
        # Performance assertions
        assert ops_per_second > 100  # At least 100 ops/second
        assert duration < 30  # Should complete within 30 seconds
    
    @pytest.mark.asyncio
    async def test_embedding_batch_performance(self):
        """Test embedding service batch performance."""
        with patch('app.services.embedding_service.SentenceTransformer'):
            service = EmbeddingService()
            service.model = Mock()
            service.model.encode.return_value = np.random.rand(100, 384)
            
            # Generate test texts
            texts = [f"Test text {i}" for i in range(1000)]
            
            start_time = time.time()
            embeddings = await service.generate_batch_embeddings(texts, batch_size=50)
            end_time = time.time()
            
            duration = end_time - start_time
            throughput = len(texts) / duration
            
            # Performance assertions
            assert len(embeddings) == len(texts)
            assert duration < 60  # Should complete within 60 seconds
            assert throughput > 10  # At least 10 texts/second
    
    @pytest.mark.asyncio
    async def test_memory_service_performance(self):
        """Test memory service performance."""
        service = MemoryService()
        service.redis_client = Mock()
        service.redis_client.pipeline.return_value = Mock()
        service.redis_client.pipeline.return_value.execute.return_value = AsyncMock()
        
        # Test batch memory operations
        num_operations = 500
        start_time = time.time()
        
        # Execute batch operations
        for i in range(num_operations):
            await service.store_memory(f"mem_key_{i}", f"mem_value_{i}")
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Performance assertions
        assert duration < 30  # Should complete within 30 seconds


# =============================================================================
# ERROR HANDLING AND RESILIENCE TESTS
# =============================================================================

class TestServiceResilience:
    """Test error handling and resilience of services."""
    
    @pytest.mark.asyncio
    async def test_cache_fallback_behavior(self):
        """Test cache service fallback when Redis is unavailable."""
        cache_service = RedisCacheService(enable_fallback=True)
        cache_service.redis_client = None  # No Redis available
        cache_service.fallback_cache = InMemoryFallbackCache()
        await cache_service.initialize()
        
        # Test operations with fallback only
        result = await cache_service.set("fallback_key", "fallback_value")
        assert result is True
        
        value = await cache_service.get("fallback_key")
        assert value == "fallback_value"
        
        # Test batch operations
        items = {"key1": "value1", "key2": "value2"}
        result = await cache_service.batch_set(items)
        assert result is True
    
    @pytest.mark.asyncio
    async def test_embedding_service_graceful_degradation(self):
        """Test embedding service graceful degradation."""
        service = EmbeddingService()
        service.model = None  # No model loaded
        
        # Test operations when model is unavailable
        with pytest.raises(Exception):
            await service.generate_embeddings(["test"])
        
        # Test cached embeddings when model is unavailable
        cached_embedding = await service.get_cached_embedding("test")
        assert cached_embedding is None
    
    @pytest.mark.asyncio
    async def test_message_service_error_handling(self):
        """Test message service error handling."""
        service = MessageService()
        test_db = Mock()
        test_db.execute.side_effect = Exception("Database error")
        
        # Test error handling in message operations
        result = await service.get_message_by_id("test-msg", test_db)
        assert result is None
        
        result = await service.get_next_sequence_number("test-session", test_db)
        assert result == 0  # Default value on error
    
    @pytest.mark.asyncio
    async def test_memory_service_error_recovery(self):
        """Test memory service error recovery."""
        service = MemoryService()
        service.redis_client = Mock()
        service.redis_client.get.side_effect = Exception("Redis error")
        
        # Test error recovery
        value = await service.get_memory("test_key")
        assert value is None  # Should handle error gracefully
        
        result = await service.delete_memory("test_key")
        assert result is False  # Should handle error gracefully


# =============================================================================
# TEST DATA AND FIXTURES
# =============================================================================

@pytest.fixture
def sample_embeddings():
    """Provide sample embeddings for testing."""
    return {
        "small": np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]),
        "medium": np.random.rand(100, 384),
        "large": np.random.rand(1000, 768)
    }


@pytest.fixture
def sample_messages():
    """Provide sample messages for testing."""
    return [
        {
            "id": "msg1",
            "content": "Hello, how are you?",
            "role": "user",
            "timestamp": datetime.now(),
            "session_id": "session1"
        },
        {
            "id": "msg2",
            "content": "I'm doing well, thank you!",
            "role": "assistant",
            "timestamp": datetime.now(),
            "session_id": "session1"
        },
        {
            "id": "msg3",
            "content": "Can you help me with this task?",
            "role": "user",
            "timestamp": datetime.now(),
            "session_id": "session1"
        }
    ]


@pytest.fixture
def cache_test_data():
    """Provide test data for cache testing."""
    return {
        "string_data": {"key": "string_value"},
        "json_data": {"key": "json_value", "nested": {"value": 42}},
        "complex_data": {
            "datetime": datetime.now(),
            "list": [1, 2, 3],
            "dict": {"nested": "value"}
        },
        "binary_data": b"\x00\x01\x02\x03\x04"
    }


# =============================================================================
# MARKERS CONFIGURATION
# =============================================================================

pytest.mark.unit = pytest.mark.unit
pytest.mark.integration = pytest.mark.integration
pytest.mark.slow = pytest.mark.slow
pytest.mark.performance = pytest.mark.performance
pytest.mark.resilience = pytest.mark.resilience

# Test execution markers
pytest.mark.asyncioyncio = pytest.mark.asyncio


# =============================================================================
# TEST SUITE CONFIGURATION
# =============================================================================

def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line(
        "markers", "unit: Unit tests for individual components"
    )
    config.addinivalue_line(
        "markers", "integration: Integration tests for service interactions"
    )
    config.addinivalue_line(
        "markers", "slow: Slow running tests that should be skipped in quick runs"
    )
    config.addinivalue_line(
        "markers", "performance: Performance and stress tests"
    )
    config.addinivalue_line(
        "markers", "resilience: Error handling and resilience tests"
    )


def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on test names."""
    for item in items:
        # Add performance marker to performance tests
        if "performance" in item.name.lower():
            item.add_marker(pytest.mark.performance)
        
        # Add resilience marker to resilience tests
        if "resilience" in item.name.lower() or "error" in item.name.lower():
            item.add_marker(pytest.mark.resilience)
        
        # Add slow marker to tests with large datasets
        if any(keyword in item.name.lower() for keyword in ["batch", "large", "stress"]):
            item.add_marker(pytest.mark.slow)