"""
Unit tests for configuration management.

Tests the enhanced configuration system including environment-specific 
configurations, validation, migration, and security features.
"""

import pytest
import os
import tempfile
import json
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock
import asyncio

# Import configuration modules
try:
    from app.config import Settings
    CONFIG_AVAILABLE = True
except ImportError:
    CONFIG_AVAILABLE = False
    pytest.skip("Configuration modules not available", allow_module_level=True)

from tests.utils.test_data_generator import TestDataGenerator


class TestSettings:
    """Test main Settings class."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_settings_creation(self, test_data_gen):
        """Test basic settings creation."""
        settings = Settings()
        
        # Test basic attributes
        assert settings.environment in ["development", "production", "testing"]
        assert settings.app_name == "Customer Support AI Agent"
        assert settings.app_version == "1.0.0"
        
        # Test environment detection
        assert hasattr(settings, 'is_development')
        assert hasattr(settings, 'is_production') 
        assert hasattr(settings, 'is_testing')
        assert hasattr(settings, 'is_development') in [True, False]
    
    def test_environment_detection(self, test_data_gen):
        """Test environment detection functionality."""
        settings = Settings()
        
        # Test environment-specific flags
        if settings.environment == "development":
            assert settings.is_development == True
            assert settings.is_production == False
        elif settings.environment == "production":
            assert settings.is_development == False
            assert settings.is_production == True
        else:  # testing
            assert settings.is_development == False
            assert settings.is_production == False
    
    def test_configuration_validation(self, test_data_gen):
        """Test configuration validation."""
        settings = Settings()
        validation_result = settings.validate_configuration()
        
        assert "valid" in validation_result
        assert "issues" in validation_result
        assert "configuration_summary" in validation_result
        assert isinstance(validation_result["valid"], bool)
        assert isinstance(validation_result["issues"], list)
    
    @pytest.mark.skipif(not CONFIG_AVAILABLE, reason="Configuration not available")
    def test_configuration_loading(self, test_data_gen):
        """Test configuration loading from environment."""
        # Test with different environment variables
        test_env = {
            "ENVIRONMENT": "testing",
            "DATABASE_URL": "sqlite:///./test.db",
            "SECRET_KEY": "test_secret_key_for_configuration_testing_123456",
            "LOG_LEVEL": "DEBUG",
            "API_HOST": "127.0.0.1",
            "API_PORT": "8000"
        }
        
        with patch.dict(os.environ, test_env, clear=True):
            settings = Settings()
            
            assert settings.environment == "testing"
            assert "test.db" in settings.database_url
            assert settings.log_level == "DEBUG"
            assert settings.api_host == "127.0.0.1"
            assert settings.api_port == 8000
    
    def test_hot_reload_monitoring(self, test_data_gen):
        """Test configuration monitoring for hot-reloading."""
        settings = Settings()
        
        if hasattr(settings, 'ConfigurationMonitor'):
            monitor = settings.ConfigurationMonitor(settings)
            
            # Test adding callbacks
            def test_callback(change):
                pass
            
            monitor.add_callback(test_callback)
            assert len(monitor._callbacks) == 1
            
            # Test callback removal
            monitor.remove_callback(test_callback)
            assert len(monitor._callbacks) == 0
    
    def test_sensitive_data_handling(self, test_data_gen):
        """Test sensitive data handling."""
        settings = Settings()
        
        # Test that sensitive data is properly handled
        sensitive_fields = ['secret_key', 'jwt_secret_key', 'api_key']
        
        for field in sensitive_fields:
            if hasattr(settings, field):
                value = getattr(settings, field)
                # Should not be empty
                assert value is not None
                assert len(str(value)) > 0
    
    def test_directory_creation(self, test_data_gen):
        """Test automatic directory creation."""
        settings = Settings()
        
        if hasattr(settings, 'create_directories'):
            with tempfile.TemporaryDirectory() as temp_dir:
                original_dirs = getattr(settings, '_directories', [])
                
                # Test directory creation (mock)
                try:
                    settings.create_directories()
                    # If no exception, directories were created successfully
                    assert True
                except Exception as e:
                    # Some directories might fail to create in test environment
                    pytest.skip(f"Directory creation test skipped: {e}")


class TestDatabaseConfig:
    """Test DatabaseConfig functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_database_config_creation(self, test_data_gen):
        """Test database configuration creation."""
        from config.database import DatabaseConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("DatabaseConfig not available")
        
        config = DatabaseConfig()
        assert config.database_url is not None
        assert hasattr(config, 'db_pool_size')
    
    def test_database_type_detection(self, test_data_gen):
        """Test database type detection."""
        from config.database import DatabaseConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("DatabaseConfig not available")
        
        config = DatabaseConfig()
        
        # Test connection args generation
        if hasattr(config, 'get_connection_args'):
            args = config.get_connection_args()
            assert isinstance(args, dict)
        
        # Test engine kwargs generation  
        if hasattr(config, 'get_engine_kwargs'):
            engine_kwargs = config.get_engine_kwargs()
            assert "pool_size" in engine_kwargs
            assert engine_kwargs["pool_size"] > 0
    
    @pytest.mark.asyncio
    async def test_database_connection_validation(self, test_data_gen):
        """Test database connection validation."""
        from config.database import DatabaseConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("DatabaseConfig not available")
        
        config = DatabaseConfig()
        
        if hasattr(config, 'validate_connection'):
            # Test validation (might fail in test environment)
            try:
                result = await config.validate_connection()
                assert "valid" in result
            except Exception as e:
                # Connection validation might fail in test environment
                assert "connection" in str(e).lower() or "database" in str(e).lower()


class TestRedisConfig:
    """Test RedisConfig functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_redis_config_creation(self, test_data_gen):
        """Test Redis configuration creation."""
        from config.redis import RedisConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("RedisConfig not available")
        
        config = RedisConfig()
        assert config.redis_host is not None
        assert config.redis_port > 0
        assert 0 <= config.redis_db <= 15
    
    def test_redis_connection_kwargs(self, test_data_gen):
        """Test Redis connection kwargs generation."""
        from config.redis import RedisConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("RedisConfig not available")
        
        config = RedisConfig()
        
        if hasattr(config, 'get_connection_kwargs'):
            kwargs = config.get_connection_kwargs()
            
            assert "max_connections" in kwargs
            assert "connection_timeout" in kwargs
            assert kwargs["max_connections"] > 0
            assert kwargs["connection_timeout"] > 0
    
    @pytest.mark.asyncio
    async def test_redis_validation(self, test_data_gen):
        """Test Redis configuration validation."""
        from config.redis import RedisConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("RedisConfig not available")
        
        config = RedisConfig()
        
        if hasattr(config, 'validate_configuration'):
            try:
                result = await config.validate_configuration()
                assert "valid" in result
            except Exception as e:
                # Redis validation might fail in test environment
                assert "redis" in str(e).lower() or "connection" in str(e).lower()


class TestSecurityConfig:
    """Test SecurityConfig functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_security_config_creation(self, test_data_gen):
        """Test security configuration creation."""
        from config.security import SecurityConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("SecurityConfig not available")
        
        config = SecurityConfig()
        assert config.secret_key is not None
        assert config.jwt_secret_key is not None
        
        if hasattr(config, 'jwt_algorithm'):
            assert config.jwt_algorithm in ["HS256", "HS384", "HS512"]
    
    def test_password_validation(self, test_data_gen):
        """Test password validation functionality."""
        from config.security import SecurityConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("SecurityConfig not available")
        
        config = SecurityConfig()
        
        if hasattr(config, 'validate_password'):
            # Test strong password
            strong_password = "StrongPass123!@#"
            result = config.validate_password(strong_password)
            assert isinstance(result, dict)
            assert "valid" in result
            
            # Test weak password
            weak_password = "123"
            result = config.validate_password(weak_password)
            assert isinstance(result, dict)
            assert not result["valid"]
    
    def test_security_validation(self, test_data_gen):
        """Test security configuration validation."""
        from config.security import SecurityConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("SecurityConfig not available")
        
        config = SecurityConfig()
        
        if hasattr(config, 'validate_configuration'):
            result = config.validate_configuration()
            assert "valid" in result
    
    def test_cors_settings(self, test_data_gen):
        """Test CORS settings generation."""
        from config.security import SecurityConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("SecurityConfig not available")
        
        config = SecurityConfig()
        
        if hasattr(config, 'get_cors_settings'):
            cors_settings = config.get_cors_settings()
            
            assert isinstance(cors_settings, dict)
            assert "allow_origins" in cors_settings
            assert "allow_credentials" in cors_settings


class TestAIConfig:
    """Test AIConfig functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_ai_config_creation(self, test_data_gen):
        """Test AI configuration creation."""
        from config.ai import AIConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("AIConfig not available")
        
        config = AIConfig()
        
        if hasattr(config, 'llm_provider'):
            assert config.llm_provider in ["openai", "azure_openai", "anthropic", "cohere"]
        
        if hasattr(config, 'openai_temperature'):
            assert 0.0 <= config.openai_temperature <= 2.0
    
    def test_provider_detection(self, test_data_gen):
        """Test LLM provider detection."""
        from config.ai import AIConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("AIConfig not available")
        
        config = AIConfig()
        
        if hasattr(config, 'active_llm_provider'):
            active_provider = config.active_llm_provider
            # Should be either None or a valid provider
            assert active_provider is None or active_provider in ["openai", "azure_openai", "anthropic", "cohere"]
        
        if hasattr(config, 'get_embedding_config'):
            embedding_config = config.get_embedding_config()
            assert isinstance(embedding_config, dict)
    
    def test_ai_validation(self, test_data_gen):
        """Test AI configuration validation."""
        from config.ai import AIConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("AIConfig not available")
        
        config = AIConfig()
        
        if hasattr(config, 'validate_configuration'):
            result = config.validate_configuration()
            assert "valid" in result
    
    def test_cost_estimation(self, test_data_gen):
        """Test cost estimation functionality."""
        from config.ai import AIConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("AIConfig not available")
        
        config = AIConfig()
        
        if hasattr(config, 'get_cost_estimate'):
            cost = config.get_cost_estimate(prompt_tokens=100, completion_tokens=50)
            assert isinstance(cost, float)
            assert cost >= 0.0


class TestMonitoringConfig:
    """Test MonitoringConfig functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_monitoring_config_creation(self, test_data_gen):
        """Test monitoring configuration creation."""
        from config.monitoring import MonitoringConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("MonitoringConfig not available")
        
        config = MonitoringConfig()
        assert config.log_level in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        
        if hasattr(config, 'prometheus_port'):
            assert config.prometheus_port > 0
    
    def test_logging_config(self, test_data_gen):
        """Test logging configuration."""
        from config.monitoring import MonitoringConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("MonitoringConfig not available")
        
        config = MonitoringConfig()
        
        if hasattr(config, 'get_logging_config'):
            logging_config = config.get_logging_config()
            
            assert isinstance(logging_config, dict)
            assert "version" in logging_config
            assert "formatters" in logging_config
    
    def test_monitoring_validation(self, test_data_gen):
        """Test monitoring configuration validation."""
        from config.monitoring import MonitoringConfig
        
        if not CONFIG_AVAILABLE:
            pytest.skip("MonitoringConfig not available")
        
        config = MonitoringConfig()
        
        if hasattr(config, 'validate_configuration'):
            result = config.validate_configuration()
            assert "valid" in result


class TestConfigurationValidator:
    """Test ConfigurationValidator functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_validator_creation(self, test_data_gen):
        """Test validator creation."""
        from config.config_validator import ConfigurationValidator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationValidator not available")
        
        validator = ConfigurationValidator()
        assert validator is not None
        
        if hasattr(validator, 'validation_rules'):
            assert isinstance(validator.validation_rules, dict)
        
        if hasattr(validator, 'dependency_graph'):
            assert isinstance(validator.dependency_graph, dict)
    
    def test_environment_validation(self, test_data_gen):
        """Test environment-specific validation."""
        from config.config_validator import ConfigurationValidator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationValidator not available")
        
        validator = ConfigurationValidator()
        
        if hasattr(validator, 'validate_environment_config'):
            # Test valid environment
            result = validator.validate_environment_config("development")
            assert hasattr(result, 'valid')
            
            # Test invalid environment
            result = validator.validate_environment_config("invalid_env")
            assert hasattr(result, 'valid')
    
    def test_comprehensive_validation(self, test_data_gen):
        """Test comprehensive configuration validation."""
        from config.config_validator import ConfigurationValidator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationValidator not available")
        
        validator = ConfigurationValidator()
        
        if hasattr(validator, 'validate_comprehensive'):
            # Sample configuration
            sample_config = {
                "environment": "development",
                "secret_key": "a" * 32,
                "database_url": "sqlite:///./test.db"
            }
            
            result = validator.validate_comprehensive(sample_config)
            assert hasattr(result, 'valid')


class TestConfigurationLoader:
    """Test ConfigurationLoader functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_loader_creation(self, test_data_gen):
        """Test loader creation."""
        from config.config_loader import ConfigurationLoader
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationLoader not available")
        
        loader = ConfigurationLoader()
        assert loader is not None
        
        if hasattr(loader, 'config_sources'):
            assert isinstance(loader.config_sources, list)
        
        if hasattr(loader, 'base_path'):
            assert loader.base_path is not None
    
    def test_environment_detection(self, test_data_gen):
        """Test environment detection."""
        from config.config_loader import ConfigurationLoader, Environment
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationLoader not available")
        
        loader = ConfigurationLoader()
        
        if hasattr(loader, 'set_environment'):
            loader.set_environment("production")
            assert hasattr(loader, 'environment')
        
        if hasattr(loader, 'detect_environment'):
            # Test automatic detection with mocked environment
            with patch.dict(os.environ, {"ENVIRONMENT": "testing"}):
                detected_env = loader.detect_environment()
                assert detected_env in [Environment.TESTING, Environment.DEVELOPMENT, Environment.PRODUCTION]
    
    def test_config_loading(self, test_data_gen):
        """Test configuration loading from files."""
        from config.config_loader import ConfigurationLoader
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationLoader not available")
        
        loader = ConfigurationLoader()
        
        if hasattr(loader, 'load_all_configs'):
            # Create temporary config file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                config_data = {"test": "value", "number": 42}
                json.dump(config_data, f)
                temp_file = f.name
            
            try:
                # Test loading (might fail in test environment)
                try:
                    loaded_config = loader.load_all_configs()
                    assert loaded_config is not None
                except Exception as e:
                    # Config loading might fail in test environment
                    assert "config" in str(e).lower() or "file" in str(e).lower()
            finally:
                os.unlink(temp_file)
    
    def test_config_merging(self, test_data_gen):
        """Test configuration merging."""
        from config.config_loader import ConfigurationLoader
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationLoader not available")
        
        loader = ConfigurationLoader()
        
        if hasattr(loader, 'merge_configs'):
            configs = [
                {"a": 1, "common": "first"},
                {"b": 2, "common": "second"},
                {"c": {"nested": "value"}}
            ]
            
            merged = loader.merge_configs(configs)
            assert merged["a"] == 1
            assert merged["b"] == 2
            assert merged["c"]["nested"] == "value"
            assert merged["common"] == "second"  # Last value wins


class TestConfigurationMigrator:
    """Test ConfigurationMigrator functionality."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_migrator_creation(self, test_data_gen):
        """Test migrator creation."""
        from config.config_migration import ConfigurationMigrator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationMigrator not available")
        
        migrator = ConfigurationMigrator()
        assert migrator is not None
        
        if hasattr(migrator, 'migration_rules'):
            assert isinstance(migrator.migration_rules, list)
    
    def test_migration_operations(self, test_data_gen):
        """Test various migration operations."""
        from config.config_migration import ConfigurationMigrator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationMigrator not available")
        
        migrator = ConfigurationMigrator()
        
        if hasattr(migrator, 'migrate_configuration'):
            # Test configuration migration
            old_config = {"version": "1.0", "old_setting": "value"}
            
            try:
                migrated_config = migrator.migrate_configuration(old_config, "1.0", "1.1")
                assert migrated_config is not None
            except ValueError:
                # Migration path not found, which is expected for test configs
                pytest.skip("Migration path not found in test environment")
    
    def test_validation_after_migration(self, test_data_gen):
        """Test validation after migration."""
        from config.config_migration import ConfigurationMigrator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("ConfigurationMigrator not available")
        
        migrator = ConfigurationMigrator()
        
        if hasattr(migrator, 'validate_migration'):
            old_config = {"old_key": "value"}
            new_config = {"new_key": "value"}
            
            validation = migrator.validate_migration(old_config, new_config)
            assert "valid" in validation
            assert "warnings" in validation


class TestIntegration:
    """Integration tests for the complete configuration system."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_full_configuration_loading(self, test_data_gen):
        """Test complete configuration loading pipeline."""
        from config.config_loader import ConfigurationLoader, Environment
        
        if not CONFIG_AVAILABLE:
            pytest.skip("Configuration modules not available")
        
        try:
            loader = ConfigurationLoader()
            
            # Detect environment
            env = loader.detect_environment()
            assert env in [Environment.DEVELOPMENT, Environment.PRODUCTION, Environment.TESTING]
            
            # Load configuration
            if hasattr(loader, 'load_all_configs'):
                config = loader.load_all_configs(env)
                assert config is not None
                
                if hasattr(config, '_environment'):
                    assert config._environment == env
        except Exception as e:
            # Configuration loading might fail in test environment
            pytest.skip(f"Configuration loading test skipped: {e}")
    
    def test_configuration_validation_pipeline(self, test_data_gen):
        """Test configuration validation pipeline."""
        from config.config_validator import ConfigurationValidator
        
        if not CONFIG_AVAILABLE:
            pytest.skip("Configuration modules not available")
        
        try:
            validator = ConfigurationValidator()
            
            # Test with a minimal valid configuration
            config = {
                "environment": "development",
                "secret_key": "a" * 32,
                "database_url": "sqlite:///./test.db",
            }
            
            if hasattr(validator, 'validate_comprehensive'):
                result = validator.validate_comprehensive(config)
                
                # Results might vary in test environment
                assert hasattr(result, 'valid') or isinstance(result, dict)
        except Exception as e:
            # Validation might fail in test environment
            pytest.skip(f"Configuration validation test skipped: {e}")
    
    def test_settings_with_config_modules(self, test_data_gen):
        """Test Settings class with imported config modules."""
        if not CONFIG_AVAILABLE:
            pytest.skip("Configuration modules not available")
        
        try:
            settings = Settings()
            
            # Test that settings can be created
            assert settings.environment is not None
            
            # Test validation
            if hasattr(settings, 'validate_configuration'):
                validation = settings.validate_configuration()
                assert isinstance(validation, dict)
        except Exception as e:
            # Settings creation might fail in test environment
            pytest.skip(f"Settings creation test skipped: {e}")


class TestConfigurationHelpers:
    """Test configuration helper functions."""
    
    @pytest.fixture
    def test_data_gen(self):
        return TestDataGenerator(seed=42)
    
    def test_environment_specific_configs(self, test_data_gen):
        """Test environment-specific configuration differences."""
        if not CONFIG_AVAILABLE:
            pytest.skip("Configuration not available")
        
        try:
            dev_config = Settings(environment="development")
            prod_config = Settings(environment="production")
            test_config = Settings(environment="testing")
            
            # Each should have appropriate settings
            assert dev_config.environment == "development"
            assert prod_config.environment == "production"
            assert test_config.environment == "testing"
        except Exception as e:
            pytest.skip(f"Environment-specific config test skipped: {e}")
    
    def test_configuration_export(self, test_data_gen):
        """Test configuration export functionality."""
        if not CONFIG_AVAILABLE:
            pytest.skip("Configuration not available")
        
        settings = Settings()
        
        if hasattr(settings, 'export_to_env_file'):
            with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
                try:
                    settings.export_to_env_file(f.name)
                    
                    # Check that file was created and contains data
                    with open(f.name, 'r') as read_f:
                        content = read_f.read()
                        assert len(content) > 0
                        
                except Exception as e:
                    pytest.skip(f"Configuration export test skipped: {e}")
                finally:
                    os.unlink(f.name)


# Test data and helper fixtures
@pytest.fixture
def sample_config_data(test_data_gen):
    """Provide sample configuration data for testing."""
    return test_data_gen.generate_user()


@pytest.fixture
def environment_vars():
    """Provide test environment variables."""
    test_env = {
        "ENVIRONMENT": "testing",
        "DATABASE_URL": "sqlite:///./test.db",
        "REDIS_HOST": "localhost",
        "SECRET_KEY": "test_secret_key_32_chars_long_for_testing",
        "JWT_SECRET_KEY": "test_jwt_secret_key_32_chars_long_for_testing",
        "LOG_LEVEL": "INFO",
    }
    
    with patch.dict(os.environ, test_env, clear=False):
        yield test_env


@pytest.fixture
def temp_config_dir():
    """Create a temporary directory for configuration files."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)


if __name__ == "__main__":
    # Run basic smoke tests
    print("Running configuration management tests...")
    
    try:
        if CONFIG_AVAILABLE:
            # Test basic settings creation
            settings = Settings()
            print(f"✓ Settings created successfully")
            print(f"  - Environment: {settings.environment}")
            print(f"  - App name: {settings.app_name}")
            
            # Test validation
            validation = settings.validate_configuration()
            print(f"✓ Configuration validation completed")
            print(f"  - Valid: {validation['valid']}")
            print(f"  - Issues: {len(validation['issues'])}")
            
        else:
            print("⚠ Configuration modules not available for testing")
        
        print("\n🎉 Configuration management system test completed!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise