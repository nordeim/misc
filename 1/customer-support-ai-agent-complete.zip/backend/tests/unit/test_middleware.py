"""
Comprehensive unit tests for all middleware components.

This test module covers:
- Error Handling Middleware (global exception handling, structured responses)
- CORS Middleware (cross-origin resource sharing configuration)
- Logging Middleware (request/response logging, structured logging)
- Rate Limiting Middleware (rate limiting, throttling, quotas)
- Security Middleware (security headers, CSRF protection, validation)

Uses pytest fixtures from conftest.py and test utilities from utils package.
"""

import pytest
import asyncio
import json
import time
import uuid
from datetime import datetime, timedelta
from unittest.mock import Mock, AsyncMock, patch, MagicMock, call
from typing import Dict, Any, Optional, List
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response as StarletteResponse
from starlette.testclient import TestClient
from starlette.applications import Starlette
from starlette.routing import Route
import structlog

# Import middleware components
from app.middleware.error_handling import (
    ErrorHandlingMiddleware,
    ErrorSeverity,
    ErrorCategory,
    ErrorResponse,
    global_exception_handler,
    validation_exception_handler,
    http_exception_handler,
    authentication_exception_handler,
    general_exception_handler
)
from app.middleware.cors import CORSMiddleware
from app.middleware.logging import (
    LoggingMiddleware,
    RequestLogger,
    ResponseLogger,
    StructuredLogger,
    RequestLoggingConfig
)
from app.middleware.rate_limiting import (
    RateLimitingMiddleware,
    RateLimiter,
    TokenBucketLimiter,
    SlidingWindowLimiter,
    RateLimitExceeded,
    RateLimitConfig,
    RateLimitStorage
)
from app.middleware.security import (
    SecurityMiddleware,
    SecurityHeaders,
    CSRFProtection,
    ContentSecurityPolicy,
    SecurityConfig,
    SecurityValidator,
    InputValidator,
    OutputSanitizer
)

# Import test utilities
from tests.utils.test_data_generator import TestDataGenerator
from tests.utils.auth_helpers import AuthTestHelper
from tests.utils.performance_testing import PerformanceProfiler


# =============================================================================
# ERROR HANDLING MIDDLEWARE TESTS
# =============================================================================

class TestErrorHandlingMiddleware:
    """Test error handling middleware functionality."""
    
    @pytest.fixture
    def test_app(self):
        """Create test FastAPI application with error handling middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add error handling middleware
        app.add_middleware(ErrorHandlingMiddleware)
        
        # Add test routes
        @app.get("/test/normal")
        async def normal_endpoint():
            return {"message": "normal response"}
        
        @app.get("/test/http-error")
        async def http_error_endpoint():
            raise HTTPException(status_code=404, detail="Not found")
        
        @app.get("/test/validation-error")
        async def validation_error_endpoint():
            from fastapi.exceptions import RequestValidationError
            raise RequestValidationError(errors=[{"loc": ["body"], "msg": "Invalid data"}])
        
        @app.get("/test/general-error")
        async def general_error_endpoint():
            raise ValueError("Something went wrong")
        
        @app.get("/test/timeout-error")
        async def timeout_error_endpoint():
            await asyncio.sleep(10)  # Simulate timeout
            return {"message": "timeout response"}
        
        return app
    
    def test_error_response_structure(self):
        """Test ErrorResponse structure and methods."""
        # Test basic error response
        error_response = ErrorResponse(
            detail="Test error detail",
            error_type="TEST_ERROR",
            category=ErrorCategory.VALIDATION_ERROR,
            severity=ErrorSeverity.MEDIUM,
            status_code=400,
            correlation_id="test-correlation-id",
            details={"field": "value"},
            suggestions=["Try again", "Check input"]
        )
        
        # Test to_dict conversion
        error_dict = error_response.to_dict()
        assert "error" in error_dict
        assert error_dict["error"]["type"] == "TEST_ERROR"
        assert error_dict["error"]["category"] == "validation_error"
        assert error_dict["error"]["severity"] == "medium"
        assert error_dict["error"]["detail"] == "Test error detail"
        assert error_dict["error"]["correlation_id"] == "test-correlation-id"
        assert error_dict["error"]["details"]["field"] == "value"
        assert "Try again" in error_dict["error"]["suggestions"]
        
        # Test to_response conversion
        response = error_response.to_response()
        assert isinstance(response, JSONResponse)
        assert response.status_code == 400
    
    def test_error_severity_enum(self):
        """Test error severity levels."""
        assert ErrorSeverity.LOW.value == "low"
        assert ErrorSeverity.MEDIUM.value == "medium"
        assert ErrorSeverity.HIGH.value == "high"
        assert ErrorSeverity.CRITICAL.value == "critical"
    
    def test_error_category_enum(self):
        """Test error categories."""
        assert ErrorCategory.VALIDATION_ERROR.value == "validation_error"
        assert ErrorCategory.AUTHENTICATION_ERROR.value == "authentication_error"
        assert ErrorCategory.AUTHORIZATION_ERROR.value == "authorization_error"
        assert ErrorCategory.NOT_FOUND_ERROR.value == "not_found_error"
        assert ErrorCategory.CONFLICT_ERROR.value == "conflict_error"
        assert ErrorCategory.RATE_LIMIT_ERROR.value == "rate_limit_error"
    
    @pytest.mark.asyncio
    async def test_global_exception_handler(self):
        """Test global exception handler."""
        request = Mock(spec=Request)
        request.url = "http://test.com"
        request.method = "GET"
        
        # Test with ValueError
        exception = ValueError("Test error")
        response = await global_exception_handler(request, exception)
        
        assert isinstance(response, JSONResponse)
        assert response.status_code == 500
        
        response_data = json.loads(response.body.decode())
        assert "error" in response_data
        assert response_data["error"]["type"] == "ValueError"
        assert response_data["error"]["category"] == "unknown_error"
    
    @pytest.mark.asyncio
    async def test_http_exception_handler(self):
        """Test HTTP exception handler."""
        request = Mock(spec=Request)
        
        # Test with HTTPException
        exception = HTTPException(status_code=404, detail="Not found")
        response = await http_exception_handler(request, exception)
        
        assert isinstance(response, JSONResponse)
        assert response.status_code == 404
        
        response_data = json.loads(response.body.decode())
        assert "error" in response_data
        assert response_data["error"]["type"] == "HTTPException"
        assert response_data["error"]["detail"] == "Not found"
    
    @pytest.mark.asyncio
    async def test_validation_exception_handler(self):
        """Test validation exception handler."""
        request = Mock(spec=Request)
        
        # Test with RequestValidationError
        from fastapi.exceptions import RequestValidationError
        exception = RequestValidationError(
            errors=[
                {"loc": ["body", "field1"], "msg": "field required", "type": "value_error.missing"},
                {"loc": ["body", "field2"], "msg": "ensure value is positive", "type": "value_error.number.not_positive"}
            ]
        )
        
        response = await validation_exception_handler(request, exception)
        
        assert isinstance(response, JSONResponse)
        assert response.status_code == 422
        
        response_data = json.loads(response.body.decode())
        assert "error" in response_data
        assert response_data["error"]["category"] == "validation_error"
        assert "details" in response_data["error"]
    
    @pytest.mark.asyncio
    async def test_authentication_exception_handler(self):
        """Test authentication exception handler."""
        request = Mock(spec=Request)
        
        # Test with authentication error
        from fastapi.security import HTTPBearer
        from fastapi import Depends
        from fastapi.security.http import HTTPBasicCredentials
        
        # Mock authentication exception
        exception = HTTPException(
            status_code=401,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"}
        )
        
        response = await authentication_exception_handler(request, exception)
        
        assert isinstance(response, JSONResponse)
        assert response.status_code == 401
        
        response_data = json.loads(response.body.decode())
        assert "error" in response_data
        assert response_data["error"]["category"] == "authentication_error"
    
    def test_error_middleware_integration(self, test_app):
        """Test error middleware integration with FastAPI app."""
        client = TestClient(test_app)
        
        # Test normal request
        response = client.get("/test/normal")
        assert response.status_code == 200
        assert response.json() == {"message": "normal response"}
        
        # Test HTTP error
        response = client.get("/test/http-error")
        assert response.status_code == 404
        response_data = response.json()
        assert "error" in response_data
        assert response_data["error"]["category"] == "not_found_error"
        
        # Test validation error
        response = client.get("/test/validation-error")
        assert response.status_code == 422
        response_data = response.json()
        assert "error" in response_data
        assert response_data["error"]["category"] == "validation_error"
        
        # Test general error
        response = client.get("/test/general-error")
        assert response.status_code == 500
        response_data = response.json()
        assert "error" in response_data


# =============================================================================
# CORS MIDDLEWARE TESTS
# =============================================================================

class TestCORSMiddleware:
    """Test CORS middleware functionality."""
    
    @pytest.fixture
    def cors_app(self):
        """Create test app with CORS middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add CORS middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["http://localhost:3000", "https://example.com"],
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "DELETE"],
            allow_headers=["*"],
            expose_headers=["X-Total-Count", "X-Page-Info"]
        )
        
        # Add test route
        @app.get("/test/cors")
        async def cors_endpoint():
            return {"message": "CORS response"}
        
        return app
    
    def test_cors_allow_origin(self, cors_app):
        """Test CORS allow origin functionality."""
        client = TestClient(cors_app)
        
        # Test request with allowed origin
        response = client.get(
            "/test/cors",
            headers={"Origin": "http://localhost:3000"}
        )
        
        assert response.status_code == 200
        assert response.headers["access-control-allow-origin"] == "http://localhost:3000"
        assert response.headers["access-control-allow-credentials"] == "true"
    
    def test_cors_preflight_request(self, cors_app):
        """Test CORS preflight OPTIONS request."""
        client = TestClient(cors_app)
        
        # Test OPTIONS preflight request
        response = client.options(
            "/test/cors",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "Content-Type"
            }
        )
        
        assert response.status_code == 200
        assert response.headers["access-control-allow-origin"] == "http://localhost:3000"
        assert response.headers["access-control-allow-methods"] == "GET, POST, PUT, DELETE"
        assert response.headers["access-control-allow-headers"] == "*"
    
    def test_cors_disallowed_origin(self, cors_app):
        """Test CORS with disallowed origin."""
        client = TestClient(cors_app)
        
        # Test request with disallowed origin
        response = client.get(
            "/test/cors",
            headers={"Origin": "http://evil.com"}
        )
        
        # Should not include CORS headers for disallowed origin
        assert "access-control-allow-origin" not in response.headers
    
    def test_cors_expose_headers(self, cors_app):
        """Test CORS expose headers functionality."""
        client = TestClient(cors_app)
        
        response = client.get(
            "/test/cors",
            headers={"Origin": "http://localhost:3000"}
        )
        
        assert response.headers["access-control-expose-headers"] == "X-Total-Count, X-Page-Info"


# =============================================================================
# LOGGING MIDDLEWARE TESTS
# =============================================================================

class TestLoggingMiddleware:
    """Test logging middleware functionality."""
    
    @pytest.fixture
    def logging_app(self):
        """Create test app with logging middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add logging middleware
        app.add_middleware(LoggingMiddleware, config=RequestLoggingConfig())
        
        # Add test routes
        @app.get("/test/log-success")
        async def log_success():
            return {"message": "success"}
        
        @app.get("/test/log-error")
        async def log_error():
            raise HTTPException(status_code=500, detail="Internal error")
        
        @app.get("/test/log-slow")
        async def log_slow():
            await asyncio.sleep(0.1)  # Simulate slow operation
            return {"message": "slow response"}
        
        return app
    
    @pytest.fixture
    def mock_logger(self):
        """Mock logger for testing."""
        with patch('structlog.get_logger') as mock_get_logger:
            mock_logger = Mock()
            mock_get_logger.return_value = mock_logger
            yield mock_logger
    
    def test_request_logging(self, logging_app, mock_logger):
        """Test request logging functionality."""
        client = TestClient(logging_app)
        
        # Make request
        response = client.get("/test/log-success")
        
        assert response.status_code == 200
        
        # Verify logging calls
        assert mock_logger.info.call_count >= 1
        log_calls = [call for call in mock_logger.method_calls 
                    if call[0] in ['info', 'debug', 'warning', 'error']]
        assert len(log_calls) > 0
    
    def test_error_logging(self, logging_app, mock_logger):
        """Test error logging functionality."""
        client = TestClient(logging_app)
        
        # Make request that generates error
        response = client.get("/test/log-error")
        
        assert response.status_code == 500
        
        # Verify error logging
        error_calls = [call for call in mock_logger.method_calls 
                      if call[0] == 'error']
        assert len(error_calls) > 0
    
    def test_performance_logging(self, logging_app, mock_logger):
        """Test performance logging functionality."""
        client = TestClient(logging_app)
        
        # Make request
        response = client.get("/test/log-slow")
        
        assert response.status_code == 200
        
        # Verify performance metrics are logged
        perf_calls = [call for call in mock_logger.method_calls 
                     if any('duration' in str(call) or 'response_time' in str(call))]
        # Should have performance logging enabled
    
    def test_structured_logger(self):
        """Test structured logger functionality."""
        logger = StructuredLogger("test_logger")
        
        # Test structured logging
        with patch.object(logger, 'log_event') as mock_log_event:
            logger.log_event(
                level="info",
                event="test_event",
                extra_fields={"key": "value", "request_id": "123"}
            )
            
            mock_log_event.assert_called_once()
            call_args = mock_log_event.call_args
            assert call_args[1]["level"] == "info"
            assert call_args[1]["event"] == "test_event"
            assert call_args[1]["extra_fields"]["key"] == "value"


# =============================================================================
# RATE LIMITING MIDDLEWARE TESTS
# =============================================================================

class TestRateLimitingMiddleware:
    """Test rate limiting middleware functionality."""
    
    @pytest.fixture
    def rate_limit_app(self):
        """Create test app with rate limiting middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add rate limiting middleware
        app.add_middleware(
            RateLimitingMiddleware,
            config=RateLimitConfig(
                requests_per_minute=60,
                requests_per_hour=1000,
                burst_size=10
            )
        )
        
        # Add test routes
        @app.get("/test/rate-limited")
        async def rate_limited_endpoint():
            return {"message": "success"}
        
        @app.get("/test/admin")
        async def admin_endpoint():
            return {"message": "admin response"}
        
        return app
    
    @pytest.fixture
    def mock_rate_storage(self):
        """Mock rate limiting storage."""
        storage = Mock(spec=RateLimitStorage)
        storage.get_count.return_value = AsyncMock(return_value=0)
        storage.increment.return_value = AsyncMock(return_value=1)
        storage.reset.return_value = AsyncMock(return_value=True)
        storage.cleanup.return_value = AsyncMock(return_value=0)
        return storage
    
    def test_rate_limiter_basic(self, mock_rate_storage):
        """Test basic rate limiter functionality."""
        limiter = TokenBucketLimiter(
            capacity=10,
            refill_rate=1.0,
            storage=mock_rate_storage
        )
        
        # Test allowed requests
        for i in range(10):
            result = limiter.is_allowed("test_key")
            assert result.allowed is True
        
        # Test exceeded requests
        result = limiter.is_allowed("test_key")
        assert result.allowed is False
        assert result.retry_after > 0
    
    def test_sliding_window_limiter(self, mock_rate_storage):
        """Test sliding window rate limiter."""
        limiter = SlidingWindowLimiter(
            max_requests=100,
            window_size=60,  # 1 minute
            storage=mock_rate_storage
        )
        
        # Mock storage to return increasing counts
        mock_rate_storage.get_count.side_effect = [50, 80, 120]
        
        # Test requests within limit
        result1 = limiter.is_allowed("test_key")
        assert result1.allowed is True
        
        result2 = limiter.is_allowed("test_key")
        assert result2.allowed is True
        
        # Test requests exceeding limit
        result3 = limiter.is_allowed("test_key")
        assert result3.allowed is False
    
    def test_rate_limit_exceeded_exception(self):
        """Test RateLimitExceeded exception."""
        exception = RateLimitExceeded(
            retry_after=60,
            limit_type="requests_per_minute",
            limit=100,
            remaining=0
        )
        
        assert exception.retry_after == 60
        assert exception.limit_type == "requests_per_minute"
        assert exception.limit == 100
        assert exception.remaining == 0
    
    def test_rate_limit_config(self):
        """Test rate limit configuration."""
        config = RateLimitConfig(
            requests_per_minute=100,
            requests_per_hour=1000,
            burst_size=20,
            whitelist_ips=["127.0.0.1"],
            blacklist_ips=["10.0.0.1"]
        )
        
        assert config.requests_per_minute == 100
        assert config.requests_per_hour == 1000
        assert config.burst_size == 20
        assert "127.0.0.1" in config.whitelist_ips
        assert "10.0.0.1" in config.blacklist_ips
    
    @pytest.mark.asyncio
    async def test_rate_limit_storage_operations(self, mock_rate_storage):
        """Test rate limit storage operations."""
        # Test increment
        await mock_rate_storage.increment("test_key", 1)
        mock_rate_storage.increment.assert_called_once_with("test_key", 1)
        
        # Test get count
        count = await mock_rate_storage.get_count("test_key")
        assert isinstance(count, int)
        
        # Test reset
        result = await mock_rate_storage.reset("test_key")
        assert result is True
        
        # Test cleanup
        cleaned = await mock_rate_storage.cleanup()
        assert isinstance(cleaned, int)
    
    def test_rate_limit_middleware_integration(self, rate_limit_app):
        """Test rate limiting middleware integration."""
        client = TestClient(rate_limit_app)
        
        # Test successful requests
        for i in range(5):
            response = client.get("/test/rate-limited")
            assert response.status_code == 200
        
        # Note: Actual rate limiting would require configuration
        # and may not trigger in test environment with default settings


# =============================================================================
# SECURITY MIDDLEWARE TESTS
# =============================================================================

class TestSecurityMiddleware:
    """Test security middleware functionality."""
    
    @pytest.fixture
    def security_app(self):
        """Create test app with security middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add security middleware
        app.add_middleware(
            SecurityMiddleware,
            config=SecurityConfig(
                enable_csp=True,
                enable_hsts=True,
                enable_xss_protection=True,
                enable_content_type_nosniff=True,
                frame_options="DENY",
                content_security_policy={
                    "default-src": ["'self'"],
                    "script-src": ["'self'"],
                    "style-src": ["'self'", "https://fonts.googleapis.com"]
                }
            )
        )
        
        # Add test routes
        @app.get("/test/secure")
        async def secure_endpoint():
            return {"message": "secure response"}
        
        @app.post("/test/xss-vulnerable")
        async def xss_vulnerable_endpoint(data: Dict[str, Any]):
            return {"message": data.get("text", "")}
        
        return app
    
    def test_security_headers(self):
        """Test security headers generation."""
        headers = SecurityHeaders()
        
        # Test basic security headers
        result = headers.generate_headers()
        
        assert "X-Content-Type-Options" in result
        assert result["X-Content-Type-Options"] == "nosniff"
        assert "X-Frame-Options" in result
        assert "X-XSS-Protection" in result
        assert "Referrer-Policy" in result
    
    def test_content_security_policy(self):
        """Test Content Security Policy generation."""
        csp = ContentSecurityPolicy(
            default_src=["'self'"],
            script_src=["'self'", "https://cdn.example.com"],
            style_src=["'self'", "https://fonts.googleapis.com"]
        )
        
        policy = csp.generate_policy()
        
        assert "default-src 'self'" in policy
        assert "script-src 'self' https://cdn.example.com" in policy
        assert "style-src 'self' https://fonts.googleapis.com" in policy
    
    def test_csrf_protection(self):
        """Test CSRF protection functionality."""
        csrf = CSRFProtection(secret_key="test-secret-key")
        
        # Test token generation
        token = csrf.generate_token()
        assert isinstance(token, str)
        assert len(token) > 0
        
        # Test token validation
        is_valid = csrf.validate_token(token)
        assert is_valid is True
        
        # Test invalid token
        is_valid = csrf.validate_token("invalid-token")
        assert is_valid is False
    
    def test_security_validator(self):
        """Test security validator functionality."""
        validator = SecurityValidator()
        
        # Test SQL injection detection
        malicious_sql = "'; DROP TABLE users; --"
        is_safe = validator.validate_input(malicious_sql)
        assert is_safe is False
        
        # Test XSS detection
        malicious_xss = "<script>alert('xss')</script>"
        is_safe = validator.validate_input(malicious_xss)
        assert is_safe is False
        
        # Test normal input
        normal_input = "This is normal text"
        is_safe = validator.validate_input(normal_input)
        assert is_safe is True
    
    def test_input_validator(self):
        """Test input validation functionality."""
        validator = InputValidator()
        
        # Test length validation
        result = validator.validate_length("test", min_length=2, max_length=10)
        assert result.is_valid is True
        
        result = validator.validate_length("t", min_length=2)
        assert result.is_valid is False
        
        # Test pattern validation
        result = validator.validate_pattern("test@example.com", r"^[^@]+@[^@]+\.[^@]+$")
        assert result.is_valid is True
        
        result = validator.validate_pattern("invalid-email", r"^[^@]+@[^@]+\.[^@]+$")
        assert result.is_valid is False
    
    def test_output_sanitizer(self):
        """Test output sanitization functionality."""
        sanitizer = OutputSanitizer()
        
        # Test HTML sanitization
        dirty_html = "<script>alert('xss')</script><p>Safe content</p>"
        clean_html = sanitizer.sanitize_html(dirty_html)
        
        assert "<script>" not in clean_html
        assert "<p>Safe content</p>" in clean_html
        
        # Test URL sanitization
        malicious_url = "javascript:alert('xss')"
        clean_url = sanitizer.sanitize_url(malicious_url)
        
        assert not clean_url.startswith("javascript:")
    
    def test_security_config(self):
        """Test security configuration."""
        config = SecurityConfig(
            enable_csp=True,
            enable_hsts=True,
            enable_xss_protection=True,
            enable_content_type_nosniff=True,
            frame_options="DENY",
            hsts_max_age=31536000,
            content_security_policy={
                "default-src": ["'self'"]
            }
        )
        
        assert config.enable_csp is True
        assert config.enable_hsts is True
        assert config.frame_options == "DENY"
        assert config.hsts_max_age == 31536000
    
    def test_security_middleware_integration(self, security_app):
        """Test security middleware integration."""
        client = TestClient(security_app)
        
        response = client.get("/test/secure")
        
        # Check security headers are present
        assert "X-Content-Type-Options" in response.headers
        assert "X-Frame-Options" in response.headers
        assert "X-XSS-Protection" in response.headers
        assert "Referrer-Policy" in response.headers
        
        # Check CSP header if enabled
        if "Content-Security-Policy" in response.headers:
            csp = response.headers["Content-Security-Policy"]
            assert "default-src 'self'" in csp
    
    @pytest.mark.asyncio
    async def test_xss_protection_endpoint(self, security_app):
        """Test XSS protection on endpoint."""
        client = TestClient(security_app)
        
        # Test with potentially malicious input
        response = client.post(
            "/test/xss-vulnerable",
            json={"text": "<script>alert('xss')</script>"}
        )
        
        assert response.status_code == 200
        # Content should be sanitized or handled safely
        response_data = response.json()
        assert isinstance(response_data, dict)


# =============================================================================
# INTEGRATION TESTS FOR MIDDLEWARE
# =============================================================================

class TestMiddlewareIntegration:
    """Test middleware integration and interaction."""
    
    @pytest.fixture
    def full_middleware_app(self):
        """Create app with all middleware."""
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add all middleware in order
        app.add_middleware(SecurityMiddleware)
        app.add_middleware(LoggingMiddleware)
        app.add_middleware(RateLimitingMiddleware)
        app.add_middleware(ErrorHandlingMiddleware)
        
        # Add CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"]
        )
        
        @app.get("/test/full-stack")
        async def full_stack_endpoint():
            return {"message": "full stack response"}
        
        @app.get("/test/error-handling")
        async def error_endpoint():
            raise HTTPException(status_code=418, detail="I'm a teapot")
        
        return app
    
    def test_full_middleware_stack(self, full_middleware_app):
        """Test full middleware stack integration."""
        client = TestClient(full_middleware_app)
        
        # Test normal request through full stack
        response = client.get("/test/full-stack")
        
        assert response.status_code == 200
        
        # Verify security headers
        assert "X-Content-Type-Options" in response.headers
        
        # Verify logging and error handling are working
        # (specific behavior depends on configuration)
        
        # Test error handling through full stack
        response = client.get("/test/error-handling")
        assert response.status_code == 418
        
        # Verify error handling works with other middleware
        response_data = response.json()
        assert "error" in response_data
    
    def test_middleware_ordering(self):
        """Test middleware ordering effects."""
        # This test verifies that middleware order affects behavior
        
        from fastapi import FastAPI
        
        app = FastAPI()
        
        # Add middleware in specific order
        # 1. Security (outermost)
        # 2. Logging
        # 3. Rate Limiting
        # 4. Error Handling (innermost)
        app.add_middleware(SecurityMiddleware)
        app.add_middleware(LoggingMiddleware)
        app.add_middleware(RateLimitingMiddleware)
        
        # Note: ErrorHandlingMiddleware is typically added via exception handlers
        # rather than as a middleware component
        
        @app.get("/test/ordering")
        async def ordering_test():
            return {"message": "ordering test"}
        
        client = TestClient(app)
        response = client.get("/test/ordering")
        
        assert response.status_code == 200
        
        # Verify middleware effects are cumulative
        assert "X-Content-Type-Options" in response.headers


# =============================================================================
# PERFORMANCE AND STRESS TESTS
# =============================================================================

class TestMiddlewarePerformance:
    """Performance tests for middleware."""
    
    def test_logging_performance(self):
        """Test logging middleware performance."""
        # This would test logging overhead
        # Implementation depends on specific logging configuration
        
        # Mock a high-throughput scenario
        num_requests = 1000
        start_time = time.time()
        
        # Simulate logging many requests
        for i in range(num_requests):
            # Simulate logging operation
            pass
        
        end_time = time.time()
        duration = end_time - start_time
        
        # Performance assertions
        requests_per_second = num_requests / duration if duration > 0 else float('inf')
        assert requests_per_second > 1000  # Should handle 1000+ requests/second
    
    def test_rate_limiting_performance(self):
        """Test rate limiting performance under load."""
        # Test rate limiting overhead
        limiter = TokenBucketLimiter(capacity=1000, refill_rate=100.0)
        
        num_checks = 10000
        start_time = time.time()
        
        for i in range(num_checks):
            limiter.is_allowed("test_key")
        
        end_time = time.time()
        duration = end_time - start_time
        
        checks_per_second = num_checks / duration if duration > 0 else float('inf')
        assert checks_per_second > 10000  # Should handle 10k+ checks/second
    
    def test_security_overhead(self):
        """Test security middleware overhead."""
        # Test security header generation performance
        
        headers = SecurityHeaders()
        
        num_generations = 1000
        start_time = time.time()
        
        for i in range(num_generations):
            headers.generate_headers()
        
        end_time = time.time()
        duration = end_time - start_time
        
        generations_per_second = num_generations / duration if duration > 0 else float('inf')
        assert generations_per_second > 1000  # Should generate 1k+ header sets/second


# =============================================================================
# ERROR SCENARIOS AND EDGE CASES
# =============================================================================

class TestMiddlewareEdgeCases:
    """Test middleware edge cases and error scenarios."""
    
    def test_error_middleware_with_corrupted_request(self):
        """Test error handling with corrupted requests."""
        from fastapi import FastAPI
        
        app = FastAPI()
        app.add_middleware(ErrorHandlingMiddleware)
        
        @app.get("/test/corrupted")
        async def corrupted_endpoint():
            # Simulate various error conditions
            raise MemoryError("Out of memory")
        
        client = TestClient(app)
        
        # Test with memory error
        with pytest.raises((MemoryError, Exception)):  # May be caught by middleware
            response = client.get("/test/corrupted")
            
            # If middleware catches it, should return 500 error
            if hasattr(response, 'status_code'):
                assert response.status_code == 500
    
    def test_rate_limiting_with_whitelist(self):
        """Test rate limiting with whitelist functionality."""
        config = RateLimitConfig(
            requests_per_minute=60,
            whitelist_ips=["127.0.0.1", "::1"]
        )
        
        # Whitelisted IPs should bypass rate limiting
        # Implementation depends on specific middleware
        assert "127.0.0.1" in config.whitelist_ips
        assert "::1" in config.whitelist_ips
    
    def test_cors_with_complex_origins(self):
        """Test CORS with complex origin patterns."""
        from fastapi import FastAPI
        
        app = FastAPI()
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["https://*.example.com", "https://app.*.com"],
            allow_credentials=True
        )
        
        # Test with subdomain
        client = TestClient(app)
        
        response = client.get(
            "/test/cors",
            headers={"Origin": "https://subdomain.example.com"}
        )
        
        # Should allow subdomain based on wildcard pattern
        # Implementation depends on CORS library support
    
    def test_security_with_malformed_headers(self):
        """Test security middleware with malformed headers."""
        headers = SecurityHeaders()
        
        # Test with None values
        result = headers._safe_header(None, "value")
        assert result is not None
        
        # Test with empty headers
        empty_headers = {}
        result = headers._safe_headers(empty_headers)
        assert isinstance(result, dict)


# =============================================================================
# TEST DATA AND UTILITIES
# =============================================================================

@pytest.fixture
def sample_requests():
    """Provide sample HTTP requests for testing."""
    return [
        {
            "method": "GET",
            "path": "/api/test",
            "headers": {"Host": "test.com", "User-Agent": "test-client"},
            "client": {"host": "127.0.0.1", "port": 8000}
        },
        {
            "method": "POST",
            "path": "/api/data",
            "headers": {"Content-Type": "application/json"},
            "client": {"host": "192.168.1.1", "port": 12345}
        },
        {
            "method": "PUT",
            "path": "/api/resource/123",
            "headers": {"Authorization": "Bearer token"},
            "client": {"host": "10.0.0.1", "port": 54321}
        }
    ]


@pytest.fixture
def security_test_data():
    """Provide test data for security testing."""
    return {
        "malicious_inputs": [
            "<script>alert('xss')</script>",
            "'; DROP TABLE users; --",
            "../../../etc/passwd",
            "${7*7}",
            "{{config.__class__.__init__.__globals__['os'].popen('ls').read()}}"
        ],
        "safe_inputs": [
            "Normal text input",
            "Email: user@example.com",
            "URL: https://example.com",
            "JSON: {\"key\": \"value\"}",
            "HTML: <p>Paragraph text</p>"
        ],
        "security_headers": {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }
    }


@pytest.fixture
def rate_limit_test_scenarios():
    """Provide test scenarios for rate limiting."""
    return {
        "normal_usage": {"requests_per_minute": 60, "expected_allowed": True},
        "high_usage": {"requests_per_minute": 120, "expected_allowed": False},
        "burst_usage": {"burst_size": 10, "expected_allowed": True},
        "excessive_burst": {"burst_size": 50, "expected_allowed": False},
        "whitelisted_ip": {"ip": "127.0.0.1", "expected_allowed": True},
        "blacklisted_ip": {"ip": "10.0.0.1", "expected_allowed": False}
    }


# =============================================================================
# MARKERS CONFIGURATION
# =============================================================================

pytest.mark.unit = pytest.mark.unit
pytest.mark.integration = pytest.mark.integration
pytest.mark.slow = pytest.mark.slow
pytest.mark.performance = pytest.mark.performance
pytest.mark.security = pytest.mark.security


# =============================================================================
# TEST SUITE CONFIGURATION
# =============================================================================

def pytest_configure(config):
    """Configure pytest markers."""
    config.addinivalue_line("markers", "unit: Unit tests for middleware components")
    config.addinivalue_line("markers", "integration: Integration tests for middleware interactions")
    config.addinivalue_line("markers", "slow: Slow running middleware tests")
    config.addinivalue_line("markers", "performance: Performance tests for middleware")
    config.addinivalue_line("markers", "security: Security-focused middleware tests")


def pytest_collection_modifyitems(config, items):
    """Modify test collection to add markers based on test names."""
    for item in items:
        # Add performance marker to performance tests
        if "performance" in item.name.lower():
            item.add_marker(pytest.mark.performance)
        
        # Add security marker to security tests
        if any(keyword in item.name.lower() for keyword in ["security", "csrf", "xss", "csp"]):
            item.add_marker(pytest.mark.security)
        
        # Add slow marker to stress tests
        if any(keyword in item.name.lower() for keyword in ["stress", "load", "high_throughput"]):
            item.add_marker(pytest.mark.slow)