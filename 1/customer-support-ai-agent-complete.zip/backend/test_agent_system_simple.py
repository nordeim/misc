"""
Simplified test for the Customer Support Agent System.

This test focuses on the agent system components without requiring
the full application configuration.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add the backend directory to Python path
backend_path = Path(__file__).parent
sys.path.insert(0, str(backend_path))

async def test_basic_agent_components():
    """Test basic agent system components without full configuration."""
    print("Testing basic agent system components...")
    
    try:
        # Test agent classes
        from app.agents.chat_agent import (
            CustomerSupportAgent,
            AgentContext,
            AgentResponse,
            AgentConfiguration,
            AgentMetrics,
            AgentState,
            EscalationType,
            ToolExecutionStatus
        )
        print("✓ Core agent classes imported")
        
        # Test factory classes
        from app.agents.agent_factory import (
            AgentRegistry,
            AgentConfigurationManager,
            AgentPool,
            AgentFactory,
            AgentStateManager
        )
        print("✓ Factory classes imported")
        
        # Test utils classes
        from app.agents.agent_utils import (
            AgentMonitor,
            AgentPerformanceTracker,
            AgentResourceManager,
            AgentDiagnosticTool,
            AgentAlert,
            AlertSeverity
        )
        print("✓ Utility classes imported")
        
        # Test monitoring classes
        from app.agents.monitoring_integration import (
            AgentMetricsCollector,
            AgentHealthChecker,
            AgentAlertManager,
            AgentMonitoringIntegration
        )
        print("✓ Monitoring classes imported")
        
        return True
        
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False
    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


async def test_agent_configuration():
    """Test agent configuration system."""
    print("\nTesting agent configuration system...")
    
    try:
        from app.agents.chat_agent import AgentConfiguration
        
        # Create configuration instances
        config = AgentConfiguration()
        print(f"✓ Default configuration created with {len(config.__dict__)} settings")
        
        # Test custom configuration
        custom_config = AgentConfiguration(
            max_history_length=100,
            max_processing_time=30.0,
            enable_caching=True
        )
        print(f"✓ Custom configuration created")
        
        # Test configuration attributes
        assert custom_config.max_history_length == 100
        assert custom_config.max_processing_time == 30.0
        assert custom_config.enable_caching == True
        print("✓ Configuration attributes work correctly")
        
        return True
        
    except Exception as e:
        print(f"✗ Configuration test failed: {e}")
        return False


async def test_agent_context():
    """Test agent context management."""
    print("\nTesting agent context management...")
    
    try:
        from app.agents.chat_agent import AgentContext, AgentState
        
        # Create context
        context = AgentContext(
            session_id="test_session_123",
            user_id="test_user_456"
        )
        print("✓ Agent context created")
        
        # Test context attributes
        assert context.session_id == "test_session_123"
        assert context.user_id == "test_user_456"
        assert context.agent_state == AgentState.IDLE
        assert context.conversation_turn == 0
        print("✓ Context attributes work correctly")
        
        # Test context updates
        context.add_message({"content": "test message", "timestamp": "2023-01-01T00:00:00"})
        assert context.conversation_turn == 1
        print("✓ Context message addition works")
        
        return True
        
    except Exception as e:
        print(f"✗ Context test failed: {e}")
        return False


async def test_agent_metrics():
    """Test agent metrics system."""
    print("\nTesting agent metrics system...")
    
    try:
        from app.agents.chat_agent import AgentMetrics
        
        # Create metrics instance
        metrics = AgentMetrics()
        print("✓ Agent metrics created")
        
        # Test metrics updates
        metrics.update_response_metrics(1.5, success=True, escalated=False)
        assert metrics.total_messages_processed == 1
        assert metrics.successful_responses == 1
        print("✓ Metrics update works")
        
        # Test tool usage tracking
        metrics.update_tool_usage("rag_tool", success=True)
        assert metrics.total_tools_executed == 1
        assert "rag_tool" in metrics.tool_usage_stats
        print("✓ Tool usage tracking works")
        
        # Test success rate calculation
        success_rate = metrics.get_success_rate()
        assert success_rate == 100.0
        print("✓ Success rate calculation works")
        
        return True
        
    except Exception as e:
        print(f"✗ Metrics test failed: {e}")
        return False


async def test_agent_factory():
    """Test agent factory system."""
    print("\nTesting agent factory system...")
    
    try:
        from app.agents.agent_factory import (
            AgentRegistry,
            AgentConfigurationManager,
            AgentFactory
        )
        
        # Test registry
        registry = AgentRegistry()
        assert isinstance(registry._agents, dict)
        print("✓ Agent registry created")
        
        # Test configuration manager
        config_manager = AgentConfigurationManager()
        configurations = config_manager.get_all_configurations()
        print(f"✓ Configuration manager loaded {len(configurations)} configurations")
        
        # Test factory
        factory = AgentFactory()
        assert hasattr(factory, 'registry')
        assert hasattr(factory, 'config_manager')
        print("✓ Agent factory created")
        
        return True
        
    except Exception as e:
        print(f"✗ Factory test failed: {e}")
        return False


async def test_agent_tools():
    """Test agent tools functionality."""
    print("\nTesting agent tools functionality...")
    
    try:
        from app.agents.chat_agent import CustomerSupportAgent, AgentConfiguration
        
        # Create minimal agent configuration
        config = AgentConfiguration(
            max_processing_time=10.0,
            tool_timeout=5.0
        )
        
        # Create agent instance (without starting it)
        agent = CustomerSupportAgent(config=config)
        print(f"✓ Agent created with ID: {agent.agent_id}")
        
        # Test agent attributes
        assert agent.state == AgentState.IDLE
        assert hasattr(agent, 'rag_tool')
        assert hasattr(agent, 'memory_tool')
        assert hasattr(agent, 'attachment_tool')
        assert hasattr(agent, 'escalation_tool')
        print("✓ Agent tools registered")
        
        # Test configuration
        agent_config = agent.get_configuration()
        assert agent_config.max_processing_time == 10.0
        print("✓ Agent configuration accessible")
        
        # Test status
        status = agent.get_status()
        assert "agent_id" in status
        assert "state" in status
        print("✓ Agent status accessible")
        
        return True
        
    except Exception as e:
        print(f"✗ Agent tools test failed: {e}")
        return False


async def test_monitoring_components():
    """Test monitoring and utility components."""
    print("\nTesting monitoring components...")
    
    try:
        from app.agents.agent_utils import (
            AgentMonitor,
            AgentPerformanceTracker,
            AgentResourceManager,
            AlertSeverity
        )
        
        # Test monitor
        monitor = AgentMonitor()
        assert hasattr(monitor, '_thresholds')
        assert hasattr(monitor, '_alerts')
        print("✓ Agent monitor created")
        
        # Test performance tracker
        tracker = AgentPerformanceTracker()
        assert hasattr(tracker, '_performance_data')
        print("✓ Performance tracker created")
        
        # Test resource manager
        resource_mgr = AgentResourceManager()
        assert hasattr(resource_mgr, '_resource_limits')
        print("✓ Resource manager created")
        
        # Test alert severity
        assert hasattr(AlertSeverity, 'INFO')
        assert hasattr(AlertSeverity, 'WARNING')
        assert hasattr(AlertSeverity, 'ERROR')
        print("✓ Alert severity enum works")
        
        return True
        
    except Exception as e:
        print(f"✗ Monitoring test failed: {e}")
        return False


async def run_simplified_tests():
    """Run all simplified tests."""
    print("=" * 60)
    print("CUSTOMER SUPPORT AGENT SYSTEM - SIMPLIFIED TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Agent Components", test_basic_agent_components),
        ("Agent Configuration", test_agent_configuration),
        ("Agent Context", test_agent_context),
        ("Agent Metrics", test_agent_metrics),
        ("Agent Factory", test_agent_factory),
        ("Agent Tools", test_agent_tools),
        ("Monitoring Components", test_monitoring_components),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            if result:
                passed += 1
                print(f"✅ {test_name}: PASSED")
            else:
                failed += 1
                print(f"❌ {test_name}: FAILED")
        except Exception as e:
            failed += 1
            print(f"💥 {test_name}: EXCEPTION - {e}")
    
    print("\n" + "=" * 60)
    print("SIMPLIFIED TEST RESULTS SUMMARY")
    print("=" * 60)
    print(f"Total Tests: {passed + failed}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Success Rate: {(passed / (passed + failed)) * 100:.1f}%")
    
    if failed == 0:
        print("\n🎉 ALL SIMPLIFIED TESTS PASSED!")
        print("✅ Agent system core components are working correctly")
        print("✅ The agent system is ready for integration")
    else:
        print(f"\n⚠️  {failed} tests failed.")
        print("📝 Please review the issues above")
    
    return failed == 0


if __name__ == "__main__":
    # Run the simplified test suite
    success = asyncio.run(run_simplified_tests())
    sys.exit(0 if success else 1)