"""
Example integration of monitoring into the main FastAPI application.
This shows how to add monitoring to your existing Customer Support Agent backend.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import structlog
from monitoring.backend_monitoring import (
    create_monitoring_app,
    MetricsMiddleware,
    track_agent_operation,
    track_rag_query,
    update_active_conversations,
    record_conversation_escalation,
    record_conversation_resolution,
    record_user_feedback,
    active_conversations_total,
    conversations_escalated_total,
    conversations_resolved_total,
)

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Create the main FastAPI application
app = FastAPI(
    title="Customer Support Agent API",
    description="API for the Customer Support AI Agent",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add metrics middleware for automatic HTTP request monitoring
app.add_middleware(MetricsMiddleware)


# Example: Chat endpoint with monitoring
@app.post("/api/chat")
@track_agent_operation("chat_processing")
async def chat_endpoint(request: Request):
    """Handle chat messages with full monitoring."""
    logger.info("Processing chat message", endpoint="/api/chat")
    
    try:
        # Simulate processing
        import asyncio
        await asyncio.sleep(0.1)  # Simulate processing time
        
        # Update active conversations
        update_active_conversations(1)
        
        # Record conversation status
        conversations_resolved_total.inc()
        
        return {
            "status": "success",
            "message": "Chat processed successfully"
        }
    except Exception as e:
        logger.error("Chat processing failed", error=str(e), endpoint="/api/chat")
        raise


# Example: Escalation endpoint
@app.post("/api/escalate")
@track_agent_operation("escalation_processing")
async def escalate_endpoint(request: Request):
    """Handle conversation escalations."""
    logger.info("Processing escalation", endpoint="/api/escalate")
    
    try:
        # Record escalation
        record_conversation_escalation()
        
        return {
            "status": "escalated",
            "message": "Conversation escalated successfully"
        }
    except Exception as e:
        logger.error("Escalation failed", error=str(e), endpoint="/api/escalate")
        raise


# Example: RAG search endpoint
@app.post("/api/search")
@track_rag_query()
@track_agent_operation("rag_search")
async def search_endpoint(request: Request):
    """Handle knowledge base searches."""
    logger.info("Processing search request", endpoint="/api/search")
    
    try:
        # Simulate RAG search
        import asyncio
        await asyncio.sleep(0.05)  # Simulate search time
        
        return {
            "status": "success",
            "results": ["Search result 1", "Search result 2"]
        }
    except Exception as e:
        logger.error("Search failed", error=str(e), endpoint="/api/search")
        raise


# Example: User feedback endpoint
@app.post("/api/feedback")
async def feedback_endpoint(request: Request):
    """Handle user feedback."""
    try:
        # This would normally parse the request body
        feedback_score = 4  # Example score
        
        # Record feedback
        record_user_feedback(feedback_score)
        
        logger.info("Feedback recorded", score=feedback_score)
        
        return {
            "status": "success",
            "message": "Thank you for your feedback"
        }
    except Exception as e:
        logger.error("Feedback processing failed", error=str(e))
        raise


# Example: WebSocket endpoint with connection tracking
@app.websocket("/ws/chat")
async def websocket_endpoint(websocket):
    """WebSocket endpoint for real-time chat."""
    logger.info("WebSocket connection established")
    active_conversations_total.inc()
    
    try:
        await websocket.accept()
        # WebSocket logic here
        await websocket.send_text("Connected to chat")
        
        # Keep connection alive
        while True:
            data = await websocket.receive_text()
            await websocket.send_text(f"Echo: {data}")
            
    except Exception as e:
        logger.error("WebSocket error", error=str(e))
    finally:
        active_conversations_total.dec()
        logger.info("WebSocket connection closed")


# Health check endpoints (automatically provided by monitoring module)
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "Customer Support Agent",
        "version": "1.0.0"
    }


if __name__ == "__main__":
    import uvicorn
    
    # Run the application
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_config=None  # Use structlog instead
    )