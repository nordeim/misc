# Monitoring and Observability Infrastructure

This directory contains the complete monitoring and observability setup for the Customer Support AI Agent system.

## Overview

The monitoring stack consists of:

- **Prometheus**: Metrics collection and storage
- **Grafana**: Visualization and dashboards
- **AlertManager**: Alert routing and management
- **Node Exporter**: System metrics collection
- **Redis Exporter**: Redis monitoring
- **PostgreSQL Exporter**: Database monitoring

## Components

### 1. Prometheus Configuration (`prometheus.yml`)
- Configured to scrape metrics from all services every 15 seconds
- Includes backend application metrics, system metrics, and database metrics
- Set up with proper relabeling and service discovery

### 2. Grafana Dashboards

#### System Metrics Dashboard (`grafana-dashboards/system-metrics.json`)
- CPU, memory, and disk usage
- Network I/O and load averages
- Disk I/O performance

#### Application Metrics Dashboard (`grafana-dashboards/application-metrics.json`)
- Request rates and error rates
- Response time percentiles (P50, P95, P99)
- Database connection pools
- WebSocket connection status
- AI agent processing times
- RAG query performance

#### Business Metrics Dashboard (`grafana-dashboards/business-metrics.json`)
- Active conversations
- Escalation rates
- Customer satisfaction scores
- Resolution rates
- Knowledge base usage
- User feedback distribution

### 3. Alerting Rules (`alert-rules/`)

#### Application Alerts (`application-alerts.yml`)
- High error rate (5% threshold)
- High response time (P95 > 2s)
- Service availability issues
- Database connection pool exhaustion
- Redis memory usage
- AI agent performance issues
- Failed message rates

#### System Alerts (`system-alerts.yml`)
- High CPU usage (>85%)
- High memory usage (>85%)
- High disk usage (>80%)
- Load average warnings
- Disk I/O issues
- Network errors

#### Business Alerts (`business-alerts.yml`)
- High escalation rates (>20%)
- Low customer satisfaction (<3.5)
- No active conversations
- Low resolution rates (<70%)
- High RAG miss rates (>50%)
- Authentication failures
- WebSocket connection drops

### 4. Backend Monitoring Module (`backend_monitoring.py`)

Comprehensive FastAPI monitoring module providing:

#### Health Check Endpoints
- `/health` - Basic health check
- `/health/ready` - Readiness probe with dependency checks
- `/health/live` - Liveness probe

#### Metrics Endpoints
- `/metrics` - Prometheus metrics export
- `/metrics/app` - Application-specific metrics
- `/metrics/chromadb` - ChromaDB metrics
- `/metrics/system` - System metrics

#### Custom Metrics Tracked
- HTTP request metrics (counts, duration histograms)
- Conversation metrics (total, escalated, resolved)
- Message metrics (inbound/outbound, failed)
- AI agent processing times
- RAG query performance
- Customer satisfaction scores
- User feedback distribution
- Authentication attempts and failures
- WebSocket connection metrics

#### Structured Logging
- JSON-formatted logs with structured fields
- Contextual information for better debugging
- Integration with standard Python logging

#### Decorators for Metrics Collection
- `@track_agent_operation()` - Track AI agent operations
- `@track_rag_query()` - Track RAG query performance

## Setup Instructions

### 1. Install Dependencies

Add the monitoring dependencies to your backend requirements:

```bash
pip install -r monitoring/requirements.txt
```

### 2. Integrate Backend Monitoring

Add the monitoring module to your FastAPI application:

```python
from monitoring.backend_monitoring import create_monitoring_app, MetricsMiddleware
from monitoring.backend_monitoring import (
    track_agent_operation, 
    track_rag_query,
    update_active_conversations,
    record_conversation_escalation,
    record_user_feedback
)

app = FastAPI()
# Add metrics middleware
app.add_middleware(MetricsMiddleware)

# Use decorators in your agent operations
@track_agent_operation("process_message")
async def process_user_message():
    # Your logic here
    pass

# Update metrics in your services
@router.post("/chat")
async def chat_endpoint():
    update_active_conversations(1)
    # Process chat
    record_conversation_resolution()
```

### 3. Start the Monitoring Stack

```bash
# Start all monitoring services
docker-compose -f monitoring/docker-compose.monitoring.yml up -d

# Access the services:
# - Grafana: http://localhost:3000 (admin/admin)
# - Prometheus: http://localhost:9090
# - AlertManager: http://localhost:9093
```

### 4. Configure Alerts

Update the AlertManager configuration (`alertmanager.yml`) with your actual:
- SMTP settings for email notifications
- Slack webhook URLs
- Team email addresses
- PagerDuty or other notification services

### 5. Deploy with Your Application

For production deployment, update your `docker-compose.prod.yml`:

```yaml
services:
  backend:
    image: your-backend-image
    environment:
      - MONITORING_ENABLED=true
      - PROMETHEUS_ENDPOINT=http://prometheus:9090
    volumes:
      - ./monitoring/backend_monitoring.py:/app/monitoring.py
```

## Custom Metrics Examples

### Track Conversation Metrics
```python
from monitoring.backend_monitoring import (
    update_active_conversations,
    record_conversation_escalation,
    record_conversation_resolution,
    record_user_feedback
)

# Update conversation counts
update_active_conversations(current_active_count)

# Record escalations
record_conversation_escalation()

# Record resolutions
record_conversation_resolution()

# Record user feedback (1-5 stars)
record_user_feedback(4)
```

### Track AI Operations
```python
from monitoring.backend_monitoring import track_agent_operation, track_rag_query

@track_agent_operation("rag_search")
@track_rag_query()
async def search_knowledge_base():
    # RAG search logic
    pass

@track_agent_operation("generate_response")
async def generate_response():
    # Response generation logic
    pass
```

### Custom Business Metrics
```python
# Add custom counters and gauges for your specific business needs
from prometheus_client import Counter, Gauge

# Example: Track escalations by reason
escalations_by_reason = Counter(
    'escalations_by_reason_total',
    'Escalations by reason',
    ['reason']
)

escalations_by_reason.labels(reason="complex_question").inc()
```

## Alert Configuration

### Customizing Thresholds

All alert thresholds can be customized in the alert rule files:

```yaml
# Change error rate threshold
- alert: HighErrorRate
  expr: (rate(http_requests_total{service="fastapi-backend",status_code=~"5.."}[5m]) / rate(http_requests_total{service="fastapi-backend"}[5m])) * 100 > 10  # Changed from 5 to 10
```

### Adding New Alerts

1. Create new rules in the appropriate alert file
2. Define the Prometheus query
3. Set severity and team labels
4. Provide summary and description annotations

## Monitoring Best Practices

### 1. Use Labels Wisely
- Keep label cardinality low (avoid using user IDs, timestamps as labels)
- Use consistent naming conventions
- Include service, environment, and instance labels

### 2. Set Appropriate Alert Thresholds
- Use realistic thresholds based on your SLOs
- Consider noise vs. criticality
- Test alerts during normal operations

### 3. Monitor Both Leading and Lagging Indicators
- Leading: Response time, error rate
- Lagging: Customer satisfaction, escalation rate

### 4. Regular Dashboard Reviews
- Review dashboards weekly
- Update metrics as business needs change
- Archive unused dashboards

### 5. Alert Fatigue Prevention
- Group related alerts
- Use appropriate repeat intervals
- Have clear escalation paths

## Troubleshooting

### Prometheus Not Scraping Metrics
- Check target status at http://prometheus:9090/targets
- Verify network connectivity between containers
- Check metric endpoints are accessible

### Grafana Dashboards Showing No Data
- Verify Prometheus datasource configuration
- Check query syntax in Grafana
- Ensure metrics are being scraped

### Missing Custom Metrics
- Verify metrics are registered in the application
- Check Prometheus scraping configuration
- Use `curl http://backend:8000/metrics` to inspect metrics

## Security Considerations

1. **Secure AlertManager**: Use authentication for AlertManager UI
2. **Limit Grafana Access**: Configure proper user management
3. **Network Isolation**: Use Docker networks to isolate monitoring traffic
4. **Credential Management**: Store sensitive configs (email passwords, API keys) in secrets
5. **Metrics Security**: Consider authentication for metrics endpoints in production

## Performance Considerations

1. **Scraping Intervals**: Balance freshness vs. overhead
2. **Retention Policies**: Configure appropriate data retention
3. **Resource Limits**: Set memory and CPU limits for monitoring services
4. **Storage**: Monitor disk usage for metrics storage

This monitoring infrastructure provides comprehensive observability for both system health and business metrics, enabling proactive issue detection and data-driven decision making.