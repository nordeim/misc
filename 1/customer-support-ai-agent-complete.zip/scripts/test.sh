#!/bin/bash

# Customer Support AI Agent - Comprehensive Test Suite
# This script runs all tests including unit, integration, and system tests

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}=== $1 ===${NC}\n"
}

# Test counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
SKIPPED_TESTS=0

# Test result tracking
declare -A TEST_RESULTS

# Function to run a test
run_test() {
    local test_name="$1"
    local test_command="$2"
    local required="$3"
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    
    echo "Testing: $test_name"
    
    if eval "$test_command" > /dev/null 2>&1; then
        print_status "$test_name"
        PASSED_TESTS=$((PASSED_TESTS + 1))
        TEST_RESULTS["$test_name"]="PASS"
        return 0
    else
        if [ "$required" = "true" ]; then
            print_error "$test_name"
            FAILED_TESTS=$((FAILED_TESTS + 1))
            TEST_RESULTS["$test_name"]="FAIL"
        else
            print_warning "$test_name (optional)"
            SKIPPED_TESTS=$((SKIPPED_TESTS + 1))
            TEST_RESULTS["$test_name"]="SKIP"
        fi
        return 1
    fi
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Test Prerequisites"
    
    # Check if services are running
    if ! docker-compose ps | grep -q "Up"; then
        print_warning "No Docker services are running"
        read -p "Start services automatically? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_status "Starting services..."
            docker-compose up -d
            sleep 30
        else
            print_error "Services must be running for tests"
            exit 1
        fi
    fi
    
    # Check backend service
    if curl -s http://localhost:8000/health > /dev/null; then
        print_status "Backend service is running"
    else
        print_error "Backend service is not responding"
        exit 1
    fi
    
    # Check database connection
    if docker-compose exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
        print_status "Database is ready"
    else
        print_error "Database is not ready"
        exit 1
    fi
    
    print_status "Prerequisites check completed"
}

# Backend tests
test_backend() {
    print_header "Backend Tests"
    
    # Test API health
    run_test "API Health Check" \
        "curl -s http://localhost:8000/health | grep -q 'healthy'" \
        "true"
    
    # Test API documentation
    run_test "API Documentation Available" \
        "curl -s http://localhost:8000/docs > /dev/null" \
        "true"
    
    # Test session creation
    run_test "Session Creation" \
        'session_id=$(curl -s -X POST http://localhost:8000/api/v1/sessions | jq -r ".session_id") && [ "$session_id" != "null" ]' \
        "true"
    
    # Test message sending
    run_test "Send Chat Message" \
        'curl -s -X POST http://localhost:8000/api/v1/chat/sessions/test/messages -H "Content-Type: application/json" -d "{\"message\":\"Hello\",\"session_id\":\"test\"}" | grep -q "message_id"' \
        "false"
    
    # Test health endpoints
    run_test "Detailed Health Check" \
        "curl -s http://localhost:8000/health/detailed > /dev/null" \
        "false"
    
    # Test database connection
    run_test "Database Connection" \
        'curl -s http://localhost:8000/health | jq -r ".services.database" | grep -q "healthy"' \
        "true"
    
    # Test Redis connection (if running)
    if docker-compose ps redis | grep -q "Up"; then
        run_test "Redis Connection" \
            'curl -s http://localhost:8000/health | jq -r ".services.redis" | grep -q "healthy"' \
            "false"
    fi
    
    # Test ChromaDB connection
    run_test "ChromaDB Connection" \
        'curl -s http://localhost:8000/health | jq -r ".services.chromadb" | grep -q "healthy"' \
        "true"
}

# Backend unit tests
test_backend_unit() {
    print_header "Backend Unit Tests"
    
    if [ -d "backend" ] && [ -f "backend/requirements.txt" ]; then
        cd backend
        
        # Activate virtual environment
        if [ -d "venv" ]; then
            source venv/bin/activate
        fi
        
        # Install test dependencies
        if [ -f "requirements-dev.txt" ]; then
            pip install -q -r requirements-dev.txt 2>/dev/null || true
        fi
        
        # Run pytest
        if command -v pytest &> /dev/null; then
            run_test "Backend Unit Tests" \
                "pytest -v --tb=short --maxfail=5" \
                "false"
        else
            print_warning "pytest not installed, skipping unit tests"
        fi
        
        # Run specific test files if they exist
        if [ -d "tests" ]; then
            if [ -f "tests/test_agents.py" ]; then
                run_test "Agent Tests" \
                    "pytest tests/test_agents.py -v" \
                    "false"
            fi
            
            if [ -f "tests/test_api.py" ]; then
                run_test "API Tests" \
                    "pytest tests/test_api.py -v" \
                    "false"
            fi
            
            if [ -f "tests/test_models.py" ]; then
                run_test "Model Tests" \
                    "pytest tests/test_models.py -v" \
                    "false"
            fi
        fi
        
        cd ..
    else
        print_warning "Backend directory not found, skipping unit tests"
    fi
}

# Frontend tests
test_frontend() {
    print_header "Frontend Tests"
    
    if [ -d "frontend" ] && [ -f "frontend/package.json" ]; then
        cd frontend
        
        # Install dependencies
        if [ ! -d "node_modules" ]; then
            npm install
        fi
        
        # Run TypeScript check
        if [ -f "tsconfig.json" ]; then
            run_test "TypeScript Compilation" \
                "npm run build --if-present" \
                "false"
        fi
        
        # Run linting
        if npm run lint --if-present &> /dev/null; then
            run_test "Frontend Linting" \
                "npm run lint" \
                "false"
        fi
        
        # Run tests if configured
        if [ -f "jest.config.js" ] || grep -q '"test"' package.json; then
            run_test "Frontend Unit Tests" \
                "npm test -- --watchAll=false --passWithNoTests" \
                "false"
        fi
        
        # Test build
        if [ -f "vite.config.ts" ]; then
            run_test "Frontend Build" \
                "npm run build" \
                "true"
        fi
        
        cd ..
    else
        print_warning "Frontend directory not found, skipping frontend tests"
    fi
}

# Integration tests
test_integration() {
    print_header "Integration Tests"
    
    # Test WebSocket connection
    run_test "WebSocket Connection" \
        'curl -s -N -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Version: 13" http://localhost:8000/ws/test | head -1' \
        "false"
    
    # Test file upload endpoint
    run_test "File Upload Endpoint" \
        'curl -s -X POST http://localhost:8000/api/v1/files -F "file=@/dev/null" | grep -q "file_id"' \
        "false"
    
    # Test search endpoint
    run_test "Search Endpoint" \
        'curl -s -X POST http://localhost:8000/api/v1/search -H "Content-Type: application/json" -d "{\"query\":\"test\",\"limit\":1}" | grep -q "results"' \
        "false"
    
    # Test session management
    run_test "Session Management" \
        'session_id=$(curl -s -X POST http://localhost:8000/api/v1/sessions | jq -r ".session_id") && curl -s http://localhost:8000/api/v1/sessions/$session_id | grep -q "session_id"' \
        "false"
    
    # Test error handling
    run_test "Error Handling" \
        'curl -s -X POST http://localhost:8000/api/v1/chat/sessions/invalid/messages -H "Content-Type: application/json" -d "{}" | grep -q "error"' \
        "true"
}

# Database tests
test_database() {
    print_header "Database Tests"
    
    # Test database connectivity
    run_test "Database Connectivity" \
        "docker-compose exec -T postgres psql -U postgres -d customer_support -c 'SELECT 1;'" \
        "true"
    
    # Test table existence
    run_test "Session Table Exists" \
        "docker-compose exec -T postgres psql -U postgres -d customer_support -c \"\\\\dt sessions\" | grep -q sessions" \
        "true"
    
    run_test "Messages Table Exists" \
        "docker-compose exec -T postgres psql -U postgres -d customer_support -c \"\\\\dt messages\" | grep -q messages" \
        "true"
    
    # Test database migrations
    run_test "Migration Status" \
        "docker-compose exec -T backend alembic current" \
        "true"
    
    # Test database performance
    run_test "Database Performance" \
        'docker-compose exec -T postgres psql -U postgres -d customer_support -c "SELECT COUNT(*) FROM pg_stat_activity;"' \
        "false"
}

# Redis tests
test_redis() {
    print_header "Redis Tests"
    
    if docker-compose ps redis | grep -q "Up"; then
        # Test Redis connectivity
        run_test "Redis Connectivity" \
            "docker-compose exec -T redis redis-cli ping | grep -q PONG" \
            "true"
        
        # Test Redis operations
        run_test "Redis Operations" \
            'docker-compose exec -T redis redis-cli set test_key test_value && docker-compose exec -T redis redis-cli get test_key | grep -q test_value' \
            "true"
        
        # Test Redis performance
        run_test "Redis Performance" \
            'docker-compose exec -T redis redis-cli --latency-history -i 1 | head -5' \
            "false"
    else
        print_warning "Redis is not running, skipping Redis tests"
    fi
}

# ChromaDB tests
test_chromadb() {
    print_header "ChromaDB Tests"
    
    # Test ChromaDB client connection
    run_test "ChromaDB Client Connection" \
        'docker-compose exec -T backend python -c "import chromadb; client = chromadb.Client(); collections = client.list_collections(); print(f\'Collections: {len(collections)}\')" | grep -q "Collections:"' \
        "true"
    
    # Test vector operations
    run_test "Vector Operations" \
        'docker-compose exec -T backend python -c "
import chromadb
client = chromadb.Client()
collection = client.get_or_create_collection(\"test_collection\")
collection.add(documents=[\"test document\"], ids=[\"test_id\"])
results = collection.query(query_texts=[\"test\"], n_results=1)
print(f\'Found {len(results[\"documents\"][0])} results\')
" | grep -q "Found 1 results"' \
        "false"
    
    # Test ChromaDB health
    run_test "ChromaDB Health" \
        'docker-compose exec -T backend python -c "
from app.services.embedding_service import EmbeddingService
import asyncio

async def test():
    service = EmbeddingService()
    healthy = await service.health_check()
    print(f\'Healthy: {healthy}\')

asyncio.run(test())
" | grep -q "Healthy: True"' \
        "true"
}

# Security tests
test_security() {
    print_header "Security Tests"
    
    # Test HTTPS redirect (if configured)
    if [ -n "${HTTPS_ENABLED:-}" ]; then
        run_test "HTTPS Redirect" \
            'curl -s -I http://localhost:8000/health | grep -q "301\|302"' \
            "false"
    fi
    
    # Test rate limiting
    run_test "Rate Limiting" \
        'for i in {1..10}; do curl -s http://localhost:8000/health > /dev/null; done; curl -s http://localhost:8000/health | grep -q "429"' \
        "false"
    
    # Test CORS headers
    run_test "CORS Headers" \
        'curl -s -I -H "Origin: http://localhost:3000" http://localhost:8000/health | grep -i "access-control"' \
        "false"
    
    # Test security headers
    run_test "Security Headers" \
        'curl -s -I http://localhost:8000/health | grep -i "x-frame-options\|x-content-type-options"' \
        "false"
    
    # Test SQL injection protection
    run_test "SQL Injection Protection" \
        'curl -s -X POST http://localhost:8000/api/v1/sessions -H "Content-Type: application/json" -d "{\"session_id\": \"\\\"; DROP TABLE sessions; --\"}" | grep -q "error\|validation"' \
        "false"
}

# Performance tests
test_performance() {
    print_header "Performance Tests"
    
    # Test API response time
    run_test "API Response Time (<1s)" \
        'response_time=$(curl -w "%{time_total}" -o /dev/null -s http://localhost:8000/health) && python3 -c "exit(0 if float('$response_time') < 1.0 else 1)"' \
        "true"
    
    # Test concurrent requests
    run_test "Concurrent Requests (10 requests)" \
        'for i in {1..10}; do curl -s http://localhost:8000/health > /dev/null & done; wait' \
        "true"
    
    # Test database query performance
    run_test "Database Query Performance" \
        'docker-compose exec -T postgres psql -U postgres -d customer_support -c "EXPLAIN ANALYZE SELECT * FROM sessions LIMIT 1;" | grep -q "Execution Time"' \
        "false"
    
    # Test memory usage
    run_test "Memory Usage (Backend < 2GB)" \
        'memory_mb=$(docker stats --no-stream --format "{{.MemUsage}}" $(docker-compose ps -q backend) | cut -d"/" -f1 | sed "s/MiB//") && python3 -c "exit(0 if float('$memory_mb') < 2048 else 1)"' \
        "false"
    
    # Test CPU usage
    run_test "CPU Usage (Backend < 80%)" \
        'cpu_percent=$(docker stats --no-stream --format "{{.CPUPerc}}" $(docker-compose ps -q backend) | sed "s/%//") && python3 -c "exit(0 if float('$cpu_percent') < 80 else 1)"' \
        "false"
}

# Monitoring tests
test_monitoring() {
    print_header "Monitoring Tests"
    
    # Test Prometheus metrics
    run_test "Prometheus Metrics" \
        "curl -s http://localhost:9090/metrics > /dev/null" \
        "false"
    
    # Test custom application metrics
    run_test "Application Metrics" \
        'curl -s http://localhost:8000/metrics | grep -q "http_requests_total"' \
        "false"
    
    # Test Grafana (if accessible)
    if curl -s http://localhost:3001 > /dev/null; then
        run_test "Grafana Accessibility" \
            "curl -s http://localhost:3001 > /dev/null" \
            "false"
    fi
    
    # Test log aggregation
    run_test "Log Aggregation" \
        'docker-compose logs --tail=1 backend | grep -q "."' \
        "false"
}

# Load tests
test_load() {
    print_header "Load Tests"
    
    # Basic load test with curl
    run_test "Basic Load Test (50 requests)" \
        'for i in {1..50}; do curl -s http://localhost:8000/health > /dev/null; done' \
        "false"
    
    # Test with concurrent sessions
    run_test "Concurrent Session Load Test" \
        'for i in {1..5}; do curl -s -X POST http://localhost:8000/api/v1/sessions > /dev/null & done; wait' \
        "false"
    
    # Monitor resource usage during load
    run_test "Resource Usage Under Load" \
        'docker stats --no-stream | grep -q "customer-support"' \
        "false"
}

# Generate test report
generate_report() {
    print_header "Test Report"
    
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    echo "Test Execution Report"
    echo "===================="
    echo "Timestamp: $timestamp"
    echo "Total Tests: $TOTAL_TESTS"
    echo "Passed: $PASSED_TESTS"
    echo "Failed: $FAILED_TESTS"
    echo "Skipped: $SKIPPED_TESTS"
    echo ""
    
    echo "Success Rate: $(( PASSED_TESTS * 100 / TOTAL_TESTS ))%"
    echo ""
    
    if [ $FAILED_TESTS -eq 0 ]; then
        echo "🎉 All tests passed!"
    else
        echo "⚠️ Some tests failed:"
        for test_name in "${!TEST_RESULTS[@]}"; do
            if [ "${TEST_RESULTS[$test_name]}" = "FAIL" ]; then
                echo "  ❌ $test_name"
            fi
        done
    fi
    
    echo ""
    echo "Test Details:"
    for test_name in "${!TEST_RESULTS[@]}"; do
        result="${TEST_RESULTS[$test_name]}"
        case "$result" in
            "PASS") echo "  ✅ $test_name" ;;
            "FAIL") echo "  ❌ $test_name" ;;
            "SKIP") echo "  ⏭️  $test_name" ;;
        esac
    done
    
    # Save report to file
    report_file="test_report_$(date +%Y%m%d_%H%M%S).txt"
    {
        echo "Customer Support AI Agent - Test Report"
        echo "======================================"
        echo "Date: $timestamp"
        echo "Total Tests: $TOTAL_TESTS"
        echo "Passed: $PASSED_TESTS"
        echo "Failed: $FAILED_TESTS"
        echo "Skipped: $SKIPPED_TESTS"
        echo "Success Rate: $(( PASSED_TESTS * 100 / TOTAL_TESTS ))%"
        echo ""
        echo "Test Results:"
        for test_name in "${!TEST_RESULTS[@]}"; do
            result="${TEST_RESULTS[$test_name]}"
            echo "  $result: $test_name"
        done
    } > "$report_file"
    
    echo ""
    echo "Report saved to: $report_file"
}

# Show test summary
show_summary() {
    print_header "Test Summary"
    
    echo "Results:"
    echo "  Total Tests: $TOTAL_TESTS"
    echo "  Passed: $PASSED_TESTS"
    echo "  Failed: $FAILED_TESTS"
    echo "  Skipped: $SKIPPED_TESTS"
    echo ""
    
    if [ $FAILED_TESTS -eq 0 ]; then
        exit 0
    else
        exit 1
    fi
}

# Main test runner
run_tests() {
    print_header "Customer Support AI Agent - Test Suite"
    
    # Parse command line arguments
    case "${1:-all}" in
        "backend")
            check_prerequisites
            test_backend
            test_backend_unit
            ;;
        "frontend")
            test_frontend
            ;;
        "integration")
            check_prerequisites
            test_integration
            ;;
        "database")
            check_prerequisites
            test_database
            ;;
        "security")
            check_prerequisites
            test_security
            ;;
        "performance")
            check_prerequisites
            test_performance
            ;;
        "monitoring")
            test_monitoring
            ;;
        "load")
            check_prerequisites
            test_load
            ;;
        "quick")
            check_prerequisites
            test_backend
            test_database
            ;;
        "all"|*)
            check_prerequisites
            test_backend
            test_backend_unit
            test_frontend
            test_integration
            test_database
            test_redis
            test_chromadb
            test_security
            test_performance
            test_monitoring
            test_load
            ;;
    esac
    
    generate_report
    show_summary
}

# Show help
show_help() {
    cat << EOF
Customer Support AI Agent - Test Suite

Usage: $0 [TEST_SUITE]

Test Suites:
    all          Run all tests (default)
    quick        Run quick validation tests
    backend      Backend-specific tests
    frontend     Frontend-specific tests
    integration  Integration tests
    database     Database tests
    security     Security tests
    performance  Performance tests
    monitoring   Monitoring tests
    load         Load tests

Examples:
    $0              # Run all tests
    $0 quick        # Run quick validation
    $0 backend      # Backend tests only
    $0 security     # Security tests only

Test Categories:
- Backend: API health, database, Redis, ChromaDB
- Frontend: Build, lint, type check
- Integration: WebSocket, file upload, search
- Security: CORS, rate limiting, SQL injection
- Performance: Response time, concurrent requests
- Monitoring: Metrics, logging, dashboards

Note: Some tests require services to be running.
EOF
}

# Handle command line arguments
case "${1:-all}" in
    "help"|"-h"|"--help")
        show_help
        ;;
    *)
        run_tests "$@"
        ;;
esac
