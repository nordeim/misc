#!/bin/bash

# Customer Support AI Agent - Production Deployment Script
# This script automates production deployment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}=== $1 ===${NC}\n"
}

# Configuration
COMPOSE_FILE="docker-compose.prod.yml"
ENV_FILE=".env.production"
BACKUP_DIR="./backups"
DEPLOYMENT_LOG="./logs/deployment.log"

# Create necessary directories
mkdir -p logs backups scripts/backups

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$DEPLOYMENT_LOG"
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"
    
    # Check if running as root (required for some production setups)
    if [ "$EUID" -eq 0 ]; then
        print_warning "Running as root. Consider using a dedicated user."
    fi
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed"
        exit 1
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        print_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Check environment file
    if [ ! -f "$ENV_FILE" ]; then
        print_error "Production environment file not found: $ENV_FILE"
        print_error "Please create it from .env.example"
        exit 1
    fi
    
    print_status "Prerequisites check passed"
}

# Validate environment configuration
validate_environment() {
    print_header "Validating Environment Configuration"
    
    # Source environment variables
    set -a
    source "$ENV_FILE"
    set +a
    
    # Check critical variables
    required_vars=(
        "DATABASE_URL"
        "SECRET_KEY"
        "JWT_SECRET_KEY"
        "OPENAI_API_KEY"
    )
    
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            print_error "Required environment variable not set: $var"
            exit 1
        fi
    done
    
    # Validate SECRET_KEY length
    if [ ${#SECRET_KEY} -lt 32 ]; then
        print_error "SECRET_KEY must be at least 32 characters long"
        exit 1
    fi
    
    # Validate JWT_SECRET_KEY length
    if [ ${#JWT_SECRET_KEY} -lt 32 ]; then
        print_error "JWT_SECRET_KEY must be at least 32 characters long"
        exit 1
    fi
    
    print_status "Environment configuration is valid"
}

# Create deployment backup
create_backup() {
    print_header "Creating Deployment Backup"
    
    timestamp=$(date +%Y%m%d_%H%M%S)
    backup_name="pre_deploy_$timestamp"
    backup_path="$BACKUP_DIR/$backup_name"
    
    mkdir -p "$backup_path"
    
    log "Creating backup: $backup_name"
    
    # Backup database
    if docker-compose -f "$COMPOSE_FILE" ps postgres | grep -q "Up"; then
        print_status "Backing up database..."
        docker-compose -f "$COMPOSE_FILE" exec -T postgres pg_dump -U postgres customer_support > "$backup_path/database.sql"
        log "Database backed up to $backup_path/database.sql"
    fi
    
    # Backup Redis
    if docker-compose -f "$COMPOSE_FILE" ps redis | grep -q "Up"; then
        print_status "Backing up Redis..."
        docker cp "$(docker-compose -f "$COMPOSE_FILE" ps -q redis):/data/dump.rdb" "$backup_path/redis.rdb"
        log "Redis data backed up to $backup_path/redis.rdb"
    fi
    
    # Backup ChromaDB
    if [ -d "data/chromadb" ]; then
        print_status "Backing up ChromaDB..."
        tar -czf "$backup_path/chromadb.tar.gz" -C data chromadb
        log "ChromaDB backed up to $backup_path/chromadb.tar.gz"
    fi
    
    # Backup configuration
    cp "$ENV_FILE" "$backup_path/"
    cp "$COMPOSE_FILE" "$backup_path/" 2>/dev/null || true
    
    log "Backup created successfully: $backup_path"
    print_status "Backup created: $backup_path"
}

# Pull latest code
pull_latest_code() {
    print_header "Pulling Latest Code"
    
    if [ -d ".git" ]; then
        if git diff-index --quiet HEAD --; then
            print_status "No uncommitted changes"
        else
            print_warning "You have uncommitted changes"
            read -p "Continue anyway? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                print_error "Deployment cancelled"
                exit 1
            fi
        fi
        
        print_status "Pulling latest changes..."
        git pull origin main
        log "Pulled latest code"
    else
        print_warning "Not a git repository, skipping code pull"
    fi
}

# Build production images
build_images() {
    print_header "Building Production Images"
    
    print_status "Building backend image..."
    docker-compose -f "$COMPOSE_FILE" build --no-cache backend
    log "Backend image built"
    
    print_status "Building frontend image..."
    docker-compose -f "$COMPOSE_FILE" build --no-cache frontend
    log "Frontend image built"
    
    print_status "Production images built successfully"
}

# Run database migrations
run_migrations() {
    print_header "Running Database Migrations"
    
    print_status "Waiting for database to be ready..."
    timeout=60
    while [ $timeout -gt 0 ]; do
        if docker-compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U postgres > /dev/null 2>&1; then
            print_status "Database is ready!"
            break
        fi
        echo -n "."
        sleep 2
        timeout=$((timeout - 2))
    done
    
    if [ $timeout -le 0 ]; then
        print_error "Database failed to become ready"
        exit 1
    fi
    
    print_status "Running Alembic migrations..."
    docker-compose -f "$COMPOSE_FILE" exec -T backend alembic upgrade head
    log "Database migrations completed"
    
    print_status "Database migrations completed successfully"
}

# Deploy services
deploy_services() {
    print_header "Deploying Services"
    
    print_status "Creating/updating Docker network..."
    docker network create --driver overlay customer-support-net 2>/dev/null || true
    
    print_status "Deploying services with Docker Stack..."
    docker stack deploy -c "$COMPOSE_FILE" customer-support
    
    log "Services deployed"
    print_status "Services deployed successfully"
}

# Wait for services to be healthy
wait_for_services() {
    print_header "Waiting for Services"
    
    print_status "Waiting for backend to be healthy..."
    timeout=120
    while [ $timeout -gt 0 ]; do
        if curl -s http://localhost:8000/health > /dev/null 2>&1; then
            print_status "Backend is healthy!"
            break
        fi
        echo -n "."
        sleep 5
        timeout=$((timeout - 5))
    done
    
    if [ $timeout -le 0 ]; then
        print_error "Backend failed to become healthy"
        print_error "Check logs with: docker service logs customer-support_backend"
        exit 1
    fi
    
    print_status "All services are healthy!"
}

# Run post-deployment tests
run_tests() {
    print_header "Running Post-Deployment Tests"
    
    print_status "Testing API health..."
    response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health)
    if [ "$response" = "200" ]; then
        print_status "✅ API health check passed"
    else
        print_error "❌ API health check failed (HTTP $response)"
        return 1
    fi
    
    print_status "Testing database connection..."
    docker-compose -f "$COMPOSE_FILE" exec -T backend python -c "
from app.database import SessionLocal
from sqlalchemy import text
try:
    with SessionLocal() as db:
        result = db.execute(text('SELECT 1'))
        print('✅ Database connection test passed')
except Exception as e:
    print(f'❌ Database connection test failed: {e}')
    exit(1)
"
    
    print_status "Testing Redis connection..."
    if docker-compose -f "$COMPOSE_FILE" ps redis | grep -q "Up"; then
        docker-compose -f "$COMPOSE_FILE" exec -T redis redis-cli ping > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_status "✅ Redis connection test passed"
        else
            print_warning "⚠️ Redis connection test failed"
        fi
    fi
    
    log "Post-deployment tests completed"
    print_status "Post-deployment tests completed"
}

# Generate deployment report
generate_report() {
    print_header "Deployment Report"
    
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    cat > "$BACKUP_DIR/deployment_report_$(date +%Y%m%d_%H%M%S).txt" << EOF
Deployment Report
=================
Date: $timestamp
Environment: Production
User: $(whoami)
Host: $(hostname)

Deployment Summary:
- Code version: $(git rev-parse HEAD 2>/dev/null || echo "Unknown")
- Deployment method: Docker Stack
- Services deployed: Backend, Frontend, Database, Redis, ChromaDB

Service Status:
$(docker service ls | grep customer-support || echo "No services found")

Resource Usage:
$(docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}" || echo "Stats not available")

Database Migrations:
$(docker service logs customer-support_backend | grep -E "(INFO|ERROR).*alembic" | tail -10 || echo "Migration logs not available")

Health Check Results:
- API Health: $(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health)
- Database: $(docker-compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U postgres > /dev/null 2>&1 && echo "OK" || echo "FAILED")
- Redis: $(docker-compose -f "$COMPOSE_FILE" exec -T redis redis-cli ping > /dev/null 2>&1 && echo "OK" || echo "FAILED")

Backup Location: $BACKUP_DIR
Deployment Log: $DEPLOYMENT_LOG

Next Steps:
1. Monitor application logs: docker service logs -f customer-support_backend
2. Check Grafana dashboards: http://localhost:3001
3. Verify all endpoints are working
4. Set up monitoring alerts if not already done

Deployment completed at: $(date '+%Y-%m-%d %H:%M:%S')
EOF
    
    print_status "Deployment report generated"
}

# Rollback function
rollback() {
    local backup_name="$1"
    
    print_header "Rolling Back Deployment"
    print_warning "This will restore the previous state!"
    
    read -p "Are you sure? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_error "Rollback cancelled"
        exit 1
    fi
    
    local backup_path="$BACKUP_DIR/$backup_name"
    
    if [ ! -d "$backup_path" ]; then
        print_error "Backup not found: $backup_path"
        exit 1
    fi
    
    log "Starting rollback from backup: $backup_name"
    
    # Stop current services
    print_status "Stopping current services..."
    docker stack rm customer-support
    
    # Restore database
    if [ -f "$backup_path/database.sql" ]; then
        print_status "Restoring database..."
        docker-compose -f "$COMPOSE_FILE" up -d postgres
        sleep 30
        docker-compose -f "$COMPOSE_FILE" exec -T postgres psql -U postgres customer_support < "$backup_path/database.sql"
    fi
    
    # Restore Redis
    if [ -f "$backup_path/redis.rdb" ]; then
        print_status "Restoring Redis data..."
        docker-compose -f "$COMPOSE_FILE" up -d redis
        sleep 10
        docker cp "$backup_path/redis.rdb" "$(docker-compose -f "$COMPOSE_FILE" ps -q redis):/data/dump.rdb"
        docker-compose -f "$COMPOSE_FILE" restart redis
    fi
    
    # Restore ChromaDB
    if [ -f "$backup_path/chromadb.tar.gz" ]; then
        print_status "Restoring ChromaDB..."
        docker-compose -f "$COMPOSE_FILE" down
        rm -rf data/chromadb
        tar -xzf "$backup_path/chromadb.tar.gz" -C data/
    fi
    
    # Redeploy services
    docker stack deploy -c "$COMPOSE_FILE" customer-support
    
    log "Rollback completed"
    print_status "Rollback completed successfully"
}

# Show deployment status
show_status() {
    print_header "Deployment Status"
    
    echo "Services:"
    docker stack services customer-support || echo "No services deployed"
    
    echo -e "\nResource Usage:"
    docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}" 2>/dev/null || echo "Stats not available"
    
    echo -e "\nHealth Check:"
    curl -s http://localhost:8000/health | jq '.' 2>/dev/null || curl -s http://localhost:8000/health
    
    echo -e "\nRecent Logs:"
    docker service logs --tail=20 customer-support_backend || echo "Logs not available"
}

# Main deployment function
deploy() {
    log "Starting production deployment"
    
    check_prerequisites
    validate_environment
    create_backup
    pull_latest_code
    build_images
    run_migrations
    deploy_services
    wait_for_services
    run_tests
    generate_report
    
    print_header "🎉 Deployment Completed Successfully!"
    
    echo ""
    echo "Deployment Summary:"
    echo "✅ Code updated and built"
    echo "✅ Database migrations applied"
    echo "✅ Services deployed"
    echo "✅ Health checks passed"
    echo "✅ Post-deployment tests completed"
    echo ""
    echo "Services:"
    echo "  Frontend: https://yourdomain.com"
    echo "  Backend API: https://api.yourdomain.com"
    echo "  API Documentation: https://api.yourdomain.com/docs"
    echo ""
    echo "Monitoring:"
    echo "  Grafana: http://localhost:3001 (admin/admin)"
    echo "  Prometheus: http://localhost:9090"
    echo ""
    echo "Deployment log: $DEPLOYMENT_LOG"
    echo "Backup location: $BACKUP_DIR"
    echo ""
    
    log "Production deployment completed successfully"
}

# Help function
show_help() {
    cat << EOF
Customer Support AI Agent - Production Deployment

Usage: $0 [COMMAND]

Commands:
    deploy         Full production deployment
    status         Show deployment status
    rollback       Rollback to previous deployment
    test           Run post-deployment tests
    help           Show this help message

Examples:
    $0 deploy                    # Run full deployment
    $0 status                    # Show current status
    $0 rollback pre_deploy_20240115_120000  # Rollback to specific backup

Environment:
    ENV_FILE         Environment file (default: .env.production)
    COMPOSE_FILE     Docker Compose file (default: docker-compose.prod.yml)
    BACKUP_DIR       Backup directory (default: ./backups)

For rollback, you can specify a backup name from the backups directory.
EOF
}

# Handle command line arguments
case "${1:-deploy}" in
    "deploy")
        deploy
        ;;
    "rollback")
        if [ -z "${2:-}" ]; then
            print_error "Please specify a backup name"
            echo "Available backups:"
            ls -la "$BACKUP_DIR"/pre_deploy_* 2>/dev/null | awk '{print $9}' | sed 's|.*/||' || echo "No backups found"
            exit 1
        fi
        rollback "$2"
        ;;
    "status")
        show_status
        ;;
    "test")
        run_tests
        ;;
    "help"|"-h"|"--help")
        show_help
        ;;
    *)
        print_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
