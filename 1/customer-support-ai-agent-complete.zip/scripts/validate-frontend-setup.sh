#!/bin/bash

# Frontend Testing and Deployment Validation Script
# This script validates that all testing and deployment components are properly set up

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

TOTAL_CHECKS=0
PASSED_CHECKS=0

check() {
    local description="$1"
    local command="$2"
    
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    log_info "Checking: $description"
    
    if eval "$command" > /dev/null 2>&1; then
        log_success "✓ $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        log_error "✗ $description"
        return 1
    fi
}

echo "🧪 Frontend Testing & Deployment Validation"
echo "=============================================="

# Check testing framework files
log_info "1. Testing Framework Setup"
check "Vitest config exists" "test -f frontend/vitest.config.ts"
check "Test setup file exists" "test -f frontend/src/test/setup.ts"
check "MSW server config exists" "test -f frontend/src/test/msw-server.ts"
check "Test utilities exist" "test -f frontend/src/test/utils.tsx"

# Check component tests
log_info "2. Component Unit Tests"
check "App component test exists" "test -f frontend/src/App.test.tsx"
check "Header component test exists" "test -f frontend/src/components/Header.test.tsx"
check "ChatInterface component test exists" "test -f frontend/src/components/ChatInterface.test.tsx"
check "MessageBubble component test exists" "test -f frontend/src/components/MessageBubble.test.tsx"
check "FileUpload component test exists" "test -f frontend/src/components/FileUpload.test.tsx"
check "TypingIndicator component test exists" "test -f frontend/src/components/TypingIndicator.test.tsx"

# Check service and hook tests
log_info "3. Service & Hook Tests"
check "API service test exists" "test -f frontend/src/services/api.test.ts"
check "useWebSocket hook test exists" "test -f frontend/src/hooks/useWebSocket.test.ts"
check "Integration tests exist" "test -f frontend/src/test/integration/chat-integration.test.tsx"

# Check E2E testing
log_info "4. End-to-End Testing"
check "Playwright config exists" "test -f frontend/playwright.config.ts"
check "Chat E2E tests exist" "test -f frontend/e2e/chat.spec.ts"
check "Accessibility E2E tests exist" "test -f frontend/e2e/accessibility.spec.ts"

# Check deployment configuration
log_info "5. Deployment Configuration"
check "Dockerfile exists" "test -f frontend/Dockerfile"
check "Production Dockerfile exists" "test -f frontend/Dockerfile.prod"
check "Nginx config exists" "test -f frontend/nginx.conf"

# Check Kubernetes manifests
log_info "6. Kubernetes Configuration"
check "K8s deployment exists" "test -f k8s/deployment.yaml"
check "K8s service exists" "test -f k8s/service.yaml"
check "K8s ingress exists" "test -f k8s/ingress.yaml"
check "K8s HPA exists" "test -f k8s/hpa.yaml"

# Check CI/CD configuration
log_info "7. CI/CD Pipeline"
check "GitHub workflow exists" "test -f .github/workflows/frontend-ci-cd.yml"

# Check automation scripts
log_info "8. Automation Scripts"
check "Test runner script exists" "test -f scripts/testing/run-tests.sh"
check "Deployment script exists" "test -f scripts/deployment/deploy-frontend.sh"

# Check configuration files
log_info "9. Configuration Files"
check "Lighthouse config exists" "test -f frontend/lighthouserc.js"
check "Vite config exists" "test -f frontend/vite.config.ts"
check "TypeScript config exists" "test -f frontend/tsconfig.json"

# Validate file content
log_info "10. Content Validation"

# Check test coverage
if grep -q "coverage" frontend/vitest.config.ts; then
    log_success "✓ Coverage configuration in Vitest"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    log_error "✗ Missing coverage config"
fi
TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

# Check E2E browser support
if grep -q "chromium\|firefox\|webkit" frontend/playwright.config.ts; then
    log_success "✓ Multi-browser E2E testing configured"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    log_error "✗ Missing multi-browser config"
fi
TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

# Check accessibility testing
if grep -q "accessibility" frontend/e2e/accessibility.spec.ts; then
    log_success "✓ Accessibility tests configured"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    log_error "✗ Missing accessibility tests"
fi
TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

# Check performance monitoring
if grep -q "lighthouserc.js" frontend/package.json; then
    log_success "✓ Performance monitoring configured"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    log_error "✗ Missing performance monitoring"
fi
TOTAL_CHECKS=$((PASSED_CHECKS + 1))

# Check security scanning
if grep -q "trivy\|npm audit" .github/workflows/frontend-ci-cd.yml; then
    log_success "✓ Security scanning configured"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    log_error "✗ Missing security scanning"
fi
TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

# Summary
echo ""
echo "📊 Validation Summary"
echo "====================="
echo "Total checks: $TOTAL_CHECKS"
echo "Passed: $PASSED_CHECKS"
echo "Failed: $((TOTAL_CHECKS - PASSED_CHECKS))"

if [ $PASSED_CHECKS -eq $TOTAL_CHECKS ]; then
    log_success "🎉 All frontend testing and deployment components are properly configured!"
    exit 0
else
    log_error "⚠️  Some components are missing or misconfigured"
    exit 1
fi