#!/bin/bash
# Development Setup Script for Customer Support AI Agent

set -e

echo "🚀 Setting up Customer Support AI Agent - Development Environment"

# Check Python version
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    exit 1
fi

echo "✅ Python 3 found"

# Create virtual environment
echo "📦 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd backend
uv pip install --upgrade uv pip
uv pip install -r requirements.txt

# Create data directories
echo "📁 Creating data directories..."
mkdir -p data/sqlite
mkdir -p data/chromadb
mkdir -p logs

# Initialize database
echo "🗄️  Initializing database..."
python -c "
from app.database import init_db
import asyncio
asyncio.run(init_db())
"

# Install frontend dependencies
echo "📦 Installing frontend dependencies..."
cd ../frontend
npm install

# Create environment file
echo "⚙️  Creating environment configuration..."
cp ../.env .env.local

echo "✅ Setup complete!"
echo ""
echo "To start the development environment:"
echo "  1. Start backend: cd backend && uvicorn app.main:app --reload --host 0.0.0.0 --port 8000"
echo "  2. Start frontend: cd frontend && npm run dev"
echo ""
echo "Alternatively, run: docker-compose up"
