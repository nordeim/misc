# RAG Tool with ChromaDB Integration

This document provides comprehensive documentation for the Retrieval-Augmented Generation (RAG) tool with ChromaDB integration, implemented as part of the customer support AI agent system.

## Overview

The RAG tool provides advanced document processing, embedding generation, and semantic search capabilities using ChromaDB as the vector database backend. It enables efficient knowledge base construction and retrieval for AI-powered customer support.

## Architecture

### Core Components

1. **DocumentProcessor**: Handles document parsing, chunking, and preprocessing
2. **EmbeddingService**: Manages embedding generation with caching
3. **ChromaDBManager**: Handles vector database operations
4. **SearchEngine**: Provides semantic, keyword, and hybrid search
5. **RAGTool**: Main interface for all RAG operations

### Technology Stack

- **Vector Database**: ChromaDB for persistent vector storage
- **Embeddings**: SentenceTransformers with configurable models
- **Caching**: Multi-level caching (memory + Redis)
- **Document Processing**: Support for PDF, DOCX, TXT, MD, HTML
- **Performance Monitoring**: Real-time metrics and analytics

## Installation and Setup

### Prerequisites

```bash
# Install system dependencies
apt-get update
apt-get install -y tesseract-ocr poppler-utils libreoffice

# Install Python dependencies
pip install -r requirements.txt
```

### Environment Configuration

Configure the following environment variables:

```bash
# ChromaDB Configuration
CHROMA_PERSIST_DIRECTORY=./data/chromadb
CHROMA_COLLECTION_NAME=customer_support_docs

# Embedding Model
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
EMBEDDING_BATCH_SIZE=32

# RAG Configuration
RAG_CHUNK_SIZE=1000
RAG_CHUNK_OVERLAP=200
RAG_ENABLED=true

# Document Processing
DOCUMENT_CHUNKING_ENABLED=true
DOCUMENT_SUPPORTED_FORMATS=pdf,docx,txt,md,html
DOCUMENT_MAX_SIZE_MB=50

# Cache Configuration
REDIS_URL=redis://localhost:6379/0
AI_CACHE_TTL=3600
AI_CACHE_MAX_SIZE=1000
```

### Database Initialization

```python
from app.tools.rag_tool import RAGTool

# Initialize RAG tool
rag_tool = RAGTool()
await rag_tool.initialize()
```

## Usage Guide

### Basic Operations

#### Adding Documents

```python
# Add documents to knowledge base
documents = [
    "Python programming guide for beginners",
    "Machine learning algorithms and applications",
    "Data science best practices and methodologies"
]

stats = await rag_tool.add_documents(documents)
print(f"Added {stats.total_chunks} chunks from {stats.total_documents} documents")
```

#### Search Operations

```python
# Semantic search
results = await rag_tool.search(
    query="Python programming concepts",
    search_type="semantic",
    top_k=5
)

print(f"Found {results['total_results']} results with confidence: {results['confidence']}")

# Hybrid search (semantic + keyword)
hybrid_results = await rag_tool.search(
    query="machine learning algorithms",
    search_type="hybrid",
    top_k=5,
    filter_metadata={"category": "technical"}
)

# Keyword-only search
keyword_results = await rag_tool.search(
    query="data science python",
    search_type="keyword",
    top_k=3
)
```

#### Similarity Search

```python
# Find similar documents
similar_docs = await rag_tool.similarity_search(
    document="This is a sample document for comparison",
    top_k=5
)

for doc in similar_docs:
    print(f"Similarity: {doc['similarity']:.3f}")
    print(f"Content: {doc['content'][:100]}...")
```

### Advanced Features

#### Document Processing with File Paths

```python
# Process documents with metadata
documents = [
    "Document content 1",
    "Document content 2"
]

metadatas = [
    {"category": "technical", "source": "manual"},
    {"category": "guide", "source": "documentation"}
]

source_paths = [
    "/path/to/doc1.txt",
    "/path/to/doc2.pdf"
]

stats = await rag_tool.add_documents(
    documents=documents,
    metadatas=metadatas,
    source_paths=source_paths
)
```

#### Performance Monitoring

```python
from app.utils.performance_monitor import performance_monitor

# Start performance monitoring
performance_monitor.start_monitoring(interval=30.0)

# Get performance statistics
query_perf = performance_monitor.get_query_performance(hours=24)
system_perf = performance_monitor.get_system_performance(hours=1)

# Get comprehensive summary
summary = performance_monitor.get_performance_summary(hours=24)
print(f"Average query time: {summary['query_performance']['average_execution_time']:.2f}s")
```

#### Cache Management

```python
from app.utils.caching import cache_manager

# Initialize cache
await cache_manager.initialize()

# Use cached function
@cache_manager.cached(ttl=3600, key_prefix="embedding")
async def expensive_operation(text: str):
    # Expensive computation here
    return result

# Manually cache data
await cache_manager.cache.set("custom_key", {"data": "value"}, ttl=1800)
cached_value = await cache_manager.cache.get("custom_key")
```

### Batch Processing

#### Document Directory Processing

```python
from app.utils.document_processor import BatchDocumentProcessor

processor = BatchDocumentProcessor(max_concurrent=5)

def progress_callback(completed_count):
    print(f"Processed {completed_count} documents")

# Process entire directory
results = await processor.process_directory(
    directory_path="/path/to/documents",
    recursive=True,
    include_patterns=["*.pdf", "*.docx"],
    progress_callback=progress_callback
)

print(f"Processed {len(results)} documents")
```

#### Embedding Generation in Batches

```python
from app.tools.rag_tool import EmbeddingService

embedding_service = EmbeddingService()
await embedding_service.initialize()

# Batch generate embeddings
texts = ["Text 1", "Text 2", "Text 3"]
embeddings = await embedding_service.generate_embeddings_batch(texts)

for i, embedding in enumerate(embeddings):
    print(f"Text {i}: {len(embedding)} dimensions")
```

## API Reference

### RAGTool Class

#### Methods

##### `initialize() -> None`
Initialize all RAG tool components.

##### `add_documents(documents, metadatas=None, source_paths=None) -> ProcessingStats`
Add documents to the knowledge base.

**Parameters:**
- `documents`: List of document contents
- `metadatas`: Optional list of metadata dictionaries
- `source_paths`: Optional list of source file paths

**Returns:** ProcessingStats object with processing metrics

##### `search(query, search_type='semantic', top_k=5, filter_metadata=None) -> Dict[str, Any]`
Search the knowledge base.

**Parameters:**
- `query`: Search query text
- `search_type`: Type of search ('semantic', 'keyword', 'hybrid')
- `top_k`: Number of results to return
- `filter_metadata`: Optional metadata filters

**Returns:** Dictionary with search results and metadata

##### `similarity_search(document, top_k=5, filter_metadata=None) -> List[Dict[str, Any]]`
Find documents similar to a given document.

##### `get_collection_stats() -> Dict[str, Any]`
Get comprehensive statistics about the knowledge base.

##### `health_check() -> Dict[str, Any]`
Perform health check on all RAG components.

##### `create_backup(backup_path=None) -> bool`
Create a backup of the knowledge base.

##### `delete_collection() -> None`
Delete the entire knowledge base collection.

### DocumentProcessor Class

#### Methods

##### `chunk_document(content, metadata=None) -> List[DocumentChunk]`
Split document into overlapping chunks.

##### `extract_metadata(content, source_path=None) -> Dict[str, Any]`
Extract metadata from document content and source.

##### `validate_document(content, source_path=None) -> Tuple[bool, str]`
Validate document for processing.

### EmbeddingService Class

#### Methods

##### `initialize() -> None`
Initialize the embedding model.

##### `generate_embedding(text) -> List[float]`
Generate embedding for a single text with caching.

##### `generate_embeddings_batch(texts) -> List[List[float]]`
Generate embeddings for multiple texts in batches.

### SearchEngine Class

#### Methods

##### `semantic_search(query, top_k=5, filter_metadata=None) -> List[SearchResult]`
Perform semantic search using vector similarity.

##### `keyword_search(query, top_k=5, filter_metadata=None) -> List[SearchResult]`
Perform keyword-based search using TF-IDF.

##### `hybrid_search(query, top_k=5, vector_weight=0.7, keyword_weight=0.3, filter_metadata=None) -> List[SearchResult]`
Perform hybrid search combining semantic and keyword search.

## Configuration Options

### ChromaDB Settings

```python
# ChromaDB configuration
CHROMA_PERSIST_DIRECTORY = "./data/chromadb"  # Persistence directory
CHROMA_COLLECTION_NAME = "customer_support_docs"  # Collection name
CHROMA_TENANT_NAME = "customer_support"  # Tenant name
CHROMA_DATABASE_NAME = "customer_support"  # Database name
```

### Embedding Configuration

```python
# Embedding model settings
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
EMBEDDING_BATCH_SIZE = 32
EMBEDDING_DIMENSION = 384
```

### RAG Settings

```python
# RAG configuration
RAG_CHUNK_SIZE = 1000  # Character chunk size
RAG_CHUNK_OVERLAP = 200  # Character overlap
RAG_MAX_CHUNKS_PER_QUERY = 5
RAG_SIMILARITY_THRESHOLD = 0.7
```

### Cache Settings

```python
# Cache configuration
AI_CACHE_TTL = 3600  # Cache TTL in seconds
AI_CACHE_MAX_SIZE = 1000  # Maximum cache size
REDIS_URL = "redis://localhost:6379/0"  # Redis connection
```

### Document Processing Settings

```python
# Document processing
DOCUMENT_CHUNKING_ENABLED = True
DOCUMENT_SUPPORTED_FORMATS = ["pdf", "docx", "txt", "md", "html"]
DOCUMENT_MAX_SIZE_MB = 50
DOCUMENT_UPLOAD_PATH = "./data/uploads"
```

## Performance Optimization

### Caching Strategies

1. **Embedding Cache**: Automatically caches generated embeddings
2. **Search Result Cache**: Caches search results with configurable TTL
3. **Multi-level Cache**: Memory + Redis for optimal performance

### Memory Management

```python
# Monitor memory usage
import psutil

process = psutil.Process()
memory_mb = process.memory_info().rss / 1024 / 1024
print(f"Memory usage: {memory_mb:.2f} MB")
```

### Batch Processing

```python
# Process documents in batches to avoid memory issues
BATCH_SIZE = 100

for i in range(0, len(documents), BATCH_SIZE):
    batch = documents[i:i + BATCH_SIZE]
    stats = await rag_tool.add_documents(batch)
    print(f"Processed batch {i//BATCH_SIZE + 1}")
```

### Index Optimization

```python
# Create ChromaDB backup before optimization
await rag_tool.create_backup()

# Monitor collection statistics
stats = await rag_tool.get_collection_stats()
print(f"Collection has {stats['total_documents']} documents")
```

## Monitoring and Analytics

### Performance Metrics

The system tracks:
- Query execution time
- Memory usage
- Cache hit rates
- Search accuracy
- System resource utilization

### Health Checks

```python
# Comprehensive health check
health = await rag_tool.health_check()

print(f"Overall status: {health['overall_status']}")
print(f"Components: {health['components']}")
```

### Performance Monitoring

```python
from app.utils.performance_monitor import PerformanceContext

# Track specific operations
with PerformanceContext(performance_monitor, "document_processing"):
    stats = await rag_tool.add_documents(documents)

# Get performance reports
query_performance = performance_monitor.get_query_performance(hours=24)
system_performance = performance_monitor.get_system_performance(hours=1)
```

## Troubleshooting

### Common Issues

#### 1. ChromaDB Connection Issues

```python
# Check ChromaDB initialization
try:
    await rag_tool.initialize()
except Exception as e:
    print(f"ChromaDB initialization failed: {e}")
    
    # Check directory permissions
    import os
    persist_dir = Path("./data/chromadb")
    print(f"Directory exists: {persist_dir.exists()}")
    print(f"Directory writable: {os.access(persist_dir, os.W_OK)}")
```

#### 2. Memory Issues

```python
# Monitor memory usage during large operations
import psutil

def monitor_memory():
    memory = psutil.virtual_memory()
    print(f"Memory usage: {memory.percent:.1f}%")
    
    if memory.percent > 90:
        print("WARNING: High memory usage detected")

# Use with large document batches
for batch in document_batches:
    monitor_memory()
    stats = await rag_tool.add_documents(batch)
```

#### 3. Cache Issues

```python
# Debug cache performance
stats = cache_manager.get_cache_stats()
print(f"Cache hit rate: {stats['combined']['hit_rate']:.2%}")
print(f"Cache size: {stats['memory_cache']['size']}")

# Clear cache if needed
await cache_manager.clear_cache()
```

#### 4. Embedding Model Loading

```python
# Check embedding model availability
from sentence_transformers import SentenceTransformer

try:
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    print("Model loaded successfully")
except Exception as e:
    print(f"Model loading failed: {e}")
    
    # Try alternative model
    try:
        model = SentenceTransformer("all-MiniLM-L6-v2")
        print("Alternative model loaded successfully")
    except Exception as e2:
        print(f"Alternative model also failed: {e2}")
```

### Debug Mode

Enable debug logging:

```python
import logging

# Set debug logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("app.tools.rag_tool")
logger.setLevel(logging.DEBUG)
```

### Performance Debugging

```python
# Enable performance profiling
from app.utils.performance_monitor import track_performance

@track_performance(performance_monitor, "search_operation")
async def search_with_monitoring(query):
    return await rag_tool.search(query)

# Profile specific operations
result = await search_with_monitoring("test query")
```

## Security Considerations

### Input Validation

```python
# Validate document content
from app.utils.document_processor import validate_document_content

is_valid, message = validate_document_content(document_content)
if not is_valid:
    raise ValueError(f"Invalid document: {message}")
```

### Access Control

```python
# Implement metadata-based access control
def filter_by_permissions(metadata, user_permissions):
    """Filter documents based on user permissions."""
    if "allowed_roles" in metadata:
        user_role = get_user_role(user_permissions)
        return user_role in metadata["allowed_roles"]
    return True
```

### Content Sanitization

```python
# Sanitize document content
import bleach

def sanitize_content(content):
    """Remove potentially malicious content."""
    cleaned = bleach.clean(content, tags=[], strip=True)
    return cleaned
```

## Best Practices

### Document Organization

1. **Use consistent metadata**: Standardize metadata fields across documents
2. **Implement proper categorization**: Use clear categories and tags
3. **Regular cleanup**: Remove obsolete or duplicate documents
4. **Backup strategy**: Implement regular backup procedures

### Performance Optimization

1. **Batch processing**: Process documents in batches for efficiency
2. **Cache warming**: Pre-warm caches with frequently accessed data
3. **Regular monitoring**: Monitor performance metrics continuously
4. **Index maintenance**: Perform regular index optimization

### Error Handling

```python
try:
    stats = await rag_tool.add_documents(documents)
except Exception as e:
    logger.error(f"Document processing failed: {e}")
    
    # Log processing statistics if available
    if hasattr(stats, 'errors'):
        for error in stats.errors:
            logger.error(f"Processing error: {error}")
```

### Code Examples

#### Complete Workflow Example

```python
import asyncio
from app.tools.rag_tool import RAGTool
from app.utils.performance_monitor import performance_monitor

async def setup_rag_knowledge_base():
    """Complete RAG setup and document ingestion workflow."""
    
    # Initialize RAG tool
    rag_tool = RAGTool()
    await rag_tool.initialize()
    
    # Start performance monitoring
    performance_monitor.start_monitoring()
    
    # Define documents to add
    documents = [
        "Python programming fundamentals and best practices",
        "Machine learning algorithms for predictive analytics",
        "Data science methodologies and statistical analysis",
        "Natural language processing techniques and applications",
        "Computer vision and image recognition systems"
    ]
    
    # Add documents with metadata
    metadatas = [
        {"category": "programming", "difficulty": "beginner"},
        {"category": "ml", "difficulty": "intermediate"},
        {"category": "data_science", "difficulty": "intermediate"},
        {"category": "nlp", "difficulty": "advanced"},
        {"category": "cv", "difficulty": "advanced"}
    ]
    
    try:
        # Add documents to knowledge base
        print("Adding documents to knowledge base...")
        stats = await rag_tool.add_documents(documents, metadatas)
        print(f"Successfully processed {stats.total_chunks} chunks")
        
        # Perform test searches
        test_queries = [
            "Python programming basics",
            "machine learning algorithms",
            "data analysis methods"
        ]
        
        for query in test_queries:
            print(f"\nSearching for: {query}")
            
            # Semantic search
            semantic_results = await rag_tool.search(
                query, search_type="semantic", top_k=3
            )
            print(f"Semantic search: {len(semantic_results['sources'])} results")
            print(f"Confidence: {semantic_results['confidence']:.3f}")
            
            # Hybrid search
            hybrid_results = await rag_tool.search(
                query, search_type="hybrid", top_k=3
            )
            print(f"Hybrid search: {len(hybrid_results['sources'])} results")
            print(f"Confidence: {hybrid_results['confidence']:.3f}")
        
        # Get collection statistics
        print("\nCollection Statistics:")
        collection_stats = await rag_tool.get_collection_stats()
        for key, value in collection_stats.items():
            print(f"  {key}: {value}")
        
        # Create backup
        print("\nCreating backup...")
        backup_success = await rag_tool.create_backup("./backups/rag_kb_backup")
        print(f"Backup created: {backup_success}")
        
        # Health check
        print("\nHealth Check:")
        health = await rag_tool.health_check()
        print(f"Status: {health['overall_status']}")
        
    except Exception as e:
        print(f"Error during RAG setup: {e}")
        
    finally:
        # Cleanup
        await rag_tool.close()
        performance_monitor.stop_monitoring()

# Run the example
if __name__ == "__main__":
    asyncio.run(setup_rag_knowledge_base())
```

This documentation provides a comprehensive guide for using and maintaining the RAG tool with ChromaDB integration. For additional support or questions, refer to the test suite and source code for more detailed examples.