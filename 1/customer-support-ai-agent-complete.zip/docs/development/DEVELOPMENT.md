# 🛠️ Development Guide

This guide provides comprehensive information for developers working on the Customer Support AI Agent project.

## Table of Contents

- [Development Setup](#development-setup)
- [Project Structure](#project-structure)
- [Coding Standards](#coding-standards)
- [Testing Guidelines](#testing-guidelines)
- [Debugging](#debugging)
- [Performance Optimization](#performance-optimization)
- [Common Development Tasks](#common-development-tasks)

---

## Development Setup

### Prerequisites

Ensure you have the following installed:
- Python 3.11+
- Node.js 18+
- Git
- Docker and Docker Compose

### Local Development Environment

#### 1. Clone and Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/customer-support-ai-agent.git
cd customer-support-ai-agent

# Create Python virtual environment
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Install frontend dependencies
cd ../frontend
npm install
```

#### 2. Environment Configuration

```bash
# Copy environment template
cd ..
cp .env.example .env

# Edit environment variables
nano .env
```

Required environment variables for development:
```env
# Development Settings
DEBUG=true
LOG_LEVEL=DEBUG
ENVIRONMENT=development

# Database (SQLite for development)
DATABASE_URL=sqlite:///./customer_support.db

# Redis (optional, will fallback to in-memory)
REDIS_URL=redis://localhost:6379

# ChromaDB
CHROMA_PERSIST_DIRECTORY=./chroma_db

# OpenAI (for LLM)
OPENAI_API_KEY=your-openai-key
AGENT_MODEL=gpt-4o-mini

# Frontend
FRONTEND_URL=http://localhost:3000
```

#### 3. Initialize Database

```bash
cd backend
python -m alembic upgrade head

# Seed with sample data (optional)
python scripts/seed_data.py
```

#### 4. Download AI Models

```bash
# Download SentenceTransformer model
python scripts/download_models.py
```

#### 5. Start Development Services

**Option A: Docker (Recommended)**
```bash
# Start supporting services
docker-compose up -d redis chromadb

# Start backend (from backend directory)
cd backend
source venv/bin/activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Start frontend (from frontend directory)
cd ../frontend
npm run dev
```

**Option B: Manual Setup**
```bash
# Terminal 1: Redis
docker run -p 6379:6379 redis:7-alpine

# Terminal 2: ChromaDB
docker run -p 8001:8000 chromadb/chroma:latest

# Terminal 3: Backend
cd backend && source venv/bin/activate && uvicorn app.main:app --reload

# Terminal 4: Frontend
cd frontend && npm run dev
```

### Hot Reload Setup

The development environment supports hot reload for both frontend and backend:

- **Backend**: Code changes auto-reload the server
- **Frontend**: Code changes auto-reload the browser
- **Database**: Models automatically create missing tables

---

## Project Structure

### Backend Structure

```
backend/app/
├── __init__.py                 # Package initialization
├── main.py                     # FastAPI application entry point
├── config.py                   # Configuration management
├── database.py                 # Database connection and session
│
├── agents/                     # AI Agent implementations
│   ├── chat_agent.py          # Main agent orchestrator
│   └── prompts.py             # System prompts and instructions
│
├── tools/                      # Agent capability tools
│   ├── rag_tool.py            # RAG search implementation
│   ├── memory_tool.py         # Memory persistence
│   ├── attachment_tool.py     # Document processing
│   └── escalation_tool.py     # Human escalation logic
│
├── api/                        # API routes and handlers
│   ├── routes/
│   │   ├── chat.py           # Chat endpoints
│   │   ├── sessions.py       # Session management
│   │   └── health.py         # Health checks
│   ├── websocket.py          # WebSocket handlers
│   └── dependencies.py       # Shared dependencies
│
├── models/                     # Data models
│   ├── session.py            # Session ORM model
│   ├── message.py            # Message ORM model
│   ├── memory.py             # Memory ORM model
│   └── schemas.py            # Pydantic schemas
│
├── services/                   # Business logic services
│   ├── embedding_service.py  # Embedding generation
│   ├── cache_service.py      # Redis cache
│   ├── memory_service.py     # Memory operations
│   └── auth_service.py       # Authentication
│
└── utils/                      # Utility functions
    ├── telemetry.py          # OpenTelemetry setup
    ├── middleware.py         # Custom middleware
    └── validators.py         # Input validation
```

### Frontend Structure

```
frontend/src/
├── main.tsx                   # Application entry point
├── App.tsx                    # Main application component
│
├── components/                # React components
│   ├── ChatInterface.tsx     # Main chat UI
│   ├── MessageList.tsx       # Message display
│   ├── InputArea.tsx         # User input
│   ├── SourcesPanel.tsx      # Source references
│   └── FileUpload.tsx        # File upload component
│
├── hooks/                     # Custom React hooks
│   ├── useChat.ts           # Chat functionality
│   ├── useWebSocket.ts      # WebSocket connection
│   └── useFileUpload.ts     # File handling
│
├── services/                 # API services
│   ├── api.ts              # REST API client
│   └── websocket.ts        # WebSocket client
│
├── types/                    # TypeScript types
│   ├── api.ts              # API types
│   ├── chat.ts             # Chat types
│   └── index.ts            # Common types
│
└── styles/                   # CSS styles
    └── globals.css         # Global styles
```

---

## Coding Standards

### Python (Backend)

#### Style Guidelines

1. **PEP 8 Compliance**
   - Follow PEP 8 style guide
   - Maximum line length: 88 characters (Black formatter)
   - Use meaningful variable and function names

2. **Type Hints**
   ```python
   from typing import List, Optional, Dict, Any
   
   async def process_message(
       message: str,
       session_id: str,
       context: Optional[Dict[str, Any]] = None
   ) -> Dict[str, Any]:
       """Process a user message and return response."""
       pass
   ```

3. **Docstrings**
   ```python
   async def search_knowledge_base(
       query: str,
       limit: int = 5
   ) -> List[Dict[str, Any]]:
       """
       Search the knowledge base using RAG.
       
       Args:
           query: Search query string
           limit: Maximum number of results to return
           
       Returns:
           List of relevant documents with metadata
           
       Raises:
           ValueError: If query is empty
       """
       if not query.strip():
           raise ValueError("Query cannot be empty")
       pass
   ```

4. **Error Handling**
   ```python
   from fastapi import HTTPException
   
   async def risky_operation() -> str:
       try:
           result = await external_api_call()
           return result
       except SpecificError as e:
           logger.error(f"External API failed: {e}")
           raise HTTPException(status_code=503, detail="Service unavailable")
       except Exception as e:
           logger.exception(f"Unexpected error: {e}")
           raise HTTPException(status_code=500, detail="Internal server error")
   ```

5. **Async/Await Patterns**
   ```python
   # Good: Proper async usage
   async def get_user_data(user_id: str) -> Dict[str, Any]:
       # Concurrent database queries
       user_task = db.get_user(user_id)
       preferences_task = db.get_preferences(user_id)
       
       user, preferences = await asyncio.gather(
           user_task, preferences_task
       )
       
       return {"user": user, "preferences": preferences}
   
   # Bad: Blocking operations in async
   async def bad_example():
       time.sleep(1)  # This blocks the event loop!
   ```

#### Code Organization

1. **Imports**
   ```python
   # Standard library
   import asyncio
   import logging
   from typing import List, Optional
   
   # Third party
   import pytest
   from fastapi import FastAPI
   
   # Local
   from .models import Session
   from ..utils.validators import validate_input
   ```

2. **Configuration**
   ```python
   # Use Pydantic Settings
   from pydantic import BaseSettings, validator
   
   class Settings(BaseSettings):
       database_url: str
       redis_url: str = "redis://localhost:6379"
       debug: bool = False
       
       @validator("database_url")
       def validate_database_url(cls, v):
           if not v:
               raise ValueError("Database URL is required")
           return v
       
       class Config:
           env_file = ".env"
   ```

### TypeScript (Frontend)

#### Style Guidelines

1. **TypeScript Best Practices**
   ```typescript
   // Use strict typing
   interface ChatMessage {
     id: string;
     content: string;
     role: 'user' | 'assistant';
     timestamp: Date;
     sources?: Source[];
     sessionId: string;
   }
   
   // Use proper types for API calls
   async function sendMessage(
     sessionId: string, 
     message: string
   ): Promise<ChatResponse> {
     const response = await api.post('/chat/sessions/{id}/messages', {
       message
     });
     return response.data;
   }
   ```

2. **React Component Structure**
   ```typescript
   // Functional components with hooks
   interface MessageListProps {
     messages: ChatMessage[];
     onMessageSelect?: (message: ChatMessage) => void;
   }
   
   export const MessageList: React.FC<MessageListProps> = ({
     messages,
     onMessageSelect
   }) => {
     const [selectedMessage, setSelectedMessage] = useState<ChatMessage | null>(null);
     
     const handleMessageClick = useCallback((message: ChatMessage) => {
       setSelectedMessage(message);
       onMessageSelect?.(message);
     }, [onMessageSelect]);
     
     return (
       <div className="message-list">
         {messages.map(message => (
           <MessageItem
             key={message.id}
             message={message}
             onClick={handleMessageClick}
             selected={selectedMessage?.id === message.id}
           />
         ))}
       </div>
     );
   };
   ```

3. **Custom Hooks**
   ```typescript
   // Well-structured custom hooks
   export const useChat = (sessionId: string) => {
     const [messages, setMessages] = useState<ChatMessage[]>([]);
     const [isLoading, setIsLoading] = useState(false);
     
     const sendMessage = useCallback(async (content: string) => {
       setIsLoading(true);
       try {
         const response = await api.sendMessage(sessionId, content);
         setMessages(prev => [...prev, response]);
       } catch (error) {
         console.error('Failed to send message:', error);
       } finally {
         setIsLoading(false);
       }
     }, [sessionId]);
     
     return {
       messages,
       isLoading,
       sendMessage
     };
   };
   ```

4. **Error Handling**
   ```typescript
   // Proper error handling in components
   const ChatInterface: React.FC = () => {
     const [error, setError] = useState<string | null>(null);
     
     const handleSendMessage = async (message: string) => {
       try {
         setError(null);
         await sendMessage(message);
       } catch (err) {
         const errorMessage = err instanceof Error ? err.message : 'Unknown error';
         setError(errorMessage);
       }
     };
     
     return (
       <div>
         {error && (
           <Alert severity="error" onClose={() => setError(null)}>
             {error}
           </Alert>
         )}
         {/* Chat UI */}
       </div>
     );
   };
   ```

---

## Testing Guidelines

### Backend Testing

#### Test Structure

```
backend/tests/
├── conftest.py                 # pytest configuration and fixtures
├── unit/                      # Unit tests
│   ├── test_agents.py         # Agent tests
│   ├── test_tools.py          # Tool tests
│   └── test_services.py       # Service tests
├── integration/               # Integration tests
│   ├── test_api.py           # API endpoint tests
│   └── test_websocket.py     # WebSocket tests
└── fixtures/                  # Test data and fixtures
    ├── sample_documents/
    └── mock_responses/
```

#### Writing Tests

1. **Unit Tests**
   ```python
   import pytest
   from unittest.mock import Mock, patch
   from app.agents.chat_agent import CustomerSupportAgent
   from app.tools.rag_tool import RAGTool
   
   class TestRAGTool:
       @pytest.fixture
       def rag_tool(self):
           return RAGTool()
       
       def test_search_returns_results(self, rag_tool):
           # Arrange
           query = "test query"
           
           # Act
           results = asyncio.run(rag_tool.search(query))
           
           # Assert
           assert isinstance(results, list)
           assert len(results) > 0
           assert all('content' in result for result in results)
       
       @patch('app.tools.rag_tool.ChromaDB')
       def test_search_with_mock_db(self, mock_chromadb, rag_tool):
           # Arrange
           mock_chromadb.return_value.query.return_value = [
               {"content": "test content", "metadata": {}}
           ]
           
           # Act
           results = asyncio.run(rag_tool.search("test"))
           
           # Assert
           assert len(results) == 1
           mock_chromadb.assert_called_once()
   ```

2. **Integration Tests**
   ```python
   from fastapi.testclient import TestClient
   from app.main import app
   
   class TestChatAPI:
       def setup_method(self):
           self.client = TestClient(app)
       
       def test_create_session(self):
           response = self.client.post("/api/sessions")
           assert response.status_code == 201
           data = response.json()
           assert "session_id" in data
       
       def test_send_message(self):
           # First create a session
           session_response = self.client.post("/api/sessions")
           session_id = session_response.json()["session_id"]
           
           # Then send a message
           message_data = {"message": "Hello, how can you help me?"}
           response = self.client.post(
               f"/api/chat/sessions/{session_id}/messages",
               json=message_data
           )
           
           assert response.status_code == 200
           data = response.json()
           assert "message" in data
           assert "session_id" in data
   ```

3. **Test Fixtures**
   ```python
   # conftest.py
   import pytest
   import asyncio
   from app.database import get_db, engine
   from app.models import Base
   
   @pytest.fixture(scope="session")
   def event_loop():
       """Create an instance of the default event loop for the test session."""
       loop = asyncio.get_event_loop_policy().new_event_loop()
       yield loop
       loop.close()
   
   @pytest.fixture
   def test_db():
       """Create a test database."""
       Base.metadata.create_all(bind=engine)
       yield
       Base.metadata.drop_all(bind=engine)
   
   @pytest.fixture
   def client():
       """Create a test client."""
       from fastapi.testclient import TestClient
       with TestClient(app) as c:
           yield c
   ```

#### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html --cov-report=term

# Run specific test file
pytest tests/unit/test_agents.py

# Run with markers
pytest -m "not slow"

# Run in parallel
pytest -n 4

# Run specific test
pytest tests/test_agents.py::TestChatAgent::test_process_message
```

### Frontend Testing

#### Test Structure

```
frontend/src/
├── __tests__/                 # Test files
│   ├── components/           # Component tests
│   ├── hooks/               # Hook tests
│   ├── services/            # Service tests
│   └── utils/               # Utility tests
└── test-utils/
    ├── mocks/               # Mock data and utilities
    └── test-setup.ts        # Test configuration
```

#### Writing Tests

1. **Component Tests**
   ```typescript
   import { render, screen, fireEvent, waitFor } from '@testing-library/react';
   import { ChatInterface } from '../components/ChatInterface';
   import { mockChatApi } from '../test-utils/mocks';
   
   jest.mock('../services/api', () => ({
     chatApi: mockChatApi
   }));
   
   describe('ChatInterface', () => {
     it('should send message when form is submitted', async () => {
       render(<ChatInterface sessionId="test-session" />);
       
       // Find input and send button
       const input = screen.getByPlaceholderText('Type your message...');
       const sendButton = screen.getByText('Send');
       
       // Type message and submit
       fireEvent.change(input, { target: { value: 'Hello' } });
       fireEvent.click(sendButton);
       
       // Wait for message to appear
       await waitFor(() => {
         expect(screen.getByText('Hello')).toBeInTheDocument();
       });
     });
     
     it('should handle error when message fails to send', async () => {
       mockChatApi.sendMessage.mockRejectedValue(new Error('Network error'));
       
       render(<ChatInterface sessionId="test-session" />);
       
       const input = screen.getByPlaceholderText('Type your message...');
       const sendButton = screen.getByText('Send');
       
       fireEvent.change(input, { target: { value: 'Hello' } });
       fireEvent.click(sendButton);
       
       await waitFor(() => {
         expect(screen.getByText('Failed to send message')).toBeInTheDocument();
       });
     });
   });
   ```

2. **Hook Tests**
   ```typescript
   import { renderHook, act } from '@testing-library/react';
   import { useChat } from '../hooks/useChat';
   import { mockChatApi } from '../test-utils/mocks';
   
   jest.mock('../services/api');
   
   describe('useChat', () => {
     it('should send message and update messages', async () => {
       const { result } = renderHook(() => useChat('test-session'));
       
       // Initial state
       expect(result.current.messages).toEqual([]);
       expect(result.current.isLoading).toBe(false);
       
       // Send message
       await act(async () => {
         await result.current.sendMessage('Hello');
       });
       
       // Check updated state
       expect(result.current.messages.length).toBe(1);
       expect(result.current.messages[0].content).toBe('Hello');
     });
   });
   ```

3. **Service Tests**
   ```typescript
   import { ChatApi } from '../services/api';
   
   describe('ChatApi', () => {
     beforeEach(() => {
       fetchMock.resetMocks();
     });
     
     it('should send message successfully', async () => {
       const mockResponse = {
         message: 'Test response',
         session_id: 'test-session'
       };
       
       fetchMock.mockResponseOnce(JSON.stringify(mockResponse));
       
       const api = new ChatApi('http://localhost:8000');
       const result = await api.sendMessage('test-session', 'Hello');
       
       expect(result).toEqual(mockResponse);
       expect(fetch).toHaveBeenCalledWith(
         'http://localhost:8000/api/chat/sessions/test-session/messages',
         expect.objectContaining({
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ message: 'Hello' })
         })
       );
     });
   });
   ```

#### Running Tests

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run in watch mode
npm run test:watch

# Run specific test file
npm test ChatInterface.test.tsx

# Run tests with specific pattern
npm test -- --testNamePattern="should send message"
```

### Test Coverage Requirements

- **Minimum Coverage**: 80% for new code
- **Critical Path Coverage**: 95% for core functionality
- **Integration Tests**: All API endpoints must have integration tests

---

## Debugging

### Backend Debugging

#### Using Python Debugger

```python
import pdb; pdb.set_trace()  # Set breakpoint

# Or using ipdb for better debugging
import ipdb; ipdb.set_trace()
```

#### Using VS Code Debugger

Create `.vscode/launch.json`:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: FastAPI",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/backend/venv/bin/uvicorn",
            "args": [
                "app.main:app",
                "--reload",
                "--host",
                "0.0.0.0",
                "--port",
                "8000"
            ],
            "cwd": "${workspaceFolder}/backend",
            "console": "integratedTerminal"
        }
    ]
}
```

#### Debugging Tests

```bash
# Run test with debugger
pytest --pdb tests/test_agents.py

# Drop into debugger on failure
pytest --pdbcls=IPython.terminal.debugger:Pdb ./tests/test_agents.py

# Run test with verbose output
pytest -v -s tests/test_agents.py
```

#### Common Debug Commands

```bash
# Check database state
docker exec -it cs-backend python -c "
from app.database import SessionLocal
from app.models import Session
db = SessionLocal()
sessions = db.query(Session).all()
print(f'Total sessions: {len(sessions)}')
for session in sessions:
    print(f'Session {session.id}: {len(session.messages)} messages')
"

# Test ChromaDB connection
docker exec -it cs-backend python -c "
import chromadb
client = chromadb.Client()
print('ChromaDB client created successfully')
collections = client.list_collections()
print(f'Collections: {[c.name for c in collections]}')
"

# Check Redis connection
docker exec -it cs-redis redis-cli ping
```

### Frontend Debugging

#### Browser DevTools

1. **React Developer Tools**
   - Install React DevTools extension
   - Inspect component tree and props
   - View component state and hooks

2. **Network Tab**
   - Monitor API requests
   - Check request/response payloads
   - Identify failed requests

3. **Console Debugging**
   ```typescript
   // Debug WebSocket messages
   const ws = new WebSocket('ws://localhost:8000/ws?session_id=123');
   ws.onmessage = (event) => {
     console.log('WebSocket message:', event.data);
   };
   
   // Debug API calls
   const originalFetch = window.fetch;
   window.fetch = (...args) => {
     console.log('Fetch request:', args);
     return originalFetch(...args).then(response => {
       console.log('Fetch response:', response);
       return response;
     });
   };
   ```

#### VS Code Debugging

Create `.vscode/launch.json`:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Chrome: Launch",
            "type": "chrome",
            "request": "launch",
            "url": "http://localhost:3000",
            "webRoot": "${workspaceFolder}/frontend/src"
        }
    ]
}
```

#### Testing Components

```bash
# Run tests with detailed output
npm test -- --verbose --watchAll

# Debug specific test
npm test -- ChatInterface.test.tsx --verbose
```

### Logging

#### Backend Logging

```python
import logging
from app.utils.telemetry import setup_logging

# Setup structured logging
setup_logging()

logger = logging.getLogger(__name__)

# Use appropriate log levels
logger.info("User session created", extra={"session_id": session_id})
logger.warning("RAG search returned no results", extra={"query": query})
logger.error("Failed to process message", exc_info=True)
```

#### Frontend Logging

```typescript
// Use console with appropriate methods
console.log('Debug info', data);
console.info('Informational message', info);
console.warn('Warning message', warning);
console.error('Error occurred', error);

// Or use a logging library
import { logger } from '../utils/logger';

logger.info('User action', { action: 'send_message', userId: userId });
logger.error('API call failed', { error: error.message, endpoint: url });
```

---

## Performance Optimization

### Backend Optimization

#### Database Optimization

1. **Query Optimization**
   ```python
   # Use specific columns instead of SELECT *
   result = session.query(Session.id, Session.created_at).filter(
       Session.id == session_id
   ).first()
   
   # Use indexes for frequent queries
   # Add to your model
   class Session(Base):
       __tablename__ = "sessions"
       id = Column(String, primary_key=True)
       created_at = Column(DateTime, default=datetime.utcnow, index=True)
   
   # Use eager loading for relationships
   session = session.query(Session).options(
       selectinload(Session.messages)
   ).first()
   ```

2. **Connection Pooling**
   ```python
   # In database.py
   engine = create_engine(
       database_url,
       pool_size=20,
       max_overflow=30,
       pool_timeout=30,
       pool_recycle=3600
   )
   ```

#### Caching Strategy

```python
from app.services.cache_service import cache

@cache(ttl=3600)  # Cache for 1 hour
async def get_knowledge_base_documents() -> List[Document]:
    """Get all documents from knowledge base."""
    # Expensive operation
    pass

# Use cache decorators
@cache.memoize(timeout=1800)
async def expensive_computation(param: str) -> str:
    # Some expensive computation
    pass
```

#### Async Optimization

```python
# Use concurrent operations
async def process_multiple_requests(requests: List[str]) -> List[Response]:
    tasks = [process_single_request(req) for req in requests]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Handle exceptions
    processed_results = []
    for result in results:
        if isinstance(result, Exception):
            logger.error(f"Request failed: {result}")
            processed_results.append(None)
        else:
            processed_results.append(result)
    
    return processed_results
```

### Frontend Optimization

#### React Optimization

1. **Memoization**
   ```typescript
   // Use React.memo for expensive components
   const ExpensiveComponent = React.memo(({ data }) => {
     const processedData = useMemo(() => {
       return data.map(item => expensiveComputation(item));
     }, [data]);
     
     return <div>{processedData}</div>;
   });
   
   // Use useCallback for stable function references
   const handleClick = useCallback((id: string) => {
     onItemClick(id);
   }, [onItemClick]);
   ```

2. **Virtualization for Large Lists**
   ```typescript
   import { FixedSizeList as List } from 'react-window';
   
   const MessageList = ({ messages }: { messages: ChatMessage[] }) => (
     <List
       height={600}
       itemCount={messages.length}
       itemSize={80}
       itemData={messages}
     >
       {MessageItem}
     </List>
   );
   ```

3. **Code Splitting**
   ```typescript
   // Lazy load components
   const ChatInterface = lazy(() => import('../components/ChatInterface'));
   
   // In your component
   <Suspense fallback={<div>Loading...</div>}>
     <ChatInterface />
   </Suspense>
   ```

#### Bundle Optimization

```javascript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['@mui/material', '@emotion/react'],
        }
      }
    }
  }
});
```

---

## Common Development Tasks

### Adding a New Tool

1. **Create Tool Class**
   ```python
   # backend/app/tools/new_tool.py
   from .base_tool import BaseTool
   
   class NewTool(BaseTool):
       def __init__(self, config: dict):
           super().__init__(config)
           self.name = "new_tool"
           self.description = "Description of what this tool does"
       
       async def execute(self, **kwargs) -> dict:
           """Execute the tool with given parameters."""
           try:
               # Tool logic here
               result = await self._perform_operation(**kwargs)
               return {
                   "success": True,
                   "result": result
               }
           except Exception as e:
               return {
                   "success": False,
                   "error": str(e)
               }
       
       async def _perform_operation(self, **kwargs) -> Any:
           """Internal implementation."""
           pass
   ```

2. **Register Tool in Agent**
   ```python
   # backend/app/agents/chat_agent.py
   from ..tools.new_tool import NewTool
   
   class CustomerSupportAgent:
       def __init__(self):
           self.tools = {
               "new_tool": NewTool(self.config.get("new_tool", {}))
           }
   ```

### Adding a New API Endpoint

1. **Create Route**
   ```python
   # backend/app/api/routes/new_endpoint.py
   from fastapi import APIRouter, HTTPException, Depends
   from ...models.schemas import RequestModel, ResponseModel
   from ...api.dependencies import get_current_user
   
   router = APIRouter()
   
   @router.post("/new-endpoint", response_model=ResponseModel)
   async def create_resource(
       request: RequestModel,
       current_user = Depends(get_current_user)
   ):
       try:
           # Business logic here
           result = await some_service.process(request)
           return ResponseModel(success=True, data=result)
       except Exception as e:
           raise HTTPException(status_code=400, detail=str(e))
   ```

2. **Register Route**
   ```python
   # backend/app/main.py
   from .api.routes.new_endpoint import router as new_endpoint_router
   
   app.include_router(new_endpoint_router, prefix="/api/v1", tags=["new-endpoint"])
   ```

### Adding a New Frontend Component

1. **Create Component**
   ```typescript
   // frontend/src/components/NewComponent.tsx
   import React from 'react';
   
   interface NewComponentProps {
     title: string;
     onAction?: () => void;
   }
   
   export const NewComponent: React.FC<NewComponentProps> = ({
     title,
     onAction
   }) => {
     return (
       <div className="new-component">
         <h2>{title}</h2>
         {onAction && (
           <button onClick={onAction}>
             Action
           </button>
         )}
       </div>
     );
   };
   ```

2. **Add Component to Storybook (Optional)**
   ```typescript
   // frontend/src/components/NewComponent.stories.tsx
   import { Meta, StoryObj } from '@storybook/react';
   import { NewComponent } from './NewComponent';
   
   const meta: Meta<typeof NewComponent> = {
     title: 'Components/NewComponent',
     component: NewComponent,
   };
   
   export default meta;
   type Story = StoryObj<typeof meta>;
   
   export const Default: Story = {
     args: {
       title: 'Hello World',
     },
   };
   ```

### Database Migrations

1. **Create Migration**
   ```bash
   cd backend
   alembic revision --autogenerate -m "Add new table"
   ```

2. **Edit Migration**
   ```python
   # backend/alembic/versions/xxx_add_new_table.py
   def upgrade():
       op.create_table('new_table',
           sa.Column('id', sa.String(), nullable=False),
           sa.Column('name', sa.String(255), nullable=False),
           sa.PrimaryKeyConstraint('id')
       )
   
   def downgrade():
       op.drop_table('new_table')
   ```

3. **Run Migration**
   ```bash
   alembic upgrade head
   ```

### Adding Tests

1. **Unit Test**
   ```python
   # backend/tests/unit/test_new_feature.py
   import pytest
   from app.services.new_service import NewService
   
   class TestNewService:
       @pytest.fixture
       def service(self):
           return NewService()
       
       def test_new_method(self, service):
           # Test implementation
           result = service.new_method("test_input")
           assert result == expected_output
   ```

2. **Integration Test**
   ```python
   # backend/tests/integration/test_new_api.py
   from fastapi.testclient import TestClient
   from app.main import app
   
   class TestNewAPI:
       def setup_method(self):
           self.client = TestClient(app)
       
       def test_new_endpoint(self):
           response = self.client.post("/api/v1/new-endpoint", json={
               "field": "value"
           })
           assert response.status_code == 201
   ```

---

## Development Best Practices

### Code Quality

1. **Linting and Formatting**
   ```bash
   # Backend
   cd backend
   black .                    # Format code
   isort .                   # Sort imports
   flake8 .                  # Lint code
   mypy app/                 # Type checking
   
   # Frontend
   cd frontend
   npm run lint              # ESLint
   npm run format            # Prettier
   npm run type-check        # TypeScript check
   ```

2. **Pre-commit Hooks**
   ```yaml
   # .pre-commit-config.yaml
   repos:
     - repo: https://github.com/pre-commit/pre-commit-hooks
       rev: v4.4.0
       hooks:
         - id: trailing-whitespace
         - id: end-of-file-fixer
         - id: check-yaml
     
     - repo: https://github.com/psf/black
       rev: 23.3.0
       hooks:
         - id: black
           language_version: python3.11
     
     - repo: https://github.com/pycqa/isort
       rev: 5.12.0
       hooks:
         - id: isort
   ```

### Documentation

1. **Code Documentation**
   - Write docstrings for all public functions
   - Add JSDoc comments for TypeScript
   - Include usage examples in docstrings
   - Document complex algorithms

2. **API Documentation**
   - Use FastAPI's automatic API documentation
   - Include request/response examples
   - Document error conditions
   - Add OpenAPI annotations

### Security

1. **Input Validation**
   ```python
   from pydantic import BaseModel, validator
   
   class ChatMessageRequest(BaseModel):
       message: str
       session_id: str
       
       @validator('message')
       def message_must_not_be_empty(cls, v):
           if not v.strip():
               raise ValueError('Message cannot be empty')
           return v
       
       @validator('message')
       def message_must_be_reasonable_length(cls, v):
           if len(v) > 1000:
               raise ValueError('Message too long')
           return v
   ```

2. **Authentication**
   ```python
   from fastapi import Depends, HTTPException, status
   from fastapi.security import HTTPBearer
   
   security = HTTPBearer()
   
   def get_current_user(token: str = Depends(security)):
       try:
           payload = jwt.decode(token.credentials, SECRET_KEY, algorithms=["HS256"])
           user_id: str = payload.get("sub")
           if user_id is None:
               raise HTTPException(
                   status_code=status.HTTP_401_UNAUTHORIZED,
                   detail="Invalid authentication credentials"
               )
           return user_id
       except JWTError:
           raise HTTPException(
               status_code=status.HTTP_401_UNAUTHORIZED,
               detail="Invalid authentication credentials"
           )
   ```

### Performance Monitoring

1. **Add Metrics**
   ```python
   from prometheus_client import Counter, Histogram, Gauge
   
   # Define metrics
   chat_requests_total = Counter(
       'chat_requests_total',
       'Total chat requests',
       ['endpoint', 'status_code']
   )
   
   chat_response_time = Histogram(
       'chat_response_duration_seconds',
       'Chat response time in seconds'
   )
   
   active_sessions = Gauge(
       'active_sessions_total',
       'Number of active sessions'
   )
   
   # Use metrics
   @app.middleware("http")
   async def metrics_middleware(request: Request, call_next):
       start_time = time.time()
       
       response = await call_next(request)
       
       # Record metrics
       chat_requests_total.labels(
           endpoint=request.url.path,
           status_code=response.status_code
       ).inc()
       
       process_time = time.time() - start_time
       chat_response_time.observe(process_time)
       
       return response
   ```

2. **Profile Performance**
   ```python
   import cProfile
   import pstats
   
   def profile_function():
       profiler = cProfile.Profile()
       profiler.enable()
       
       # Function to profile
       expensive_operation()
       
       profiler.disable()
       
       stats = pstats.Stats(profiler)
       stats.sort_stats('cumulative')
       stats.print_stats(10)  # Top 10 functions
   ```

---

This development guide provides a comprehensive foundation for developers working on the Customer Support AI Agent. Follow these guidelines to maintain code quality, ensure reliability, and streamline the development process.
