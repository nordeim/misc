# 🔧 Troubleshooting Guide

This comprehensive troubleshooting guide helps you diagnose and resolve common issues with the Customer Support AI Agent.

## Table of Contents

- [Quick Diagnosis](#quick-diagnosis)
- [Common Issues](#common-issues)
- [Backend Issues](#backend-issues)
- [Frontend Issues](#frontend-issues)
- [Database Issues](#database-issues)
- [Performance Issues](#performance-issues)
- [Security Issues](#security-issues)
- [Deployment Issues](#deployment-issues)
- [Monitoring and Logs](#monitoring-and-logs)
- [Debug Commands](#debug-commands)
- [FAQ](#faq)

---

## Quick Diagnosis

### Health Check Commands

```bash
# Quick health check
curl http://localhost:8000/health

# Detailed health check
curl http://localhost:8000/health/detailed

# Check all services
docker-compose ps

# Check service logs
docker-compose logs backend --tail=50
```

### System Status Check

```bash
# Check system resources
docker stats --no-stream

# Check disk space
df -h

# Check memory usage
free -h

# Check network connectivity
ping google.com

# Check DNS resolution
nslookup api.openai.com
```

### Service Dependencies

```bash
# Test database connection
docker-compose exec backend python -c "
from app.database import engine
with engine.connect() as conn:
    result = conn.execute('SELECT 1')
    print('✅ Database: OK')
"

# Test Redis connection
docker-compose exec backend python -c "
import redis
try:
    r = redis.from_url('redis://redis:6379')
    r.ping()
    print('✅ Redis: OK')
except Exception as e:
    print(f'❌ Redis: {e}')
"

# Test ChromaDB connection
docker-compose exec backend python -c "
import chromadb
try:
    client = chromadb.Client()
    collections = client.list_collections()
    print(f'✅ ChromaDB: OK (collections: {len(collections)})')
except Exception as e:
    print(f'❌ ChromaDB: {e}')
"
```

---

## Common Issues

### 🔴 Issue: Application Won't Start

#### Symptoms
- Backend service exits immediately
- Error messages in logs
- Port already in use errors

#### Diagnosis
```bash
# Check if port is already in use
lsof -i :8000

# Check service logs
docker-compose logs backend

# Check environment variables
docker-compose exec backend env | grep -E "(DATABASE|REDIS|OPENAI)"
```

#### Solutions

**Port Conflict:**
```bash
# Kill process using the port
sudo lsof -ti:8000 | xargs sudo kill -9

# Or change port in docker-compose.yml
# backend:
#   ports:
#     - "8001:8000"  # Change to different port
```

**Missing Environment Variables:**
```bash
# Check .env file exists
ls -la .env

# Copy from example if missing
cp .env.example .env

# Edit with your values
nano .env
```

**Database Connection Error:**
```bash
# Start database first
docker-compose up -d postgres

# Wait for database to be ready
sleep 10

# Check database logs
docker-compose logs postgres

# Run migrations
docker-compose exec backend alembic upgrade head
```

### 🟡 Issue: Slow Response Times

#### Symptoms
- Chat responses take >5 seconds
- High latency in API calls
- Timeout errors

#### Diagnosis
```bash
# Check response times
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:8000/health

# Check system resources
docker stats --no-stream

# Check database performance
docker-compose exec postgres psql -U postgres -d customer_support -c "
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
"

# Check Redis performance
docker-compose exec redis redis-cli info stats | grep -E "instantaneous_ops_per_sec|keyspace_hits|keyspace_misses"
```

#### Solutions

**Enable Caching:**
```python
# In config.py
ENABLE_CACHING = True
CACHE_TTL = 3600  # Cache for 1 hour
```

**Optimize Database:**
```sql
-- Add indexes
CREATE INDEX CONCURRENTLY idx_messages_session_created 
ON messages(session_id, created_at);

CREATE INDEX CONCURRENTLY idx_memories_session_timestamp 
ON memories(session_id, timestamp DESC);
```

**Scale Resources:**
```yaml
# docker-compose.yml
services:
  backend:
    deploy:
      resources:
        limits:
          memory: 2G
          cpus: '2.0'
```

### 🔵 Issue: WebSocket Disconnections

#### Symptoms
- Real-time chat stops working
- Connection timeout errors
- WebSocket handshake failures

#### Diagnosis
```bash
# Check WebSocket endpoint
curl -i -N -H "Connection: Upgrade" \
     -H "Upgrade: websocket" \
     -H "Sec-WebSocket-Key: SGVsbG8sIHdvcmxkIQ==" \
     -H "Sec-WebSocket-Version: 13" \
     http://localhost:8000/ws/test

# Check nginx configuration
docker-compose exec nginx nginx -t

# Check CORS settings
curl -H "Origin: http://localhost:3000" http://localhost:8000/health
```

#### Solutions

**Fix CORS Configuration:**
```python
# In config.py
CORS_ORIGINS = [
    "http://localhost:3000",
    "https://yourdomain.com"
]

# In main.py
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**Update Nginx Configuration:**
```nginx
# /etc/nginx/sites-available/customer-support
location /ws/ {
    proxy_pass http://backend;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 86400;
}
```

### 🟠 Issue: File Upload Failures

#### Symptoms
- Files not uploading
- "File too large" errors
- Processing timeouts

#### Diagnosis
```bash
# Check file size limits
docker-compose exec backend python -c "
import os
print('Max file size:', os.environ.get('MAX_FILE_SIZE', '10MB'))
"

# Check disk space
df -h ./uploads

# Check supported formats
curl -X POST -F "file=@test.txt" http://localhost:8000/api/files -v
```

#### Solutions

**Increase File Size Limit:**
```python
# In config.py
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_FILE_TYPES = [
    "pdf", "doc", "docx", "txt", 
    "jpg", "jpeg", "png", "gif", "bmp"
]
```

**Check Disk Space:**
```bash
# Clean up old files
find ./uploads -type f -mtime +30 -delete

# Monitor disk usage
watch df -h
```

### 🟣 Issue: Authentication Problems

#### Symptoms
- "Invalid token" errors
- Login failures
- Permission denied messages

#### Diagnosis
```bash
# Test token creation
curl -X POST http://localhost:8000/auth/token \
  -H "Content-Type: application/json" \
  -d '{"username": "test", "password": "test"}'

# Check JWT secret
docker-compose exec backend python -c "
from app.config import settings
print('JWT secret configured:', bool(settings.JWT_SECRET_KEY))
"

# Check user database
docker-compose exec postgres psql -U postgres -d customer_support -c "
SELECT username, created_at FROM users LIMIT 5;
"
```

#### Solutions

**Verify JWT Configuration:**
```python
# In config.py
JWT_SECRET_KEY = "your-256-bit-secret-key"
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# Generate a secure key
import secrets
print(secrets.token_urlsafe(32))
```

**Reset User Password:**
```bash
# Via database
docker-compose exec postgres psql -U postgres -d customer_support -c "
UPDATE users SET password_hash = crypt('newpassword', gen_salt('bf')) WHERE username = 'testuser';
"
```

---

## Backend Issues

### Startup Problems

#### Database Migration Errors

**Error: "Table doesn't exist"**
```bash
# Run migrations
docker-compose exec backend alembic upgrade head

# Check migration status
docker-compose exec backend alembic current
docker-compose exec backend alembic history

# Recreate database if needed
docker-compose down -v
docker-compose up -d postgres
sleep 10
docker-compose exec backend alembic upgrade head
```

**Error: "Connection refused"**
```bash
# Wait for database to be ready
until docker-compose exec postgres pg_isready -U postgres; do
  echo "Waiting for database..."
  sleep 2
done

# Check database logs
docker-compose logs postgres
```

#### Import Errors

**Error: "ModuleNotFoundError"**
```bash
# Check Python path
docker-compose exec backend python -c "
import sys
print('Python path:', sys.path)
"

# Check if all dependencies are installed
docker-compose exec backend pip list

# Rebuild backend image
docker-compose build --no-cache backend
```

#### Configuration Errors

**Error: "Invalid environment variable"**
```bash
# Check environment variables
docker-compose exec backend env | sort

# Validate config
docker-compose exec backend python -c "
from app.config import settings
print('Config validation:', settings.dict())
"
```

### Runtime Issues

#### Memory Leaks

**Diagnosis:**
```bash
# Monitor memory usage over time
docker stats --no-stream

# Check for memory leaks in logs
docker-compose logs backend | grep -i "memory\|oom"

# Analyze memory usage
docker-compose exec backend python -c "
import tracemalloc
tracemalloc.start()

# Your code here - simulate load
import asyncio
from app.agents.chat_agent import CustomerSupportAgent

async def test_memory():
    agent = CustomerSupportAgent()
    for i in range(100):
        await agent.process_message('test message')

asyncio.run(test_memory())

current, peak = tracemalloc.get_traced_memory()
print(f'Current memory: {current / 1024 / 1024:.1f} MB')
print(f'Peak memory: {peak / 1024 / 1024:.1f} MB')
"
```

**Solutions:**
```python
# Add memory monitoring
import psutil
import logging

@app.middleware("http")
async def memory_middleware(request: Request, call_next):
    process = psutil.Process()
    memory_mb = process.memory_info().rss / 1024 / 1024
    
    if memory_mb > 1000:  # 1GB threshold
        logging.warning(f"High memory usage: {memory_mb:.1f} MB")
    
    response = await call_next(request)
    return response

# Configure garbage collection
import gc
gc.set_threshold(700, 10, 10)  # More frequent GC
```

#### Thread/Async Issues

**Deadlocks:**
```python
# Use proper async patterns
import asyncio

# Bad: Blocking call in async
async def bad_example():
    time.sleep(1)  # Blocks event loop!

# Good: Async alternative
async def good_example():
    await asyncio.sleep(1)

# Use asyncio.gather for concurrent operations
async def concurrent_operations():
    task1 = async_operation_1()
    task2 = async_operation_2()
    results = await asyncio.gather(task1, task2)
    return results
```

**Resource Exhaustion:**
```python
# Limit concurrent operations
import asyncio
from asyncio import Semaphore

# Limit to 10 concurrent operations
semaphore = Semaphore(10)

async def limited_operation():
    async with semaphore:
        await expensive_operation()

# Use connection pooling
from sqlalchemy.pool import QueuePool

engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,
    max_overflow=30,
    pool_timeout=30
)
```

---

## Frontend Issues

### Build Problems

#### TypeScript Errors

**Error: "Property does not exist"**
```typescript
// Check type definitions
// src/types/api.ts
export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  sources?: Source[];
}

// Fix component
interface MessageProps {
  message: ChatMessage;  // Use proper type
}

const MessageComponent: React.FC<MessageProps> = ({ message }) => {
  return <div>{message.content}</div>;  // No error now
};
```

#### Dependency Issues

**Error: "Package conflicts"**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check for peer dependency issues
npm ls

# Update dependencies
npm update
```

### Runtime Issues

#### React Component Errors

**Error: "Cannot read property of undefined"**
```typescript
// Add null checks
const MessageList: React.FC<{ messages?: ChatMessage[] }> = ({ messages = [] }) => {
  return (
    <div>
      {messages.map(message => (
        <MessageItem key={message.id} message={message} />
      ))}
    </div>
  );
};

// Use optional chaining
const userName = user?.profile?.name ?? 'Unknown';
```

**Error: "Too many re-renders"**
```typescript
// Fix infinite re-render loops
const [count, setCount] = useState(0);

// Bad: Causes infinite loop
useEffect(() => {
  setCount(count + 1);  // Don't update state in useEffect without conditions
}, [count]);

// Good: Add dependencies and conditions
useEffect(() => {
  if (count < 10) {
    setCount(prevCount => prevCount + 1);
  }
}, [count]);
```

#### WebSocket Issues

**Connection Problems:**
```typescript
// Add connection retry logic
const useWebSocket = (sessionId: string) => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const maxReconnectAttempts = 5;

  const connect = useCallback(() => {
    const ws = new WebSocket(`${WS_URL}?session_id=${sessionId}`);
    
    ws.onopen = () => {
      setReconnectAttempts(0);
      setSocket(ws);
    };
    
    ws.onclose = () => {
      setSocket(null);
      
      if (reconnectAttempts < maxReconnectAttempts) {
        setTimeout(() => {
          setReconnectAttempts(prev => prev + 1);
          connect();
        }, 1000 * Math.pow(2, reconnectAttempts)); // Exponential backoff
      }
    };
    
    return ws;
  }, [sessionId, reconnectAttempts]);

  useEffect(() => {
    const ws = connect();
    setSocket(ws);
    
    return () => {
      ws.close();
    };
  }, [connect]);

  return socket;
};
```

---

## Database Issues

### PostgreSQL Problems

#### Connection Issues

**Error: "Connection refused"**
```bash
# Check PostgreSQL is running
docker-compose exec postgres pg_isready -U postgres

# Check connection string
docker-compose exec backend python -c "
from app.database import DATABASE_URL
print('Database URL:', DATABASE_URL)
"

# Test connection manually
docker-compose exec postgres psql -U postgres -d customer_support -c "SELECT 1;"
```

**Solution:**
```bash
# Restart PostgreSQL
docker-compose restart postgres

# Check PostgreSQL logs
docker-compose logs postgres

# Ensure database exists
docker-compose exec postgres psql -U postgres -c "CREATE DATABASE customer_support;"
```

#### Performance Issues

**Slow Queries:**
```sql
-- Enable query logging
ALTER SYSTEM SET log_statement = 'all';
ALTER SYSTEM SET log_min_duration_statement = 1000; -- Log queries > 1s
SELECT pg_reload_conf();

-- Check slow queries
SELECT query, calls, total_time, mean_time 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;

-- Check for missing indexes
SELECT schemaname, tablename, attname, n_distinct, correlation 
FROM pg_stats 
WHERE schemaname = 'public' 
ORDER BY tablename, attname;
```

**Index Optimization:**
```sql
-- Check index usage
SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read, idx_tup_fetch
FROM pg_stat_user_indexes
ORDER BY idx_scan DESC;

-- Create missing indexes
CREATE INDEX CONCURRENTLY idx_messages_session_created 
ON messages(session_id, created_at);

CREATE INDEX CONCURRENTLY idx_messages_role_timestamp 
ON messages(role, created_at);

-- Remove unused indexes
DROP INDEX CONCURRENTLY IF EXISTS idx_unused_index;
```

#### Data Issues

**Corrupted Data:**
```bash
# Check database integrity
docker-compose exec postgres psql -U postgres -d customer_support -c "
SELECT tablename, attname, null_frac, n_distinct, correlation 
FROM pg_stats 
WHERE schemaname = 'public';
"

# Vacuum and analyze
docker-compose exec postgres psql -U postgres -d customer_support -c "
VACUUM ANALYZE;
"
```

### Redis Issues

#### Memory Problems

**High Memory Usage:**
```bash
# Check Redis memory usage
docker-compose exec redis redis-cli info memory

# Check keyspace
docker-compose exec redis redis-cli --bigkeys

# Monitor memory over time
watch docker-compose exec redis redis-cli info memory
```

**Solutions:**
```bash
# Configure Redis maxmemory
docker-compose exec redis redis-cli config set maxmemory 512mb
docker-compose exec redis redis-cli config set maxmemory-policy allkeys-lru

# Clear cache if needed
docker-compose exec redis redis-cli flushall

# Check slow log
docker-compose exec redis redis-cli slowlog get 10
```

---

## Performance Issues

### Slow Response Times

#### API Latency

**Diagnosis:**
```bash
# Test API response times
for i in {1..10}; do
  curl -w "@curl-format.txt" -o /dev/null -s http://localhost:8000/health
done

# Check response times for different endpoints
curl -w "Session create: %{time_total}s\n" -o /dev/null -s -X POST http://localhost:8000/sessions
curl -w "Health check: %{time_total}s\n" -o /dev/null -s http://localhost:8000/health
```

**Solutions:**
```python
# Add response time monitoring
@app.middleware("http")
async def timing_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Use connection pooling
DATABASE_POOL_SIZE = 20
DATABASE_MAX_OVERFLOW = 30

# Enable query result caching
from functools import lru_cache

@lru_cache(maxsize=1000)
def get_cached_result(query_hash: str):
    # Expensive database query
    pass
```

#### Database Performance

**Slow Queries:**
```python
# Add query logging
import logging
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)

# Use database indexes
# Check slow queries in pg_stat_statements
# Optimize frequently executed queries
```

**Connection Pool Exhaustion:**
```python
# Monitor connection pool
with engine.connect() as conn:
    pool = engine.pool
    print(f"Pool size: {pool.size()}")
    print(f"Checked in: {pool.checkedin()}")
    print(f"Checked out: {pool.checkedout()}")
    print(f"Overflow: {pool.overflow()}")
```

### High CPU Usage

**Diagnosis:**
```bash
# Check CPU usage
top -p $(pgrep -f "uvicorn.*main:app")

# Check Python CPU profiling
docker-compose exec backend python -c "
import cProfile
import pstats
profiler = cProfile.Profile()
profiler.enable()
# Run your code here
profiler.disable()
stats = pstats.Stats(profiler)
stats.sort_stats('cumulative')
stats.print_stats(10)
"
```

**Solutions:**
```python
# Optimize CPU-intensive operations
import asyncio
from concurrent.futures import ThreadPoolExecutor

# Use threads for CPU-bound tasks
executor = ThreadPoolExecutor(max_workers=4)

async def cpu_intensive_task():
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, heavy_computation)
    return result

# Use async for I/O operations
async def io_operations():
    await asyncio.gather(
        database_query(),
        redis_get(),
        external_api_call()
    )
```

### High Memory Usage

**Diagnosis:**
```bash
# Monitor memory usage
docker stats --no-stream

# Check for memory leaks
docker-compose exec backend python -c "
import tracemalloc
tracemalloc.start()

# Your code here

current, peak = tracemalloc.get_traced_memory()
print(f'Current: {current / 1024 / 1024:.1f} MB')
print(f'Peak: {peak / 1024 / 1024:.1f} MB')
"
```

**Solutions:**
```python
# Use generators for large datasets
def process_large_dataset():
    for item in large_dataset:
        yield process_item(item)

# Implement proper cleanup
import contextlib

@contextlib.contextmanager
def resource_management():
    resource = acquire_resource()
    try:
        yield resource
    finally:
        release_resource(resource)

# Monitor memory usage
import psutil
import logging

def check_memory_usage():
    process = psutil.Process()
    memory_mb = process.memory_info().rss / 1024 / 1024
    
    if memory_mb > 1000:
        logging.warning(f"High memory usage: {memory_mb:.1f} MB")
    
    return memory_mb
```

---

## Security Issues

### Authentication Problems

#### JWT Issues

**Invalid Tokens:**
```python
# Check JWT configuration
from jose import jwt
import os

SECRET_KEY = os.getenv('JWT_SECRET_KEY')
ALGORITHM = 'HS256'

def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
```

**Token Expiration:**
```python
# Configure token expiration
from datetime import datetime, timedelta

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(hours=24)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
```

#### Rate Limiting Issues

**False Positives:**
```python
# Configure rate limiting properly
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)

@app.post("/api/chat/messages")
@limiter.limit("30/minute")
async def send_message(request: Request):
    # Your endpoint logic
    pass

# Handle rate limit exceeded
@app.exception_handler(RateLimitExceeded)
async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"detail": "Rate limit exceeded"}
    )
```

### Input Validation

**SQL Injection Prevention:**
```python
# Use SQLAlchemy ORM (already protected)
from sqlalchemy.orm import Session

def get_user_by_id(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()

# Never use string concatenation for queries
# Bad: query = f"SELECT * FROM users WHERE id = {user_id}"
# Good: Use ORM or parameterized queries
```

**XSS Prevention:**
```python
# Sanitize HTML input
import bleach

def sanitize_html(text: str) -> str:
    allowed_tags = ['b', 'i', 'em', 'strong']
    return bleach.clean(text, tags=allowed_tags, strip=True)

# Use Content Security Policy
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response
```

---

## Deployment Issues

### Docker Issues

#### Build Failures

**Error: "No space left on device"**
```bash
# Clean up Docker
docker system prune -a

# Remove unused volumes
docker volume prune

# Remove unused images
docker image prune -a

# Check disk space
df -h
```

**Error: "Permission denied"**
```bash
# Fix file permissions
sudo chown -R $USER:$USER .

# Make scripts executable
chmod +x scripts/*.sh

# Fix Docker socket permissions
sudo chmod 666 /var/run/docker.sock
```

#### Container Issues

**Container Won't Start:**
```bash
# Check container logs
docker-compose logs container_name

# Inspect container state
docker inspect container_name

# Check resource limits
docker stats

# Restart with verbose output
docker-compose up --no-deps container_name --verbose
```

**Networking Issues:**
```bash
# Check Docker networks
docker network ls
docker network inspect network_name

# Test connectivity between containers
docker-compose exec backend ping postgres
docker-compose exec backend nc -zv postgres 5432
```

### Kubernetes Issues

#### Pod Startup Issues

**Error: "ImagePullBackOff"**
```yaml
# Fix image pull policy
apiVersion: v1
kind: Pod
metadata:
  name: backend
spec:
  containers:
  - name: backend
    image: your-registry/image:tag
    imagePullPolicy: IfNotPresent  # Or Always
```

**Error: "CrashLoopBackOff"**
```bash
# Check pod logs
kubectl logs pod-name --previous

# Check pod events
kubectl describe pod pod-name

# Check resource limits
kubectl top pod pod-name
```

#### Service Issues

**Error: "Service not available"**
```bash
# Check service endpoints
kubectl get endpoints service-name

# Check service selector
kubectl get svc service-name -o yaml

# Test service connectivity
kubectl run test-pod --image=busybox --rm -it -- wget -qO- service-name:port
```

---

## Monitoring and Logs

### Log Analysis

#### Centralized Logging

**Docker Logs:**
```bash
# View logs from all services
docker-compose logs

# Follow logs in real-time
docker-compose logs -f

# View logs from specific service
docker-compose logs -f backend

# Search for errors in logs
docker-compose logs backend | grep -i error

# Export logs to file
docker-compose logs backend > backend.log
```

**Application Logs:**
```bash
# Check application logs
tail -f logs/app.log

# Search for specific patterns
grep -r "ERROR" logs/

# Monitor log file growth
watch -n 5 'ls -lh logs/*.log'
```

#### Log Analysis Tools

**ELK Stack Setup:**
```yaml
# docker-compose.logging.yml
version: '3.8'

services:
  elasticsearch:
    image: elasticsearch:7.14.0
    environment:
      - discovery.type=single-node
    volumes:
      - elasticsearch_data:/usr/share/elasticsearch/data

  kibana:
    image: kibana:7.14.0
    ports:
      - "5601:5601"
    depends_on:
      - elasticsearch

volumes:
  elasticsearch_data:
```

**Log Analysis Commands:**
```bash
# Count error types
grep -r "ERROR" logs/ | awk '{print $4}' | sort | uniq -c | sort -nr

# Find slow requests
grep "duration=" logs/app.log | awk -F'duration=' '{print $2}' | awk '{print $1}' | sort -nr | head -20

# Monitor error rate
watch "grep -c 'ERROR' logs/app.log"
```

### Metrics Collection

#### Prometheus Metrics

**Custom Metrics:**
```python
from prometheus_client import Counter, Histogram, Gauge

# Define metrics
request_count = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint'])
request_duration = Histogram('http_request_duration_seconds', 'HTTP request duration')
active_sessions = Gauge('active_sessions_total', 'Number of active sessions')

# Use metrics
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    
    response = await call_next(request)
    
    request_count.labels(
        method=request.method,
        endpoint=request.url.path
    ).inc()
    
    request_duration.observe(time.time() - start_time)
    
    return response
```

**Grafana Dashboard:**
```json
{
  "dashboard": {
    "title": "Customer Support AI Agent",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          }
        ]
      }
    ]
  }
}
```

---

## Debug Commands

### System Diagnostics

#### Quick Health Check
```bash
#!/bin/bash
# scripts/health-check.sh

echo "🔍 Customer Support AI Agent - Health Check"
echo "============================================"

# Check Docker services
echo "📦 Docker Services:"
docker-compose ps

echo -e "\n🌐 Network Check:"
curl -s http://localhost:8000/health > /dev/null && echo "✅ Backend: OK" || echo "❌ Backend: FAILED"
curl -s http://localhost:3000 > /dev/null && echo "✅ Frontend: OK" || echo "❌ Frontend: FAILED"

echo -e "\n🗄️ Database Check:"
docker-compose exec -T postgres pg_isready -U postgres > /dev/null && echo "✅ PostgreSQL: OK" || echo "❌ PostgreSQL: FAILED"

echo -e "\n💾 Cache Check:"
docker-compose exec -T redis redis-cli ping > /dev/null && echo "✅ Redis: OK" || echo "❌ Redis: FAILED"

echo -e "\n🔍 Vector DB Check:"
curl -s http://localhost:8001/api/v1/heartbeat > /dev/null && echo "✅ ChromaDB: OK" || echo "❌ ChromaDB: FAILED"

echo -e "\n📊 Resource Usage:"
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"

echo -e "\n✅ Health check completed!"
```

#### Performance Test
```bash
#!/bin/bash
# scripts/performance-test.sh

echo "🚀 Performance Test"
echo "==================="

# Test API response time
echo "📡 API Response Time Test:"
for i in {1..10}; do
  response_time=$(curl -w "%{time_total}" -o /dev/null -s http://localhost:8000/health)
  echo "Request $i: ${response_time}s"
done

# Test concurrent requests
echo -e "\n⚡ Concurrent Request Test:"
for i in {1..20}; do
  curl -s http://localhost:8000/health > /dev/null &
done
wait
echo "20 concurrent requests completed"

# Test database performance
echo -e "\n🗄️ Database Performance:"
docker-compose exec -T postgres psql -U postgres -d customer_support -c "
SELECT 
  schemaname,
  tablename,
  seq_scan,
  seq_tup_read,
  idx_scan,
  idx_tup_fetch
FROM pg_stat_user_tables 
ORDER BY seq_scan DESC 
LIMIT 5;
"
```

### Database Diagnostics

#### Check Database Health
```bash
#!/bin/bash
# scripts/db-health.sh

echo "🗄️ Database Health Check"
echo "========================="

# Connection count
echo "📊 Connection Statistics:"
docker-compose exec -T postgres psql -U postgres -d customer_support -c "
SELECT 
  count(*) as total_connections,
  count(*) FILTER (WHERE state = 'active') as active_connections,
  count(*) FILTER (WHERE state = 'idle') as idle_connections
FROM pg_stat_activity;
"

# Table sizes
echo -e "\n📏 Table Sizes:"
docker-compose exec -T postgres psql -U postgres -d customer_support -c "
SELECT 
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
"

# Index usage
echo -e "\n📇 Index Usage:"
docker-compose exec -T postgres psql -U postgres -d customer_support -c "
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan,
  idx_tup_read,
  idx_tup_fetch
FROM pg_stat_user_indexes
ORDER BY idx_scan DESC
LIMIT 10;
"

# Slow queries
echo -e "\n🐌 Slow Queries:"
docker-compose exec -T postgres psql -U postgres -d customer_support -c "
SELECT 
  query,
  calls,
  total_time,
  mean_time,
  rows
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 5;
"
```

### Application Diagnostics

#### Check Application State
```bash
#!/bin/bash
# scripts/app-state.sh

echo "🤖 Application State Check"
echo "=========================="

# Session statistics
echo "💬 Session Statistics:"
docker-compose exec -T backend python -c "
from app.database import SessionLocal
from app.models import Session, Message

db = SessionLocal()
total_sessions = db.query(Session).count()
active_sessions = db.query(Session).filter(Session.status == 'active').count()
total_messages = db.query(Message).count()
db.close()
print(f'Total Sessions: {total_sessions}')
print(f'Active Sessions: {active_sessions}')
print(f'Total Messages: {total_messages}')
"

# Memory usage
echo -e "\n💾 Memory Usage:"
docker-compose exec -T backend python -c "
import psutil
import os
process = psutil.Process(os.getpid())
print(f'Process Memory: {process.memory_info().rss / 1024 / 1024:.1f} MB')
print(f'CPU Percent: {process.cpu_percent():.1f}%')
"

# Cache statistics
echo -e "\n💾 Cache Statistics:"
docker-compose exec -T backend python -c "
import redis
try:
    r = redis.from_url('redis://redis:6379')
    info = r.info('memory')
    print(f'Redis Memory: {info[\"used_memory_human\"]}')
    print(f'Connected Clients: {info[\"connected_clients\"]}')
    print(f'Total Commands Processed: {info[\"total_commands_processed\"]}')
except Exception as e:
    print(f'Redis Error: {e}')
"

# Vector database statistics
echo -e "\n🔍 Vector Database:"
docker-compose exec -T backend python -c "
import chromadb
try:
    client = chromadb.Client()
    collections = client.list_collections()
    print(f'Collections: {len(collections)}')
    for collection in collections[:5]:
        count = collection.count()
        print(f'  {collection.name}: {count} documents')
except Exception as e:
    print(f'ChromaDB Error: {e}')
"
```

---

## FAQ

### General Questions

**Q: How do I reset the entire system?**
A: 
```bash
# Stop all services
docker-compose down

# Remove volumes (WARNING: This deletes all data)
docker-compose down -v

# Start fresh
docker-compose up -d

# Run migrations
docker-compose exec backend alembic upgrade head

# Seed data (optional)
docker-compose exec backend python scripts/seed_data.py
```

**Q: How do I backup my data?**
A:
```bash
# Backup database
docker-compose exec postgres pg_dump -U postgres customer_support > backup_$(date +%Y%m%d).sql

# Backup Redis data
docker cp customer-support_redis_1:/data/dump.rdb redis_backup_$(date +%Y%m%d).rdb

# Backup ChromaDB
tar -czf chromadb_backup_$(date +%Y%m%d).tar.gz ./data/chromadb/

# Backup uploaded files
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz ./uploads/
```

**Q: How do I scale the application?**
A:
```bash
# Scale backend instances
docker-compose up -d --scale backend=3

# Or use Kubernetes
kubectl scale deployment backend --replicas=5

# For load balancing, configure nginx upstream
# See deployment guide for detailed instructions
```

### Development Questions

**Q: How do I add a new API endpoint?**
A:
1. Create the route in `backend/app/api/routes/`
2. Add the endpoint to `main.py`
3. Write tests in `backend/tests/`
4. Update API documentation

**Q: How do I debug a specific message?**
A:
```python
# Enable debug logging
import logging
logging.getLogger('app.agents.chat_agent').setLevel(logging.DEBUG)

# Or use the debug endpoint
response = client.chat.send_message(
    session_id=session_id,
    message="test message",
    context={"debug": True}
)
```

**Q: How do I test the WebSocket connection?**
A:
```javascript
// Simple WebSocket test
const ws = new WebSocket('ws://localhost:8000/ws?session_id=test');

ws.onopen = () => {
  console.log('Connected!');
  ws.send(JSON.stringify({
    type: 'message',
    content: 'test message'
  }));
};

ws.onmessage = (event) => {
  console.log('Received:', event.data);
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};
```

### Production Questions

**Q: How do I monitor the application in production?**
A:
1. Set up Prometheus + Grafana (see monitoring section)
2. Configure log aggregation (ELK stack)
3. Set up alerting rules
4. Monitor key metrics: response time, error rate, resource usage

**Q: How do I handle high traffic?**
A:
1. Scale horizontally (multiple backend instances)
2. Use a load balancer (nginx, ALB, etc.)
3. Enable caching (Redis)
4. Optimize database queries
5. Consider CDN for static assets

**Q: How do I implement custom authentication?**
A:
```python
# Extend the auth service
from app.services.auth_service import AuthService

class CustomAuthService(AuthService):
    async def authenticate_user(self, credentials):
        # Custom authentication logic
        pass
    
    async def get_user_permissions(self, user_id):
        # Custom permission logic
        pass

# Register the custom service
auth_service = CustomAuthService()
```

For more specific issues or questions not covered here, please:
1. Check the logs: `docker-compose logs`
2. Review the health endpoints: `/health` and `/health/detailed`
3. Consult the API documentation: `/docs`
4. Search existing issues in the project repository
5. Create a new issue with detailed information about your problem

Remember to include:
- Error messages and logs
- Steps to reproduce the issue
- Environment details (OS, Docker version, etc.)
- Configuration details (if relevant)
