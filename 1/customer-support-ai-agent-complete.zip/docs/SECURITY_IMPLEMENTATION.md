# Security and CORS Configuration

This document describes the comprehensive security implementation for the Customer Support AI Agent backend, including authentication, authorization, input validation, rate limiting, and CORS configuration.

## Overview

The security implementation follows OWASP guidelines and industry best practices to provide a robust security framework:

- **Authentication**: JWT-based authentication with refresh tokens
- **Authorization**: Role-based access control (RBAC) with fine-grained permissions
- **Input Validation**: Comprehensive input sanitization and validation
- **Rate Limiting**: Advanced rate limiting with multiple strategies
- **Security Headers**: Complete set of security headers (HSTS, CSP, etc.)
- **CORS**: Secure cross-origin resource sharing configuration
- **Audit Logging**: Security event logging and monitoring

## Security Features

### 1. Authentication System (`/app/security/`)

#### JWT Authentication (`auth.py`)
- **JWT Token Generation**: Secure token creation with configurable expiration
- **Token Refresh**: Automatic token rotation and refresh mechanism
- **User Management**: User creation, validation, and session management
- **Account Security**: Account lockout after failed attempts
- **Session Tracking**: Last login tracking and session management

#### Password Security (`password_utils.py`)
- **Password Hashing**: Bcrypt with configurable cost factors
- **Strength Validation**: Comprehensive password complexity checking
- **Secure Generation**: Cryptographically secure random password generation
- **History Checking**: Prevention of password reuse

#### Token Management (`token_utils.py`)
- **Token Pairs**: Access and refresh token management
- **Token Blacklisting**: Revoked token tracking
- **Token Types**: Support for access, refresh, reset, and verification tokens
- **Token Validation**: Comprehensive token verification and decoding

#### Role-Based Access Control (`permissions.py`)
- **Permission System**: Fine-grained permission management
- **Role Hierarchy**: Predefined roles (Guest, User, Premium, Moderator, Admin, Super Admin)
- **Resource Permissions**: Resource-based access control
- **Permission Checking**: Runtime permission validation

#### Encryption (`encryption_utils.py`)
- **Symmetric Encryption**: AES encryption with Fernet
- **Asymmetric Encryption**: RSA key pair generation and management
- **Key Management**: Secure key derivation and management
- **Hash Functions**: Secure hashing with salt and HMAC support

### 2. Security Middleware (`/app/middleware/`)

#### Security Headers Middleware
```python
# Adds comprehensive security headers
- Strict-Transport-Security (HSTS)
- Content-Security-Policy (CSP)
- X-Frame-Options (Clickjacking protection)
- X-Content-Type-Options (MIME sniffing protection)
- X-XSS-Protection (XSS filtering)
- Referrer-Policy
- Permissions-Policy
```

#### JWT Authentication Middleware
```python
# Automatic JWT token validation
- Token extraction from Authorization header
- JWT signature verification
- Token expiration checking
- User context injection
```

#### Input Validation Middleware
```python
# Comprehensive input sanitization
- SQL injection detection
- XSS pattern detection
- Command injection prevention
- Path traversal protection
- Request size limits
```

#### Rate Limiting Middleware
```python
# Multiple rate limiting strategies
- Sliding window rate limiting
- Token bucket algorithm
- Distributed rate limiting (Redis)
- Adaptive rate limiting
- IP-based and user-based limiting
```

#### IP Allowlisting
```python
# IP-based access control
- Configurable IP allowlists
- Development vs production rules
- Proxy header trust configuration
```

### 3. Authentication API Endpoints (`/app/api/routes/auth.py`)

#### User Authentication
```http
POST /auth/login
Content-Type: application/json

{
  "username": "user@example.com",
  "password": "secure_password"
}

# Returns: JWT access token, refresh token, user info
```

#### User Registration
```http
POST /auth/register
Content-Type: application/json

{
  "username": "newuser",
  "email": "user@example.com",
  "password": "secure_password",
  "confirm_password": "secure_password"
}

# Returns: User information with verification status
```

#### Token Refresh
```http
POST /auth/refresh
Content-Type: application/json

{
  "refresh_token": "refresh_token_here"
}

# Returns: New access token
```

#### Logout
```http
POST /auth/logout
Authorization: Bearer <access_token>

# Returns: Success message
```

#### Password Management
```http
# Request password reset
POST /auth/reset-password
Content-Type: application/json

{
  "email": "user@example.com"
}

# Confirm password reset
POST /auth/reset-password/confirm
Content-Type: application/json

{
  "token": "reset_token",
  "new_password": "new_secure_password",
  "confirm_password": "new_secure_password"
}

# Change password (authenticated)
POST /auth/change-password
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "current_password": "current_password",
  "new_password": "new_secure_password",
  "confirm_password": "new_secure_password"
}
```

#### User Information
```http
# Get current user info
GET /auth/me
Authorization: Bearer <access_token>

# Returns: Current user information
```

#### Password Validation
```http
# Validate password strength
GET /auth/validate-password?password=test123&username=user&email=user@example.com

# Generate secure password
POST /auth/generate-password

# Returns: Secure random password
```

### 4. Advanced Rate Limiting (`/app/security/rate_limiter.py`)

#### Rate Limit Strategies
- **Sliding Window**: Time-based window with request counting
- **Token Bucket**: Token-based rate limiting with burst allowance
- **Distributed**: Redis-backed distributed rate limiting
- **Adaptive**: Dynamic rate limits based on user behavior

#### Configuration Examples
```python
# Default rate limits
default_rule = RateLimitRule(
    name="default",
    limit=100,  # requests
    window=60,  # seconds
    strategy=RateLimitStrategy.SLIDING_WINDOW,
    burst_limit=20  # burst allowance
)

# Authentication endpoint limits
auth_rule = RateLimitRule(
    name="auth",
    limit=5,  # requests
    window=60,  # seconds
    strategy=RateLimitStrategy.SLIDING_WINDOW,
    block_duration=300  # 5-minute block
)
```

### 5. Input Validation (`/app/security/security_validator.py`)

#### Validation Types
- **SQL Injection**: Pattern-based detection and prevention
- **XSS (Cross-Site Scripting)**: Script injection detection
- **Command Injection**: Shell command injection prevention
- **Path Traversal**: Directory traversal attack prevention
- **NoSQL Injection**: NoSQL-specific injection attacks
- **LDAP Injection**: LDAP injection attack prevention
- **Template Injection**: Template engine injection prevention
- **SSRF**: Server-Side Request Forgery prevention

#### Validation Example
```python
from app.security.security_validator import security_validator

# Comprehensive validation
result = security_validator.validate_and_sanitize_input(
    value=user_input,
    validation_type="comprehensive",
    sanitize_html=True,
    max_length=1000
)

if result.is_valid:
    # Use sanitized value
    safe_value = result.sanitized_value
else:
    # Handle validation failure
    print(f"Violations: {result.violations}")
```

## CORS Configuration

### Settings Configuration
```python
# In settings.py
cors_origins: List[AnyHttpUrl] = Field(
    default=["http://localhost:3000", "http://localhost:5173"],
    description="CORS allowed origins"
)
cors_allow_credentials: bool = Field(default=True, description="Allow CORS credentials")
cors_allow_methods: List[str] = Field(
    default=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    description="CORS allowed methods"
)
cors_allow_headers: List[str] = Field(
    default=["*"],
    description="CORS allowed headers"
)
```

### Middleware Configuration
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=settings.cors_allow_methods,
    allow_headers=settings.cors_allow_headers,
    expose_headers=[
        "X-Request-ID", 
        "X-Process-Time", 
        "X-RateLimit-Limit", 
        "X-RateLimit-Remaining", 
        "X-RateLimit-Reset"
    ],
    max_age=86400  # 24 hours
)
```

## Security Headers

### Implemented Headers
1. **Strict-Transport-Security (HSTS)**: Forces HTTPS connections
2. **Content-Security-Policy (CSP)**: Controls resource loading
3. **X-Frame-Options**: Prevents clickjacking attacks
4. **X-Content-Type-Options**: Prevents MIME sniffing
5. **X-XSS-Protection**: Enables browser XSS filtering
6. **Referrer-Policy**: Controls referrer information
7. **Permissions-Policy**: Controls browser features

### Example Configuration
```python
headers = {
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Content-Security-Policy": "default-src 'self'",
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
}
```

## Rate Limiting Configuration

### Environment Variables
```bash
# Rate limiting configuration
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS_PER_MINUTE=100
RATE_LIMIT_BURST_SIZE=20
RATE_LIMIT_STORAGE=redis
```

### Custom Rate Limit Rules
```python
from app.security.rate_limiter import RateLimitRule, RateLimitStrategy

# Add custom rate limit rule
custom_rule = RateLimitRule(
    name="api",
    limit=1000,
    window=3600,  # 1 hour
    strategy=RateLimitStrategy.SLIDING_WINDOW,
    exempt_users=["admin_user_id"]
)

rate_limiter.add_rate_limit_rule(custom_rule)
```

## Audit Logging

### Security Events Logged
- Authentication attempts (success/failure)
- Permission denials
- Security violations
- Rate limit violations
- Input validation failures

### Log Format
```json
{
  "timestamp": "2024-01-01T00:00:00Z",
  "level": "WARNING",
  "logger": "security",
  "event": "authentication_attempt",
  "user_id": "user123",
  "ip_address": "192.168.1.100",
  "user_agent": "Mozilla/5.0...",
  "success": false,
  "reason": "invalid_credentials"
}
```

## Configuration

### Environment-Specific Settings

#### Development
```python
# development settings
security_headers_enabled=True
rate_limit_enabled=True
trust_proxy_headers=False
ssl_enabled=False
app_debug=True
```

#### Production
```python
# production settings
security_headers_enabled=True
rate_limit_enabled=True
trust_proxy_headers=True
ssl_enabled=True
app_debug=False
```

### Security Checklist

- [x] JWT authentication implemented
- [x] Password hashing with bcrypt
- [x] Input validation and sanitization
- [x] Rate limiting configured
- [x] Security headers implemented
- [x] CORS properly configured
- [x] Role-based access control
- [x] Audit logging enabled
- [x] SQL injection protection
- [x] XSS prevention
- [x] CSRF protection (implicit through same-site)
- [x] Secure session management
- [x] Account lockout mechanism
- [x] Token expiration and refresh

## Testing Security Features

### Authentication Testing
```bash
# Test login endpoint
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Test protected endpoint
curl -X GET http://localhost:8000/auth/me \
  -H "Authorization: Bearer <access_token>"
```

### Rate Limiting Testing
```bash
# Test rate limiting (should return 429 after limit)
for i in {1..110}; do
  curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/api/v1/rate-limit-test
done
```

### Input Validation Testing
```bash
# Test SQL injection detection
curl -X POST http://localhost:8000/api/v1/validate-input \
  -H "Content-Type: application/json" \
  -d '{"test":" UNION SELECT * FROM users --"}'
```

## Monitoring and Alerting

### Security Metrics
- Authentication failure rates
- Rate limit violations
- Input validation failures
- Suspicious request patterns
- Token usage statistics

### Alert Conditions
- High authentication failure rates
- Multiple rate limit violations from same IP
- Suspicious input patterns detected
- Token usage anomalies

## Best Practices

1. **Use Strong Passwords**: Implement password complexity requirements
2. **Regular Token Rotation**: Automatically refresh tokens
3. **Input Validation**: Always validate and sanitize user input
4. **Rate Limiting**: Prevent abuse and DoS attacks
5. **Audit Logging**: Log all security-relevant events
6. **Security Headers**: Implement all recommended security headers
7. **CORS Configuration**: Only allow necessary origins
8. **Principle of Least Privilege**: Grant minimal necessary permissions
9. **Regular Security Updates**: Keep dependencies updated
10. **Security Testing**: Regular penetration testing and vulnerability scanning

## Dependencies

### Security Libraries
- `cryptography`: Cryptographic operations
- `passlib[bcrypt]`: Password hashing
- `python-jose[cryptography]`: JWT token handling
- `bleach`: HTML sanitization
- `PyJWT[crypto]`: JWT token processing

### Rate Limiting
- `redis`: Distributed rate limiting (optional)
- Built-in sliding window and token bucket implementations

## Future Enhancements

1. **Multi-Factor Authentication (MFA)**: TOTP and SMS support
2. **OAuth2 Integration**: Social login support
3. **API Key Management**: Per-user API keys with scopes
4. **Security Headers Automation**: Dynamic CSP generation
5. **Threat Intelligence Integration**: IP reputation checking
6. **Advanced Rate Limiting**: Machine learning-based adaptive limits
7. **Zero Trust Architecture**: Enhanced identity verification
8. **Security Automation**: Automated security testing and validation

This comprehensive security implementation provides enterprise-grade protection for the Customer Support AI Agent while maintaining performance and usability.
