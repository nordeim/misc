# MemoryTool - Advanced Conversation Memory Management

The MemoryTool is a comprehensive system for managing conversation history and context in the Customer Support AI Agent. It provides advanced features for storage, retrieval, optimization, and analytics of conversation memories.

## Features

### Core Memory Management
- **Persistent Storage**: Store conversation memories with different types and importance levels
- **Advanced Retrieval**: Search memories with relevance scoring and filtering
- **Memory Types**: Support for conversation, user preferences, facts, knowledge, context, and more
- **Importance Scoring**: Intelligent scoring based on content, recency, and access patterns
- **TTL Management**: Automatic expiration with configurable time-to-live

### Advanced Features
- **Memory Compression**: Automatic compression of long conversations
- **Relevance Scoring**: Advanced algorithms for context relevance
- **Memory Analytics**: Comprehensive statistics and insights
- **Pattern Detection**: Automatic detection of memory usage patterns
- **Optimization**: Automatic cleanup and memory optimization

### Context Management
- **Conversation Tracking**: Track conversation flow and context
- **Context Window Management**: Intelligent context selection
- **User Preference Tracking**: Automatic extraction and storage of user preferences
- **Fact Identification**: Extract and store important facts from conversations

## Quick Start

### Basic Usage

```python
from app.tools import memory_tool
from app.tools.memory_tool import MemoryType, MemoryQuery

# Store a conversation memory
memory_id = await memory_tool.store_memory(
    session_id="user_session_123",
    key="user_name",
    value="John Doe",
    memory_type=MemoryType.USER_INFO.value,
    importance_score=0.9,
    metadata={"source": "user_introduction"}
)

# Retrieve memories
context = await memory_tool.get_context(
    session_id="user_session_123",
    memory_types=[MemoryType.CONVERSATION.value, MemoryType.USER_INFO.value],
    limit=10,
    min_importance=0.5
)

# Search memories
search_query = MemoryQuery(
    session_id="user_session_123",
    keywords=["name", "email"],
    limit=10,
    memory_types=[MemoryType.USER_INFO.value]
)
results = await memory_tool.search_memories(search_query)
```

### Advanced Usage

```python
from app.services.memory_service import get_conversation_memory_manager

# Get conversation memory manager
conv_manager = get_conversation_memory_manager()

# Store a conversation turn
user_memory_id, assistant_memory_id = await conv_manager.store_conversation_turn(
    session_id="user_session_123",
    turn_number=1,
    user_message="Hi, I need help with my order",
    assistant_response="I'd be happy to help you with your order. Can you provide your order number?",
    context_tags=["support", "order_inquiry"]
)

# Track user preferences
preferences = {
    "support_method": "email",
    "preferred_language": "English",
    "communication_style": "formal"
}
await conv_manager.track_user_preferences(
    session_id="user_session_123",
    user_message="I prefer email support and formal communication",
    extracted_preferences=preferences
)

# Get conversation context
context = await conv_manager.get_conversation_context(
    session_id="user_session_123",
    recent_turns=5
)
```

## API Reference

### MemoryTool Class

#### Methods

##### `store_memory()`
Store a new memory with automatic optimization.

```python
async def store_memory(
    self,
    session_id: str,
    key: str,
    value: str,
    memory_type: str = MemoryType.CONVERSATION.value,
    importance_score: float = 0.5,
    metadata: Optional[Dict[str, Any]] = None,
    tags: Optional[List[str]] = None,
    ttl_days: Optional[int] = None,
    source_message_id: Optional[str] = None,
    auto_compress: bool = True
) -> str
```

**Parameters:**
- `session_id`: Unique session identifier
- `key`: Memory key for retrieval
- `value`: Memory content
- `memory_type`: Type of memory (see Memory Types)
- `importance_score`: Importance score (0.0 to 1.0)
- `metadata`: Additional metadata
- `tags`: List of tags for categorization
- `ttl_days`: Time to live in days
- `source_message_id`: ID of source message
- `auto_compress`: Enable automatic compression

**Returns:** Memory ID

##### `get_context()`
Retrieve conversation context with filtering.

```python
async def get_context(
    self,
    session_id: str,
    memory_types: Optional[List[str]] = None,
    limit: int = 20,
    since: Optional[datetime] = None,
    min_importance: float = 0.0,
    include_expired: bool = False
) -> List[Dict[str, Any]]
```

##### `search_memories()`
Advanced memory search with relevance scoring.

```python
async def search_memories(
    self,
    query: MemoryQuery
) -> List[MemorySearchResult]
```

**MemoryQuery Parameters:**
- `session_id`: Session to search in
- `memory_types`: Filter by memory types
- `tags`: Filter by tags
- `keywords`: Search keywords
- `importance_min`: Minimum importance score
- `since`/`until`: Time range filter
- `limit`/`offset`: Pagination
- `sort_by`/`sort_order`: Sorting options

##### `get_memory_analytics()`
Generate comprehensive analytics.

```python
async def get_memory_analytics(
    self,
    session_id: str,
    days: int = 30
) -> MemoryAnalytics
```

**Returns MemoryAnalytics with:**
- Total memories count
- Memories by type distribution
- Importance distribution
- Average importance score
- Access patterns
- Retention statistics
- Compression ratio

##### `cleanup_expired_memories()`
Clean up expired memories.

```python
async def cleanup_expired_memories(
    self,
    session_id: Optional[str] = None
) -> int
```

##### `compress_old_memories()`
Compress old, low-importance memories.

```python
async def compress_old_memories(
    self,
    session_id: str,
    older_than_days: int = 7,
    min_importance: float = 0.3
) -> int
```

### Memory Types

```python
class MemoryType(Enum):
    CONVERSATION = "conversation"      # Regular conversation content
    CONTEXT = "context"                # Contextual information
    USER_PREFERENCE = "user_preference" # User preferences and settings
    KNOWLEDGE = "knowledge"            # Knowledge base information
    FACT = "fact"                      # Factual information
    USER_INFO = "user_info"            # User personal information
    SUMMARY = "summary"                # Conversation summaries
    POLICY = "policy"                  # Policy information
    ERROR = "error"                    # Error and issue tracking
```

### Importance Levels

```python
class ImportanceLevel(Enum):
    CRITICAL = 1.0      # Critical information
    HIGH = 0.8          # High importance
    MEDIUM = 0.6        # Medium importance
    LOW = 0.4           # Low importance
    MINIMAL = 0.2       # Minimal importance
```

## Memory Management Services

### ConversationMemoryManager

High-level conversation management service.

```python
from app.services.memory_service import get_conversation_memory_manager

conv_manager = get_conversation_memory_manager()

# Store conversation turn
user_id, assistant_id = await conv_manager.store_conversation_turn(
    session_id, turn_number, user_message, assistant_response
)

# Track user preferences
preferences = await conv_manager.track_user_preferences(
    session_id, user_message, extracted_preferences
)

# Identify important facts
facts = await conv_manager.identify_important_facts(session_id, messages)

# Generate conversation summary
summary = await conv_manager.generate_conversation_summary(session_id)
```

### MemoryOptimizationService

Memory optimization and cleanup service.

```python
from app.services.memory_service import get_memory_optimization_service

opt_service = get_memory_optimization_service()

# Optimize session memories
results = await opt_service.optimize_session_memories(session_id, force=True)

# Analyze memory patterns
patterns = await opt_service.analyze_memory_patterns(session_id)
```

## Best Practices

### 1. Memory Types
- Use appropriate memory types for different content
- Set higher importance scores for critical information
- Use TTL for temporary or less important memories

### 2. Importance Scoring
- User preferences: 0.8-1.0
- Personal facts: 0.7-0.9
- Important conversation points: 0.6-0.8
- Regular conversation: 0.4-0.6
- Temporary context: 0.2-0.4

### 3. Memory Organization
- Use consistent key naming conventions
- Tag memories with relevant keywords
- Store related information together
- Use metadata to add context

### 4. Performance Optimization
- Regular cleanup of expired memories
- Compression of old, low-importance memories
- Monitor memory usage patterns
- Use summaries for long conversations

### 5. Context Management
- Retrieve relevant context using search
- Consider importance and recency scores
- Use conversation summaries for long histories
- Track user preferences separately

## Configuration

### Memory Limits
- Default max memories per session: 10,000
- Cleanup batch size: 1,000
- Default TTL: 30 days
- Compression threshold: 70% size reduction

### Importance Scoring
- Recency weight: 30%
- Importance weight: 40%
- Access weight: 20%
- Relevance weight: 10%

### Compression Settings
- Max conversation length: 2,000 characters
- Summary threshold: 1,000 characters
- Compression ratio threshold: 0.7

## Examples

### Complete Conversation Flow

```python
import asyncio
from app.tools import memory_tool
from app.tools.memory_tool import MemoryType
from app.services.memory_service import get_conversation_memory_manager

async def handle_conversation(session_id: str, user_message: str, assistant_response: str):
    # Get conversation manager
    conv_manager = get_conversation_memory_manager()
    
    # Store the conversation turn
    turn_number = 1  # You would track this
    await conv_manager.store_conversation_turn(
        session_id=session_id,
        turn_number=turn_number,
        user_message=user_message,
        assistant_response=assistant_response,
        context_tags=["support", "customer_service"]
    )
    
    # Extract and store preferences if any
    preferences = extract_preferences_from_message(user_message)
    if preferences:
        await conv_manager.track_user_preferences(
            session_id, user_message, preferences
        )
    
    # Get context for next response
    context = await conv_manager.get_conversation_context(
        session_id=session_id,
        recent_turns=3
    )
    
    return context

async def extract_preferences_from_message(message: str) -> dict:
    """Extract user preferences from message."""
    preferences = {}
    message_lower = message.lower()
    
    if "email" in message_lower:
        preferences["support_method"] = "email"
    if "phone" in message_lower:
        preferences["support_method"] = "phone"
    if "formal" in message_lower:
        preferences["communication_style"] = "formal"
    if "casual" in message_lower:
        preferences["communication_style"] = "casual"
    
    return preferences

# Usage
async def main():
    session_id = "user_123"
    
    # Simulate conversation
    context = await handle_conversation(
        session_id,
        "Hi, I prefer email support and formal communication",
        "I'll remember your preferences for email support and formal communication style."
    )
    
    # Generate summary after conversation
    conv_manager = get_conversation_memory_manager()
    summary = await conv_manager.generate_conversation_summary(session_id)
    print(f"Conversation summary: {summary}")

asyncio.run(main())
```

### Memory Analytics and Monitoring

```python
async def monitor_session_memories(session_id: str):
    # Get comprehensive analytics
    analytics = await memory_tool.get_memory_analytics(session_id, days=30)
    
    print(f"Session: {session_id}")
    print(f"Total memories: {analytics.total_memories}")
    print(f"Average importance: {analytics.avg_importance_score:.2f}")
    print(f"Retention rate: {analytics.retention_stats['retention_rate']:.1f}%")
    
    # Check for optimization opportunities
    if analytics.total_memories > 1000:
        print("High memory usage - consider optimization")
    
    if analytics.retention_stats['retention_rate'] < 70:
        print("Low retention rate - review expiration settings")
    
    # Run optimization if needed
    opt_service = get_memory_optimization_service()
    patterns = await opt_service.analyze_memory_patterns(session_id)
    
    for pattern in patterns:
        print(f"Pattern detected: {pattern.pattern_type}")
        print(f"Recommendations: {pattern.recommendations}")
```

### Search and Retrieval

```python
async def find_user_information(session_id: str):
    # Search for user information
    query = MemoryQuery(
        session_id=session_id,
        memory_types=[
            MemoryType.USER_INFO.value,
            MemoryType.USER_PREFERENCE.value
        ],
        keywords=["name", "email", "phone", "address"],
        min_importance=0.7,
        limit=20
    )
    
    results = await memory_tool.search_memories(query)
    
    user_info = {}
    for result in results:
        memory = result.memory
        if "name" in result.matched_keywords:
            user_info["name"] = memory.value
        elif "email" in result.matched_keywords:
            user_info["email"] = memory.value
        elif "phone" in result.matched_keywords:
            user_info["phone"] = memory.value
    
    return user_info

async def get_conversation_history(session_id: str, days: int = 7):
    # Get recent conversation history
    context = await memory_tool.get_context(
        session_id=session_id,
        memory_types=[MemoryType.CONVERSATION.value],
        since=datetime.utcnow() - timedelta(days=days),
        min_importance=0.4,
        limit=50
    )
    
    # Format for display
    history = []
    for memory in sorted(context, key=lambda x: x['created_at']):
        history.append({
            "timestamp": memory['created_at'],
            "type": memory['memory_type'],
            "content": memory['value'][:100] + "..." if len(memory['value']) > 100 else memory['value'],
            "importance": memory['importance_score']
        })
    
    return history
```

## Error Handling

```python
try:
    memory_id = await memory_tool.store_memory(
        session_id=session_id,
        key=key,
        value=value,
        memory_type=memory_type
    )
except Exception as e:
    logger.error(f"Failed to store memory: {e}")
    # Handle error appropriately

try:
    context = await memory_tool.get_context(session_id)
except Exception as e:
    logger.error(f"Failed to retrieve context: {e}")
    # Return empty context or handle error
```

## Performance Considerations

### Indexing
- Memories are automatically indexed by session_id, memory_type, and importance_score
- Search operations use optimized database queries
- Relevance scoring is performed in-memory for accuracy

### Cleanup
- Automatic cleanup of expired memories
- Batch processing for large cleanup operations
- Configurable cleanup intervals

### Compression
- Automatic compression of long conversations
- Configurable compression thresholds
- Preservation of important information

## Monitoring

### Metrics to Monitor
- Memory usage per session
- Search performance
- Cleanup success rates
- Compression effectiveness
- Error rates

### Alerts
- High memory usage
- Frequent search timeouts
- Cleanup failures
- Compression errors

## Troubleshooting

### Common Issues

1. **Memory not found**
   - Check session_id and key are correct
   - Verify memory hasn't expired
   - Check access permissions

2. **Slow search performance**
   - Review memory usage limits
   - Consider adding more specific search filters
   - Run cleanup operations

3. **High memory usage**
   - Enable automatic compression
   - Review TTL settings
   - Run optimization service

4. **Missing context**
   - Check importance scoring
   - Verify memory types
   - Review search parameters

### Debug Mode

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Enable debug logging for memory operations
logger = logging.getLogger('app.tools.memory_tool')
logger.setLevel(logging.DEBUG)
```

## Integration

### With FastAPI

```python
from fastapi import APIRouter, Depends
from app.tools import memory_tool
from app.database import get_db

router = APIRouter(prefix="/api/memory", tags=["memory"])

@router.post("/store")
async def store_memory(
    request: MemoryStoreRequest,
    db=Depends(get_db)
):
    memory_id = await memory_tool.store_memory(
        session_id=request.session_id,
        key=request.key,
        value=request.value,
        memory_type=request.memory_type,
        importance_score=request.importance_score
    )
    return {"memory_id": memory_id}

@router.get("/context/{session_id}")
async def get_context(
    session_id: str,
    memory_types: List[str] = None,
    limit: int = 20
):
    context = await memory_tool.get_context(
        session_id=session_id,
        memory_types=memory_types,
        limit=limit
    )
    return {"context": context}
```

### With Database Models

The MemoryTool integrates seamlessly with the existing database models:

- `MemoryORM`: Core memory model
- `SessionORM`: Session relationship
- `MessageORM`: Source message linking

### With Other Tools

- **RAG Tool**: Share knowledge base memories
- **Escalation Tool**: Preserve context during escalations
- **Attachment Tool**: Link memories to file attachments

## Version History

### v2.0.0 (Current)
- Complete rewrite with advanced features
- Enhanced search and relevance scoring
- Memory compression and optimization
- Comprehensive analytics
- Context management services
- Pattern detection and recommendations

### v1.0.0
- Basic memory storage and retrieval
- Simple search functionality
- Memory expiration

## Contributing

When contributing to the MemoryTool:

1. Follow the existing code style
2. Add comprehensive tests
3. Update documentation
4. Consider performance implications
5. Test with various data sizes
6. Verify memory cleanup works correctly

## Support

For issues and questions:

1. Check the troubleshooting section
2. Review the test examples
3. Check the logs for error messages
4. Verify database connectivity
5. Test with minimal examples
