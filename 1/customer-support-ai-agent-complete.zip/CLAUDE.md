# 🤖 Customer Support AI Agent - Technical Briefing for AI Coding Agents

<div align="center">

![Technical Brief](https://img.shields.io/badge/Briefing-AI%20Agent%20Optimized-blue)
![Architecture](https://img.shields.io/badge/Architecture-Production%20Ready-green)
![Code](https://img.shields.io/badge/Code-15,000%2B%20Lines-orange)
![AI](https://img.shields.io/badge/AI-Custom%20Orchestrator-red)
![Stack](https://img.shields.io/badge/Stack-FastAPI%20%7C%20React-purple)

**Comprehensive Technical Briefing for Claude Code, Codex, and other AI Coding Agents**

*Specialized Documentation for Development, Extension, and Maintenance*

</div>

---

## 📋 Table of Contents

- [🎯 Executive Summary](#-executive-summary)
- [🏗️ System Architecture & File Structure](#️-system-architecture--file-structure)
- [⚡ Technology Stack & Dependencies](#️-technology-stack--dependencies)
- [🚀 Quick Setup & Development Environment](#-quick-setup--development-environment)
- [🌐 API Architecture & Endpoints](#-api-architecture--endpoints)
- [🤖 AI Agent System Deep Dive](#-ai-agent-system-deep-dive)
- [⚙️ Development Workflows & Procedures](#️-development-workflows--procedures)
- [🏭 Deployment & Operations](#-deployment--operations)
- [🔧 Troubleshooting & Maintenance](#-troubleshooting--maintenance)

---

## 🎯 Executive Summary

### 🎯 Project Purpose
**Customer Support AI Agent** is a production-ready, enterprise-grade intelligent customer support system combining conversational AI, document processing, and real-time communication. Built with a **custom AI agent orchestrator** (not black-box frameworks), this system handles customer inquiries through sophisticated multi-tool coordination.

### 🔑 Critical Success Factors
- **15,000+ lines** of production-ready code
- **Custom AI Agent Orchestrator** - Complete control over AI logic
- **Real-time WebSocket** communication with streaming responses
- **RAG-Powered Knowledge** - ChromaDB vector database with SentenceTransformer embeddings
- **Enterprise Security** - JWT auth, rate limiting, input sanitization, audit trails
- **Multi-format Document Processing** - 15+ file types using MarkItDown
- **Microservices Architecture** - Docker Compose with PostgreSQL, Redis, ChromaDB

### 🏃‍♂️ Development Priority Areas
1. **Agent System Enhancement** - Extend tool registry, improve agent decision logic
2. **API Endpoints** - Add new chat functionalities, file processing endpoints
3. **Performance Optimization** - Caching strategies, database query optimization
4. **Security Hardening** - Authentication flows, input validation enhancement
5. **Monitoring & Analytics** - Business intelligence, performance metrics

### ⚡ Key Technical Challenges
- **Agent State Management** - Complex conversation flow with memory persistence
- **Tool Orchestration** - Dynamic tool selection and execution pipeline
- **Real-time Processing** - WebSocket message streaming with AI response generation
- **Document Processing** - Multi-format file handling with AI content extraction
- **Scalability** - Multi-tenant support with conversation isolation

### 🎯 Development Focus
- **Extensibility** - Plugin-based tool system for easy feature addition
- **Performance** - Caching layers, async processing, optimized queries
- **Maintainability** - Comprehensive validation, structured logging, monitoring
- **Security** - Multi-layer security with audit trails and compliance

---

## 🏗️ System Architecture & File Structure

### 📁 Complete File Hierarchy

```
customer-support-ai-agent/
├── 📂 backend/                          # FastAPI Backend (Primary focus)
│   ├── 📄 main.py                      # FastAPI app entry point (934 lines)
│   ├── 📄 config.py                    # Enhanced configuration system (932 lines)
│   ├── 📄 database.py                  # Database connection management
│   ├── 📄 dependencies.py              # Dependency injection utilities
│   │
│   ├── 📂 agents/                      # 🔥 AI Agent System Core
│   │   ├── 📄 chat_agent.py            # CustomerSupportAgent orchestrator (1016 lines)
│   │   ├── 📄 agent_factory.py         # Agent creation and management
│   │   ├── 📄 agent_monitoring.py      # Agent performance monitoring
│   │   └── 📄 __init__.py
│   │
│   ├── 📂 tools/                       # 🔥 Agent Tools System
│   │   ├── 📄 base_tool.py             # Base tool class and interface
│   │   ├── 📄 rag_tool.py              # RAG (Retrieval-Augmented Generation)
│   │   ├── 📄 memory_tool.py           # Conversation memory management
│   │   ├── 📄 attachment_tool.py       # File attachment processing
│   │   ├── 📄 escalation_tool.py       # Human escalation handling
│   │   └── 📄 tool_registry.py         # Tool registration and management
│   │
│   ├── 📂 api/                         # 🔥 API Endpoints & Routes
│   │   ├── 📂 routes/
│   │   │   ├── 📄 chat.py              # Core chat API endpoints (1540 lines)
│   │   │   ├── 📄 auth.py              # Authentication endpoints
│   │   │   ├── 📄 sessions.py          # Session management
│   │   │   ├── 📄 files.py             # File upload/processing
│   │   │   ├── 📄 agents.py            # Agent management endpoints
│   │   │   └── 📄 health.py            # Health check endpoints
│   │   ├── 📄 websocket.py             # WebSocket endpoint for real-time chat
│   │   └── 📄 backup_restore.py        # Database backup/restore
│   │
│   ├── 📂 middleware/                  # Security & Request Processing
│   │   ├── 📄 security.py              # JWT, headers, API key auth
│   │   ├── 📄 rate_limiting.py         # Rate limiting implementation
│   │   ├── 📄 cors.py                  # CORS configuration
│   │   ├── 📄 logging.py               # Structured logging setup
│   │   ├── 📄 error_handling.py        # Global exception handling
│   │   └── 📄 request_validation.py    # Request validation pipeline
│   │
│   ├── 📂 models/                      # 🔥 Data Models & Schemas
│   │   ├── 📄 user.py                  # User authentication models
│   │   ├── 📄 session.py               # Session management models
│   │   ├── 📄 message.py               # Chat message models
│   │   ├── 📄 escalation.py            # Escalation system models
│   │   ├── 📄 escalation_schemas.py    # Escalation Pydantic schemas
│   │   └── 📂 user_defined/            # Custom model definitions
│   │
│   ├── 📂 services/                    # Business Logic Layer
│   │   ├── 📄 message_service.py       # Message processing logic
│   │   ├── 📄 session_service.py       # Session management logic
│   │   ├── 📄 embedding_service.py     # AI embedding generation
│   │   ├── 📄 rag_service.py           # RAG system service
│   │   ├── 📄 message_analytics_service.py # Analytics and metrics
│   │   ├── 📄 message_security_service.py  # Security validation
│   │   └── 📄 message_utilities_service.py # Utility functions
│   │
│   ├── 📂 config/                      # Configuration Management
│   │   ├── 📄 database.py              # Database configuration
│   │   ├── 📄 redis.py                 # Redis configuration
│   │   ├── 📄 security.py              # Security configuration
│   │   ├── 📄 ai.py                    # AI/LLM configuration (498 lines)
│   │   ├── 📄 monitoring.py            # Monitoring configuration
│   │   ├── 📄 config_loader.py         # Environment-based config loading
│   │   ├── 📄 config_validator.py      # Configuration validation
│   │   └── 📄 config_migration.py      # Config migration utilities
│   │
│   ├── 📂 utils/                       # Utility Functions
│   │   ├── 📄 file_utils.py            # File processing utilities
│   │   ├── 📄 validation_utils.py      # Input validation utilities
│   │   ├── 📄 security_utils.py        # Security utility functions
│   │   └── 📄 performance_utils.py     # Performance optimization tools
│   │
│   ├── 📂 validation/                  # 🔥 Request/Response Validation
│   │   ├── 📄 __init__.py              # Validation package init
│   │   ├── 📄 base_validation.py       # Base validation classes
│   │   ├── 📄 request_validation.py    # Request validation pipeline
│   │   ├── 📄 response_validation.py   # Response validation pipeline
│   │   ├── 📄 security_validation.py   # Security validation rules
│   │   └── 📄 business_validation.py   # Business logic validation
│   │
│   ├── 📂 streaming/                   # Real-time Communication
│   │   ├── 📄 ws_manager.py            # WebSocket connection management
│   │   ├── 📄 streaming_service.py     # Streaming response handling
│   │   └── 📄 event_handler.py         # Real-time event processing
│   │
│   ├── 📂 monitoring/                  # Observability & Metrics
│   │   ├── 📄 metrics.py               # Prometheus metrics collection
│   │   ├── 📄 logging.py               # Structured logging configuration
│   │   ├── 📄 health_checker.py        # Health check implementations
│   │   └── 📄 performance_monitor.py   # Performance monitoring
│   │
│   ├── 📂 scripts/                     # Development Utilities
│   │   ├── 📄 initialize_db.py         # Database initialization
│   │   ├── 📄 backup_cli.py            # Command-line backup tool
│   │   └── 📄 seed_data.py             # Development data seeding
│   │
│   ├── 📂 tests/                       # 🔥 Testing Suite
│   │   ├── 📂 unit/                    # Unit tests
│   │   ├── 📂 integration/             # Integration tests
│   │   ├── 📂 e2e/                     # End-to-end tests
│   │   └── 📄 conftest.py              # pytest configuration
│   │
│   ├── 📂 data/                        # Data Storage
│   │   ├── 📂 sqlite/                  # SQLite databases (development)
│   │   ├── 📂 chromadb/                # ChromaDB vector storage
│   │   └── 📄 encryption.key           # Encryption keys
│   │
│   ├── 📄 Dockerfile                   # Production Docker image
│   ├── 📄 Dockerfile.dev               # Development Docker image
│   ├── 📄 requirements.txt             # Python dependencies
│   └── 📄 alembic/                     # Database migrations
│
├── 📂 frontend/                        # React TypeScript Frontend
│   ├── 📄 src/App.tsx                  # Main application component
│   ├── 📄 src/main.tsx                 # Application entry point
│   ├── 📄 package.json                 # Node.js dependencies & scripts
│   ├── 📂 src/components/              # React components
│   ├── 📂 src/hooks/                   # Custom React hooks
│   ├── 📂 src/services/                # API service layer
│   ├── 📂 src/types/                   # TypeScript type definitions
│   └── 📄 Dockerfile                   # Frontend Docker configuration
│
├── 📂 scripts/                         # 🔥 Development & Deployment Scripts
│   ├── 📄 setup.sh                     # Environment setup script
│   ├── 📄 start.sh                     # Development startup (245 lines)
│   ├── 📄 deploy.sh                    # Production deployment (525+ lines)
│   ├── 📄 test.sh                      # Testing automation
│   └── 📂 deployment/                  # Deployment configurations
│
├── 📂 docker/                          # Docker Compose & Configurations
│   ├── 📄 docker-compose.yml           # Multi-service orchestration
│   ├── 📄 nginx.conf                   # Reverse proxy configuration
│   ├── 📄 prometheus.yml               # Monitoring configuration
│   └── 📂 production/                  # Production-specific configs
│
├── 📂 k8s/                             # Kubernetes Deployment
│   ├── 📄 deployment.yaml              # Kubernetes deployment specs
│   ├── 📄 service.yaml                 # Service definitions
│   ├── 📄 ingress.yaml                 # Ingress configuration
│   └── 📄 hpa.yaml                     # Horizontal Pod Autoscaler
│
├── 📂 monitoring/                      # 🔥 Observability Stack
│   ├── 📂 grafana-dashboards/          # Grafana dashboard definitions
│   ├── 📂 grafana-datasources/         # Data source configurations
│   ├── 📂 alert-rules/                 # Prometheus alert rules
│   ├── 📄 docker-compose.monitoring.yml # Monitoring stack
│   └── 📄 alertmanager.yml             # Alert manager configuration
│
├── 📄 CLAUDE.md                        # 📋 This briefing document
├── 📄 README.md                        # Comprehensive project documentation
├── 📄 Project_Architecture_Document.md # Technical architecture details
└── 📄 docker-compose.yml               # Root Docker Compose configuration
```

### 🔥 Critical Files for Modification

#### **High Priority Files (Immediate Development Focus)**
1. **`/backend/app/agents/chat_agent.py`** - Custom agent orchestrator (1016 lines)
2. **`/backend/app/api/routes/chat.py`** - Core chat API endpoints (1540 lines)
3. **`/backend/app/config/ai.py`** - AI service configuration (498 lines)
4. **`/backend/app/main.py`** - FastAPI application entry (934 lines)
5. **`/backend/app/config.py`** - Enhanced configuration system (932 lines)

#### **Medium Priority Files (Feature Development)**
1. **`/backend/app/tools/rag_tool.py`** - RAG system implementation
2. **`/backend/app/services/message_service.py`** - Message processing logic
3. **`/backend/app/models/*.py`** - Data models and schemas
4. **`/backend/app/middleware/*.py`** - Security and request processing
5. **`/scripts/start.sh`** - Development environment startup (245 lines)

#### **Lower Priority Files (Infrastructure & Operations)**
1. **`/docker/docker-compose.yml`** - Service orchestration
2. **`/monitoring/*.yml`** - Monitoring and observability
3. **`/k8s/*.yaml`** - Kubernetes deployement configs

### 🎯 Key Architecture Patterns

#### **Agent Orchestration Pattern**
```python
# Core pattern in chat_agent.py
class CustomerSupportAgent:
    async def process_message(self, context: AgentContext) -> AgentResponse:
        # 1. Tool selection based on intent
        selected_tools = await self.select_tools(context)
        
        # 2. Execute tools in sequence
        results = await self.execute_tools(selected_tools, context)
        
        # 3. Generate response using LLM
        response = await self.generate_response(results, context)
        
        # 4. Update conversation state
        await self.update_memory(context, response)
        
        return response
```

#### **Tool Registry Pattern**
```python
# Base tool interface in tools/base_tool.py
class BaseTool(ABC):
    @abstractmethod
    async def execute(self, context: AgentContext) -> ToolResult:
        pass
    
    @abstractmethod
    def can_handle(self, intent: str) -> bool:
        pass

# Tool registration in tools/tool_registry.py
class ToolRegistry:
    def register_tool(self, tool: BaseTool):
        self._tools[tool.name] = tool
    
    async def get_tool_for_intent(self, intent: str) -> Optional[BaseTool]:
        return self._tools.get(intent)
```

#### **Service Layer Pattern**
```python
# Service implementation pattern
class MessageService:
    def __init__(self):
        self.db = get_db()
        self.agent = CustomerSupportAgent()
        self.validator = RequestValidator()
    
    async def process_message(self, message: MessageCreate) -> MessageResponse:
        # Validation -> Processing -> Response
        validated = await self.validator.validate(message)
        result = await self.agent.process(validated)
        return await self.format_response(result)
```

---

## ⚡ Technology Stack & Dependencies

### 🔧 Precise Version Requirements

#### **Backend Technology Stack**
| Component | Technology | Version | Purpose | Critical Files |
|-----------|------------|---------|---------|----------------|
| **Runtime** | Python | 3.11+ | Application runtime | `backend/Dockerfile` |
| **Framework** | FastAPI | 0.115+ | Web framework | `backend/app/main.py` |
| **Agent System** | Custom Orchestrator | v1.0 | AI agent coordination | `backend/app/agents/` |
| **Async Runtime** | asyncio + uvicorn | Latest | Async request handling | `backend/main.py:47` |
| **ORM** | SQLAlchemy | 2.0+ | Database operations | `backend/app/database.py` |
| **Migrations** | Alembic | Latest | Database schema management | `backend/alembic/` |
| **Validation** | Pydantic | 2.0+ | Data validation | `backend/app/models/` |
| **Authentication** | JWT + Custom | Latest | User authentication | `backend/app/middleware/security.py` |
| **Caching** | Redis | 7+ | Multi-level caching | `backend/config/redis.py` |
| **Vector DB** | ChromaDB | 0.5.20+ | RAG implementation | `backend/app/tools/rag_tool.py` |
| **Embeddings** | SentenceTransformers | Latest | Text embeddings | `backend/app/services/embedding_service.py` |
| **Document Processing** | MarkItDown | Latest | Multi-format file processing | `backend/app/tools/attachment_tool.py` |
| **Testing** | pytest + pytest-asyncio | Latest | Test framework | `backend/tests/` |

#### **Frontend Technology Stack**
| Component | Technology | Version | Purpose |
|-----------|------------|---------|---------|
| **Framework** | React | 18.2+ | UI framework |
| **Language** | TypeScript | 5.2+ | Type safety |
| **Build Tool** | Vite | 5.0+ | Fast development build |
| **Styling** | Tailwind CSS | 3.4+ | Utility-first styling |
| **State Management** | React Context + Hooks | Latest | Local state management |
| **HTTP Client** | Axios | 1.6+ | API communication |
| **Real-time** | socket.io-client | 4.7+ | WebSocket communication |
| **Testing** | Vitest + Playwright | Latest | Unit and E2E testing |

#### **Infrastructure & Deployment**
| Component | Technology | Version | Purpose |
|-----------|------------|---------|---------|
| **Containerization** | Docker + Docker Compose | 20.10+ / 2.0+ | Service orchestration |
| **Database** | PostgreSQL | 15+ | Primary database |
| **Cache** | Redis | 7+ | Session and cache storage |
| **Vector Database** | ChromaDB | Latest | RAG vector storage |
| **Reverse Proxy** | Nginx | Latest | Load balancing and SSL |
| **Monitoring** | Prometheus + Grafana | Latest | Metrics and observability |
| **Process Manager** | Gunicorn + Uvicorn | Latest | WSGI/ASGI server |
| **Orchestration** | Kubernetes | 1.25+ | Container orchestration |

### 🔌 Key Dependencies & Usage Patterns

#### **Backend Dependencies (`backend/requirements.txt`)**
```python
# Core framework dependencies
fastapi==0.115.0
uvicorn[standard]==0.30.0
pydantic==2.5.0
sqlalchemy[asyncio]==2.0.23
alembic==1.13.0

# Authentication & Security
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-multipart==0.0.6

# Database & Cache
asyncpg==0.29.0
redis==5.0.1
chromadb==0.5.20

# AI/ML Dependencies
sentence-transformers==2.2.2
openai==1.3.7
anthropic==0.7.8

# Monitoring & Logging
prometheus-client==0.19.0
structlog==23.2.0

# Document Processing
python-docx==1.1.0
python-pptx==0.6.22
openpyxl==3.1.2
pillow==10.1.0

# Testing
pytest==7.4.3
pytest-asyncio==0.21.1
httpx==0.25.2

# Development Tools
black==23.11.0
isort==5.12.0
mypy==1.7.1
```

#### **Frontend Dependencies (`frontend/package.json`)**
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.1",
    "typescript": "^5.2.2",
    "tailwindcss": "^3.3.6",
    "socket.io-client": "^4.7.4",
    "axios": "^1.6.2",
    "react-hot-toast": "^2.4.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.1.1",
    "vite": "^5.0.0",
    "vitest": "^0.34.6",
    "@playwright/test": "^1.40.0",
    "@testing-library/react": "^13.4.0"
  }
}
```

### 🔧 Configuration Management

#### **Environment-Based Configuration**
```python
# backend/app/config.py - Primary configuration class
class Settings(BaseSettings):
    # Application settings
    app_name: str = "Customer Support AI Agent"
    app_version: str = "1.0.0"
    environment: str = "development"
    
    # Database configuration
    database_url: PostgresDsn
    database_echo: bool = False
    
    # Redis configuration  
    redis_url: RedisDsn
    
    # Security settings
    secret_key: SecretStr
    jwt_expire_minutes: int = 30
    jwt_algorithm: str = "HS256"
    
    # AI/LLM configuration
    openai_api_key: Optional[SecretStr] = None
    anthropic_api_key: Optional[SecretStr] = None
    embedding_model: str = "all-MiniLM-L6-v2"
    
    # File upload settings
    upload_max_file_size_mb: int = 10
    allowed_file_types: List[str] = ["pdf", "docx", "txt", "md", "html", "jpg", "png"]
    
    # CORS settings
    cors_origins: List[AnyHttpUrl] = ["http://localhost:3000", "http://localhost:5173"]
    
    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_requests: int = 100
    rate_limit_window: int = 60  # seconds
    
    class Config:
        env_file = ".env"
        case_sensitive = False
```

#### **AI Service Configuration**
```python
# backend/config/ai.py - Specialized AI configuration
class AIConfig(BaseSettings):
    # Primary LLM configuration
    llm_provider: str = "openai"
    llm_enabled: bool = True
    
    # OpenAI configuration
    openai_api_key: Optional[SecretStr] = None
    openai_model: str = "gpt-4"
    openai_max_tokens: int = 1000
    openai_temperature: float = 0.7
    
    # Anthropic configuration
    anthropic_api_key: Optional[SecretStr] = None
    anthropic_model: str = "claude-3-sonnet-20240229"
    
    # Embedding configuration
    embedding_provider: str = "sentence_transformers"
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dimension: int = 384
    
    # RAG configuration
    chroma_db_url: str = "http://localhost:8000"
    chroma_db_collection: str = "customer_support_knowledge"
    rag_top_k: int = 5
    rag_similarity_threshold: float = 0.7
    
    class Config:
        env_prefix = "AI_"
        env_file = ".env"
```

---

## 🚀 Quick Setup & Development Environment

### ⚡ One-Command Setup

#### **Prerequisites Check**
```bash
# Required tools
docker --version          # >= 20.10
docker-compose --version  # >= 2.0
git --version             # Latest
python --version          # 3.11+
node --version            # >= 18.0.0
npm --version             # >= 9.0.0
```

#### **Environment Setup**
```bash
# 1. Clone and setup
git clone <your-repo-url>
cd customer-support-ai-agent

# 2. Environment configuration
cp .env.example .env
# Edit .env with your configuration

# 3. Start all services
./scripts/start.sh

# 4. Verify setup
curl http://localhost:8000/health
curl http://localhost:3000  # Frontend health
```

### 🏃‍♂️ Development Workflows

#### **Daily Development Cycle**
```bash
# Start development environment
./scripts/start.sh

# Backend development (hot reload)
docker-compose exec backend bash
cd /app
python -m pytest tests/unit/ -v

# Frontend development (hot reload)  
docker-compose exec frontend bash
cd /app
npm run dev

# Live monitoring
docker-compose logs -f backend
docker-compose logs -f frontend

# Database access
docker-compose exec postgres psql -U postgres -d customer_support
```

#### **Feature Development Workflow**
```bash
# 1. Create feature branch
git checkout -b feature/your-feature-name

# 2. Make changes to backend
#    Edit files in backend/app/
#    Run tests: ./scripts/test.sh backend

# 3. Make changes to frontend
#    Edit files in frontend/src/
#    Run frontend tests: npm run test

# 4. Integration testing
docker-compose -f docker-compose.yml up -d
./scripts/test.sh integration

# 5. Commit and push
git add .
git commit -m "feat: your feature description"
git push origin feature/your-feature-name
```

#### **Testing Procedures**
```bash
# Unit tests (fast)
./scripts/test.sh unit

# Integration tests (slower)
./scripts/test.sh integration

# End-to-end tests (slowest)
./scripts/test.sh e2e

# All tests
./scripts/test.sh

# Specific test file
pytest backend/tests/unit/test_chat_agent.py -v

# Test with coverage
pytest --cov=app tests/ --cov-report=html
```

### 🔧 Debugging & Development Tools

#### **Backend Debugging**
```bash
# Access backend container
docker-compose exec backend bash

# Python debugging
python -m pdb your_script.py

# Database debugging
docker-compose exec postgres psql -U postgres -d customer_support
# SQL queries to inspect data

# Redis debugging
docker-compose exec redis redis-cli
# Redis commands for cache inspection

# ChromaDB debugging
docker-compose exec backend python -c "
import chromadb
client = chromadb.Client()
print(client.list_collections())
"

# Log analysis
docker-compose logs backend | grep ERROR
docker-compose logs backend | grep "chat_agent.py"
```

#### **Frontend Debugging**
```bash
# Access frontend container
docker-compose exec frontend bash

# React dev tools (browser)
# Open http://localhost:3000 and use browser dev tools

# Component testing
npm run test:ui

# Build analysis
npm run build
npm run preview

# Type checking
npm run type-check
```

#### **API Testing**
```bash
# Health check
curl http://localhost:8000/health

# API documentation
open http://localhost:8000/docs

# Chat endpoint testing
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, how can you help me?"}'

# WebSocket testing
wscat -c ws://localhost:8000/ws
```

---

## 🌐 API Architecture & Endpoints

### 🔗 Core API Endpoints

#### **Chat & Messaging API**
```python
# Core chat processing endpoint
POST /api/v1/chat
{
    "message": "string",
    "session_id": "uuid (optional)",
    "file_attachments": "File[] (optional)",
    "parent_message_id": "uuid (optional)",
    "metadata": "dict (optional)"
}

# Response format
{
    "response": "string",
    "session_id": "uuid",
    "message_id": "uuid", 
    "timestamp": "datetime",
    "tools_used": ["rag_tool", "memory_tool"],
    "confidence_score": 0.85,
    "escalated": false,
    "metadata": {}
}
```

#### **WebSocket Real-time API**
```python
# WebSocket endpoint for real-time chat
WS /ws

# Client message format
{
    "type": "chat_message",
    "data": {
        "message": "string",
        "session_id": "uuid (optional)"
    }
}

# Server response format
{
    "type": "chat_response", 
    "data": {
        "response": "streamed_response",
        "session_id": "uuid",
        "complete": false,
        "tools_used": ["rag_tool"]
    }
}
```

#### **Session Management API**
```python
# Create new session
POST /api/v1/sessions
{
    "user_id": "uuid (optional)",
    "metadata": "dict (optional)"
}

# Get session details
GET /api/v1/sessions/{session_id}

# Update session
PUT /api/v1/sessions/{session_id}
{
    "metadata": "dict",
    "status": "active|closed|escalated"
}

# Close session
DELETE /api/v1/sessions/{session_id}
```

#### **File Upload & Processing API**
```python
# Upload file
POST /api/v1/files/upload
Content-Type: multipart/form-data

# Process uploaded file
POST /api/v1/files/process
{
    "file_id": "uuid",
    "processing_options": {
        "extract_text": true,
        "summarize": false,
        "embedding_generate": true
    }
}

# List uploaded files
GET /api/v1/files?session_id={session_id}

# Download file
GET /api/v1/files/{file_id}/download
```

#### **Authentication API**
```python
# User registration
POST /api/v1/auth/register
{
    "email": "string",
    "password": "string",
    "full_name": "string"
}

# User login
POST /api/v1/auth/login
{
    "email": "string", 
    "password": "string"
}

# Token refresh
POST /api/v1/auth/refresh
{
    "refresh_token": "string"
}

# User profile
GET /api/v1/auth/me
Authorization: Bearer {access_token}
```

#### **Health & Monitoring API**
```python
# Basic health check
GET /health

# Detailed health check
GET /health/detailed

# Readiness probe
GET /health/ready

# Liveness probe  
GET /health/live

# System metrics
GET /metrics

# Configuration status
GET /health/config
```

### 🔧 Request/Response Patterns

#### **Request Validation Schema**
```python
# Example validation in backend/app/validation/request_validation.py
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class ChatMessageRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10000)
    session_id: Optional[str] = None
    file_attachments: Optional[List[UploadFile]] = None
    parent_message_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    class Config:
        json_schema_extra = {
            "example": {
                "message": "How can I reset my password?",
                "session_id": "123e4567-e89b-12d3-a456-426614174000",
                "metadata": {"user_type": "premium"}
            }
        }
```

#### **Response Pattern**
```python
# Standard API response format
class APIResponse(BaseModel):
    success: bool = True
    data: Any = None
    message: Optional[str] = None
    errors: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    correlation_id: str

# Chat-specific response
class ChatResponse(BaseModel):
    response: str
    session_id: str
    message_id: str
    timestamp: datetime
    tools_used: List[str]
    confidence_score: float = Field(ge=0.0, le=1.0)
    escalated: bool = False
    metadata: Dict[str, Any] = Field(default_factory=dict)
```

### 🔐 Authentication & Security Patterns

#### **JWT Authentication Flow**
```python
# Middleware in backend/app/middleware/security.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    try:
        payload = jwt.decode(
            credentials.credentials, 
            settings.secret_key.get_secret_value(),
            algorithms=[settings.jwt_algorithm]
        )
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials"
            )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    return await get_user_by_id(user_id)
```

#### **Rate Limiting Implementation**
```python
# Rate limiting in backend/app/middleware/rate_limiting.py
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)

@limiter.limit("100/minute")
async def chat_endpoint(request: Request, ...):
    # Endpoint implementation
    pass
```

#### **Input Sanitization**
```python
# Security validation in backend/app/validation/security_validation.py
import bleach
from app.security.security_validator import SecurityValidator

class InputSanitizer:
    @staticmethod
    def sanitize_html(content: str) -> str:
        return bleach.clean(
            content,
            tags=['p', 'br', 'strong', 'em', 'u'],
            attributes={}
        )
    
    @staticmethod
    def validate_file_upload(file: UploadFile) -> bool:
        # Validate file type and size
        allowed_extensions = ['.pdf', '.docx', '.txt', '.md']
        file_extension = Path(file.filename).suffix.lower()
        return file_extension in allowed_extensions
```

### 🔄 WebSocket Implementation

#### **WebSocket Manager**
```python
# backend/app/api/websocket.py
from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List
import json
import uuid

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        self.active_connections[client_id] = websocket
    
    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]
    
    async def send_personal_message(self, message: str, client_id: str):
        if client_id in self.active_connections:
            await self.active_connections[client_id].send_text(message)

manager = ConnectionManager()

@websocket.websocket_route("/ws")
async def websocket_endpoint(websocket: WebSocket):
    client_id = str(uuid.uuid4())
    await manager.connect(websocket, client_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            # Process message through agent
            response = await process_chat_message(message_data)
            
            # Send response back
            await manager.send_personal_message(
                json.dumps(response), 
                client_id
            )
            
    except WebSocketDisconnect:
        manager.disconnect(client_id)
```

---

## 🤖 AI Agent System Deep Dive

### 🧠 Custom Agent Orchestrator Architecture

#### **Core Agent Implementation**
```python
# backend/app/agents/chat_agent.py - CustomerSupportAgent class
class CustomerSupportAgent:
    """
    Custom AI agent orchestrator that manages the logic flow for processing
    user messages and generating intelligent responses. This is the core
    of the application - NOT a black-box framework.
    """
    
    def __init__(self):
        self.tool_registry = ToolRegistry()
        self.state_manager = AgentStateManager()
        self.memory_manager = MemoryManager()
        self.metrics_collector = MetricsCollector()
        self._initialize_tools()
    
    async def process_message(self, context: AgentContext) -> AgentResponse:
        """
        Main message processing pipeline:
        1. Intent detection
        2. Tool selection
        3. Tool execution
        4. Response generation
        5. Memory update
        """
        
        # Update agent state
        context.agent_state = AgentState.PROCESSING
        
        try:
            # Step 1: Intent detection
            intent = await self.detect_intent(context)
            
            # Step 2: Tool selection
            selected_tools = await self.select_tools(intent, context)
            
            # Step 3: Execute tools in sequence
            tool_results = await self.execute_tools(selected_tools, context)
            
            # Step 4: Generate response
            response = await self.generate_response(tool_results, context)
            
            # Step 5: Update memory and state
            await self.update_memory(context, response)
            context.agent_state = AgentState.IDLE
            
            return response
            
        except Exception as e:
            context.agent_state = AgentState.ERROR
            logger.error(f"Agent processing error: {str(e)}", exc_info=True)
            return await self.handle_error(e, context)
    
    async def detect_intent(self, context: AgentContext) -> str:
        """Detect user intent from message content."""
        message = context.message_history[-1]["content"]
        
        # Intent classification using LLM
        intent_prompt = f"""
        Classify the user intent for this customer support message:
        Message: "{message}"
        
        Possible intents: greeting, question, complaint, technical_support, 
        billing_inquiry, product_info, escalation_request, file_upload, goodbye
        
        Return only the intent name.
        """
        
        llm_response = await self.llm_service.generate(intent_prompt)
        return llm_response.content.strip().lower()
    
    async def select_tools(self, intent: str, context: AgentContext) -> List[BaseTool]:
        """Select appropriate tools based on intent and context."""
        selected_tools = []
        
        # Always start with memory tool
        selected_tools.append(self.tool_registry.get_tool("memory_tool"))
        
        # Add tools based on intent
        if intent == "question" or intent == "technical_support":
            selected_tools.append(self.tool_registry.get_tool("rag_tool"))
        
        if intent == "escalation_request" or context.escalation_level > 2:
            selected_tools.append(self.tool_registry.get_tool("escalation_tool"))
        
        if context.current_file_attachments:
            selected_tools.append(self.tool_registry.get_tool("attachment_tool"))
        
        return [tool for tool in selected_tools if tool is not None]
```

#### **Agent Context Management**
```python
# Agent context definition for conversation state
@dataclass
class AgentContext:
    """Enhanced context for the agent conversation."""
    session_id: str
    user_id: str
    message_history: List[Dict[str, Any]] = field(default_factory=list)
    current_file_attachments: List[str] = field(default_factory=list)
    escalation_level: int = 0
    agent_state: AgentState = AgentState.IDLE
    current_step: str = ""
    context_data: Dict[str, Any] = field(default_factory=dict)
    tools_used: List[str] = field(default_factory=list)
    escalation_type: EscalationType = EscalationType.NONE
    user_intent: Optional[str] = None
    conversation_turn: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_activity: datetime = field(default_factory=datetime.utcnow)
```

### 🛠️ Tool System Implementation

#### **Base Tool Interface**
```python
# backend/app/tools/base_tool.py
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from enum import Enum

class ToolStatus(str, Enum):
    """Tool execution status."""
    PENDING = "pending"
    RUNNING = "running" 
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

class BaseTool(ABC):
    """Base class for all agent tools."""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.status = ToolStatus.PENDING
        self.execution_time = 0.0
        self.metrics = {}
    
    @abstractmethod
    async def execute(self, context: AgentContext) -> Dict[str, Any]:
        """Execute the tool's primary function."""
        pass
    
    @abstractmethod
    def can_handle(self, intent: str, context: AgentContext) -> bool:
        """Determine if this tool can handle the given intent."""
        pass
    
    async def pre_execute(self, context: AgentContext) -> bool:
        """Pre-execution validation and setup."""
        self.status = ToolStatus.RUNNING
        start_time = time.time()
        
        try:
            # Pre-execution logic (validation, setup, etc.)
            return True
        except Exception as e:
            self.status = ToolStatus.FAILED
            logger.error(f"Tool {self.name} pre-execution failed: {str(e)}")
            return False
    
    async def post_execute(self, context: AgentContext, result: Dict[str, Any]):
        """Post-execution cleanup and metric collection."""
        self.status = ToolStatus.COMPLETED
        self.execution_time = time.time() - getattr(self, '_start_time', time.time())
        
        # Update metrics
        self.metrics.update({
            'execution_time': self.execution_time,
            'status': self.status.value,
            'timestamp': datetime.utcnow().isoformat()
        })
        
        # Log execution
        logger.info(f"Tool {self.name} completed in {self.execution_time:.3f}s")
```

#### **Tool Registry Implementation**
```python
# backend/app/tools/tool_registry.py
class ToolRegistry:
    """Central registry for all agent tools."""
    
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._tool_intents: Dict[str, List[str]] = {}
    
    def register_tool(self, tool: BaseTool):
        """Register a tool with the registry."""
        self._tools[tool.name] = tool
        
        # Update intent mapping
        for intent in self._get_supported_intents(tool):
            if intent not in self._tool_intents:
                self._tool_intents[intent] = []
            self._tool_intents[intent].append(tool.name)
        
        logger.info(f"Registered tool: {tool.name}")
    
    def get_tool(self, tool_name: str) -> Optional[BaseTool]:
        """Get a tool by name."""
        return self._tools.get(tool_name)
    
    def get_tools_for_intent(self, intent: str) -> List[BaseTool]:
        """Get all tools that can handle a specific intent."""
        tool_names = self._tool_intents.get(intent, [])
        return [self._tools[name] for name in tool_names if name in self._tools]
    
    def list_tools(self) -> Dict[str, str]:
        """List all registered tools with descriptions."""
        return {name: tool.description for name, tool in self._tools.items()}
```

### 🔧 Core Tool Implementations

#### **RAG Tool (Knowledge Retrieval)**
```python
# backend/app/tools/rag_tool.py
class RAGTool(BaseTool):
    """Retrieval-Augmented Generation tool for knowledge-based responses."""
    
    def __init__(self):
        super().__init__(
            name="rag_tool",
            description="Retrieval-Augmented Generation for knowledge-based responses"
        )
        self.embedding_service = EmbeddingService()
        self.vector_store = ChromaDBManager()
        self.cache = RedisCache()
    
    async def execute(self, context: AgentContext) -> Dict[str, Any]:
        """Execute RAG pipeline: retrieve relevant documents and generate response."""
        
        # Get latest user message
        latest_message = context.message_history[-1]["content"]
        
        # Check cache first
        cache_key = f"rag:{hash(latest_message)}"
        cached_result = await self.cache.get(cache_key)
        if cached_result:
            return cached_result
        
        # Generate embedding for query
        query_embedding = await self.embedding_service.generate_embedding(latest_message)
        
        # Search vector store
        search_results = await self.vector_store.search(
            query_embedding=query_embedding,
            top_k=settings.rag_top_k,
            threshold=settings.rag_similarity_threshold
        )
        
        # Format context for LLM
        context_text = self._format_retrieved_content(search_results)
        
        # Generate response using LLM with retrieved context
        prompt = f"""
        You are a helpful customer support agent. Use the following context 
        to answer the user's question accurately and helpfully.
        
        Context: {context_text}
        
        User Question: {latest_message}
        
        Provide a helpful, accurate response based on the context above.
        """
        
        response = await self.llm_service.generate(prompt)
        
        result = {
            "response": response.content,
            "sources": [doc['metadata'] for doc in search_results],
            "confidence": self._calculate_confidence(search_results),
            "tool_used": "rag_tool"
        }
        
        # Cache result
        await self.cache.set(cache_key, result, ttl=3600)
        
        return result
    
    def can_handle(self, intent: str, context: AgentContext) -> bool:
        """RAG tool handles knowledge-based questions."""
        return intent in ["question", "technical_support", "product_info", "billing_inquiry"]
```

#### **Memory Tool (Conversation Persistence)**
```python
# backend/app/tools/memory_tool.py
class MemoryTool(BaseTool):
    """Conversation memory management tool."""
    
    def __init__(self):
        super().__init__(
            name="memory_tool",
            description="Manages conversation memory and context"
        )
        self.memory_store = SQLiteMemoryStore()
        self.context_compressor = ContextCompressor()
    
    async def execute(self, context: AgentContext) -> Dict[str, Any]:
        """Manage conversation memory and context."""
        
        # Store current message in memory
        await self.memory_store.store_message(
            session_id=context.session_id,
            message=context.message_history[-1],
            metadata={
                'turn_number': context.conversation_turn,
                'tools_used': context.tools_used,
                'escalation_level': context.escalation_level
            }
        )
        
        # Retrieve relevant conversation history
        recent_messages = await self.memory_store.get_recent_messages(
            session_id=context.session_id,
            limit=10
        )
        
        # Compress context if too long
        compressed_context = await self.context_compressor.compress_context(
            messages=recent_messages,
            max_tokens=2000
        )
        
        # Update context data
        context.context_data.update({
            'conversation_history': compressed_context,
            'message_count': len(recent_messages),
            'total_interactions': await self.memory_store.get_session_message_count(
                session_id=context.session_id
            )
        })
        
        return {
            "context_updated": True,
            "message_count": len(recent_messages),
            "context_length": len(compressed_context),
            "tool_used": "memory_tool"
        }
    
    def can_handle(self, intent: str, context: AgentContext) -> bool:
        """Memory tool handles all conversations."""
        return True
```

#### **Attachment Tool (File Processing)**
```python
# backend/app/tools/attachment_tool.py
class AttachmentTool(BaseTool):
    """File attachment processing tool."""
    
    def __init__(self):
        super().__init__(
            name="attachment_tool",
            description="Processes uploaded file attachments"
        )
        self.file_processor = MultiFormatProcessor()
        self.vector_store = ChromaDBManager()
        self.embedding_service = EmbeddingService()
    
    async def execute(self, context: AgentContext) -> Dict[str, Any]:
        """Process uploaded file attachments."""
        
        if not context.current_file_attachments:
            return {"no_attachments": True, "tool_used": "attachment_tool"}
        
        processed_files = []
        
        for file_path in context.current_file_attachments:
            try:
                # Process file based on type
                file_type = self._detect_file_type(file_path)
                
                if file_type == "document":
                    # Extract text content
                    text_content = await self.file_processor.extract_text(file_path)
                    
                    # Generate embeddings
                    embeddings = await self.embedding_service.generate_embedding(text_content)
                    
                    # Store in vector database
                    await self.vector_store.add_document(
                        content=text_content,
                        embedding=embeddings,
                        metadata={
                            'file_path': file_path,
                            'session_id': context.session_id,
                            'file_type': file_type
                        }
                    )
                    
                    processed_files.append({
                        'file_path': file_path,
                        'type': file_type,
                        'processed': True,
                        'text_length': len(text_content)
                    })
                
                elif file_type == "image":
                    # Process image for OCR
                    ocr_text = await self.file_processor.extract_text_from_image(file_path)
                    
                    processed_files.append({
                        'file_path': file_path,
                        'type': file_type,
                        'processed': True,
                        'ocr_text_length': len(ocr_text)
                    })
                
            except Exception as e:
                logger.error(f"Failed to process file {file_path}: {str(e)}")
                processed_files.append({
                    'file_path': file_path,
                    'type': file_type,
                    'processed': False,
                    'error': str(e)
                })
        
        return {
            "files_processed": processed_files,
            "total_files": len(context.current_file_attachments),
            "successful_processing": len([f for f in processed_files if f.get('processed')]),
            "tool_used": "attachment_tool"
        }
    
    def can_handle(self, intent: str, context: AgentContext) -> bool:
        """Attachment tool handles file uploads."""
        return len(context.current_file_attachments) > 0
```

#### **Escalation Tool (Human Handoff)**
```python
# backend/app/tools/escalation_tool.py
class EscalationTool(BaseTool):
    """Human agent escalation tool."""
    
    def __init__(self):
        super().__init__(
            name="escalation_tool",
            description="Handles escalation to human agents"
        )
        self.escalation_rules = EscalationRuleEngine()
        self.notification_service = NotificationService()
    
    async def execute(self, context: AgentContext) -> Dict[str, Any]:
        """Handle escalation to human agents."""
        
        # Determine escalation type and priority
        escalation_info = await self.escalation_rules.determine_escalation(
            context=context
        )
        
        # Create escalation ticket
        ticket_id = await self.create_escalation_ticket(
            session_id=context.session_id,
            escalation_info=escalation_info,
            conversation_summary=await self.summarize_conversation(context)
        )
        
        # Notify human agents
        await self.notification_service.notify_agents(
            ticket_id=ticket_id,
            escalation_info=escalation_info
        )
        
        # Update context
        context.escalation_level = escalation_info['priority']
        context.escalation_type = escalation_info['type']
        
        return {
            "escalated": True,
            "ticket_id": ticket_id,
            "escalation_type": escalation_info['type'],
            "estimated_response_time": escalation_info['estimated_response_time'],
            "tool_used": "escalation_tool"
        }
    
    def can_handle(self, intent: str, context: AgentContext) -> bool:
        """Escalation tool handles complex or escalated situations."""
        escalation_triggers = [
            "escalation_request", 
            "complaint",
            "billing_issue_complex",
            "technical_issue_complex"
        ]
        
        # Auto-escalate if conversation is too long or complex
        return (intent in escalation_triggers or 
                context.conversation_turn > 10 or
                context.escalation_level > 0)
```

### 📊 Agent Monitoring & Metrics

#### **Performance Monitoring**
```python
# backend/app/agents/agent_monitoring.py
class AgentMetricsCollector:
    """Collects and reports agent performance metrics."""
    
    def __init__(self):
        self.metrics_store = MetricsStore()
        self.prometheus_client = PrometheusClient()
    
    async def record_agent_execution(self, context: AgentContext, execution_time: float):
        """Record agent execution metrics."""
        
        metrics = {
            'agent_execution_time': execution_time,
            'agent_state': context.agent_state.value,
            'conversation_turn': context.conversation_turn,
            'tools_used_count': len(context.tools_used),
            'escalation_level': context.escalation_level,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        # Store in metrics database
        await self.metrics_store.store_metrics(context.session_id, metrics)
        
        # Update Prometheus metrics
        self.prometheus_client.histogram('agent_execution_time').observe(execution_time)
        self.prometheus_client.counter('agent_messages_processed').inc()
        
        # Log metrics
        logger.info(f"Agent metrics recorded for session {context.session_id}")
    
    async def get_agent_performance_report(self, time_range: str) -> Dict[str, Any]:
        """Generate performance report for agent operations."""
        
        return await self.metrics_store.aggregate_metrics({
            'average_response_time': 'avg',
            'total_messages': 'count',
            'escalation_rate': 'sum',
            'tool_usage_stats': 'histogram'
        }, time_range)
```

---

## ⚙️ Development Workflows & Procedures

### 🔄 Feature Development Workflow

#### **Step-by-Step Feature Development**
```bash
#!/bin/bash
# Feature development workflow script

# 1. Create feature branch
git checkout -b feature/add-advanced-rag

# 2. Setup development environment
./scripts/setup.sh

# 3. Create feature branch structure
mkdir -p backend/app/features/advanced_rag
touch backend/app/features/advanced_rag/__init__.py
touch backend/app/features/advanced_rag/enhanced_rag_tool.py
touch backend/app/features/advanced_rag/semantic_search.py
touch backend/tests/unit/features/test_advanced_rag.py

# 4. Implement feature
# Edit files in backend/app/features/advanced_rag/

# 5. Write tests
# Edit backend/tests/unit/features/test_advanced_rag.py

# 6. Run tests
./scripts/test.sh unit
./scripts/test.sh integration

# 7. Update documentation
# Update relevant .md files

# 8. Commit changes
git add .
git commit -m "feat: add advanced RAG with semantic search capabilities"

# 9. Push and create PR
git push origin feature/add-advanced-rag
```

#### **Code Standards & Patterns**
```python
# Example implementation following project patterns
# backend/app/features/advanced_rag/enhanced_rag_tool.py

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.tools.base_tool import BaseTool, ToolStatus
from app.config import settings
from app.services.embedding_service import EmbeddingService
from app.services.vector_store_service import VectorStoreService
from app.utils.validation_utils import validate_input

logger = logging.getLogger(__name__)

class EnhancedRAGTool(BaseTool):
    """Enhanced RAG tool with advanced semantic search capabilities."""
    
    def __init__(self):
        super().__init__(
            name="enhanced_rag_tool",
            description="Advanced RAG with semantic search and context ranking"
        )
        self.embedding_service = EmbeddingService()
        self.vector_store = VectorStoreService()
        self.cache = settings.get_redis_client()
    
    async def execute(self, context: "AgentContext") -> Dict[str, Any]:
        """Execute enhanced RAG pipeline with semantic search."""
        
        # Input validation
        if not await validate_input(context.message_history[-1]["content"]):
            raise ValueError("Invalid input detected")
        
        # Pre-execution setup
        self.status = ToolStatus.RUNNING
        start_time = datetime.utcnow()
        
        try:
            # Extract and process query
            query = context.message_history[-1]["content"]
            
            # Generate multi-vector embedding
            query_vectors = await self.embedding_service.generate_multi_vector(query)
            
            # Perform semantic search with context ranking
            search_results = await self.vector_store.semantic_search(
                query_vectors=query_vectors,
                context_window=5,
                similarity_threshold=0.7,
                include_metadata=True
            )
            
            # Rank and filter results
            ranked_results = await self.rank_results(search_results, context)
            
            # Generate response with citations
            response = await self.generate_cited_response(ranked_results, query)
            
            # Post-processing
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            
            result = {
                "response": response.content,
                "citations": response.citations,
                "confidence_score": response.confidence,
                "sources_used": len(ranked_results),
                "execution_time": execution_time,
                "tool_used": "enhanced_rag_tool",
                "search_metadata": {
                    "query_type": response.query_type,
                    "semantic_similarity": response.avg_similarity,
                    "context_relevance": response.context_score
                }
            }
            
            self.status = ToolStatus.COMPLETED
            return result
            
        except Exception as e:
            self.status = ToolStatus.FAILED
            logger.error(f"Enhanced RAG execution failed: {str(e)}", exc_info=True)
            raise
    
    async def rank_results(self, results: List[Dict], context: "AgentContext") -> List[Dict]:
        """Rank search results based on relevance and context."""
        # Implementation of advanced ranking algorithm
        pass
    
    async def generate_cited_response(self, results: List[Dict], query: str) -> "CitationResponse":
        """Generate response with proper citations."""
        # Implementation of citation generation
        pass
```

### 🐛 Bug Fix Workflow

#### **Bug Investigation Process**
```bash
#!/bin/bash
# Bug investigation workflow

# 1. Gather information
echo "Bug ID: $1"
echo "Description: $2"

# 2. Reproduce the issue
./scripts/start.sh
# Test the specific functionality

# 3. Check logs
docker-compose logs backend | grep ERROR
docker-compose logs backend | grep -A5 -B5 "error_pattern"

# 4. Check metrics
curl http://localhost:8000/metrics | grep -i error

# 5. Database investigation
docker-compose exec postgres psql -U postgres -d customer_support
# SQL queries to check data consistency

# 6. Generate fix
# Edit relevant files

# 7. Test fix
./scripts/test.sh unit
./scripts/test.sh integration

# 8. Validate fix
# Manual testing of the specific bug scenario
```

#### **Error Handling Patterns**
```python
# backend/app/utils/error_handling.py
import logging
import traceback
from datetime import datetime
from typing import Any, Dict, Optional
from fastapi import HTTPException, status

logger = logging.getLogger(__name__)

class ErrorHandler:
    """Centralized error handling for the application."""
    
    @staticmethod
    async def handle_agent_error(error: Exception, context: "AgentContext") -> Dict[str, Any]:
        """Handle agent processing errors gracefully."""
        
        error_info = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "timestamp": datetime.utcnow().isoformat(),
            "session_id": context.session_id,
            "traceback": traceback.format_exc()
        }
        
        # Log error with context
        logger.error(
            f"Agent processing error in session {context.session_id}: {str(error)}",
            extra=error_info
        )
        
        # Send error metrics
        await ErrorHandler.send_error_metrics(error_info)
        
        # Return user-friendly error response
        return {
            "response": "I apologize, but I encountered a technical issue while processing your request. Please try again or contact support if the problem persists.",
            "error": True,
            "error_code": "AGENT_PROCESSING_ERROR",
            "session_id": context.session_id,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    @staticmethod
    async def handle_api_error(error: Exception) -> HTTPException:
        """Handle API errors with proper HTTP status codes."""
        
        if isinstance(error, ValueError):
            return HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid request: {str(error)}"
            )
        
        elif isinstance(error, KeyError):
            return HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Missing required field: {str(error)}"
            )
        
        elif isinstance(error, PermissionError):
            return HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        
        else:
            logger.error(f"Unexpected API error: {str(error)}", exc_info=True)
            return HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )

class CircuitBreaker:
    """Circuit breaker for external service calls."""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    async def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection."""
        
        if self.state == "OPEN":
            if self._should_attempt_reset():
                self.state = "HALF_OPEN"
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
            
        except Exception as e:
            self._on_failure()
            raise e
    
    def _on_success(self):
        """Handle successful function call."""
        self.failure_count = 0
        self.state = "CLOSED"
    
    def _on_failure(self):
        """Handle failed function call."""
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()
        
        if self.failure_count >= self.failure_threshold:
            self.state = "OPEN"
    
    def _should_attempt_reset(self) -> bool:
        """Check if circuit breaker should attempt reset."""
        if not self.last_failure_time:
            return False
        
        time_since_failure = (datetime.utcnow() - self.last_failure_time).total_seconds()
        return time_since_failure >= self.recovery_timeout
```

### 🧪 Testing Procedures

#### **Testing Architecture**
```python
# backend/tests/conftest.py - pytest configuration
import pytest
import asyncio
from typing import AsyncGenerator
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.main import app
from app.database import get_db, AsyncSessionLocal
from app.agents.chat_agent import CustomerSupportAgent
from app.tools.tool_registry import ToolRegistry

@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
async def db() -> AsyncGenerator[AsyncSession, None]:
    """Create a test database session."""
    async with AsyncSessionLocal() as session:
        yield session

@pytest.fixture
def client() -> TestClient:
    """Create a test client for the FastAPI application."""
    return TestClient(app)

@pytest.fixture
async def agent() -> CustomerSupportAgent:
    """Create a test agent instance."""
    return CustomerSupportAgent()

@pytest.fixture
async def tool_registry() -> ToolRegistry:
    """Create a test tool registry."""
    registry = ToolRegistry()
    # Register test tools
    return registry

# Example test implementation
# backend/tests/unit/test_chat_agent.py
import pytest
from unittest.mock import Mock, AsyncMock

from app.agents.chat_agent import CustomerSupportAgent, AgentContext, AgentState
from app.tools.memory_tool import MemoryTool

class TestCustomerSupportAgent:
    
    @pytest.fixture
    async def agent(self):
        return CustomerSupportAgent()
    
    @pytest.fixture
    def sample_context(self):
        return AgentContext(
            session_id="test-session-123",
            user_id="test-user-456",
            message_history=[
                {
                    "content": "Hello, how can you help me?",
                    "role": "user",
                    "timestamp": "2025-01-01T00:00:00Z"
                }
            ]
        )
    
    async def test_agent_initialization(self, agent):
        """Test agent initializes correctly."""
        assert agent is not None
        assert len(agent.tool_registry.list_tools()) > 0
        assert agent.state_manager is not None
    
    async def test_process_message_greeting(self, agent, sample_context):
        """Test processing a simple greeting message."""
        # Arrange
        expected_response = "Hello! How can I assist you today?"
        
        # Act
        response = await agent.process_message(sample_context)
        
        # Assert
        assert response is not None
        assert isinstance(response.response, str)
        assert len(response.response) > 0
        assert sample_context.agent_state == AgentState.IDLE
    
    async def test_intent_detection(self, agent, sample_context):
        """Test intent detection functionality."""
        # Test different message types
        test_cases = [
            ("Hello", "greeting"),
            ("How do I reset my password?", "question"),
            ("I want to speak to a manager", "escalation_request"),
            ("This product is terrible", "complaint")
        ]
        
        for message, expected_intent in test_cases:
            sample_context.message_history[-1]["content"] = message
            intent = await agent.detect_intent(sample_context)
            # Note: This would need mocking the LLM service for deterministic testing
            assert intent is not None
    
    @pytest.mark.asyncio
    async def test_tool_selection(self, agent):
        """Test tool selection based on intent."""
        # This would test the tool selection logic
        pass
    
    @pytest.mark.integration
    async def test_end_to_end_chat_flow(self, agent, db):
        """Test complete chat flow with database."""
        # Integration test that tests the full pipeline
        context = AgentContext(
            session_id="integration-test-session",
            user_id="integration-test-user",
            message_history=[{"content": "What's my order status?", "role": "user"}]
        )
        
        # This would test the full pipeline including database operations
        response = await agent.process_message(context)
        
        assert response is not None
        assert "response" in response
```

#### **Test Automation Scripts**
```bash
#!/bin/bash
# scripts/test.sh - Comprehensive testing automation

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Test categories
run_unit_tests() {
    print_status "Running unit tests..."
    cd backend
    python -m pytest tests/unit/ -v --tb=short
    print_status "Unit tests completed successfully"
}

run_integration_tests() {
    print_status "Running integration tests..."
    cd backend
    python -m pytest tests/integration/ -v --tb=short
    print_status "Integration tests completed successfully"
}

run_e2e_tests() {
    print_status "Running end-to-end tests..."
    cd frontend
    npm run test:e2e
    print_status "E2E tests completed successfully"
}

run_coverage_tests() {
    print_status "Running tests with coverage..."
    cd backend
    python -m pytest tests/ --cov=app --cov-report=html --cov-report=term
    print_status "Coverage report generated"
}

# Main function
main() {
    case "${1:-all}" in
        "unit")
            run_unit_tests
            ;;
        "integration")
            run_integration_tests
            ;;
        "e2e")
            run_e2e_tests
            ;;
        "coverage")
            run_coverage_tests
            ;;
        "all")
            print_status "Running all tests..."
            run_unit_tests
            run_integration_tests
            run_e2e_tests
            print_status "All tests completed successfully"
            ;;
        *)
            echo "Usage: $0 [unit|integration|e2e|coverage|all]"
            exit 1
            ;;
    esac
}

main "$@"
```

### 📚 Code Documentation Standards

#### **Documentation Template**
```python
# backend/app/agents/chat_agent.py - Example documentation
"""
Customer Support Agent Orchestrator System.

This is the core of the application - a custom-built agent orchestrator that manages
the logic flow for processing user messages and generating intelligent responses.
The system includes conversation flow management, tool selection, metrics tracking,
and lifecycle management.

Key Features:
- Custom AI agent orchestrator (not black-box framework)
- Dynamic tool selection based on intent
- Conversation state management
- Performance monitoring and metrics
- Error handling and recovery
- Extensible tool system

Example:
    agent = CustomerSupportAgent()
    context = AgentContext(
        session_id="session-123",
        user_id="user-456",
        message_history=[{"content": "Hello", "role": "user"}]
    )
    response = await agent.process_message(context)

Classes:
    CustomerSupportAgent: Main agent orchestrator
    AgentContext: Conversation context container
    AgentState: Agent lifecycle states
    EscalationType: Types of escalation

Author: Customer Support AI Team
Version: 1.0.0
"""

import logging
import asyncio
import time
import uuid
from typing import List, Dict, Any, Optional, Union, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from contextlib import asynccontextmanager
import json

# Module-level imports and setup
logger = logging.getLogger(__name__)

class CustomerSupportAgent:
    """
    Custom AI agent orchestrator for customer support.
    
    This agent manages the complete conversation flow, including:
    - Intent detection and classification
    - Dynamic tool selection and execution
    - Response generation using LLM
    - Conversation memory management
    - Error handling and recovery
    
    Attributes:
        tool_registry (ToolRegistry): Registry of available tools
        state_manager (AgentStateManager): Agent state management
        memory_manager (MemoryManager): Conversation memory handling
        metrics_collector (MetricsCollector): Performance metrics collection
        
    Example:
        Creating and using the agent:
        
        >>> agent = CustomerSupportAgent()
        >>> context = AgentContext(
        ...     session_id="session-123",
        ...     user_id="user-456",
        ...     message_history=[{"content": "Hello", "role": "user"}]
        ... )
        >>> response = await agent.process_message(context)
        >>> print(response.response)
        "Hello! How can I assist you today?"
        
    Note:
        This is a custom implementation, not using external AI frameworks.
        All logic is transparent and controllable.
    """
    
    def __init__(self):
        """Initialize the agent with all required components."""
        self.tool_registry = ToolRegistry()
        self.state_manager = AgentStateManager()
        self.memory_manager = MemoryManager()
        self.metrics_collector = MetricsCollector()
        self._initialize_tools()
        
        logger.info("CustomerSupportAgent initialized successfully")
    
    async def process_message(self, context: AgentContext) -> AgentResponse:
        """
        Process a user message through the complete agent pipeline.
        
        This method orchestrates the entire conversation flow:
        1. Intent detection
        2. Tool selection
        3. Tool execution
        4. Response generation
        5. Memory update
        6. Metrics collection
        
        Args:
            context (AgentContext): The conversation context including history and metadata
            
        Returns:
            AgentResponse: The generated response with metadata
            
        Raises:
            AgentProcessingError: If any step in the pipeline fails
            ValidationError: If input validation fails
            
        Example:
            >>> context = AgentContext(
            ...     session_id="session-123",
            ...     user_id="user-456", 
            ...     message_history=[{"content": "Help me", "role": "user"}]
            ... )
            >>> response = await agent.process_message(context)
            >>> response.response
            "I'd be happy to help! What do you need assistance with?"
        """
        # Implementation details...
        pass
```

---

## 🏭 Deployment & Operations

### 🐳 Docker Deployment Strategy

#### **Production Docker Configuration**
```dockerfile
# backend/Dockerfile - Production optimized
FROM python:3.11-slim as base

# Set environment variables for production
ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PYTHONPATH="/app:$PYTHONPATH" \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    WORKERS=4 \
    KEEPALIVE=120

# Install system dependencies
RUN apt-get update && apt-get install -y \
    curl \
    build-essential \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/* \
    && apt-get clean

# Create non-root user for security
RUN groupadd -r appuser && useradd -r -g appuser appuser

WORKDIR /app

# Copy and install Python dependencies
COPY requirements.txt* ./
RUN pip install --upgrade pip setuptools wheel && \
    pip install --no-cache-dir -r    CMD curl -f http://localhost:8000/health || exit 1

# Default command with environment variable support
CMD ["sh", "-c", "gunicorn app.main:app -w ${WORKERS:-4} -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 --timeout ${KEEPALIVE:-120} --keep-alive ${KEEPALIVE:-2}"]

# Development stage
FROM base as development
WORKDIR /app

# Copy source code for development
COPY --chown=appuser:appuser . .

# Install development dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Switch to app user
USER appuser

# Expose port for development
EXPOSE 8000

# Development command with hot reload
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload", "--reload-dir", "/app"]
```

### 🚀 Production Deployment Process

#### **Environment Configuration**
```bash
# Production environment setup
export ENVIRONMENT=production
export DATABASE_URL="postgresql://user:password@prod-db:5432/customer_support"
export REDIS_URL="redis://prod-redis:6379/0"
export SECRET_KEY="your-super-secure-secret-key"
export OPENAI_API_KEY="your-openai-api-key"
export ANTHROPIC_API_KEY="your-anthropic-api-key"

# Security settings
export JWT_SECRET_KEY="your-jwt-secret"
export ENCRYPTION_KEY="your-encryption-key"

# Performance settings
export WORKERS=8
export KEEPALIVE=120
export MAX_CONNECTIONS=1000

# Monitoring settings
export PROMETHEUS_ENABLED=true
export GRAFANA_ENABLED=true
export LOG_LEVEL=INFO
```

#### **Deployment Scripts**
```bash
#!/bin/bash
# scripts/deploy.sh - Production deployment automation

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Pre-deployment checks
run_pre_deployment_checks() {
    print_status "Running pre-deployment checks..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed"
        exit 1
    fi
    
    # Check environment variables
    required_vars=("ENVIRONMENT" "DATABASE_URL" "REDIS_URL" "SECRET_KEY")
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            print_error "Required environment variable $var is not set"
            exit 1
        fi
    done
    
    # Run tests
    print_status "Running tests..."
    ./scripts/test.sh unit
    
    print_status "Pre-deployment checks completed successfully"
}

# Build and deploy
build_and_deploy() {
    print_status "Building Docker images..."
    
    # Build backend
    docker build -t customer-support-backend:$VERSION -f backend/Dockerfile .
    
    # Build frontend
    docker build -t customer-support-frontend:$VERSION -f frontend/Dockerfile .
    
    # Tag as latest
    docker tag customer-support-backend:$VERSION customer-support-backend:latest
    docker tag customer-support-frontend:$VERSION customer-support-frontend:latest
    
    print_status "Deploying to production..."
    
    # Use production Docker Compose
    docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
    
    print_status "Deployment completed successfully"
}

# Post-deployment validation
validate_deployment() {
    print_status "Validating deployment..."
    
    # Health checks
    sleep 30  # Wait for services to start
    
    # Backend health
    if curl -f http://localhost:8000/health > /dev/null 2>&1; then
        print_status "✅ Backend: Healthy"
    else
        print_error "❌ Backend: Unhealthy"
        exit 1
    fi
    
    # Database connectivity
    docker-compose exec postgres pg_isready -U postgres > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        print_status "✅ Database: Healthy"
    else
        print_error "❌ Database: Unhealthy"
        exit 1
    fi
    
    # Redis connectivity
    docker-compose exec redis redis-cli ping > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        print_status "✅ Redis: Healthy"
    else
        print_warning "⚠️ Redis: Unhealthy"
    fi
    
    print_status "Deployment validation completed successfully"
}

# Rollback function
rollback_deployment() {
    print_warning "Rolling back to previous version..."
    
    # Stop current deployment
    docker-compose down
    
    # Deploy previous version
    docker tag customer-support-backend:$PREVIOUS_VERSION customer-support-backend:latest
    docker tag customer-support-frontend:$PREVIOUS_VERSION customer-support-frontend:latest
    
    docker-compose up -d
    
    print_status "Rollback completed successfully"
}

# Main deployment function
main() {
    VERSION=${1:-latest}
    
    case "${2:-deploy}" in
        "check")
            run_pre_deployment_checks
            ;;
        "deploy")
            run_pre_deployment_checks
            build_and_deploy
            validate_deployment
            ;;
        "rollback")
            rollback_deployment
            ;;
        *)
            echo "Usage: $0 <version> [check|deploy|rollback]"
            echo "  check   - Run pre-deployment checks only"
            echo "  deploy  - Full deployment (default)"
            echo "  rollback- Rollback to previous version"
            exit 1
            ;;
    esac
}

main "$@"
```

### 📊 Monitoring & Observability

#### **Prometheus Configuration**
```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert-rules/*.yml"

scrape_configs:
  - job_name: 'customer-support-backend'
    static_configs:
      - targets: ['backend:8000']
    metrics_path: '/metrics'
    scrape_interval: 10s

  - job_name: 'postgres-exporter'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis-exporter'
    static_configs:
      - targets: ['redis-exporter:9121']

  - job_name: 'nginx-exporter'
    static_configs:
      - targets: ['nginx-exporter:9113']

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

#### **Grafana Dashboards**
```json
{
  "dashboard": {
    "title": "Customer Support AI Agent",
    "panels": [
      {
        "title": "API Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          },
          {
            "expr": "histogram_quantile(0.50, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "50th percentile"
          }
        ]
      },
      {
        "title": "Agent Processing Time",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(agent_execution_time_seconds_sum[5m]) / rate(agent_execution_time_seconds_count[5m])",
            "legendFormat": "Average execution time"
          }
        ]
      },
      {
        "title": "Message Volume",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(agent_messages_processed_total[5m])",
            "legendFormat": "Messages per second"
          }
        ]
      },
      {
        "title": "Error Rate",
        "type": "singlestat",
        "targets": [
          {
            "expr": "rate(http_requests_total{status=~\"5..\"}[5m]) / rate(http_requests_total[5m])",
            "legendFormat": "Error rate"
          }
        ]
      }
    ]
  }
}
```

#### **Alert Rules**
```yaml
# monitoring/alert-rules/application-alerts.yml
groups:
  - name: customer-support-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value | humanizePercentage }} for the last 5 minutes"

      - alert: HighResponseTime
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High response time detected"
          description: "95th percentile response time is {{ $value }}s"

      - alert: AgentProcessingHigh
        expr: rate(agent_execution_time_seconds_sum[5m]) / rate(agent_execution_time_seconds_count[5m]) > 5
        for: 3m
        labels:
          severity: warning
        annotations:
          summary: "Agent processing is slow"
          description: "Average agent processing time is {{ $value }}s"

      - alert: DatabaseConnectionsHigh
        expr: pg_stat_database_numbackends / pg_settings_max_connections > 0.8
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: "Database connections near limit"
          description: "Database connections are at {{ $value | humanizePercentage }} of maximum"
```

### 🗄️ Database Management

#### **Migration Strategy**
```bash
#!/bin/bash
# backend/scripts/manage_migrations.sh

case "${1:-status}" in
    "status")
        print_status "Checking migration status..."
        alembic current
        alembic history --verbose
        ;;
    "upgrade")
        print_status "Upgrading database to latest..."
        alembic upgrade head
        ;;
    "downgrade")
        print_status "Downgrading database..."
        alembic downgrade -1
        ;;
    "create")
        if [ -z "$2" ]; then
            print_error "Migration name required"
            echo "Usage: $0 create <migration_name>"
            exit 1
        fi
        print_status "Creating migration: $2"
        alembic revision --autogenerate -m "$2"
        ;;
    *)
        echo "Usage: $0 [status|upgrade|downgrade|create] [migration_name]"
        exit 1
        ;;
esac
```

#### **Backup Strategy**
```bash
#!/bin/bash
# scripts/backup.sh - Database backup automation

BACKUP_DIR="/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$TIMESTAMP.sql"

# Create backup directory
mkdir -p $BACKUP_DIR

# PostgreSQL backup
docker-compose exec -T postgres pg_dumpall -U postgres > $BACKUP_FILE

# Compress backup
gzip $BACKUP_FILE

# Keep only last 30 backups
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +30 -delete

print_status "Backup completed: ${BACKUP_FILE}.gz"
```

### 🔒 Security Operations

#### **Security Checklist**
```markdown
## Production Security Checklist

### ✅ Environment Security
- [ ] All secrets stored in environment variables or secure vault
- [ ] SECRET_KEY is cryptographically secure (32+ characters)
- [ ] Database uses strong passwords
- [ ] Redis password configured
- [ ] CORS origins properly configured

### ✅ Application Security
- [ ] JWT tokens have appropriate expiration
- [ ] Rate limiting configured and tested
- [ ] Input validation enabled on all endpoints
- [ ] SQL injection protection active
- [ ] XSS protection enabled
- [ ] CSRF protection configured

### ✅ Infrastructure Security
- [ ] Docker containers run as non-root users
- [ ] File permissions properly set
- [ ] Network segmentation configured
- [ ] SSL/TLS certificates installed
- [ ] Firewall rules configured
- [ ] Log monitoring enabled

### ✅ Monitoring Security
- [ ] Audit logging enabled
- [ ] Security event alerts configured
- [ ] Failed login attempt monitoring
- [ ] API usage monitoring
- [ ] Database access logging
```

#### **Security Scanning**
```bash
#!/bin/bash
# scripts/security_scan.sh

print_status "Running security scans..."

# Container security scan
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
  aquasec/trivy image customer-support-backend:latest

# Dependency vulnerability scan
cd backend
safety check --json

# Code security scan
bandit -r . -f json -o security_report.json

print_status "Security scan completed"
```

---

## 🔧 Troubleshooting & Maintenance

### 🚨 Common Issues & Solutions

#### **Agent Processing Issues**
```bash
# Issue: Agent not responding
# Symptoms: High response times, timeout errors
# Diagnosis:
curl -X POST http://localhost:8000/health/detailed
docker-compose logs backend | grep -i "agent\|error"

# Solutions:
# 1. Check LLM API connectivity
curl -X POST https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "gpt-3.5-turbo", "messages": [{"role": "user", "content": "test"}]}'

# 2. Clear agent cache
docker-compose exec backend python -c "
from app.services.cache_service import clear_agent_cache
clear_agent_cache()
"

# 3. Restart agent components
docker-compose restart backend
```

#### **Database Connection Issues**
```bash
# Issue: Database connection failures
# Symptoms: 500 errors, connection timeouts
# Diagnosis:
docker-compose exec postgres pg_isready -U postgres
docker-compose exec backend python -c "
from app.database import test_connection
test_connection()
"

# Solutions:
# 1. Check database connectivity
docker-compose exec backend python -c "
import asyncpg
import asyncio
async def test_db():
    try:
        conn = await asyncpg.connect('postgresql://postgres:postgres123@postgres:5432/customer_support')
        await conn.execute('SELECT 1')
        await conn.close()
        print('Database connection successful')
    except Exception as e:
        print(f'Database connection failed: {e}')
asyncio.run(test_db())
"

# 2. Reset database connections
docker-compose restart postgres
docker-compose restart backend
```

#### **Memory & Performance Issues**
```bash
# Issue: High memory usage or slow performance
# Symptoms: OOM errors, slow response times
# Diagnosis:
docker stats
curl http://localhost:8000/metrics | grep -E "(memory|cpu)"

# Solutions:
# 1. Clear Redis cache
docker-compose exec redis redis-cli FLUSHALL

# 2. Restart services with memory limits
docker-compose down
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# 3. Check for memory leaks in application logs
docker-compose logs backend | grep -i "memory\|oom"
```

### 🔍 Debugging Procedures

#### **System Debugging Commands**
```bash
# Complete system health check
#!/bin/bash
echo "=== Customer Support AI Agent Debug Report ==="
echo "Timestamp: $(date)"
echo

echo "=== Docker Services Status ==="
docker-compose ps
echo

echo "=== Resource Usage ==="
docker stats --no-stream
echo

echo "=== Backend Health ==="
curl -s http://localhost:8000/health/detailed | jq .
echo

echo "=== Database Status ==="
docker-compose exec -T postgres pg_isready -U postgres
echo

echo "=== Redis Status ==="
docker-compose exec -T redis redis-cli ping
echo

echo "=== Recent Backend Logs ==="
docker-compose logs backend --tail=50
echo

echo "=== Recent Errors ==="
docker-compose logs backend 2>&1 | grep -i error | tail -10
echo

echo "=== API Endpoints Test ==="
echo "Health check:"
curl -s -w "\nHTTP Status: %{http_code}\n" http://localhost:8000/health

echo "Chat test:"
curl -s -w "\nHTTP Status: %{http_code}\n" \
  -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, test message"}' | head -200
```

#### **Agent-Specific Debugging**
```python
# Debug agent processing pipeline
#!/usr/bin/env python3
import asyncio
import logging
from app.agents.chat_agent import CustomerSupportAgent, AgentContext
from app.config import settings

# Enable debug logging
logging.basicConfig(level=logging.DEBUG)

async def debug_agent_processing():
    """Debug agent message processing step by step."""
    
    agent = CustomerSupportAgent()
    
    # Create test context
    context = AgentContext(
        session_id="debug-session",
        user_id="debug-user",
        message_history=[
            {
                "content": "Hello, I need help with my account",
                "role": "user",
                "timestamp": "2025-01-01T00:00:00Z"
            }
        ]
    )
    
    try:
        print("=== Starting Agent Debug ===")
        
        # Step 1: Intent detection
        print("\n1. Detecting intent...")
        intent = await agent.detect_intent(context)
        print(f"Detected intent: {intent}")
        
        # Step 2: Tool selection
        print("\n2. Selecting tools...")
        selected_tools = await agent.select_tools(intent, context)
        print(f"Selected tools: {[tool.name for tool in selected_tools]}")
        
        # Step 3: Execute tools
        print("\n3. Executing tools...")
        for i, tool in enumerate(selected_tools):
            print(f"  Executing tool {i+1}: {tool.name}")
            result = await tool.execute(context)
            print(f"  Tool result: {result}")
        
        # Step 4: Generate response
        print("\n4. Generating response...")
        # This would require mocking the LLM service
        
        print("\n=== Agent Debug Complete ===")
        
    except Exception as e:
        print(f"Agent debug failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(debug_agent_processing())
```

### 🔄 Maintenance Procedures

#### **Regular Maintenance Tasks**
```bash
#!/bin/bash
# scripts/maintenance.sh - Regular maintenance automation

print_status "Starting maintenance procedures..."

# Database maintenance
print_status "Running database maintenance..."
docker-compose exec postgres psql -U postgres -d customer_support -c "
VACUUM ANALYZE;
REINDEX DATABASE customer_support;
"

# Redis maintenance
print_status "Running Redis maintenance..."
docker-compose exec redis redis-cli --rdb /tmp/dump.rdb
docker-compose exec redis redis-cli --slaveof no one
docker-compose exec redis redis-cli FLUSHDB
docker-compose exec redis redis-cli --slaveof localhost 6379

# Log rotation
print_status "Rotating logs..."
find ./logs -name "*.log" -mtime +7 -exec gzip {} \;
find ./logs -name "*.log.gz" -mtime +30 -delete

# Cache cleanup
print_status "Cleaning application cache..."
docker-compose exec backend python -c "
from app.services.cache_service import cleanup_cache
cleanup_cache()
"

# Backup verification
print_status "Verifying backups..."
LATEST_BACKUP=$(ls -t /backups/backup_*.sql.gz | head -1)
if [ -f "$LATEST_BACKUP" ]; then
    gunzip -t "$LATEST_BACKUP"
    if [ $? -eq 0 ]; then
        print_status "Latest backup is valid: $(basename $LATEST_BACKUP)"
    else
        print_error "Latest backup is corrupted!"
    fi
else
    print_error "No backups found!"
fi

# Security scan
print_status "Running security scan..."
./scripts/security_scan.sh

print_status "Maintenance procedures completed"
```

#### **Performance Optimization**
```bash
# Database performance optimization
print_status "Optimizing database performance..."

# Update table statistics
docker-compose exec postgres psql -U postgres -d customer_support -c "
ANALYZE;

-- Update table statistics for better query planning
SELECT tablename FROM pg_tables WHERE schemaname = 'public';

-- Check for missing indexes
SELECT schemaname, tablename, attname, n_distinct, correlation 
FROM pg_stats 
WHERE schemaname = 'public' 
  AND n_distinct > 100 
ORDER BY n_distinct DESC;
"

# Application performance tuning
print_status "Tuning application performance..."

# Clear old sessions
docker-compose exec backend python -c "
from app.services.session_service import cleanup_old_sessions
cleanup_old_sessions(days_old=7)
"

# Optimize embedding cache
docker-compose exec backend python -c "
from app.services.embedding_service import optimize_embedding_cache
optimize_embedding_cache()
"

# Database connection pool tuning
echo "Current connection pool settings:"
docker-compose exec backend python -c "
from app.config import settings
print(f'Max connections: {settings.database_pool_size}')
print(f'Min connections: {settings.database_pool_min_size}')
"
```

### 📋 Operational Runbooks

#### **Incident Response Procedure**
```markdown
# Incident Response Runbook

## Severity Levels
- **P0 (Critical)**: Service down, data loss, security breach
- **P1 (High)**: Major functionality impaired, performance severely degraded
- **P2 (Medium)**: Minor functionality issues, performance degradation
- **P3 (Low)**: Cosmetic issues, minor bugs

## Response Timeline
- **P0**: Immediate response (< 15 minutes)
- **P1**: 1 hour response
- **P2**: 4 hour response
- **P3**: Next business day

## Escalation Process
1. On-call engineer responds immediately
2. Incident commander assigned within 15 minutes
3. Stakeholder notification within 30 minutes
4. Regular status updates every 30 minutes
5. Post-incident review within 48 hours

## Communication Channels
- **Primary**: Slack #incidents channel
- **Secondary**: PagerDuty alerts
- **External**: Status page updates
```

#### **Disaster Recovery Plan**
```markdown
# Disaster Recovery Plan

## Recovery Objectives
- **RTO** (Recovery Time Objective): 2 hours
- **RPO** (Recovery Point Objective): 15 minutes

## Backup Strategy
- **Database**: Point-in-time recovery with WAL archiving
- **Files**: Daily full backup + 15-minute incremental
- **Configuration**: Version controlled in Git
- **Embeddings**: Weekly full rebuild capability

## Recovery Steps
1. Activate incident response team
2. Assess damage and determine recovery scope
3. Activate backup systems
4. Restore data from backups
5. Validate system functionality
6. Gradually restore service
7. Monitor for stability
8. Declare service recovery

## Contact Information
- **Technical Lead**: [contact info]
- **DBA**: [contact info]
- **Security Officer**: [contact info]
- **Management**: [contact info]
```

---

## 📚 Additional Resources

### 🔗 Key Documentation Links
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Documentation](https://react.dev/)
- [ChromaDB Documentation](https://docs.trychroma.com/)
- [SentenceTransformers Documentation](https://www.sbert.net/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)

### 🎯 Development Tools & References
- **API Testing**: Postman collections, curl examples
- **Database Tools**: pgAdmin, Redis CLI, ChromaDB Dashboard
- **Monitoring**: Grafana dashboards, Prometheus queries
- **Debugging**: VS Code debugger, Docker logs, application metrics
- **Performance**: Apache Bench, LoadRunner, monitoring dashboards

### 🏆 Success Metrics & KPIs
- **Response Time**: < 2 seconds average, < 5 seconds 95th percentile
- **Availability**: 99.9% uptime target
- **Accuracy**: > 90% customer satisfaction
- **Scalability**: 1000+ concurrent conversations
- **Error Rate**: < 1% error rate
- **Throughput**: 100+ messages per minute per instance

---

## 🎉 Conclusion

This comprehensive technical briefing provides AI coding agents with all the essential knowledge to effectively work on the Customer Support AI Agent system. The documentation covers:

✅ **Complete Architecture Understanding** - From high-level system overview to detailed component interactions

✅ **Development Readiness** - Setup procedures, debugging tools, and workflow patterns

✅ **Operational Excellence** - Deployment procedures, monitoring, and maintenance practices

✅ **Security Best Practices** - Authentication, authorization, and security hardening procedures

✅ **Troubleshooting Guide** - Common issues, debugging procedures, and recovery plans

The Customer Support AI Agent is a sophisticated, production-ready system built with modern best practices and enterprise-grade reliability. Its custom AI agent orchestrator provides unprecedented control and transparency compared to black-box solutions, making it ideal for development, extension, and maintenance.

**Happy Coding! 🚀**

---

*Last Updated: November 2025*  
*Version: 1.0.0*  
*Document Type: Technical Briefing for AI Coding Agents*