/**
 * Service Worker for Customer Support AI Frontend

Provides offline functionality, caching, background sync, and push notifications.
 */

const CACHE_NAME = 'customer-support-ai-v1';
const STATIC_CACHE = 'static-v1';
const DYNAMIC_CACHE = 'dynamic-v1';
const API_CACHE = 'api-v1';

// Files to cache for offline functionality
const STATIC_FILES = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json',
  '/favicon.ico',
];

// API endpoints to cache
const API_ENDPOINTS = [
  '/api/v1/chat',
  '/api/v1/sessions',
  '/api/v1/config',
  '/health',
];

// Install event - cache static files
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('Service Worker: Caching static files');
        return cache.addAll(STATIC_FILES);
      })
      .then(() => {
        console.log('Service Worker: Static files cached');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Failed to cache static files:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== STATIC_CACHE && 
                cacheName !== DYNAMIC_CACHE && 
                cacheName !== API_CACHE) {
              console.log('Service Worker: Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Activated');
        return self.clients.claim();
      })
  );
});

// Fetch event - handle requests with different strategies
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Handle API requests
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(handleApiRequest(request));
    return;
  }

  // Handle navigation requests (SPA)
  if (request.mode === 'navigate') {
    event.respondWith(handleNavigationRequest(request));
    return;
  }

  // Handle static assets
  if (request.destination === 'script' || 
      request.destination === 'style' || 
      request.destination === 'image') {
    event.respondWith(handleStaticAsset(request));
    return;
  }
});

// Handle API requests with cache-first strategy for GET requests
async function handleApiRequest(request) {
  const { method } = request;

  // For GET requests, try cache first, then network
  if (method === 'GET') {
    try {
      const cachedResponse = await caches.match(request);
      if (cachedResponse) {
        console.log('Service Worker: Serving from cache:', request.url);
        return cachedResponse;
      }

      console.log('Service Worker: Fetching from network:', request.url);
      const networkResponse = await fetch(request);
      
      if (networkResponse.ok) {
        const cache = await caches.open(API_CACHE);
        cache.put(request, networkResponse.clone());
      }
      
      return networkResponse;
    } catch (error) {
      console.error('Service Worker: API request failed:', error);
      
      // Try to serve from cache even if stale
      const cachedResponse = await caches.match(request);
      if (cachedResponse) {
        return cachedResponse;
      }
      
      // Return offline response for critical endpoints
      return new Response(
        JSON.stringify({ 
          error: 'Offline - data not available',
          offline: true 
        }),
        { 
          status: 503,
          statusText: 'Service Unavailable',
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }
  }

  // For POST/PUT/DELETE requests, use network only
  // Queue for background sync if offline
  try {
    const response = await fetch(request);
    return response;
  } catch (error) {
    console.log('Service Worker: Request failed, queuing for background sync');
    
    // Store failed request for background sync
    await queueFailedRequest(request);
    
    return new Response(
      JSON.stringify({ 
        message: 'Request queued for sync when online',
        queued: true 
      }),
      { 
        status: 202,
        statusText: 'Accepted',
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

// Handle navigation requests (SPA routing)
async function handleNavigationRequest(request) {
  try {
    const networkResponse = await fetch(request);
    return networkResponse;
  } catch (error) {
    console.log('Service Worker: Navigation request failed, serving cached app shell');
    
    const cachedResponse = await caches.match('/');
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return offline page
    return new Response(
      `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Customer Support AI - Offline</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              display: flex; 
              align-items: center; 
              justify-content: center; 
              height: 100vh; 
              margin: 0; 
              background: #f3f4f6;
            }
            .offline-container {
              text-align: center;
              padding: 2rem;
              background: white;
              border-radius: 0.5rem;
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
              max-width: 400px;
            }
            .offline-icon { 
              font-size: 4rem; 
              margin-bottom: 1rem; 
            }
            .retry-btn {
              background: #3b82f6;
              color: white;
              border: none;
              padding: 0.75rem 1.5rem;
              border-radius: 0.375rem;
              cursor: pointer;
              font-size: 1rem;
              margin-top: 1rem;
            }
            .retry-btn:hover {
              background: #2563eb;
            }
          </style>
        </head>
        <body>
          <div class="offline-container">
            <div class="offline-icon">📡</div>
            <h1>You're Offline</h1>
            <p>Please check your internet connection and try again.</p>
            <button class="retry-btn" onclick="window.location.reload()">Retry</button>
          </div>
        </body>
      </html>
      `,
      { 
        headers: { 'Content-Type': 'text/html' }
      }
    );
  }
}

// Handle static assets with cache-first strategy
async function handleStaticAsset(request) {
  try {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }

    console.log('Service Worker: Fetching static asset:', request.url);
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      const cache = await caches.open(STATIC_CACHE);
      cache.put(request, networkResponse.clone());
    }
    
    return networkResponse;
  } catch (error) {
    console.error('Service Worker: Static asset fetch failed:', error);
    
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
      return cachedResponse;
    }
    
    throw error;
  }
}

// Queue failed requests for background sync
async function queueFailedRequest(request) {
  const failedRequests = await getStoredFailedRequests();
  failedRequests.push({
    url: request.url,
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    body: request.method !== 'GET' ? await request.text() : null,
    timestamp: Date.now(),
  });
  
  await storeFailedRequests(failedRequests);
  
  // Register for background sync if supported
  if ('sync' in self.registration) {
    try {
      await self.registration.sync.register('failed-requests');
      console.log('Service Worker: Background sync registered');
    } catch (error) {
      console.error('Service Worker: Failed to register background sync:', error);
    }
  }
}

// Process queued failed requests when back online
async function processFailedRequests() {
  const failedRequests = await getStoredFailedRequests();
  
  for (const requestData of failedRequests) {
    try {
      const response = await fetch(requestData.url, {
        method: requestData.method,
        headers: requestData.headers,
        body: requestData.body,
      });
      
      if (response.ok) {
        console.log('Service Worker: Successfully synced failed request:', requestData.url);
      }
    } catch (error) {
      console.error('Service Worker: Failed to sync request:', requestData.url, error);
    }
  }
  
  await storeFailedRequests([]);
}

// Local storage helpers for failed requests
async function getStoredFailedRequests() {
  try {
    const cache = await caches.open('failed-requests');
    const response = await cache.match('/failed-requests');
    return response ? await response.json() : [];
  } catch {
    return [];
  }
}

async function storeFailedRequests(requests) {
  try {
    const cache = await caches.open('failed-requests');
    const response = new Response(JSON.stringify(requests), {
      headers: { 'Content-Type': 'application/json' }
    });
    await cache.put('/failed-requests', response);
  } catch (error) {
    console.error('Service Worker: Failed to store failed requests:', error);
  }
}

// Background sync event
self.addEventListener('sync', (event) => {
  if (event.tag === 'failed-requests') {
    console.log('Service Worker: Background sync triggered');
    event.waitUntil(processFailedRequests());
  }
});

// Push notification event
self.addEventListener('push', (event) => {
  console.log('Service Worker: Push notification received');
  
  const options = {
    body: event.data ? event.data.text() : 'New notification',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    vibrate: [200, 100, 200],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Open App',
        icon: '/favicon.ico'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/favicon.ico'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('Customer Support AI', options)
  );
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Notification click received');
  
  event.notification.close();
  
  if (event.action === 'explore') {
    event.waitUntil(
      self.clients.openWindow('/')
    );
  }
});

// Message event - handle messages from main thread
self.addEventListener('message', (event) => {
  console.log('Service Worker: Message received:', event.data);
  
  const { type, payload } = event.data;
  
  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting();
      break;
      
    case 'CACHE_URLS':
      cacheUrls(payload.urls);
      break;
      
    case 'CLEAR_CACHE':
      clearCaches(payload.cacheNames);
      break;
      
    case 'GET_CACHE_SIZE':
      getCacheSize().then(size => {
        event.ports[0].postMessage({ cacheSize: size });
      });
      break;
      
    default:
      console.log('Service Worker: Unknown message type:', type);
  }
});

// Helper function to cache URLs
async function cacheUrls(urls) {
  try {
    const cache = await caches.open(DYNAMIC_CACHE);
    await cache.addAll(urls);
    console.log('Service Worker: URLs cached successfully');
  } catch (error) {
    console.error('Service Worker: Failed to cache URLs:', error);
  }
}

// Helper function to clear caches
async function clearCaches(cacheNames) {
  try {
    const promises = cacheNames.map(cacheName => caches.delete(cacheName));
    await Promise.all(promises);
    console.log('Service Worker: Caches cleared successfully');
  } catch (error) {
    console.error('Service Worker: Failed to clear caches:', error);
  }
}

// Helper function to get cache size
async function getCacheSize() {
  try {
    const cacheNames = await caches.keys();
    let totalSize = 0;
    
    for (const cacheName of cacheNames) {
      const cache = await caches.open(cacheName);
      const requests = await cache.keys();
      
      for (const request of requests) {
        const response = await cache.match(request);
        if (response) {
          const blob = await response.blob();
          totalSize += blob.size;
        }
      }
    }
    
    return totalSize;
  } catch (error) {
    console.error('Service Worker: Failed to get cache size:', error);
    return 0;
  }
}

// Error event
self.addEventListener('error', (event) => {
  console.error('Service Worker: Global error:', event.error);
});

// Unhandled rejection event
self.addEventListener('unhandledrejection', (event) => {
  console.error('Service Worker: Unhandled promise rejection:', event.reason);
});

console.log('Service Worker: Loaded');