import { render, RenderOptions } from '@testing-library/react'
import { ReactElement } from 'react'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

// Create a test query client
export function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: 0,
      },
    },
  })
}

// Custom render function that includes providers
export function renderWithProviders(
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>,
) {
  const testQueryClient = createTestQueryClient()

  function Wrapper({ children }: { children: React.ReactNode }) {
    return (
      <BrowserRouter>
        <QueryClientProvider client={testQueryClient}>
          {children}
        </QueryClientProvider>
      </BrowserRouter>
    )
  }

  return render(ui, { wrapper: Wrapper, ...options })
}

// Mock WebSocket helper
export function createMockWebSocket() {
  return {
    send: vi.fn(),
    close: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
    readyState: 1,
    CONNECTING: 0,
    OPEN: 1,
    CLOSING: 2,
    CLOSED: 3,
  }
}

// Mock File helper
export function createMockFile(
  name: string,
  size: number,
  type: string,
  lastModified?: number,
) {
  const file = new File([''], name, { type })
  Object.defineProperty(file, 'size', { value: size })
  Object.defineProperty(file, 'lastModified', { value: lastModified || Date.now() })
  return file
}

// Create mock user
export function createMockUser(overrides = {}) {
  return {
    id: '1',
    username: 'testuser',
    email: 'test@example.com',
    first_name: 'Test',
    last_name: 'User',
    ...overrides,
  }
}

// Create mock message
export function createMockMessage(overrides = {}) {
  return {
    id: '1',
    content: 'Test message',
    sender: 'user' as const,
    timestamp: new Date().toISOString(),
    session_id: 'session-1',
    file_attachments: [],
    ...overrides,
  }
}

// Create mock session
export function createMockSession(overrides = {}) {
  return {
    session_id: 'session-1',
    created_at: new Date().toISOString(),
    status: 'active' as const,
    user_id: '1',
    last_activity: new Date().toISOString(),
    ...overrides,
  }
}

// Async utilities
export function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// Wait for next tick
export function waitForNextTick() {
  return new Promise(resolve => setImmediate(resolve))
}

// Type helpers for testing
export type Partial<T> = {
  [P in keyof T]?: T[P]
}

// Snapshot testing helper
export function toMatchSnapshot(element: ReactElement) {
  const { container } = renderWithProviders(element)
  expect(container.firstChild).toMatchSnapshot()
}

// Accessibility testing helpers
export async function checkAccessibility(element: HTMLElement) {
  // This would integrate with axe-core for comprehensive accessibility testing
  const { axe } = await import('vitest-axe')
  const results = await axe(element)
  expect(results).toHaveNoViolations()
}

// Performance testing helpers
export function measurePerformance(name: string, fn: () => void | Promise<void>) {
  const start = performance.now()
  const result = fn()
  
  if (result instanceof Promise) {
    return result.finally(() => {
      const end = performance.now()
      console.log(`${name} took ${end - start} milliseconds`)
    })
  } else {
    const end = performance.now()
    console.log(`${name} took ${end - start} milliseconds`)
  }
}

// Mock localStorage
export const localStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
}

// Mock sessionStorage
export const sessionStorageMock = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
}