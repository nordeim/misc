/**
 * Custom React hook for managing chat sessions.
 * 
 * Provides session management functionality including listing,
 * creating, updating, and deleting sessions.
 */

import { useState, useCallback, useEffect, useMemo } from 'react';
import { Session, PaginationInfo } from '../types';
import { apiService } from '../services/api';
import { toast } from 'react-hot-toast';

interface SessionFilters {
  status?: 'active' | 'inactive' | 'archived';
  dateRange?: {
    start: Date;
    end: Date;
  };
  search?: string;
}

interface SessionSortOptions {
  field: 'created_at' | 'updated_at' | 'title' | 'message_count';
  direction: 'asc' | 'desc';
}

interface UseSessionOptions {
  userId?: string;
  autoLoad?: boolean;
  pageSize?: number;
}

interface UseSessionReturn {
  // State
  sessions: Session[];
  currentSession: Session | null;
  isLoading: boolean;
  isCreating: boolean;
  error: string | null;
  pagination: PaginationInfo | null;
  filters: SessionFilters;
  sortOptions: SessionSortOptions;
  
  // Actions
  loadSessions: (page?: number, filters?: SessionFilters, sort?: SessionSortOptions) => Promise<void>;
  loadSession: (sessionId: string) => Promise<void>;
  createSession: (title?: string) => Promise<Session>;
  deleteSession: (sessionId: string) => Promise<void>;
  updateSessionTitle: (sessionId: string, title: string) => Promise<void>;
  updateSessionStatus: (sessionId: string, status: Session['status']) => Promise<void>;
  
  // Filtering and Sorting
  setFilters: (filters: SessionFilters) => void;
  setSortOptions: (sort: SessionSortOptions) => void;
  clearFilters: () => void;
  
  // Utility
  getSessionById: (sessionId: string) => Session | undefined;
  getRecentSessions: (limit?: number) => Session[];
  getActiveSessions: () => Session[];
  getArchivedSessions: () => Session[];
  searchSessions: (query: string) => Session[];
  
  // Actions
  refreshSessions: () => Promise<void>;
  clearCurrentSession: () => void;
}

const DEFAULT_FILTERS: SessionFilters = {};
const DEFAULT_SORT: SessionSortOptions = {
  field: 'updated_at',
  direction: 'desc',
};

export const useSession = (options: UseSessionOptions = {}): UseSessionReturn => {
  const {
    userId,
    autoLoad = true,
    pageSize = 20,
  } = options;

  // State
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [filters, setFiltersState] = useState<SessionFilters>(DEFAULT_FILTERS);
  const [sortOptions, setSortOptionsState] = useState<SessionSortOptions>(DEFAULT_SORT);
  const [currentPage, setCurrentPage] = useState(1);

  // Auto-load sessions on mount
  useEffect(() => {
    if (autoLoad) {
      loadSessions();
    }
  }, [autoLoad, userId]);

  // Compute filtered and sorted sessions
  const filteredAndSortedSessions = useMemo(() => {
    let filtered = [...sessions];

    // Apply filters
    if (filters.status) {
      filtered = filtered.filter(session => session.status === filters.status);
    }

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(session =>
        session.title.toLowerCase().includes(searchLower) ||
        session.id.toLowerCase().includes(searchLower)
      );
    }

    if (filters.dateRange) {
      const { start, end } = filters.dateRange;
      filtered = filtered.filter(session => {
        const sessionDate = new Date(session.created_at);
        return sessionDate >= start && sessionDate <= end;
      });
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (sortOptions.field) {
        case 'created_at':
          aValue = new Date(a.created_at);
          bValue = new Date(b.created_at);
          break;
        case 'updated_at':
          aValue = new Date(a.updated_at || a.created_at);
          bValue = new Date(b.updated_at || b.created_at);
          break;
        case 'title':
          aValue = a.title.toLowerCase();
          bValue = b.title.toLowerCase();
          break;
        case 'message_count':
          aValue = a.message_count || 0;
          bValue = b.message_count || 0;
          break;
        default:
          return 0;
      }

      if (aValue < bValue) {
        return sortOptions.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortOptions.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });

    return filtered;
  }, [sessions, filters, sortOptions]);

  const loadSessions = useCallback(async (
    page = 1,
    newFilters = filters,
    newSort = sortOptions
  ) => {
    setIsLoading(true);
    setError(null);

    try {
      const params: any = {
        page,
        limit: pageSize,
        sort_field: newSort.field,
        sort_direction: newSort.direction,
      };

      if (userId) {
        params.user_id = userId;
      }

      if (newFilters.status) {
        params.status = newFilters.status;
      }

      if (newFilters.search) {
        params.search = newFilters.search;
      }

      if (newFilters.dateRange) {
        params.start_date = newFilters.dateRange.start.toISOString();
        params.end_date = newFilters.dateRange.end.toISOString();
      }

      const response = await apiService.getSessions();
      
      setSessions(response.sessions);
      setPagination(response.pagination || null);
      setCurrentPage(page);
      
    } catch (error: any) {
      const errorMessage = `Failed to load sessions: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortOptions, userId, pageSize]);

  const loadSession = useCallback(async (sessionId: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const session = await apiService.getSession(sessionId);
      setCurrentSession(session);
      
      // Update sessions list if this session isn't already there
      setSessions(prev => {
        const existing = prev.find(s => s.id === sessionId);
        if (!existing) {
          return [session, ...prev];
        }
        return prev.map(s => s.id === sessionId ? session : s);
      });

    } catch (error: any) {
      const errorMessage = `Failed to load session: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createSession = useCallback(async (title?: string): Promise<Session> => {
    setIsCreating(true);
    setError(null);

    try {
      const sessionTitle = title || `New Chat ${new Date().toLocaleString()}`;
      
      // For now, create a local session since the API might not have session creation
      const newSession: Session = {
        id: `session_${Date.now()}`,
        title: sessionTitle,
        created_at: new Date().toISOString(),
        status: 'active',
        message_count: 0,
      };

      // Try to persist via API
      try {
        // This would be an API call in a real implementation
        // await apiService.createSession(newSession);
      } catch (apiError) {
        console.warn('Failed to persist session to API:', apiError);
      }

      setSessions(prev => [newSession, ...prev]);
      setCurrentSession(newSession);
      
      toast.success('New session created');
      return newSession;

    } catch (error: any) {
      const errorMessage = `Failed to create session: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsCreating(false);
    }
  }, []);

  const deleteSession = useCallback(async (sessionId: string) => {
    try {
      await apiService.deleteSession(sessionId);
      
      setSessions(prev => prev.filter(s => s.id !== sessionId));
      
      if (currentSession?.id === sessionId) {
        setCurrentSession(null);
      }
      
      toast.success('Session deleted successfully');

    } catch (error: any) {
      const errorMessage = `Failed to delete session: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    }
  }, [currentSession]);

  const updateSessionTitle = useCallback(async (sessionId: string, title: string) => {
    try {
      await apiService.updateSessionTitle(sessionId, title);
      
      setSessions(prev => prev.map(s => 
        s.id === sessionId ? { ...s, title } : s
      ));
      
      if (currentSession?.id === sessionId) {
        setCurrentSession(prev => prev ? { ...prev, title } : null);
      }
      
      toast.success('Session title updated');

    } catch (error: any) {
      const errorMessage = `Failed to update session title: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    }
  }, [currentSession]);

  const updateSessionStatus = useCallback(async (sessionId: string, status: Session['status']) => {
    try {
      // Update locally first for better UX
      setSessions(prev => prev.map(s => 
        s.id === sessionId ? { ...s, status } : s
      ));
      
      if (currentSession?.id === sessionId) {
        setCurrentSession(prev => prev ? { ...prev, status } : null);
      }

      // Try to persist via API
      try {
        // This would be an API call in a real implementation
        // await apiService.updateSessionStatus(sessionId, status);
      } catch (apiError) {
        console.warn('Failed to persist session status:', apiError);
        // Revert on failure
        setSessions(prev => prev.map(s => 
          s.id === sessionId ? { ...s, status: s.status } : s
        ));
      }
      
      toast.success('Session status updated');

    } catch (error: any) {
      const errorMessage = `Failed to update session status: ${error.message}`;
      setError(errorMessage);
      toast.error(errorMessage);
      throw error;
    }
  }, [currentSession]);

  const setFilters = useCallback((newFilters: SessionFilters) => {
    setFiltersState(newFilters);
    setCurrentPage(1); // Reset to first page when filtering
  }, []);

  const setSortOptions = useCallback((newSort: SessionSortOptions) => {
    setSortOptionsState(newSort);
    setCurrentPage(1); // Reset to first page when sorting
  }, []);

  const clearFilters = useCallback(() => {
    setFiltersState(DEFAULT_FILTERS);
    setSortOptionsState(DEFAULT_SORT);
    setCurrentPage(1);
  }, []);

  const getSessionById = useCallback((sessionId: string): Session | undefined => {
    return sessions.find(session => session.id === sessionId);
  }, [sessions]);

  const getRecentSessions = useCallback((limit = 5): Session[] => {
    return sessions
      .sort((a, b) => new Date(b.updated_at || b.created_at).getTime() - new Date(a.updated_at || a.created_at).getTime())
      .slice(0, limit);
  }, [sessions]);

  const getActiveSessions = useCallback((): Session[] => {
    return sessions.filter(session => session.status === 'active');
  }, [sessions]);

  const getArchivedSessions = useCallback((): Session[] => {
    return sessions.filter(session => session.status === 'archived');
  }, [sessions]);

  const searchSessions = useCallback((query: string): Session[] => {
    const searchLower = query.toLowerCase();
    return sessions.filter(session =>
      session.title.toLowerCase().includes(searchLower) ||
      session.id.toLowerCase().includes(searchLower)
    );
  }, [sessions]);

  const refreshSessions = useCallback(async () => {
    await loadSessions(currentPage);
  }, [loadSessions, currentPage]);

  const clearCurrentSession = useCallback(() => {
    setCurrentSession(null);
  }, []);

  return {
    // State
    sessions: filteredAndSortedSessions,
    currentSession,
    isLoading,
    isCreating,
    error,
    pagination,
    filters,
    sortOptions,
    
    // Actions
    loadSessions,
    loadSession,
    createSession,
    deleteSession,
    updateSessionTitle,
    updateSessionStatus,
    
    // Filtering and Sorting
    setFilters,
    setSortOptions,
    clearFilters,
    
    // Utility
    getSessionById,
    getRecentSessions,
    getActiveSessions,
    getArchivedSessions,
    searchSessions,
    
    // Actions
    refreshSessions,
    clearCurrentSession,
  };
};