/**
 * Custom React hook for managing chat functionality.
 * 
 * Provides comprehensive chat state management including message history,
 * session handling, and real-time messaging.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useWebSocket } from './useWebSocket';
import { Message, Session, ChatResponse } from '../types';
import { apiService } from '../services/api';
import { toast } from 'react-hot-toast';

interface UseChatOptions {
  sessionId?: string;
  autoConnect?: boolean;
  enableFileUpload?: boolean;
}

interface UseChatReturn {
  // State
  messages: Message[];
  currentSession: Session | null;
  isLoading: boolean;
  isTyping: boolean;
  error: string | null;
  
  // Actions
  sendMessage: (content: string, attachments?: File[]) => Promise<void>;
  loadSession: (sessionId: string) => Promise<void>;
  createNewSession: () => Promise<void>;
  deleteSession: (sessionId: string) => Promise<void>;
  updateSessionTitle: (sessionId: string, title: string) => Promise<void>;
  clearChat: () => void;
  
  // Utility
  retryMessage: (messageId: string) => Promise<void>;
  getMessageById: (id: string) => Message | undefined;
  canSendMessage: boolean;
}

export const useChat = (options: UseChatOptions = {}): UseChatReturn => {
  const { sessionId: initialSessionId, autoConnect = true, enableFileUpload = true } = options;
  
  // State
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentSession, setCurrentSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const retryMessageIdRef = useRef<string | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const handleWebSocketMessage = useCallback((data: any) => {
    setIsLoading(false);
    setIsTyping(false);
    
    if (data.type === 'chat_response') {
      const responseMessage: Message = {
        id: data.response.message_id || `msg_${Date.now()}`,
        content: data.response.content,
        role: 'assistant',
        timestamp: new Date().toISOString(),
        sources: data.response.sources,
        confidence: data.response.confidence_score,
        attachments_processed: data.response.attachments_processed,
      };
      
      setMessages(prev => [...prev, responseMessage]);
      
      // Show success notification for file processing
      if (data.response.attachments_processed?.length > 0) {
        toast.success(`Processed ${data.response.attachments_processed.length} file(s)`);
      }
      
    } else if (data.type === 'error') {
      const errorMessage = data.message || 'An error occurred';
      setError(errorMessage);
      toast.error(errorMessage);
      
      // Add error message to chat
      if (retryMessageIdRef.current) {
        const errorMsg: Message = {
          id: `error_${Date.now()}`,
          content: `❌ ${errorMessage}`,
          role: 'assistant',
          timestamp: new Date().toISOString(),
        };
        setMessages(prev => [...prev, errorMsg]);
      }
    }
  }, []);

  const handleTyping = useCallback((typing: boolean) => {
    setIsTyping(typing);
    
    // Auto-clear typing after 5 seconds
    if (typing) {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
      }, 5000);
    }
  }, []);

  const { sendMessage: sendWebSocketMessage, isConnected, connect } = useWebSocket({
    onMessage: handleWebSocketMessage,
    onTyping: handleTyping,
    onError: (error) => {
      console.error('WebSocket error:', error);
      setError('Connection error. Please check your internet connection.');
    },
  });

  // Initialize session
  useEffect(() => {
    if (initialSessionId) {
      loadSession(initialSessionId);
    } else {
      createNewSession();
    }
    
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [initialSessionId]);

  const sendMessage = useCallback(async (content: string, attachments?: File[]) => {
    if (!content.trim() || !currentSession || !isConnected) {
      setError('Cannot send message: ' + (!content.trim() ? 'Empty message' : !currentSession ? 'No session' : 'Not connected'));
      return;
    }

    setIsLoading(true);
    setError(null);
    const messageId = `msg_${Date.now()}`;
    retryMessageIdRef.current = messageId;

    const userMessage: Message = {
      id: messageId,
      content,
      role: 'user',
      timestamp: new Date().toISOString(),
      attachments: attachments?.map(file => ({ 
        name: file.name, 
        size: file.size,
        type: file.type 
      })) || [],
    };

    setMessages(prev => [...prev, userMessage]);

    try {
      // Send via WebSocket for real-time response
      sendWebSocketMessage({
        type: 'chat_message',
        content,
        session_id: currentSession.id,
        attachments: attachments?.map(file => ({ 
          name: file.name, 
          size: file.size,
          type: file.type 
        })) || [],
        message_id: messageId,
      });
      
      // Also persist via API (optional, for backup)
      if (attachments && attachments.length > 0) {
        try {
          await apiService.sendMessage(content, currentSession.id, attachments);
        } catch (apiError) {
          console.warn('API backup failed, but WebSocket message sent:', apiError);
        }
      }
      
    } catch (error) {
      setError('Failed to send message');
      setIsLoading(false);
    }
  }, [currentSession, isConnected, sendWebSocketMessage]);

  const loadSession = useCallback(async (id: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const [sessionData, messagesData] = await Promise.all([
        apiService.getSession(id),
        apiService.getSessionMessages(id),
      ]);

      setCurrentSession(sessionData);
      setMessages(messagesData.messages);
      
    } catch (error: any) {
      setError(`Failed to load session: ${error.message}`);
      toast.error('Failed to load chat session');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createNewSession = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const newSession: Session = {
        id: `session_${Date.now()}`,
        title: `New Chat ${new Date().toLocaleDateString()}`,
        created_at: new Date().toISOString(),
        status: 'active',
      };

      setCurrentSession(newSession);
      setMessages([]);
      
      // Create session via API (non-blocking)
      apiService.getSessions().catch(err => {
        console.warn('Failed to persist session:', err);
      });
      
    } catch (error: any) {
      setError(`Failed to create session: ${error.message}`);
      toast.error('Failed to create new chat');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const deleteSession = useCallback(async (id: string) => {
    try {
      await apiService.deleteSession(id);
      if (currentSession?.id === id) {
        setCurrentSession(null);
        setMessages([]);
      }
      toast.success('Session deleted');
    } catch (error: any) {
      setError(`Failed to delete session: ${error.message}`);
      toast.error('Failed to delete session');
    }
  }, [currentSession]);

  const updateSessionTitle = useCallback(async (id: string, title: string) => {
    try {
      await apiService.updateSessionTitle(id, title);
      if (currentSession?.id === id) {
        setCurrentSession(prev => prev ? { ...prev, title } : null);
      }
      toast.success('Session title updated');
    } catch (error: any) {
      setError(`Failed to update title: ${error.message}`);
      toast.error('Failed to update session title');
    }
  }, [currentSession]);

  const clearChat = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  const retryMessage = useCallback(async (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (message && message.role === 'user') {
      retryMessageIdRef.current = messageId;
      await sendMessage(message.content, message.attachments?.map(att => {
        // Note: We can't reconstruct File objects from metadata
        // This would need to be handled differently in a real app
        return new File([], att.name, { type: att.type || 'application/octet-stream' });
      }));
    }
  }, [messages, sendMessage]);

  const getMessageById = useCallback((id: string) => {
    return messages.find(message => message.id === id);
  }, [messages]);

  const canSendMessage = Boolean(currentSession && isConnected && !isLoading);

  return {
    // State
    messages,
    currentSession,
    isLoading,
    isTyping,
    error,
    
    // Actions
    sendMessage,
    loadSession,
    createNewSession,
    deleteSession,
    updateSessionTitle,
    clearChat,
    
    // Utility
    retryMessage,
    getMessageById,
    canSendMessage,
  };
};