/**
 * Type definitions for the Customer Support AI Agent frontend.
 */

export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  attachments?: Array<{
    name: string;
    size: number;
    type?: string;
  }>;
  sources?: Array<{
    content: string;
    metadata: Record<string, any>;
    relevance_score?: number;
  }>;
  confidence?: number;
  attachments_processed?: string[];
}

export interface Session {
  id: string;
  title: string;
  created_at: string;
  updated_at?: string;
  status?: 'active' | 'inactive' | 'archived';
  message_count?: number;
}

export interface ChatResponse {
  session_id: string;
  response: {
    content: string;
    attachments_processed: string[];
    escalation_triggered: boolean;
    sources: Array<{
      content: string;
      metadata: Record<string, any>;
      relevance_score?: number;
    }>;
    confidence_score: number;
    processing_time: number;
  };
}

export interface WebSocketMessage {
  type: 'chat_message' | 'chat_response' | 'connection' | 'typing_indicator' | 'error';
  content?: string;
  session_id?: string;
  client_id?: string;
  timestamp?: string;
  response?: ChatResponse['response'];
  message?: string;
  is_typing?: boolean;
}

export interface AgentConfig {
  app_name: string;
  debug: boolean;
  log_level: string;
  host: string;
  port: number;
  cors_origins: string[];
  database_url: string;
  redis_url: string;
  chroma_db_path: string;
  embedding_model: string;
  upload_max_size: number;
  upload_allowed_types: string[];
}

export interface UploadedFile {
  name: string;
  size: number;
  type: string;
  lastModified: number;
}

export interface EscalationInfo {
  should_escalate: boolean;
  escalation_score: number;
  reasons: string[];
  threshold: number;
  timestamp: string;
}

export interface Memory {
  id: string;
  key: string;
  value: string;
  memory_type: string;
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface RAGResult {
  query: string;
  sources: Array<{
    content: string;
    metadata: Record<string, any>;
    distance?: number;
    relevance_score: number;
  }>;
  confidence: number;
  total_results: number;
}

export interface APIError {
  message: string;
  code?: string;
  details?: Record<string, any>;
}

export interface PaginationInfo {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
}

export interface ChatSessionsResponse {
  sessions: Session[];
  pagination?: PaginationInfo;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin' | 'agent';
  created_at: string;
  last_login?: string;
}

export interface Attachment {
  id: string;
  filename: string;
  original_name: string;
  file_type: string;
  file_size: number;
  mime_type: string;
  uploaded_at: string;
  processed: boolean;
  content?: string;
}

// Additional API Response Types
export interface ApiResponse<T = any> {
  data?: T;
  message?: string;
  success: boolean;
  error?: APIError;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  offset?: number;
}

export interface SortParams {
  sort_by?: string;
  sort_order?: 'asc' | 'desc';
}

// WebSocket Event Types
export interface ConnectionEvent {
  type: 'connection';
  client_id: string;
  timestamp: string;
  user_agent?: string;
}

export interface ChatMessageEvent {
  type: 'chat_message';
  content: string;
  session_id: string;
  client_id: string;
  timestamp: string;
  attachments?: Array<{
    name: string;
    size: number;
    type?: string;
  }>;
}

export interface ChatResponseEvent {
  type: 'chat_response';
  session_id: string;
  client_id: string;
  timestamp: string;
  response: {
    content: string;
    attachments_processed: string[];
    escalation_triggered: boolean;
    sources: Array<{
      content: string;
      metadata: Record<string, any>;
      relevance_score?: number;
    }>;
    confidence_score: number;
    processing_time: number;
  };
}

export interface TypingIndicatorEvent {
  type: 'typing_indicator';
  client_id: string;
  is_typing: boolean;
  timestamp: string;
}

export interface ErrorEvent {
  type: 'error';
  message: string;
  code?: string;
  timestamp: string;
}

export type WebSocketEvent = ConnectionEvent | ChatMessageEvent | ChatResponseEvent | TypingIndicatorEvent | ErrorEvent;

// Authentication Types
export interface AuthTokens {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
  loading: boolean;
  error: string | null;
}

// File Upload Types
export interface FileUploadProgress {
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export interface FileUploadOptions {
  maxFileSize?: number;
  allowedTypes?: string[];
  sessionId?: string;
  onProgress?: (progress: FileUploadProgress[]) => void;
  onComplete?: (files: string[]) => void;
  onError?: (error: string) => void;
}

// Component Props Types
export interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
}

export interface LoadingState {
  isLoading: boolean;
  error: string | null;
}

export interface SearchFilters {
  query?: string;
  dateFrom?: string;
  dateTo?: string;
  status?: string;
  type?: string;
}