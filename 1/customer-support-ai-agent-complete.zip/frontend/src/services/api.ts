/**
 * API service for making HTTP requests to the backend.

Provides functions for chat operations, session management, and other API calls.
 */

import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { Message, Session, ChatResponse, APIError } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

class ApiService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add auth token if available
        const token = localStorage.getItem('auth_token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response: AxiosResponse) => {
        return response;
      },
      (error) => {
        if (error.response?.status === 401) {
          // Handle unauthorized access
          localStorage.removeItem('auth_token');
          window.location.href = '/login';
        }
        return Promise.reject(this.normalizeError(error));
      }
    );
  }

  private normalizeError(error: any): APIError {
    if (error.response) {
      return {
        message: error.response.data?.detail || error.message || 'Unknown error',
        code: error.response.data?.code,
        details: error.response.data,
      };
    } else if (error.request) {
      return {
        message: 'Network error - please check your connection',
        code: 'NETWORK_ERROR',
      };
    } else {
      return {
        message: error.message || 'Unexpected error occurred',
        code: 'UNKNOWN_ERROR',
      };
    }
  }

  // Chat API
  async sendMessage(
    message: string,
    sessionId?: string,
    fileAttachments?: File[]
  ): Promise<ChatResponse> {
    const formData = new FormData();
    formData.append('message', message);
    
    if (sessionId) {
      formData.append('session_id', sessionId);
    }
    
    if (fileAttachments) {
      fileAttachments.forEach((file) => {
        formData.append('file_attachments', file);
      });
    }

    const response = await this.client.post('/api/v1/chat', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    return response.data;
  }

  // Session Management API
  async getSessions(userId?: string): Promise<{ sessions: Session[] }> {
    const params = userId ? { user_id: userId } : {};
    const response = await this.client.get('/api/v1/sessions', { params });
    return response.data;
  }

  async getSession(sessionId: string): Promise<Session> {
    const response = await this.client.get(`/api/v1/sessions/${sessionId}`);
    return response.data;
  }

  async deleteSession(sessionId: string): Promise<{ message: string }> {
    const response = await this.client.delete(`/api/v1/sessions/${sessionId}`);
    return response.data;
  }

  async updateSessionTitle(
    sessionId: string,
    title: string
  ): Promise<{ message: string }> {
    const response = await this.client.post(`/api/v1/sessions/${sessionId}/title`, {
      title,
    });
    return response.data;
  }

  async getSessionMessages(
    sessionId: string,
    limit = 50,
    offset = 0
  ): Promise<{ messages: Message[] }> {
    const response = await this.client.get(`/api/v1/sessions/${sessionId}/messages`, {
      params: { limit, offset },
    });
    return response.data;
  }

  // Health and Status API
  async getHealth(): Promise<{ status: string; version: string }> {
    const response = await this.client.get('/health');
    return response.data;
  }

  async getRoot(): Promise<{ message: string }> {
    const response = await this.client.get('/');
    return response.data;
  }

  // Upload API
  async uploadFile(file: File, sessionId: string): Promise<{ path: string }> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('session_id', sessionId);

    const response = await this.client.post('/api/v1/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    return response.data;
  }

  async uploadMultipleFiles(
    files: File[],
    sessionId: string
  ): Promise<{ paths: string[] }> {
    const formData = new FormData();
    files.forEach((file, index) => {
      formData.append(`file_${index}`, file);
    });
    formData.append('session_id', sessionId);

    const response = await this.client.post('/api/v1/upload/multiple', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    return response.data;
  }

  // Knowledge Base API
  async addKnowledgeDocument(
    content: string,
    metadata?: Record<string, any>
  ): Promise<{ id: string }> {
    const response = await this.client.post('/api/v1/knowledge', {
      content,
      metadata,
    });
    return response.data;
  }

  async searchKnowledge(
    query: string,
    topK = 5
  ): Promise<{
    query: string;
    sources: Array<{
      content: string;
      metadata: Record<string, any>;
      relevance_score: number;
    }>;
    confidence: number;
  }> {
    const response = await this.client.post('/api/v1/knowledge/search', {
      query,
      top_k: topK,
    });
    return response.data;
  }

  // Agent Control API
  async getAgentStatus(): Promise<{
    status: string;
    uptime: number;
    total_sessions: number;
    active_sessions: number;
  }> {
    const response = await this.client.get('/api/v1/agent/status');
    return response.data;
  }

  async restartAgent(): Promise<{ message: string }> {
    const response = await this.client.post('/api/v1/agent/restart');
    return response.data;
  }

  // Configuration API
  async getConfig(): Promise<{
    app_name: string;
    version: string;
    features: string[];
  }> {
    const response = await this.client.get('/api/v1/config');
    return response.data;
  }

  // User Management API (for admin)
  async getUsers(page = 1, limit = 20): Promise<{
    users: Array<{
      id: string;
      email: string;
      name: string;
      role: string;
      created_at: string;
    }>;
    pagination: {
      page: number;
      page_size: number;
      total: number;
      total_pages: number;
    };
  }> {
    const response = await this.client.get('/api/v1/admin/users', {
      params: { page, limit },
    });
    return response.data;
  }

  // Error tracking
  async reportError(
    error: string,
    context?: Record<string, any>
  ): Promise<{ message: string }> {
    const response = await this.client.post('/api/v1/errors', {
      error,
      context,
      timestamp: new Date().toISOString(),
    });
    return response.data;
  }
}

// Export singleton instance
export const apiService = new ApiService();
export default apiService;