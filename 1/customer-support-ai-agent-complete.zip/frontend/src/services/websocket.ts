/**
 * WebSocket Client Service

Provides real-time communication with the backend server.
Handles connection management, message sending, and event handling.
 */

import { io, Socket } from 'socket.io-client';
import { WebSocketMessage } from '../types';

export interface WebSocketOptions {
  url?: string;
  autoConnect?: boolean;
  reconnection?: boolean;
  reconnectionAttempts?: number;
  reconnectionDelay?: number;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onMessage?: (message: WebSocketMessage) => void;
  onError?: (error: any) => void;
  onTyping?: (isTyping: boolean) => void;
}

class WebSocketClient {
  private socket: Socket | null = null;
  private options: WebSocketOptions;
  private clientId: string;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  constructor(options: WebSocketOptions = {}) {
    this.options = {
      url: import.meta.env.VITE_WS_URL || 'ws://localhost:8000',
      autoConnect: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      ...options,
    };
    
    this.clientId = `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    if (this.options.autoConnect) {
      this.connect();
    }
  }

  connect(): Promise<Socket> {
    return new Promise((resolve, reject) => {
      if (this.socket?.connected) {
        resolve(this.socket);
        return;
      }

      try {
        this.socket = io(this.options.url!, {
          transports: ['websocket'],
          upgrade: false,
          reconnection: this.options.reconnection,
          reconnectionAttempts: this.options.reconnectionAttempts,
          reconnectionDelay: this.options.reconnectionDelay,
          timeout: 20000,
        });

        const socket = this.socket;

        // Connection events
        socket.on('connect', () => {
          console.log('WebSocket connected successfully');
          this.reconnectAttempts = 0;
          this.sendConnectionMessage();
          this.options.onConnect?.();
          resolve(socket);
        });

        socket.on('disconnect', (reason) => {
          console.log('WebSocket disconnected:', reason);
          this.options.onDisconnect?.();
        });

        socket.on('connect_error', (error) => {
          console.error('WebSocket connection error:', error);
          this.reconnectAttempts++;
          
          if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnection attempts reached');
            reject(new Error('Max reconnection attempts reached'));
          } else {
            this.options.onError?.(error);
          }
        });

        // Message handling
        socket.on('message', (data: WebSocketMessage) => {
          this.handleMessage(data);
        });

        socket.on('chat_response', (data: WebSocketMessage) => {
          this.handleMessage({ ...data, type: 'chat_response' });
        });

        socket.on('typing_indicator', (data: { is_typing: boolean; client_id: string }) => {
          if (data.client_id !== this.clientId) {
            this.options.onTyping?.(data.is_typing);
          }
        });

        socket.on('error', (error: any) => {
          console.error('WebSocket error:', error);
          this.options.onError?.(error);
        });

      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        reject(error);
      }
    });
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  private sendConnectionMessage(): void {
    if (this.socket?.connected) {
      this.socket.emit('connection', {
        client_id: this.clientId,
        timestamp: new Date().toISOString(),
        user_agent: navigator.userAgent,
      });
    }
  }

  private handleMessage(data: WebSocketMessage): void {
    switch (data.type) {
      case 'chat_response':
        this.options.onMessage?.(data);
        break;
      case 'typing_indicator':
        if (data.client_id !== this.clientId && data.is_typing !== undefined) {
          this.options.onTyping?.(data.is_typing);
        }
        break;
      case 'error':
        this.options.onError?.(data.message);
        break;
      default:
        this.options.onMessage?.(data);
    }
  }

  sendMessage(message: Partial<WebSocketMessage>): void {
    if (!this.socket?.connected) {
      console.warn('WebSocket not connected, cannot send message');
      return;
    }

    const fullMessage = {
      ...message,
      client_id: this.clientId,
      timestamp: new Date().toISOString(),
    };

    this.socket.emit('message', fullMessage);
  }

  sendTypingIndicator(isTyping: boolean): void {
    if (!this.socket?.connected) {
      return;
    }

    this.socket.emit('typing_indicator', {
      client_id: this.clientId,
      is_typing: isTyping,
      timestamp: new Date().toISOString(),
    });
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }

  getClientId(): string {
    return this.clientId;
  }
}

// Export singleton instance
export const websocketClient = new WebSocketClient();
export default websocketClient;