/**
 * File Upload Service

Handles file uploads to the backend with progress tracking, validation,
and error handling. Supports single and multiple file uploads.
 */

import { UploadedFile } from '../types';

export interface UploadProgress {
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export interface UploadOptions {
  onProgress?: (progress: UploadProgress[]) => void;
  onUploadComplete?: (files: string[]) => void;
  onUploadError?: (error: string) => void;
  maxFileSize?: number; // in bytes
  allowedTypes?: string[];
  sessionId?: string;
}

class FileUploadService {
  private readonly MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
  private readonly ALLOWED_TYPES = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'application/json',
    'text/csv',
    'image/jpeg',
    'image/png',
    'image/gif',
  ];

  /**
   * Upload a single file
   */
  async uploadFile(
    file: File,
    sessionId?: string,
    options: Partial<UploadOptions> = {}
  ): Promise<string> {
    try {
      // Validate file
      this.validateFile(file, options);

      const formData = new FormData();
      formData.append('file', file);
      
      if (sessionId) {
        formData.append('session_id', sessionId);
      }

      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8000'}/api/v1/upload`, {
        method: 'POST',
        body: formData,
        headers: this.getAuthHeaders(),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Upload failed');
      }

      const result = await response.json();
      return result.path;
    } catch (error) {
      console.error('File upload error:', error);
      options.onUploadError?.(error instanceof Error ? error.message : 'Upload failed');
      throw error;
    }
  }

  /**
   * Upload multiple files with progress tracking
   */
  async uploadMultipleFiles(
    files: File[],
    options: UploadOptions = {}
  ): Promise<string[]> {
    const maxFileSize = options.maxFileSize || this.MAX_FILE_SIZE;
    const allowedTypes = options.allowedTypes || this.ALLOWED_TYPES;

    // Validate all files first
    files.forEach(file => this.validateFile(file, { maxFileSize, allowedTypes }));

    const progress: UploadProgress[] = files.map(file => ({
      fileName: file.name,
      progress: 0,
      status: 'pending',
    }));

    const uploadedPaths: string[] = [];
    let completedUploads = 0;

    // Update initial progress
    options.onProgress?.(progress);

    // Upload files concurrently with limit
    const uploadPromises = files.map(async (file, index) => {
      try {
        // Update status to uploading
        progress[index].status = 'uploading';
        options.onProgress?.([...progress]);

        const formData = new FormData();
        formData.append('file', file);
        
        if (options.sessionId) {
          formData.append('session_id', options.sessionId);
        }

        const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8000'}/api/v1/upload`, {
          method: 'POST',
          body: formData,
          headers: this.getAuthHeaders(),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.detail || 'Upload failed');
        }

        const result = await response.json();
        uploadedPaths[index] = result.path;

        // Update progress to completed
        progress[index].progress = 100;
        progress[index].status = 'completed';
        options.onProgress?.([...progress]);

        completedUploads++;
        if (completedUploads === files.length) {
          options.onUploadComplete?.(uploadedPaths);
        }

        return result.path;
      } catch (error) {
        // Update progress to error
        progress[index].status = 'error';
        progress[index].error = error instanceof Error ? error.message : 'Upload failed';
        options.onProgress?.([...progress]);
        
        console.error(`Upload failed for file ${file.name}:`, error);
        throw error;
      }
    });

    try {
      await Promise.all(uploadPromises);
      return uploadedPaths;
    } catch (error) {
      options.onUploadError?.(error instanceof Error ? error.message : 'One or more uploads failed');
      throw error;
    }
  }

  /**
   * Upload files using drag and drop with enhanced progress tracking
   */
  async uploadDroppedFiles(
    droppedFiles: FileList,
    options: UploadOptions = {}
  ): Promise<string[]> {
    const files = Array.from(droppedFiles);
    return this.uploadMultipleFiles(files, options);
  }

  /**
   * Get upload progress for multiple files
   */
  getUploadProgress(files: File[]): UploadProgress[] {
    return files.map(file => ({
      fileName: file.name,
      progress: 0,
      status: 'pending',
    }));
  }

  /**
   * Validate file before upload
   */
  private validateFile(file: File, options: Partial<UploadOptions>): void {
    const maxFileSize = options.maxFileSize || this.MAX_FILE_SIZE;
    const allowedTypes = options.allowedTypes || this.ALLOWED_TYPES;

    // Check file size
    if (file.size > maxFileSize) {
      const maxSizeMB = Math.round(maxFileSize / (1024 * 1024));
      throw new Error(`File size exceeds ${maxSizeMB}MB limit. Current size: ${this.formatFileSize(file.size)}`);
    }

    // Check file type
    if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
      throw new Error(`File type ${file.type} is not supported. Allowed types: ${allowedTypes.join(', ')}`);
    }

    // Check file name for security
    if (this.containsDangerousCharacters(file.name)) {
      throw new Error('File name contains dangerous characters');
    }
  }

  /**
   * Check if filename contains dangerous characters
   */
  private containsDangerousCharacters(fileName: string): boolean {
    const dangerousChars = /[<>:"|?*\x00-\x1f]/;
    return dangerousChars.test(fileName);
  }

  /**
   * Format file size for display
   */
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Get file icon based on type
   */
  getFileIcon(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    const iconMap: Record<string, string> = {
      pdf: '📄',
      doc: '📝',
      docx: '📝',
      txt: '📋',
      json: '🗂️',
      csv: '📊',
      jpg: '🖼️',
      jpeg: '🖼️',
      png: '🖼️',
      gif: '🖼️',
    };
    
    return iconMap[extension || ''] || '📎';
  }

  /**
   * Check if file type is supported
   */
  isFileTypeSupported(file: File, allowedTypes?: string[]): boolean {
    const types = allowedTypes || this.ALLOWED_TYPES;
    return types.includes(file.type);
  }

  /**
   * Check if file size is within limit
   */
  isFileSizeValid(file: File, maxSize?: number): boolean {
    const max = maxSize || this.MAX_FILE_SIZE;
    return file.size <= max;
  }

  /**
   * Get authentication headers for upload requests
   */
  private getAuthHeaders(): Record<string, string> {
    const token = localStorage.getItem('auth_token');
    const headers: Record<string, string> = {};
    
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    
    return headers;
  }

  /**
   * Upload file with chunked upload for large files
   */
  async uploadLargeFile(
    file: File,
    chunkSize: number = 1024 * 1024, // 1MB chunks
    options: Partial<UploadOptions> = {}
  ): Promise<string> {
    if (file.size <= chunkSize) {
      return this.uploadFile(file, options.sessionId, options);
    }

    // For large files, implement chunked upload logic here
    // This is a placeholder for future implementation
    throw new Error('Chunked upload not yet implemented');
  }

  /**
   * Cancel ongoing uploads
   */
  cancelUploads(): void {
    // Implementation for canceling uploads would go here
    // This would require tracking upload requests and aborting them
  }
}

// Export singleton instance
export const fileUploadService = new FileUploadService();
export default fileUploadService;