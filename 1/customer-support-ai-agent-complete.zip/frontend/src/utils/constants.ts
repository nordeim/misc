/**
 * Application Constants

Central location for all application-wide constants, configurations,
and enumerations used throughout the frontend.
 */

// API Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  TIMEOUT: 30000,
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000,
} as const;

// WebSocket Configuration
export const WS_CONFIG = {
  URL: import.meta.env.VITE_WS_URL || 'ws://localhost:8000',
  RECONNECTION_ATTEMPTS: 5,
  RECONNECTION_DELAY: 1000,
  RECONNECTION_DELAY_MAX: 5000,
  PING_INTERVAL: 30000,
  PING_TIMEOUT: 5000,
} as const;

// File Upload Configuration
export const FILE_UPLOAD_CONFIG = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  MAX_FILES: 10,
  ALLOWED_TYPES: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'application/json',
    'text/csv',
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'text/markdown',
  ] as const,
  CHUNK_SIZE: 1024 * 1024, // 1MB chunks for large files
} as const;

// Chat Configuration
export const CHAT_CONFIG = {
  MAX_MESSAGE_LENGTH: 2000,
  MAX_MESSAGES_PER_SESSION: 1000,
  TYPING_DEBOUNCE_MS: 1000,
  AUTO_SAVE_INTERVAL: 30000, // 30 seconds
  MESSAGE_BATCH_SIZE: 50,
  AUTO_SCROLL_THRESHOLD: 100, // pixels from bottom
} as const;

// Session Configuration
export const SESSION_CONFIG = {
  DEFAULT_TITLE: 'New Chat',
  MAX_TITLE_LENGTH: 100,
  AUTO_GENERATE_TITLE: true,
  RETENTION_DAYS: 30,
  MAX_SESSIONS_PER_USER: 100,
} as const;

// UI Configuration
export const UI_CONFIG = {
  SIDEBAR_WIDTH: 280,
  HEADER_HEIGHT: 64,
  TOAST_DURATION: 5000,
  MODAL_ANIMATION_DURATION: 300,
  DEBOUNCE_DELAY: 300,
  THEME_CONFIG: {
    DEFAULT_THEME: 'light',
    STORAGE_KEY: 'app-theme',
  },
  BREAKPOINTS: {
    SM: 640,
    MD: 768,
    LG: 1024,
    XL: 1280,
    '2XL': 1536,
  },
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  SERVER_ERROR: 'Server error. Please try again later.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  FORBIDDEN: 'Access denied.',
  NOT_FOUND: 'The requested resource was not found.',
  TIMEOUT: 'Request timed out. Please try again.',
  VALIDATION_ERROR: 'Please check your input and try again.',
  FILE_TOO_LARGE: 'File size exceeds the maximum limit.',
  UNSUPPORTED_FILE_TYPE: 'This file type is not supported.',
  UPLOAD_FAILED: 'File upload failed. Please try again.',
  GENERIC_ERROR: 'An unexpected error occurred.',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  MESSAGE_SENT: 'Message sent successfully.',
  FILE_UPLOADED: 'File uploaded successfully.',
  SESSION_CREATED: 'New chat session created.',
  SESSION_UPDATED: 'Session updated successfully.',
  SESSION_DELETED: 'Session deleted successfully.',
  PROFILE_UPDATED: 'Profile updated successfully.',
  PASSWORD_CHANGED: 'Password changed successfully.',
  LOGIN_SUCCESS: 'Login successful.',
  LOGOUT_SUCCESS: 'Logged out successfully.',
  SETTINGS_SAVED: 'Settings saved successfully.',
} as const;

// Storage Keys
export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  USER_DATA: 'current_user',
  THEME: 'app-theme',
  LANGUAGE: 'app-language',
  CHAT_HISTORY: 'chat_history',
  USER_PREFERENCES: 'user_preferences',
  SESSION_DATA: 'session_data',
  NOTIFICATIONS: 'notifications',
  WORKSPACE: 'workspace_data',
} as const;

// API Endpoints
export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/auth/login',
    LOGOUT: '/auth/logout',
    REGISTER: '/auth/register',
    REFRESH: '/auth/refresh',
    VALIDATE: '/auth/validate',
    PROFILE: '/auth/profile',
    CHANGE_PASSWORD: '/auth/change-password',
  },
  CHAT: {
    SEND_MESSAGE: '/api/v1/chat',
    SESSIONS: '/api/v1/sessions',
    SESSION_MESSAGES: (sessionId: string) => `/api/v1/sessions/${sessionId}/messages`,
    UPDATE_SESSION_TITLE: (sessionId: string) => `/api/v1/sessions/${sessionId}/title`,
    DELETE_SESSION: (sessionId: string) => `/api/v1/sessions/${sessionId}`,
  },
  FILES: {
    UPLOAD: '/api/v1/upload',
    UPLOAD_MULTIPLE: '/api/v1/upload/multiple',
    DOWNLOAD: (fileId: string) => `/api/v1/files/${fileId}`,
    DELETE: (fileId: string) => `/api/v1/files/${fileId}`,
  },
  KNOWLEDGE: {
    ADD_DOCUMENT: '/api/v1/knowledge',
    SEARCH: '/api/v1/knowledge/search',
    DOCUMENTS: '/api/v1/knowledge/documents',
  },
  AGENT: {
    STATUS: '/api/v1/agent/status',
    RESTART: '/api/v1/agent/restart',
    STATISTICS: '/api/v1/agent/statistics',
  },
  ADMIN: {
    USERS: '/api/v1/admin/users',
    SYSTEM_STATUS: '/api/v1/admin/system',
    LOGS: '/api/v1/admin/logs',
  },
} as const;

// WebSocket Events
export const WS_EVENTS = {
  CONNECTION: 'connection',
  MESSAGE: 'message',
  CHAT_MESSAGE: 'chat_message',
  CHAT_RESPONSE: 'chat_response',
  TYPING_INDICATOR: 'typing_indicator',
  ERROR: 'error',
  PING: 'ping',
  PONG: 'pong',
} as const;

// Message Types
export const MESSAGE_TYPES = {
  USER: 'user',
  ASSISTANT: 'assistant',
  SYSTEM: 'system',
  ERROR: 'error',
} as const;

// User Roles
export const USER_ROLES = {
  USER: 'user',
  ADMIN: 'admin',
  AGENT: 'agent',
  MODERATOR: 'moderator',
} as const;

// Session Status
export const SESSION_STATUS = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  ARCHIVED: 'archived',
  DELETED: 'deleted',
} as const;

// Agent Status
export const AGENT_STATUS = {
  ONLINE: 'online',
  OFFLINE: 'offline',
  BUSY: 'busy',
  AWAY: 'away',
} as const;

// Notification Types
export const NOTIFICATION_TYPES = {
  SUCCESS: 'success',
  ERROR: 'error',
  WARNING: 'warning',
  INFO: 'info',
} as const;

// Theme Options
export const THEME_OPTIONS = {
  LIGHT: 'light',
  DARK: 'dark',
  AUTO: 'auto',
} as const;

// Language Options
export const LANGUAGE_OPTIONS = {
  EN: 'en',
  ES: 'es',
  FR: 'fr',
  DE: 'de',
  IT: 'it',
  PT: 'pt',
  ZH: 'zh',
  JA: 'ja',
  KO: 'ko',
} as const;

// File Types
export const FILE_TYPES = {
  DOCUMENT: 'document',
  IMAGE: 'image',
  VIDEO: 'video',
  AUDIO: 'audio',
  ARCHIVE: 'archive',
  CODE: 'code',
} as const;

// File Extensions
export const FILE_EXTENSIONS = {
  DOCUMENTS: ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt'],
  IMAGES: ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'],
  VIDEOS: ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'],
  AUDIO: ['.mp3', '.wav', '.ogg', '.aac', '.flac'],
  ARCHIVES: ['.zip', '.rar', '.7z', '.tar', '.gz'],
  CODE: ['.js', '.ts', '.py', '.java', '.cpp', '.c', '.cs', '.php', '.rb', '.go', '.rs'],
  DATA: ['.json', '.xml', '.csv', '.xlsx', '.xls', '.sql', '.db', '.sqlite'],
} as const;

// Confidence Levels
export const CONFIDENCE_LEVELS = {
  VERY_HIGH: { min: 0.9, label: 'Very High', color: 'green' },
  HIGH: { min: 0.75, label: 'High', color: 'green' },
  MEDIUM: { min: 0.5, label: 'Medium', color: 'yellow' },
  LOW: { min: 0.25, label: 'Low', color: 'orange' },
  VERY_LOW: { min: 0, label: 'Very Low', color: 'red' },
} as const;

// Keyboard Shortcuts
export const KEYBOARD_SHORTCUTS = {
  SEND_MESSAGE: 'Enter',
  NEW_LINE: 'Shift+Enter',
  FOCUS_INPUT: 'Ctrl+/',
  TOGGLE_SIDEBAR: 'Ctrl+B',
  SEARCH: 'Ctrl+K',
  HELP: 'F1',
  REFRESH: 'F5',
  SAVE: 'Ctrl+S',
} as const;

// Animation Durations
export const ANIMATION_DURATIONS = {
  FAST: 150,
  NORMAL: 300,
  SLOW: 500,
} as const;

// Z-Index Layers
export const Z_INDEX = {
  HIDDEN: -1,
  BASE: 0,
  DROPDOWN: 1000,
  STICKY: 1020,
  FIXED: 1030,
  MODAL_BACKDROP: 1040,
  MODAL: 1050,
  POPOVER: 1060,
  TOOLTIP: 1070,
  NOTIFICATION: 1080,
} as const;

// Accessibility
export const ACCESSIBILITY = {
  MIN_TOUCH_TARGET: 44, // pixels
  FOCUS_VISIBLE_OUTLINE: '2px solid #3b82f6',
  SKIP_TO_CONTENT_ID: 'skip-to-content',
} as const;

// Performance
export const PERFORMANCE = {
  DEBOUNCE_DELAY: 300,
  THROTTLE_DELAY: 100,
  VIRTUAL_SCROLL_ITEM_SIZE: 60,
  LAZY_LOAD_THRESHOLD: 0.8,
  MAX_CONCURRENT_REQUESTS: 6,
} as const;

// Feature Flags
export const FEATURE_FLAGS = {
  ENABLE_WEBSOCKETS: true,
  ENABLE_FILE_UPLOAD: true,
  ENABLE_DARK_MODE: true,
  ENABLE_NOTIFICATIONS: true,
  ENABLE_ANALYTICS: false,
  ENABLE_DEBUG_MODE: import.meta.env.DEV,
  ENABLE_SERVICE_WORKER: 'serviceWorker' in navigator,
  ENABLE_PWA: true,
} as const;

// Default Values
export const DEFAULT_VALUES = {
  USER: {
    AVATAR: '/images/default-avatar.png',
    THEME: THEME_OPTIONS.LIGHT,
    LANGUAGE: LANGUAGE_OPTIONS.EN,
  },
  SESSION: {
    TITLE: SESSION_CONFIG.DEFAULT_TITLE,
    STATUS: SESSION_STATUS.ACTIVE,
  },
  MESSAGE: {
    TYPE: MESSAGE_TYPES.USER,
    MAX_LENGTH: CHAT_CONFIG.MAX_MESSAGE_LENGTH,
  },
  FILE: {
    MAX_SIZE: FILE_UPLOAD_CONFIG.MAX_FILE_SIZE,
    MAX_COUNT: FILE_UPLOAD_CONFIG.MAX_FILES,
  },
} as const;

// Export all constants as a single object
export const CONSTANTS = {
  API_CONFIG,
  WS_CONFIG,
  FILE_UPLOAD_CONFIG,
  CHAT_CONFIG,
  SESSION_CONFIG,
  UI_CONFIG,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  STORAGE_KEYS,
  API_ENDPOINTS,
  WS_EVENTS,
  MESSAGE_TYPES,
  USER_ROLES,
  SESSION_STATUS,
  AGENT_STATUS,
  NOTIFICATION_TYPES,
  THEME_OPTIONS,
  LANGUAGE_OPTIONS,
  FILE_TYPES,
  FILE_EXTENSIONS,
  CONFIDENCE_LEVELS,
  KEYBOARD_SHORTCUTS,
  ANIMATION_DURATIONS,
  Z_INDEX,
  ACCESSIBILITY,
  PERFORMANCE,
  FEATURE_FLAGS,
  DEFAULT_VALUES,
} as const;

export default CONSTANTS;