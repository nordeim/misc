/**
 * General Utility Functions

Common utility functions for data manipulation, DOM operations,
state management, and other general-purpose tasks.
 */

// Debounce function
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(null, args), delay);
  };
}

// Throttle function
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func.apply(null, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), delay);
    }
  };
}

// Deep clone object
export function deepClone<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  
  if (obj instanceof Date) {
    return new Date(obj.getTime()) as unknown as T;
  }
  
  if (obj instanceof Array) {
    return obj.map(item => deepClone(item)) as unknown as T;
  }
  
  if (typeof obj === 'object') {
    const clonedObj = {} as { [key: string]: any };
    Object.keys(obj).forEach(key => {
      clonedObj[key] = deepClone((obj as any)[key]);
    });
    return clonedObj as T;
  }
  
  return obj;
}

// Generate unique ID
export function generateId(prefix: string = 'id'): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Check if value is empty
export function isEmpty(value: any): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return false;
}

// Check if value is not empty
export function isNotEmpty(value: any): boolean {
  return !isEmpty(value);
}

// Capitalize first letter
export function capitalize(str: string): string {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Convert to camelCase
export function toCamelCase(str: string): string {
  return str
    .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
      return index === 0 ? word.toLowerCase() : word.toUpperCase();
    })
    .replace(/\s+/g, '');
}

// Convert to kebab-case
export function toKebabCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/[\s_]+/g, '-')
    .toLowerCase();
}

// Convert to snake_case
export function toSnakeCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .replace(/[\s-]+/g, '_')
    .toLowerCase();
}

// Remove duplicates from array
export function removeDuplicates<T>(array: T[], key?: keyof T): T[] {
  if (!key) {
    return [...new Set(array)];
  }
  
  const seen = new Set();
  return array.filter(item => {
    const value = item[key];
    if (seen.has(value)) {
      return false;
    }
    seen.add(value);
    return true;
  });
}

// Sort array by key
export function sortBy<T>(array: T[], key: keyof T, order: 'asc' | 'desc' = 'asc'): T[] {
  return [...array].sort((a, b) => {
    const aVal = a[key];
    const bVal = b[key];
    
    if (aVal < bVal) return order === 'asc' ? -1 : 1;
    if (aVal > bVal) return order === 'asc' ? 1 : -1;
    return 0;
  });
}

// Group array by key
export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce((groups, item) => {
    const group = String(item[key]);
    groups[group] = groups[group] || [];
    groups[group].push(item);
    return groups;
  }, {} as Record<string, T[]>);
}

// Chunk array into smaller arrays
export function chunk<T>(array: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

// Get random item from array
export function getRandomItem<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

// Shuffle array
export function shuffle<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// Check if object has property
export function hasProperty(obj: any, key: string): boolean {
  return Object.prototype.hasOwnProperty.call(obj, key);
}

// Get nested property value
export function getNestedValue(obj: any, path: string, defaultValue?: any): any {
  const keys = path.split('.');
  let result = obj;
  
  for (const key of keys) {
    if (result === null || result === undefined || !hasProperty(result, key)) {
      return defaultValue;
    }
    result = result[key];
  }
  
  return result;
}

// Set nested property value
export function setNestedValue(obj: any, path: string, value: any): void {
  const keys = path.split('.');
  const lastKey = keys.pop()!;
  let current = obj;
  
  for (const key of keys) {
    if (!current[key] || typeof current[key] !== 'object') {
      current[key] = {};
    }
    current = current[key];
  }
  
  current[lastKey] = value;
}

// Delete nested property
export function deleteNestedValue(obj: any, path: string): void {
  const keys = path.split('.');
  const lastKey = keys.pop()!;
  let current = obj;
  
  for (const key of keys) {
    if (!current[key] || typeof current[key] !== 'object') {
      return; // Path doesn't exist
    }
    current = current[key];
  }
  
  delete current[lastKey];
}

// Local storage utilities
export const storage = {
  get: (key: string, defaultValue: any = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  },
  
  set: (key: string, value: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  },
  
  remove: (key: string) => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Failed to remove from localStorage:', error);
    }
  },
  
  clear: () => {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('Failed to clear localStorage:', error);
    }
  }
};

// Session storage utilities
export const sessionStorage = {
  get: (key: string, defaultValue: any = null) => {
    try {
      const item = window.sessionStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  },
  
  set: (key: string, value: any) => {
    try {
      window.sessionStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Failed to save to sessionStorage:', error);
    }
  },
  
  remove: (key: string) => {
    try {
      window.sessionStorage.removeItem(key);
    } catch (error) {
      console.error('Failed to remove from sessionStorage:', error);
    }
  },
  
  clear: () => {
    try {
      window.sessionStorage.clear();
    } catch (error) {
      console.error('Failed to clear sessionStorage:', error);
    }
  }
};

// URL utilities
export const url = {
  getParams: (search?: string): URLSearchParams => {
    return new URLSearchParams(search || window.location.search);
  },
  
  getParam: (param: string, search?: string): string | null => {
    return url.getParams(search).get(param);
  },
  
  setParam: (param: string, value: string): string => {
    const params = url.getParams();
    params.set(param, value);
    return `?${params.toString()}`;
  },
  
  removeParam: (param: string): string => {
    const params = url.getParams();
    params.delete(param);
    return `?${params.toString()}`;
  },
  
  buildUrl: (base: string, params: Record<string, string | number | boolean>): string => {
    const url = new URL(base, window.location.origin);
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.set(key, String(value));
    });
    return url.toString();
  }
};

// Color utilities
export const colors = {
  hexToRgb: (hex: string): { r: number; g: number; b: number } | null => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  },
  
  rgbToHex: (r: number, g: number, b: number): string => {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  },
  
  getContrastColor: (hexColor: string): string => {
    const rgb = colors.hexToRgb(hexColor);
    if (!rgb) return '#000000';
    
    const brightness = (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    return brightness > 128 ? '#000000' : '#ffffff';
  },
  
  generateGradient: (colors: string[]): string => {
    if (colors.length === 1) return colors[0];
    return `linear-gradient(90deg, ${colors.join(', ')})`;
  }
};

// Math utilities
export const math = {
  clamp: (value: number, min: number, max: number): number => {
    return Math.min(Math.max(value, min), max);
  },
  
  lerp: (start: number, end: number, factor: number): number => {
    return start + (end - start) * factor;
  },
  
  map: (value: number, inMin: number, inMax: number, outMin: number, outMax: number): number => {
    return outMin + (outMax - outMin) * ((value - inMin) / (inMax - inMin));
  },
  
  average: (numbers: number[]): number => {
    return numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
  },
  
  median: (numbers: number[]): number => {
    const sorted = [...numbers].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    
    if (sorted.length % 2 === 0) {
      return (sorted[mid - 1] + sorted[mid]) / 2;
    } else {
      return sorted[mid];
    }
  },
  
  sum: (numbers: number[]): number => {
    return numbers.reduce((sum, num) => sum + num, 0);
  }
};

// Array utilities
export const arrays = {
  last: <T>(array: T[]): T | undefined => {
    return array[array.length - 1];
  },
  
  first: <T>(array: T[]): T | undefined => {
    return array[0];
  },
  
  findIndex: <T>(array: T[], predicate: (item: T, index: number) => boolean): number => {
    return array.findIndex(predicate);
  },
  
  findLast: <T>(array: T[], predicate: (item: T) => boolean): T | undefined => {
    for (let i = array.length - 1; i >= 0; i--) {
      if (predicate(array[i])) {
        return array[i];
      }
    }
    return undefined;
  },
  
  includes: <T>(array: T[], value: T): boolean => {
    return array.includes(value);
  },
  
  range: (start: number, end: number, step: number = 1): number[] => {
    const result: number[] = [];
    for (let i = start; i < end; i += step) {
      result.push(i);
    }
    return result;
  },
  
  unique: <T>(array: T[]): T[] => {
    return [...new Set(array)];
  }
};

// String utilities
export const strings = {
  pad: (num: number, size: number): string => {
    let s = String(num);
    while (s.length < size) s = "0" + s;
    return s;
  },
  
  truncate: (str: string, length: number, suffix: string = '...'): string => {
    if (str.length <= length) return str;
    return str.substring(0, length - suffix.length) + suffix;
  },
  
  escapeHtml: (str: string): string => {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },
  
  escapeRegex: (str: string): string => {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  },
  
  toTitleCase: (str: string): string => {
    return str.replace(/\w\S*/g, (txt) => 
      txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
    );
  },
  
  stripHtml: (str: string): string => {
    return str.replace(/<[^>]*>/g, '');
  }
};

// Performance utilities
export const performance = {
  now: (): number => {
    return performance.now();
  },
  
  measure: (name: string, fn: () => void): void => {
    const start = performance.now();
    fn();
    const end = performance.now();
    console.log(`${name} took ${end - start} milliseconds`);
  },
  
  async: async <T>(name: string, fn: () => Promise<T>): Promise<T> => {
    const start = performance.now();
    const result = await fn();
    const end = performance.now();
    console.log(`${name} took ${end - start} milliseconds`);
    return result;
  }
};

// Browser utilities
export const browser = {
  isMobile: (): boolean => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  },
  
  isIOS: (): boolean => {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
  },
  
  isAndroid: (): boolean => {
    return /Android/.test(navigator.userAgent);
  },
  
  isSafari: (): boolean => {
    return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
  },
  
  isFirefox: (): boolean => {
    return /firefox/i.test(navigator.userAgent);
  },
  
  isChrome: (): boolean => {
    return /chrome/i.test(navigator.userAgent) && !/edg/i.test(navigator.userAgent);
  },
  
  isEdge: (): boolean => {
    return /edg/i.test(navigator.userAgent);
  },
  
  supportsWebP: (): boolean => {
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
  },
  
  supportsServiceWorker: (): boolean => {
    return 'serviceWorker' in navigator;
  },
  
  supportsWebSocket: (): boolean => {
    return 'WebSocket' in window;
  },
  
  isOnline: (): boolean => {
    return navigator.onLine;
  }
};

// DOM utilities
export const dom = {
  createElement: (tag: string, className?: string, text?: string): HTMLElement => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text) element.textContent = text;
    return element;
  },
  
  removeAllChildren: (element: HTMLElement): void => {
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
  },
  
  getElementOffset: (element: HTMLElement): { top: number; left: number } => {
    const rect = element.getBoundingClientRect();
    return {
      top: rect.top + window.pageYOffset,
      left: rect.left + window.pageXOffset
    };
  },
  
  isElementInViewport: (element: HTMLElement): boolean => {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },
  
  scrollToElement: (element: HTMLElement, offset: number = 0): void => {
    const elementTop = dom.getElementOffset(element).top - offset;
    window.scrollTo({
      top: elementTop,
      behavior: 'smooth'
    });
  }
};

// Error handling utilities
export const errors = {
  try: <T>(fn: () => T): { success: boolean; data?: T; error?: any } => {
    try {
      const data = fn();
      return { success: true, data };
    } catch (error) {
      return { success: false, error };
    }
  },
  
  async tryAsync: async <T>(fn: () => Promise<T>): Promise<{ success: boolean; data?: T; error?: any }> => {
    try {
      const data = await fn();
      return { success: true, data };
    } catch (error) {
      return { success: false, error };
    }
  },
  
  isError: (error: any): error is Error => {
    return error instanceof Error;
  },
  
  getErrorMessage: (error: any): string => {
    if (errors.isError(error)) {
      return error.message;
    }
    
    if (typeof error === 'string') {
      return error;
    }
    
    if (error && typeof error === 'object' && 'message' in error) {
      return String(error.message);
    }
    
    return 'An unknown error occurred';
  }
};

// Export all utilities
export default {
  debounce,
  throttle,
  deepClone,
  generateId,
  isEmpty,
  isNotEmpty,
  capitalize,
  toCamelCase,
  toKebabCase,
  toSnakeCase,
  removeDuplicates,
  sortBy,
  groupBy,
  chunk,
  getRandomItem,
  shuffle,
  hasProperty,
  getNestedValue,
  setNestedValue,
  deleteNestedValue,
  storage,
  sessionStorage,
  url,
  colors,
  math,
  arrays,
  strings,
  performance,
  browser,
  dom,
  errors,
};