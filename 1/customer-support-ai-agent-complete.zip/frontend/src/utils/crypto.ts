/**
 * Simple Encryption/Decryption Utilities

Provides basic encryption functions using Web Crypto API.
Note: For production use, implement proper key management and security practices.
 */

const ALGORITHM = 'AES-GCM';
const KEY_LENGTH = 256;
const IV_LENGTH = 12;

/**
 * Generate encryption key from a password
 */
async function generateKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 100000,
      hash: 'SHA-256',
    },
    passwordKey,
    { name: ALGORITHM, length: KEY_LENGTH },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Generate random salt
 */
function generateSalt(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(16));
}

/**
 * Generate random IV
 */
function generateIV(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(IV_LENGTH));
}

/**
 * Convert ArrayBuffer to base64
 */
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Convert base64 to ArrayBuffer
 */
function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Encrypt data with password
 */
export async function encrypt(data: string, password?: string): Promise<string> {
  try {
    // If no password provided, use a default one (NOT SECURE for production)
    const encryptionPassword = password || 'customer-support-ai-default-key';
    
    const salt = generateSalt();
    const iv = generateIV();
    const key = await generateKey(encryptionPassword, salt);
    
    const encoder = new TextEncoder();
    const encodedData = encoder.encode(data);
    
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: ALGORITHM,
        iv: iv,
      },
      key,
      encodedData
    );
    
    // Combine salt, iv, and encrypted data
    const combined = new Uint8Array(salt.length + iv.length + encryptedData.byteLength);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(new Uint8Array(encryptedData), salt.length + iv.length);
    
    return arrayBufferToBase64(combined);
  } catch (error) {
    console.error('Encryption failed:', error);
    // Return original data if encryption fails
    return data;
  }
}

/**
 * Decrypt data with password
 */
export async function decrypt(encryptedData: string, password?: string): Promise<string> {
  try {
    // If no password provided, use a default one (NOT SECURE for production)
    const encryptionPassword = password || 'customer-support-ai-default-key';
    
    const combined = new Uint8Array(base64ToArrayBuffer(encryptedData));
    
    // Extract salt, iv, and encrypted data
    const salt = combined.slice(0, 16);
    const iv = combined.slice(16, 16 + IV_LENGTH);
    const data = combined.slice(16 + IV_LENGTH);
    
    const key = await generateKey(encryptionPassword, salt);
    
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: ALGORITHM,
        iv: iv,
      },
      key,
      data
    );
    
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  } catch (error) {
    console.error('Decryption failed:', error);
    // Return original data if decryption fails
    return encryptedData;
  }
}

/**
 * Hash string using SHA-256
 */
export async function hash(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const encodedData = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', encodedData);
  return arrayBufferToBase64(hashBuffer);
}

/**
 * Generate secure random token
 */
export function generateSecureToken(length: number = 32): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return arrayBufferToBase64(array.buffer);
}

/**
 * Check if Web Crypto API is supported
 */
export function isCryptoSupported(): boolean {
  return 'crypto' in window && 'subtle' in crypto;
}