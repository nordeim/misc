/**
 * Frontend Utils Index

Central export point for all utility functions and services.
Organizes and exports utilities for easy importing throughout the application.
 */

// Services
export * from '../services/api';
export * from '../services/websocket';
export * from '../services/auth';
export * from '../services/fileUpload';

// Types (already in types/index.ts)
export * from '../types';

// Formatting utilities
export * from './formatting';

// Validation utilities
export * from './validation';

// Constants
export * from './constants';

// General utilities
export * from './utils';

// Service Worker utilities
export * from './serviceWorker';

// Push notification utilities
export * from './pushNotifications';

// Local storage utilities
export * from './localStorage';

// Crypto utilities
export * from './crypto';

// Error handling utilities
export * from './errorHandling';

// Export specific utility functions for convenience
import { 
  debounce, 
  throttle, 
  generateId, 
  isEmpty, 
  capitalize,
  deepClone,
  storage,
  sessionStorage,
  url,
  colors,
  math,
  arrays,
  strings,
  performance,
  browser,
  dom,
  errors
} from './utils';

import { 
  validateEmail,
  validatePassword,
  validatePhoneNumber,
  validateUrl,
  validateFile,
  validateFiles,
  validateTextContent,
  validateForm
} from './validation';

import { 
  formatDate,
  formatRelativeTime,
  formatFileSize,
  formatDuration,
  truncateText,
  formatPhoneNumber,
  formatCurrency,
  formatPercentage,
  formatNumber,
  formatConfidence,
  formatMessageContent
} from './formatting';

import { 
  API_CONFIG,
  WS_CONFIG,
  FILE_UPLOAD_CONFIG,
  CHAT_CONFIG,
  SESSION_CONFIG,
  UI_CONFIG,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  STORAGE_KEYS,
  API_ENDPOINTS,
  WS_EVENTS,
  MESSAGE_TYPES,
  USER_ROLES,
  SESSION_STATUS,
  AGENT_STATUS,
  NOTIFICATION_TYPES,
  THEME_OPTIONS,
  LANGUAGE_OPTIONS,
  FILE_TYPES,
  FILE_EXTENSIONS,
  CONFIDENCE_LEVELS,
  KEYBOARD_SHORTCUTS,
  ANIMATION_DURATIONS,
  Z_INDEX,
  ACCESSIBILITY,
  PERFORMANCE,
  FEATURE_FLAGS,
  DEFAULT_VALUES
} from './constants';

import { 
  setItem,
  getItem,
  removeItem,
  clear,
  hasItem,
  getKeys,
  getStats,
  subscribe,
  getMultiple,
  setMultiple,
  removeMultiple,
  exportStorage,
  importStorage,
  saveUserPreferences,
  loadUserPreferences,
  saveChatHistory,
  loadChatHistory,
  saveTheme,
  loadTheme,
  clearExpiredData
} from './localStorage';

import { 
  showSuccess,
  showError,
  showWarning,
  showInfo,
  showLoading,
  dismissToast,
  dismissAllToasts,
  handleError
} from './errorHandling';

import { 
  isCryptoSupported,
  encrypt,
  decrypt,
  hash,
  generateSecureToken
} from './crypto';

import { 
  registerServiceWorker,
  unregisterServiceWorker,
  updateServiceWorker,
  showUpdateNotification
} from './serviceWorker';

import { 
  requestNotificationPermission,
  showNotification,
  showChatNotification,
  showSystemNotification,
  testNotifications,
  subscribeToPush,
  unsubscribeFromPush,
  getNotificationPermissionState
} from './pushNotifications';

// Re-export commonly used utilities for convenience
export const utils = {
  // Core utilities
  debounce,
  throttle,
  generateId,
  isEmpty,
  capitalize,
  deepClone,
  
  // Storage
  storage,
  sessionStorage,
  
  // URL utilities
  url,
  
  // Formatting
  formatDate,
  formatRelativeTime,
  formatFileSize,
  formatDuration,
  truncateText,
  formatPhoneNumber,
  formatCurrency,
  formatPercentage,
  formatNumber,
  formatConfidence,
  formatMessageContent,
  
  // Validation
  validateEmail,
  validatePassword,
  validatePhoneNumber,
  validateUrl,
  validateFile,
  validateFiles,
  validateTextContent,
  validateForm,
  
  // Constants
  API_CONFIG,
  WS_CONFIG,
  FILE_UPLOAD_CONFIG,
  CHAT_CONFIG,
  SESSION_CONFIG,
  UI_CONFIG,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  STORAGE_KEYS,
  API_ENDPOINTS,
  WS_EVENTS,
  MESSAGE_TYPES,
  USER_ROLES,
  SESSION_STATUS,
  AGENT_STATUS,
  NOTIFICATION_TYPES,
  THEME_OPTIONS,
  LANGUAGE_OPTIONS,
  FILE_TYPES,
  FILE_EXTENSIONS,
  CONFIDENCE_LEVELS,
  KEYBOARD_SHORTCUTS,
  ANIMATION_DURATIONS,
  Z_INDEX,
  ACCESSIBILITY,
  PERFORMANCE,
  FEATURE_FLAGS,
  DEFAULT_VALUES,
  
  // Storage management
  setItem,
  getItem,
  removeItem,
  clear,
  hasItem,
  getKeys,
  getStats,
  subscribe,
  getMultiple,
  setMultiple,
  removeMultiple,
  exportStorage,
  importStorage,
  saveUserPreferences,
  loadUserPreferences,
  saveChatHistory,
  loadChatHistory,
  saveTheme,
  loadTheme,
  clearExpiredData,
  
  // Error handling
  showSuccess,
  showError,
  showWarning,
  showInfo,
  showLoading,
  dismissToast,
  dismissAllToasts,
  handleError,
  
  // Crypto
  isCryptoSupported,
  encrypt,
  decrypt,
  hash,
  generateSecureToken,
  
  // Service Worker
  registerServiceWorker,
  unregisterServiceWorker,
  updateServiceWorker,
  showUpdateNotification,
  
  // Push Notifications
  requestNotificationPermission,
  showNotification,
  showChatNotification,
  showSystemNotification,
  testNotifications,
  subscribeToPush,
  unsubscribeFromPush,
  getNotificationPermissionState,
  
  // Advanced utilities
  colors,
  math,
  arrays,
  strings,
  performance,
  browser,
  dom,
  errors
};

// Create a comprehensive API object
export const frontendAPI = {
  // Core functionality
  utils,
  
  // Services
  api: () => import('../services/api').then(m => m.default),
  websocket: () => import('../services/websocket').then(m => m.default),
  auth: () => import('../services/auth').then(m => m.default),
  fileUpload: () => import('../services/fileUpload').then(m => m.default),
  
  // Storage
  storage: () => import('./localStorage').then(m => m.default),
  
  // Error handling
  errorHandler: () => import('./errorHandling').then(m => m.default),
  
  // Service Worker
  serviceWorker: () => import('./serviceWorker').then(m => m.default),
  
  // Push notifications
  notifications: () => import('./pushNotifications').then(m => m.default),
  
  // Crypto
  crypto: () => import('./crypto').then(m => m),
};

// Version information
export const VERSION = '1.0.0';
export const BUILD_DATE = new Date().toISOString();

// Environment information
export const ENVIRONMENT = {
  development: import.meta.env.DEV,
  production: import.meta.env.PROD,
  test: import.meta.env.MODE === 'test',
  debug: import.meta.env.DEV,
};

// Feature flags
export const FEATURES = {
  offline: true,
  pushNotifications: true,
  serviceWorker: 'serviceWorker' in navigator,
  webCrypto: 'crypto' in window && 'subtle' in crypto,
  fileAPI: 'FileReader' in window,
  webRTC: 'RTCPeerConnection' in window,
  webSockets: 'WebSocket' in window,
  webGL: (() => {
    try {
      const canvas = document.createElement('canvas');
      return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
    } catch {
      return false;
    }
  })(),
  touchEvents: 'ontouchstart' in window,
  pointerEvents: 'PointerEvent' in window,
  intersectionObserver: 'IntersectionObserver' in window,
  mutationObserver: 'MutationObserver' in window,
  broadcastChannel: 'BroadcastChannel' in window,
  indexedDB: 'indexedDB' in window,
  localStorage: 'localStorage' in window,
  sessionStorage: 'sessionStorage' in window,
};

// Browser capabilities
export const BROWSER_INFO = {
  userAgent: navigator.userAgent,
  language: navigator.language,
  languages: navigator.languages,
  platform: navigator.platform,
  cookieEnabled: navigator.cookieEnabled,
  onLine: navigator.onLine,
  viewport: {
    width: window.innerWidth,
    height: window.innerHeight
  },
  screen: {
    width: screen.width,
    height: screen.height,
    colorDepth: screen.colorDepth,
    pixelDepth: screen.pixelDepth
  },
  device: {
    touch: 'ontouchstart' in window,
    mobile: /Mobile|Android|iOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
    iOS: /iPad|iPhone|iPod/.test(navigator.userAgent),
    Android: /Android/.test(navigator.userAgent),
    Safari: /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
    Chrome: /chrome/i.test(navigator.userAgent) && !/edg/i.test(navigator.userAgent),
    Firefox: /firefox/i.test(navigator.userAgent),
    Edge: /edg/i.test(navigator.userAgent),
    Opera: /opera/i.test(navigator.userAgent),
    IE: /msie|trident/i.test(navigator.userAgent)
  }
};

export default frontendAPI;