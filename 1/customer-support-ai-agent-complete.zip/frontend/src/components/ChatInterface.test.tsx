import { describe, it, expect, vi } from 'vitest'
import { screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders, createMockMessage } from '@/test/utils'
import ChatInterface from './ChatInterface'

// Mock child components
vi.mock('./MessageBubble', () => ({
  default: ({ message }: { message: any }) => (
    <div data-testid="message-bubble">{message.content}</div>
  ),
}))

vi.mock('./TypingIndicator', () => ({
  default: () => <div data-testid="typing-indicator">Agent is typing...</div>,
}))

// Mock services
vi.mock('@/services/api', () => ({
  sendMessage: vi.fn(),
  getMessages: vi.fn(),
}))

// Mock hooks
vi.mock('@/hooks/useWebSocket', () => ({
  useWebSocket: () => ({
    connected: true,
    sendMessage: vi.fn(),
    lastMessage: null,
  }),
}))

vi.mock('react-hot-toast', () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    loading: vi.fn(),
    dismiss: vi.fn(),
  },
}))

describe('ChatInterface', () => {
  const mockMessages = [
    createMockMessage({ id: '1', content: 'Hello', sender: 'user' }),
    createMockMessage({ id: '2', content: 'Hi there!', sender: 'agent' }),
  ]

  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders without crashing', () => {
    renderWithProviders(<ChatInterface />)
    expect(document.body).toBeInTheDocument()
  })

  it('displays chat messages', async () => {
    const { getMessages } = await import('@/services/api')
    vi.mocked(getMessages).mockResolvedValue({ data: mockMessages })
    
    renderWithProviders(<ChatInterface />)
    
    await waitFor(() => {
      expect(screen.getByText('Hello')).toBeInTheDocument()
      expect(screen.getByText('Hi there!')).toBeInTheDocument()
    })
  })

  it('has a message input field', () => {
    renderWithProviders(<ChatInterface />)
    const input = screen.getByPlaceholderText('Type your message...')
    expect(input).toBeInTheDocument()
  })

  it('has a send button', () => {
    renderWithProviders(<ChatInterface />)
    const sendButton = screen.getByRole('button', { name: /send/i })
    expect(sendButton).toBeInTheDocument()
  })

  it('sends message when form is submitted', async () => {
    const user = userEvent.setup()
    const { sendMessage } = await import('@/services/api')
    vi.mocked(sendMessage).mockResolvedValue({ data: {} })
    
    renderWithProviders(<ChatInterface />)
    
    const input = screen.getByPlaceholderText('Type your message...')
    const sendButton = screen.getByRole('button', { name: /send/i })
    
    await user.type(input, 'Test message')
    await user.click(sendButton)
    
    expect(sendMessage).toHaveBeenCalledWith('Test message')
    expect(input).toHaveValue('')
  })

  it('sends message on Enter key press', async () => {
    const user = userEvent.setup()
    const { sendMessage } = await import('@/services/api')
    vi.mocked(sendMessage).mockResolvedValue({ data: {} })
    
    renderWithProviders(<ChatInterface />)
    
    const input = screen.getByPlaceholderText('Type your message...')
    
    await user.type(input, 'Test message{enter}')
    
    expect(sendMessage).toHaveBeenCalledWith('Test message')
    expect(input).toHaveValue('')
  })

  it('disables send button when input is empty', () => {
    renderWithProviders(<ChatInterface />)
    const sendButton = screen.getByRole('button', { name: /send/i })
    
    const input = screen.getByPlaceholderText('Type your message...')
    expect(input).toHaveValue('')
    
    expect(sendButton).toBeDisabled()
  })

  it('enables send button when input has content', async () => {
    const user = userEvent.setup()
    renderWithProviders(<ChatInterface />)
    
    const input = screen.getByPlaceholderText('Type your message...')
    const sendButton = screen.getByRole('button', { name: /send/i })
    
    await user.type(input, 'Test message')
    
    expect(sendButton).not.toBeDisabled()
  })

  it('handles message sending errors', async () => {
    const user = userEvent.setup()
    const { sendMessage } = await import('@/services/api')
    const { toast } = await import('react-hot-toast')
    vi.mocked(sendMessage).mockRejectedValue(new Error('Network error'))
    
    renderWithProviders(<ChatInterface />)
    
    const input = screen.getByPlaceholderText('Type your message...')
    const sendButton = screen.getByRole('button', { name: /send/i })
    
    await user.type(input, 'Test message')
    await user.click(sendButton)
    
    await waitFor(() => {
      expect(toast.error).toHaveBeenCalled()
    })
  })

  it('displays typing indicator when agent is typing', () => {
    // This would require mocking the WebSocket to simulate typing
    renderWithProviders(<ChatInterface />)
    // Add specific test for typing indicator
  })

  it('scrolls to bottom when new message arrives', async () => {
    const user = userEvent.setup()
    const { getMessages } = await import('@/services/api')
    vi.mocked(getMessages).mockResolvedValue({ data: mockMessages })
    
    const { sendMessage } = await import('@/services/api')
    vi.mocked(sendMessage).mockResolvedValue({ 
      data: createMockMessage({ id: '3', content: 'New message', sender: 'user' }) 
    })
    
    renderWithProviders(<ChatInterface />)
    
    const input = screen.getByPlaceholderText('Type your message...')
    const sendButton = screen.getByRole('button', { name: /send/i })
    
    await user.type(input, 'Test message')
    await user.click(sendButton)
    
    // Mock scroll behavior
    const scrollContainer = document.querySelector('[data-testid="chat-messages"]')
    expect(scrollContainer).toBeInTheDocument()
  })

  it('has proper accessibility features', () => {
    renderWithProviders(<ChatInterface />)
    
    // Check for proper ARIA labels
    const chatContainer = screen.getByLabelText('Chat messages')
    expect(chatContainer).toBeInTheDocument()
    
    const messageInput = screen.getByLabelText('Type your message')
    expect(messageInput).toBeInTheDocument()
  })

  it('supports keyboard navigation', async () => {
    const user = userEvent.setup()
    renderWithProviders(<ChatInterface />)
    
    // Focus management test
    const input = screen.getByPlaceholderText('Type your message...')
    await user.click(input)
    expect(input).toHaveFocus()
    
    // Enter key handling
    await user.type(input, 'Test message{enter}')
    expect(input).not.toHaveFocus()
  })

  it('handles file attachments', async () => {
    // Test file attachment functionality
    renderWithProviders(<ChatInterface />)
    
    const fileButton = screen.getByText('Attach file')
    expect(fileButton).toBeInTheDocument()
  })

  it('maintains chat history', async () => {
    const { getMessages } = await import('@/services/api')
    vi.mocked(getMessages).mockResolvedValue({ data: mockMessages })
    
    renderWithProviders(<ChatInterface />)
    
    await waitFor(() => {
      // Check that messages are loaded and displayed
      const messageBubbles = screen.getAllByTestId('message-bubble')
      expect(messageBubbles).toHaveLength(2)
    })
  })

  it('handles connection status', () => {
    renderWithProviders(<ChatInterface />)
    
    // Check connection status indicator
    const statusIndicator = screen.getByTestId('connection-status')
    expect(statusIndicator).toHaveTextContent('Connected')
  })
})