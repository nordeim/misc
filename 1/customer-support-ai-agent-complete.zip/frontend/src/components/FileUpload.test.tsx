import { describe, it, expect, vi } from 'vitest'
import { screen, fireEvent } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders, createMockFile } from '@/test/utils'
import FileUpload from './FileUpload'

// Mock services
vi.mock('@/services/api', () => ({
  uploadFile: vi.fn(),
}))

// Mock react-hot-toast
vi.mock('react-hot-toast', () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    loading: vi.fn(),
    dismiss: vi.fn(),
  },
}))

describe('FileUpload', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('renders without crashing', () => {
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    expect(document.body).toBeInTheDocument()
  })

  it('displays upload area', () => {
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const uploadArea = screen.getByTestId('file-upload-area')
    expect(uploadArea).toBeInTheDocument()
  })

  it('has drag and drop functionality', async () => {
    const user = userEvent.setup()
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const uploadArea = screen.getByTestId('file-upload-area')
    
    // Test drag enter
    fireEvent.dragEnter(uploadArea, {
      dataTransfer: {
        files: [createMockFile('test.pdf', 1024, 'application/pdf')],
      },
    })
    
    expect(uploadArea).toHaveClass('border-blue-400', 'bg-blue-50')
  })

  it('handles file selection via click', async () => {
    const user = userEvent.setup()
    const onFileSelect = vi.fn()
    renderWithProviders(<FileUpload onFileSelect={onFileSelect} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    expect(onFileSelect).toHaveBeenCalledWith(testFile)
  })

  it('validates file types', async () => {
    const user = userEvent.setup()
    const onFileSelect = vi.fn()
    renderWithProviders(
      <FileUpload 
        onFileSelect={onFileSelect} 
        acceptedTypes={['image/*', 'application/pdf']} 
      />
    )
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.txt', 1024, 'text/plain')
    
    await user.upload(fileInput, testFile)
    
    expect(onFileSelect).not.toHaveBeenCalled()
  })

  it('validates file size', async () => {
    const user = userEvent.setup()
    const { toast } = await import('react-hot-toast')
    renderWithProviders(
      <FileUpload 
        onFileSelect={vi.fn()} 
        maxSize={1024} // 1KB limit
      />
    )
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const largeFile = createMockFile('test.pdf', 2048, 'application/pdf')
    
    await user.upload(fileInput, largeFile)
    
    expect(toast.error).toHaveBeenCalledWith('File size exceeds limit')
  })

  it('displays upload progress', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockImplementation(() => {
      // Simulate upload progress
      return Promise.resolve({
        data: {
          success: true,
          file_id: 'file-123',
        },
      })
    })
    
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    const progressBar = screen.getByTestId('upload-progress')
    expect(progressBar).toBeInTheDocument()
  })

  it('shows uploaded files list', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockResolvedValue({
      data: {
        success: true,
        file_id: 'file-123',
        filename: 'test.pdf',
        size: 1024,
      },
    })
    
    const onFileSelect = vi.fn()
    renderWithProviders(<FileUpload onFileSelect={onFileSelect} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    expect(screen.getByText('test.pdf')).toBeInTheDocument()
    expect(screen.getByText('1.0 KB')).toBeInTheDocument()
  })

  it('allows file removal', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockResolvedValue({
      data: {
        success: true,
        file_id: 'file-123',
        filename: 'test.pdf',
        size: 1024,
      },
    })
    
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    const removeButton = screen.getByTestId('remove-file')
    await user.click(removeButton)
    
    expect(screen.queryByText('test.pdf')).not.toBeInTheDocument()
  })

  it('handles upload errors gracefully', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockRejectedValue(new Error('Upload failed'))
    const { toast } = await import('react-hot-toast')
    
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    expect(toast.error).toHaveBeenCalledWith('Upload failed')
  })

  it('shows loading state during upload', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockImplementation(
      () => new Promise(resolve => setTimeout(() => resolve({ data: {} }), 100))
    )
    
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const testFile = createMockFile('test.pdf', 1024, 'application/pdf')
    
    await user.upload(fileInput, testFile)
    
    const loadingIndicator = screen.getByTestId('upload-loading')
    expect(loadingIndicator).toBeInTheDocument()
  })

  it('has proper accessibility features', () => {
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const uploadArea = screen.getByTestId('file-upload-area')
    expect(uploadArea).toHaveAttribute('role', 'button')
    expect(uploadArea).toHaveAttribute('aria-label', 'Upload files')
    expect(uploadArea).toHaveAttribute('tabindex', '0')
  })

  it('supports keyboard navigation', async () => {
    const user = userEvent.setup()
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const uploadArea = screen.getByTestId('file-upload-area')
    
    // Test keyboard activation
    await user.tab()
    expect(uploadArea).toHaveFocus()
    
    await user.keyboard('{Enter}')
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    expect(fileInput).toBeVisible()
  })

  it('displays supported file types', () => {
    renderWithProviders(
      <FileUpload 
        onFileSelect={vi.fn()} 
        acceptedTypes={['image/*', '.pdf', '.doc']} 
      />
    )
    
    expect(screen.getByText(/Supported formats: PDF, DOC, Images/)).toBeInTheDocument()
  })

  it('handles multiple file uploads', async () => {
    const user = userEvent.setup()
    const { uploadFile } = await import('@/services/api')
    vi.mocked(uploadFile).mockResolvedValue({
      data: {
        success: true,
        file_id: 'file-123',
      },
    })
    
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} multiple />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const files = [
      createMockFile('file1.pdf', 1024, 'application/pdf'),
      createMockFile('file2.png', 2048, 'image/png'),
    ]
    
    await user.upload(fileInput, files)
    
    expect(screen.getByText('file1.pdf')).toBeInTheDocument()
    expect(screen.getByText('file2.png')).toBeInTheDocument()
  })

  it('shows file previews for images', async () => {
    const user = userEvent.setup()
    renderWithProviders(<FileUpload onFileSelect={vi.fn()} />)
    
    const fileInput = screen.getByTestId('file-input') as HTMLInputElement
    const imageFile = createMockFile('image.jpg', 1024, 'image/jpeg')
    
    await user.upload(fileInput, imageFile)
    
    const imagePreview = screen.getByTestId('image-preview')
    expect(imagePreview).toBeInTheDocument()
  })
})