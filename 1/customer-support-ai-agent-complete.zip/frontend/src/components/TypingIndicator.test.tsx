import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/utils'
import TypingIndicator from './TypingIndicator'

// Mock Heroicons
vi.mock('@heroicons/react/24/outline', () => ({
  EllipsisHorizontalIcon: ({ className }: { className?: string }) => (
    <svg data-testid="ellipsis-icon" className={className}>
      <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M5 12h.01M12 12h.01M19 12h.01M6 2l1.09-.09a2 2 0 012.91.5L11.18 4l.18 1.59a2 2 0 01-.5 2.91L10 9l-.09 1.09a2 2 0 01-2.91.5L5 8l-1.59-.18a2 2 0 01-.5-2.91L4.18 4l-.09-1.09a2 2 0 01.5-2.91L6.82 2L8 2.09z" />
    </svg>
  ),
}))

describe('TypingIndicator', () => {
  beforeEach(() => {
    vi.useFakeTimers()
  })

  afterEach(() => {
    vi.useRealTimers()
  })

  it('renders without crashing', () => {
    renderWithProviders(<TypingIndicator />)
    expect(document.body).toBeInTheDocument()
  })

  it('displays typing animation', () => {
    renderWithProviders(<TypingIndicator />)
    
    const indicator = screen.getByTestId('typing-indicator')
    expect(indicator).toBeInTheDocument()
    expect(indicator).toHaveTextContent('Agent is typing')
  })

  it('shows animated dots', () => {
    renderWithProviders(<TypingIndicator />)
    
    const dots = screen.getAllByTestId('typing-dot')
    expect(dots).toHaveLength(3)
    
    // Check initial classes
    dots.forEach((dot, index) => {
      expect(dot).toHaveClass('w-2', 'h-2', 'bg-gray-400', 'rounded-full')
    })
  })

  it('animates typing dots with staggered delays', () => {
    renderWithProviders(<TypingIndicator />)
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // First dot should be active immediately
    expect(dots[0]).toHaveClass('bg-blue-400')
    
    // Advance time to trigger next animation
    vi.advanceTimersByTime(200)
    
    // Second dot should be active
    expect(dots[1]).toHaveClass('bg-blue-400')
    
    // Advance time to trigger next animation
    vi.advanceTimersByTime(200)
    
    // Third dot should be active
    expect(dots[2]).toHaveClass('bg-blue-400')
  })

  it('resets animation cycle', () => {
    renderWithProviders(<TypingIndicator />)
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // Let animation run through full cycle
    vi.advanceTimersByTime(1000)
    
    // Animation should restart
    expect(dots[0]).toHaveClass('bg-blue-400')
  })

  it('handles custom message text', () => {
    renderWithProviders(<TypingIndicator message="Agent is responding" />)
    
    expect(screen.getByText('Agent is responding')).toBeInTheDocument()
  })

  it('supports custom duration', () => {
    renderWithProviders(<TypingIndicator duration={150} />)
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // Check initial animation
    expect(dots[0]).toHaveClass('bg-blue-400')
    
    // Advance time by custom duration
    vi.advanceTimersByTime(150)
    
    expect(dots[1]).toHaveClass('bg-blue-400')
  })

  it('applies correct styling classes', () => {
    renderWithProviders(<TypingIndicator />)
    
    const indicator = screen.getByTestId('typing-indicator')
    expect(indicator).toHaveClass(
      'flex',
      'items-center',
      'space-x-1',
      'text-gray-500',
      'text-sm'
    )
  })

  it('handles pause functionality', async () => {
    renderWithProviders(<TypingIndicator pause={true} />)
    
    const indicator = screen.getByTestId('typing-indicator')
    expect(indicator).toHaveAttribute('aria-hidden', 'true')
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // Dots should not animate when paused
    vi.advanceTimersByTime(500)
    dots.forEach(dot => {
      expect(dot).not.toHaveClass('bg-blue-400')
    })
  })

  it('supports different sizes', () => {
    renderWithProviders(<TypingIndicator size="small" />)
    
    const dots = screen.getAllByTestId('typing-dot')
    dots.forEach(dot => {
      expect(dot).toHaveClass('w-1', 'h-1')
    })
    
    renderWithProviders(<TypingIndicator size="large" />)
    
    const largeDots = screen.getAllByTestId('typing-dot')
    largeDots.forEach(dot => {
      expect(dot).toHaveClass('w-3', 'h-3')
    })
  })

  it('has proper accessibility attributes', () => {
    renderWithProviders(<TypingIndicator />)
    
    const indicator = screen.getByTestId('typing-indicator')
    expect(indicator).toHaveAttribute('role', 'status')
    expect(indicator).toHaveAttribute('aria-live', 'polite')
    expect(indicator).toHaveAttribute('aria-label', 'Agent is typing')
  })

  it('supports custom colors', () => {
    renderWithProviders(<TypingIndicator color="blue" />)
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // Initial active dot should be blue
    expect(dots[0]).toHaveClass('bg-blue-500')
  })

  it('handles rapid state changes', () => {
    renderWithProviders(<TypingIndicator />)
    
    // Simulate rapid enable/disable
    const { rerender } = renderWithProviders(<TypingIndicator pause={true} />)
    rerender(<TypingIndicator pause={false} />)
    
    const dots = screen.getAllByTestId('typing-dot')
    expect(dots[0]).toHaveClass('bg-blue-400')
  })

  it('supports custom animation speeds', () => {
    renderWithProviders(<TypingIndicator speed={300} />)
    
    const dots = screen.getAllByTestId('typing-dot')
    
    // Check initial animation
    expect(dots[0]).toHaveClass('bg-blue-400')
    
    // Advance time by custom speed
    vi.advanceTimersByTime(300)
    
    expect(dots[1]).toHaveClass('bg-blue-400')
  })

  it('handles cleanup on unmount', () => {
    const { unmount } = renderWithProviders(<TypingIndicator />)
    
    // Should not cause memory leaks
    unmount()
    
    // Advance timers to ensure no callbacks are pending
    vi.advanceTimersByTime(1000)
  })

  it('supports different dot counts', () => {
    renderWithProviders(<TypingIndicator dots={5} />)
    
    const dots = screen.getAllByTestId('typing-dot')
    expect(dots).toHaveLength(5)
  })

  it('has proper semantic HTML structure', () => {
    renderWithProviders(<TypingIndicator />)
    
    const indicator = screen.getByTestId('typing-indicator')
    const dotsContainer = screen.getByTestId('typing-dots')
    
    expect(dotsContainer).toHaveClass('flex', 'space-x-1')
    
    const dots = screen.getAllByTestId('typing-dot')
    dots.forEach(dot => {
      expect(dot).toHaveClass('inline-block')
    })
  })

  it('responds to reduced motion preference', () => {
    // Mock reduced motion media query
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: vi.fn().mockImplementation(query => ({
        matches: query === '(prefers-reduced-motion: reduce)',
        media: query,
        onchange: null,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    })
    
    renderWithProviders(<TypingIndicator />)
    
    const dots = screen.getAllByTestId('typing-dot')
    // Should use static animation when motion is reduced
    expect(dots[0]).toHaveClass('opacity-75')
  })
})