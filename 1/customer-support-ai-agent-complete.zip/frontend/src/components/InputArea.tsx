/**
 * InputArea Component

Handles user input with text area, file upload, and send functionality.
Supports multiline input, keyboard shortcuts, and file attachment.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { PaperAirplaneIcon, DocumentTextIcon, XMarkIcon, PlusIcon } from '@heroicons/react/24/outline';
import { fileUploadService } from '../services/fileUpload';

interface InputAreaProps {
  onSendMessage: (message: string, files?: File[]) => void;
  isConnected: boolean;
  isLoading?: boolean;
  disabled?: boolean;
  placeholder?: string;
  sessionId?: string;
  className?: string;
}

interface FilePreview {
  file: File;
  id: string;
  preview?: string;
}

const InputArea: React.FC<InputAreaProps> = ({
  onSendMessage,
  isConnected,
  isLoading = false,
  disabled = false,
  placeholder = "Type your message...",
  sessionId,
  className = '',
}) => {
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState<FilePreview[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [showFileUpload, setShowFileUpload] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);

  // Focus textarea on mount
  useEffect(() => {
    if (textareaRef.current && !disabled) {
      textareaRef.current.focus();
    }
  }, [disabled]);

  // Handle keyboard shortcuts
  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (e.shiftKey) {
        // Allow newline with Shift+Enter
        return;
      } else {
        e.preventDefault();
        handleSendMessage();
      }
    }
  }, [message, files, isConnected, disabled]);

  // Send message
  const handleSendMessage = useCallback(() => {
    if (!message.trim() && files.length === 0) return;
    if (!isConnected || disabled || isLoading) return;

    const fileList = files.map(f => f.file);
    onSendMessage(message.trim(), fileList);
    
    // Reset form
    setMessage('');
    setFiles([]);
    setShowFileUpload(false);
    
    // Focus back to textarea
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [message, files, isConnected, disabled, isLoading, onSendMessage]);

  // Handle text change
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
  };

  // Handle file selection
  const handleFileSelect = (selectedFiles: FileList) => {
    const newFiles = Array.from(selectedFiles).map(file => ({
      file,
      id: `${file.name}-${file.size}-${file.lastModified}`,
    }));

    setFiles(prev => [...prev, ...newFiles]);
  };

  // Remove file
  const removeFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  };

  // Handle drag and drop
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    
    if (e.dataTransfer.types.includes('Files')) {
      setIsDragOver(true);
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    
    if (dragCounter.current === 0) {
      setIsDragOver(false);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    dragCounter.current = 0;
    setIsDragOver(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files);
    }
  }, []);

  // Get file icon
  const getFileIcon = (fileName: string) => {
    return fileUploadService.getFileIcon(fileName);
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    return fileUploadService.formatFileSize(bytes);
  };

  // Check if can send message
  const canSend = message.trim().length > 0 || files.length > 0;

  return (
    <div className={`border-t bg-white ${className}`}>
      {/* File attachments preview */}
      {files.length > 0 && (
        <div className="px-4 py-2 bg-gray-50 border-b">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              Attachments ({files.length})
            </span>
            <button
              onClick={() => setFiles([])}
              className="text-xs text-red-600 hover:text-red-700"
            >
              Clear all
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {files.map((filePreview) => (
              <div
                key={filePreview.id}
                className="flex items-center space-x-2 bg-white p-2 rounded-lg border max-w-xs"
              >
                <span className="text-lg">{getFileIcon(filePreview.file.name)}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {filePreview.file.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(filePreview.file.size)}
                  </p>
                </div>
                <button
                  onClick={() => removeFile(filePreview.id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <XMarkIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Drag and drop overlay */}
      {isDragOver && (
        <div className="absolute inset-0 bg-blue-50 bg-opacity-90 flex items-center justify-center z-10 rounded-lg">
          <div className="text-center">
            <DocumentTextIcon className="w-12 h-12 text-blue-500 mx-auto mb-2" />
            <p className="text-blue-700 font-medium">Drop files here to attach</p>
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="p-4">
        <div className="flex items-end space-x-2">
          {/* Text input */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={handleTextChange}
              onKeyPress={handleKeyPress}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              placeholder={placeholder}
              className={`w-full p-3 border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${
                isDragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
              } ${disabled || !isConnected ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`}
              rows={1}
              style={{ minHeight: '48px', maxHeight: '120px' }}
              disabled={disabled || !isConnected}
              aria-label="Message input"
            />
            
            {/* Character count for long messages */}
            {message.length > 500 && (
              <div className="absolute bottom-1 right-1 text-xs text-gray-400">
                {message.length}/2000
              </div>
            )}
          </div>

          {/* File upload button */}
          <div className="flex flex-col space-y-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={disabled || !isConnected}
              className={`p-3 rounded-lg transition-colors ${
                disabled || !isConnected
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
              }`}
              title="Attach files"
            >
              <DocumentTextIcon className="w-5 h-5" />
            </button>

            {/* Send button */}
            <button
              onClick={handleSendMessage}
              disabled={!canSend || disabled || !isConnected || isLoading}
              className={`p-3 rounded-lg transition-colors ${
                canSend && isConnected && !disabled && !isLoading
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              title="Send message (Enter)"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <PaperAirplaneIcon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => e.target.files && handleFileSelect(e.target.files)}
          accept=".txt,.pdf,.doc,.docx,.json,.csv,.jpg,.jpeg,.png,.gif"
        />

        {/* Status indicators */}
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <div className="flex items-center space-x-4">
            {isConnected ? (
              <span className="flex items-center text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                Connected
              </span>
            ) : (
              <span className="flex items-center text-red-600">
                <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                Disconnected
              </span>
            )}
            
            {files.length > 0 && (
              <span className="text-blue-600">
                {files.length} file{files.length !== 1 ? 's' : ''} attached
              </span>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <span>Press Enter to send, Shift+Enter for new line</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InputArea;