#!/bin/bash

# =============================================================================
# Docker Compose Configuration Verification Script
# =============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
PROJECT_ROOT="/workspace"
ERRORS=0
WARNINGS=0

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
    ((WARNINGS++))
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
    ((ERRORS++))
}

# Test 1: Check required files exist
check_required_files() {
    log_info "Checking required Docker Compose files..."
    
    local files=(
        "docker-compose.yml"
        "docker-compose.prod.yml"
        "docker-compose.override.yml"
        "backend/Dockerfile"
        "backend/Dockerfile.dev"
        "frontend/Dockerfile"
        "frontend/Dockerfile.dev"
        "docker/nginx.conf"
        "docker/nginx.prod.conf"
        "docker/prometheus.yml"
        "docker/README.md"
        ".env.example"
        "deploy.sh"
        "Makefile"
    )
    
    for file in "${files[@]}"; do
        if [ -f "$PROJECT_ROOT/$file" ]; then
            log_success "Found: $file"
        else
            log_error "Missing: $file"
        fi
    done
}

# Test 2: Validate YAML syntax
validate_yaml_syntax() {
    log_info "Validating YAML syntax..."
    
    # Check if yq is available, otherwise use python
    if command -v yq &> /dev/null; then
        if yq eval '.' "$PROJECT_ROOT/docker-compose.yml" > /dev/null 2>&1; then
            log_success "docker-compose.yml syntax is valid"
        else
            log_error "docker-compose.yml has syntax errors"
        fi
        
        if yq eval '.' "$PROJECT_ROOT/docker-compose.prod.yml" > /dev/null 2>&1; then
            log_success "docker-compose.prod.yml syntax is valid"
        else
            log_error "docker-compose.prod.yml has syntax errors"
        fi
    elif command -v python3 &> /dev/null; then
        if python3 -c "import yaml; yaml.safe_load(open('$PROJECT_ROOT/docker-compose.yml'))" 2>/dev/null; then
            log_success "docker-compose.yml syntax is valid"
        else
            log_error "docker-compose.yml has syntax errors"
        fi
        
        if python3 -c "import yaml; yaml.safe_load(open('$PROJECT_ROOT/docker-compose.prod.yml'))" 2>/dev/null; then
            log_success "docker-compose.prod.yml syntax is valid"
        else
            log_error "docker-compose.prod.yml has syntax errors"
        fi
    else
        log_warning "Neither yq nor python3 available, skipping YAML validation"
    fi
}

# Test 3: Check Docker Compose configuration
check_compose_config() {
    log_info "Checking Docker Compose configuration..."
    
    cd "$PROJECT_ROOT"
    
    # Check development configuration
    if docker-compose config > /dev/null 2>&1; then
        log_success "Development compose configuration is valid"
    else
        log_error "Development compose configuration has errors"
        docker-compose config
    fi
    
    # Check production configuration
    if docker-compose -f docker-compose.prod.yml config > /dev/null 2>&1; then
        log_success "Production compose configuration is valid"
    else
        log_error "Production compose configuration has errors"
        docker-compose -f docker-compose.prod.yml config
    fi
}

# Test 4: Validate Dockerfile syntax
check_dockerfile_syntax() {
    log_info "Validating Dockerfile syntax..."
    
    local dockerfiles=(
        "backend/Dockerfile"
        "backend/Dockerfile.dev"
        "frontend/Dockerfile"
        "frontend/Dockerfile.dev"
    )
    
    for dockerfile in "${dockerfiles[@]}"; do
        if [ -f "$PROJECT_ROOT/$dockerfile" ]; then
            # Basic Dockerfile syntax check
            if grep -q "FROM" "$PROJECT_ROOT/$dockerfile"; then
                log_success "$dockerfile has valid FROM statement"
            else
                log_error "$dockerfile missing FROM statement"
            fi
        else
            log_error "Dockerfile not found: $dockerfile"
        fi
    done
}

# Test 5: Check environment file template
check_env_template() {
    log_info "Checking environment template..."
    
    if [ -f "$PROJECT_ROOT/.env.example" ]; then
        local required_vars=(
            "SECRET_KEY"
            "DB_PASSWORD"
            "REDIS_PASSWORD"
            "DATABASE_URL"
            "REDIS_URL"
        )
        
        for var in "${required_vars[@]}"; do
            if grep -q "$var" "$PROJECT_ROOT/.env.example"; then
                log_success "Environment variable defined: $var"
            else
                log_warning "Environment variable might be missing: $var"
            fi
        done
    else
        log_error ".env.example file not found"
    fi
}

# Test 6: Check nginx configurations
check_nginx_config() {
    log_info "Checking nginx configurations..."
    
    local nginx_configs=(
        "docker/nginx.conf"
        "docker/nginx.prod.conf"
        "frontend/nginx.conf"
    )
    
    for config in "${nginx_configs[@]}"; do
        if [ -f "$PROJECT_ROOT/$config" ]; then
            # Basic nginx config validation
            if grep -q "server {" "$PROJECT_ROOT/$config"; then
                log_success "$config has valid server block"
            else
                log_warning "$config might be missing server block"
            fi
        else
            log_error "Nginx config not found: $config"
        fi
    done
}

# Test 7: Check required directories
check_directories() {
    log_info "Checking required directories..."
    
    local dirs=(
        "backend"
        "frontend"
        "docker"
        "data"
        "logs"
        "backups"
    )
    
    for dir in "${dirs[@]}"; do
        if [ -d "$PROJECT_ROOT/$dir" ]; then
            log_success "Directory exists: $dir"
        else
            log_warning "Directory might be missing: $dir"
        fi
    done
}

# Test 8: Validate Prometheus configuration
check_prometheus_config() {
    log_info "Checking Prometheus configuration..."
    
    if [ -f "$PROJECT_ROOT/docker/prometheus.yml" ]; then
        if grep -q "scrape_configs:" "$PROJECT_ROOT/docker/prometheus.yml"; then
            log_success "Prometheus configuration has scrape_configs"
        else
            log_warning "Prometheus configuration might be incomplete"
        fi
        
        if grep -q "customer-support-backend" "$PROJECT_ROOT/docker/prometheus.yml"; then
            log_success "Prometheus configured to scrape backend service"
        else
            log_warning "Prometheus might not be configured to scrape backend"
        fi
    else
        log_error "Prometheus configuration not found"
    fi
}

# Test 9: Check for security issues
check_security() {
    log_info "Checking for potential security issues..."
    
    # Check for default passwords
    if grep -r "postgres123" "$PROJECT_ROOT"/*.yml "$PROJECT_ROOT"/docker/*.yml 2>/dev/null | grep -v ".example" > /dev/null; then
        log_warning "Default password 'postgres123' found in configuration"
    else
        log_success "No default passwords detected"
    fi
    
    # Check for development configurations in production
    if grep -q "DEBUG.*true" "$PROJECT_ROOT/docker-compose.prod.yml" 2>/dev/null; then
        log_warning "Debug mode enabled in production configuration"
    else
        log_success "Debug mode disabled in production"
    fi
    
    # Check for health checks in production
    if grep -q "healthcheck:" "$PROJECT_ROOT/docker-compose.prod.yml"; then
        log_success "Health checks configured in production"
    else
        log_warning "Health checks might be missing in production"
    fi
}

# Test 10: Generate summary report
generate_summary() {
    echo ""
    echo "============================================"
    echo "   DOCKER COMPOSE VERIFICATION SUMMARY"
    echo "============================================"
    echo ""
    
    if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
        log_success "All checks passed! Docker Compose configuration is ready."
        echo ""
        echo "Next steps:"
        echo "  1. cp .env.example .env"
        echo "  2. Edit .env with your configuration"
        echo "  3. Run: make dev"
        echo ""
        return 0
    elif [ $ERRORS -eq 0 ]; then
        log_warning "Configuration is mostly ready with $WARNINGS warnings."
        echo ""
        echo "Recommendations:"
        echo "  - Review warnings above"
        echo "  - Update configuration if needed"
        echo "  - Run make dev to start development"
        echo ""
        return 0
    else
        log_error "Found $ERRORS errors and $WARNINGS warnings in configuration."
        echo ""
        echo "Please fix the errors before proceeding:"
        echo "  - Review error messages above"
        echo "  - Check file permissions"
        echo "  - Verify all required files exist"
        echo ""
        return 1
    fi
}

# Main execution
main() {
    echo ""
    echo "============================================"
    echo "  DOCKER COMPOSE CONFIGURATION VERIFIER"
    echo "============================================"
    echo ""
    
    check_required_files
    echo ""
    
    validate_yaml_syntax
    echo ""
    
    check_compose_config
    echo ""
    
    check_dockerfile_syntax
    echo ""
    
    check_env_template
    echo ""
    
    check_nginx_config
    echo ""
    
    check_directories
    echo ""
    
    check_prometheus_config
    echo ""
    
    check_security
    echo ""
    
    generate_summary
    
    exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        echo "Verification completed successfully!"
    else
        echo "Verification failed. Please review the errors above."
    fi
    
    exit $exit_code
}

# Run main function
main